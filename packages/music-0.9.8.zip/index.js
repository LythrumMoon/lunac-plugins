const Pe = "__lunac_host";
function We() {
  return globalThis[Pe] ?? null;
}
function n(e, i) {
  const s = We();
  return s && typeof s.t == "function" ? s.t(e, i) : e;
}
function He(e, i = !1) {
  return window.__TAURI_INTERNALS__.transformCallback(e, i);
}
async function m(e, i = {}, s) {
  return window.__TAURI_INTERNALS__.invoke(e, i, s);
}
var be;
(function(e) {
  e.WINDOW_RESIZED = "tauri://resize", e.WINDOW_MOVED = "tauri://move", e.WINDOW_CLOSE_REQUESTED = "tauri://close-requested", e.WINDOW_DESTROYED = "tauri://destroyed", e.WINDOW_FOCUS = "tauri://focus", e.WINDOW_BLUR = "tauri://blur", e.WINDOW_SCALE_FACTOR_CHANGED = "tauri://scale-change", e.WINDOW_THEME_CHANGED = "tauri://theme-changed", e.WINDOW_CREATED = "tauri://window-created", e.WINDOW_SUSPENDED = "tauri://suspended", e.WINDOW_RESUMED = "tauri://resumed", e.WEBVIEW_CREATED = "tauri://webview-created", e.DRAG_ENTER = "tauri://drag-enter", e.DRAG_OVER = "tauri://drag-over", e.DRAG_DROP = "tauri://drag-drop", e.DRAG_LEAVE = "tauri://drag-leave";
})(be || (be = {}));
async function je(e, i) {
  window.__TAURI_EVENT_PLUGIN_INTERNALS__.unregisterListener(e, i), await m("plugin:event|unlisten", {
    event: e,
    eventId: i
  });
}
async function Ue(e, i, s) {
  var t;
  const c = (t = void 0) !== null && t !== void 0 ? t : { kind: "Any" };
  return m("plugin:event|listen", {
    event: e,
    target: c,
    handler: He(i)
  }).then((u) => async () => je(e, u));
}
async function Fe(e, i) {
  await m("plugin:shell|open", {
    path: e,
    with: i
  });
}
async function ze(e, i) {
  await m("plugin:clipboard-manager|write_text", {
    label: i == null ? void 0 : i.label,
    text: e
  });
}
const Ve = 1280, Ge = 720, Qe = 550, Ye = 300, Ee = 180, xe = 520, Xe = 4e3, Je = 450, Ke = 800, Ze = 8e3, is = 200, y = {
  play: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polygon points="6 4 20 12 6 20 6 4"/></svg>',
  pause: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="9" y1="4" x2="9" y2="20"/><line x1="15" y1="4" x2="15" y2="20"/></svg>',
  prev: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polygon points="19 5 9 12 19 19 19 5"/><line x1="5" y1="5" x2="5" y2="19"/></svg>',
  next: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polygon points="5 5 15 12 5 19 5 5"/><line x1="19" y1="5" x2="19" y2="19"/></svg>',
  /** 随机（关 / 随机共用这一个；「关」靠 `data-mode` 变暗区分）。 */
  shuffle: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="16 3 21 3 21 8"/><line x1="4" y1="20" x2="21" y2="3"/><polyline points="21 16 21 21 16 21"/><line x1="15" y1="15" x2="21" y2="21"/><line x1="4" y1="4" x2="9" y2="9"/></svg>',
  /** 循环（单曲循环；那个「1」由 CSS `::after` 加，SVG 里不写字）。 */
  repeat: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="17 1 21 5 17 9"/><path d="M3 11V9a4 4 0 0 1 4-4h14"/><polyline points="7 23 3 19 7 15"/><path d="M21 13v2a4 4 0 0 1-4 4H3"/></svg>',
  list: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="9" y1="6" x2="21" y2="6"/><line x1="9" y1="12" x2="21" y2="12"/><line x1="9" y1="18" x2="21" y2="18"/><circle cx="4" cy="6" r="1" fill="currentColor" stroke="none"/><circle cx="4" cy="12" r="1" fill="currentColor" stroke="none"/><circle cx="4" cy="18" r="1" fill="currentColor" stroke="none"/></svg>',
  /** 进播放界面。 */
  expand: '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 3 21 3 21 9"/><polyline points="9 21 3 21 3 15"/><line x1="21" y1="3" x2="14" y2="10"/><line x1="3" y1="21" x2="10" y2="14"/></svg>',
  /** 回默认界面。**唯一**的退出播放界面的入口 —— 播放停止不会自动退出。 */
  back: '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/><line x1="3" y1="12" x2="9" y2="12"/></svg>',
  copy: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15V5a2 2 0 0 1 2-2h10"/></svg>',
  link: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.5 1.5"/><path d="M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7L12 19"/></svg>',
  power: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M18.4 6.6a9 9 0 1 1-12.8 0"/><line x1="12" y1="2" x2="12" y2="12"/></svg>',
  gear: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>',
  volume: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M15.5 8.5a5 5 0 0 1 0 7"/></svg>',
  /** 工具条上的「设备」按钮（2026-09-28）。画成一台小音箱，比「显示器」更贴
   *  Spotify 那种「可选的播放设备」语义。 */
  speaker: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="2" width="14" height="20" rx="2"/><circle cx="12" cy="14" r="3.2"/><circle cx="12" cy="6" r="1" fill="currentColor" stroke="none"/></svg>',
  /** 实心心形（「我喜欢的歌曲」那块封面上的图案）。**这个是 `fill`，不是描边** ——
   *  它是一块封面图（Spotify 的收藏夹封面就是实心心 + 渐变底），不是可点按钮。 */
  heart: '<svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" stroke="none"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>'
};
let a = null, l = null, I = null, Vi = "", Gi = !1, li = [], J = -1, Si = null, pi = null, T = "default", Qi = null, K = null, D = !1, qe = "", E = null, Ui = !1, si = "", P = "", k = null, oi = !1, vi, B = "playlist";
const ri = /* @__PURE__ */ new Map(), fi = /* @__PURE__ */ new Set(), wi = /* @__PURE__ */ new Map();
let v = null, W = null, ui = !1, Q = "", F = !1, Z = !1, U = "tracks", ni = null, G = !1, q = null, H = "", Ti = !1, yi = Ye, Yi = null, bi = "", hi, Ei = !1, xi, Le = 0, Ce = 0, ii = null, Me = null, ai = 0, di = !1, Y = -1, ei = [], _i = 0, z, ti, qi = "", Li = 0, Xi = "";
function r(e) {
  return e.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
function ki(e) {
  if (!isFinite(e) || e < 0) return "0:00";
  const i = Math.floor(e / 1e3), s = Math.floor(i / 60), t = i % 60;
  return `${s}:${String(t).padStart(2, "0")}`;
}
function g(e) {
  const i = e instanceof Error ? e.message : String(e);
  if (i.includes("ERR_NO_CLIENT_ID")) return n("music.err_no_client_id");
  if (i.includes("ERR_NOT_CONNECTED")) return n("music.err_not_connected");
  if (i.includes("ERR_NO_QUERY")) return n("music.err_no_query");
  if (i.includes("ERR_PORT_BUSY")) return n("music.err_port_busy", { port: String((a == null ? void 0 : a.port) ?? "") });
  if (i.includes("ERR_BAD_URI") || i.includes("ERR_BAD_ID")) return n("music.err_bad_uri");
  const s = i.match(/ERR_RATE_LIMITED:(\S*)/);
  return s ? n("music.err_rate_limited", { s: s[1] || "?" }) : i.includes("Insufficient client scope") ? n("music.err_scope") : i.includes("No active device") || i.includes("NO_ACTIVE_DEVICE") ? n("music.err_no_device") : i.includes("Premium required") || i.includes("PREMIUM_REQUIRED") ? n("music.err_premium") : i.includes("Restriction violated") ? n("music.err_restricted") : i;
}
function es(e) {
  const i = [];
  for (const s of e.split(/\r?\n/)) {
    const t = [...s.matchAll(/\[(\d{1,3}):(\d{1,2})(?:[.:](\d{1,3}))?\]/g)];
    if (t.length === 0) continue;
    const c = s.replace(/\[[^\]]*\]/g, "").trim();
    if (c)
      for (const u of t) {
        const p = u[3] ? Number(u[3].padEnd(3, "0")) / 1e3 : 0;
        i.push({ at: Number(u[1]) * 60 + Number(u[2]) + p, text: c });
      }
  }
  return i.sort((s, t) => s.at - t.at), i;
}
function ss() {
  return `
  <div class="music-root">
    <!-- ── 默认界面：顶部工具条 + 状态行 + 连接设置 + 歌单列 / 搜索结果 ──
         工具条与「返回」按钮**分属两态**：默认态用工具条上的「进播放界面」，
         播放态用歌名模块右端那个「返回」（music-back 这个 id 全文档只有一个）。 -->
    <div class="music-view" id="music-v-default">
      <!-- 顶部工具条：头像 / 账号 / 搜索（**带下拉预览**）/ 状态 / 设置。
           2026-09-28 第二次改：设备按钮与「展开播放面板」都**下移到最底下那条控制栏**
           （用户要求「严格对齐 Spotify」，Spotify 的工具条上本来就没有这两样）。 -->
      <div class="music-toolbar">
        <span class="music-avatar" id="music-avatar"></span>
        <span class="music-acc" id="music-acc"></span>
        <div class="music-search-wrap">
          <input class="music-search" id="music-search" type="search" autocomplete="off" spellcheck="false" placeholder="${r(n("music.search_ph"))}">
          <!-- 下拉预览：绝对定位挂在工具条下方（**不占布局**，否则窗口高会跟着抖） -->
          <div class="music-dd hidden" id="music-search-dd"></div>
        </div>
        <span class="music-status" id="music-status">${n("music.loading")}</span>
        <button class="music-ghost-btn music-icon-btn" id="music-setup-toggle" title="${r(n("music.settings"))}">${y.gear}</button>
      </div>

      <div class="music-setup hidden" id="music-setup">
        <div class="music-hint" id="music-setup-hint">${n("music.setup_hint")}</div>
        <!-- 凭据字段默认只在「没有内置 Client ID」或用户主动展开时显示：
             内置值让「登录」变成一步操作，Redirect URI 那一串对普通用户是噪音。 -->
        <button class="music-ghost-btn music-fields-toggle hidden" id="music-fields-toggle"></button>
        <div id="music-setup-fields">
          <div class="music-field">
            <label for="music-client-id">${n("music.client_id")}</label>
            <input id="music-client-id" type="text" spellcheck="false" autocomplete="off" placeholder="${r(n("music.client_id_ph"))}">
          </div>
          <div class="music-field music-field-port">
            <label for="music-port">${n("music.port")}</label>
            <input id="music-port" type="text" inputmode="numeric" autocomplete="off">
          </div>
          <div class="music-field">
            <label>${n("music.redirect")}</label>
            <div class="music-redirect-row">
              <code id="music-redirect"></code>
              <button class="music-ghost-btn music-icon-btn" id="music-copy-redirect" title="${r(n("music.copy"))}">${y.copy}</button>
            </div>
          </div>
          <!-- 本机播放（librespot）的两项设置：路径留空 = 自动探测；代理留空 = 直连。
               两者都不是「必填」，所以各带一行小字说明（见 renderSetup）。 -->
          <div class="music-field">
            <label for="music-librespot">${n("music.local_play")}</label>
            <input id="music-librespot" type="text" spellcheck="false" autocomplete="off" placeholder="librespot.exe">
          </div>
          <div class="music-field">
            <label for="music-librespot-proxy">proxy</label>
            <input id="music-librespot-proxy" type="text" spellcheck="false" autocomplete="off" placeholder="http://127.0.0.1:7890">
          </div>
          <!-- 串流质量：三档互斥按钮。**不用原生 select 元素** —— WebView2 透明窗口里
               它不渲染弹出层（code-rules §5.2）。三档值只允许 96/160/320（宿主侧
               LIBRESPOT_BITRATES，来自 librespot --help 的原文）。
               ⚠️ 这段注释在模板字符串里 ⇒ **不许出现反引号**（预检 #39 ⑩）。 -->
          <div class="music-field">
            <label>${n("music.quality")}</label>
            <div class="music-seg" id="music-quality">
              ${[96, 160, 320].map((e) => `<button type="button" class="music-seg-btn" data-q="${e}">${e}k</button>`).join("")}
            </div>
            <div class="music-hint">${r(n("music.quality_hint"))}</div>
          </div>
        </div>
        <div class="music-actions">
          <button class="music-btn" id="music-save">${n("music.save")}</button>
          <button class="music-btn music-primary" id="music-connect">${y.link} ${n("music.connect")}</button>
          <button class="music-btn" id="music-disconnect">${y.power} ${n("music.disconnect")}</button>
        </div>
      </div>

      <!-- 主体：**左栏（宽度可拖）+ 分隔条 + 主区**（用户 2026-09-28 的
           「歌单列作为单独的一列可拉动」「中间大的大部分区域作为歌曲列表」）。
           两栏各自内部滚动 —— 窗口是定尺 1280×720，不是靠内容撑出来的。 -->
      <div class="music-body hidden" id="music-body">
        <aside class="music-side" id="music-side">
          <div class="music-side-tabs" id="music-side-tabs">
            <button class="music-tab on" data-act="side-tab" data-tab="playlist">${n("music.playlists")}</button>
            <button class="music-tab" data-act="side-tab" data-tab="album">${n("music.tab_albums")}</button>
            <button class="music-tab" data-act="side-tab" data-tab="artist">${n("music.tab_artists")}</button>
            <button class="music-tab" data-act="side-tab" data-tab="show">${n("music.tab_shows")}</button>
          </div>
          <div class="music-side-list" id="music-side-list"></div>
        </aside>
        <div class="music-split" id="music-split" role="separator" aria-orientation="vertical"></div>
        <main class="music-main" id="music-main"></main>
      </div>

      <!-- ── 底部控制栏（2026-09-28，Spotify 复刻）─────────────────────────
           用户要求「在默认面板下方添加 Spotify 那样的播放控制，并把一些按钮也
           移动到下方控制」。三列 grid：左 = 正在播放（点它 = 打开播放面板）、
           中 = 播放键组、右 = 设备 / 音量 / 队列 / 展开。
           栏顶那条 2px 细进度线**绝对定位**（不占高），拖动即可跳转。
           **两个弹层都挂在右端那一簇里、向上弹**：这条栏贴着窗口下沿，
           向下弹会跑到窗口外面（见 styles.css 里那两条覆盖 top 的规则）。
           注意本段是 JS 模板字符串 —— 注释里不能出现反引号（会把字符串截断）。 -->
      <div class="music-nowbar hidden" id="music-nowbar">
        <div class="music-bp" id="music-bp" title="${r(n("music.seek"))}">
          <div class="music-bp-fill" id="music-bp-fill"></div>
          <div class="music-progress-tip" id="music-bp-tip">0:00</div>
        </div>
        <button class="music-bnow" id="music-bnow" title="${r(n("music.open_player"))}">
          <span class="music-bnow-cover" id="music-bnow-cover"></span>
          <span class="music-bnow-main">
            <span class="music-bnow-n" id="music-bnow-n"></span>
            <span class="music-bnow-a" id="music-bnow-a"></span>
          </span>
        </button>
        <div class="music-bctl">
          <button class="music-round-btn music-mode-btn" id="music-b-mode" data-mode="off"></button>
          <button class="music-round-btn" id="music-b-prev" title="${r(n("music.prev"))}">${y.prev}</button>
          <button class="music-round-btn music-play-btn" id="music-b-play" title="${r(n("music.play_pause"))}">${y.play}</button>
          <button class="music-round-btn" id="music-b-next" title="${r(n("music.next"))}">${y.next}</button>
        </div>
        <div class="music-bend">
          <button class="music-ghost-btn music-icon-btn" id="music-devices-btn" title="${r(n("music.devices"))}">${y.speaker}</button>
          <span class="music-vol-ico">${y.volume}</span>
          <input class="music-vol" id="music-b-vol" type="range" min="0" max="100" step="1" value="50" title="${r(n("music.volume"))}">
          <button class="music-round-btn" id="music-b-queue" title="${r(n("music.queue"))}">${y.list}</button>
          <button class="music-ghost-btn music-icon-btn hidden" id="music-open-player" title="${r(n("music.open_player"))}">${y.expand}</button>
          <div class="music-dd music-dev-dd hidden" id="music-dev-dd"></div>
          <div class="music-dd hidden" id="music-q-dd"></div>
        </div>
      </div>
    </div>

    <!-- ── 播放界面：**550×130 的长条**（封面 100 + 右侧列 450）──────────
         右侧列三块的高度加起来正好是长条高：歌名 30 + 歌词 65 + 控制 35 = 130。
         **这几个数都是用户 2026-09-27 给的定尺**：改任何一个都要同步
         styles.css 的 .music-name / .music-lyr / .music-bar，以及宿主
         plugin_window.rs 的 MUSIC_W（见 ai-spec §4.6 与预检 #39 ④）。 -->
    <!-- 注意：本段是 JS 模板字符串，**注释里不能出现反引号**（会把字符串截断）。 -->
    <div class="music-view music-player hidden" id="music-v-player">
      <div class="music-pv-card">
        <div class="music-pv-cover" id="music-pv-cover"></div>
        <div class="music-pv-col">
          <!-- 歌名模块 H30：歌名（亮）+ 歌手·专辑（暗）+ 返回入口。
               「返回」放在这里而不是标题行 —— 播放态整条只有 130 高，
               标题行（状态 / 账号 / 齿轮）在默认态里，这一态不显示。
               时间不在这里（用户 2026-09-27 要求挪到控制块最左端、进度条下方）。 -->
          <div class="music-name">
            <div class="music-name-text">
              <span class="music-title" id="music-pv-title"></span>
              <span class="music-sub" id="music-pv-sub"></span>
            </div>
            <button class="music-ghost-btn music-icon-btn hidden" id="music-back" title="${r(n("music.back"))}">${y.back}</button>
          </div>

          <!-- 歌词模块 H65：正好两行可见（行高 32）。已过 + 正在 = 亮，未到 = 暗；
               点某一行 = 跳到那一句的进度。 -->
          <div class="music-lyr" id="music-lyr"></div>

          <!-- 控制面板 H35：进度条**叠在本块顶部**（绝对定位 ⇒ 不占高度，总高仍是 130），
               四个播放键在块内居中，右端音量条 80px + 播放列表按钮。 -->
          <div class="music-bar">
            <!-- 时间在控制块**最左端、进度条下方**（用户 2026-09-27 定）。
                 绝对定位 ⇒ 不参与四钮的居中计算。 -->
            <div class="music-time">
              <span id="music-pv-pos">0:00</span><span class="music-time-sep">/</span><span id="music-pv-dur">0:00</span>
            </div>
            <div class="music-progress" id="music-pv-progress" title="${r(n("music.seek"))}">
              <div class="music-progress-fill" id="music-pv-fill"></div>
              <div class="music-progress-dot" id="music-pv-dot"></div>
              <div class="music-progress-tip" id="music-pv-tip">0:00</div>
            </div>
            <div class="music-bar-main">
              <button class="music-round-btn music-mode-btn" id="music-mode" data-mode="off"></button>
              <button class="music-round-btn" id="music-prev" title="${r(n("music.prev"))}">${y.prev}</button>
              <button class="music-round-btn music-play-btn" id="music-play" title="${r(n("music.play_pause"))}">${y.play}</button>
              <button class="music-round-btn" id="music-next" title="${r(n("music.next"))}">${y.next}</button>
            </div>
            <div class="music-bar-end">
              <span class="music-vol-ico">${y.volume}</span>
              <input class="music-vol" id="music-vol" type="range" min="0" max="100" step="1" value="50" title="${r(n("music.volume"))}">
              <button class="music-round-btn" id="music-queue-btn" title="${r(n("music.queue"))}">${y.list}</button>
            </div>
          </div>
        </div>
      </div>

      <!-- 播放列表（队列）挂在长条**下方**、不再与歌词互斥：长条是定尺 130，
           塞不进队列。开着时窗口按内容长高（applyResize 实测贴合）。 -->
      <div class="music-q-wrap hidden" id="music-q-wrap">
        <div class="music-sec-head">
          <span class="music-sec-title">${n("music.queue")}</span>
          <span class="music-sec-note">${n("music.queue_hint")}</span>
        </div>
        <div class="music-q" id="music-q"></div>
      </div>
    </div>

    <div class="music-msg" id="music-msg"></div>
  </div>`;
}
function h(e, i) {
  e && e.textContent !== i && (e.textContent = i);
}
function $(e, i) {
  e && e.innerHTML !== i && (e.innerHTML = i);
}
function C(e, i) {
  e == null || e.classList.toggle("hidden", !i);
}
function Ai(e, i, s) {
  e && e.getAttribute(i) !== s && e.setAttribute(i, s);
}
function ts(e) {
  const i = e.querySelector("#music-msg");
  if (!i) return;
  const s = i.textContent ?? "";
  if (s !== qi) {
    qi = s, Li = Date.now();
    return;
  }
  s && Date.now() - Li >= Ze && (i.textContent = "", qi = "", Li = 0);
}
function X(e) {
  const i = T === "player";
  C(e.querySelector("#music-v-default"), !i), C(e.querySelector("#music-v-player"), i), e.classList.toggle("music-player-on", i), ns(i), cs(), Ie(e), i ? (J = -1, Ni(e), Pi(e)) : (C(e.querySelector("#music-body"), !!(a != null && a.connected)), ci(e), N(e), V(e), mi(e)), gi(e);
}
function ns(e) {
  const i = !e;
  document.getElementById("plugin-titlebar") && Yi !== i && (Yi = i, m("plugin_window_set_resizable", { resizable: i }).catch(() => {
  }));
}
function cs() {
  const e = document.getElementById("plugin-close");
  if (!e) return;
  bi || (bi = e.innerHTML);
  const i = T === "player" ? "back" : "close";
  if (e.dataset.mode === i) return;
  e.dataset.mode = i, e.innerHTML = i === "back" ? y.back : bi;
  const s = i === "back" ? n("music.back") : "Close";
  e.title = s, e.setAttribute("aria-label", s);
}
function as() {
  const e = document.getElementById("plugin-close");
  !e || !bi || e.dataset.mode !== "back" || (e.innerHTML = bi, e.title = "Close", e.setAttribute("aria-label", "Close"), e.dataset.mode = "close");
}
async function ls(e) {
  try {
    await m("spotify_control", { action: "pause" });
  } catch (i) {
    M(e, g(i));
  }
  T = "default", X(e);
}
function Ie(e) {
  const i = T === "player";
  C(e.querySelector("#music-open-player"), !i && !!(l != null && l.track)), C(e.querySelector("#music-back"), i), C(e.querySelector("#music-nowbar"), !i && !!(a != null && a.connected));
}
function Di(e, i) {
  const s = e.querySelector("#music-status");
  a != null && a.client_id ? a.connected ? l ? l.active ? l.playing ? h(s, n("music.status_playing")) : h(s, n("music.status_paused")) : h(s, n("music.status_no_device")) : h(s, n("music.status_connecting")) : h(s, n("music.status_disconnected")) : h(s, n("music.status_unconfigured"));
  const t = e.querySelector("#music-avatar");
  if (t) {
    const u = a != null && a.connected && a.avatar || "";
    $(t, u ? `<img src="${r(u)}" alt="">` : "");
  }
  h(e.querySelector("#music-acc"), a != null && a.connected && a.display_name || "");
  const c = e.querySelector("#music-devices-btn");
  c && (Ai(c, "title", `${n("music.devices")}：${(l == null ? void 0 : l.device) || n("music.device_none")}`), c.classList.toggle("warn", !!(a != null && a.connected) && !(l != null && l.active)));
}
function Ci(e) {
  C(e.querySelector("#music-setup"), !(a != null && a.connected)), C(e.querySelector("#music-body"), !!(a != null && a.connected)), ci(e), N(e), a != null && a.connected && (Te(e, B), Ae(e));
  const i = Si ?? !(a != null && a.builtin);
  C(e.querySelector("#music-setup-fields"), i), C(e.querySelector("#music-save"), i);
  const s = e.querySelector("#music-fields-toggle");
  C(s, !!(a != null && a.builtin)), h(s, n(i ? "music.hide_fields" : "music.use_own_client_id")), h(
    e.querySelector("#music-setup-hint"),
    a != null && a.builtin ? n("music.setup_builtin") : n("music.setup_hint")
  );
  const t = e.querySelector("#music-client-id"), c = e.querySelector("#music-port"), u = e.querySelector("#music-librespot"), p = e.querySelector("#music-librespot-proxy");
  t && document.activeElement !== t && (t.value = (a == null ? void 0 : a.client_id) ?? ""), c && document.activeElement !== c && (c.value = String((a == null ? void 0 : a.port) ?? 8899)), u && document.activeElement !== u && (u.value = (a == null ? void 0 : a.librespot_path) ?? ""), p && document.activeElement !== p && (p.value = (a == null ? void 0 : a.librespot_proxy) ?? "");
  const R = pi ?? (a == null ? void 0 : a.librespot_bitrate) ?? 320;
  for (const _ of e.querySelectorAll("#music-quality .music-seg-btn"))
    Ai(_, "aria-pressed", String(Number(_.dataset.q) === R));
  h(e.querySelector("#music-redirect"), (a == null ? void 0 : a.redirect_uri) ?? "");
}
function us(e) {
  var i;
  return !!e.uri && ((i = l == null ? void 0 : l.track) == null ? void 0 : i.uri) === e.uri;
}
function M(e, i) {
  h(e.querySelector("#music-msg"), i);
}
function Oi(e, i, s, t = "", c = "") {
  return `<button class="music-tr${us(e) ? " playing" : ""}" data-act="${s}" data-uri="${r(e.uri)}"${t ? ` data-i="${r(t)}"` : ""}${c ? ` title="${r(c)}"` : ""}>
    <span class="music-tr-i">${i + 1}</span>
    <span class="music-tr-main">
      <span class="music-tr-n">${r(e.name || "?")}</span>
      <span class="music-tr-a">${r(e.artists || e.album)}</span>
    </span>
    <span class="music-tr-d">${ki(e.duration_ms)}</span>
  </button>`;
}
function Bi(e) {
  return { id: e.id, uri: e.uri, name: e.name, cover: e.cover, subtitle: e.owner, total: e.total };
}
function Mi(e, i) {
  const s = !!i.uri && (l == null ? void 0 : l.context_uri) === i.uri, t = (v == null ? void 0 : v.kind) === e && v.id === i.id, c = i.cover ? `<img src="${r(i.cover)}" alt="">` : "";
  return `<div class="music-pl${s ? " playing" : ""}${t ? " on" : ""}" data-uri="${r(i.uri)}">
    <button class="music-pl-btn" data-act="open" data-kind="${e}" data-id="${r(i.id)}" title="${r(i.name || "?")}">
      <span class="music-pl-cover">${c}</span>
      <span class="music-pl-main">
        <span class="music-pl-name">${r(i.name || "?")}</span>
        <span class="music-pl-sub">${r(i.subtitle)}</span>
      </span>
    </button>
  </div>`;
}
function os(e, i) {
  const s = i.cover ? `<img src="${r(i.cover)}" alt="">` : "";
  return `<button class="music-card" data-act="open" data-kind="${e}" data-id="${r(i.id)}" title="${r(i.name)}">
    <span class="music-card-cover${e === "artist" ? " round" : ""}">${s}</span>
    <span class="music-card-n">${r(i.name)}</span>
    <span class="music-card-s">${r(i.subtitle)}</span>
  </button>`;
}
function rs() {
  const e = (v == null ? void 0 : v.kind) === "liked", i = E ? String(E.total) : "", s = si || [(a == null ? void 0 : a.display_name) || "", i].filter(Boolean).join(" · ");
  return `<div class="music-pl music-pl-liked${e ? " on" : ""}${si ? " err" : ""}">
    <button class="music-pl-btn" data-act="open" data-kind="liked" data-id="liked" title="${r(n("music.liked_songs"))}">
      <span class="music-pl-cover music-pl-liked-cover">${y.heart}</span>
      <span class="music-pl-main">
        <span class="music-pl-name">${r(n("music.liked_songs"))}</span>
        <span class="music-pl-sub">${r(s)}</span>
      </span>
    </button>
  </div>`;
}
function ci(e) {
  e.querySelectorAll("#music-side-tabs .music-tab").forEach((u) => {
    u.classList.toggle("on", u.dataset.tab === B);
  });
  const i = e.querySelector("#music-side-list");
  if (!i) return;
  if (!(a != null && a.connected)) {
    $(i, `<div class="music-empty">${n("music.playlists_login")}</div>`);
    return;
  }
  const s = ri.get(B), t = wi.get(B);
  let c = B === "playlist" ? rs() : "";
  fi.has(B) ? c += `<div class="music-empty">${n("music.loading")}</div>` : t ? c += `<div class="music-empty music-empty-err">${r(t)}</div>` : s && (c += s.length === 0 ? `<div class="music-empty">${n(B === "playlist" ? "music.playlists_empty" : "music.lib_empty")}</div>` : s.map((u) => Mi(B, u)).join("")), $(i, c);
}
function Fi(e) {
  e.querySelectorAll("#music-side-list .music-pl").forEach((i) => {
    const s = i.querySelector(".music-pl-btn"), t = !!v && (s == null ? void 0 : s.dataset.kind) === v.kind && (s == null ? void 0 : s.dataset.id) === v.id;
    i.classList.toggle("on", t);
  });
}
function N(e) {
  const i = e.querySelector("#music-main");
  if (!i) return;
  if (Z && P) {
    $(i, ds());
    return;
  }
  if (!v) {
    $(i, `<div class="music-empty">${a != null && a.connected ? n("music.pick_hint") : n("music.playlists_login")}</div>`);
    return;
  }
  const s = v.cover ? `<img src="${r(v.cover)}" alt="">` : "", t = v.kind === "liked" ? n("music.liked_songs") : v.kind === "playlist" ? n("music.playlists") : v.kind === "album" ? n("music.tab_albums") : v.kind === "artist" ? n("music.tab_artists") : n("music.tab_shows");
  let c;
  ui ? c = `<div class="music-empty">${n("music.loading")}</div>` : Q ? c = `<div class="music-empty music-empty-err">${r(Q)}</div>` : !W || W.length === 0 ? c = `<div class="music-empty">${n("music.playlist_empty")}</div>` : c = W.map((u, p) => Oi(u, p, "main-track", String(p))).join(""), $(i, `<div class="music-page">
    <div class="music-page-head">
      <span class="music-page-cover${v.kind === "artist" ? " round" : ""}">${s}</span>
      <div class="music-page-info">
        <span class="music-page-kind">${r(t)}</span>
        <span class="music-page-name">${r(v.name || "?")}</span>
        <span class="music-page-sub">${r(v.subtitle)}</span>
        <div class="music-page-actions">
          <button class="music-btn music-primary" data-act="main-play-all">${y.play} ${n("music.play_all")}</button>
        </div>
      </div>
    </div>
    <div class="music-list">${c}</div>
  </div>`);
}
function ds() {
  const e = k, s = [
    ["tracks", n("music.tracks")],
    ["artists", n("music.tab_artists")],
    ["albums", n("music.tab_albums")],
    ["playlists", n("music.playlists")],
    ["shows", n("music.tab_shows")]
  ].map(([c, u]) => `<button class="music-tab${U === c ? " on" : ""}" data-act="search-tab" data-tab="${c}">${r(u)}</button>`).join("");
  let t;
  if (oi || !e)
    t = `<div class="music-empty">${n("music.loading")}</div>`;
  else if (U === "tracks")
    t = e.tracks.length ? e.tracks.map((c, u) => Oi(c, u, "main-track", String(u))).join("") : `<div class="music-empty">${n("music.search_empty")}</div>`;
  else {
    const u = (U === "artists" ? e.artists : U === "albums" ? e.albums : U === "shows" ? e.shows : e.playlists.map(Bi)).map((p) => os(U === "playlists" ? "playlist" : U === "artists" ? "artist" : U === "albums" ? "album" : "show", p));
    t = u.length ? `<div class="music-grid">${u.join("")}</div>` : `<div class="music-empty">${n("music.search_empty")}</div>`;
  }
  return `<div class="music-page">
    <div class="music-page-info music-page-info-flat">
      <span class="music-page-kind">${n("music.search_result")}</span>
      <span class="music-page-name">${r(P)}</span>
    </div>
    <div class="music-tabs">${s}</div>
    <div class="music-list">${t}</div>
  </div>`;
}
function V(e) {
  const i = e.querySelector("#music-search-dd");
  if (!i) return;
  const s = !!(a != null && a.connected) && F && !!P;
  if (C(i, s), !s) return;
  if (!k) {
    $(i, oi ? `<div class="music-empty">${n("music.loading")}</div>` : "");
    return;
  }
  const t = k, c = [];
  t.tracks.slice(0, 3).forEach((u, p) => c.push(Oi(u, p, "dd-track"))), t.artists.slice(0, 2).forEach((u) => c.push(Mi("artist", u))), t.albums.slice(0, 2).forEach((u) => c.push(Mi("album", u))), t.playlists.slice(0, 2).forEach((u) => c.push(Mi("playlist", Bi(u)))), c.length || c.push(`<div class="music-empty">${n("music.search_empty")}</div>`), c.push(`<button class="music-dd-all" data-act="search-all">${n("music.search_all")}</button>`), $(i, c.join(""));
}
function mi(e) {
  const i = e.querySelector("#music-dev-dd");
  if (!i || (C(i, G), !G)) return;
  const s = q;
  let t = `<div class="music-dd-head">${n("music.devices")}</div>`;
  s != null && s.available && !s.has_credentials ? t += `<button class="music-dev-row" data-act="local-login">
      <span class="music-dev-ico">${y.power}</span>
      <span class="music-dev-main">
        <span class="music-dev-n">${n("music.local_login")}</span>
        <span class="music-dev-s">${n("music.local_login_hint")}</span>
      </span>
    </button>` : s != null && s.available ? t += `<button class="music-dev-row${s.running ? " on" : ""}" data-act="local-toggle">
      <span class="music-dev-ico">${y.power}</span>
      <span class="music-dev-main">
        <span class="music-dev-n">${n("music.local_play")}</span>
        <span class="music-dev-s">${r(s.path || "")}</span>
      </span>
    </button>` : t += `<div class="music-dev-row disabled">
      <span class="music-dev-ico">${y.power}</span>
      <span class="music-dev-main">
        <span class="music-dev-n">${n("music.local_play")}</span>
        <span class="music-dev-s">${n("music.local_no_exe")}</span>
      </span>
    </div>`;
  const c = ni ?? [];
  t += c.length ? c.map((u) => `<button class="music-dev-row${u.active ? " on" : ""}" data-act="dev-pick" data-id="${r(u.id)}">
        <span class="music-dev-ico">${y.speaker}</span>
        <span class="music-dev-main">
          <span class="music-dev-n">${r(u.name || "?")}</span>
          <span class="music-dev-s">${r(u.kind)}</span>
        </span>
      </button>`).join("") : `<div class="music-empty">${n("music.device_none")}</div>`, $(i, t);
}
function ms(e) {
  var t;
  const i = (l == null ? void 0 : l.context_uri) ?? "", s = ((t = l == null ? void 0 : l.track) == null ? void 0 : t.uri) ?? "";
  e.querySelectorAll(".music-pl").forEach((c) => {
    c.classList.toggle("playing", !!i && c.dataset.uri === i);
  }), e.querySelectorAll(".music-tr").forEach((c) => {
    c.classList.toggle("playing", !!s && c.dataset.uri === s);
  });
}
function he(e) {
  yi = Math.min(xe, Math.max(Ee, Math.round(yi))), e.style.setProperty("--music-side-w", `${yi}px`);
}
function Re(e, i) {
  var t;
  if (e === "liked")
    return { id: "liked", uri: "", name: n("music.liked_songs"), cover: "", subtitle: "", total: (E == null ? void 0 : E.total) ?? 0 };
  const s = e === "artist" ? k == null ? void 0 : k.artists : e === "album" ? k == null ? void 0 : k.albums : e === "show" ? k == null ? void 0 : k.shows : k == null ? void 0 : k.playlists.map(Bi);
  return ((t = ri.get(e)) == null ? void 0 : t.find((c) => c.id === i)) ?? (s == null ? void 0 : s.find((c) => c.id === i)) ?? null;
}
async function Te(e, i) {
  if (!(!(a != null && a.connected) || fi.has(i) || ri.has(i))) {
    fi.add(i), wi.delete(i), ci(e);
    try {
      const s = i === "playlist" ? (Qi = await m("spotify_playlists")).map(Bi) : await m(
        i === "album" ? "spotify_albums" : i === "artist" ? "spotify_artists" : "spotify_shows"
      );
      ri.set(i, s);
    } catch (s) {
      wi.set(i, g(s));
    } finally {
      fi.delete(i), ci(e);
    }
  }
}
async function ps(e, i, s) {
  const t = Re(i, s);
  if (t) {
    if (Z = !1, F = !1, v = { kind: i, id: t.id, uri: t.uri, name: t.name, cover: t.cover, subtitle: t.subtitle }, W = null, Q = "", i === "liked") {
      W = (E == null ? void 0 : E.items) ?? null, Q = si, ui = !E, V(e), Fi(e), N(e), E || await Ae(e);
      return;
    }
    ui = !0, V(e), Fi(e), N(e);
    try {
      W = await m("spotify_item_tracks", { kind: i, id: t.id });
    } catch (c) {
      Q = g(c);
    } finally {
      ui = !1, Fi(e), N(e);
    }
  }
}
async function _e(e, i, s, t = 0) {
  const c = Re(i, s);
  if (c)
    try {
      if (i === "liked" || i === "show") {
        const u = (i === "liked" ? E == null ? void 0 : E.items : W) ?? [];
        if (!u.length) return;
        await m("spotify_play_uris", { uris: u.slice(Math.max(0, t)).map((p) => p.uri), deviceId: H || void 0 });
      } else if (c.uri)
        await m("spotify_play_context", { contextUri: c.uri, offsetUri: "", deviceId: H || void 0 });
      else
        return;
    } catch (u) {
      M(e, g(u));
    }
}
async function vs(e, i) {
  if (!v) return;
  const s = W ?? [], t = s[i];
  if (t)
    try {
      v.kind === "liked" || v.kind === "show" ? await m("spotify_play_uris", { uris: s.slice(i).map((c) => c.uri), deviceId: H || void 0 }) : await m("spotify_play_context", { contextUri: v.uri, offsetUri: t.uri, deviceId: H || void 0 });
    } catch (c) {
      M(e, g(c));
    }
}
async function Ji(e) {
  if (!(a != null && a.connected)) return;
  const i = !!(q != null && q.running);
  try {
    const s = await m("music_autoconfigure", { allowLocal: !Ti });
    H = s.device_id || "", s.source === "needs_login" ? M(e, n("music.auto_need_login")) : s.source === "local" && !s.device_id ? M(e, n("music.auto_local_unregistered")) : s.started_local && !i ? M(e, n("music.auto_local_started")) : s.source === "none" && !Ti && M(e, n("music.auto_none"));
  } catch (s) {
    H = "", String(s) !== "ERR_NOT_CONNECTED" && M(e, g(s));
  }
  await $i(e);
}
async function $i(e) {
  try {
    ni = await m("spotify_devices");
  } catch (i) {
    ni = [], M(e, g(i));
  }
  try {
    q = await m("librespot_status");
  } catch {
    q = null;
  }
  mi(e);
}
async function fs(e) {
  if (!(q != null && q.available)) return;
  const i = q.running;
  try {
    q = await m(i ? "librespot_stop" : "librespot_start");
  } catch (s) {
    M(e, g(s));
    return;
  }
  if (Ti = i, mi(e), i) {
    H = "", await Ji(e);
    return;
  }
  for (let s = 0; s < 6; s++) {
    await new Promise((t) => window.setTimeout(t, 1500));
    try {
      const t = await m("spotify_devices");
      ni = t;
      const c = t.find((u) => u.name === "Lunac");
      if (c && !c.active && await m("spotify_transfer", { deviceId: c.id, play: !0 }), c) {
        H = c.id;
        break;
      }
    } catch {
    }
  }
  await $i(e);
}
async function ys(e) {
  try {
    q = await m("librespot_login");
  } catch (i) {
    M(e, g(i));
    return;
  }
  Ti = !1, mi(e), M(e, n("music.local_login_started"));
  for (let i = 0; i < 60; i++) {
    if (await new Promise((t) => window.setTimeout(t, 2e3)), !e.isConnected) return;
    let s;
    try {
      s = await m("librespot_status");
    } catch {
      continue;
    }
    if (q = s, !!s.has_credentials) {
      s.running || (q = await m("librespot_start").catch(() => s));
      for (let t = 0; t < 8; t++) {
        if (await new Promise((p) => window.setTimeout(p, 1500)), !e.isConnected) return;
        const c = await m("spotify_devices").catch(() => []);
        ni = c;
        const u = c.find((p) => p.name === "Lunac");
        if (u) {
          u.active || await m("spotify_transfer", { deviceId: u.id, play: !1 }), H = u.id;
          break;
        }
      }
      M(e, n("music.local_login_ok"));
      break;
    }
  }
  await $i(e);
}
async function bs(e, i) {
  if (i) {
    try {
      await m("spotify_transfer", { deviceId: i, play: !1 }), G = !1;
    } catch (s) {
      M(e, g(s));
    }
    await $i(e);
  }
}
async function Ae(e) {
  if (!(!(a != null && a.connected) || Ui || E)) {
    Ui = !0, si = "", ci(e);
    try {
      E = await m("spotify_liked");
    } catch (i) {
      si = g(i);
    } finally {
      Ui = !1, (v == null ? void 0 : v.kind) === "liked" && (W = (E == null ? void 0 : E.items) ?? null, ui = !1, Q = si), ci(e), N(e);
    }
  }
}
function ge(e, i) {
  if (P = i, F = !!i, vi !== void 0 && (window.clearTimeout(vi), vi = void 0), !i) {
    k = null, oi = !1, Z = !1, V(e), N(e);
    return;
  }
  oi = !0, V(e), N(e), vi = window.setTimeout(() => void hs(e, i), Je);
}
async function hs(e, i) {
  vi = void 0;
  try {
    const s = await m("spotify_search", { query: i });
    if (P !== i) return;
    k = s;
  } catch (s) {
    if (P !== i) return;
    k = null, M(e, g(s));
  } finally {
    P === i && (oi = !1, V(e), N(e));
  }
}
function Ii(e) {
  const i = (K == null ? void 0 : K.items) ?? [], s = n("music.play_from_here"), t = i.length === 0 ? `<div class="music-empty">${n(K ? "music.queue_empty" : "music.loading")}</div>` : i.map((c, u) => Oi(c, u, "play-uri", "", s)).join("");
  for (const c of ["#music-q", "#music-q-dd"]) $(e.querySelector(c), t);
}
async function De(e) {
  var i;
  try {
    K = await m("spotify_queue"), qe = ((i = l == null ? void 0 : l.track) == null ? void 0 : i.id) ?? "";
  } catch (s) {
    K = null, h(e.querySelector("#music-msg"), g(s));
  }
  Ii(e);
}
function Ki(e) {
  const i = (l == null ? void 0 : l.track) ?? null, s = i != null && i.cover ? `<img src="${r(i.cover)}" alt="">` : "", t = [i == null ? void 0 : i.artists, i == null ? void 0 : i.album].filter(Boolean).join(" · ") || (l != null && l.active ? "" : n("music.no_device_hint"));
  $(e.querySelector("#music-pv-cover"), s), $(e.querySelector("#music-bnow-cover"), s), h(e.querySelector("#music-pv-title"), (i == null ? void 0 : i.name) || n("music.no_track")), h(e.querySelector("#music-bnow-n"), (i == null ? void 0 : i.name) || n("music.no_track")), h(e.querySelector("#music-pv-sub"), t), h(e.querySelector("#music-bnow-a"), t);
  const c = (i == null ? void 0 : i.duration_ms) ?? 0, u = Math.min((l == null ? void 0 : l.progress_ms) ?? 0, c || Number.MAX_SAFE_INTEGER), p = c > 0 ? Math.max(0, Math.min(100, u / c * 100)) : 0;
  if (Le = u, Ce = Date.now(), Y < 0)
    for (const w of ei) w.style.setProperty("--seek-pct", `${p}%`);
  h(e.querySelector("#music-pv-pos"), ki(u)), h(e.querySelector("#music-pv-dur"), ki(c));
  const R = l != null && l.playing ? y.pause : y.play;
  $(e.querySelector("#music-play"), R), $(e.querySelector("#music-b-play"), R);
  const _ = Ne(), O = n(_ === "shuffle" ? "music.mode_shuffle" : _ === "repeat_one" ? "music.mode_repeat_one" : "music.mode_off");
  for (const w of [e.querySelector("#music-mode"), e.querySelector("#music-b-mode")])
    w && (Ai(w, "data-mode", _), Ai(w, "title", O), $(w, _ === "repeat_one" ? y.repeat : y.shuffle));
  const x = l && l.volume_percent >= 0 ? String(l.volume_percent) : "";
  for (const w of [e.querySelector("#music-vol"), e.querySelector("#music-b-vol")])
    w && x && document.activeElement !== w && (w.value = x);
  const ee = !(l != null && l.active);
  e.querySelectorAll(".music-bar button, .music-nowbar button").forEach((w) => {
    w.id === "music-devices-btn" || w.id === "music-open-player" || w.id === "music-bnow" || (w.disabled = ee);
  });
}
function _s(e) {
  var c;
  if (!e.isConnected || !(l != null && l.playing) || Y >= 0) return;
  const i = ((c = l.track) == null ? void 0 : c.duration_ms) ?? 0;
  if (i <= 0) return;
  const s = Math.min(Le + (Date.now() - Ce), i), t = Math.max(0, Math.min(100, s / i * 100));
  for (const u of ei) u.style.setProperty("--seek-pct", `${t}%`);
  h(e.querySelector("#music-pv-pos"), ki(s));
}
function Ne() {
  return (l == null ? void 0 : l.repeat) === "track" ? "repeat_one" : l != null && l.shuffle ? "shuffle" : "off";
}
function zi(e) {
  var i, s;
  C(e.querySelector("#music-q-wrap"), D), C(e.querySelector("#music-q-dd"), D), (i = e.querySelector("#music-queue-btn")) == null || i.classList.toggle("on", D), (s = e.querySelector("#music-b-queue")) == null || s.classList.toggle("on", D);
}
function Ni(e) {
  const i = e.querySelector("#music-lyr");
  if (!i) return;
  if (Zi(), J = -1, li = [], di && (di = !1, z !== void 0 && (window.clearTimeout(z), z = void 0)), Gi) {
    $(i, `<div class="music-empty">${n("music.lyrics_loading")}</div>`);
    return;
  }
  if (I != null && I.synced) {
    const t = es(I.synced);
    if (t.length > 0) {
      li = t;
      const c = r(n("music.seek_line"));
      $(
        i,
        `<div class="music-lyr-lines">${t.map((u, p) => `<div class="music-lyr-line" data-i="${p}" title="${c}">${r(u.text)}</div>`).join("")}</div>`
      );
      return;
    }
  }
  const s = ((I == null ? void 0 : I.plain) || "").trim();
  if (s) {
    $(i, `<div class="music-lyr-plain">${r(s)}</div>`);
    return;
  }
  if (I != null && I.instrumental) {
    $(i, `<div class="music-empty">${n("music.lyrics_instrumental")}</div>`);
    return;
  }
  $(i, `<div class="music-empty">${n("music.lyrics_none")}</div>`);
}
function Zi() {
  _i && (cancelAnimationFrame(_i), _i = 0);
}
function we(e, i) {
  Zi();
  const s = e.scrollTop, t = i - s;
  if (Math.abs(t) < 1) {
    e.scrollTop = i;
    return;
  }
  let c = 0;
  const u = (p) => {
    c || (c = p);
    const R = Math.min(1, (p - c) / Ke);
    e.scrollTop = s + t * (1 - Math.pow(1 - R, 5)), _i = R < 1 ? requestAnimationFrame(u) : 0;
  };
  _i = requestAnimationFrame(u);
}
function Pi(e) {
  var _, O;
  if (li.length === 0) return;
  const i = e.querySelector("#music-lyr");
  if (!i || !i.isConnected || i.clientHeight === 0) return;
  const s = ((l == null ? void 0 : l.progress_ms) ?? 0) / 1e3;
  let t = -1;
  for (let x = 0; x < li.length && li[x].at <= s; x++)
    t = x;
  if (t === J) return;
  const c = Math.min(J, t), u = Math.max(J, t);
  for (let x = Math.max(0, c + 1); x <= u; x++)
    (_ = i.querySelector(`.music-lyr-line[data-i="${x}"]`)) == null || _.classList.toggle("done", x <= t);
  (O = i.querySelector(".music-lyr-line.on")) == null || O.classList.remove("on"), J = t;
  const p = i.querySelector(`.music-lyr-line[data-i="${t}"]`);
  if (!p) {
    di || we(i, 0);
    return;
  }
  if (p.classList.add("on"), di) return;
  const R = p.getBoundingClientRect().top - i.getBoundingClientRect().top + i.scrollTop;
  we(i, Math.max(0, R));
}
function ke(e) {
  di = !0, Zi(), z !== void 0 && window.clearTimeout(z), z = window.setTimeout(() => {
    z = void 0, di = !1, J = -1, Pi(e);
  }, Xe);
}
async function Ri(e) {
  try {
    a = await m("music_config_get");
  } catch (i) {
    h(e.querySelector("#music-msg"), g(i));
    return;
  }
  !a.connected && T === "player" && (T = "default", X(e)), Ci(e), Di(e);
}
async function gs(e) {
  if (Vi === e.id) return;
  Vi = e.id, Gi = !0, I = null;
  const i = Me;
  i && Ni(i);
  try {
    I = await m("lyrics_get", {
      title: e.name,
      artist: e.artists,
      album: e.album,
      duration: e.duration_ms / 1e3
    });
  } catch (s) {
    I = { found: !1, instrumental: !1, track: "", artist: "", album: "", duration: 0, synced: null, plain: null }, i && h(i.querySelector("#music-msg"), g(s));
  } finally {
    Gi = !1, i && (Ni(i), Pi(i));
  }
}
async function Oe(e, i) {
  if (i === ai) {
    if (!e.isConnected) {
      ie();
      return;
    }
    if (ts(e), a != null && a.connected) {
      if (!document.hidden && !Ei) {
        Ei = !0;
        try {
          if (l = await m("spotify_status"), i !== ai) return;
          Di(e), Ki(e), Pi(e), ms(e), Ie(e), gi(e);
        } catch (s) {
          if (i !== ai) return;
          String(s).includes("ERR_NOT_CONNECTED") ? await Ri(e) : h(e.querySelector("#music-msg"), g(s));
        } finally {
          Ei = !1;
        }
      }
      l != null && l.track && gs(l.track), D && (l != null && l.track) && l.track.id !== qe && De(e);
    }
    i === ai && (hi = window.setTimeout(() => void Oe(e, i), 1e3));
  }
}
function ie() {
  hi !== void 0 && (window.clearTimeout(hi), hi = void 0), xi !== void 0 && (window.clearInterval(xi), xi = void 0), ai++, Ei = !1;
}
function $e(e) {
  ie();
  const i = ai;
  hi = window.setTimeout(() => void Oe(e, i), 200), xi = window.setInterval(() => _s(e), is);
}
function gi(e) {
  document.getElementById("plugin-titlebar") && (ti !== void 0 && window.clearTimeout(ti), ti = window.setTimeout(() => void ws(e), 80));
}
async function ws(e) {
  if (ti = void 0, !document.getElementById("plugin-titlebar")) return;
  let i = Ve, s = Ge;
  if (T === "player") {
    const c = e.closest(".plugin-result"), u = c == null ? void 0 : c.closest("#results-list");
    if (!c || !u) return;
    const p = getComputedStyle(u), R = parseFloat(p.paddingTop || "0") + parseFloat(p.paddingBottom || "0"), _ = window.innerHeight - u.clientHeight;
    s = Math.round(_ + R + c.getBoundingClientRect().height), i = Qe;
  }
  const t = `${i}x${s}`;
  if (t !== Xi)
    try {
      await m("plugin_window_resize", { width: i, height: s }), Xi = t;
    } catch {
    }
}
async function $s(e) {
  var te, ne, ce, ae, le, ue, oe, re, de, me, pe, ve, fe, ye;
  const i = e.querySelector(".music-root");
  if (!i) return;
  Me = i, T = "default", Si = null, pi = null, D = !1, Xi = "", Yi = null, qi = "", Li = 0, E = null, si = "", Qi = null, ri.clear(), fi.clear(), wi.clear(), B = "playlist", v = null, W = null, ui = !1, Q = "", ni = null, G = !1, q = null, H = "", P = "", k = null, oi = !1, F = !1, Z = !1, U = "tracks", ei = [];
  const s = (o) => h(i.querySelector("#music-msg"), o), t = (o) => i.querySelector(o);
  ii && (ii(), ii = null), ii = await Ue("spotify-auth", (o) => {
    i.isConnected && (o.payload.ok ? (s(n("music.auth_ok")), Ri(i).then(() => {
      $e(i), Ji(i);
    })) : s(o.payload.message || n("music.auth_failed")));
  });
  const c = () => {
    T = "player", X(i);
  }, u = () => {
    T = "default", X(i);
  };
  (te = t("#music-setup-toggle")) == null || te.addEventListener("click", () => {
    T = "default", X(i);
    const o = t("#music-setup");
    o && o.classList.toggle("hidden");
  }), (ne = t("#music-open-player")) == null || ne.addEventListener("click", c), (ce = t("#music-bnow")) == null || ce.addEventListener("click", c), (ae = t("#music-back")) == null || ae.addEventListener("click", u);
  const p = (o) => {
    var d;
    !i.isConnected || T !== "player" || (d = o.target) != null && d.closest("#plugin-close") && (o.stopPropagation(), o.preventDefault(), ls(i));
  };
  document.addEventListener("click", p, !0), (le = t("#music-fields-toggle")) == null || le.addEventListener("click", () => {
    Si = !(Si ?? !(a != null && a.builtin)), Ci(i);
  }), (ue = t("#music-copy-redirect")) == null || ue.addEventListener("click", () => {
    const o = (a == null ? void 0 : a.redirect_uri) || "";
    o && ze(o).then(() => s(n("music.copied"))).catch(() => {
    });
  });
  for (const o of i.querySelectorAll("#music-quality .music-seg-btn"))
    o.addEventListener("click", () => {
      pi = Number(o.dataset.q), Ci(i);
    });
  (oe = t("#music-save")) == null || oe.addEventListener("click", async () => {
    var S, f, L, j;
    const o = ((S = t("#music-client-id")) == null ? void 0 : S.value.trim()) ?? "", d = ((f = t("#music-port")) == null ? void 0 : f.value.trim()) ?? "", b = Number(d);
    if (!o) {
      s(n("music.err_no_client_id"));
      return;
    }
    if (!Number.isInteger(b) || b < 1024 || b > 65535) {
      s(n("music.err_bad_port"));
      return;
    }
    try {
      a = await m("music_config_set", {
        clientId: o,
        port: b,
        // 本机播放那两项**一起交上去**（留空 = 自动探测 / 直连，都是合法值）
        librespotPath: ((L = t("#music-librespot")) == null ? void 0 : L.value.trim()) ?? "",
        librespotProxy: ((j = t("#music-librespot-proxy")) == null ? void 0 : j.value.trim()) ?? "",
        // 串流质量：没点过就传 null（= 别动），点了才带上刚选的那一档
        librespotBitrate: pi
      }), pi = null, s(n("music.saved")), Ci(i), Di(i), q = null;
    } catch (ji) {
      s(g(ji));
    }
  }), (re = t("#music-connect")) == null || re.addEventListener("click", async () => {
    var b, S;
    const o = ((b = t("#music-client-id")) == null ? void 0 : b.value.trim()) ?? "", d = Number(((S = t("#music-port")) == null ? void 0 : S.value.trim()) ?? "");
    if (o && Number.isInteger(d) && d >= 1024)
      try {
        a = await m("music_config_set", {
          clientId: o,
          port: d,
          librespotPath: null,
          librespotProxy: null,
          // 串流质量同上：这条路径只是「先落盘再连」，别动用户选的档
          librespotBitrate: null
        });
      } catch (f) {
        s(g(f));
        return;
      }
    try {
      const f = await m("spotify_connect");
      s(n("music.browser_hint")), await Fe(f);
    } catch (f) {
      s(g(f));
    }
  }), (de = t("#music-disconnect")) == null || de.addEventListener("click", async () => {
    try {
      await m("spotify_disconnect"), l = null, I = null, Vi = "", Qi = null, ri.clear(), wi.clear(), K = null, D = !1, v = null, W = null, Q = "", k = null, P = "", F = !1, Z = !1, ni = null, T = "default", await Ri(i), X(i), Ii(i), s(n("music.disconnected"));
    } catch (o) {
      s(g(o));
    }
  });
  const R = (o) => {
    var f;
    const d = (f = o.target) == null ? void 0 : f.closest("[data-act]");
    if (!d) return;
    const b = d.dataset.kind || "", S = d.dataset.id || "";
    switch (d.dataset.act) {
      case "side-tab":
        B = d.dataset.tab || "playlist", ci(i), Te(i, B);
        break;
      case "search-tab":
        U = d.dataset.tab || "tracks", N(i);
        break;
      case "open":
        ps(i, b, S);
        break;
      case "main-track":
        vs(i, Number(d.dataset.i || "0"));
        break;
      case "main-play-all":
        v && _e(i, v.kind, v.id);
        break;
      case "dd-track":
        d.dataset.uri && Se(i, d.dataset.uri);
        break;
      case "play-uri":
        d.dataset.uri && Se(i, d.dataset.uri);
        break;
      case "search-all":
        F = !1, Z = !0, V(i), N(i);
        break;
      case "dev-pick":
        bs(i, S);
        break;
      case "local-toggle":
        fs(i);
        break;
      case "local-login":
        ys(i);
        break;
    }
  };
  for (const o of ["#music-side-list", "#music-side-tabs", "#music-main", "#music-search-dd", "#music-dev-dd", "#music-q", "#music-q-dd"])
    (me = t(o)) == null || me.addEventListener("click", R);
  (pe = t("#music-side-list")) == null || pe.addEventListener("dblclick", (o) => {
    var f;
    const d = (f = o.target) == null ? void 0 : f.closest('[data-act="open"]');
    if (!d) return;
    const b = d.dataset.kind || "", S = d.dataset.id || "";
    S && _e(i, b, S);
  }), (ve = t("#music-devices-btn")) == null || ve.addEventListener("click", () => {
    G = !G, mi(i), G && $i(i);
  }), he(i), (fe = t("#music-split")) == null || fe.addEventListener("pointerdown", (o) => {
    var L;
    o.preventDefault();
    const d = o.clientX, b = ((L = t("#music-side")) == null ? void 0 : L.getBoundingClientRect().width) ?? yi, S = (j) => {
      yi = Math.min(xe, Math.max(Ee, Math.round(b + j.clientX - d))), he(i);
    }, f = () => {
      window.removeEventListener("pointermove", S), window.removeEventListener("pointerup", f), document.body.classList.remove("music-resizing");
    };
    document.body.classList.add("music-resizing"), window.addEventListener("pointermove", S), window.addEventListener("pointerup", f);
  }), document.addEventListener("pointerdown", (o) => {
    const d = o.target;
    d && (G && !d.closest("#music-dev-dd") && !d.closest("#music-devices-btn") && (G = !1, mi(i)), F && !d.closest(".music-search-wrap") && (F = !1, V(i)), D && !d.closest("#music-q-dd") && !d.closest("#music-b-queue") && !d.closest("#music-queue-btn") && (D = !1, zi(i)));
  });
  const _ = t("#music-search");
  _ == null || _.addEventListener("input", () => ge(i, _.value.trim())), _ == null || _.addEventListener("focus", () => {
    P && (F = !0, V(i));
  }), _ == null || _.addEventListener("keydown", (o) => {
    if (o.key === "Enter" && P) {
      F = !1, Z = !0, V(i), N(i);
      return;
    }
    o.key === "Escape" && (_.value = "", ge(i, ""));
  }), document.body.addEventListener("mouseenter", () => gi(i)), document.body.addEventListener("mouseleave", () => gi(i));
  const O = async (o, d) => {
    try {
      await m("spotify_control", { action: o, value: d });
    } catch (b) {
      s(g(b));
    }
  }, x = (o, d) => {
    var b;
    for (const S of o) (b = t(`#${S}`)) == null || b.addEventListener("click", d);
  };
  x(["music-queue-btn", "music-b-queue"], () => {
    D = !D, zi(i), Ii(i), D ? De(i) : Ki(i), gi(i);
  }), x(["music-prev", "music-b-prev"], () => void O("previous")), x(["music-next", "music-b-next"], () => void O("next")), x(["music-play", "music-b-play"], () => void O(l != null && l.playing ? "pause" : "play"));
  let w = null, Wi = !1;
  const Be = async (o) => {
    if (w = o, !Wi) {
      Wi = !0;
      try {
        for (; w !== null; ) {
          const d = w;
          w = null, await O("volume", d);
        }
      } finally {
        Wi = !1;
      }
    }
  };
  for (const o of ["music-vol", "music-b-vol"])
    (ye = t(`#${o}`)) == null || ye.addEventListener("input", (d) => {
      Be(Number(d.target.value));
    });
  x(["music-mode", "music-b-mode"], () => {
    const o = Ne();
    m("spotify_set_play_mode", { mode: o === "off" ? "shuffle" : o === "shuffle" ? "repeat_one" : "off" }).catch((b) => s(g(b)));
  }), ei = ["#music-pv-progress", "#music-bp"].map((o) => t(o)).filter((o) => !!o);
  for (const o of ei) {
    const d = (f) => {
      const L = o.getBoundingClientRect();
      return Math.max(0, Math.min(1, (f - L.left) / Math.max(1, L.width)));
    }, b = (f) => {
      var j;
      Y = f;
      const L = `${f * 100}%`;
      for (const ji of ei) ji.style.setProperty("--seek-pct", L);
      h(o.querySelector(".music-progress-tip"), ki((((j = l == null ? void 0 : l.track) == null ? void 0 : j.duration_ms) ?? 0) * f));
    };
    o.addEventListener("pointerdown", (f) => {
      var L;
      if (!((((L = l == null ? void 0 : l.track) == null ? void 0 : L.duration_ms) ?? 0) <= 0)) {
        try {
          o.setPointerCapture(f.pointerId);
        } catch {
        }
        o.classList.add("music-dragging"), b(d(f.clientX));
      }
    }), o.addEventListener("pointermove", (f) => {
      Y < 0 || b(d(f.clientX));
    });
    const S = (f) => {
      var j;
      if (Y < 0) return;
      const L = Y;
      Y = -1, o.classList.remove("music-dragging");
      try {
        o.releasePointerCapture(f.pointerId);
      } catch {
      }
      O("seek", Math.round((((j = l == null ? void 0 : l.track) == null ? void 0 : j.duration_ms) ?? 0) * L));
    };
    o.addEventListener("pointerup", S), o.addEventListener("pointercancel", S);
  }
  const A = t("#music-lyr");
  let Hi = !1, se = 0;
  A == null || A.addEventListener("wheel", () => ke(i), { passive: !0 }), A == null || A.addEventListener("pointerdown", (o) => {
    Hi = !1, se = o.clientY, ke(i);
  }), A == null || A.addEventListener("pointermove", (o) => {
    Math.abs(o.clientY - se) > 4 && (Hi = !0);
  }), A == null || A.addEventListener("click", (o) => {
    if (Hi) return;
    const d = o.target.closest(".music-lyr-line"), b = d ? li[Number(d.dataset.i)] : void 0;
    b && O("seek", Math.round(b.at * 1e3));
  }), await Ri(i), X(i), Ki(i), Ni(i), Ii(i), zi(i), Di(i), $e(i), Ji(i);
}
async function Se(e, i) {
  try {
    await m("spotify_play_uri", { uri: i, deviceId: H || void 0 });
  } catch (s) {
    h(e.querySelector("#music-msg"), g(s));
  }
}
function ks() {
  ie(), z !== void 0 && (window.clearTimeout(z), z = void 0), ti !== void 0 && (window.clearTimeout(ti), ti = void 0), ii && (ii(), ii = null), ei = [], as();
}
window.__lunac_music_stop = ks;
const Ss = {
  id: "music",
  name: "音乐歌词",
  keywords: ["音乐", "歌词", "歌曲", "正在播放", "music", "lyrics", "spotify", "播放控制", "暂停", "下一首", "歌单", "播放列表"],
  description: "歌词自动抓取 (LRCLIB + 网易云兜底) + Spotify 播放控制 / 歌单 / 队列",
  icon: "🎵",
  badge: "music",
  // 「本插件一律在**悬浮窗**里打开」（2026-09-29 从 main.ts 的硬编码 `id === "music"` 改成声明）。
  // 为什么要声明而不是让宿主按 id 判：音乐已归入**拓展插件**，要能从市场独立打包分发
  // —— 磁盘插件的代码宿主没法写死，行为只能由插件自己声明（见 ai-spec §3.5「插件契约」）。
  // 这也是「用户 2026-09-28 定的：从 Lunac 进音乐界面时自动展开成独立界面」那条的执行点。
  permissions: ["window.float"],
  async execute() {
    return { type: "html", content: ss() };
  }
};
export {
  $s as attach,
  $s as attachMusicListeners,
  Ss as default,
  ks as detach,
  Ss as musicPlugin,
  ks as stopMusicPolling
};
