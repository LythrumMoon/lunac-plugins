async function m(t, o = {}, e) {
  return window.__TAURI_INTERNALS__.invoke(t, o, e);
}
const O = "__lunac_host";
function U() {
  return globalThis[O] ?? null;
}
function n(t, o) {
  const e = U();
  return e && typeof e.t == "function" ? e.t(t, o) : t;
}
let d = null, f = null, a = null, w = [], y = !1, L = !1, _;
function i(t) {
  return t.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
function r(t) {
  return document.querySelector(t);
}
function u(t) {
  const o = r("#proxy-msg");
  o && (o.textContent = t, _ !== void 0 && window.clearTimeout(_), _ = window.setTimeout(() => {
    const e = r("#proxy-msg");
    e && (e.textContent = ""), _ = void 0;
  }, 3e3));
}
async function E() {
  try {
    d = await m("proxy_config_get");
  } catch (t) {
    u(String(t));
    return;
  }
  try {
    f = await m("proxy_system_get");
  } catch {
    f = null;
  }
  await T(), M();
}
async function T() {
  try {
    a = await m("mihomo_status");
  } catch {
    a = null;
  }
  if (a != null && a.running)
    try {
      w = await m("mihomo_proxies");
    } catch {
      w = [];
    }
  else
    w = [];
}
function M() {
  G(), F(), J();
  const t = r("#proxy-link");
  t && document.activeElement !== t && (t.checked = !!(d != null && d.link_librespot));
  const o = r("#proxy-sys");
  o && document.activeElement !== o && (o.checked = !!(f != null && f.enabled));
}
function F() {
  const t = d == null ? void 0 : d.mihomo, o = a, e = r("#mihomo-state");
  e && (o ? o.installed ? o.running ? e.textContent = n("proxy.m_running", { ver: o.version, port: String(o.mixed_port) }) : e.textContent = n("proxy.m_stopped", { ver: o.version }) : e.textContent = n("proxy.m_need_core") : e.textContent = "", e.classList.toggle("warn", !!(o != null && o.installed) && !(o != null && o.running)));
  const l = r("#mihomo-actions");
  if (l) {
    const v = y ? " disabled" : "";
    if (o != null && o.installed ? o.running ? l.innerHTML = `<button type="button" class="proxy-btn danger" id="mihomo-stop"${v}>${i(n("proxy.m_stop"))}</button>` : l.innerHTML = `<button type="button" class="proxy-btn primary" id="mihomo-start"${v}>${i(n("proxy.m_start"))}</button>` : l.innerHTML = `<button type="button" class="proxy-btn primary" id="mihomo-install"${v}>${i(n("proxy.m_install"))}</button>`, y) {
      const h = document.createElement("span");
      h.className = "proxy-row-note", h.textContent = n("proxy.m_working"), l.appendChild(h);
    }
  }
  const b = r("#mihomo-mode");
  b && t && b.querySelectorAll("[data-mode]").forEach((v) => {
    v.classList.toggle("on", v.dataset.mode === t.mode);
  }), Y(t), S();
}
function Y(t) {
  const o = r("#mihomo-subs");
  if (!o) return;
  const e = (t == null ? void 0 : t.subscriptions) ?? [];
  if (e.length === 0) {
    o.innerHTML = `<div class="proxy-empty">${i(n("proxy.m_no_subs"))}</div>`;
    return;
  }
  o.innerHTML = e.map(
    (l, b) => `<div class="proxy-row" data-sub="${b}">
      <div class="proxy-row-main">
        <div class="proxy-row-label">${i(l.name || n("proxy.m_unnamed"))}</div>
        <div class="proxy-row-server">${i(l.url)}</div>
      </div>
      <button type="button" class="proxy-btn danger" data-mact="sub-del"${y ? " disabled" : ""}>${i(n("proxy.del"))}</button>
    </div>`
  ).join("");
}
function S() {
  const t = r("#mihomo-nodes");
  if (t) {
    if (!(a != null && a.running)) {
      t.innerHTML = "";
      return;
    }
    if (w.length === 0) {
      t.innerHTML = `<div class="proxy-empty">${i(n("proxy.m_no_nodes"))}</div>`;
      return;
    }
    t.innerHTML = w.map((o) => {
      const e = z(o), l = e === null ? "dim" : e > 800 ? "bad" : "ok", b = e === null ? "—" : `${e} ms`;
      if (o.is_group) {
        const v = [...o.all].map(
          (h) => `<button type="button" class="proxy-seg-btn${h === o.now ? " on" : ""}" data-group-pick="${i(h)}"${y ? " disabled" : ""}>${i(h)}</button>`
        ).join("");
        return `<div class="proxy-row proxy-row-group" data-group="${i(o.name)}">
          <div class="proxy-row-main">
            <div class="proxy-row-label">${i(o.name)}<span class="proxy-tag">${i(o.type)}</span></div>
            <div class="proxy-seg proxy-seg-wrap">${v}</div>
          </div>
        </div>`;
      }
      return `<div class="proxy-row" data-node="${i(o.name)}">
        <div class="proxy-row-main">
          <div class="proxy-row-label">${i(o.name)}<span class="proxy-tag">${i(o.type)}</span></div>
        </div>
        <span class="proxy-delay ${l}">${i(b)}</span>
        <button type="button" class="proxy-btn" data-mact="delay" data-name="${i(o.name)}"${y ? " disabled" : ""}>${i(n("proxy.m_test"))}</button>
      </div>`;
    }).join("");
  }
}
function z(t) {
  const o = t.history;
  if (!Array.isArray(o) || o.length === 0) return null;
  const e = o[o.length - 1], l = Number(e == null ? void 0 : e.delay);
  return Number.isFinite(l) && l > 0 ? l : null;
}
function G() {
  const t = r("#proxy-state");
  if (t) {
    if (!f) {
      t.textContent = "";
      return;
    }
    t.textContent = f.enabled ? n("proxy.state_on", { server: f.server }) : n("proxy.state_off"), t.classList.toggle("warn", f.enabled && !(a != null && a.running));
  }
}
function J() {
  const t = r("#mihomo-node-list");
  if (!t) return;
  const o = (a == null ? void 0 : a.nodes) ?? [];
  if (o.length === 0) {
    t.innerHTML = `<div class="proxy-empty">${i(n("proxy.m_no_manual_nodes"))}</div>`;
    return;
  }
  t.innerHTML = o.map(
    (e) => `<div class="proxy-row" data-node-index="${e.index}">
        <div class="proxy-row-main">
          <div class="proxy-row-label">${i(e.name)}<span class="proxy-tag">${i(e.kind)}</span></div>
        </div>
        <button type="button" class="proxy-btn danger" data-mact="node-del"${y ? " disabled" : ""}>${i(n("proxy.del"))}</button>
      </div>`
  ).join("");
}
async function $(t) {
  try {
    await m("librespot_set_proxy", { proxy: t });
  } catch (o) {
    u(n("proxy.err_librespot", { err: String(o) }));
  }
}
async function Q(t) {
  if (!L) {
    L = !0, M();
    try {
      if (t && !(a != null && a.running) && (a = await m("mihomo_start")), a = await m("mihomo_system_proxy_set", { enabled: t }), d != null && d.link_librespot) {
        const o = t ? (a == null ? void 0 : a.mixed_port) ?? 0 : 0;
        await $(o ? `http://127.0.0.1:${o}` : "");
      }
    } catch (o) {
      u(String(o));
    }
    L = !1, await E();
  }
}
async function V(t) {
  if (!d) return;
  const o = { entries: d.entries, active: d.active, link_librespot: t };
  try {
    d = await m("proxy_config_set", { config: o });
  } catch (e) {
    u(String(e)), await E();
    return;
  }
  if (t) {
    const e = a != null && a.running ? a.mixed_port : 0;
    await $(e ? `http://127.0.0.1:${e}` : "");
  } else
    await $(""), u(n("proxy.saved"));
  M();
}
async function g(t) {
  if (!y) {
    y = !0, F();
    try {
      await t();
    } catch (o) {
      u(String(o));
    }
    y = !1, await E();
  }
}
async function K(t, o) {
  a = await m("mihomo_config_set", { cfg: t }), u(n(o));
}
async function W() {
  await g(async () => {
    const t = await m("mihomo_install_core");
    u(t);
  });
}
async function X() {
  await g(async () => {
    a = await m("mihomo_start"), d != null && d.link_librespot && await $(`http://127.0.0.1:${a.mixed_port}`);
  });
}
async function Z() {
  await g(async () => {
    a = await m("mihomo_stop"), d != null && d.link_librespot && await $("");
  });
}
async function I() {
  if (y) return;
  const t = r("#mihomo-node-link"), o = ((t == null ? void 0 : t.value) ?? "").trim();
  if (!o) {
    u(n("proxy.m_node_ph"));
    return;
  }
  await g(async () => {
    a = await m("mihomo_node_add", { link: o }), t && (t.value = ""), u(n("proxy.m_node_added"));
  });
}
async function tt(t) {
  await g(async () => {
    a = await m("mihomo_node_del", { index: t }), u(n("proxy.m_node_deleted"));
  });
}
async function R() {
  const t = d == null ? void 0 : d.mihomo;
  if (!t || y) return;
  const o = r("#mihomo-sub-name"), e = r("#mihomo-sub-url"), l = ((e == null ? void 0 : e.value) ?? "").trim();
  if (!/^https?:\/\//i.test(l)) {
    u(n("proxy.m_err_url"));
    return;
  }
  const b = ((o == null ? void 0 : o.value) ?? "").trim() || `sub_${t.subscriptions.length}`;
  if (t.subscriptions.some((v) => v.url === l)) {
    u(n("proxy.err_dup"));
    return;
  }
  o && (o.value = ""), e && (e.value = ""), await g(() => K({ ...t, subscriptions: [...t.subscriptions, { name: b, url: l }] }, "proxy.m_saved"));
}
async function ot(t) {
  const o = d == null ? void 0 : d.mihomo;
  o && await g(
    () => K({ ...o, subscriptions: o.subscriptions.filter((e, l) => l !== t) }, "proxy.m_saved")
  );
}
async function et(t) {
  await g(async () => {
    a = await m("mihomo_set_mode", { mode: t });
  });
}
async function nt(t) {
  if (!y) {
    y = !0, S();
    try {
      const o = await m("mihomo_delay", { name: t });
      u(n("proxy.m_delay_ok", { name: t, ms: String(o) }));
    } catch (o) {
      u(String(o));
    }
    y = !1, await T(), S();
  }
}
async function it(t, o) {
  if (!y) {
    y = !0;
    try {
      await m("mihomo_select", { group: t, node: o });
    } catch (e) {
      u(String(e));
    }
    y = !1, await T(), S();
  }
}
async function B() {
  try {
    const t = await m("mihomo_log"), o = r("#mihomo-log");
    o && (o.textContent = t || n("proxy.m_log_empty"));
  } catch (t) {
    u(String(t));
  }
}
function at() {
  return `<div class="plugin-result proxy-panel">
  <div class="proxy-head">
    <div class="proxy-title">${i(n("proxy.title"))}</div>
    <div class="proxy-state" id="proxy-state"></div>
  </div>

  <div class="proxy-body">
    <nav class="proxy-nav" id="proxy-nav">
      <button type="button" class="proxy-nav-btn on" data-page="proxies">${i(n("proxy.nav_proxies"))}</button>
      <button type="button" class="proxy-nav-btn" data-page="subs">${i(n("proxy.nav_subs"))}</button>
      <button type="button" class="proxy-nav-btn" data-page="nodes">${i(n("proxy.nav_nodes"))}</button>
      <button type="button" class="proxy-nav-btn" data-page="log">${i(n("proxy.nav_log"))}</button>
    </nav>

    <div class="proxy-pages">
      <section class="proxy-page on" data-page="proxies">
        <div class="proxy-sec-title">${i(n("proxy.m_title"))}</div>
        <div class="proxy-state" id="mihomo-state" title="${i(n("proxy.m_hint"))}"></div>
        <div class="proxy-actions" id="mihomo-actions"></div>
        <label class="proxy-link" title="${i(n("proxy.sys_hint"))}">
          <input type="checkbox" id="proxy-sys" />
          <span>${i(n("proxy.sys"))}</span>
        </label>
        <label class="proxy-link" title="${i(n("proxy.link_hint"))}">
          <input type="checkbox" id="proxy-link" />
          <span>${i(n("proxy.link"))}</span>
        </label>
        <div class="proxy-seg" id="mihomo-mode">
          <button type="button" class="proxy-seg-btn" data-mode="rule">rule</button>
          <button type="button" class="proxy-seg-btn" data-mode="global">global</button>
          <button type="button" class="proxy-seg-btn" data-mode="direct">direct</button>
        </div>
        <div class="proxy-list" id="mihomo-nodes"></div>
      </section>

      <section class="proxy-page" data-page="subs">
        <div class="proxy-list" id="mihomo-subs"></div>
        <div class="proxy-form">
          <input id="mihomo-sub-name" type="text" autocomplete="off" spellcheck="false" placeholder="${i(n("proxy.m_sub_name_ph"))}" />
          <input id="mihomo-sub-url" type="text" autocomplete="off" spellcheck="false" placeholder="${i(n("proxy.m_sub_url_ph"))}" />
          <button type="button" class="proxy-btn primary" id="mihomo-sub-add">${i(n("proxy.m_sub_add"))}</button>
        </div>
      </section>

      <section class="proxy-page" data-page="nodes">
        <div class="proxy-sec-title">${i(n("proxy.m_nodes_title"))}</div>
        <div class="proxy-list" id="mihomo-node-list"></div>
        <div class="proxy-form">
          <input id="mihomo-node-link" type="text" autocomplete="off" spellcheck="false" placeholder="${i(n("proxy.m_node_ph"))}" />
          <button type="button" class="proxy-btn primary" id="mihomo-node-add">${i(n("proxy.m_node_add"))}</button>
        </div>
      </section>

      <section class="proxy-page" data-page="log">
        <div class="proxy-form">
          <button type="button" class="proxy-btn" id="mihomo-log-btn">${i(n("proxy.m_log"))}</button>
        </div>
        <pre class="proxy-log" id="mihomo-log"></pre>
      </section>
    </div>
  </div>
  <div class="proxy-msg" id="proxy-msg"></div>
</div>`;
}
const st = {
  id: "proxy",
  name: "Proxy",
  keywords: ["proxy", "代理", "系统代理", "梯子", "vpn", "socks5", "http proxy", "clash", "mihomo", "订阅", "节点"],
  description: "系统代理管理 + mihomo 内核托管（订阅 / 测速 / 规则）+ 本机播放走代理",
  icon: "🌐",
  badge: "Network",
  // 接管型面板 HTML + **独立窗口**（2026-10-24 用户口径：代理插件一律在独立界面里打开）。
  // `layout.takeover` 保留给插件窗内部挂载用；`window.float` 让主窗口打开时直接开插件窗。
  permissions: ["layout.takeover", "window.float"],
  execute: async () => ({ type: "html", content: at() })
};
async function rt() {
  var o, e, l, b, v, h, H, N, C, A, q, P, j;
  const t = r(".proxy-panel");
  (o = t == null ? void 0 : t.querySelector("#proxy-nav")) == null || o.addEventListener("click", (c) => {
    const s = c.target.closest("[data-page]"), p = s == null ? void 0 : s.dataset.page;
    !t || !p || s != null && s.classList.contains("on") || (t.querySelectorAll("#proxy-nav [data-page]").forEach((x) => {
      x.classList.toggle("on", x.dataset.page === p);
    }), t.querySelectorAll(".proxy-page").forEach((x) => {
      x.classList.toggle("on", x.dataset.page === p);
    }), p === "log" && B());
  }), (e = r("#mihomo-node-list")) == null || e.addEventListener("click", (c) => {
    const s = c.target.closest("[data-mact='node-del']"), p = s == null ? void 0 : s.closest("[data-node-index]"), x = p == null ? void 0 : p.dataset.nodeIndex;
    s && x !== void 0 && tt(Number(x));
  }), (l = r("#mihomo-node-add")) == null || l.addEventListener("click", () => void I()), (b = r("#mihomo-node-link")) == null || b.addEventListener("keydown", (c) => {
    c.key === "Enter" && I();
  }), (v = r("#mihomo-actions")) == null || v.addEventListener("click", (c) => {
    const s = c.target.id;
    s === "mihomo-install" ? W() : s === "mihomo-start" ? X() : s === "mihomo-stop" && Z();
  }), (h = r("#mihomo-subs")) == null || h.addEventListener("click", (c) => {
    const s = c.target.closest("[data-mact='sub-del']"), p = s == null ? void 0 : s.closest("[data-sub]"), x = p == null ? void 0 : p.dataset.sub;
    s && x !== void 0 && ot(Number(x));
  }), (H = r("#mihomo-nodes")) == null || H.addEventListener("click", (c) => {
    const s = c.target, p = s.closest("[data-group-pick]");
    if ((p == null ? void 0 : p.dataset.groupPick) !== void 0) {
      const k = p.closest("[data-group]");
      k != null && k.dataset.group && it(k.dataset.group, p.dataset.groupPick);
      return;
    }
    const x = s.closest("[data-mact='delay']"), D = x == null ? void 0 : x.dataset.name;
    x && D && nt(D);
  }), (N = r("#mihomo-sub-add")) == null || N.addEventListener("click", () => void R());
  for (const c of ["#mihomo-sub-name", "#mihomo-sub-url"])
    (C = r(c)) == null || C.addEventListener("keydown", (s) => {
      s.key === "Enter" && R();
    });
  (A = r("#mihomo-mode")) == null || A.addEventListener("click", (c) => {
    const s = c.target.closest("[data-mode]");
    s != null && s.dataset.mode && et(s.dataset.mode);
  }), (q = r("#mihomo-log-btn")) == null || q.addEventListener("click", () => void B()), (P = r("#proxy-sys")) == null || P.addEventListener("change", (c) => {
    Q(c.target.checked);
  }), (j = r("#proxy-link")) == null || j.addEventListener("change", (c) => {
    V(c.target.checked);
  }), await E();
}
function dt() {
  _ !== void 0 && (window.clearTimeout(_), _ = void 0), d = null, f = null, a = null, w = [], L = !1, y = !1;
}
export {
  rt as attach,
  st as default,
  dt as detach,
  st as proxyPlugin
};
