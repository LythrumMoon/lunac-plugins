async function c(t, a = {}, e) {
  return window.__TAURI_INTERNALS__.invoke(t, a, e);
}
var Q;
(function(t) {
  t.WINDOW_RESIZED = "tauri://resize", t.WINDOW_MOVED = "tauri://move", t.WINDOW_CLOSE_REQUESTED = "tauri://close-requested", t.WINDOW_DESTROYED = "tauri://destroyed", t.WINDOW_FOCUS = "tauri://focus", t.WINDOW_BLUR = "tauri://blur", t.WINDOW_SCALE_FACTOR_CHANGED = "tauri://scale-change", t.WINDOW_THEME_CHANGED = "tauri://theme-changed", t.WINDOW_CREATED = "tauri://window-created", t.WINDOW_SUSPENDED = "tauri://suspended", t.WINDOW_RESUMED = "tauri://resumed", t.WEBVIEW_CREATED = "tauri://webview-created", t.DRAG_ENTER = "tauri://drag-enter", t.DRAG_OVER = "tauri://drag-over", t.DRAG_DROP = "tauri://drag-drop", t.DRAG_LEAVE = "tauri://drag-leave";
})(Q || (Q = {}));
async function ct(t, a) {
  await c("plugin:event|emit", {
    event: t,
    payload: a
  });
}
const xt = "__lunac_host";
function ut() {
  return globalThis[xt] ?? null;
}
function n(t, a) {
  const e = ut();
  return e && typeof e.t == "function" ? e.t(t, a) : t;
}
const mt = "proxy-service-state";
let y = null, o = null, w = [], B = [], g = null, S = !1, k, W, A, P, $ = null, R = 190;
const _t = ["ss", "trojan", "vless", "vmess", "anytls", "hysteria2"], yt = ["aes-256-gcm", "aes-128-gcm", "chacha20-ietf-poly1305"];
let D = "ss", j = "aes-256-gcm", M = /* @__PURE__ */ new Map(), N = !1;
function i(t) {
  return t.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
function s(t) {
  return document.querySelector(t);
}
function x(t) {
  const a = s("#px-msg");
  a && (a.textContent = t, k !== void 0 && window.clearTimeout(k), k = window.setTimeout(() => {
    const e = s("#px-msg");
    e && (e.textContent = ""), k = void 0;
  }, 4e3));
}
function vt(t) {
  if (!Number.isFinite(t) || t <= 0) return "0 B";
  const a = ["B", "KB", "MB", "GB"];
  let e = t, r = 0;
  for (; e >= 1024 && r < a.length - 1; )
    e /= 1024, r++;
  return `${e >= 100 ? e.toFixed(0) : e.toFixed(1)} ${a[r]}`;
}
function X(t) {
  return `${vt(t)}/s`;
}
function ft(t) {
  const a = new Date(t);
  if (!Number.isNaN(a.getTime()))
    return a.toLocaleTimeString([], { hour12: !1 });
  const e = t.match(/T(\d{2}:\d{2}:\d{2})/);
  return e ? e[1] : t.replace("T", " ").replace("Z", "");
}
async function L() {
  try {
    y = await c("proxy_config_get"), o = await c("mihomo_status"), w = await c("mihomo_servers").catch(() => []);
  } catch (t) {
    x(String(t));
    return;
  }
  o != null && o.running ? (U(), bt()) : (F(), g = null, $ = null), at(), nt();
}
function nt() {
  ct(mt, { enabled: !!(o != null && o.enabled) }).catch(() => {
  });
}
async function U() {
  try {
    g = await c("mihomo_exit_info");
  } catch {
    g = null;
  }
  pt();
}
function bt() {
  W === void 0 && (W = window.setInterval(() => void ht(), 1e3), A = window.setInterval(() => void ot(), 2e3), P = window.setInterval(() => void U(), 6e4));
}
function F() {
  W !== void 0 && window.clearInterval(W), A !== void 0 && window.clearInterval(A), P !== void 0 && window.clearInterval(P), W = void 0, A = void 0, P = void 0;
}
async function ht() {
  try {
    o = await c("mihomo_status");
  } catch {
    return;
  }
  if (!o.running) {
    F(), g = null, $ = null, at();
    return;
  }
  const t = performance.now();
  if ($) {
    const a = (t - $.t) / 1e3;
    if (a > 0.2) {
      const e = Math.max(0, o.bytes_up - $.up) / a, r = Math.max(0, o.bytes_down - $.down) / a;
      q("#px-up", X(e)), q("#px-down", X(r));
    }
  }
  $ = { t, up: o.bytes_up, down: o.bytes_down }, st();
}
async function ot() {
  try {
    B = await c("mihomo_requests", { limit: 200 });
  } catch {
    return;
  }
  lt();
}
function q(t, a) {
  const e = s(t);
  e && e.textContent !== a && (e.textContent = a);
}
function at() {
  var d, _, f;
  st(), it(), gt(), rt(), I(), lt(), pt();
  const t = s("#px-set-port");
  t && document.activeElement !== t && (t.value = String(((d = y == null ? void 0 : y.mihomo) == null ? void 0 : d.mixed_port) ?? (o == null ? void 0 : o.mixed_port) ?? 0)), q("#px-set-engine", (o == null ? void 0 : o.engine) === "mihomo" ? "mihomo" : "native"), q("#px-set-log", (o == null ? void 0 : o.log_path) || "—");
  const a = (((_ = y == null ? void 0 : y.mihomo) == null ? void 0 : _.rule_mode) ?? "blacklist") === "whitelist", e = s("#px-rule-mode");
  e && (e.checked = a);
  const r = s("#px-rule-mode-label");
  r && (r.textContent = n(a ? "proxy.px_rule_whitelist" : "proxy.px_rule_blacklist"));
  const l = s("#px-rule-domains");
  l && document.activeElement !== l && (l.value = (((f = y == null ? void 0 : y.mihomo) == null ? void 0 : f.rule_domains) ?? []).join(`
`));
}
function st() {
  const t = s("#px-state");
  if (!t) return;
  if (!o) {
    t.textContent = "";
    return;
  }
  const a = o.engine === "mihomo", e = !!o.enabled;
  if (t.classList.toggle("warn", a || !o.running), a) {
    t.textContent = n("proxy.m_legacy_engine");
    return;
  }
  t.textContent = o.running ? e ? n("proxy.px_state_running", { port: String(o.mixed_port) }) : n("proxy.px_state_ready", { port: String(o.mixed_port) }) : n("proxy.px_state_stopped");
}
function it() {
  const t = s("#px-orb");
  if (!t) return;
  const a = (o == null ? void 0 : o.engine) === "mihomo", e = !!(o != null && o.enabled);
  t.disabled = S || !o || a, t.textContent = n(S ? "proxy.m_working" : e ? "proxy.px_orb_stop" : "proxy.px_orb_start"), t.dataset.state = e ? "running" : "stopped", t.classList.toggle("legacy", a);
}
function gt() {
  var e;
  const t = s("#px-mode-label");
  if (!t) return;
  const a = (((e = y == null ? void 0 : y.mihomo) == null ? void 0 : e.mode) ?? (o == null ? void 0 : o.mode) ?? "rule") === "global" ? "global" : "rule";
  t.textContent = n(a === "global" ? "proxy.px_mode_global" : "proxy.px_mode_rule"), document.querySelectorAll("#px-mode-menu [data-mode]").forEach((r) => {
    r.classList.toggle("on", r.dataset.mode === a);
  });
}
function rt() {
  const t = s("#px-tun");
  t && (t.checked = !!(o != null && o.tun));
}
function pt() {
  var l;
  const t = s("#px-region");
  if (!t) return;
  const a = (o == null ? void 0 : o.selected) || "", e = ((l = w.find((d) => d.name === a)) == null ? void 0 : l.source) || "";
  if (!(o != null && o.running)) {
    t.textContent = n("proxy.px_region_idle");
    return;
  }
  const r = g != null && g.ok ? [g.country, g.region, g.city, g.ip].filter(Boolean).join(" · ") : n("proxy.px_region_unknown");
  t.textContent = [r, a ? `${e ? `${e} / ` : ""}${a}` : ""].filter(Boolean).join("　");
}
function I() {
  const t = s("#px-servers");
  if (!t) return;
  if (w.length === 0) {
    t.innerHTML = `<div class="px-empty">${i(n("proxy.px_server_empty"))}</div>`;
    return;
  }
  const a = !!(o != null && o.running);
  t.innerHTML = w.map((e) => {
    const r = M.get(e.name), l = r === void 0 ? "" : Number.isNaN(r) ? '<span class="px-delay pending">…</span>' : r < 0 ? `<span class="px-delay bad" title="${i(n("proxy.px_delay_failed"))}">×</span>` : `<span class="px-delay${r <= 150 ? " fast" : r >= 400 ? " slow" : ""}">${Math.round(r)} ms</span>`;
    return `<button type="button" class="px-server${e.selected ? " on" : ""}" data-server="${i(e.name)}"${a ? "" : " disabled"}>
        <span class="px-server-main">
          <span class="px-server-name">${i(e.name || n("proxy.m_unnamed"))}</span>
          <span class="px-server-sub">${i(e.server)}:${e.port}　${i(e.transport)}</span>
        </span>
        <span class="px-server-side">
          ${l}
          <span class="px-tag">${i(e.kind)}</span>
          <span class="px-server-src">${i(e.source || n("proxy.px_manual"))}</span>
        </span>
      </button>`;
  }).join("");
}
function lt() {
  const t = s("#px-log-list");
  if (!t) return;
  if (B.length === 0) {
    t.innerHTML = `<div class="px-empty">${i(n("proxy.px_log_empty"))}</div>`;
    return;
  }
  const a = new Map(w.map((e) => [e.name, e.source]));
  t.innerHTML = [...B].reverse().map((e) => {
    const r = e.node && a.get(e.node) || "", l = e.via === "proxy" ? [r, e.node].filter(Boolean).join(" / ") : e.via === "direct" ? n("proxy.px_via_direct") : n("proxy.px_via_reject");
    return `<div class="px-log-row" data-via="${i(e.via)}">
        <span class="px-log-ts">${i(ft(e.ts))}</span>
        <span class="px-log-host" title="${i(`${e.host}:${e.port}`)}">${i(e.host)}<span class="px-log-port">:${e.port}</span></span>
        <span class="px-log-via">${i(l)}</span>
      </div>`;
  }).join("");
}
function J(t) {
  var r;
  const a = s("#px-drawer");
  a == null || a.classList.toggle("open", t);
  const e = s("#px-rail");
  e == null || e.classList.toggle("hidden", t), (r = s("#px-drawer-close")) == null || r.classList.toggle("hidden", !t);
}
function wt(t) {
  const a = s("#px-layer");
  a == null || a.classList.remove("hidden"), document.querySelectorAll(".px-panel").forEach((e) => {
    e.classList.toggle("hidden", e.dataset.panel !== t);
  });
}
function G() {
  var t;
  (t = s("#px-layer")) == null || t.classList.add("hidden");
}
function E() {
  document.querySelectorAll("#px-tools .px-tool").forEach((t) => t.classList.remove("open"));
}
async function $t(t) {
  if (!S) {
    S = !0, it();
    try {
      await t();
    } catch (a) {
      x(String(a));
    }
    S = !1, await L();
  }
}
async function Lt() {
  o && await $t(async () => {
    o != null && o.enabled ? await c("mihomo_stop") : await c("mihomo_start");
  });
}
async function kt(t) {
  if (o != null && o.enabled) {
    x(n("proxy.px_mode_running"));
    return;
  }
  const a = !!(o != null && o.running);
  try {
    a && await c("mihomo_engine_stop");
    try {
      await c("mihomo_set_mode", { mode: t }), x(n("proxy.px_mode_saved"));
    } catch (e) {
      x(String(e));
    }
  } finally {
    a && await c("mihomo_engine_start").catch(() => {
    });
  }
  await L();
}
async function tt(t) {
  try {
    o = await c("mihomo_set_tun", { enabled: t }), x(n(t ? "proxy.px_tun_on" : "proxy.px_tun_off"));
  } catch (e) {
    x(String(e));
  }
  const a = s("#px-tun");
  a && (a.checked = !!(o != null && o.tun)), rt();
}
async function Et(t) {
  var v;
  const a = s("#px-tun");
  if (!t) {
    await tt(!1);
    return;
  }
  if (await c("mihomo_is_elevated").catch(() => !1)) {
    await tt(!0);
    return;
  }
  a && (a.checked = !1);
  const r = await c("mihomo_is_dev_build").catch(() => !1), l = s("#px-tun-title"), d = s("#px-tun-body"), _ = s("#px-tun-ok"), f = s("#px-tun-cancel");
  l && (l.textContent = n(r ? "proxy.px_tun_dev_title" : "proxy.px_tun_warn_title")), d && (d.textContent = n(r ? "proxy.px_tun_dev_body" : "proxy.px_tun_warn_body")), _ == null || _.classList.toggle("hidden", r), f && (f.textContent = n(r ? "proxy.px_tun_dev_ok" : "proxy.px_cancel")), (v = s("#px-tun-modal")) == null || v.classList.remove("hidden");
}
async function St(t) {
  if (!(o != null && o.running)) {
    x(n("proxy.px_select_hint"));
    return;
  }
  try {
    await c("mihomo_select", { group: "", node: t }), x(n("proxy.px_selected", { name: t })), w = await c("mihomo_servers").catch(() => w), I(), U();
  } catch (a) {
    x(String(a));
  }
}
async function Dt() {
  try {
    const t = await c("mihomo_refresh_subs");
    x(n("proxy.px_subs_updated", { n: String(t) }));
  } catch (t) {
    x(String(t));
  }
  await L();
}
async function Nt() {
  if (N) return;
  if (!(o != null && o.running))
    try {
      o = await c("mihomo_engine_start"), w = await c("mihomo_servers").catch(() => w), I();
    } catch {
      x(n("proxy.px_delay_need_running"));
      return;
    }
  const t = w.map((e) => e.name).filter(Boolean);
  if (t.length === 0) {
    x(n("proxy.px_delay_no_nodes"));
    return;
  }
  N = !0, M = new Map(t.map((e) => [e, Number.NaN])), et(), I();
  let a = 0;
  for (const e of t) {
    try {
      const r = await c("mihomo_delay", { name: e });
      M.set(e, r), a++;
    } catch {
      M.set(e, -1);
    }
    I();
  }
  N = !1, et(), x(n("proxy.px_delay_done", { ok: String(a), n: String(t.length) }));
}
function et() {
  const t = s("#px-delay-btn");
  t && (t.disabled = N, t.textContent = n(N ? "proxy.px_delay_testing" : "proxy.px_tool_delay"));
}
async function Ct() {
  try {
    await c("mihomo_engine_start"), await L();
  } catch (t) {
    console.warn("[proxy] engine auto-start failed:", t);
  }
}
async function Ot() {
  var e, r, l;
  if (!(y != null && y.mihomo)) return;
  const t = (((e = s("#px-rule-domains")) == null ? void 0 : e.value) ?? "").split(/\r?\n/).map((d) => d.trim().toLowerCase()).filter((d) => d && !d.startsWith("#") && !d.startsWith("//")), a = {
    ...y.mihomo,
    // 0 = 由宿主在启动时挑一个空闲端口（原语义保留）。
    mixed_port: Math.max(0, Math.min(65535, Number(((r = s("#px-set-port")) == null ? void 0 : r.value) ?? "0") || 0)),
    rule_mode: (l = s("#px-rule-mode")) != null && l.checked ? "whitelist" : "blacklist",
    rule_domains: t
  };
  try {
    o = await c("mihomo_config_set", { cfg: a }), x(n("proxy.px_set_saved")), await L();
  } catch (d) {
    x(String(d));
  }
}
async function Wt() {
  var l, d, _, f;
  const t = (((l = s("#px-c-name")) == null ? void 0 : l.value) ?? "").trim(), a = (((d = s("#px-c-server")) == null ? void 0 : d.value) ?? "").trim(), e = Number(((_ = s("#px-c-port")) == null ? void 0 : _.value) ?? "0"), r = (((f = s("#px-c-cred")) == null ? void 0 : f.value) ?? "").trim();
  if (!a || !e || !r) {
    x(n("proxy.px_custom_required"));
    return;
  }
  try {
    o = await c("mihomo_node_add_custom", {
      name: t,
      server: a,
      port: e,
      kind: D,
      credential: r,
      cipher: D === "ss" ? j : null
    }), x(n("proxy.m_node_added")), G(), await c("mihomo_refresh_subs").catch(() => {
    }), await L();
  } catch (v) {
    x(String(v));
  }
}
async function Mt() {
  const { readText: t } = await Promise.resolve().then(() => Gt);
  return await t() ?? "";
}
async function It() {
  try {
    const t = await Mt(), a = s("#px-paste-text");
    a && (a.value = t), t.trim() || x(n("proxy.px_paste_empty"));
  } catch (t) {
    x(String(t));
  }
}
async function Rt() {
  var l;
  const a = (((l = s("#px-paste-text")) == null ? void 0 : l.value) ?? "").split(/\r?\n/).map((d) => d.trim()).filter((d) => d && !d.startsWith("#"));
  if (a.length === 0) {
    x(n("proxy.px_paste_empty"));
    return;
  }
  let e = 0, r = 0;
  for (const d of a)
    try {
      await c("mihomo_node_add", { link: d }), e++;
    } catch {
      r++;
    }
  x(n("proxy.px_paste_done", { ok: String(e), fail: String(r) })), e > 0 && G(), e > 0 && await c("mihomo_refresh_subs").catch(() => {
  }), await L();
}
function dt() {
  const t = s(".proxy-panel");
  t && t.style.setProperty("--px-log-h", `${R}px`);
}
function Tt() {
  try {
    const t = Number(localStorage.getItem("lunac.proxy.logHeight"));
    Number.isFinite(t) && t >= 80 && t <= 480 && (R = t);
  } catch {
  }
}
function Ht() {
  try {
    localStorage.setItem("lunac.proxy.logHeight", String(Math.round(R)));
  } catch {
  }
}
function At() {
  const t = s("#px-log-handle"), a = s(".proxy-panel");
  if (!t || !a) return;
  let e = 0, r = 0, l = !1;
  const d = () => {
    var C, O;
    const v = ((C = s(".px-top")) == null ? void 0 : C.offsetHeight) ?? 50, T = ((O = s("#px-msg")) == null ? void 0 : O.offsetHeight) ?? 0;
    return Math.max(96, a.clientHeight - v - T - 220 - 24);
  }, _ = () => {
    l && (l = !1, window.removeEventListener("mousemove", f), window.removeEventListener("mouseup", _), window.removeEventListener("blur", _), Ht());
  }, f = (v) => {
    if (l) {
      if ((v.buttons & 1) === 0) {
        _();
        return;
      }
      R = Math.min(d(), Math.max(80, r + (e - v.clientY))), dt(), v.preventDefault();
    }
  };
  t.addEventListener("mousedown", (v) => {
    v.button === 0 && (v.preventDefault(), e = v.clientY, r = R, l = !0, window.removeEventListener("mousemove", f), window.removeEventListener("mouseup", _), window.removeEventListener("blur", _), window.addEventListener("mousemove", f), window.addEventListener("mouseup", _), window.addEventListener("blur", _));
  });
}
function Pt() {
  return _t.map(
    (t) => `<button type="button" class="px-chip${t === D ? " on" : ""}" data-kind="${t}">${t}</button>`
  ).join("");
}
function Bt() {
  return yt.map(
    (t) => `<button type="button" class="px-chip${t === j ? " on" : ""}" data-cipher="${t}">${t}</button>`
  ).join("");
}
function jt() {
  return `<div class="plugin-result proxy-panel">
  <header class="px-top">
    <div class="px-brand">${i(n("proxy.title"))}</div>
    <nav class="px-tools" id="px-tools">
      <div class="px-tool-group">
        <div class="px-tool">
          <button type="button" class="px-tool-btn" data-tool="import">${i(n("proxy.px_tool_import"))}<span class="px-caret">▾</span></button>
          <div class="px-menu">
            <button type="button" data-open="custom">${i(n("proxy.px_import_custom"))}</button>
            <button type="button" data-open="paste">${i(n("proxy.px_import_paste"))}</button>
          </div>
        </div>
        <div class="px-tool">
          <button type="button" class="px-tool-btn" data-action="refresh-subs">${i(n("proxy.px_tool_subs"))}</button>
        </div>
        <div class="px-tool">
          <button type="button" class="px-tool-btn" id="px-delay-btn" data-action="delay">${i(n("proxy.px_tool_delay"))}</button>
        </div>
        <div class="px-tool">
          <button type="button" class="px-tool-btn" data-open="settings">${i(n("proxy.px_tool_settings"))}</button>
        </div>
      </div>
    </nav>
    <div class="px-state" id="px-state"></div>
  </header>

  <section class="px-stage" id="px-stage">
    <div class="px-center">
      <button type="button" class="px-orb" id="px-orb" data-state="stopped">${i(n("proxy.px_orb_start"))}</button>
      <div class="px-speeds">
        <span class="px-speed"><span class="px-speed-label">↑</span><b id="px-up">0 B/s</b></span>
        <span class="px-speed"><span class="px-speed-label">↓</span><b id="px-down">0 B/s</b></span>
      </div>
      <div class="px-region" id="px-region"></div>
      <div class="px-controls">
        <div class="px-tool px-mode">
          <button type="button" class="px-tool-btn" id="px-mode-btn">
            <span id="px-mode-label">${i(n("proxy.px_mode_rule"))}</span><span class="px-caret">▾</span>
          </button>
          <div class="px-menu up" id="px-mode-menu">
            <button type="button" data-mode="rule">${i(n("proxy.px_mode_rule"))}</button>
            <button type="button" data-mode="global">${i(n("proxy.px_mode_global"))}</button>
          </div>
        </div>
        <label class="px-tun" title="${i(n("proxy.px_tun_hint"))}">
          <span>${i(n("proxy.px_tun"))}</span>
          <input type="checkbox" id="px-tun" />
          <i class="px-switch"></i>
        </label>
      </div>
    </div>

    <button type="button" class="px-rail" id="px-rail" title="${i(n("proxy.px_drawer_open"))}">${i(n("proxy.px_drawer_open"))}</button>
    <aside class="px-drawer" id="px-drawer">
      <div class="px-drawer-head">
        <b>${i(n("proxy.px_drawer_title"))}</b>
      </div>
      <div class="px-drawer-list" id="px-servers"></div>
    </aside>
    <!-- 拉回：与左侧「服务器」拉手同一形状（竖向贴在左缘），只是高度 60 且用 < 图标 -->
    <button type="button" class="px-rail px-rail-close hidden" id="px-drawer-close" title="${i(n("proxy.px_drawer_close"))}" aria-label="${i(n("proxy.px_drawer_close"))}">
      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/></svg>
    </button>
  </section>

  <section class="px-log" id="px-log">
    <div class="px-log-handle" id="px-log-handle" title="${i(n("proxy.px_log_resize"))}"></div>
    <div class="px-log-head">
      <b>${i(n("proxy.px_log_title"))}</b>
      <span class="px-log-hint">${i(n("proxy.px_log_hint"))}</span>
    </div>
    <div class="px-log-list" id="px-log-list"></div>
  </section>

  <div class="px-msg" id="px-msg"></div>

  <!-- TUN 的管理员闸门：独立警告框，同意后才请求提权重启。 -->
  <div class="px-modal hidden" id="px-tun-modal">
    <div class="px-modal-card">
      <b id="px-tun-title">${i(n("proxy.px_tun_warn_title"))}</b>
      <p id="px-tun-body">${i(n("proxy.px_tun_warn_body"))}</p>
      <div class="px-modal-btns">
        <button type="button" class="px-btn" id="px-tun-cancel">${i(n("proxy.px_cancel"))}</button>
        <button type="button" class="px-btn primary" id="px-tun-ok">${i(n("proxy.px_tun_elevate"))}</button>
      </div>
    </div>
  </div>

  <div class="px-layer hidden" id="px-layer">
    <section class="px-panel hidden" data-panel="custom">
      <div class="px-panel-head">
        <b>${i(n("proxy.px_import_custom"))}</b>
        <button type="button" class="px-btn" data-close>${i(n("proxy.px_close"))}</button>
      </div>
      <div class="px-form">
        <label class="px-field"><span>${i(n("proxy.px_field_name"))}</span>
          <input id="px-c-name" type="text" autocomplete="off" spellcheck="false" placeholder="${i(n("proxy.m_sub_name_ph"))}" /></label>
        <label class="px-field"><span>${i(n("proxy.px_field_server"))}</span>
          <input id="px-c-server" type="text" autocomplete="off" spellcheck="false" placeholder="example.com" /></label>
        <label class="px-field small"><span>${i(n("proxy.px_field_port"))}</span>
          <input id="px-c-port" type="number" min="1" max="65535" placeholder="443" /></label>
        <label class="px-field"><span>${i(n("proxy.px_field_cred"))}</span>
          <input id="px-c-cred" type="password" autocomplete="off" spellcheck="false" placeholder="${i(n("proxy.px_cred_ph"))}" /></label>
        <div class="px-field wide"><span>${i(n("proxy.px_field_kind"))}</span>
          <div class="px-chips" id="px-kind">${Pt()}</div></div>
        <div class="px-field wide" id="px-cipher-wrap"><span>${i(n("proxy.px_field_cipher"))}</span>
          <div class="px-chips" id="px-cipher">${Bt()}</div></div>
      </div>
      <div class="px-panel-foot">
        <button type="button" class="px-btn primary" id="px-c-add">${i(n("proxy.px_add"))}</button>
      </div>
    </section>

    <section class="px-panel hidden" data-panel="paste">
      <div class="px-panel-head">
        <b>${i(n("proxy.px_import_paste"))}</b>
        <button type="button" class="px-btn" data-close>${i(n("proxy.px_close"))}</button>
      </div>
      <p class="px-note">${i(n("proxy.px_paste_hint"))}</p>
      <textarea id="px-paste-text" spellcheck="false" placeholder="${i(n("proxy.px_paste_ph"))}"></textarea>
      <div class="px-panel-foot">
        <button type="button" class="px-btn" id="px-paste-read">${i(n("proxy.px_paste_read"))}</button>
        <button type="button" class="px-btn primary" id="px-paste-import">${i(n("proxy.px_paste_import"))}</button>
      </div>
    </section>

    <section class="px-panel hidden" data-panel="settings">
      <div class="px-panel-head">
        <b>${i(n("proxy.px_tool_settings"))}</b>
        <button type="button" class="px-btn" data-close>${i(n("proxy.px_close"))}</button>
      </div>
      <div class="px-setrow plain"><span><b>${i(n("proxy.px_set_port"))}</b></span>
        <input id="px-set-port" class="px-num" type="number" min="0" max="65535" placeholder="0" /></div>
      <div class="px-setrow plain"><span><b>${i(n("proxy.px_set_engine"))}</b></span><span id="px-set-engine">native</span></div>
      <div class="px-setrow plain"><span><b>${i(n("proxy.px_set_log"))}</b></span><span id="px-set-log" class="px-wrap">—</span></div>
      <div class="px-setrow plain"><span><b>${i(n("proxy.px_set_rule_profile"))}</b></span>
        <span class="px-rule-mode">
          <em id="px-rule-mode-label">${i(n("proxy.px_rule_blacklist"))}</em>
          <label class="px-tun"><input type="checkbox" id="px-rule-mode" /><i class="px-switch"></i></label>
        </span>
      </div>
      <div class="px-field wide">
        <span>${i(n("proxy.px_rule_domains"))}</span>
        <textarea id="px-rule-domains" rows="6" spellcheck="false"></textarea>
      </div>
      <div class="px-panel-foot">
        <button type="button" class="px-btn primary" id="px-dom-save">${i(n("proxy.px_set_save"))}</button>
      </div>
    </section>
  </div>
</div>`;
}
const Ut = {
  id: "proxy",
  name: "Proxy",
  keywords: ["proxy", "代理", "系统代理", "梯子", "vpn", "socks5", "http proxy", "订阅", "节点"],
  description: "系统代理 + 自研代理内核（订阅 / 服务器 / 规则 / 请求日志）",
  icon: "🌐",
  badge: "Network",
  permissions: ["layout.takeover", "window.float"],
  execute: async () => ({ type: "html", content: jt() })
};
async function Ft() {
  var a, e, r, l, d, _, f, v, T, C, O, Y, V, z, K, Z;
  const t = s(".proxy-panel");
  t && (Tt(), dt(), At(), (a = s("#px-tools")) == null || a.addEventListener("click", (u) => {
    const p = u.target, m = p.closest("[data-open]");
    if (m != null && m.dataset.open) {
      E(), wt(m.dataset.open);
      return;
    }
    if (p.closest("[data-action='refresh-subs']")) {
      E(), Dt();
      return;
    }
    if (p.closest("[data-action='delay']")) {
      E(), Nt();
      return;
    }
    const b = p.closest("[data-tool]");
    if (b) {
      const h = b.parentElement, H = h == null ? void 0 : h.classList.contains("open");
      E(), h && !H && h.classList.add("open");
    }
  }), (e = s("#px-mode-btn")) == null || e.addEventListener("click", (u) => {
    var p, m;
    u.stopPropagation(), (m = (p = s("#px-mode-btn")) == null ? void 0 : p.parentElement) == null || m.classList.toggle("open");
  }), (r = s("#px-mode-menu")) == null || r.addEventListener("click", (u) => {
    var m, b;
    const p = u.target.closest("[data-mode]");
    (b = (m = s("#px-mode-btn")) == null ? void 0 : m.parentElement) == null || b.classList.remove("open"), p != null && p.dataset.mode && kt(p.dataset.mode);
  }), (l = s("#px-rail")) == null || l.addEventListener("click", () => J(!0)), (d = s("#px-drawer-close")) == null || d.addEventListener("click", () => J(!1)), (_ = s("#px-servers")) == null || _.addEventListener("click", (u) => {
    const p = u.target.closest("[data-server]");
    p != null && p.dataset.server && St(p.dataset.server);
  }), (f = s("#px-orb")) == null || f.addEventListener("click", () => void Lt()), (v = s("#px-tun")) == null || v.addEventListener("change", (u) => {
    Et(u.target.checked);
  }), (T = s("#px-tun-cancel")) == null || T.addEventListener("click", () => {
    var p;
    (p = s("#px-tun-modal")) == null || p.classList.add("hidden");
    const u = s("#px-tun");
    u && (u.checked = !!(o != null && o.tun));
  }), (C = s("#px-tun-ok")) == null || C.addEventListener("click", () => {
    var u;
    (u = s("#px-tun-modal")) == null || u.classList.add("hidden"), c("mihomo_relaunch_elevated").catch((p) => x(String(p)));
  }), (O = s("#px-layer")) == null || O.addEventListener("click", (u) => {
    const p = u.target;
    if (p.closest("[data-close]")) {
      G();
      return;
    }
    const m = p.closest("[data-kind]");
    if (m != null && m.dataset.kind) {
      D = m.dataset.kind, t.querySelectorAll("#px-kind [data-kind]").forEach((H) => {
        H.classList.toggle("on", H.dataset.kind === D);
      });
      const h = s("#px-cipher-wrap");
      h == null || h.classList.toggle("hidden", D !== "ss");
    }
    const b = p.closest("[data-cipher]");
    b != null && b.dataset.cipher && (j = b.dataset.cipher, t.querySelectorAll("#px-cipher [data-cipher]").forEach((h) => {
      h.classList.toggle("on", h.dataset.cipher === j);
    }));
  }), (Y = s("#px-c-add")) == null || Y.addEventListener("click", () => void Wt()), (V = s("#px-paste-read")) == null || V.addEventListener("click", () => void It()), (z = s("#px-paste-import")) == null || z.addEventListener("click", () => void Rt()), (K = s("#px-rule-mode")) == null || K.addEventListener("change", (u) => {
    const p = u.target.checked, m = s("#px-rule-mode-label");
    m && (m.textContent = n(p ? "proxy.px_rule_whitelist" : "proxy.px_rule_blacklist"));
  }), (Z = s("#px-dom-save")) == null || Z.addEventListener("click", () => void Ot()), t.addEventListener("click", (u) => {
    var m, b;
    const p = u.target;
    p.closest(".px-tool") || E(), p.closest(".px-mode") || (b = (m = s("#px-mode-btn")) == null ? void 0 : m.parentElement) == null || b.classList.remove("open");
  }), await L(), o != null && o.running && ot(), Ct());
}
function Yt() {
  const t = !!(o != null && o.running), a = !!(o != null && o.enabled);
  k !== void 0 && window.clearTimeout(k), k = void 0, F(), E(), G(), t && !a && c("mihomo_engine_stop").catch(() => {
  }), nt(), y = null, o = null, w = [], B = [], g = null, $ = null, S = !1, M = /* @__PURE__ */ new Map(), N = !1;
}
async function qt() {
  return await c("plugin:clipboard-manager|read_text");
}
const Gt = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  readText: qt
}, Symbol.toStringTag, { value: "Module" }));
export {
  Ft as attach,
  Ut as default,
  Yt as detach,
  Ut as proxyPlugin
};
