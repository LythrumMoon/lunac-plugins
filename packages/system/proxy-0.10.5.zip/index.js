async function c(t, o = {}, e) {
  return window.__TAURI_INTERNALS__.invoke(t, o, e);
}
const dt = "__lunac_host";
function ct() {
  return globalThis[dt] ?? null;
}
function n(t, o) {
  const e = ct();
  return e && typeof e.t == "function" ? e.t(t, o) : t;
}
let _ = null, a = null, w = [], R = [], g = null, S = !1, k, N, A, D, $ = null, B = 190;
const xt = ["ss", "trojan", "vless", "vmess", "anytls", "hysteria2"], ut = ["aes-256-gcm", "aes-128-gcm", "chacha20-ietf-poly1305"];
let T = "ss", O = "aes-256-gcm", P = /* @__PURE__ */ new Map(), M = !1;
function i(t) {
  return t.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
function s(t) {
  return document.querySelector(t);
}
function x(t) {
  const o = s("#px-msg");
  o && (o.textContent = t, k !== void 0 && window.clearTimeout(k), k = window.setTimeout(() => {
    const e = s("#px-msg");
    e && (e.textContent = ""), k = void 0;
  }, 4e3));
}
function mt(t) {
  if (!Number.isFinite(t) || t <= 0) return "0 B";
  const o = ["B", "KB", "MB", "GB"];
  let e = t, p = 0;
  for (; e >= 1024 && p < o.length - 1; )
    e /= 1024, p++;
  return `${e >= 100 ? e.toFixed(0) : e.toFixed(1)} ${o[p]}`;
}
function V(t) {
  return `${mt(t)}/s`;
}
function _t(t) {
  const o = new Date(t);
  if (!Number.isNaN(o.getTime()))
    return o.toLocaleTimeString([], { hour12: !1 });
  const e = t.match(/T(\d{2}:\d{2}:\d{2})/);
  return e ? e[1] : t.replace("T", " ").replace("Z", "");
}
async function L() {
  try {
    _ = await c("proxy_config_get"), a = await c("mihomo_status"), w = await c("mihomo_servers").catch(() => []);
  } catch (t) {
    x(String(t));
    return;
  }
  a != null && a.running ? (z(), yt()) : (K(), g = null, $ = null), ot();
}
async function z() {
  try {
    g = await c("mihomo_exit_info");
  } catch {
    g = null;
  }
  pt();
}
function yt() {
  N === void 0 && (N = window.setInterval(() => void vt(), 1e3), A = window.setInterval(() => void nt(), 2e3), D = window.setInterval(() => void z(), 6e4));
}
function K() {
  N !== void 0 && window.clearInterval(N), A !== void 0 && window.clearInterval(A), D !== void 0 && window.clearInterval(D), N = void 0, A = void 0, D = void 0;
}
async function vt() {
  try {
    a = await c("mihomo_status");
  } catch {
    return;
  }
  if (!a.running) {
    K(), g = null, $ = null, ot();
    return;
  }
  const t = performance.now();
  if ($) {
    const o = (t - $.t) / 1e3;
    if (o > 0.2) {
      const e = Math.max(0, a.bytes_up - $.up) / o, p = Math.max(0, a.bytes_down - $.down) / o;
      F("#px-up", V(e)), F("#px-down", V(p));
    }
  }
  $ = { t, up: a.bytes_up, down: a.bytes_down }, at();
}
async function nt() {
  try {
    R = await c("mihomo_requests", { limit: 200 });
  } catch {
    return;
  }
  rt();
}
function F(t, o) {
  const e = s(t);
  e && e.textContent !== o && (e.textContent = o);
}
function ot() {
  var d, y, f;
  at(), st(), ft(), it(), j(), rt(), pt();
  const t = s("#px-set-port");
  t && document.activeElement !== t && (t.value = String(((d = _ == null ? void 0 : _.mihomo) == null ? void 0 : d.mixed_port) ?? (a == null ? void 0 : a.mixed_port) ?? 0)), F("#px-set-engine", (a == null ? void 0 : a.engine) === "mihomo" ? "mihomo" : "native"), F("#px-set-log", (a == null ? void 0 : a.log_path) || "—");
  const o = (((y = _ == null ? void 0 : _.mihomo) == null ? void 0 : y.rule_mode) ?? "blacklist") === "whitelist", e = s("#px-rule-mode");
  e && (e.checked = o);
  const p = s("#px-rule-mode-label");
  p && (p.textContent = n(o ? "proxy.px_rule_whitelist" : "proxy.px_rule_blacklist"));
  const l = s("#px-rule-domains");
  l && document.activeElement !== l && (l.value = (((f = _ == null ? void 0 : _.mihomo) == null ? void 0 : f.rule_domains) ?? []).join(`
`));
}
function at() {
  const t = s("#px-state");
  if (!t) return;
  if (!a) {
    t.textContent = "";
    return;
  }
  const o = a.engine === "mihomo";
  if (t.classList.toggle("warn", o || !a.running), o) {
    t.textContent = n("proxy.m_legacy_engine");
    return;
  }
  t.textContent = a.running ? n("proxy.px_state_running", { port: String(a.mixed_port) }) : n("proxy.px_state_stopped");
}
function st() {
  const t = s("#px-orb");
  if (!t) return;
  const o = (a == null ? void 0 : a.engine) === "mihomo", e = !!(a != null && a.running);
  t.disabled = S || !a || o, t.textContent = n(S ? "proxy.m_working" : e ? "proxy.px_orb_stop" : "proxy.px_orb_start"), t.dataset.state = e ? "running" : "stopped", t.classList.toggle("legacy", o);
}
function ft() {
  var e;
  const t = s("#px-mode-label");
  if (!t) return;
  const o = (((e = _ == null ? void 0 : _.mihomo) == null ? void 0 : e.mode) ?? (a == null ? void 0 : a.mode) ?? "rule") === "global" ? "global" : "rule";
  t.textContent = n(o === "global" ? "proxy.px_mode_global" : "proxy.px_mode_rule"), document.querySelectorAll("#px-mode-menu [data-mode]").forEach((p) => {
    p.classList.toggle("on", p.dataset.mode === o);
  });
}
function it() {
  const t = s("#px-tun");
  t && (t.checked = !!(a != null && a.tun));
}
function pt() {
  var l;
  const t = s("#px-region");
  if (!t) return;
  const o = (a == null ? void 0 : a.selected) || "", e = ((l = w.find((d) => d.name === o)) == null ? void 0 : l.source) || "";
  if (!(a != null && a.running)) {
    t.textContent = n("proxy.px_region_idle");
    return;
  }
  const p = g != null && g.ok ? [g.country, g.region, g.city, g.ip].filter(Boolean).join(" · ") : n("proxy.px_region_unknown");
  t.textContent = [p, o ? `${e ? `${e} / ` : ""}${o}` : ""].filter(Boolean).join("　");
}
function j() {
  const t = s("#px-servers");
  if (!t) return;
  if (w.length === 0) {
    t.innerHTML = `<div class="px-empty">${i(n("proxy.px_server_empty"))}</div>`;
    return;
  }
  const o = !!(a != null && a.running);
  t.innerHTML = w.map((e) => {
    const p = P.get(e.name), l = p === void 0 ? "" : Number.isNaN(p) ? '<span class="px-delay pending">…</span>' : p < 0 ? `<span class="px-delay bad" title="${i(n("proxy.px_delay_failed"))}">×</span>` : `<span class="px-delay${p <= 150 ? " fast" : p >= 400 ? " slow" : ""}">${Math.round(p)} ms</span>`;
    return `<button type="button" class="px-server${e.selected ? " on" : ""}" data-server="${i(e.name)}"${o ? "" : " disabled"}>
        <span class="px-server-main">
          <span class="px-server-name">${i(e.name || n("proxy.m_unnamed"))}</span>
          <span class="px-server-sub">${i(e.server)}:${e.port}　${i(e.transport)}</span>
        </span>
        <span class="px-server-side">
          ${l}
          <span class="px-tag">${i(e.kind)}</span>
          <span class="px-server-src">${i(e.source || n("proxy.px_manual"))}</span>
        </span>
      </button>`;
  }).join("");
}
function rt() {
  const t = s("#px-log-list");
  if (!t) return;
  if (R.length === 0) {
    t.innerHTML = `<div class="px-empty">${i(n("proxy.px_log_empty"))}</div>`;
    return;
  }
  const o = new Map(w.map((e) => [e.name, e.source]));
  t.innerHTML = [...R].reverse().map((e) => {
    const p = e.node && o.get(e.node) || "", l = e.via === "proxy" ? [p, e.node].filter(Boolean).join(" / ") : e.via === "direct" ? n("proxy.px_via_direct") : n("proxy.px_via_reject");
    return `<div class="px-log-row" data-via="${i(e.via)}">
        <span class="px-log-ts">${i(_t(e.ts))}</span>
        <span class="px-log-host" title="${i(`${e.host}:${e.port}`)}">${i(e.host)}<span class="px-log-port">:${e.port}</span></span>
        <span class="px-log-via">${i(l)}</span>
      </div>`;
  }).join("");
}
function X(t) {
  var p;
  const o = s("#px-drawer");
  o == null || o.classList.toggle("open", t);
  const e = s("#px-rail");
  e == null || e.classList.toggle("hidden", t), (p = s("#px-drawer-close")) == null || p.classList.toggle("hidden", !t);
}
function bt(t) {
  const o = s("#px-layer");
  o == null || o.classList.remove("hidden"), document.querySelectorAll(".px-panel").forEach((e) => {
    e.classList.toggle("hidden", e.dataset.panel !== t);
  });
}
function Y() {
  var t;
  (t = s("#px-layer")) == null || t.classList.add("hidden");
}
function E() {
  document.querySelectorAll("#px-tools .px-tool").forEach((t) => t.classList.remove("open"));
}
async function ht(t) {
  if (!S) {
    S = !0, st();
    try {
      await t();
    } catch (o) {
      x(String(o));
    }
    S = !1, await L();
  }
}
async function gt() {
  a && await ht(async () => {
    a != null && a.running ? await c("mihomo_stop") : await c("mihomo_start");
  });
}
async function wt(t) {
  if (a != null && a.running) {
    x(n("proxy.px_mode_running"));
    return;
  }
  try {
    await c("mihomo_set_mode", { mode: t }), x(n("proxy.px_mode_saved"));
  } catch (o) {
    x(String(o));
  }
  await L();
}
async function tt(t) {
  try {
    a = await c("mihomo_set_tun", { enabled: t }), x(n(t ? "proxy.px_tun_on" : "proxy.px_tun_off"));
  } catch (e) {
    x(String(e));
  }
  const o = s("#px-tun");
  o && (o.checked = !!(a != null && a.tun)), it();
}
async function $t(t) {
  var v;
  const o = s("#px-tun");
  if (!t) {
    await tt(!1);
    return;
  }
  if (await c("mihomo_is_elevated").catch(() => !1)) {
    await tt(!0);
    return;
  }
  o && (o.checked = !1);
  const p = await c("mihomo_is_dev_build").catch(() => !1), l = s("#px-tun-title"), d = s("#px-tun-body"), y = s("#px-tun-ok"), f = s("#px-tun-cancel");
  l && (l.textContent = n(p ? "proxy.px_tun_dev_title" : "proxy.px_tun_warn_title")), d && (d.textContent = n(p ? "proxy.px_tun_dev_body" : "proxy.px_tun_warn_body")), y == null || y.classList.toggle("hidden", p), f && (f.textContent = n(p ? "proxy.px_tun_dev_ok" : "proxy.px_cancel")), (v = s("#px-tun-modal")) == null || v.classList.remove("hidden");
}
async function kt(t) {
  if (!(a != null && a.running)) {
    x(n("proxy.px_select_hint"));
    return;
  }
  try {
    await c("mihomo_select", { group: "", node: t }), x(n("proxy.px_selected", { name: t })), w = await c("mihomo_servers").catch(() => w), j(), z();
  } catch (o) {
    x(String(o));
  }
}
async function Lt() {
  try {
    const t = await c("mihomo_refresh_subs");
    x(n("proxy.px_subs_updated", { n: String(t) }));
  } catch (t) {
    x(String(t));
  }
  await L();
}
async function Et() {
  if (M) return;
  if (!(a != null && a.running)) {
    x(n("proxy.px_delay_need_running"));
    return;
  }
  const t = w.map((e) => e.name).filter(Boolean);
  if (t.length === 0) {
    x(n("proxy.px_delay_no_nodes"));
    return;
  }
  M = !0, P = new Map(t.map((e) => [e, Number.NaN])), et(), j();
  let o = 0;
  for (const e of t) {
    try {
      const p = await c("mihomo_delay", { name: e });
      P.set(e, p), o++;
    } catch {
      P.set(e, -1);
    }
    j();
  }
  M = !1, et(), x(n("proxy.px_delay_done", { ok: String(o), n: String(t.length) }));
}
function et() {
  const t = s("#px-delay-btn");
  t && (t.disabled = M, t.textContent = n(M ? "proxy.px_delay_testing" : "proxy.px_tool_delay"));
}
async function St() {
  try {
    await c("mihomo_refresh_subs"), w = await c("mihomo_servers").catch(() => w), j();
  } catch {
  }
}
async function Tt() {
  var e, p, l;
  if (!(_ != null && _.mihomo)) return;
  const t = (((e = s("#px-rule-domains")) == null ? void 0 : e.value) ?? "").split(/\r?\n/).map((d) => d.trim().toLowerCase()).filter((d) => d && !d.startsWith("#") && !d.startsWith("//")), o = {
    ..._.mihomo,
    // 0 = 由宿主在启动时挑一个空闲端口（原语义保留）。
    mixed_port: Math.max(0, Math.min(65535, Number(((p = s("#px-set-port")) == null ? void 0 : p.value) ?? "0") || 0)),
    rule_mode: (l = s("#px-rule-mode")) != null && l.checked ? "whitelist" : "blacklist",
    rule_domains: t
  };
  try {
    a = await c("mihomo_config_set", { cfg: o }), x(n("proxy.px_set_saved")), await L();
  } catch (d) {
    x(String(d));
  }
}
async function Mt() {
  var l, d, y, f;
  const t = (((l = s("#px-c-name")) == null ? void 0 : l.value) ?? "").trim(), o = (((d = s("#px-c-server")) == null ? void 0 : d.value) ?? "").trim(), e = Number(((y = s("#px-c-port")) == null ? void 0 : y.value) ?? "0"), p = (((f = s("#px-c-cred")) == null ? void 0 : f.value) ?? "").trim();
  if (!o || !e || !p) {
    x(n("proxy.px_custom_required"));
    return;
  }
  try {
    a = await c("mihomo_node_add_custom", {
      name: t,
      server: o,
      port: e,
      kind: T,
      credential: p,
      cipher: T === "ss" ? O : null
    }), x(n("proxy.m_node_added")), Y(), await c("mihomo_refresh_subs").catch(() => {
    }), await L();
  } catch (v) {
    x(String(v));
  }
}
async function Ct() {
  const { readText: t } = await Promise.resolve().then(() => Rt);
  return await t() ?? "";
}
async function Ht() {
  try {
    const t = await Ct(), o = s("#px-paste-text");
    o && (o.value = t), t.trim() || x(n("proxy.px_paste_empty"));
  } catch (t) {
    x(String(t));
  }
}
async function Nt() {
  var l;
  const o = (((l = s("#px-paste-text")) == null ? void 0 : l.value) ?? "").split(/\r?\n/).map((d) => d.trim()).filter((d) => d && !d.startsWith("#"));
  if (o.length === 0) {
    x(n("proxy.px_paste_empty"));
    return;
  }
  let e = 0, p = 0;
  for (const d of o)
    try {
      await c("mihomo_node_add", { link: d }), e++;
    } catch {
      p++;
    }
  x(n("proxy.px_paste_done", { ok: String(e), fail: String(p) })), e > 0 && Y(), e > 0 && await c("mihomo_refresh_subs").catch(() => {
  }), await L();
}
function lt() {
  const t = s(".proxy-panel");
  t && t.style.setProperty("--px-log-h", `${B}px`);
}
function Pt() {
  try {
    const t = Number(localStorage.getItem("lunac.proxy.logHeight"));
    Number.isFinite(t) && t >= 80 && t <= 480 && (B = t);
  } catch {
  }
}
function Bt() {
  try {
    localStorage.setItem("lunac.proxy.logHeight", String(Math.round(B)));
  } catch {
  }
}
function jt() {
  const t = s("#px-log-handle"), o = s(".proxy-panel");
  if (!t || !o) return;
  let e = 0, p = 0, l = !1;
  const d = () => {
    var C, H;
    const v = ((C = s(".px-top")) == null ? void 0 : C.offsetHeight) ?? 50, q = ((H = s("#px-msg")) == null ? void 0 : H.offsetHeight) ?? 0;
    return Math.max(96, o.clientHeight - v - q - 220 - 24);
  }, y = () => {
    l && (l = !1, window.removeEventListener("mousemove", f), window.removeEventListener("mouseup", y), window.removeEventListener("blur", y), Bt());
  }, f = (v) => {
    if (l) {
      if ((v.buttons & 1) === 0) {
        y();
        return;
      }
      B = Math.min(d(), Math.max(80, p + (e - v.clientY))), lt(), v.preventDefault();
    }
  };
  t.addEventListener("mousedown", (v) => {
    v.button === 0 && (v.preventDefault(), e = v.clientY, p = B, l = !0, window.removeEventListener("mousemove", f), window.removeEventListener("mouseup", y), window.removeEventListener("blur", y), window.addEventListener("mousemove", f), window.addEventListener("mouseup", y), window.addEventListener("blur", y));
  });
}
function qt() {
  return xt.map(
    (t) => `<button type="button" class="px-chip${t === T ? " on" : ""}" data-kind="${t}">${t}</button>`
  ).join("");
}
function It() {
  return ut.map(
    (t) => `<button type="button" class="px-chip${t === O ? " on" : ""}" data-cipher="${t}">${t}</button>`
  ).join("");
}
function At() {
  return `<div class="plugin-result proxy-panel">
  <header class="px-top">
    <div class="px-brand">${i(n("proxy.title"))}</div>
    <nav class="px-tools" id="px-tools">
      <div class="px-tool-group">
        <div class="px-tool">
          <button type="button" class="px-tool-btn" data-tool="import">${i(n("proxy.px_tool_import"))}<span class="px-caret">▾</span></button>
          <div class="px-menu">
            <button type="button" data-open="custom">${i(n("proxy.px_import_custom"))}</button>
            <button type="button" data-open="paste">${i(n("proxy.px_import_paste"))}</button>
          </div>
        </div>
        <div class="px-tool">
          <button type="button" class="px-tool-btn" data-action="refresh-subs">${i(n("proxy.px_tool_subs"))}</button>
        </div>
        <div class="px-tool">
          <button type="button" class="px-tool-btn" id="px-delay-btn" data-action="delay">${i(n("proxy.px_tool_delay"))}</button>
        </div>
        <div class="px-tool">
          <button type="button" class="px-tool-btn" data-open="settings">${i(n("proxy.px_tool_settings"))}</button>
        </div>
      </div>
    </nav>
    <div class="px-state" id="px-state"></div>
  </header>

  <section class="px-stage" id="px-stage">
    <div class="px-center">
      <button type="button" class="px-orb" id="px-orb" data-state="stopped">${i(n("proxy.px_orb_start"))}</button>
      <div class="px-speeds">
        <span class="px-speed"><span class="px-speed-label">↑</span><b id="px-up">0 B/s</b></span>
        <span class="px-speed"><span class="px-speed-label">↓</span><b id="px-down">0 B/s</b></span>
      </div>
      <div class="px-region" id="px-region"></div>
      <div class="px-controls">
        <div class="px-tool px-mode">
          <button type="button" class="px-tool-btn" id="px-mode-btn">
            <span id="px-mode-label">${i(n("proxy.px_mode_rule"))}</span><span class="px-caret">▾</span>
          </button>
          <div class="px-menu up" id="px-mode-menu">
            <button type="button" data-mode="rule">${i(n("proxy.px_mode_rule"))}</button>
            <button type="button" data-mode="global">${i(n("proxy.px_mode_global"))}</button>
          </div>
        </div>
        <label class="px-tun" title="${i(n("proxy.px_tun_hint"))}">
          <span>${i(n("proxy.px_tun"))}</span>
          <input type="checkbox" id="px-tun" />
          <i class="px-switch"></i>
        </label>
      </div>
    </div>

    <button type="button" class="px-rail" id="px-rail" title="${i(n("proxy.px_drawer_open"))}">${i(n("proxy.px_drawer_open"))}</button>
    <aside class="px-drawer" id="px-drawer">
      <div class="px-drawer-head">
        <b>${i(n("proxy.px_drawer_title"))}</b>
      </div>
      <div class="px-drawer-list" id="px-servers"></div>
    </aside>
    <!-- 拉回：与左侧「服务器」拉手同一形状（竖向贴在左缘），只是高度 60 且用 < 图标 -->
    <button type="button" class="px-rail px-rail-close hidden" id="px-drawer-close" title="${i(n("proxy.px_drawer_close"))}" aria-label="${i(n("proxy.px_drawer_close"))}">
      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/></svg>
    </button>
  </section>

  <section class="px-log" id="px-log">
    <div class="px-log-handle" id="px-log-handle" title="${i(n("proxy.px_log_resize"))}"></div>
    <div class="px-log-head">
      <b>${i(n("proxy.px_log_title"))}</b>
      <span class="px-log-hint">${i(n("proxy.px_log_hint"))}</span>
    </div>
    <div class="px-log-list" id="px-log-list"></div>
  </section>

  <div class="px-msg" id="px-msg"></div>

  <!-- TUN 的管理员闸门：独立警告框，同意后才请求提权重启。 -->
  <div class="px-modal hidden" id="px-tun-modal">
    <div class="px-modal-card">
      <b id="px-tun-title">${i(n("proxy.px_tun_warn_title"))}</b>
      <p id="px-tun-body">${i(n("proxy.px_tun_warn_body"))}</p>
      <div class="px-modal-btns">
        <button type="button" class="px-btn" id="px-tun-cancel">${i(n("proxy.px_cancel"))}</button>
        <button type="button" class="px-btn primary" id="px-tun-ok">${i(n("proxy.px_tun_elevate"))}</button>
      </div>
    </div>
  </div>

  <div class="px-layer hidden" id="px-layer">
    <section class="px-panel hidden" data-panel="custom">
      <div class="px-panel-head">
        <b>${i(n("proxy.px_import_custom"))}</b>
        <button type="button" class="px-btn" data-close>${i(n("proxy.px_close"))}</button>
      </div>
      <div class="px-form">
        <label class="px-field"><span>${i(n("proxy.px_field_name"))}</span>
          <input id="px-c-name" type="text" autocomplete="off" spellcheck="false" placeholder="${i(n("proxy.m_sub_name_ph"))}" /></label>
        <label class="px-field"><span>${i(n("proxy.px_field_server"))}</span>
          <input id="px-c-server" type="text" autocomplete="off" spellcheck="false" placeholder="example.com" /></label>
        <label class="px-field small"><span>${i(n("proxy.px_field_port"))}</span>
          <input id="px-c-port" type="number" min="1" max="65535" placeholder="443" /></label>
        <label class="px-field"><span>${i(n("proxy.px_field_cred"))}</span>
          <input id="px-c-cred" type="password" autocomplete="off" spellcheck="false" placeholder="${i(n("proxy.px_cred_ph"))}" /></label>
        <div class="px-field wide"><span>${i(n("proxy.px_field_kind"))}</span>
          <div class="px-chips" id="px-kind">${qt()}</div></div>
        <div class="px-field wide" id="px-cipher-wrap"><span>${i(n("proxy.px_field_cipher"))}</span>
          <div class="px-chips" id="px-cipher">${It()}</div></div>
      </div>
      <div class="px-panel-foot">
        <button type="button" class="px-btn primary" id="px-c-add">${i(n("proxy.px_add"))}</button>
      </div>
    </section>

    <section class="px-panel hidden" data-panel="paste">
      <div class="px-panel-head">
        <b>${i(n("proxy.px_import_paste"))}</b>
        <button type="button" class="px-btn" data-close>${i(n("proxy.px_close"))}</button>
      </div>
      <p class="px-note">${i(n("proxy.px_paste_hint"))}</p>
      <textarea id="px-paste-text" spellcheck="false" placeholder="${i(n("proxy.px_paste_ph"))}"></textarea>
      <div class="px-panel-foot">
        <button type="button" class="px-btn" id="px-paste-read">${i(n("proxy.px_paste_read"))}</button>
        <button type="button" class="px-btn primary" id="px-paste-import">${i(n("proxy.px_paste_import"))}</button>
      </div>
    </section>

    <section class="px-panel hidden" data-panel="settings">
      <div class="px-panel-head">
        <b>${i(n("proxy.px_tool_settings"))}</b>
        <button type="button" class="px-btn" data-close>${i(n("proxy.px_close"))}</button>
      </div>
      <div class="px-setrow plain"><span><b>${i(n("proxy.px_set_port"))}</b></span>
        <input id="px-set-port" class="px-num" type="number" min="0" max="65535" placeholder="0" /></div>
      <div class="px-setrow plain"><span><b>${i(n("proxy.px_set_engine"))}</b></span><span id="px-set-engine">native</span></div>
      <div class="px-setrow plain"><span><b>${i(n("proxy.px_set_log"))}</b></span><span id="px-set-log" class="px-wrap">—</span></div>
      <div class="px-setrow plain"><span><b>${i(n("proxy.px_set_rule_profile"))}</b></span>
        <span class="px-rule-mode">
          <em id="px-rule-mode-label">${i(n("proxy.px_rule_blacklist"))}</em>
          <label class="px-tun"><input type="checkbox" id="px-rule-mode" /><i class="px-switch"></i></label>
        </span>
      </div>
      <div class="px-field wide">
        <span>${i(n("proxy.px_rule_domains"))}</span>
        <textarea id="px-rule-domains" rows="6" spellcheck="false"></textarea>
      </div>
      <div class="px-panel-foot">
        <button type="button" class="px-btn primary" id="px-dom-save">${i(n("proxy.px_set_save"))}</button>
      </div>
    </section>
  </div>
</div>`;
}
const Ot = {
  id: "proxy",
  name: "Proxy",
  keywords: ["proxy", "代理", "系统代理", "梯子", "vpn", "socks5", "http proxy", "订阅", "节点"],
  description: "系统代理 + 自研代理内核（订阅 / 服务器 / 规则 / 请求日志）",
  icon: "🌐",
  badge: "Network",
  permissions: ["layout.takeover", "window.float"],
  execute: async () => ({ type: "html", content: At() })
};
async function Ft() {
  var o, e, p, l, d, y, f, v, q, C, H, W, U, G, Z, J, Q;
  const t = s(".proxy-panel");
  t && (Pt(), lt(), jt(), (o = s("#px-tools")) == null || o.addEventListener("click", (u) => {
    const r = u.target, m = r.closest("[data-open]");
    if (m != null && m.dataset.open) {
      E(), bt(m.dataset.open);
      return;
    }
    if (r.closest("[data-action='refresh-subs']")) {
      E(), Lt();
      return;
    }
    if (r.closest("[data-action='delay']")) {
      E(), Et();
      return;
    }
    const b = r.closest("[data-tool]");
    if (b) {
      const h = b.parentElement, I = h == null ? void 0 : h.classList.contains("open");
      E(), h && !I && h.classList.add("open");
    }
  }), (e = s("#px-mode-btn")) == null || e.addEventListener("click", (u) => {
    var r, m;
    u.stopPropagation(), (m = (r = s("#px-mode-btn")) == null ? void 0 : r.parentElement) == null || m.classList.toggle("open");
  }), (p = s("#px-mode-menu")) == null || p.addEventListener("click", (u) => {
    var m, b;
    const r = u.target.closest("[data-mode]");
    (b = (m = s("#px-mode-btn")) == null ? void 0 : m.parentElement) == null || b.classList.remove("open"), r != null && r.dataset.mode && wt(r.dataset.mode);
  }), (l = s("#px-rail")) == null || l.addEventListener("click", () => X(!0)), (d = s("#px-drawer-close")) == null || d.addEventListener("click", () => X(!1)), (y = s("#px-servers")) == null || y.addEventListener("click", (u) => {
    const r = u.target.closest("[data-server]");
    r != null && r.dataset.server && kt(r.dataset.server);
  }), (f = s("#px-orb")) == null || f.addEventListener("click", () => void gt()), (v = s("#px-tun")) == null || v.addEventListener("change", (u) => {
    $t(u.target.checked);
  }), (q = s("#px-tun-cancel")) == null || q.addEventListener("click", () => {
    var r;
    (r = s("#px-tun-modal")) == null || r.classList.add("hidden");
    const u = s("#px-tun");
    u && (u.checked = !!(a != null && a.tun));
  }), (C = s("#px-tun-ok")) == null || C.addEventListener("click", () => {
    var u;
    (u = s("#px-tun-modal")) == null || u.classList.add("hidden"), c("mihomo_relaunch_elevated").catch((r) => x(String(r)));
  }), (H = s("#px-layer")) == null || H.addEventListener("click", (u) => {
    const r = u.target;
    if (r.closest("[data-close]")) {
      Y();
      return;
    }
    const m = r.closest("[data-kind]");
    if (m != null && m.dataset.kind) {
      T = m.dataset.kind, t.querySelectorAll("#px-kind [data-kind]").forEach((I) => {
        I.classList.toggle("on", I.dataset.kind === T);
      });
      const h = s("#px-cipher-wrap");
      h == null || h.classList.toggle("hidden", T !== "ss");
    }
    const b = r.closest("[data-cipher]");
    b != null && b.dataset.cipher && (O = b.dataset.cipher, t.querySelectorAll("#px-cipher [data-cipher]").forEach((h) => {
      h.classList.toggle("on", h.dataset.cipher === O);
    }));
  }), (W = s("#px-c-add")) == null || W.addEventListener("click", () => void Mt()), (U = s("#px-paste-read")) == null || U.addEventListener("click", () => void Ht()), (G = s("#px-paste-import")) == null || G.addEventListener("click", () => void Nt()), (Z = s("#px-rule-mode")) == null || Z.addEventListener("change", (u) => {
    const r = u.target.checked, m = s("#px-rule-mode-label");
    m && (m.textContent = n(r ? "proxy.px_rule_whitelist" : "proxy.px_rule_blacklist"));
  }), (J = s("#px-dom-save")) == null || J.addEventListener("click", () => void Tt()), t.addEventListener("click", (u) => {
    var m, b;
    const r = u.target;
    r.closest(".px-tool") || E(), r.closest(".px-mode") || (b = (m = s("#px-mode-btn")) == null ? void 0 : m.parentElement) == null || b.classList.remove("open");
  }), await L(), a != null && a.running && nt(), w.length === 0 && (((Q = _ == null ? void 0 : _.mihomo) == null ? void 0 : Q.subscriptions.length) ?? 0) > 0 && St());
}
function Yt() {
  k !== void 0 && window.clearTimeout(k), k = void 0, K(), E(), Y(), _ = null, a = null, w = [], R = [], g = null, $ = null, S = !1, P = /* @__PURE__ */ new Map(), M = !1;
}
async function Dt() {
  return await c("plugin:clipboard-manager|read_text");
}
const Rt = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  readText: Dt
}, Symbol.toStringTag, { value: "Module" }));
export {
  Ft as attach,
  Ot as default,
  Yt as detach,
  Ot as proxyPlugin
};
