const Ae = "__lunac_host";
function Ne() {
  return globalThis[Ae] ?? null;
}
function n(e, i) {
  const s = Ne();
  return s && typeof s.t == "function" ? s.t(e, i) : e;
}
function Be(e, i = !1) {
  return window.__TAURI_INTERNALS__.transformCallback(e, i);
}
async function m(e, i = {}, s) {
  return window.__TAURI_INTERNALS__.invoke(e, i, s);
}
var pe;
(function(e) {
  e.WINDOW_RESIZED = "tauri://resize", e.WINDOW_MOVED = "tauri://move", e.WINDOW_CLOSE_REQUESTED = "tauri://close-requested", e.WINDOW_DESTROYED = "tauri://destroyed", e.WINDOW_FOCUS = "tauri://focus", e.WINDOW_BLUR = "tauri://blur", e.WINDOW_SCALE_FACTOR_CHANGED = "tauri://scale-change", e.WINDOW_THEME_CHANGED = "tauri://theme-changed", e.WINDOW_CREATED = "tauri://window-created", e.WINDOW_SUSPENDED = "tauri://suspended", e.WINDOW_RESUMED = "tauri://resumed", e.WEBVIEW_CREATED = "tauri://webview-created", e.DRAG_ENTER = "tauri://drag-enter", e.DRAG_OVER = "tauri://drag-over", e.DRAG_DROP = "tauri://drag-drop", e.DRAG_LEAVE = "tauri://drag-leave";
})(pe || (pe = {}));
async function Oe(e, i) {
  window.__TAURI_EVENT_PLUGIN_INTERNALS__.unregisterListener(e, i), await m("plugin:event|unlisten", {
    event: e,
    eventId: i
  });
}
async function We(e, i, s) {
  var t;
  const c = (t = void 0) !== null && t !== void 0 ? t : { kind: "Any" };
  return m("plugin:event|listen", {
    event: e,
    target: c,
    handler: Be(i)
  }).then((o) => async () => Oe(e, o));
}
async function Pe(e, i) {
  await m("plugin:shell|open", {
    path: e,
    with: i
  });
}
async function He(e, i) {
  await m("plugin:clipboard-manager|write_text", {
    label: i == null ? void 0 : i.label,
    text: e
  });
}
const Ue = 1280, je = 720, Fe = 550, ze = 300, we = 180, ke = 520, Ve = 4e3, Ge = 450, Ye = 800, Qe = 8e3, Xe = 200, y = {
  play: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polygon points="6 4 20 12 6 20 6 4"/></svg>',
  pause: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="9" y1="4" x2="9" y2="20"/><line x1="15" y1="4" x2="15" y2="20"/></svg>',
  prev: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polygon points="19 5 9 12 19 19 19 5"/><line x1="5" y1="5" x2="5" y2="19"/></svg>',
  next: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polygon points="5 5 15 12 5 19 5 5"/><line x1="19" y1="5" x2="19" y2="19"/></svg>',
  /** 随机（关 / 随机共用这一个；「关」靠 `data-mode` 变暗区分）。 */
  shuffle: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="16 3 21 3 21 8"/><line x1="4" y1="20" x2="21" y2="3"/><polyline points="21 16 21 21 16 21"/><line x1="15" y1="15" x2="21" y2="21"/><line x1="4" y1="4" x2="9" y2="9"/></svg>',
  /** 循环（单曲循环；那个「1」由 CSS `::after` 加，SVG 里不写字）。 */
  repeat: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="17 1 21 5 17 9"/><path d="M3 11V9a4 4 0 0 1 4-4h14"/><polyline points="7 23 3 19 7 15"/><path d="M21 13v2a4 4 0 0 1-4 4H3"/></svg>',
  list: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="9" y1="6" x2="21" y2="6"/><line x1="9" y1="12" x2="21" y2="12"/><line x1="9" y1="18" x2="21" y2="18"/><circle cx="4" cy="6" r="1" fill="currentColor" stroke="none"/><circle cx="4" cy="12" r="1" fill="currentColor" stroke="none"/><circle cx="4" cy="18" r="1" fill="currentColor" stroke="none"/></svg>',
  /** 进播放界面。 */
  expand: '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 3 21 3 21 9"/><polyline points="9 21 3 21 3 15"/><line x1="21" y1="3" x2="14" y2="10"/><line x1="3" y1="21" x2="10" y2="14"/></svg>',
  /** 回默认界面。**唯一**的退出播放界面的入口 —— 播放停止不会自动退出。 */
  back: '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/><line x1="3" y1="12" x2="9" y2="12"/></svg>',
  copy: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15V5a2 2 0 0 1 2-2h10"/></svg>',
  link: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.5 1.5"/><path d="M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7L12 19"/></svg>',
  power: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M18.4 6.6a9 9 0 1 1-12.8 0"/><line x1="12" y1="2" x2="12" y2="12"/></svg>',
  gear: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>',
  volume: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M15.5 8.5a5 5 0 0 1 0 7"/></svg>',
  /** 工具条上的「设备」按钮（2026-09-28）。画成一台小音箱，比「显示器」更贴
   *  Spotify 那种「可选的播放设备」语义。 */
  speaker: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="2" width="14" height="20" rx="2"/><circle cx="12" cy="14" r="3.2"/><circle cx="12" cy="6" r="1" fill="currentColor" stroke="none"/></svg>',
  /** 实心心形（「我喜欢的歌曲」那块封面上的图案）。**这个是 `fill`，不是描边** ——
   *  它是一块封面图（Spotify 的收藏夹封面就是实心心 + 渐变底），不是可点按钮。 */
  heart: '<svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" stroke="none"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>'
};
let a = null, l = null, C = null, Pi = "", Hi = !1, ai = [], Q = -1, wi = null, M = "default", Ui = null, X = null, I = !1, $e = "", E = null, Bi = !1, ii = "", B = "", k = null, ui = !1, mi, N = "playlist";
const oi = /* @__PURE__ */ new Map(), pi = /* @__PURE__ */ new Set(), _i = /* @__PURE__ */ new Map();
let p = null, O = null, li = !1, V = "", H = !1, J = !1, P = "tracks", si = null, z = !1, U = null, vi = ze, ji = null, fi = "", yi, ki = !1, $i, Se = 0, Ee = 0, K = null, xe = null, ci = 0, ri = !1, G = -1, Z = [], bi = 0, j, ei, Si = "", Ei = 0, Fi = "";
function r(e) {
  return e.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
function gi(e) {
  if (!isFinite(e) || e < 0) return "0:00";
  const i = Math.floor(e / 1e3), s = Math.floor(i / 60), t = i % 60;
  return `${s}:${String(t).padStart(2, "0")}`;
}
function g(e) {
  const i = e instanceof Error ? e.message : String(e);
  if (i.includes("ERR_NO_CLIENT_ID")) return n("music.err_no_client_id");
  if (i.includes("ERR_NOT_CONNECTED")) return n("music.err_not_connected");
  if (i.includes("ERR_NO_QUERY")) return n("music.err_no_query");
  if (i.includes("ERR_PORT_BUSY")) return n("music.err_port_busy", { port: String((a == null ? void 0 : a.port) ?? "") });
  if (i.includes("ERR_BAD_URI") || i.includes("ERR_BAD_ID")) return n("music.err_bad_uri");
  const s = i.match(/ERR_RATE_LIMITED:(\S*)/);
  return s ? n("music.err_rate_limited", { s: s[1] || "?" }) : i.includes("Insufficient client scope") ? n("music.err_scope") : i.includes("No active device") || i.includes("NO_ACTIVE_DEVICE") ? n("music.err_no_device") : i.includes("Premium required") || i.includes("PREMIUM_REQUIRED") ? n("music.err_premium") : i.includes("Restriction violated") ? n("music.err_restricted") : i;
}
function Je(e) {
  const i = [];
  for (const s of e.split(/\r?\n/)) {
    const t = [...s.matchAll(/\[(\d{1,3}):(\d{1,2})(?:[.:](\d{1,3}))?\]/g)];
    if (t.length === 0) continue;
    const c = s.replace(/\[[^\]]*\]/g, "").trim();
    if (c)
      for (const o of t) {
        const v = o[3] ? Number(o[3].padEnd(3, "0")) / 1e3 : 0;
        i.push({ at: Number(o[1]) * 60 + Number(o[2]) + v, text: c });
      }
  }
  return i.sort((s, t) => s.at - t.at), i;
}
function Ke() {
  return `
  <div class="music-root">
    <!-- ── 默认界面：顶部工具条 + 状态行 + 连接设置 + 歌单列 / 搜索结果 ──
         工具条与「返回」按钮**分属两态**：默认态用工具条上的「进播放界面」，
         播放态用歌名模块右端那个「返回」（music-back 这个 id 全文档只有一个）。 -->
    <div class="music-view" id="music-v-default">
      <!-- 顶部工具条：头像 / 账号 / 搜索（**带下拉预览**）/ 状态 / 设置。
           2026-09-28 第二次改：设备按钮与「展开播放面板」都**下移到最底下那条控制栏**
           （用户要求「严格对齐 Spotify」，Spotify 的工具条上本来就没有这两样）。 -->
      <div class="music-toolbar">
        <span class="music-avatar" id="music-avatar"></span>
        <span class="music-acc" id="music-acc"></span>
        <div class="music-search-wrap">
          <input class="music-search" id="music-search" type="search" autocomplete="off" spellcheck="false" placeholder="${r(n("music.search_ph"))}">
          <!-- 下拉预览：绝对定位挂在工具条下方（**不占布局**，否则窗口高会跟着抖） -->
          <div class="music-dd hidden" id="music-search-dd"></div>
        </div>
        <span class="music-status" id="music-status">${n("music.loading")}</span>
        <button class="music-ghost-btn music-icon-btn" id="music-setup-toggle" title="${r(n("music.settings"))}">${y.gear}</button>
      </div>

      <div class="music-setup hidden" id="music-setup">
        <div class="music-hint" id="music-setup-hint">${n("music.setup_hint")}</div>
        <!-- 凭据字段默认只在「没有内置 Client ID」或用户主动展开时显示：
             内置值让「登录」变成一步操作，Redirect URI 那一串对普通用户是噪音。 -->
        <button class="music-ghost-btn music-fields-toggle hidden" id="music-fields-toggle"></button>
        <div id="music-setup-fields">
          <div class="music-field">
            <label for="music-client-id">${n("music.client_id")}</label>
            <input id="music-client-id" type="text" spellcheck="false" autocomplete="off" placeholder="${r(n("music.client_id_ph"))}">
          </div>
          <div class="music-field music-field-port">
            <label for="music-port">${n("music.port")}</label>
            <input id="music-port" type="text" inputmode="numeric" autocomplete="off">
          </div>
          <div class="music-field">
            <label>${n("music.redirect")}</label>
            <div class="music-redirect-row">
              <code id="music-redirect"></code>
              <button class="music-ghost-btn music-icon-btn" id="music-copy-redirect" title="${r(n("music.copy"))}">${y.copy}</button>
            </div>
          </div>
          <!-- 本机播放（librespot）的两项设置：路径留空 = 自动探测；代理留空 = 直连。
               两者都不是「必填」，所以各带一行小字说明（见 renderSetup）。 -->
          <div class="music-field">
            <label for="music-librespot">${n("music.local_play")}</label>
            <input id="music-librespot" type="text" spellcheck="false" autocomplete="off" placeholder="librespot.exe">
          </div>
          <div class="music-field">
            <label for="music-librespot-proxy">proxy</label>
            <input id="music-librespot-proxy" type="text" spellcheck="false" autocomplete="off" placeholder="http://127.0.0.1:7890">
          </div>
        </div>
        <div class="music-actions">
          <button class="music-btn" id="music-save">${n("music.save")}</button>
          <button class="music-btn music-primary" id="music-connect">${y.link} ${n("music.connect")}</button>
          <button class="music-btn" id="music-disconnect">${y.power} ${n("music.disconnect")}</button>
        </div>
      </div>

      <!-- 主体：**左栏（宽度可拖）+ 分隔条 + 主区**（用户 2026-09-28 的
           「歌单列作为单独的一列可拉动」「中间大的大部分区域作为歌曲列表」）。
           两栏各自内部滚动 —— 窗口是定尺 1280×720，不是靠内容撑出来的。 -->
      <div class="music-body hidden" id="music-body">
        <aside class="music-side" id="music-side">
          <div class="music-side-tabs" id="music-side-tabs">
            <button class="music-tab on" data-act="side-tab" data-tab="playlist">${n("music.playlists")}</button>
            <button class="music-tab" data-act="side-tab" data-tab="album">${n("music.tab_albums")}</button>
            <button class="music-tab" data-act="side-tab" data-tab="artist">${n("music.tab_artists")}</button>
            <button class="music-tab" data-act="side-tab" data-tab="show">${n("music.tab_shows")}</button>
          </div>
          <div class="music-side-list" id="music-side-list"></div>
        </aside>
        <div class="music-split" id="music-split" role="separator" aria-orientation="vertical"></div>
        <main class="music-main" id="music-main"></main>
      </div>

      <!-- ── 底部控制栏（2026-09-28，Spotify 复刻）─────────────────────────
           用户要求「在默认面板下方添加 Spotify 那样的播放控制，并把一些按钮也
           移动到下方控制」。三列 grid：左 = 正在播放（点它 = 打开播放面板）、
           中 = 播放键组、右 = 设备 / 音量 / 队列 / 展开。
           栏顶那条 2px 细进度线**绝对定位**（不占高），拖动即可跳转。
           **两个弹层都挂在右端那一簇里、向上弹**：这条栏贴着窗口下沿，
           向下弹会跑到窗口外面（见 styles.css 里那两条覆盖 top 的规则）。
           注意本段是 JS 模板字符串 —— 注释里不能出现反引号（会把字符串截断）。 -->
      <div class="music-nowbar hidden" id="music-nowbar">
        <div class="music-bp" id="music-bp" title="${r(n("music.seek"))}">
          <div class="music-bp-fill" id="music-bp-fill"></div>
          <div class="music-progress-tip" id="music-bp-tip">0:00</div>
        </div>
        <button class="music-bnow" id="music-bnow" title="${r(n("music.open_player"))}">
          <span class="music-bnow-cover" id="music-bnow-cover"></span>
          <span class="music-bnow-main">
            <span class="music-bnow-n" id="music-bnow-n"></span>
            <span class="music-bnow-a" id="music-bnow-a"></span>
          </span>
        </button>
        <div class="music-bctl">
          <button class="music-round-btn music-mode-btn" id="music-b-mode" data-mode="off"></button>
          <button class="music-round-btn" id="music-b-prev" title="${r(n("music.prev"))}">${y.prev}</button>
          <button class="music-round-btn music-play-btn" id="music-b-play" title="${r(n("music.play_pause"))}">${y.play}</button>
          <button class="music-round-btn" id="music-b-next" title="${r(n("music.next"))}">${y.next}</button>
        </div>
        <div class="music-bend">
          <button class="music-ghost-btn music-icon-btn" id="music-devices-btn" title="${r(n("music.devices"))}">${y.speaker}</button>
          <span class="music-vol-ico">${y.volume}</span>
          <input class="music-vol" id="music-b-vol" type="range" min="0" max="100" step="1" value="50" title="${r(n("music.volume"))}">
          <button class="music-round-btn" id="music-b-queue" title="${r(n("music.queue"))}">${y.list}</button>
          <button class="music-ghost-btn music-icon-btn hidden" id="music-open-player" title="${r(n("music.open_player"))}">${y.expand}</button>
          <div class="music-dd music-dev-dd hidden" id="music-dev-dd"></div>
          <div class="music-dd hidden" id="music-q-dd"></div>
        </div>
      </div>
    </div>

    <!-- ── 播放界面：**550×130 的长条**（封面 100 + 右侧列 450）──────────
         右侧列三块的高度加起来正好是长条高：歌名 30 + 歌词 65 + 控制 35 = 130。
         **这几个数都是用户 2026-09-27 给的定尺**：改任何一个都要同步
         styles.css 的 .music-name / .music-lyr / .music-bar，以及宿主
         plugin_window.rs 的 MUSIC_W（见 ai-spec §4.6 与预检 #39 ④）。 -->
    <!-- 注意：本段是 JS 模板字符串，**注释里不能出现反引号**（会把字符串截断）。 -->
    <div class="music-view music-player hidden" id="music-v-player">
      <div class="music-pv-card">
        <div class="music-pv-cover" id="music-pv-cover"></div>
        <div class="music-pv-col">
          <!-- 歌名模块 H30：歌名（亮）+ 歌手·专辑（暗）+ 返回入口。
               「返回」放在这里而不是标题行 —— 播放态整条只有 130 高，
               标题行（状态 / 账号 / 齿轮）在默认态里，这一态不显示。
               时间不在这里（用户 2026-09-27 要求挪到控制块最左端、进度条下方）。 -->
          <div class="music-name">
            <div class="music-name-text">
              <span class="music-title" id="music-pv-title"></span>
              <span class="music-sub" id="music-pv-sub"></span>
            </div>
            <button class="music-ghost-btn music-icon-btn hidden" id="music-back" title="${r(n("music.back"))}">${y.back}</button>
          </div>

          <!-- 歌词模块 H65：正好两行可见（行高 32）。已过 + 正在 = 亮，未到 = 暗；
               点某一行 = 跳到那一句的进度。 -->
          <div class="music-lyr" id="music-lyr"></div>

          <!-- 控制面板 H35：进度条**叠在本块顶部**（绝对定位 ⇒ 不占高度，总高仍是 130），
               四个播放键在块内居中，右端音量条 80px + 播放列表按钮。 -->
          <div class="music-bar">
            <!-- 时间在控制块**最左端、进度条下方**（用户 2026-09-27 定）。
                 绝对定位 ⇒ 不参与四钮的居中计算。 -->
            <div class="music-time">
              <span id="music-pv-pos">0:00</span><span class="music-time-sep">/</span><span id="music-pv-dur">0:00</span>
            </div>
            <div class="music-progress" id="music-pv-progress" title="${r(n("music.seek"))}">
              <div class="music-progress-fill" id="music-pv-fill"></div>
              <div class="music-progress-dot" id="music-pv-dot"></div>
              <div class="music-progress-tip" id="music-pv-tip">0:00</div>
            </div>
            <div class="music-bar-main">
              <button class="music-round-btn music-mode-btn" id="music-mode" data-mode="off"></button>
              <button class="music-round-btn" id="music-prev" title="${r(n("music.prev"))}">${y.prev}</button>
              <button class="music-round-btn music-play-btn" id="music-play" title="${r(n("music.play_pause"))}">${y.play}</button>
              <button class="music-round-btn" id="music-next" title="${r(n("music.next"))}">${y.next}</button>
            </div>
            <div class="music-bar-end">
              <span class="music-vol-ico">${y.volume}</span>
              <input class="music-vol" id="music-vol" type="range" min="0" max="100" step="1" value="50" title="${r(n("music.volume"))}">
              <button class="music-round-btn" id="music-queue-btn" title="${r(n("music.queue"))}">${y.list}</button>
            </div>
          </div>
        </div>
      </div>

      <!-- 播放列表（队列）挂在长条**下方**、不再与歌词互斥：长条是定尺 130，
           塞不进队列。开着时窗口按内容长高（applyResize 实测贴合）。 -->
      <div class="music-q-wrap hidden" id="music-q-wrap">
        <div class="music-sec-head">
          <span class="music-sec-title">${n("music.queue")}</span>
          <span class="music-sec-note">${n("music.queue_hint")}</span>
        </div>
        <div class="music-q" id="music-q"></div>
      </div>
    </div>

    <div class="music-msg" id="music-msg"></div>
  </div>`;
}
function h(e, i) {
  e && e.textContent !== i && (e.textContent = i);
}
function $(e, i) {
  e && e.innerHTML !== i && (e.innerHTML = i);
}
function L(e, i) {
  e == null || e.classList.toggle("hidden", !i);
}
function zi(e, i, s) {
  e && e.getAttribute(i) !== s && e.setAttribute(i, s);
}
function Ze(e) {
  const i = e.querySelector("#music-msg");
  if (!i) return;
  const s = i.textContent ?? "";
  if (s !== Si) {
    Si = s, Ei = Date.now();
    return;
  }
  s && Date.now() - Ei >= Qe && (i.textContent = "", Si = "", Ei = 0);
}
function Y(e) {
  const i = M === "player";
  L(e.querySelector("#music-v-default"), !i), L(e.querySelector("#music-v-player"), i), e.classList.toggle("music-player-on", i), is(i), es(), qe(e), i ? (Q = -1, Mi(e), Ti(e)) : (L(e.querySelector("#music-body"), !!(a != null && a.connected)), ti(e), T(e), F(e), di(e)), hi(e);
}
function is(e) {
  const i = !e;
  document.getElementById("plugin-titlebar") && ji !== i && (ji = i, m("plugin_window_set_resizable", { resizable: i }).catch(() => {
  }));
}
function es() {
  const e = document.getElementById("plugin-close");
  if (!e) return;
  fi || (fi = e.innerHTML);
  const i = M === "player" ? "back" : "close";
  if (e.dataset.mode === i) return;
  e.dataset.mode = i, e.innerHTML = i === "back" ? y.back : fi;
  const s = i === "back" ? n("music.back") : "Close";
  e.title = s, e.setAttribute("aria-label", s);
}
function ss() {
  const e = document.getElementById("plugin-close");
  !e || !fi || e.dataset.mode !== "back" || (e.innerHTML = fi, e.title = "Close", e.setAttribute("aria-label", "Close"), e.dataset.mode = "close");
}
async function ts(e) {
  try {
    await m("spotify_control", { action: "pause" });
  } catch (i) {
    ni(e, g(i));
  }
  M = "default", Y(e);
}
function qe(e) {
  const i = M === "player";
  L(e.querySelector("#music-open-player"), !i && !!(l != null && l.track)), L(e.querySelector("#music-back"), i), L(e.querySelector("#music-nowbar"), !i && !!(a != null && a.connected));
}
function Ci(e, i) {
  const s = e.querySelector("#music-status");
  a != null && a.client_id ? a.connected ? l ? l.active ? l.playing ? h(s, n("music.status_playing")) : h(s, n("music.status_paused")) : h(s, n("music.status_no_device")) : h(s, n("music.status_connecting")) : h(s, n("music.status_disconnected")) : h(s, n("music.status_unconfigured"));
  const t = e.querySelector("#music-avatar");
  if (t) {
    const o = a != null && a.connected && a.avatar || "";
    $(t, o ? `<img src="${r(o)}" alt="">` : "");
  }
  h(e.querySelector("#music-acc"), a != null && a.connected && a.display_name || "");
  const c = e.querySelector("#music-devices-btn");
  c && (zi(c, "title", `${n("music.devices")}：${(l == null ? void 0 : l.device) || n("music.device_none")}`), c.classList.toggle("warn", !!(a != null && a.connected) && !(l != null && l.active)));
}
function Vi(e) {
  L(e.querySelector("#music-setup"), !(a != null && a.connected)), L(e.querySelector("#music-body"), !!(a != null && a.connected)), ti(e), T(e), a != null && a.connected && (Ce(e, N), Me(e));
  const i = wi ?? !(a != null && a.builtin);
  L(e.querySelector("#music-setup-fields"), i), L(e.querySelector("#music-save"), i);
  const s = e.querySelector("#music-fields-toggle");
  L(s, !!(a != null && a.builtin)), h(s, n(i ? "music.hide_fields" : "music.use_own_client_id")), h(
    e.querySelector("#music-setup-hint"),
    a != null && a.builtin ? n("music.setup_builtin") : n("music.setup_hint")
  );
  const t = e.querySelector("#music-client-id"), c = e.querySelector("#music-port"), o = e.querySelector("#music-librespot"), v = e.querySelector("#music-librespot-proxy");
  t && document.activeElement !== t && (t.value = (a == null ? void 0 : a.client_id) ?? ""), c && document.activeElement !== c && (c.value = String((a == null ? void 0 : a.port) ?? 8899)), o && document.activeElement !== o && (o.value = (a == null ? void 0 : a.librespot_path) ?? ""), v && document.activeElement !== v && (v.value = (a == null ? void 0 : a.librespot_proxy) ?? ""), h(e.querySelector("#music-redirect"), (a == null ? void 0 : a.redirect_uri) ?? "");
}
function ns(e) {
  var i;
  return !!e.uri && ((i = l == null ? void 0 : l.track) == null ? void 0 : i.uri) === e.uri;
}
function ni(e, i) {
  h(e.querySelector("#music-msg"), i);
}
function Ri(e, i, s, t = "", c = "") {
  return `<button class="music-tr${ns(e) ? " playing" : ""}" data-act="${s}" data-uri="${r(e.uri)}"${t ? ` data-i="${r(t)}"` : ""}${c ? ` title="${r(c)}"` : ""}>
    <span class="music-tr-i">${i + 1}</span>
    <span class="music-tr-main">
      <span class="music-tr-n">${r(e.name || "?")}</span>
      <span class="music-tr-a">${r(e.artists || e.album)}</span>
    </span>
    <span class="music-tr-d">${gi(e.duration_ms)}</span>
  </button>`;
}
function Ii(e) {
  return { id: e.id, uri: e.uri, name: e.name, cover: e.cover, subtitle: e.owner, total: e.total };
}
function xi(e, i) {
  const s = !!i.uri && (l == null ? void 0 : l.context_uri) === i.uri, t = (p == null ? void 0 : p.kind) === e && p.id === i.id, c = i.cover ? `<img src="${r(i.cover)}" alt="">` : "";
  return `<div class="music-pl${s ? " playing" : ""}${t ? " on" : ""}" data-uri="${r(i.uri)}">
    <button class="music-pl-btn" data-act="open" data-kind="${e}" data-id="${r(i.id)}" title="${r(i.name || "?")}">
      <span class="music-pl-cover">${c}</span>
      <span class="music-pl-main">
        <span class="music-pl-name">${r(i.name || "?")}</span>
        <span class="music-pl-sub">${r(i.subtitle)}</span>
      </span>
    </button>
  </div>`;
}
function cs(e, i) {
  const s = i.cover ? `<img src="${r(i.cover)}" alt="">` : "";
  return `<button class="music-card" data-act="open" data-kind="${e}" data-id="${r(i.id)}" title="${r(i.name)}">
    <span class="music-card-cover${e === "artist" ? " round" : ""}">${s}</span>
    <span class="music-card-n">${r(i.name)}</span>
    <span class="music-card-s">${r(i.subtitle)}</span>
  </button>`;
}
function as() {
  const e = (p == null ? void 0 : p.kind) === "liked", i = E ? String(E.total) : "", s = ii || [(a == null ? void 0 : a.display_name) || "", i].filter(Boolean).join(" · ");
  return `<div class="music-pl music-pl-liked${e ? " on" : ""}${ii ? " err" : ""}">
    <button class="music-pl-btn" data-act="open" data-kind="liked" data-id="liked" title="${r(n("music.liked_songs"))}">
      <span class="music-pl-cover music-pl-liked-cover">${y.heart}</span>
      <span class="music-pl-main">
        <span class="music-pl-name">${r(n("music.liked_songs"))}</span>
        <span class="music-pl-sub">${r(s)}</span>
      </span>
    </button>
  </div>`;
}
function ti(e) {
  e.querySelectorAll("#music-side-tabs .music-tab").forEach((o) => {
    o.classList.toggle("on", o.dataset.tab === N);
  });
  const i = e.querySelector("#music-side-list");
  if (!i) return;
  if (!(a != null && a.connected)) {
    $(i, `<div class="music-empty">${n("music.playlists_login")}</div>`);
    return;
  }
  const s = oi.get(N), t = _i.get(N);
  let c = N === "playlist" ? as() : "";
  pi.has(N) ? c += `<div class="music-empty">${n("music.loading")}</div>` : t ? c += `<div class="music-empty music-empty-err">${r(t)}</div>` : s && (c += s.length === 0 ? `<div class="music-empty">${n(N === "playlist" ? "music.playlists_empty" : "music.lib_empty")}</div>` : s.map((o) => xi(N, o)).join("")), $(i, c);
}
function Oi(e) {
  e.querySelectorAll("#music-side-list .music-pl").forEach((i) => {
    const s = i.querySelector(".music-pl-btn"), t = !!p && (s == null ? void 0 : s.dataset.kind) === p.kind && (s == null ? void 0 : s.dataset.id) === p.id;
    i.classList.toggle("on", t);
  });
}
function T(e) {
  const i = e.querySelector("#music-main");
  if (!i) return;
  if (J && B) {
    $(i, ls());
    return;
  }
  if (!p) {
    $(i, `<div class="music-empty">${a != null && a.connected ? n("music.pick_hint") : n("music.playlists_login")}</div>`);
    return;
  }
  const s = p.cover ? `<img src="${r(p.cover)}" alt="">` : "", t = p.kind === "liked" ? n("music.liked_songs") : p.kind === "playlist" ? n("music.playlists") : p.kind === "album" ? n("music.tab_albums") : p.kind === "artist" ? n("music.tab_artists") : n("music.tab_shows");
  let c;
  li ? c = `<div class="music-empty">${n("music.loading")}</div>` : V ? c = `<div class="music-empty music-empty-err">${r(V)}</div>` : !O || O.length === 0 ? c = `<div class="music-empty">${n("music.playlist_empty")}</div>` : c = O.map((o, v) => Ri(o, v, "main-track", String(v))).join(""), $(i, `<div class="music-page">
    <div class="music-page-head">
      <span class="music-page-cover${p.kind === "artist" ? " round" : ""}">${s}</span>
      <div class="music-page-info">
        <span class="music-page-kind">${r(t)}</span>
        <span class="music-page-name">${r(p.name || "?")}</span>
        <span class="music-page-sub">${r(p.subtitle)}</span>
        <div class="music-page-actions">
          <button class="music-btn music-primary" data-act="main-play-all">${y.play} ${n("music.play_all")}</button>
        </div>
      </div>
    </div>
    <div class="music-list">${c}</div>
  </div>`);
}
function ls() {
  const e = k, s = [
    ["tracks", n("music.tracks")],
    ["artists", n("music.tab_artists")],
    ["albums", n("music.tab_albums")],
    ["playlists", n("music.playlists")],
    ["shows", n("music.tab_shows")]
  ].map(([c, o]) => `<button class="music-tab${P === c ? " on" : ""}" data-act="search-tab" data-tab="${c}">${r(o)}</button>`).join("");
  let t;
  if (ui || !e)
    t = `<div class="music-empty">${n("music.loading")}</div>`;
  else if (P === "tracks")
    t = e.tracks.length ? e.tracks.map((c, o) => Ri(c, o, "main-track", String(o))).join("") : `<div class="music-empty">${n("music.search_empty")}</div>`;
  else {
    const o = (P === "artists" ? e.artists : P === "albums" ? e.albums : P === "shows" ? e.shows : e.playlists.map(Ii)).map((v) => cs(P === "playlists" ? "playlist" : P === "artists" ? "artist" : P === "albums" ? "album" : "show", v));
    t = o.length ? `<div class="music-grid">${o.join("")}</div>` : `<div class="music-empty">${n("music.search_empty")}</div>`;
  }
  return `<div class="music-page">
    <div class="music-page-info music-page-info-flat">
      <span class="music-page-kind">${n("music.search_result")}</span>
      <span class="music-page-name">${r(B)}</span>
    </div>
    <div class="music-tabs">${s}</div>
    <div class="music-list">${t}</div>
  </div>`;
}
function F(e) {
  const i = e.querySelector("#music-search-dd");
  if (!i) return;
  const s = !!(a != null && a.connected) && H && !!B;
  if (L(i, s), !s) return;
  if (!k) {
    $(i, ui ? `<div class="music-empty">${n("music.loading")}</div>` : "");
    return;
  }
  const t = k, c = [];
  t.tracks.slice(0, 3).forEach((o, v) => c.push(Ri(o, v, "dd-track"))), t.artists.slice(0, 2).forEach((o) => c.push(xi("artist", o))), t.albums.slice(0, 2).forEach((o) => c.push(xi("album", o))), t.playlists.slice(0, 2).forEach((o) => c.push(xi("playlist", Ii(o)))), c.length || c.push(`<div class="music-empty">${n("music.search_empty")}</div>`), c.push(`<button class="music-dd-all" data-act="search-all">${n("music.search_all")}</button>`), $(i, c.join(""));
}
function di(e) {
  const i = e.querySelector("#music-dev-dd");
  if (!i || (L(i, z), !z)) return;
  const s = U;
  let t = `<div class="music-dd-head">${n("music.devices")}</div>`;
  s != null && s.available ? t += `<button class="music-dev-row${s.running ? " on" : ""}" data-act="local-toggle">
      <span class="music-dev-ico">${y.power}</span>
      <span class="music-dev-main">
        <span class="music-dev-n">${n("music.local_play")}</span>
        <span class="music-dev-s">${r(s.path || "")}</span>
      </span>
    </button>` : t += `<div class="music-dev-row disabled">
      <span class="music-dev-ico">${y.power}</span>
      <span class="music-dev-main">
        <span class="music-dev-n">${n("music.local_play")}</span>
        <span class="music-dev-s">${n("music.local_no_exe")}</span>
      </span>
    </div>`;
  const c = si ?? [];
  t += c.length ? c.map((o) => `<button class="music-dev-row${o.active ? " on" : ""}" data-act="dev-pick" data-id="${r(o.id)}">
        <span class="music-dev-ico">${y.speaker}</span>
        <span class="music-dev-main">
          <span class="music-dev-n">${r(o.name || "?")}</span>
          <span class="music-dev-s">${r(o.kind)}</span>
        </span>
      </button>`).join("") : `<div class="music-empty">${n("music.device_none")}</div>`, $(i, t);
}
function us(e) {
  var t;
  const i = (l == null ? void 0 : l.context_uri) ?? "", s = ((t = l == null ? void 0 : l.track) == null ? void 0 : t.uri) ?? "";
  e.querySelectorAll(".music-pl").forEach((c) => {
    c.classList.toggle("playing", !!i && c.dataset.uri === i);
  }), e.querySelectorAll(".music-tr").forEach((c) => {
    c.classList.toggle("playing", !!s && c.dataset.uri === s);
  });
}
function ve(e) {
  vi = Math.min(ke, Math.max(we, Math.round(vi))), e.style.setProperty("--music-side-w", `${vi}px`);
}
function Le(e, i) {
  var t;
  if (e === "liked")
    return { id: "liked", uri: "", name: n("music.liked_songs"), cover: "", subtitle: "", total: (E == null ? void 0 : E.total) ?? 0 };
  const s = e === "artist" ? k == null ? void 0 : k.artists : e === "album" ? k == null ? void 0 : k.albums : e === "show" ? k == null ? void 0 : k.shows : k == null ? void 0 : k.playlists.map(Ii);
  return ((t = oi.get(e)) == null ? void 0 : t.find((c) => c.id === i)) ?? (s == null ? void 0 : s.find((c) => c.id === i)) ?? null;
}
async function Ce(e, i) {
  if (!(!(a != null && a.connected) || pi.has(i) || oi.has(i))) {
    pi.add(i), _i.delete(i), ti(e);
    try {
      const s = i === "playlist" ? (Ui = await m("spotify_playlists")).map(Ii) : await m(
        i === "album" ? "spotify_albums" : i === "artist" ? "spotify_artists" : "spotify_shows"
      );
      oi.set(i, s);
    } catch (s) {
      _i.set(i, g(s));
    } finally {
      pi.delete(i), ti(e);
    }
  }
}
async function os(e, i, s) {
  const t = Le(i, s);
  if (t) {
    if (J = !1, H = !1, p = { kind: i, id: t.id, uri: t.uri, name: t.name, cover: t.cover, subtitle: t.subtitle }, O = null, V = "", i === "liked") {
      O = (E == null ? void 0 : E.items) ?? null, V = ii, li = !E, F(e), Oi(e), T(e), E || await Me(e);
      return;
    }
    li = !0, F(e), Oi(e), T(e);
    try {
      O = await m("spotify_item_tracks", { kind: i, id: t.id });
    } catch (c) {
      V = g(c);
    } finally {
      li = !1, Oi(e), T(e);
    }
  }
}
async function fe(e, i, s, t = 0) {
  const c = Le(i, s);
  if (c)
    try {
      if (i === "liked" || i === "show") {
        const o = (i === "liked" ? E == null ? void 0 : E.items : O) ?? [];
        if (!o.length) return;
        await m("spotify_play_uris", { uris: o.slice(Math.max(0, t)).map((v) => v.uri) });
      } else if (c.uri)
        await m("spotify_play_context", { contextUri: c.uri, offsetUri: "" });
      else
        return;
    } catch (o) {
      ni(e, g(o));
    }
}
async function rs(e, i) {
  if (!p) return;
  const s = O ?? [], t = s[i];
  if (t)
    try {
      p.kind === "liked" || p.kind === "show" ? await m("spotify_play_uris", { uris: s.slice(i).map((c) => c.uri) }) : await m("spotify_play_context", { contextUri: p.uri, offsetUri: t.uri });
    } catch (c) {
      ni(e, g(c));
    }
}
async function Yi(e) {
  try {
    si = await m("spotify_devices");
  } catch (i) {
    si = [], ni(e, g(i));
  }
  try {
    U = await m("librespot_status");
  } catch {
    U = null;
  }
  di(e);
}
async function ds(e) {
  if (!(U != null && U.available)) return;
  const i = U.running;
  try {
    U = await m(i ? "librespot_stop" : "librespot_start");
  } catch (s) {
    ni(e, g(s));
    return;
  }
  if (di(e), i) {
    si = await m("spotify_devices").catch(() => []), di(e);
    return;
  }
  for (let s = 0; s < 6; s++) {
    await new Promise((t) => window.setTimeout(t, 1500));
    try {
      const t = await m("spotify_devices");
      si = t;
      const c = t.find((o) => o.name === "Lunac");
      if (c && !c.active && await m("spotify_transfer", { deviceId: c.id, play: !0 }), c) break;
    } catch {
    }
  }
  await Yi(e);
}
async function ms(e, i) {
  if (i) {
    try {
      await m("spotify_transfer", { deviceId: i, play: !1 }), z = !1;
    } catch (s) {
      ni(e, g(s));
    }
    await Yi(e);
  }
}
async function Me(e) {
  if (!(!(a != null && a.connected) || Bi || E)) {
    Bi = !0, ii = "", ti(e);
    try {
      E = await m("spotify_liked");
    } catch (i) {
      ii = g(i);
    } finally {
      Bi = !1, (p == null ? void 0 : p.kind) === "liked" && (O = (E == null ? void 0 : E.items) ?? null, li = !1, V = ii), ti(e), T(e);
    }
  }
}
function ye(e, i) {
  if (B = i, H = !!i, mi !== void 0 && (window.clearTimeout(mi), mi = void 0), !i) {
    k = null, ui = !1, J = !1, F(e), T(e);
    return;
  }
  ui = !0, F(e), T(e), mi = window.setTimeout(() => void ps(e, i), Ge);
}
async function ps(e, i) {
  mi = void 0;
  try {
    const s = await m("spotify_search", { query: i });
    if (B !== i) return;
    k = s;
  } catch (s) {
    if (B !== i) return;
    k = null, ni(e, g(s));
  } finally {
    B === i && (ui = !1, F(e), T(e));
  }
}
function qi(e) {
  const i = (X == null ? void 0 : X.items) ?? [], s = n("music.play_from_here"), t = i.length === 0 ? `<div class="music-empty">${n(X ? "music.queue_empty" : "music.loading")}</div>` : i.map((c, o) => Ri(c, o, "play-uri", "", s)).join("");
  for (const c of ["#music-q", "#music-q-dd"]) $(e.querySelector(c), t);
}
async function Re(e) {
  var i;
  try {
    X = await m("spotify_queue"), $e = ((i = l == null ? void 0 : l.track) == null ? void 0 : i.id) ?? "";
  } catch (s) {
    X = null, h(e.querySelector("#music-msg"), g(s));
  }
  qi(e);
}
function Gi(e) {
  const i = (l == null ? void 0 : l.track) ?? null, s = i != null && i.cover ? `<img src="${r(i.cover)}" alt="">` : "", t = [i == null ? void 0 : i.artists, i == null ? void 0 : i.album].filter(Boolean).join(" · ") || (l != null && l.active ? "" : n("music.no_device_hint"));
  $(e.querySelector("#music-pv-cover"), s), $(e.querySelector("#music-bnow-cover"), s), h(e.querySelector("#music-pv-title"), (i == null ? void 0 : i.name) || n("music.no_track")), h(e.querySelector("#music-bnow-n"), (i == null ? void 0 : i.name) || n("music.no_track")), h(e.querySelector("#music-pv-sub"), t), h(e.querySelector("#music-bnow-a"), t);
  const c = (i == null ? void 0 : i.duration_ms) ?? 0, o = Math.min((l == null ? void 0 : l.progress_ms) ?? 0, c || Number.MAX_SAFE_INTEGER), v = c > 0 ? Math.max(0, Math.min(100, o / c * 100)) : 0;
  if (Se = o, Ee = Date.now(), G < 0)
    for (const w of Z) w.style.setProperty("--seek-pct", `${v}%`);
  h(e.querySelector("#music-pv-pos"), gi(o)), h(e.querySelector("#music-pv-dur"), gi(c));
  const D = l != null && l.playing ? y.pause : y.play;
  $(e.querySelector("#music-play"), D), $(e.querySelector("#music-b-play"), D);
  const _ = Ie(), A = n(_ === "shuffle" ? "music.mode_shuffle" : _ === "repeat_one" ? "music.mode_repeat_one" : "music.mode_off");
  for (const w of [e.querySelector("#music-mode"), e.querySelector("#music-b-mode")])
    w && (zi(w, "data-mode", _), zi(w, "title", A), $(w, _ === "repeat_one" ? y.repeat : y.shuffle));
  const x = l && l.volume_percent >= 0 ? String(l.volume_percent) : "";
  for (const w of [e.querySelector("#music-vol"), e.querySelector("#music-b-vol")])
    w && x && document.activeElement !== w && (w.value = x);
  const Ji = !(l != null && l.active);
  e.querySelectorAll(".music-bar button, .music-nowbar button").forEach((w) => {
    w.id === "music-devices-btn" || w.id === "music-open-player" || w.id === "music-bnow" || (w.disabled = Ji);
  });
}
function vs(e) {
  var c;
  if (!e.isConnected || !(l != null && l.playing) || G >= 0) return;
  const i = ((c = l.track) == null ? void 0 : c.duration_ms) ?? 0;
  if (i <= 0) return;
  const s = Math.min(Se + (Date.now() - Ee), i), t = Math.max(0, Math.min(100, s / i * 100));
  for (const o of Z) o.style.setProperty("--seek-pct", `${t}%`);
  h(e.querySelector("#music-pv-pos"), gi(s));
}
function Ie() {
  return (l == null ? void 0 : l.repeat) === "track" ? "repeat_one" : l != null && l.shuffle ? "shuffle" : "off";
}
function Wi(e) {
  var i, s;
  L(e.querySelector("#music-q-wrap"), I), L(e.querySelector("#music-q-dd"), I), (i = e.querySelector("#music-queue-btn")) == null || i.classList.toggle("on", I), (s = e.querySelector("#music-b-queue")) == null || s.classList.toggle("on", I);
}
function Mi(e) {
  const i = e.querySelector("#music-lyr");
  if (!i) return;
  if (Qi(), Q = -1, ai = [], ri && (ri = !1, j !== void 0 && (window.clearTimeout(j), j = void 0)), Hi) {
    $(i, `<div class="music-empty">${n("music.lyrics_loading")}</div>`);
    return;
  }
  if (C != null && C.synced) {
    const t = Je(C.synced);
    if (t.length > 0) {
      ai = t;
      const c = r(n("music.seek_line"));
      $(
        i,
        `<div class="music-lyr-lines">${t.map((o, v) => `<div class="music-lyr-line" data-i="${v}" title="${c}">${r(o.text)}</div>`).join("")}</div>`
      );
      return;
    }
  }
  const s = ((C == null ? void 0 : C.plain) || "").trim();
  if (s) {
    $(i, `<div class="music-lyr-plain">${r(s)}</div>`);
    return;
  }
  if (C != null && C.instrumental) {
    $(i, `<div class="music-empty">${n("music.lyrics_instrumental")}</div>`);
    return;
  }
  $(i, `<div class="music-empty">${n("music.lyrics_none")}</div>`);
}
function Qi() {
  bi && (cancelAnimationFrame(bi), bi = 0);
}
function be(e, i) {
  Qi();
  const s = e.scrollTop, t = i - s;
  if (Math.abs(t) < 1) {
    e.scrollTop = i;
    return;
  }
  let c = 0;
  const o = (v) => {
    c || (c = v);
    const D = Math.min(1, (v - c) / Ye);
    e.scrollTop = s + t * (1 - Math.pow(1 - D, 5)), bi = D < 1 ? requestAnimationFrame(o) : 0;
  };
  bi = requestAnimationFrame(o);
}
function Ti(e) {
  var _, A;
  if (ai.length === 0) return;
  const i = e.querySelector("#music-lyr");
  if (!i || !i.isConnected || i.clientHeight === 0) return;
  const s = ((l == null ? void 0 : l.progress_ms) ?? 0) / 1e3;
  let t = -1;
  for (let x = 0; x < ai.length && ai[x].at <= s; x++)
    t = x;
  if (t === Q) return;
  const c = Math.min(Q, t), o = Math.max(Q, t);
  for (let x = Math.max(0, c + 1); x <= o; x++)
    (_ = i.querySelector(`.music-lyr-line[data-i="${x}"]`)) == null || _.classList.toggle("done", x <= t);
  (A = i.querySelector(".music-lyr-line.on")) == null || A.classList.remove("on"), Q = t;
  const v = i.querySelector(`.music-lyr-line[data-i="${t}"]`);
  if (!v) {
    ri || be(i, 0);
    return;
  }
  if (v.classList.add("on"), ri) return;
  const D = v.getBoundingClientRect().top - i.getBoundingClientRect().top + i.scrollTop;
  be(i, Math.max(0, D));
}
function he(e) {
  ri = !0, Qi(), j !== void 0 && window.clearTimeout(j), j = window.setTimeout(() => {
    j = void 0, ri = !1, Q = -1, Ti(e);
  }, Ve);
}
async function Li(e) {
  try {
    a = await m("music_config_get");
  } catch (i) {
    h(e.querySelector("#music-msg"), g(i));
    return;
  }
  !a.connected && M === "player" && (M = "default", Y(e)), Vi(e), Ci(e);
}
async function fs(e) {
  if (Pi === e.id) return;
  Pi = e.id, Hi = !0, C = null;
  const i = xe;
  i && Mi(i);
  try {
    C = await m("lyrics_get", {
      title: e.name,
      artist: e.artists,
      album: e.album,
      duration: e.duration_ms / 1e3
    });
  } catch (s) {
    C = { found: !1, instrumental: !1, track: "", artist: "", album: "", duration: 0, synced: null, plain: null }, i && h(i.querySelector("#music-msg"), g(s));
  } finally {
    Hi = !1, i && (Mi(i), Ti(i));
  }
}
async function Te(e, i) {
  if (i === ci) {
    if (!e.isConnected) {
      Xi();
      return;
    }
    if (Ze(e), a != null && a.connected) {
      if (!document.hidden && !ki) {
        ki = !0;
        try {
          if (l = await m("spotify_status"), i !== ci) return;
          Ci(e), Gi(e), Ti(e), us(e), qe(e), hi(e);
        } catch (s) {
          if (i !== ci) return;
          String(s).includes("ERR_NOT_CONNECTED") ? await Li(e) : h(e.querySelector("#music-msg"), g(s));
        } finally {
          ki = !1;
        }
      }
      l != null && l.track && fs(l.track), I && (l != null && l.track) && l.track.id !== $e && Re(e);
    }
    i === ci && (yi = window.setTimeout(() => void Te(e, i), 1e3));
  }
}
function Xi() {
  yi !== void 0 && (window.clearTimeout(yi), yi = void 0), $i !== void 0 && (window.clearInterval($i), $i = void 0), ci++, ki = !1;
}
function _e(e) {
  Xi();
  const i = ci;
  yi = window.setTimeout(() => void Te(e, i), 200), $i = window.setInterval(() => vs(e), Xe);
}
function hi(e) {
  document.getElementById("plugin-titlebar") && (ei !== void 0 && window.clearTimeout(ei), ei = window.setTimeout(() => void ys(e), 80));
}
async function ys(e) {
  if (ei = void 0, !document.getElementById("plugin-titlebar")) return;
  let i = Ue, s = je;
  if (M === "player") {
    const c = e.closest(".plugin-result"), o = c == null ? void 0 : c.closest("#results-list");
    if (!c || !o) return;
    const v = getComputedStyle(o), D = parseFloat(v.paddingTop || "0") + parseFloat(v.paddingBottom || "0"), _ = window.innerHeight - o.clientHeight;
    s = Math.round(_ + D + c.getBoundingClientRect().height), i = Fe;
  }
  const t = `${i}x${s}`;
  if (t !== Fi)
    try {
      await m("plugin_window_resize", { width: i, height: s }), Fi = t;
    } catch {
    }
}
async function hs(e) {
  var Zi, ie, ee, se, te, ne, ce, ae, le, ue, oe, re, de, me;
  const i = e.querySelector(".music-root");
  if (!i) return;
  xe = i, M = "default", wi = null, I = !1, Fi = "", ji = null, Si = "", Ei = 0, E = null, ii = "", Ui = null, oi.clear(), pi.clear(), _i.clear(), N = "playlist", p = null, O = null, li = !1, V = "", si = null, z = !1, U = null, B = "", k = null, ui = !1, H = !1, J = !1, P = "tracks", Z = [];
  const s = (u) => h(i.querySelector("#music-msg"), u), t = (u) => i.querySelector(u);
  K && (K(), K = null), K = await We("spotify-auth", (u) => {
    i.isConnected && (u.payload.ok ? (s(n("music.auth_ok")), Li(i).then(() => {
      _e(i);
    })) : s(u.payload.message || n("music.auth_failed")));
  });
  const c = () => {
    M = "player", Y(i);
  }, o = () => {
    M = "default", Y(i);
  };
  (Zi = t("#music-setup-toggle")) == null || Zi.addEventListener("click", () => {
    M = "default", Y(i);
    const u = t("#music-setup");
    u && u.classList.toggle("hidden");
  }), (ie = t("#music-open-player")) == null || ie.addEventListener("click", c), (ee = t("#music-bnow")) == null || ee.addEventListener("click", c), (se = t("#music-back")) == null || se.addEventListener("click", o);
  const v = (u) => {
    var d;
    !i.isConnected || M !== "player" || (d = u.target) != null && d.closest("#plugin-close") && (u.stopPropagation(), u.preventDefault(), ts(i));
  };
  document.addEventListener("click", v, !0), (te = t("#music-fields-toggle")) == null || te.addEventListener("click", () => {
    wi = !(wi ?? !(a != null && a.builtin)), Vi(i);
  }), (ne = t("#music-copy-redirect")) == null || ne.addEventListener("click", () => {
    const u = (a == null ? void 0 : a.redirect_uri) || "";
    u && He(u).then(() => s(n("music.copied"))).catch(() => {
    });
  }), (ce = t("#music-save")) == null || ce.addEventListener("click", async () => {
    var S, f, q, W;
    const u = ((S = t("#music-client-id")) == null ? void 0 : S.value.trim()) ?? "", d = ((f = t("#music-port")) == null ? void 0 : f.value.trim()) ?? "", b = Number(d);
    if (!u) {
      s(n("music.err_no_client_id"));
      return;
    }
    if (!Number.isInteger(b) || b < 1024 || b > 65535) {
      s(n("music.err_bad_port"));
      return;
    }
    try {
      a = await m("music_config_set", {
        clientId: u,
        port: b,
        // 本机播放那两项**一起交上去**（留空 = 自动探测 / 直连，都是合法值）
        librespotPath: ((q = t("#music-librespot")) == null ? void 0 : q.value.trim()) ?? "",
        librespotProxy: ((W = t("#music-librespot-proxy")) == null ? void 0 : W.value.trim()) ?? ""
      }), s(n("music.saved")), Vi(i), Ci(i), U = null;
    } catch (Ni) {
      s(g(Ni));
    }
  }), (ae = t("#music-connect")) == null || ae.addEventListener("click", async () => {
    var b, S;
    const u = ((b = t("#music-client-id")) == null ? void 0 : b.value.trim()) ?? "", d = Number(((S = t("#music-port")) == null ? void 0 : S.value.trim()) ?? "");
    if (u && Number.isInteger(d) && d >= 1024)
      try {
        a = await m("music_config_set", {
          clientId: u,
          port: d,
          librespotPath: null,
          librespotProxy: null
        });
      } catch (f) {
        s(g(f));
        return;
      }
    try {
      const f = await m("spotify_connect");
      s(n("music.browser_hint")), await Pe(f);
    } catch (f) {
      s(g(f));
    }
  }), (le = t("#music-disconnect")) == null || le.addEventListener("click", async () => {
    try {
      await m("spotify_disconnect"), l = null, C = null, Pi = "", Ui = null, oi.clear(), _i.clear(), X = null, I = !1, p = null, O = null, V = "", k = null, B = "", H = !1, J = !1, si = null, M = "default", await Li(i), Y(i), qi(i), s(n("music.disconnected"));
    } catch (u) {
      s(g(u));
    }
  });
  const D = (u) => {
    var f;
    const d = (f = u.target) == null ? void 0 : f.closest("[data-act]");
    if (!d) return;
    const b = d.dataset.kind || "", S = d.dataset.id || "";
    switch (d.dataset.act) {
      case "side-tab":
        N = d.dataset.tab || "playlist", ti(i), Ce(i, N);
        break;
      case "search-tab":
        P = d.dataset.tab || "tracks", T(i);
        break;
      case "open":
        os(i, b, S);
        break;
      case "main-track":
        rs(i, Number(d.dataset.i || "0"));
        break;
      case "main-play-all":
        p && fe(i, p.kind, p.id);
        break;
      case "dd-track":
        d.dataset.uri && ge(i, d.dataset.uri);
        break;
      case "play-uri":
        d.dataset.uri && ge(i, d.dataset.uri);
        break;
      case "search-all":
        H = !1, J = !0, F(i), T(i);
        break;
      case "dev-pick":
        ms(i, S);
        break;
      case "local-toggle":
        ds(i);
        break;
    }
  };
  for (const u of ["#music-side-list", "#music-side-tabs", "#music-main", "#music-search-dd", "#music-dev-dd", "#music-q", "#music-q-dd"])
    (ue = t(u)) == null || ue.addEventListener("click", D);
  (oe = t("#music-side-list")) == null || oe.addEventListener("dblclick", (u) => {
    var f;
    const d = (f = u.target) == null ? void 0 : f.closest('[data-act="open"]');
    if (!d) return;
    const b = d.dataset.kind || "", S = d.dataset.id || "";
    S && fe(i, b, S);
  }), (re = t("#music-devices-btn")) == null || re.addEventListener("click", () => {
    z = !z, di(i), z && Yi(i);
  }), ve(i), (de = t("#music-split")) == null || de.addEventListener("pointerdown", (u) => {
    var q;
    u.preventDefault();
    const d = u.clientX, b = ((q = t("#music-side")) == null ? void 0 : q.getBoundingClientRect().width) ?? vi, S = (W) => {
      vi = Math.min(ke, Math.max(we, Math.round(b + W.clientX - d))), ve(i);
    }, f = () => {
      window.removeEventListener("pointermove", S), window.removeEventListener("pointerup", f), document.body.classList.remove("music-resizing");
    };
    document.body.classList.add("music-resizing"), window.addEventListener("pointermove", S), window.addEventListener("pointerup", f);
  }), document.addEventListener("pointerdown", (u) => {
    const d = u.target;
    d && (z && !d.closest("#music-dev-dd") && !d.closest("#music-devices-btn") && (z = !1, di(i)), H && !d.closest(".music-search-wrap") && (H = !1, F(i)), I && !d.closest("#music-q-dd") && !d.closest("#music-b-queue") && !d.closest("#music-queue-btn") && (I = !1, Wi(i)));
  });
  const _ = t("#music-search");
  _ == null || _.addEventListener("input", () => ye(i, _.value.trim())), _ == null || _.addEventListener("focus", () => {
    B && (H = !0, F(i));
  }), _ == null || _.addEventListener("keydown", (u) => {
    if (u.key === "Enter" && B) {
      H = !1, J = !0, F(i), T(i);
      return;
    }
    u.key === "Escape" && (_.value = "", ye(i, ""));
  }), document.body.addEventListener("mouseenter", () => hi(i)), document.body.addEventListener("mouseleave", () => hi(i));
  const A = async (u, d) => {
    try {
      await m("spotify_control", { action: u, value: d });
    } catch (b) {
      s(g(b));
    }
  }, x = (u, d) => {
    var b;
    for (const S of u) (b = t(`#${S}`)) == null || b.addEventListener("click", d);
  };
  x(["music-queue-btn", "music-b-queue"], () => {
    I = !I, Wi(i), qi(i), I ? Re(i) : Gi(i), hi(i);
  }), x(["music-prev", "music-b-prev"], () => void A("previous")), x(["music-next", "music-b-next"], () => void A("next")), x(["music-play", "music-b-play"], () => void A(l != null && l.playing ? "pause" : "play"));
  let w = null, Di = !1;
  const De = async (u) => {
    if (w = u, !Di) {
      Di = !0;
      try {
        for (; w !== null; ) {
          const d = w;
          w = null, await A("volume", d);
        }
      } finally {
        Di = !1;
      }
    }
  };
  for (const u of ["music-vol", "music-b-vol"])
    (me = t(`#${u}`)) == null || me.addEventListener("input", (d) => {
      De(Number(d.target.value));
    });
  x(["music-mode", "music-b-mode"], () => {
    const u = Ie();
    m("spotify_set_play_mode", { mode: u === "off" ? "shuffle" : u === "shuffle" ? "repeat_one" : "off" }).catch((b) => s(g(b)));
  }), Z = ["#music-pv-progress", "#music-bp"].map((u) => t(u)).filter((u) => !!u);
  for (const u of Z) {
    const d = (f) => {
      const q = u.getBoundingClientRect();
      return Math.max(0, Math.min(1, (f - q.left) / Math.max(1, q.width)));
    }, b = (f) => {
      var W;
      G = f;
      const q = `${f * 100}%`;
      for (const Ni of Z) Ni.style.setProperty("--seek-pct", q);
      h(u.querySelector(".music-progress-tip"), gi((((W = l == null ? void 0 : l.track) == null ? void 0 : W.duration_ms) ?? 0) * f));
    };
    u.addEventListener("pointerdown", (f) => {
      var q;
      if (!((((q = l == null ? void 0 : l.track) == null ? void 0 : q.duration_ms) ?? 0) <= 0)) {
        try {
          u.setPointerCapture(f.pointerId);
        } catch {
        }
        u.classList.add("music-dragging"), b(d(f.clientX));
      }
    }), u.addEventListener("pointermove", (f) => {
      G < 0 || b(d(f.clientX));
    });
    const S = (f) => {
      var W;
      if (G < 0) return;
      const q = G;
      G = -1, u.classList.remove("music-dragging");
      try {
        u.releasePointerCapture(f.pointerId);
      } catch {
      }
      A("seek", Math.round((((W = l == null ? void 0 : l.track) == null ? void 0 : W.duration_ms) ?? 0) * q));
    };
    u.addEventListener("pointerup", S), u.addEventListener("pointercancel", S);
  }
  const R = t("#music-lyr");
  let Ai = !1, Ki = 0;
  R == null || R.addEventListener("wheel", () => he(i), { passive: !0 }), R == null || R.addEventListener("pointerdown", (u) => {
    Ai = !1, Ki = u.clientY, he(i);
  }), R == null || R.addEventListener("pointermove", (u) => {
    Math.abs(u.clientY - Ki) > 4 && (Ai = !0);
  }), R == null || R.addEventListener("click", (u) => {
    if (Ai) return;
    const d = u.target.closest(".music-lyr-line"), b = d ? ai[Number(d.dataset.i)] : void 0;
    b && A("seek", Math.round(b.at * 1e3));
  }), await Li(i), Y(i), Gi(i), Mi(i), qi(i), Wi(i), Ci(i), _e(i);
}
async function ge(e, i) {
  try {
    await m("spotify_play_uri", { uri: i });
  } catch (s) {
    h(e.querySelector("#music-msg"), g(s));
  }
}
function bs() {
  Xi(), j !== void 0 && (window.clearTimeout(j), j = void 0), ei !== void 0 && (window.clearTimeout(ei), ei = void 0), K && (K(), K = null), Z = [], ss();
}
window.__lunac_music_stop = bs;
const _s = {
  id: "music",
  name: "音乐歌词",
  keywords: ["音乐", "歌词", "歌曲", "正在播放", "music", "lyrics", "spotify", "播放控制", "暂停", "下一首", "歌单", "播放列表"],
  description: "歌词自动抓取 (LRCLIB + 网易云兜底) + Spotify 播放控制 / 歌单 / 队列",
  icon: "🎵",
  badge: "music",
  // 「本插件一律在**悬浮窗**里打开」（2026-09-29 从 main.ts 的硬编码 `id === "music"` 改成声明）。
  // 为什么要声明而不是让宿主按 id 判：音乐已归入**拓展插件**，要能从市场独立打包分发
  // —— 磁盘插件的代码宿主没法写死，行为只能由插件自己声明（见 ai-spec §3.5「插件契约」）。
  // 这也是「用户 2026-09-28 定的：从 Lunac 进音乐界面时自动展开成独立界面」那条的执行点。
  permissions: ["window.float"],
  async execute() {
    return { type: "html", content: Ke() };
  }
};
export {
  hs as attach,
  hs as attachMusicListeners,
  _s as default,
  bs as detach,
  _s as musicPlugin,
  bs as stopMusicPolling
};
