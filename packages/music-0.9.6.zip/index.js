const Ce = "__lunac_host";
function Me() {
  return globalThis[Ce] ?? null;
}
function n(e, i) {
  const s = Me();
  return s && typeof s.t == "function" ? s.t(e, i) : e;
}
function Re(e, i = !1) {
  return window.__TAURI_INTERNALS__.transformCallback(e, i);
}
async function m(e, i = {}, s) {
  return window.__TAURI_INTERNALS__.invoke(e, i, s);
}
var re;
(function(e) {
  e.WINDOW_RESIZED = "tauri://resize", e.WINDOW_MOVED = "tauri://move", e.WINDOW_CLOSE_REQUESTED = "tauri://close-requested", e.WINDOW_DESTROYED = "tauri://destroyed", e.WINDOW_FOCUS = "tauri://focus", e.WINDOW_BLUR = "tauri://blur", e.WINDOW_SCALE_FACTOR_CHANGED = "tauri://scale-change", e.WINDOW_THEME_CHANGED = "tauri://theme-changed", e.WINDOW_CREATED = "tauri://window-created", e.WINDOW_SUSPENDED = "tauri://suspended", e.WINDOW_RESUMED = "tauri://resumed", e.WEBVIEW_CREATED = "tauri://webview-created", e.DRAG_ENTER = "tauri://drag-enter", e.DRAG_OVER = "tauri://drag-over", e.DRAG_DROP = "tauri://drag-drop", e.DRAG_LEAVE = "tauri://drag-leave";
})(re || (re = {}));
async function Ie(e, i) {
  window.__TAURI_EVENT_PLUGIN_INTERNALS__.unregisterListener(e, i), await m("plugin:event|unlisten", {
    event: e,
    eventId: i
  });
}
async function Te(e, i, s) {
  var t;
  const c = (t = void 0) !== null && t !== void 0 ? t : { kind: "Any" };
  return m("plugin:event|listen", {
    event: e,
    target: c,
    handler: Re(i)
  }).then((o) => async () => Ie(e, o));
}
async function Ae(e, i) {
  await m("plugin:shell|open", {
    path: e,
    with: i
  });
}
async function De(e, i) {
  await m("plugin:clipboard-manager|write_text", {
    label: i == null ? void 0 : i.label,
    text: e
  });
}
const Ne = 1280, Oe = 720, Be = 550, We = 300, he = 180, _e = 520, Pe = 4e3, He = 450, Ue = 800, je = 8e3, b = {
  play: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polygon points="6 4 20 12 6 20 6 4"/></svg>',
  pause: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="9" y1="4" x2="9" y2="20"/><line x1="15" y1="4" x2="15" y2="20"/></svg>',
  prev: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polygon points="19 5 9 12 19 19 19 5"/><line x1="5" y1="5" x2="5" y2="19"/></svg>',
  next: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polygon points="5 5 15 12 5 19 5 5"/><line x1="19" y1="5" x2="19" y2="19"/></svg>',
  /** 随机（关 / 随机共用这一个；「关」靠 `data-mode` 变暗区分）。 */
  shuffle: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="16 3 21 3 21 8"/><line x1="4" y1="20" x2="21" y2="3"/><polyline points="21 16 21 21 16 21"/><line x1="15" y1="15" x2="21" y2="21"/><line x1="4" y1="4" x2="9" y2="9"/></svg>',
  /** 循环（单曲循环；那个「1」由 CSS `::after` 加，SVG 里不写字）。 */
  repeat: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="17 1 21 5 17 9"/><path d="M3 11V9a4 4 0 0 1 4-4h14"/><polyline points="7 23 3 19 7 15"/><path d="M21 13v2a4 4 0 0 1-4 4H3"/></svg>',
  list: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="9" y1="6" x2="21" y2="6"/><line x1="9" y1="12" x2="21" y2="12"/><line x1="9" y1="18" x2="21" y2="18"/><circle cx="4" cy="6" r="1" fill="currentColor" stroke="none"/><circle cx="4" cy="12" r="1" fill="currentColor" stroke="none"/><circle cx="4" cy="18" r="1" fill="currentColor" stroke="none"/></svg>',
  /** 进播放界面。 */
  expand: '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 3 21 3 21 9"/><polyline points="9 21 3 21 3 15"/><line x1="21" y1="3" x2="14" y2="10"/><line x1="3" y1="21" x2="10" y2="14"/></svg>',
  /** 回默认界面。**唯一**的退出播放界面的入口 —— 播放停止不会自动退出。 */
  back: '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/><line x1="3" y1="12" x2="9" y2="12"/></svg>',
  copy: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15V5a2 2 0 0 1 2-2h10"/></svg>',
  link: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.5 1.5"/><path d="M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7L12 19"/></svg>',
  power: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M18.4 6.6a9 9 0 1 1-12.8 0"/><line x1="12" y1="2" x2="12" y2="12"/></svg>',
  gear: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>',
  volume: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M15.5 8.5a5 5 0 0 1 0 7"/></svg>',
  /** 工具条上的「设备」按钮（2026-09-28）。画成一台小音箱，比「显示器」更贴
   *  Spotify 那种「可选的播放设备」语义。 */
  speaker: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="2" width="14" height="20" rx="2"/><circle cx="12" cy="14" r="3.2"/><circle cx="12" cy="6" r="1" fill="currentColor" stroke="none"/></svg>',
  /** 实心心形（「我喜欢的歌曲」那块封面上的图案）。**这个是 `fill`，不是描边** ——
   *  它是一块封面图（Spotify 的收藏夹封面就是实心心 + 渐变底），不是可点按钮。 */
  heart: '<svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" stroke="none"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>'
};
let a = null, l = null, C = null, Oi = "", Bi = !1, ci = [], Y = -1, _i = null, M = "default", Wi = null, G = null, R = !1, ge = "", E = null, Ai = !1, J = "", N = "", k = null, li = !1, di, D = "playlist";
const ui = /* @__PURE__ */ new Map(), mi = /* @__PURE__ */ new Set(), hi = /* @__PURE__ */ new Map();
let p = null, O = null, ai = !1, z = "", P = !1, Q = !1, W = "tracks", K = null, F = !1, H = null, pi = We, Pi = null, vi = "", fi, gi = !1, X = null, we = null, ti = 0, oi = !1, si = -1, ni = [], yi = 0, U, Z, wi = "", ki = 0, Hi = "";
function r(e) {
  return e.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
function xi(e) {
  if (!isFinite(e) || e < 0) return "0:00";
  const i = Math.floor(e / 1e3), s = Math.floor(i / 60), t = i % 60;
  return `${s}:${String(t).padStart(2, "0")}`;
}
function w(e) {
  const i = e instanceof Error ? e.message : String(e);
  if (i.includes("ERR_NO_CLIENT_ID")) return n("music.err_no_client_id");
  if (i.includes("ERR_NOT_CONNECTED")) return n("music.err_not_connected");
  if (i.includes("ERR_NO_QUERY")) return n("music.err_no_query");
  if (i.includes("ERR_PORT_BUSY")) return n("music.err_port_busy", { port: String((a == null ? void 0 : a.port) ?? "") });
  if (i.includes("ERR_BAD_URI") || i.includes("ERR_BAD_ID")) return n("music.err_bad_uri");
  const s = i.match(/ERR_RATE_LIMITED:(\S*)/);
  return s ? n("music.err_rate_limited", { s: s[1] || "?" }) : i.includes("Insufficient client scope") ? n("music.err_scope") : i.includes("No active device") || i.includes("NO_ACTIVE_DEVICE") ? n("music.err_no_device") : i.includes("Premium required") || i.includes("PREMIUM_REQUIRED") ? n("music.err_premium") : i.includes("Restriction violated") ? n("music.err_restricted") : i;
}
function Fe(e) {
  const i = [];
  for (const s of e.split(/\r?\n/)) {
    const t = [...s.matchAll(/\[(\d{1,3}):(\d{1,2})(?:[.:](\d{1,3}))?\]/g)];
    if (t.length === 0) continue;
    const c = s.replace(/\[[^\]]*\]/g, "").trim();
    if (c)
      for (const o of t) {
        const v = o[3] ? Number(o[3].padEnd(3, "0")) / 1e3 : 0;
        i.push({ at: Number(o[1]) * 60 + Number(o[2]) + v, text: c });
      }
  }
  return i.sort((s, t) => s.at - t.at), i;
}
function ze() {
  return `
  <div class="music-root">
    <!-- ── 默认界面：顶部工具条 + 状态行 + 连接设置 + 歌单列 / 搜索结果 ──
         工具条与「返回」按钮**分属两态**：默认态用工具条上的「进播放界面」，
         播放态用歌名模块右端那个「返回」（music-back 这个 id 全文档只有一个）。 -->
    <div class="music-view" id="music-v-default">
      <!-- 顶部工具条：头像 / 账号 / 搜索（**带下拉预览**）/ 状态 / 设置。
           2026-09-28 第二次改：设备按钮与「展开播放面板」都**下移到最底下那条控制栏**
           （用户要求「严格对齐 Spotify」，Spotify 的工具条上本来就没有这两样）。 -->
      <div class="music-toolbar">
        <span class="music-avatar" id="music-avatar"></span>
        <span class="music-acc" id="music-acc"></span>
        <div class="music-search-wrap">
          <input class="music-search" id="music-search" type="search" autocomplete="off" spellcheck="false" placeholder="${r(n("music.search_ph"))}">
          <!-- 下拉预览：绝对定位挂在工具条下方（**不占布局**，否则窗口高会跟着抖） -->
          <div class="music-dd hidden" id="music-search-dd"></div>
        </div>
        <span class="music-status" id="music-status">${n("music.loading")}</span>
        <button class="music-ghost-btn music-icon-btn" id="music-setup-toggle" title="${r(n("music.settings"))}">${b.gear}</button>
      </div>

      <div class="music-setup hidden" id="music-setup">
        <div class="music-hint" id="music-setup-hint">${n("music.setup_hint")}</div>
        <!-- 凭据字段默认只在「没有内置 Client ID」或用户主动展开时显示：
             内置值让「登录」变成一步操作，Redirect URI 那一串对普通用户是噪音。 -->
        <button class="music-ghost-btn music-fields-toggle hidden" id="music-fields-toggle"></button>
        <div id="music-setup-fields">
          <div class="music-field">
            <label for="music-client-id">${n("music.client_id")}</label>
            <input id="music-client-id" type="text" spellcheck="false" autocomplete="off" placeholder="${r(n("music.client_id_ph"))}">
          </div>
          <div class="music-field music-field-port">
            <label for="music-port">${n("music.port")}</label>
            <input id="music-port" type="text" inputmode="numeric" autocomplete="off">
          </div>
          <div class="music-field">
            <label>${n("music.redirect")}</label>
            <div class="music-redirect-row">
              <code id="music-redirect"></code>
              <button class="music-ghost-btn music-icon-btn" id="music-copy-redirect" title="${r(n("music.copy"))}">${b.copy}</button>
            </div>
          </div>
          <!-- 本机播放（librespot）的两项设置：路径留空 = 自动探测；代理留空 = 直连。
               两者都不是「必填」，所以各带一行小字说明（见 renderSetup）。 -->
          <div class="music-field">
            <label for="music-librespot">${n("music.local_play")}</label>
            <input id="music-librespot" type="text" spellcheck="false" autocomplete="off" placeholder="librespot.exe">
          </div>
          <div class="music-field">
            <label for="music-librespot-proxy">proxy</label>
            <input id="music-librespot-proxy" type="text" spellcheck="false" autocomplete="off" placeholder="http://127.0.0.1:7890">
          </div>
        </div>
        <div class="music-actions">
          <button class="music-btn" id="music-save">${n("music.save")}</button>
          <button class="music-btn music-primary" id="music-connect">${b.link} ${n("music.connect")}</button>
          <button class="music-btn" id="music-disconnect">${b.power} ${n("music.disconnect")}</button>
        </div>
      </div>

      <!-- 主体：**左栏（宽度可拖）+ 分隔条 + 主区**（用户 2026-09-28 的
           「歌单列作为单独的一列可拉动」「中间大的大部分区域作为歌曲列表」）。
           两栏各自内部滚动 —— 窗口是定尺 1280×720，不是靠内容撑出来的。 -->
      <div class="music-body hidden" id="music-body">
        <aside class="music-side" id="music-side">
          <div class="music-side-tabs" id="music-side-tabs">
            <button class="music-tab on" data-act="side-tab" data-tab="playlist">${n("music.playlists")}</button>
            <button class="music-tab" data-act="side-tab" data-tab="album">${n("music.tab_albums")}</button>
            <button class="music-tab" data-act="side-tab" data-tab="artist">${n("music.tab_artists")}</button>
            <button class="music-tab" data-act="side-tab" data-tab="show">${n("music.tab_shows")}</button>
          </div>
          <div class="music-side-list" id="music-side-list"></div>
        </aside>
        <div class="music-split" id="music-split" role="separator" aria-orientation="vertical"></div>
        <main class="music-main" id="music-main"></main>
      </div>

      <!-- ── 底部控制栏（2026-09-28，Spotify 复刻）─────────────────────────
           用户要求「在默认面板下方添加 Spotify 那样的播放控制，并把一些按钮也
           移动到下方控制」。三列 grid：左 = 正在播放（点它 = 打开播放面板）、
           中 = 播放键组、右 = 设备 / 音量 / 队列 / 展开。
           栏顶那条 2px 细进度线**绝对定位**（不占高），拖动即可跳转。
           **两个弹层都挂在右端那一簇里、向上弹**：这条栏贴着窗口下沿，
           向下弹会跑到窗口外面（见 styles.css 里那两条覆盖 top 的规则）。
           注意本段是 JS 模板字符串 —— 注释里不能出现反引号（会把字符串截断）。 -->
      <div class="music-nowbar hidden" id="music-nowbar">
        <div class="music-bp" id="music-bp" title="${r(n("music.seek"))}">
          <div class="music-bp-fill" id="music-bp-fill"></div>
          <div class="music-progress-tip" id="music-bp-tip">0:00</div>
        </div>
        <button class="music-bnow" id="music-bnow" title="${r(n("music.open_player"))}">
          <span class="music-bnow-cover" id="music-bnow-cover"></span>
          <span class="music-bnow-main">
            <span class="music-bnow-n" id="music-bnow-n"></span>
            <span class="music-bnow-a" id="music-bnow-a"></span>
          </span>
        </button>
        <div class="music-bctl">
          <button class="music-round-btn music-mode-btn" id="music-b-mode" data-mode="off"></button>
          <button class="music-round-btn" id="music-b-prev" title="${r(n("music.prev"))}">${b.prev}</button>
          <button class="music-round-btn music-play-btn" id="music-b-play" title="${r(n("music.play_pause"))}">${b.play}</button>
          <button class="music-round-btn" id="music-b-next" title="${r(n("music.next"))}">${b.next}</button>
        </div>
        <div class="music-bend">
          <button class="music-ghost-btn music-icon-btn" id="music-devices-btn" title="${r(n("music.devices"))}">${b.speaker}</button>
          <span class="music-vol-ico">${b.volume}</span>
          <input class="music-vol" id="music-b-vol" type="range" min="0" max="100" step="5" value="50" title="${r(n("music.volume"))}">
          <button class="music-round-btn" id="music-b-queue" title="${r(n("music.queue"))}">${b.list}</button>
          <button class="music-ghost-btn music-icon-btn hidden" id="music-open-player" title="${r(n("music.open_player"))}">${b.expand}</button>
          <div class="music-dd music-dev-dd hidden" id="music-dev-dd"></div>
          <div class="music-dd hidden" id="music-q-dd"></div>
        </div>
      </div>
    </div>

    <!-- ── 播放界面：**550×130 的长条**（封面 100 + 右侧列 450）──────────
         右侧列三块的高度加起来正好是长条高：歌名 30 + 歌词 65 + 控制 35 = 130。
         **这几个数都是用户 2026-09-27 给的定尺**：改任何一个都要同步
         styles.css 的 .music-name / .music-lyr / .music-bar，以及宿主
         plugin_window.rs 的 MUSIC_W（见 ai-spec §4.6 与预检 #39 ④）。 -->
    <!-- 注意：本段是 JS 模板字符串，**注释里不能出现反引号**（会把字符串截断）。 -->
    <div class="music-view music-player hidden" id="music-v-player">
      <div class="music-pv-card">
        <div class="music-pv-cover" id="music-pv-cover"></div>
        <div class="music-pv-col">
          <!-- 歌名模块 H30：歌名（亮）+ 歌手·专辑（暗）+ 返回入口。
               「返回」放在这里而不是标题行 —— 播放态整条只有 130 高，
               标题行（状态 / 账号 / 齿轮）在默认态里，这一态不显示。
               时间不在这里（用户 2026-09-27 要求挪到控制块最左端、进度条下方）。 -->
          <div class="music-name">
            <div class="music-name-text">
              <span class="music-title" id="music-pv-title"></span>
              <span class="music-sub" id="music-pv-sub"></span>
            </div>
            <button class="music-ghost-btn music-icon-btn hidden" id="music-back" title="${r(n("music.back"))}">${b.back}</button>
          </div>

          <!-- 歌词模块 H65：正好两行可见（行高 32）。已过 + 正在 = 亮，未到 = 暗；
               点某一行 = 跳到那一句的进度。 -->
          <div class="music-lyr" id="music-lyr"></div>

          <!-- 控制面板 H35：进度条**叠在本块顶部**（绝对定位 ⇒ 不占高度，总高仍是 130），
               四个播放键在块内居中，右端音量条 80px + 播放列表按钮。 -->
          <div class="music-bar">
            <!-- 时间在控制块**最左端、进度条下方**（用户 2026-09-27 定）。
                 绝对定位 ⇒ 不参与四钮的居中计算。 -->
            <div class="music-time">
              <span id="music-pv-pos">0:00</span><span class="music-time-sep">/</span><span id="music-pv-dur">0:00</span>
            </div>
            <div class="music-progress" id="music-pv-progress" title="${r(n("music.seek"))}">
              <div class="music-progress-fill" id="music-pv-fill"></div>
              <div class="music-progress-dot" id="music-pv-dot"></div>
              <div class="music-progress-tip" id="music-pv-tip">0:00</div>
            </div>
            <div class="music-bar-main">
              <button class="music-round-btn music-mode-btn" id="music-mode" data-mode="off"></button>
              <button class="music-round-btn" id="music-prev" title="${r(n("music.prev"))}">${b.prev}</button>
              <button class="music-round-btn music-play-btn" id="music-play" title="${r(n("music.play_pause"))}">${b.play}</button>
              <button class="music-round-btn" id="music-next" title="${r(n("music.next"))}">${b.next}</button>
            </div>
            <div class="music-bar-end">
              <span class="music-vol-ico">${b.volume}</span>
              <input class="music-vol" id="music-vol" type="range" min="0" max="100" step="5" value="50" title="${r(n("music.volume"))}">
              <button class="music-round-btn" id="music-queue-btn" title="${r(n("music.queue"))}">${b.list}</button>
            </div>
          </div>
        </div>
      </div>

      <!-- 播放列表（队列）挂在长条**下方**、不再与歌词互斥：长条是定尺 130，
           塞不进队列。开着时窗口按内容长高（applyResize 实测贴合）。 -->
      <div class="music-q-wrap hidden" id="music-q-wrap">
        <div class="music-sec-head">
          <span class="music-sec-title">${n("music.queue")}</span>
          <span class="music-sec-note">${n("music.queue_hint")}</span>
        </div>
        <div class="music-q" id="music-q"></div>
      </div>
    </div>

    <div class="music-msg" id="music-msg"></div>
  </div>`;
}
function _(e, i) {
  e && e.textContent !== i && (e.textContent = i);
}
function $(e, i) {
  e && e.innerHTML !== i && (e.innerHTML = i);
}
function L(e, i) {
  e == null || e.classList.toggle("hidden", !i);
}
function Ui(e, i, s) {
  e && e.getAttribute(i) !== s && e.setAttribute(i, s);
}
function Ve(e) {
  const i = e.querySelector("#music-msg");
  if (!i) return;
  const s = i.textContent ?? "";
  if (s !== wi) {
    wi = s, ki = Date.now();
    return;
  }
  s && Date.now() - ki >= je && (i.textContent = "", wi = "", ki = 0);
}
function V(e) {
  const i = M === "player";
  L(e.querySelector("#music-v-default"), !i), L(e.querySelector("#music-v-player"), i), e.classList.toggle("music-player-on", i), Ye(i), Ge(), ke(e), i ? (Y = -1, Li(e), Ri(e)) : (L(e.querySelector("#music-body"), !!(a != null && a.connected)), ii(e), I(e), j(e), ri(e)), bi(e);
}
function Ye(e) {
  const i = !e;
  document.getElementById("plugin-titlebar") && Pi !== i && (Pi = i, m("plugin_window_set_resizable", { resizable: i }).catch(() => {
  }));
}
function Ge() {
  const e = document.getElementById("plugin-close");
  if (!e) return;
  vi || (vi = e.innerHTML);
  const i = M === "player" ? "back" : "close";
  if (e.dataset.mode === i) return;
  e.dataset.mode = i, e.innerHTML = i === "back" ? b.back : vi;
  const s = i === "back" ? n("music.back") : "Close";
  e.title = s, e.setAttribute("aria-label", s);
}
function Qe() {
  const e = document.getElementById("plugin-close");
  !e || !vi || e.dataset.mode !== "back" || (e.innerHTML = vi, e.title = "Close", e.setAttribute("aria-label", "Close"), e.dataset.mode = "close");
}
async function Xe(e) {
  try {
    await m("spotify_control", { action: "pause" });
  } catch (i) {
    ei(e, w(i));
  }
  M = "default", V(e);
}
function ke(e) {
  const i = M === "player";
  L(e.querySelector("#music-open-player"), !i && !!(l != null && l.track)), L(e.querySelector("#music-back"), i), L(e.querySelector("#music-nowbar"), !i && !!(a != null && a.connected));
}
function qi(e, i) {
  const s = e.querySelector("#music-status");
  a != null && a.client_id ? a.connected ? l ? l.active ? l.playing ? _(s, n("music.status_playing")) : _(s, n("music.status_paused")) : _(s, n("music.status_no_device")) : _(s, n("music.status_connecting")) : _(s, n("music.status_disconnected")) : _(s, n("music.status_unconfigured"));
  const t = e.querySelector("#music-avatar");
  if (t) {
    const o = a != null && a.connected && a.avatar || "";
    $(t, o ? `<img src="${r(o)}" alt="">` : "");
  }
  _(e.querySelector("#music-acc"), a != null && a.connected && a.display_name || "");
  const c = e.querySelector("#music-devices-btn");
  c && (Ui(c, "title", `${n("music.devices")}：${(l == null ? void 0 : l.device) || n("music.device_none")}`), c.classList.toggle("warn", !!(a != null && a.connected) && !(l != null && l.active)));
}
function ji(e) {
  L(e.querySelector("#music-setup"), !(a != null && a.connected)), L(e.querySelector("#music-body"), !!(a != null && a.connected)), ii(e), I(e), a != null && a.connected && (Se(e, D), Ee(e));
  const i = _i ?? !(a != null && a.builtin);
  L(e.querySelector("#music-setup-fields"), i), L(e.querySelector("#music-save"), i);
  const s = e.querySelector("#music-fields-toggle");
  L(s, !!(a != null && a.builtin)), _(s, n(i ? "music.hide_fields" : "music.use_own_client_id")), _(
    e.querySelector("#music-setup-hint"),
    a != null && a.builtin ? n("music.setup_builtin") : n("music.setup_hint")
  );
  const t = e.querySelector("#music-client-id"), c = e.querySelector("#music-port"), o = e.querySelector("#music-librespot"), v = e.querySelector("#music-librespot-proxy");
  t && document.activeElement !== t && (t.value = (a == null ? void 0 : a.client_id) ?? ""), c && document.activeElement !== c && (c.value = String((a == null ? void 0 : a.port) ?? 8899)), o && document.activeElement !== o && (o.value = (a == null ? void 0 : a.librespot_path) ?? ""), v && document.activeElement !== v && (v.value = (a == null ? void 0 : a.librespot_proxy) ?? ""), _(e.querySelector("#music-redirect"), (a == null ? void 0 : a.redirect_uri) ?? "");
}
function Je(e) {
  var i;
  return !!e.uri && ((i = l == null ? void 0 : l.track) == null ? void 0 : i.uri) === e.uri;
}
function ei(e, i) {
  _(e.querySelector("#music-msg"), i);
}
function Ci(e, i, s, t = "", c = "") {
  return `<button class="music-tr${Je(e) ? " playing" : ""}" data-act="${s}" data-uri="${r(e.uri)}"${t ? ` data-i="${r(t)}"` : ""}${c ? ` title="${r(c)}"` : ""}>
    <span class="music-tr-i">${i + 1}</span>
    <span class="music-tr-main">
      <span class="music-tr-n">${r(e.name || "?")}</span>
      <span class="music-tr-a">${r(e.artists || e.album)}</span>
    </span>
    <span class="music-tr-d">${xi(e.duration_ms)}</span>
  </button>`;
}
function Mi(e) {
  return { id: e.id, uri: e.uri, name: e.name, cover: e.cover, subtitle: e.owner, total: e.total };
}
function $i(e, i) {
  const s = !!i.uri && (l == null ? void 0 : l.context_uri) === i.uri, t = (p == null ? void 0 : p.kind) === e && p.id === i.id, c = i.cover ? `<img src="${r(i.cover)}" alt="">` : "";
  return `<div class="music-pl${s ? " playing" : ""}${t ? " on" : ""}" data-uri="${r(i.uri)}">
    <button class="music-pl-btn" data-act="open" data-kind="${e}" data-id="${r(i.id)}" title="${r(i.name || "?")}">
      <span class="music-pl-cover">${c}</span>
      <span class="music-pl-main">
        <span class="music-pl-name">${r(i.name || "?")}</span>
        <span class="music-pl-sub">${r(i.subtitle)}</span>
      </span>
    </button>
  </div>`;
}
function Ze(e, i) {
  const s = i.cover ? `<img src="${r(i.cover)}" alt="">` : "";
  return `<button class="music-card" data-act="open" data-kind="${e}" data-id="${r(i.id)}" title="${r(i.name)}">
    <span class="music-card-cover${e === "artist" ? " round" : ""}">${s}</span>
    <span class="music-card-n">${r(i.name)}</span>
    <span class="music-card-s">${r(i.subtitle)}</span>
  </button>`;
}
function Ke() {
  const e = (p == null ? void 0 : p.kind) === "liked", i = E ? String(E.total) : "", s = J || [(a == null ? void 0 : a.display_name) || "", i].filter(Boolean).join(" · ");
  return `<div class="music-pl music-pl-liked${e ? " on" : ""}${J ? " err" : ""}">
    <button class="music-pl-btn" data-act="open" data-kind="liked" data-id="liked" title="${r(n("music.liked_songs"))}">
      <span class="music-pl-cover music-pl-liked-cover">${b.heart}</span>
      <span class="music-pl-main">
        <span class="music-pl-name">${r(n("music.liked_songs"))}</span>
        <span class="music-pl-sub">${r(s)}</span>
      </span>
    </button>
  </div>`;
}
function ii(e) {
  e.querySelectorAll("#music-side-tabs .music-tab").forEach((o) => {
    o.classList.toggle("on", o.dataset.tab === D);
  });
  const i = e.querySelector("#music-side-list");
  if (!i) return;
  if (!(a != null && a.connected)) {
    $(i, `<div class="music-empty">${n("music.playlists_login")}</div>`);
    return;
  }
  const s = ui.get(D), t = hi.get(D);
  let c = D === "playlist" ? Ke() : "";
  mi.has(D) ? c += `<div class="music-empty">${n("music.loading")}</div>` : t ? c += `<div class="music-empty music-empty-err">${r(t)}</div>` : s && (c += s.length === 0 ? `<div class="music-empty">${n(D === "playlist" ? "music.playlists_empty" : "music.lib_empty")}</div>` : s.map((o) => $i(D, o)).join("")), $(i, c);
}
function Di(e) {
  e.querySelectorAll("#music-side-list .music-pl").forEach((i) => {
    const s = i.querySelector(".music-pl-btn"), t = !!p && (s == null ? void 0 : s.dataset.kind) === p.kind && (s == null ? void 0 : s.dataset.id) === p.id;
    i.classList.toggle("on", t);
  });
}
function I(e) {
  const i = e.querySelector("#music-main");
  if (!i) return;
  if (Q && N) {
    $(i, is());
    return;
  }
  if (!p) {
    $(i, `<div class="music-empty">${a != null && a.connected ? n("music.pick_hint") : n("music.playlists_login")}</div>`);
    return;
  }
  const s = p.cover ? `<img src="${r(p.cover)}" alt="">` : "", t = p.kind === "liked" ? n("music.liked_songs") : p.kind === "playlist" ? n("music.playlists") : p.kind === "album" ? n("music.tab_albums") : p.kind === "artist" ? n("music.tab_artists") : n("music.tab_shows");
  let c;
  ai ? c = `<div class="music-empty">${n("music.loading")}</div>` : z ? c = `<div class="music-empty music-empty-err">${r(z)}</div>` : !O || O.length === 0 ? c = `<div class="music-empty">${n("music.playlist_empty")}</div>` : c = O.map((o, v) => Ci(o, v, "main-track", String(v))).join(""), $(i, `<div class="music-page">
    <div class="music-page-head">
      <span class="music-page-cover${p.kind === "artist" ? " round" : ""}">${s}</span>
      <div class="music-page-info">
        <span class="music-page-kind">${r(t)}</span>
        <span class="music-page-name">${r(p.name || "?")}</span>
        <span class="music-page-sub">${r(p.subtitle)}</span>
        <div class="music-page-actions">
          <button class="music-btn music-primary" data-act="main-play-all">${b.play} ${n("music.play_all")}</button>
        </div>
      </div>
    </div>
    <div class="music-list">${c}</div>
  </div>`);
}
function is() {
  const e = k, s = [
    ["tracks", n("music.tracks")],
    ["artists", n("music.tab_artists")],
    ["albums", n("music.tab_albums")],
    ["playlists", n("music.playlists")],
    ["shows", n("music.tab_shows")]
  ].map(([c, o]) => `<button class="music-tab${W === c ? " on" : ""}" data-act="search-tab" data-tab="${c}">${r(o)}</button>`).join("");
  let t;
  if (li || !e)
    t = `<div class="music-empty">${n("music.loading")}</div>`;
  else if (W === "tracks")
    t = e.tracks.length ? e.tracks.map((c, o) => Ci(c, o, "main-track", String(o))).join("") : `<div class="music-empty">${n("music.search_empty")}</div>`;
  else {
    const o = (W === "artists" ? e.artists : W === "albums" ? e.albums : W === "shows" ? e.shows : e.playlists.map(Mi)).map((v) => Ze(W === "playlists" ? "playlist" : W === "artists" ? "artist" : W === "albums" ? "album" : "show", v));
    t = o.length ? `<div class="music-grid">${o.join("")}</div>` : `<div class="music-empty">${n("music.search_empty")}</div>`;
  }
  return `<div class="music-page">
    <div class="music-page-info music-page-info-flat">
      <span class="music-page-kind">${n("music.search_result")}</span>
      <span class="music-page-name">${r(N)}</span>
    </div>
    <div class="music-tabs">${s}</div>
    <div class="music-list">${t}</div>
  </div>`;
}
function j(e) {
  const i = e.querySelector("#music-search-dd");
  if (!i) return;
  const s = !!(a != null && a.connected) && P && !!N;
  if (L(i, s), !s) return;
  if (!k) {
    $(i, li ? `<div class="music-empty">${n("music.loading")}</div>` : "");
    return;
  }
  const t = k, c = [];
  t.tracks.slice(0, 3).forEach((o, v) => c.push(Ci(o, v, "dd-track"))), t.artists.slice(0, 2).forEach((o) => c.push($i("artist", o))), t.albums.slice(0, 2).forEach((o) => c.push($i("album", o))), t.playlists.slice(0, 2).forEach((o) => c.push($i("playlist", Mi(o)))), c.length || c.push(`<div class="music-empty">${n("music.search_empty")}</div>`), c.push(`<button class="music-dd-all" data-act="search-all">${n("music.search_all")}</button>`), $(i, c.join(""));
}
function ri(e) {
  const i = e.querySelector("#music-dev-dd");
  if (!i || (L(i, F), !F)) return;
  const s = H;
  let t = `<div class="music-dd-head">${n("music.devices")}</div>`;
  s != null && s.available ? t += `<button class="music-dev-row${s.running ? " on" : ""}" data-act="local-toggle">
      <span class="music-dev-ico">${b.power}</span>
      <span class="music-dev-main">
        <span class="music-dev-n">${n("music.local_play")}</span>
        <span class="music-dev-s">${r(s.path || "")}</span>
      </span>
    </button>` : t += `<div class="music-dev-row disabled">
      <span class="music-dev-ico">${b.power}</span>
      <span class="music-dev-main">
        <span class="music-dev-n">${n("music.local_play")}</span>
        <span class="music-dev-s">${n("music.local_no_exe")}</span>
      </span>
    </div>`;
  const c = K ?? [];
  t += c.length ? c.map((o) => `<button class="music-dev-row${o.active ? " on" : ""}" data-act="dev-pick" data-id="${r(o.id)}">
        <span class="music-dev-ico">${b.speaker}</span>
        <span class="music-dev-main">
          <span class="music-dev-n">${r(o.name || "?")}</span>
          <span class="music-dev-s">${r(o.kind)}</span>
        </span>
      </button>`).join("") : `<div class="music-empty">${n("music.device_none")}</div>`, $(i, t);
}
function es(e) {
  var t;
  const i = (l == null ? void 0 : l.context_uri) ?? "", s = ((t = l == null ? void 0 : l.track) == null ? void 0 : t.uri) ?? "";
  e.querySelectorAll(".music-pl").forEach((c) => {
    c.classList.toggle("playing", !!i && c.dataset.uri === i);
  }), e.querySelectorAll(".music-tr").forEach((c) => {
    c.classList.toggle("playing", !!s && c.dataset.uri === s);
  });
}
function de(e) {
  pi = Math.min(_e, Math.max(he, Math.round(pi))), e.style.setProperty("--music-side-w", `${pi}px`);
}
function $e(e, i) {
  var t;
  if (e === "liked")
    return { id: "liked", uri: "", name: n("music.liked_songs"), cover: "", subtitle: "", total: (E == null ? void 0 : E.total) ?? 0 };
  const s = e === "artist" ? k == null ? void 0 : k.artists : e === "album" ? k == null ? void 0 : k.albums : e === "show" ? k == null ? void 0 : k.shows : k == null ? void 0 : k.playlists.map(Mi);
  return ((t = ui.get(e)) == null ? void 0 : t.find((c) => c.id === i)) ?? (s == null ? void 0 : s.find((c) => c.id === i)) ?? null;
}
async function Se(e, i) {
  if (!(!(a != null && a.connected) || mi.has(i) || ui.has(i))) {
    mi.add(i), hi.delete(i), ii(e);
    try {
      const s = i === "playlist" ? (Wi = await m("spotify_playlists")).map(Mi) : await m(
        i === "album" ? "spotify_albums" : i === "artist" ? "spotify_artists" : "spotify_shows"
      );
      ui.set(i, s);
    } catch (s) {
      hi.set(i, w(s));
    } finally {
      mi.delete(i), ii(e);
    }
  }
}
async function ss(e, i, s) {
  const t = $e(i, s);
  if (t) {
    if (Q = !1, P = !1, p = { kind: i, id: t.id, uri: t.uri, name: t.name, cover: t.cover, subtitle: t.subtitle }, O = null, z = "", i === "liked") {
      O = (E == null ? void 0 : E.items) ?? null, z = J, ai = !E, j(e), Di(e), I(e), E || await Ee(e);
      return;
    }
    ai = !0, j(e), Di(e), I(e);
    try {
      O = await m("spotify_item_tracks", { kind: i, id: t.id });
    } catch (c) {
      z = w(c);
    } finally {
      ai = !1, Di(e), I(e);
    }
  }
}
async function me(e, i, s, t = 0) {
  const c = $e(i, s);
  if (c)
    try {
      if (i === "liked" || i === "show") {
        const o = (i === "liked" ? E == null ? void 0 : E.items : O) ?? [];
        if (!o.length) return;
        await m("spotify_play_uris", { uris: o.slice(Math.max(0, t)).map((v) => v.uri) });
      } else if (c.uri)
        await m("spotify_play_context", { contextUri: c.uri, offsetUri: "" });
      else
        return;
    } catch (o) {
      ei(e, w(o));
    }
}
async function ts(e, i) {
  if (!p) return;
  const s = O ?? [], t = s[i];
  if (t)
    try {
      p.kind === "liked" || p.kind === "show" ? await m("spotify_play_uris", { uris: s.slice(i).map((c) => c.uri) }) : await m("spotify_play_context", { contextUri: p.uri, offsetUri: t.uri });
    } catch (c) {
      ei(e, w(c));
    }
}
async function zi(e) {
  try {
    K = await m("spotify_devices");
  } catch (i) {
    K = [], ei(e, w(i));
  }
  try {
    H = await m("librespot_status");
  } catch {
    H = null;
  }
  ri(e);
}
async function ns(e) {
  if (!(H != null && H.available)) return;
  const i = H.running;
  try {
    H = await m(i ? "librespot_stop" : "librespot_start");
  } catch (s) {
    ei(e, w(s));
    return;
  }
  if (ri(e), i) {
    K = await m("spotify_devices").catch(() => []), ri(e);
    return;
  }
  for (let s = 0; s < 6; s++) {
    await new Promise((t) => window.setTimeout(t, 1500));
    try {
      const t = await m("spotify_devices");
      K = t;
      const c = t.find((o) => o.name === "Lunac");
      if (c && !c.active && await m("spotify_transfer", { deviceId: c.id, play: !0 }), c) break;
    } catch {
    }
  }
  await zi(e);
}
async function cs(e, i) {
  if (i) {
    try {
      await m("spotify_transfer", { deviceId: i, play: !1 }), F = !1;
    } catch (s) {
      ei(e, w(s));
    }
    await zi(e);
  }
}
async function Ee(e) {
  if (!(!(a != null && a.connected) || Ai || E)) {
    Ai = !0, J = "", ii(e);
    try {
      E = await m("spotify_liked");
    } catch (i) {
      J = w(i);
    } finally {
      Ai = !1, (p == null ? void 0 : p.kind) === "liked" && (O = (E == null ? void 0 : E.items) ?? null, ai = !1, z = J), ii(e), I(e);
    }
  }
}
function pe(e, i) {
  if (N = i, P = !!i, di !== void 0 && (window.clearTimeout(di), di = void 0), !i) {
    k = null, li = !1, Q = !1, j(e), I(e);
    return;
  }
  li = !0, j(e), I(e), di = window.setTimeout(() => void as(e, i), He);
}
async function as(e, i) {
  di = void 0;
  try {
    const s = await m("spotify_search", { query: i });
    if (N !== i) return;
    k = s;
  } catch (s) {
    if (N !== i) return;
    k = null, ei(e, w(s));
  } finally {
    N === i && (li = !1, j(e), I(e));
  }
}
function Si(e) {
  const i = (G == null ? void 0 : G.items) ?? [], s = n("music.play_from_here"), t = i.length === 0 ? `<div class="music-empty">${n(G ? "music.queue_empty" : "music.loading")}</div>` : i.map((c, o) => Ci(c, o, "play-uri", "", s)).join("");
  for (const c of ["#music-q", "#music-q-dd"]) $(e.querySelector(c), t);
}
async function xe(e) {
  var i;
  try {
    G = await m("spotify_queue"), ge = ((i = l == null ? void 0 : l.track) == null ? void 0 : i.id) ?? "";
  } catch (s) {
    G = null, _(e.querySelector("#music-msg"), w(s));
  }
  Si(e);
}
function Fi(e) {
  const i = (l == null ? void 0 : l.track) ?? null, s = i != null && i.cover ? `<img src="${r(i.cover)}" alt="">` : "", t = [i == null ? void 0 : i.artists, i == null ? void 0 : i.album].filter(Boolean).join(" · ") || (l != null && l.active ? "" : n("music.no_device_hint"));
  $(e.querySelector("#music-pv-cover"), s), $(e.querySelector("#music-bnow-cover"), s), _(e.querySelector("#music-pv-title"), (i == null ? void 0 : i.name) || n("music.no_track")), _(e.querySelector("#music-bnow-n"), (i == null ? void 0 : i.name) || n("music.no_track")), _(e.querySelector("#music-pv-sub"), t), _(e.querySelector("#music-bnow-a"), t);
  const c = (i == null ? void 0 : i.duration_ms) ?? 0, o = Math.min((l == null ? void 0 : l.progress_ms) ?? 0, c || Number.MAX_SAFE_INTEGER), v = c > 0 ? Math.max(0, Math.min(100, o / c * 100)) : 0;
  if (si < 0)
    for (const y of ni) y.style.setProperty("--seek-pct", `${v}%`);
  _(e.querySelector("#music-pv-pos"), xi(o)), _(e.querySelector("#music-pv-dur"), xi(c));
  const T = l != null && l.playing ? b.pause : b.play;
  $(e.querySelector("#music-play"), T), $(e.querySelector("#music-b-play"), T);
  const g = qe(), A = n(g === "shuffle" ? "music.mode_shuffle" : g === "repeat_one" ? "music.mode_repeat_one" : "music.mode_off");
  for (const y of [e.querySelector("#music-mode"), e.querySelector("#music-b-mode")])
    y && (Ui(y, "data-mode", g), Ui(y, "title", A), $(y, g === "repeat_one" ? b.repeat : b.shuffle));
  const x = l && l.volume_percent >= 0 ? String(l.volume_percent) : "";
  for (const y of [e.querySelector("#music-vol"), e.querySelector("#music-b-vol")])
    y && x && document.activeElement !== y && (y.value = x);
  const Gi = !(l != null && l.active);
  e.querySelectorAll(".music-bar button, .music-nowbar button").forEach((y) => {
    y.id === "music-devices-btn" || y.id === "music-open-player" || y.id === "music-bnow" || (y.disabled = Gi);
  });
}
function qe() {
  return (l == null ? void 0 : l.repeat) === "track" ? "repeat_one" : l != null && l.shuffle ? "shuffle" : "off";
}
function Ni(e) {
  var i, s;
  L(e.querySelector("#music-q-wrap"), R), L(e.querySelector("#music-q-dd"), R), (i = e.querySelector("#music-queue-btn")) == null || i.classList.toggle("on", R), (s = e.querySelector("#music-b-queue")) == null || s.classList.toggle("on", R);
}
function Li(e) {
  const i = e.querySelector("#music-lyr");
  if (!i) return;
  if (Vi(), Y = -1, ci = [], oi && (oi = !1, U !== void 0 && (window.clearTimeout(U), U = void 0)), Bi) {
    $(i, `<div class="music-empty">${n("music.lyrics_loading")}</div>`);
    return;
  }
  if (C != null && C.synced) {
    const t = Fe(C.synced);
    if (t.length > 0) {
      ci = t;
      const c = r(n("music.seek_line"));
      $(
        i,
        `<div class="music-lyr-lines">${t.map((o, v) => `<div class="music-lyr-line" data-i="${v}" title="${c}">${r(o.text)}</div>`).join("")}</div>`
      );
      return;
    }
  }
  const s = ((C == null ? void 0 : C.plain) || "").trim();
  if (s) {
    $(i, `<div class="music-lyr-plain">${r(s)}</div>`);
    return;
  }
  if (C != null && C.instrumental) {
    $(i, `<div class="music-empty">${n("music.lyrics_instrumental")}</div>`);
    return;
  }
  $(i, `<div class="music-empty">${n("music.lyrics_none")}</div>`);
}
function Vi() {
  yi && (cancelAnimationFrame(yi), yi = 0);
}
function ve(e, i) {
  Vi();
  const s = e.scrollTop, t = i - s;
  if (Math.abs(t) < 1) {
    e.scrollTop = i;
    return;
  }
  let c = 0;
  const o = (v) => {
    c || (c = v);
    const T = Math.min(1, (v - c) / Ue);
    e.scrollTop = s + t * (1 - Math.pow(1 - T, 5)), yi = T < 1 ? requestAnimationFrame(o) : 0;
  };
  yi = requestAnimationFrame(o);
}
function Ri(e) {
  var g, A;
  if (ci.length === 0) return;
  const i = e.querySelector("#music-lyr");
  if (!i || !i.isConnected || i.clientHeight === 0) return;
  const s = ((l == null ? void 0 : l.progress_ms) ?? 0) / 1e3;
  let t = -1;
  for (let x = 0; x < ci.length && ci[x].at <= s; x++)
    t = x;
  if (t === Y) return;
  const c = Math.min(Y, t), o = Math.max(Y, t);
  for (let x = Math.max(0, c + 1); x <= o; x++)
    (g = i.querySelector(`.music-lyr-line[data-i="${x}"]`)) == null || g.classList.toggle("done", x <= t);
  (A = i.querySelector(".music-lyr-line.on")) == null || A.classList.remove("on"), Y = t;
  const v = i.querySelector(`.music-lyr-line[data-i="${t}"]`);
  if (!v) {
    oi || ve(i, 0);
    return;
  }
  if (v.classList.add("on"), oi) return;
  const T = v.getBoundingClientRect().top - i.getBoundingClientRect().top + i.scrollTop;
  ve(i, Math.max(0, T));
}
function fe(e) {
  oi = !0, Vi(), U !== void 0 && window.clearTimeout(U), U = window.setTimeout(() => {
    U = void 0, oi = !1, Y = -1, Ri(e);
  }, Pe);
}
async function Ei(e) {
  try {
    a = await m("music_config_get");
  } catch (i) {
    _(e.querySelector("#music-msg"), w(i));
    return;
  }
  !a.connected && M === "player" && (M = "default", V(e)), ji(e), qi(e);
}
async function ls(e) {
  if (Oi === e.id) return;
  Oi = e.id, Bi = !0, C = null;
  const i = we;
  i && Li(i);
  try {
    C = await m("lyrics_get", {
      title: e.name,
      artist: e.artists,
      album: e.album,
      duration: e.duration_ms / 1e3
    });
  } catch (s) {
    C = { found: !1, instrumental: !1, track: "", artist: "", album: "", duration: 0, synced: null, plain: null }, i && _(i.querySelector("#music-msg"), w(s));
  } finally {
    Bi = !1, i && (Li(i), Ri(i));
  }
}
async function Le(e, i) {
  if (i === ti) {
    if (!e.isConnected) {
      Yi();
      return;
    }
    if (Ve(e), a != null && a.connected) {
      if (!document.hidden && !gi) {
        gi = !0;
        try {
          if (l = await m("spotify_status"), i !== ti) return;
          qi(e), Fi(e), Ri(e), es(e), ke(e), bi(e);
        } catch (s) {
          if (i !== ti) return;
          String(s).includes("ERR_NOT_CONNECTED") ? await Ei(e) : _(e.querySelector("#music-msg"), w(s));
        } finally {
          gi = !1;
        }
      }
      l != null && l.track && ls(l.track), R && (l != null && l.track) && l.track.id !== ge && xe(e);
    }
    i === ti && (fi = window.setTimeout(() => void Le(e, i), 1e3));
  }
}
function Yi() {
  fi !== void 0 && (window.clearTimeout(fi), fi = void 0), ti++, gi = !1;
}
function ye(e) {
  Yi();
  const i = ti;
  fi = window.setTimeout(() => void Le(e, i), 200);
}
function bi(e) {
  document.getElementById("plugin-titlebar") && (Z !== void 0 && window.clearTimeout(Z), Z = window.setTimeout(() => void us(e), 80));
}
async function us(e) {
  if (Z = void 0, !document.getElementById("plugin-titlebar")) return;
  let i = Ne, s = Oe;
  if (M === "player") {
    const c = e.closest(".plugin-result"), o = c == null ? void 0 : c.closest("#results-list");
    if (!c || !o) return;
    const v = getComputedStyle(o), T = parseFloat(v.paddingTop || "0") + parseFloat(v.paddingBottom || "0"), g = window.innerHeight - o.clientHeight;
    s = Math.round(g + T + c.getBoundingClientRect().height), i = Be;
  }
  const t = `${i}x${s}`;
  if (t !== Hi)
    try {
      await m("plugin_window_resize", { width: i, height: s }), Hi = t;
    } catch {
    }
}
async function rs(e) {
  var Xi, Ji, Zi, Ki, ie, ee, se, te, ne, ce, ae, le, ue, oe;
  const i = e.querySelector(".music-root");
  if (!i) return;
  we = i, M = "default", _i = null, R = !1, Hi = "", Pi = null, wi = "", ki = 0, E = null, J = "", Wi = null, ui.clear(), mi.clear(), hi.clear(), D = "playlist", p = null, O = null, ai = !1, z = "", K = null, F = !1, H = null, N = "", k = null, li = !1, P = !1, Q = !1, W = "tracks", ni = [];
  const s = (u) => _(i.querySelector("#music-msg"), u), t = (u) => i.querySelector(u);
  X && (X(), X = null), X = await Te("spotify-auth", (u) => {
    i.isConnected && (u.payload.ok ? (s(n("music.auth_ok")), Ei(i).then(() => {
      ye(i);
    })) : s(u.payload.message || n("music.auth_failed")));
  });
  const c = () => {
    M = "player", V(i);
  }, o = () => {
    M = "default", V(i);
  };
  (Xi = t("#music-setup-toggle")) == null || Xi.addEventListener("click", () => {
    M = "default", V(i);
    const u = t("#music-setup");
    u && u.classList.toggle("hidden");
  }), (Ji = t("#music-open-player")) == null || Ji.addEventListener("click", c), (Zi = t("#music-bnow")) == null || Zi.addEventListener("click", c), (Ki = t("#music-back")) == null || Ki.addEventListener("click", o);
  const v = (u) => {
    var d;
    !i.isConnected || M !== "player" || (d = u.target) != null && d.closest("#plugin-close") && (u.stopPropagation(), u.preventDefault(), Xe(i));
  };
  document.addEventListener("click", v, !0), (ie = t("#music-fields-toggle")) == null || ie.addEventListener("click", () => {
    _i = !(_i ?? !(a != null && a.builtin)), ji(i);
  }), (ee = t("#music-copy-redirect")) == null || ee.addEventListener("click", () => {
    const u = (a == null ? void 0 : a.redirect_uri) || "";
    u && De(u).then(() => s(n("music.copied"))).catch(() => {
    });
  }), (se = t("#music-save")) == null || se.addEventListener("click", async () => {
    var S, f, q, B;
    const u = ((S = t("#music-client-id")) == null ? void 0 : S.value.trim()) ?? "", d = ((f = t("#music-port")) == null ? void 0 : f.value.trim()) ?? "", h = Number(d);
    if (!u) {
      s(n("music.err_no_client_id"));
      return;
    }
    if (!Number.isInteger(h) || h < 1024 || h > 65535) {
      s(n("music.err_bad_port"));
      return;
    }
    try {
      a = await m("music_config_set", {
        clientId: u,
        port: h,
        // 本机播放那两项**一起交上去**（留空 = 自动探测 / 直连，都是合法值）
        librespotPath: ((q = t("#music-librespot")) == null ? void 0 : q.value.trim()) ?? "",
        librespotProxy: ((B = t("#music-librespot-proxy")) == null ? void 0 : B.value.trim()) ?? ""
      }), s(n("music.saved")), ji(i), qi(i), H = null;
    } catch (Ti) {
      s(w(Ti));
    }
  }), (te = t("#music-connect")) == null || te.addEventListener("click", async () => {
    var h, S;
    const u = ((h = t("#music-client-id")) == null ? void 0 : h.value.trim()) ?? "", d = Number(((S = t("#music-port")) == null ? void 0 : S.value.trim()) ?? "");
    if (u && Number.isInteger(d) && d >= 1024)
      try {
        a = await m("music_config_set", {
          clientId: u,
          port: d,
          librespotPath: null,
          librespotProxy: null
        });
      } catch (f) {
        s(w(f));
        return;
      }
    try {
      const f = await m("spotify_connect");
      s(n("music.browser_hint")), await Ae(f);
    } catch (f) {
      s(w(f));
    }
  }), (ne = t("#music-disconnect")) == null || ne.addEventListener("click", async () => {
    try {
      await m("spotify_disconnect"), l = null, C = null, Oi = "", Wi = null, ui.clear(), hi.clear(), G = null, R = !1, p = null, O = null, z = "", k = null, N = "", P = !1, Q = !1, K = null, M = "default", await Ei(i), V(i), Si(i), s(n("music.disconnected"));
    } catch (u) {
      s(w(u));
    }
  });
  const T = (u) => {
    var f;
    const d = (f = u.target) == null ? void 0 : f.closest("[data-act]");
    if (!d) return;
    const h = d.dataset.kind || "", S = d.dataset.id || "";
    switch (d.dataset.act) {
      case "side-tab":
        D = d.dataset.tab || "playlist", ii(i), Se(i, D);
        break;
      case "search-tab":
        W = d.dataset.tab || "tracks", I(i);
        break;
      case "open":
        ss(i, h, S);
        break;
      case "main-track":
        ts(i, Number(d.dataset.i || "0"));
        break;
      case "main-play-all":
        p && me(i, p.kind, p.id);
        break;
      case "dd-track":
        d.dataset.uri && be(i, d.dataset.uri);
        break;
      case "play-uri":
        d.dataset.uri && be(i, d.dataset.uri);
        break;
      case "search-all":
        P = !1, Q = !0, j(i), I(i);
        break;
      case "dev-pick":
        cs(i, S);
        break;
      case "local-toggle":
        ns(i);
        break;
    }
  };
  for (const u of ["#music-side-list", "#music-side-tabs", "#music-main", "#music-search-dd", "#music-dev-dd", "#music-q", "#music-q-dd"])
    (ce = t(u)) == null || ce.addEventListener("click", T);
  (ae = t("#music-side-list")) == null || ae.addEventListener("dblclick", (u) => {
    var f;
    const d = (f = u.target) == null ? void 0 : f.closest('[data-act="open"]');
    if (!d) return;
    const h = d.dataset.kind || "", S = d.dataset.id || "";
    S && me(i, h, S);
  }), (le = t("#music-devices-btn")) == null || le.addEventListener("click", () => {
    F = !F, ri(i), F && zi(i);
  }), de(i), (ue = t("#music-split")) == null || ue.addEventListener("pointerdown", (u) => {
    var q;
    u.preventDefault();
    const d = u.clientX, h = ((q = t("#music-side")) == null ? void 0 : q.getBoundingClientRect().width) ?? pi, S = (B) => {
      pi = Math.min(_e, Math.max(he, Math.round(h + B.clientX - d))), de(i);
    }, f = () => {
      window.removeEventListener("pointermove", S), window.removeEventListener("pointerup", f), document.body.classList.remove("music-resizing");
    };
    document.body.classList.add("music-resizing"), window.addEventListener("pointermove", S), window.addEventListener("pointerup", f);
  }), document.addEventListener("pointerdown", (u) => {
    const d = u.target;
    d && (F && !d.closest("#music-dev-dd") && !d.closest("#music-devices-btn") && (F = !1, ri(i)), P && !d.closest(".music-search-wrap") && (P = !1, j(i)), R && !d.closest("#music-q-dd") && !d.closest("#music-b-queue") && !d.closest("#music-queue-btn") && (R = !1, Ni(i)));
  });
  const g = t("#music-search");
  g == null || g.addEventListener("input", () => pe(i, g.value.trim())), g == null || g.addEventListener("focus", () => {
    N && (P = !0, j(i));
  }), g == null || g.addEventListener("keydown", (u) => {
    if (u.key === "Enter" && N) {
      P = !1, Q = !0, j(i), I(i);
      return;
    }
    u.key === "Escape" && (g.value = "", pe(i, ""));
  }), document.body.addEventListener("mouseenter", () => bi(i)), document.body.addEventListener("mouseleave", () => bi(i));
  const A = async (u, d) => {
    try {
      await m("spotify_control", { action: u, value: d });
    } catch (h) {
      s(w(h));
    }
  }, x = (u, d) => {
    var h;
    for (const S of u) (h = t(`#${S}`)) == null || h.addEventListener("click", d);
  };
  x(["music-queue-btn", "music-b-queue"], () => {
    R = !R, Ni(i), Si(i), R ? xe(i) : Fi(i), bi(i);
  }), x(["music-prev", "music-b-prev"], () => void A("previous")), x(["music-next", "music-b-next"], () => void A("next")), x(["music-play", "music-b-play"], () => void A(l != null && l.playing ? "pause" : "play"));
  for (const u of ["music-vol", "music-b-vol"])
    (oe = t(`#${u}`)) == null || oe.addEventListener("change", (d) => {
      A("volume", Number(d.target.value));
    });
  x(["music-mode", "music-b-mode"], () => {
    const u = qe();
    m("spotify_set_play_mode", { mode: u === "off" ? "shuffle" : u === "shuffle" ? "repeat_one" : "off" }).catch((h) => s(w(h)));
  }), ni = ["#music-pv-progress", "#music-bp"].map((u) => t(u)).filter((u) => !!u);
  for (const u of ni) {
    const d = (f) => {
      const q = u.getBoundingClientRect();
      return Math.max(0, Math.min(1, (f - q.left) / Math.max(1, q.width)));
    }, h = (f) => {
      var B;
      si = f;
      const q = `${f * 100}%`;
      for (const Ti of ni) Ti.style.setProperty("--seek-pct", q);
      _(u.querySelector(".music-progress-tip"), xi((((B = l == null ? void 0 : l.track) == null ? void 0 : B.duration_ms) ?? 0) * f));
    };
    u.addEventListener("pointerdown", (f) => {
      var q;
      if (!((((q = l == null ? void 0 : l.track) == null ? void 0 : q.duration_ms) ?? 0) <= 0)) {
        try {
          u.setPointerCapture(f.pointerId);
        } catch {
        }
        u.classList.add("music-dragging"), h(d(f.clientX));
      }
    }), u.addEventListener("pointermove", (f) => {
      si < 0 || h(d(f.clientX));
    });
    const S = (f) => {
      var B;
      if (si < 0) return;
      const q = si;
      si = -1, u.classList.remove("music-dragging");
      try {
        u.releasePointerCapture(f.pointerId);
      } catch {
      }
      A("seek", Math.round((((B = l == null ? void 0 : l.track) == null ? void 0 : B.duration_ms) ?? 0) * q));
    };
    u.addEventListener("pointerup", S), u.addEventListener("pointercancel", S);
  }
  const y = t("#music-lyr");
  let Ii = !1, Qi = 0;
  y == null || y.addEventListener("wheel", () => fe(i), { passive: !0 }), y == null || y.addEventListener("pointerdown", (u) => {
    Ii = !1, Qi = u.clientY, fe(i);
  }), y == null || y.addEventListener("pointermove", (u) => {
    Math.abs(u.clientY - Qi) > 4 && (Ii = !0);
  }), y == null || y.addEventListener("click", (u) => {
    if (Ii) return;
    const d = u.target.closest(".music-lyr-line"), h = d ? ci[Number(d.dataset.i)] : void 0;
    h && A("seek", Math.round(h.at * 1e3));
  }), await Ei(i), V(i), Fi(i), Li(i), Si(i), Ni(i), qi(i), ye(i);
}
async function be(e, i) {
  try {
    await m("spotify_play_uri", { uri: i });
  } catch (s) {
    _(e.querySelector("#music-msg"), w(s));
  }
}
function os() {
  Yi(), U !== void 0 && (window.clearTimeout(U), U = void 0), Z !== void 0 && (window.clearTimeout(Z), Z = void 0), X && (X(), X = null), ni = [], Qe();
}
window.__lunac_music_stop = os;
const ds = {
  id: "music",
  name: "音乐歌词",
  keywords: ["音乐", "歌词", "歌曲", "正在播放", "music", "lyrics", "spotify", "播放控制", "暂停", "下一首", "歌单", "播放列表"],
  description: "歌词自动抓取 (LRCLIB + 网易云兜底) + Spotify 播放控制 / 歌单 / 队列",
  icon: "🎵",
  badge: "music",
  async execute() {
    return { type: "html", content: ze() };
  }
};
export {
  rs as attach,
  rs as attachMusicListeners,
  ds as default,
  os as detach,
  ds as musicPlugin,
  os as stopMusicPolling
};
