function Za(e, t, n, a) {
  if (typeof t == "function" ? e !== t || !a : !t.has(e)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return n === "m" ? a : n === "a" ? a.call(e) : a ? a.value : t.get(e);
}
function Qa(e, t, n, a, o) {
  if (typeof t == "function" ? e !== t || !0 : !t.has(e)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return t.set(e, n), n;
}
var Re;
const ft = "__TAURI_TO_IPC_KEY__";
function ti(e, t = !1) {
  return window.__TAURI_INTERNALS__.transformCallback(e, t);
}
async function d(e, t = {}, n) {
  return window.__TAURI_INTERNALS__.invoke(e, t, n);
}
function Ft(e, t = "asset") {
  return window.__TAURI_INTERNALS__.convertFileSrc(e, t);
}
class ei {
  get rid() {
    return Za(this, Re, "f");
  }
  constructor(t) {
    Re.set(this, void 0), Qa(this, Re, t);
  }
  /**
   * Destroys and cleans up this resource from memory.
   * **You should not call any method on this object anymore and should drop any reference to it.**
   */
  async close() {
    return d("plugin:resources|close", {
      rid: this.rid
    });
  }
}
Re = /* @__PURE__ */ new WeakMap();
var ct;
(function(e) {
  e.WINDOW_RESIZED = "tauri://resize", e.WINDOW_MOVED = "tauri://move", e.WINDOW_CLOSE_REQUESTED = "tauri://close-requested", e.WINDOW_DESTROYED = "tauri://destroyed", e.WINDOW_FOCUS = "tauri://focus", e.WINDOW_BLUR = "tauri://blur", e.WINDOW_SCALE_FACTOR_CHANGED = "tauri://scale-change", e.WINDOW_THEME_CHANGED = "tauri://theme-changed", e.WINDOW_CREATED = "tauri://window-created", e.WINDOW_SUSPENDED = "tauri://suspended", e.WINDOW_RESUMED = "tauri://resumed", e.WEBVIEW_CREATED = "tauri://webview-created", e.DRAG_ENTER = "tauri://drag-enter", e.DRAG_OVER = "tauri://drag-over", e.DRAG_DROP = "tauri://drag-drop", e.DRAG_LEAVE = "tauri://drag-leave";
})(ct || (ct = {}));
async function oa(e, t) {
  window.__TAURI_EVENT_PLUGIN_INTERNALS__.unregisterListener(e, t), await d("plugin:event|unlisten", {
    event: e,
    eventId: t
  });
}
async function pt(e, t, n) {
  var a;
  const o = typeof (n == null ? void 0 : n.target) == "string" ? { kind: "AnyLabel", label: n.target } : (a = n == null ? void 0 : n.target) !== null && a !== void 0 ? a : { kind: "Any" };
  return d("plugin:event|listen", {
    event: e,
    target: o,
    handler: ti(t)
  }).then((c) => async () => oa(e, c));
}
async function ni(e, t, n) {
  return pt(e, (a) => {
    oa(e, a.id), t(a);
  }, n);
}
async function G(e, t) {
  await d("plugin:event|emit", {
    event: e,
    payload: t
  });
}
async function ai(e, t, n) {
  await d("plugin:event|emit_to", {
    target: typeof e == "string" ? { kind: "AnyLabel", label: e } : e,
    event: t,
    payload: n
  });
}
class sa {
  constructor(...t) {
    this.type = "Logical", t.length === 1 ? "Logical" in t[0] ? (this.width = t[0].Logical.width, this.height = t[0].Logical.height) : (this.width = t[0].width, this.height = t[0].height) : (this.width = t[0], this.height = t[1]);
  }
  /**
   * Converts the logical size to a physical one.
   * @example
   * ```typescript
   * import { LogicalSize } from '@tauri-apps/api/dpi';
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   *
   * const appWindow = getCurrentWindow();
   * const factor = await appWindow.scaleFactor();
   * const size = new LogicalSize(400, 500);
   * const physical = size.toPhysical(factor);
   * ```
   *
   * @since 2.0.0
   */
  toPhysical(t) {
    return new xe(this.width * t, this.height * t);
  }
  [ft]() {
    return {
      width: this.width,
      height: this.height
    };
  }
  toJSON() {
    return this[ft]();
  }
}
class xe {
  constructor(...t) {
    this.type = "Physical", t.length === 1 ? "Physical" in t[0] ? (this.width = t[0].Physical.width, this.height = t[0].Physical.height) : (this.width = t[0].width, this.height = t[0].height) : (this.width = t[0], this.height = t[1]);
  }
  /**
   * Converts the physical size to a logical one.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const appWindow = getCurrentWindow();
   * const factor = await appWindow.scaleFactor();
   * const size = await appWindow.innerSize(); // PhysicalSize
   * const logical = size.toLogical(factor);
   * ```
   */
  toLogical(t) {
    return new sa(this.width / t, this.height / t);
  }
  [ft]() {
    return {
      width: this.width,
      height: this.height
    };
  }
  toJSON() {
    return this[ft]();
  }
}
class ie {
  constructor(t) {
    this.size = t;
  }
  toLogical(t) {
    return this.size instanceof sa ? this.size : this.size.toLogical(t);
  }
  toPhysical(t) {
    return this.size instanceof xe ? this.size : this.size.toPhysical(t);
  }
  [ft]() {
    return {
      [`${this.size.type}`]: {
        width: this.size.width,
        height: this.size.height
      }
    };
  }
  toJSON() {
    return this[ft]();
  }
}
class la {
  constructor(...t) {
    this.type = "Logical", t.length === 1 ? "Logical" in t[0] ? (this.x = t[0].Logical.x, this.y = t[0].Logical.y) : (this.x = t[0].x, this.y = t[0].y) : (this.x = t[0], this.y = t[1]);
  }
  /**
   * Converts the logical position to a physical one.
   * @example
   * ```typescript
   * import { LogicalPosition } from '@tauri-apps/api/dpi';
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   *
   * const appWindow = getCurrentWindow();
   * const factor = await appWindow.scaleFactor();
   * const position = new LogicalPosition(400, 500);
   * const physical = position.toPhysical(factor);
   * ```
   *
   * @since 2.0.0
   */
  toPhysical(t) {
    return new Nt(this.x * t, this.y * t);
  }
  [ft]() {
    return {
      x: this.x,
      y: this.y
    };
  }
  toJSON() {
    return this[ft]();
  }
}
class Nt {
  constructor(...t) {
    this.type = "Physical", t.length === 1 ? "Physical" in t[0] ? (this.x = t[0].Physical.x, this.y = t[0].Physical.y) : (this.x = t[0].x, this.y = t[0].y) : (this.x = t[0], this.y = t[1]);
  }
  /**
   * Converts the physical position to a logical one.
   * @example
   * ```typescript
   * import { PhysicalPosition } from '@tauri-apps/api/dpi';
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   *
   * const appWindow = getCurrentWindow();
   * const factor = await appWindow.scaleFactor();
   * const position = new PhysicalPosition(400, 500);
   * const physical = position.toLogical(factor);
   * ```
   *
   * @since 2.0.0
   */
  toLogical(t) {
    return new la(this.x / t, this.y / t);
  }
  [ft]() {
    return {
      x: this.x,
      y: this.y
    };
  }
  toJSON() {
    return this[ft]();
  }
}
class Ie {
  constructor(t) {
    this.position = t;
  }
  toLogical(t) {
    return this.position instanceof la ? this.position : this.position.toLogical(t);
  }
  toPhysical(t) {
    return this.position instanceof Nt ? this.position : this.position.toPhysical(t);
  }
  [ft]() {
    return {
      [`${this.position.type}`]: {
        x: this.position.x,
        y: this.position.y
      }
    };
  }
  toJSON() {
    return this[ft]();
  }
}
class _e extends ei {
  /**
   * Creates an Image from a resource ID. For internal use only.
   *
   * @ignore
   */
  constructor(t) {
    super(t);
  }
  /** Creates a new Image using RGBA data, in row-major order from top to bottom, and with specified width and height. */
  static async new(t, n, a) {
    return d("plugin:image|new", {
      rgba: je(t),
      width: n,
      height: a
    }).then((o) => new _e(o));
  }
  /**
   * Creates a new image using the provided bytes by inferring the file format.
   * If the format is known, prefer [@link Image.fromPngBytes] or [@link Image.fromIcoBytes].
   *
   * Only `ico` and `png` are supported (based on activated feature flag).
   *
   * Note that you need the `image-ico` or `image-png` Cargo features to use this API.
   * To enable it, change your Cargo.toml file:
   * ```toml
   * [dependencies]
   * tauri = { version = "...", features = ["...", "image-png"] }
   * ```
   */
  static async fromBytes(t) {
    return d("plugin:image|from_bytes", {
      bytes: je(t)
    }).then((n) => new _e(n));
  }
  /**
   * Creates a new image using the provided path.
   *
   * Only `ico` and `png` are supported (based on activated feature flag).
   *
   * Note that you need the `image-ico` or `image-png` Cargo features to use this API.
   * To enable it, change your Cargo.toml file:
   * ```toml
   * [dependencies]
   * tauri = { version = "...", features = ["...", "image-png"] }
   * ```
   */
  static async fromPath(t) {
    return d("plugin:image|from_path", { path: t }).then((n) => new _e(n));
  }
  /** Returns the RGBA data for this image, in row-major order from top to bottom.  */
  async rgba() {
    return d("plugin:image|rgba", {
      rid: this.rid
    }).then((t) => new Uint8Array(t));
  }
  /** Returns the size of this image.  */
  async size() {
    return d("plugin:image|size", { rid: this.rid });
  }
}
function je(e) {
  return e == null ? null : typeof e == "string" ? e : e instanceof _e ? e.rid : e;
}
var bn;
(function(e) {
  e[e.Critical = 1] = "Critical", e[e.Informational = 2] = "Informational";
})(bn || (bn = {}));
class ii {
  constructor(t) {
    this._preventDefault = !1, this.event = t.event, this.id = t.id;
  }
  preventDefault() {
    this._preventDefault = !0;
  }
  isPreventDefault() {
    return this._preventDefault;
  }
}
var zn;
(function(e) {
  e.None = "none", e.Normal = "normal", e.Indeterminate = "indeterminate", e.Paused = "paused", e.Error = "error";
})(zn || (zn = {}));
function It() {
  return new ca(window.__TAURI_INTERNALS__.metadata.currentWindow.label, {
    // @ts-expect-error `skip` is not defined in the public API but it is handled by the constructor
    skip: !0
  });
}
async function sn() {
  return d("plugin:window|get_all_windows").then((e) => e.map((t) => new ca(t, {
    // @ts-expect-error `skip` is not defined in the public API but it is handled by the constructor
    skip: !0
  })));
}
const ln = ["tauri://created", "tauri://error"];
class ca {
  /**
   * Creates a new Window.
   * @example
   * ```typescript
   * import { Window } from '@tauri-apps/api/window';
   * const appWindow = new Window('my-label');
   * appWindow.once('tauri://created', function () {
   *  // window successfully created
   * });
   * appWindow.once('tauri://error', function (e) {
   *  // an error happened creating the window
   * });
   * ```
   *
   * @param label The unique window label. Must be alphanumeric: `a-zA-Z-/:_`.
   * @returns The {@link Window} instance to communicate with the window.
   */
  constructor(t, n = {}) {
    var a;
    this.label = t, this.listeners = /* @__PURE__ */ Object.create(null), n != null && n.skip || d("plugin:window|create", {
      options: {
        ...n,
        parent: typeof n.parent == "string" ? n.parent : (a = n.parent) === null || a === void 0 ? void 0 : a.label,
        label: t
      }
    }).then(async () => this.emit("tauri://created")).catch(async (o) => this.emit("tauri://error", o));
  }
  /**
   * Gets the Window associated with the given label.
   * @example
   * ```typescript
   * import { Window } from '@tauri-apps/api/window';
   * const mainWindow = Window.getByLabel('main');
   * ```
   *
   * @param label The window label.
   * @returns The Window instance to communicate with the window or null if the window doesn't exist.
   */
  static async getByLabel(t) {
    var n;
    return (n = (await sn()).find((a) => a.label === t)) !== null && n !== void 0 ? n : null;
  }
  /**
   * Get an instance of `Window` for the current window.
   */
  static getCurrent() {
    return It();
  }
  /**
   * Gets a list of instances of `Window` for all available windows.
   */
  static async getAll() {
    return sn();
  }
  /**
   *  Gets the focused window.
   * @example
   * ```typescript
   * import { Window } from '@tauri-apps/api/window';
   * const focusedWindow = Window.getFocusedWindow();
   * ```
   *
   * @returns The Window instance or `undefined` if there is not any focused window.
   */
  static async getFocusedWindow() {
    for (const t of await sn())
      if (await t.isFocused())
        return t;
    return null;
  }
  /**
   * Listen to an emitted event on this window.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const unlisten = await getCurrentWindow().listen<string>('state-changed', (event) => {
   *   console.log(`Got error: ${payload}`);
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @param event Event name. Must include only alphanumeric characters, `-`, `/`, `:` and `_`.
   * @param handler Event handler.
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async listen(t, n) {
    return this._handleTauriEvent(t, n) ? () => {
      const a = this.listeners[t];
      a.splice(a.indexOf(n), 1);
    } : pt(t, n, {
      target: { kind: "Window", label: this.label }
    });
  }
  /**
   * Listen to an emitted event on this window only once.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const unlisten = await getCurrentWindow().once<null>('initialized', (event) => {
   *   console.log(`Window initialized!`);
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @param event Event name. Must include only alphanumeric characters, `-`, `/`, `:` and `_`.
   * @param handler Event handler.
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async once(t, n) {
    return this._handleTauriEvent(t, n) ? () => {
      const a = this.listeners[t];
      a.splice(a.indexOf(n), 1);
    } : ni(t, n, {
      target: { kind: "Window", label: this.label }
    });
  }
  /**
   * Emits an event to all {@link EventTarget|targets}.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().emit('window-loaded', { loggedIn: true, token: 'authToken' });
   * ```
   *
   * @param event Event name. Must include only alphanumeric characters, `-`, `/`, `:` and `_`.
   * @param payload Event payload.
   */
  async emit(t, n) {
    if (ln.includes(t)) {
      for (const a of this.listeners[t] || [])
        a({
          event: t,
          id: -1,
          payload: n
        });
      return;
    }
    return G(t, n);
  }
  /**
   * Emits an event to all {@link EventTarget|targets} matching the given target.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().emit('main', 'window-loaded', { loggedIn: true, token: 'authToken' });
   * ```
   * @param target Label of the target Window/Webview/WebviewWindow or raw {@link EventTarget} object.
   * @param event Event name. Must include only alphanumeric characters, `-`, `/`, `:` and `_`.
   * @param payload Event payload.
   */
  async emitTo(t, n, a) {
    if (ln.includes(n)) {
      for (const o of this.listeners[n] || [])
        o({
          event: n,
          id: -1,
          payload: a
        });
      return;
    }
    return ai(t, n, a);
  }
  /** @ignore */
  _handleTauriEvent(t, n) {
    return ln.includes(t) ? (t in this.listeners ? this.listeners[t].push(n) : this.listeners[t] = [n], !0) : !1;
  }
  // Getters
  /**
   * The scale factor that can be used to map physical pixels to logical pixels.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const factor = await getCurrentWindow().scaleFactor();
   * ```
   *
   * @returns The window's monitor scale factor.
   */
  async scaleFactor() {
    return d("plugin:window|scale_factor", {
      label: this.label
    });
  }
  /**
   * The position of the top-left hand corner of the window's client area relative to the top-left hand corner of the desktop.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const position = await getCurrentWindow().innerPosition();
   * ```
   *
   * @returns The window's inner position.
   */
  async innerPosition() {
    return d("plugin:window|inner_position", {
      label: this.label
    }).then((t) => new Nt(t));
  }
  /**
   * The position of the top-left hand corner of the window relative to the top-left hand corner of the desktop.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const position = await getCurrentWindow().outerPosition();
   * ```
   *
   * @returns The window's outer position.
   */
  async outerPosition() {
    return d("plugin:window|outer_position", {
      label: this.label
    }).then((t) => new Nt(t));
  }
  /**
   * The physical size of the window's client area.
   * The client area is the content of the window, excluding the title bar and borders.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const size = await getCurrentWindow().innerSize();
   * ```
   *
   * @returns The window's inner size.
   */
  async innerSize() {
    return d("plugin:window|inner_size", {
      label: this.label
    }).then((t) => new xe(t));
  }
  /**
   * The physical size of the entire window.
   * These dimensions include the title bar and borders. If you don't want that (and you usually don't), use inner_size instead.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const size = await getCurrentWindow().outerSize();
   * ```
   *
   * @returns The window's outer size.
   */
  async outerSize() {
    return d("plugin:window|outer_size", {
      label: this.label
    }).then((t) => new xe(t));
  }
  /**
   * Gets the window's current fullscreen state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const fullscreen = await getCurrentWindow().isFullscreen();
   * ```
   *
   * @returns Whether the window is in fullscreen mode or not.
   */
  async isFullscreen() {
    return d("plugin:window|is_fullscreen", {
      label: this.label
    });
  }
  /**
   * Gets the window's current minimized state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const minimized = await getCurrentWindow().isMinimized();
   * ```
   */
  async isMinimized() {
    return d("plugin:window|is_minimized", {
      label: this.label
    });
  }
  /**
   * Gets the window's current maximized state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const maximized = await getCurrentWindow().isMaximized();
   * ```
   *
   * @returns Whether the window is maximized or not.
   */
  async isMaximized() {
    return d("plugin:window|is_maximized", {
      label: this.label
    });
  }
  /**
   * Gets the window's current focus state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const focused = await getCurrentWindow().isFocused();
   * ```
   *
   * @returns Whether the window is focused or not.
   */
  async isFocused() {
    return d("plugin:window|is_focused", {
      label: this.label
    });
  }
  /**
   * Gets the window's current decorated state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const decorated = await getCurrentWindow().isDecorated();
   * ```
   *
   * @returns Whether the window is decorated or not.
   */
  async isDecorated() {
    return d("plugin:window|is_decorated", {
      label: this.label
    });
  }
  /**
   * Gets the window's current resizable state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const resizable = await getCurrentWindow().isResizable();
   * ```
   *
   * @returns Whether the window is resizable or not.
   */
  async isResizable() {
    return d("plugin:window|is_resizable", {
      label: this.label
    });
  }
  /**
   * Gets the window's native maximize button state.
   *
   * #### Platform-specific
   *
   * - **Linux / iOS / Android:** Unsupported.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const maximizable = await getCurrentWindow().isMaximizable();
   * ```
   *
   * @returns Whether the window's native maximize button is enabled or not.
   */
  async isMaximizable() {
    return d("plugin:window|is_maximizable", {
      label: this.label
    });
  }
  /**
   * Gets the window's native minimize button state.
   *
   * #### Platform-specific
   *
   * - **Linux / iOS / Android:** Unsupported.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const minimizable = await getCurrentWindow().isMinimizable();
   * ```
   *
   * @returns Whether the window's native minimize button is enabled or not.
   */
  async isMinimizable() {
    return d("plugin:window|is_minimizable", {
      label: this.label
    });
  }
  /**
   * Gets the window's native close button state.
   *
   * #### Platform-specific
   *
   * - **iOS / Android:** Unsupported.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const closable = await getCurrentWindow().isClosable();
   * ```
   *
   * @returns Whether the window's native close button is enabled or not.
   */
  async isClosable() {
    return d("plugin:window|is_closable", {
      label: this.label
    });
  }
  /**
   * Gets the window's current visible state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const visible = await getCurrentWindow().isVisible();
   * ```
   *
   * @returns Whether the window is visible or not.
   */
  async isVisible() {
    return d("plugin:window|is_visible", {
      label: this.label
    });
  }
  /**
   * Gets the window's current title.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const title = await getCurrentWindow().title();
   * ```
   */
  async title() {
    return d("plugin:window|title", {
      label: this.label
    });
  }
  /**
   * Gets the window's current theme.
   *
   * #### Platform-specific
   *
   * - **macOS:** Theme was introduced on macOS 10.14. Returns `light` on macOS 10.13 and below.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const theme = await getCurrentWindow().theme();
   * ```
   *
   * @returns The window theme.
   */
  async theme() {
    return d("plugin:window|theme", {
      label: this.label
    });
  }
  /**
   * Whether the window is configured to be always on top of other windows or not.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const alwaysOnTop = await getCurrentWindow().isAlwaysOnTop();
   * ```
   *
   * @returns Whether the window is visible or not.
   */
  async isAlwaysOnTop() {
    return d("plugin:window|is_always_on_top", {
      label: this.label
    });
  }
  async activityName() {
    return d("plugin:window|activity_name", {
      label: this.label
    });
  }
  async sceneIdentifier() {
    return d("plugin:window|scene_identifier", {
      label: this.label
    });
  }
  // Setters
  /**
   * Centers the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().center();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async center() {
    return d("plugin:window|center", {
      label: this.label
    });
  }
  /**
   *  Requests user attention to the window, this has no effect if the application
   * is already focused. How requesting for user attention manifests is platform dependent,
   * see `UserAttentionType` for details.
   *
   * Providing `null` will unset the request for user attention. Unsetting the request for
   * user attention might not be done automatically by the WM when the window receives input.
   *
   * #### Platform-specific
   *
   * - **macOS:** `null` has no effect.
   * - **Linux:** Urgency levels have the same effect.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().requestUserAttention();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async requestUserAttention(t) {
    let n = null;
    return t && (t === bn.Critical ? n = { type: "Critical" } : n = { type: "Informational" }), d("plugin:window|request_user_attention", {
      label: this.label,
      value: n
    });
  }
  /**
   * Updates the window resizable flag.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setResizable(false);
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async setResizable(t) {
    return d("plugin:window|set_resizable", {
      label: this.label,
      value: t
    });
  }
  /**
   * Enable or disable the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setEnabled(false);
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   *
   * @since 2.0.0
   */
  async setEnabled(t) {
    return d("plugin:window|set_enabled", {
      label: this.label,
      value: t
    });
  }
  /**
   * Whether the window is enabled or disabled.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setEnabled(false);
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   *
   * @since 2.0.0
   */
  async isEnabled() {
    return d("plugin:window|is_enabled", {
      label: this.label
    });
  }
  /**
   * Sets whether the window's native maximize button is enabled or not.
   * If resizable is set to false, this setting is ignored.
   *
   * #### Platform-specific
   *
   * - **macOS:** Disables the "zoom" button in the window titlebar, which is also used to enter fullscreen mode.
   * - **Linux / iOS / Android:** Unsupported.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setMaximizable(false);
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async setMaximizable(t) {
    return d("plugin:window|set_maximizable", {
      label: this.label,
      value: t
    });
  }
  /**
   * Sets whether the window's native minimize button is enabled or not.
   *
   * #### Platform-specific
   *
   * - **Linux / iOS / Android:** Unsupported.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setMinimizable(false);
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async setMinimizable(t) {
    return d("plugin:window|set_minimizable", {
      label: this.label,
      value: t
    });
  }
  /**
   * Sets whether the window's native close button is enabled or not.
   *
   * #### Platform-specific
   *
   * - **Linux:** GTK+ will do its best to convince the window manager not to show a close button. Depending on the system, this function may not have any effect when called on a window that is already visible
   * - **iOS / Android:** Unsupported.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setClosable(false);
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async setClosable(t) {
    return d("plugin:window|set_closable", {
      label: this.label,
      value: t
    });
  }
  /**
   * Sets the window title.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setTitle('Tauri');
   * ```
   *
   * @param title The new title
   * @returns A promise indicating the success or failure of the operation.
   */
  async setTitle(t) {
    return d("plugin:window|set_title", {
      label: this.label,
      value: t
    });
  }
  /**
   * Maximizes the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().maximize();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async maximize() {
    return d("plugin:window|maximize", {
      label: this.label
    });
  }
  /**
   * Unmaximizes the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().unmaximize();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async unmaximize() {
    return d("plugin:window|unmaximize", {
      label: this.label
    });
  }
  /**
   * Toggles the window maximized state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().toggleMaximize();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async toggleMaximize() {
    return d("plugin:window|toggle_maximize", {
      label: this.label
    });
  }
  /**
   * Minimizes the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().minimize();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async minimize() {
    return d("plugin:window|minimize", {
      label: this.label
    });
  }
  /**
   * Unminimizes the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().unminimize();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async unminimize() {
    return d("plugin:window|unminimize", {
      label: this.label
    });
  }
  /**
   * Sets the window visibility to true.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().show();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async show() {
    return d("plugin:window|show", {
      label: this.label
    });
  }
  /**
   * Sets the window visibility to false.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().hide();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async hide() {
    return d("plugin:window|hide", {
      label: this.label
    });
  }
  /**
   * Closes the window.
   *
   * Note this emits a closeRequested event so you can intercept it. To force window close, use {@link Window.destroy}.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().close();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async close() {
    return d("plugin:window|close", {
      label: this.label
    });
  }
  /**
   * Destroys the window. Behaves like {@link Window.close} but forces the window close instead of emitting a closeRequested event.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().destroy();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async destroy() {
    return d("plugin:window|destroy", {
      label: this.label
    });
  }
  /**
   * Whether the window should have borders and bars.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setDecorations(false);
   * ```
   *
   * @param decorations Whether the window should have borders and bars.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setDecorations(t) {
    return d("plugin:window|set_decorations", {
      label: this.label,
      value: t
    });
  }
  /**
   * Whether or not the window should have shadow.
   *
   * #### Platform-specific
   *
   * - **Windows:**
   *   - `false` has no effect on decorated window, shadows are always ON.
   *   - `true` will make undecorated window have a 1px white border,
   * and on Windows 11, it will have a rounded corners.
   * - **Linux:** Unsupported.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setShadow(false);
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async setShadow(t) {
    return d("plugin:window|set_shadow", {
      label: this.label,
      value: t
    });
  }
  /**
   * Set window effects.
   */
  async setEffects(t) {
    return d("plugin:window|set_effects", {
      label: this.label,
      value: t
    });
  }
  /**
   * Clear any applied effects if possible.
   */
  async clearEffects() {
    return d("plugin:window|set_effects", {
      label: this.label,
      value: null
    });
  }
  /**
   * Whether the window should always be on top of other windows.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setAlwaysOnTop(true);
   * ```
   *
   * @param alwaysOnTop Whether the window should always be on top of other windows or not.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setAlwaysOnTop(t) {
    return d("plugin:window|set_always_on_top", {
      label: this.label,
      value: t
    });
  }
  /**
   * Whether the window should always be below other windows.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setAlwaysOnBottom(true);
   * ```
   *
   * @param alwaysOnBottom Whether the window should always be below other windows or not.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setAlwaysOnBottom(t) {
    return d("plugin:window|set_always_on_bottom", {
      label: this.label,
      value: t
    });
  }
  /**
   * Prevents the window contents from being captured by other apps.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setContentProtected(true);
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async setContentProtected(t) {
    return d("plugin:window|set_content_protected", {
      label: this.label,
      value: t
    });
  }
  /**
   * Resizes the window with a new inner size.
   * @example
   * ```typescript
   * import { getCurrentWindow, LogicalSize } from '@tauri-apps/api/window';
   * await getCurrentWindow().setSize(new LogicalSize(600, 500));
   * ```
   *
   * @param size The logical or physical inner size.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setSize(t) {
    return d("plugin:window|set_size", {
      label: this.label,
      value: t instanceof ie ? t : new ie(t)
    });
  }
  /**
   * Sets the window minimum inner size. If the `size` argument is not provided, the constraint is unset.
   * @example
   * ```typescript
   * import { getCurrentWindow, PhysicalSize } from '@tauri-apps/api/window';
   * await getCurrentWindow().setMinSize(new PhysicalSize(600, 500));
   * ```
   *
   * @param size The logical or physical inner size, or `null` to unset the constraint.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setMinSize(t) {
    return d("plugin:window|set_min_size", {
      label: this.label,
      value: t instanceof ie ? t : t ? new ie(t) : null
    });
  }
  /**
   * Sets the window maximum inner size. If the `size` argument is undefined, the constraint is unset.
   * @example
   * ```typescript
   * import { getCurrentWindow, LogicalSize } from '@tauri-apps/api/window';
   * await getCurrentWindow().setMaxSize(new LogicalSize(600, 500));
   * ```
   *
   * @param size The logical or physical inner size, or `null` to unset the constraint.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setMaxSize(t) {
    return d("plugin:window|set_max_size", {
      label: this.label,
      value: t instanceof ie ? t : t ? new ie(t) : null
    });
  }
  /**
   * Sets the window inner size constraints.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setSizeConstraints({ minWidth: 300 });
   * ```
   *
   * @param constraints The logical or physical inner size, or `null` to unset the constraint.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setSizeConstraints(t) {
    function n(a) {
      return a ? { Logical: a } : null;
    }
    return d("plugin:window|set_size_constraints", {
      label: this.label,
      value: {
        minWidth: n(t == null ? void 0 : t.minWidth),
        minHeight: n(t == null ? void 0 : t.minHeight),
        maxWidth: n(t == null ? void 0 : t.maxWidth),
        maxHeight: n(t == null ? void 0 : t.maxHeight)
      }
    });
  }
  /**
   * Sets the window outer position.
   * @example
   * ```typescript
   * import { getCurrentWindow, LogicalPosition } from '@tauri-apps/api/window';
   * await getCurrentWindow().setPosition(new LogicalPosition(600, 500));
   * ```
   *
   * @param position The new position, in logical or physical pixels.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setPosition(t) {
    return d("plugin:window|set_position", {
      label: this.label,
      value: t instanceof Ie ? t : new Ie(t)
    });
  }
  /**
   * Sets the window fullscreen state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setFullscreen(true);
   * ```
   *
   * @param fullscreen Whether the window should go to fullscreen or not.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setFullscreen(t) {
    return d("plugin:window|set_fullscreen", {
      label: this.label,
      value: t
    });
  }
  /**
   * On macOS, Toggles a fullscreen mode that doesn’t require a new macOS space. Returns a boolean indicating whether the transition was successful (this won’t work if the window was already in the native fullscreen).
   * This is how fullscreen used to work on macOS in versions before Lion. And allows the user to have a fullscreen window without using another space or taking control over the entire monitor.
   *
   * On other platforms, this is the same as {@link Window.setFullscreen}.
   *
   * @param fullscreen Whether the window should go to simple fullscreen or not.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setSimpleFullscreen(t) {
    return d("plugin:window|set_simple_fullscreen", {
      label: this.label,
      value: t
    });
  }
  /**
   * Bring the window to front and focus.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setFocus();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async setFocus() {
    return d("plugin:window|set_focus", {
      label: this.label
    });
  }
  /**
   * Sets whether the window can be focused.
   *
   * #### Platform-specific
   *
   * - **macOS**: If the window is already focused, it is not possible to unfocus it after calling `set_focusable(false)`.
   *   In this case, you might consider calling {@link Window.setFocus} but it will move the window to the back i.e. at the bottom in terms of z-order.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setFocusable(true);
   * ```
   *
   * @param focusable Whether the window can be focused.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setFocusable(t) {
    return d("plugin:window|set_focusable", {
      label: this.label,
      value: t
    });
  }
  /**
   * Sets the window icon.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setIcon('/tauri/awesome.png');
   * ```
   *
   * Note that you may need the `image-ico` or `image-png` Cargo features to use this API.
   * To enable it, change your Cargo.toml file:
   * ```toml
   * [dependencies]
   * tauri = { version = "...", features = ["...", "image-png"] }
   * ```
   *
   * @param icon Icon bytes or path to the icon file.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setIcon(t) {
    return d("plugin:window|set_icon", {
      label: this.label,
      value: je(t)
    });
  }
  /**
   * Whether the window icon should be hidden from the taskbar or not.
   *
   * #### Platform-specific
   *
   * - **macOS:** Unsupported.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setSkipTaskbar(true);
   * ```
   *
   * @param skip true to hide window icon, false to show it.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setSkipTaskbar(t) {
    return d("plugin:window|set_skip_taskbar", {
      label: this.label,
      value: t
    });
  }
  /**
   * Grabs the cursor, preventing it from leaving the window.
   *
   * There's no guarantee that the cursor will be hidden. You should
   * hide it by yourself if you want so.
   *
   * #### Platform-specific
   *
   * - **Linux:** Unsupported.
   * - **macOS:** This locks the cursor in a fixed location, which looks visually awkward.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setCursorGrab(true);
   * ```
   *
   * @param grab `true` to grab the cursor icon, `false` to release it.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setCursorGrab(t) {
    return d("plugin:window|set_cursor_grab", {
      label: this.label,
      value: t
    });
  }
  /**
   * Modifies the cursor's visibility.
   *
   * #### Platform-specific
   *
   * - **Windows:** The cursor is only hidden within the confines of the window.
   * - **macOS:** The cursor is hidden as long as the window has input focus, even if the cursor is
   *   outside of the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setCursorVisible(false);
   * ```
   *
   * @param visible If `false`, this will hide the cursor. If `true`, this will show the cursor.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setCursorVisible(t) {
    return d("plugin:window|set_cursor_visible", {
      label: this.label,
      value: t
    });
  }
  /**
   * Modifies the cursor icon of the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setCursorIcon('help');
   * ```
   *
   * @param icon The new cursor icon.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setCursorIcon(t) {
    return d("plugin:window|set_cursor_icon", {
      label: this.label,
      value: t
    });
  }
  /**
   * Sets the window background color.
   *
   * #### Platform-specific:
   *
   * - **Windows:** alpha channel is ignored.
   * - **iOS / Android:** Unsupported.
   *
   * @returns A promise indicating the success or failure of the operation.
   *
   * @since 2.1.0
   */
  async setBackgroundColor(t) {
    return d("plugin:window|set_background_color", { color: t });
  }
  /**
   * Changes the position of the cursor in window coordinates.
   * @example
   * ```typescript
   * import { getCurrentWindow, LogicalPosition } from '@tauri-apps/api/window';
   * await getCurrentWindow().setCursorPosition(new LogicalPosition(600, 300));
   * ```
   *
   * @param position The new cursor position.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setCursorPosition(t) {
    return d("plugin:window|set_cursor_position", {
      label: this.label,
      value: t instanceof Ie ? t : new Ie(t)
    });
  }
  /**
   * Changes the cursor events behavior.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setIgnoreCursorEvents(true);
   * ```
   *
   * @param ignore `true` to ignore the cursor events; `false` to process them as usual.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setIgnoreCursorEvents(t) {
    return d("plugin:window|set_ignore_cursor_events", {
      label: this.label,
      value: t
    });
  }
  /**
   * Starts dragging the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().startDragging();
   * ```
   *
   * @return A promise indicating the success or failure of the operation.
   */
  async startDragging() {
    return d("plugin:window|start_dragging", {
      label: this.label
    });
  }
  /**
   * Starts resize-dragging the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().startResizeDragging();
   * ```
   *
   * @return A promise indicating the success or failure of the operation.
   */
  async startResizeDragging(t) {
    return d("plugin:window|start_resize_dragging", {
      label: this.label,
      value: t
    });
  }
  /**
   * Sets the badge count. It is app wide and not specific to this window.
   *
   * #### Platform-specific
   *
   * - **Windows**: Unsupported. Use @{linkcode Window.setOverlayIcon} instead.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setBadgeCount(5);
   * ```
   *
   * @param count The badge count. Use `undefined` to remove the badge.
   * @return A promise indicating the success or failure of the operation.
   */
  async setBadgeCount(t) {
    return d("plugin:window|set_badge_count", {
      label: this.label,
      value: t
    });
  }
  /**
   * Sets the badge cont **macOS only**.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setBadgeLabel("Hello");
   * ```
   *
   * @param label The badge label. Use `undefined` to remove the badge.
   * @return A promise indicating the success or failure of the operation.
   */
  async setBadgeLabel(t) {
    return d("plugin:window|set_badge_label", {
      label: this.label,
      value: t
    });
  }
  /**
   * Sets the overlay icon. **Windows only**
   * The overlay icon can be set for every window.
   *
   *
   * Note that you may need the `image-ico` or `image-png` Cargo features to use this API.
   * To enable it, change your Cargo.toml file:
   *
   * ```toml
   * [dependencies]
   * tauri = { version = "...", features = ["...", "image-png"] }
   * ```
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setOverlayIcon("/tauri/awesome.png");
   * ```
   *
   * @param icon Icon bytes or path to the icon file. Use `undefined` to remove the overlay icon.
   * @return A promise indicating the success or failure of the operation.
   */
  async setOverlayIcon(t) {
    return d("plugin:window|set_overlay_icon", {
      label: this.label,
      value: t ? je(t) : void 0
    });
  }
  /**
   * Sets the taskbar progress state.
   *
   * #### Platform-specific
   *
   * - **Linux / macOS**: Progress bar is app-wide and not specific to this window.
   * - **Linux**: Only supported desktop environments with `libunity` (e.g. GNOME).
   *
   * @example
   * ```typescript
   * import { getCurrentWindow, ProgressBarStatus } from '@tauri-apps/api/window';
   * await getCurrentWindow().setProgressBar({
   *   status: ProgressBarStatus.Normal,
   *   progress: 50,
   * });
   * ```
   *
   * @return A promise indicating the success or failure of the operation.
   */
  async setProgressBar(t) {
    return d("plugin:window|set_progress_bar", {
      label: this.label,
      value: t
    });
  }
  /**
   * Sets whether the window should be visible on all workspaces or virtual desktops.
   *
   * #### Platform-specific
   *
   * - **Windows / iOS / Android:** Unsupported.
   *
   * @since 2.0.0
   */
  async setVisibleOnAllWorkspaces(t) {
    return d("plugin:window|set_visible_on_all_workspaces", {
      label: this.label,
      value: t
    });
  }
  /**
   * Sets the title bar style. **macOS only**.
   *
   * @since 2.0.0
   */
  async setTitleBarStyle(t) {
    return d("plugin:window|set_title_bar_style", {
      label: this.label,
      value: t
    });
  }
  /**
   * Set window theme, pass in `null` or `undefined` to follow system theme
   *
   * #### Platform-specific
   *
   * - **Linux / macOS**: Theme is app-wide and not specific to this window.
   * - **iOS / Android:** Unsupported.
   *
   * @since 2.0.0
   */
  async setTheme(t) {
    return d("plugin:window|set_theme", {
      label: this.label,
      value: t
    });
  }
  // Listeners
  /**
   * Listen to window resize.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from "@tauri-apps/api/window";
   * const unlisten = await getCurrentWindow().onResized(({ payload: size }) => {
   *  console.log('Window resized', size);
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async onResized(t) {
    return this.listen(ct.WINDOW_RESIZED, (n) => {
      n.payload = new xe(n.payload), t(n);
    });
  }
  /**
   * Listen to window move.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from "@tauri-apps/api/window";
   * const unlisten = await getCurrentWindow().onMoved(({ payload: position }) => {
   *  console.log('Window moved', position);
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async onMoved(t) {
    return this.listen(ct.WINDOW_MOVED, (n) => {
      n.payload = new Nt(n.payload), t(n);
    });
  }
  /**
   * Listen to window close requested. Emitted when the user requests to closes the window.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from "@tauri-apps/api/window";
   * import { confirm } from '@tauri-apps/api/dialog';
   * const unlisten = await getCurrentWindow().onCloseRequested(async (event) => {
   *   const confirmed = await confirm('Are you sure?');
   *   if (!confirmed) {
   *     // user did not confirm closing the window; let's prevent it
   *     event.preventDefault();
   *   }
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async onCloseRequested(t) {
    return this.listen(ct.WINDOW_CLOSE_REQUESTED, async (n) => {
      const a = new ii(n);
      await t(a), a.isPreventDefault() || await this.destroy();
    });
  }
  /**
   * Listen to a file drop event.
   * The listener is triggered when the user hovers the selected files on the webview,
   * drops the files or cancels the operation.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from "@tauri-apps/api/webview";
   * const unlisten = await getCurrentWindow().onDragDropEvent((event) => {
   *  if (event.payload.type === 'over') {
   *    console.log('User hovering', event.payload.position);
   *  } else if (event.payload.type === 'drop') {
   *    console.log('User dropped', event.payload.paths);
   *  } else {
   *    console.log('File drop cancelled');
   *  }
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async onDragDropEvent(t) {
    const n = await this.listen(ct.DRAG_ENTER, (h) => {
      t({
        ...h,
        payload: {
          type: "enter",
          paths: h.payload.paths,
          position: new Nt(h.payload.position)
        }
      });
    }), a = await this.listen(ct.DRAG_OVER, (h) => {
      t({
        ...h,
        payload: {
          type: "over",
          position: new Nt(h.payload.position)
        }
      });
    }), o = await this.listen(ct.DRAG_DROP, (h) => {
      t({
        ...h,
        payload: {
          type: "drop",
          paths: h.payload.paths,
          position: new Nt(h.payload.position)
        }
      });
    }), c = await this.listen(ct.DRAG_LEAVE, (h) => {
      t({ ...h, payload: { type: "leave" } });
    });
    return () => {
      n(), o(), a(), c();
    };
  }
  /**
   * Listen to window focus change.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from "@tauri-apps/api/window";
   * const unlisten = await getCurrentWindow().onFocusChanged(({ payload: focused }) => {
   *  console.log('Focus changed, window is focused? ' + focused);
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async onFocusChanged(t) {
    const n = await this.listen(ct.WINDOW_FOCUS, (o) => {
      t({ ...o, payload: !0 });
    }), a = await this.listen(ct.WINDOW_BLUR, (o) => {
      t({ ...o, payload: !1 });
    });
    return () => {
      n(), a();
    };
  }
  /**
   * Listen to window scale change. Emitted when the window's scale factor has changed.
   * The following user actions can cause DPI changes:
   * - Changing the display's resolution.
   * - Changing the display's scale factor (e.g. in Control Panel on Windows).
   * - Moving the window to a display with a different scale factor.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from "@tauri-apps/api/window";
   * const unlisten = await getCurrentWindow().onScaleChanged(({ payload }) => {
   *  console.log('Scale changed', payload.scaleFactor, payload.size);
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async onScaleChanged(t) {
    return this.listen(ct.WINDOW_SCALE_FACTOR_CHANGED, t);
  }
  /**
   * Listen to the system theme change.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from "@tauri-apps/api/window";
   * const unlisten = await getCurrentWindow().onThemeChanged(({ payload: theme }) => {
   *  console.log('New theme: ' + theme);
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async onThemeChanged(t) {
    return this.listen(ct.WINDOW_THEME_CHANGED, t);
  }
}
var jn;
(function(e) {
  e.Disabled = "disabled", e.Throttle = "throttle", e.Suspend = "suspend";
})(jn || (jn = {}));
var Hn;
(function(e) {
  e.Default = "default", e.FluentOverlay = "fluentOverlay";
})(Hn || (Hn = {}));
var Bn;
(function(e) {
  e.AppearanceBased = "appearanceBased", e.Light = "light", e.Dark = "dark", e.MediumLight = "mediumLight", e.UltraDark = "ultraDark", e.Titlebar = "titlebar", e.Selection = "selection", e.Menu = "menu", e.Popover = "popover", e.Sidebar = "sidebar", e.HeaderView = "headerView", e.Sheet = "sheet", e.WindowBackground = "windowBackground", e.HudWindow = "hudWindow", e.FullScreenUI = "fullScreenUI", e.Tooltip = "tooltip", e.ContentBackground = "contentBackground", e.UnderWindowBackground = "underWindowBackground", e.UnderPageBackground = "underPageBackground", e.Mica = "mica", e.Blur = "blur", e.Acrylic = "acrylic", e.Tabbed = "tabbed", e.TabbedDark = "tabbedDark", e.TabbedLight = "tabbedLight";
})(Bn || (Bn = {}));
var Vn;
(function(e) {
  e.FollowsWindowActiveState = "followsWindowActiveState", e.Active = "active", e.Inactive = "inactive";
})(Vn || (Vn = {}));
async function gn(e = {}) {
  return typeof e == "object" && Object.freeze(e), await d("plugin:dialog|open", { options: e });
}
const ri = "__lunac_host";
function oi() {
  return globalThis[ri] ?? null;
}
function w(e, t) {
  const n = oi();
  return n && typeof n.t == "function" ? n.t(e, t) : e;
}
const si = "pet", li = "engine/live2dcubismcore.min.js", ci = "engine/live2d-engine.js";
function Zt(e, t) {
  const n = e.includes("\\") ? "\\" : "/", a = e.replace(/[\\/]+$/, "").split(/[\\/]+/);
  for (const o of t.split(/[\\/]+/))
    if (!(!o || o === ".")) {
      if (o === "..") {
        a.length > 1 && a.pop();
        continue;
      }
      a.push(o);
    }
  return a.join(n);
}
function Ke(e) {
  const t = Math.max(e.lastIndexOf("\\"), e.lastIndexOf("/"));
  return t > 0 ? e.slice(0, t) : e;
}
function pi(e) {
  var n;
  const t = Number((e == null ? void 0 : e.Version) ?? 0);
  if (!((n = e == null ? void 0 : e.FileReferences) != null && n.Moc) || !(t >= 3))
    throw new Error("这不是 Cubism 4 的模型定义（缺 `FileReferences.Moc` 或 `Version < 3`）—— 请选 `*.model3.json`");
}
async function Je(e) {
  let t;
  try {
    t = await fetch(Ft(e));
  } catch (n) {
    throw new Error(`读不到模型文件（asset 协议拒绝或文件已移动）：${n instanceof Error ? n.message : String(n)}`);
  }
  if (!t.ok) throw new Error(`读模型定义失败（HTTP ${t.status}）`);
  try {
    return await t.json();
  } catch {
    throw new Error("模型定义不是合法 JSON");
  }
}
function Un(e) {
  return (e.split(/[\\/]/).pop() || "").replace(/\.[^.]+$/, "");
}
function cn(e) {
  return e.replace(/[\\/]+/g, "/").toLowerCase();
}
async function pa(e, t) {
  var y;
  const n = t ?? await Je(e), a = Ke(e), o = ((y = n.FileReferences) == null ? void 0 : y.Expressions) ?? [], c = [], h = /* @__PURE__ */ new Set();
  for (const M of o) {
    const L = M.File ? Zt(a, M.File) : "", $ = (M.Name || (M.File ? Un(M.File) : "")).trim();
    $ && (L && h.add(cn(L)), c.push({ id: $, name: $, file: L, declared: !0 }));
  }
  let b = [];
  try {
    b = await d("list_expression_files", {
      model_path: e
    }) ?? [];
  } catch {
    b = [];
  }
  for (const M of b) {
    const L = typeof (M == null ? void 0 : M.path) == "string" ? M.path : "";
    if (!L || h.has(cn(L))) continue;
    const $ = (typeof (M == null ? void 0 : M.name) == "string" && M.name.trim() || Un(L)).trim();
    $ && (h.add(cn(L)), c.push({ id: $, name: $, file: L, declared: !1 }));
  }
  return c;
}
async function ua(e) {
  var t;
  try {
    const n = await Je(e);
    pi(n);
    const a = n.FileReferences ?? {}, o = Object.keys(a.Motions ?? {});
    return {
      ok: !0,
      info: `Cubism ${Number(n.Version)} · 纹理 ${((t = a.Textures) == null ? void 0 : t.length) ?? 0} · 动作组 ${o.length ? o.join(" / ") : "无"}`
    };
  } catch (n) {
    return { ok: !1, reason: n instanceof Error ? n.message : String(n) };
  }
}
async function da() {
  const e = await d("plugins_dir_path");
  return Zt(e, si);
}
async function ui() {
  return Zt(await da(), li);
}
async function di() {
  return Zt(await da(), ci);
}
function fa() {
  return !!globalThis.Live2DCubismCore;
}
let Pe = null;
function fi() {
  return fa() ? Promise.resolve() : (Pe || (Pe = hi().catch((e) => {
    throw Pe = null, e instanceof Error ? e : new Error(String(e));
  })), Pe);
}
async function hi() {
  if (await mi(Ft(await ui())), !fa()) throw new Error("Cubism Core 已注入但全局对象仍不可见（文件可能不完整）");
}
function mi(e) {
  return new Promise((t, n) => {
    const a = document.createElement("script");
    a.src = e, a.async = !1, a.onload = () => t(), a.onerror = () => n(new Error(`引擎文件加载失败（asset 协议拒绝或文件缺失）：${e}`)), document.head.appendChild(a);
  });
}
const ha = 0.4, ma = 8, yn = "Lunac", bi = [
  "motion",
  "chain",
  "expression",
  "param",
  "artmesh",
  "artmeshColor",
  "part",
  "physics"
];
function gi(e) {
  return e.split(/[\\/]/).pop() || "";
}
function yi() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
}
function vn(e = "新热键", t = "", n) {
  return {
    id: yi(),
    name: e,
    keys: t,
    action: n ?? { type: "expression", target: "", mode: "set" }
  };
}
function vi(e) {
  const t = [
    "Numpad1",
    "Numpad2",
    "Numpad3",
    "Numpad4",
    "Numpad5",
    "Numpad6",
    "Numpad7",
    "Numpad8",
    "Numpad9"
  ], n = ["Ctrl", "Shift", "Alt", "Ctrl+Shift", "Ctrl+Alt", "Shift+Alt", "Ctrl+Shift+Alt"], a = Math.max(0, Math.floor(e)), o = t[a % t.length], c = Math.floor(a / t.length);
  return c < n.length ? `${n[c]}+${o}` : o;
}
async function oe(e) {
  let t = null;
  try {
    t = await d("read_pet_hotkeys", { modelPath: e });
  } catch {
    return [];
  }
  if (!t) return [];
  try {
    const n = JSON.parse(t);
    return (Array.isArray(n.hotkeys) ? n.hotkeys : []).filter(
      (o) => !!o && typeof o == "object" && typeof o.keys == "string"
    );
  } catch {
    return [];
  }
}
async function Ze(e, t) {
  const n = { version: 1, model: gi(e), hotkeys: t };
  return d("write_pet_hotkeys", {
    modelPath: e,
    json: JSON.stringify(n, null, 2)
  });
}
async function wi(e) {
  const t = await fetch(Ft(e));
  if (!t.ok) throw new Error(`HTTP ${t.status}`);
  return t.json();
}
async function xi(e) {
  const t = await wi(e), n = [], a = [], o = (b, y) => {
    y && !b.includes(y) && b.push(y);
  }, c = (b) => {
    const y = b;
    return typeof (y == null ? void 0 : y.Target) == "string" && y.Target ? y.Target : typeof (y == null ? void 0 : y.Id) == "string" && y.Id ? y.Id : "";
  }, h = t == null ? void 0 : t.PhysicsSettings;
  if (!Array.isArray(h)) return { inputs: n, outputs: a };
  for (const b of h) {
    const y = b == null ? void 0 : b.Input;
    if (Array.isArray(y))
      for (const L of y) o(n, c(L == null ? void 0 : L.Source));
    const M = b == null ? void 0 : b.Output;
    if (Array.isArray(M))
      for (const L of M) o(a, c(L == null ? void 0 : L.Destination));
  }
  return { inputs: n, outputs: a };
}
async function ba(e, t) {
  var c, h;
  const n = {
    motions: [],
    expressions: [],
    expressionFiles: {},
    parameters: (t == null ? void 0 : t.parameters) ?? [],
    drawables: (t == null ? void 0 : t.drawables) ?? [],
    parts: (t == null ? void 0 : t.parts) ?? [],
    physicsInputs: [],
    physicsOutputs: []
  };
  let a = null;
  try {
    a = await Je(e);
  } catch {
    a = null;
  }
  if ((c = a == null ? void 0 : a.FileReferences) != null && c.Motions)
    for (const [b, y] of Object.entries(a.FileReferences.Motions))
      n.motions.push({ group: b, count: Array.isArray(y) ? y.length : 0 });
  try {
    const b = await pa(e, a ?? void 0);
    n.expressions = b.map((y) => y.id);
    for (const y of b) n.expressionFiles[y.id] = y.file;
  } catch {
    n.expressions = [];
  }
  const o = (h = a == null ? void 0 : a.FileReferences) == null ? void 0 : h.Physics;
  if (typeof o == "string" && o)
    try {
      const b = Zt(Ke(e), o), { inputs: y, outputs: M } = await xi(b);
      n.physicsInputs = y, n.physicsOutputs = M;
    } catch {
    }
  return n;
}
const Gn = /* @__PURE__ */ new Map();
async function ga(e) {
  const t = e.toLowerCase(), n = Gn.get(t);
  if (n) return n;
  let a = [];
  try {
    const o = await fetch(Ft(e));
    if (o.ok) {
      const c = await o.json();
      a = (Array.isArray(c.Parameters) ? c.Parameters : []).map((b) => {
        const y = typeof (b == null ? void 0 : b.Id) == "string" ? b.Id : "", M = b == null ? void 0 : b.Value, L = b == null ? void 0 : b.Blend;
        return { id: y, value: typeof M == "number" ? M : NaN, blend: typeof L == "string" && L ? L : "Overwrite" };
      }).filter((b) => !!b.id && Number.isFinite(b.value));
    }
  } catch {
    a = [];
  }
  return Gn.set(t, a), a;
}
async function Qe(e) {
  try {
    const t = await fetch(Ft(e));
    return t.ok ? await t.json() : null;
  } catch {
    return null;
  }
}
async function _i(e) {
  const t = await Qe(e), n = t == null ? void 0 : t.Hotkeys;
  if (!Array.isArray(n)) return [];
  const a = [];
  for (const o of n) {
    const c = o, h = typeof (c == null ? void 0 : c.Action) == "string" ? c.Action.trim() : "";
    if (!h) continue;
    const b = typeof (c == null ? void 0 : c.File) == "string" ? c.File.trim() : "", y = typeof (c == null ? void 0 : c.Folder) == "string" ? c.Folder.trim() : "", M = typeof (c == null ? void 0 : c.Name) == "string" ? c.Name.trim() : "";
    a.push({ name: M || b, action: h, file: b ? y ? `${y}/${b}` : b : "" });
  }
  return a;
}
async function ki(e) {
  const t = await Qe(e), n = t == null ? void 0 : t.ParameterSettings;
  if (!Array.isArray(n)) return [];
  const a = [];
  for (const o of n) {
    const c = o == null ? void 0 : o.OutputLive2D;
    typeof c == "string" && c && !a.includes(c) && a.push(c);
  }
  return a;
}
async function Si(e) {
  const t = { parameters: {}, parts: {}, artMeshes: {} }, n = await Qe(e);
  if (!n) return t;
  const a = (o, c) => {
    const h = n[o];
    if (Array.isArray(h))
      for (const b of h) {
        const y = b;
        typeof (y == null ? void 0 : y.Id) == "string" && y.Id && typeof (y == null ? void 0 : y.Name) == "string" && y.Name && (c[y.Id] = y.Name);
      }
  };
  return a("Parameters", t.parameters), a("Parts", t.parts), a("ArtMeshes", t.artMeshes), t;
}
function Mi(e) {
  switch (e) {
    case "ToggleExpression":
      return "expression";
    case "TriggerAnimation":
      return "motion";
    default:
      return null;
  }
}
function Ei(e, t) {
  const n = Mi(e.action);
  if (!n) return null;
  const a = e.name || "热键";
  if (n === "expression") {
    const o = e.file ? Zt(t, e.file) : "";
    return vn(a, "", { type: "expression", target: e.name, mode: "set", file: o });
  }
  return vn(a, "", { type: "motion", group: "", index: 0 });
}
async function ve(e) {
  const t = Ke(e);
  if (!t) return [];
  try {
    const n = await d("list_motion_files", { dir: t });
    return Array.isArray(n) ? n.filter((a) => !!a && typeof a.path == "string") : [];
  } catch {
    return [];
  }
}
async function Ci(e) {
  const t = /* @__PURE__ */ new Map();
  for (const n of e) {
    const a = await Qe(n), o = a == null ? void 0 : a.Curves;
    if (Array.isArray(o))
      for (const c of o) {
        const h = c == null ? void 0 : c.Id, b = c == null ? void 0 : c.Segments;
        if (typeof h != "string" || !h || !Array.isArray(b) || b.length < 3) continue;
        const y = t.get(h) ?? /* @__PURE__ */ new Set();
        typeof b[1] == "number" && y.add(b[1]);
        let M = 2;
        for (; M < b.length; ) {
          const L = b[M];
          M += L === 1 ? 7 : 3;
          const $ = b[M - 1];
          typeof $ == "number" && y.add($);
        }
        t.set(h, y);
      }
  }
  return t;
}
const $i = 0.1, Ai = 3600;
function Li() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
}
function Ti(e = "新动作链") {
  return { id: Li(), name: e, steps: [], loop: !1 };
}
function qn(e = "") {
  return { file: e, loopSec: 3, stopSec: 0 };
}
function Xn(e, t) {
  const n = typeof e == "number" && Number.isFinite(e) ? e : t;
  return n <= 0 ? t : Math.min(Ai, Math.max($i, n));
}
function Ni(e) {
  return e.split(/[\\/]/).pop() || "";
}
async function We(e) {
  let t = null;
  try {
    t = await d("read_pet_chains", { modelPath: e });
  } catch {
    return [];
  }
  if (!t) return [];
  try {
    const n = JSON.parse(t);
    return (Array.isArray(n.chains) ? n.chains : []).filter((o) => !!o && typeof o == "object" && typeof o.id == "string").map((o) => ({
      id: String(o.id),
      name: typeof o.name == "string" && o.name ? o.name : "动作链",
      // 整链循环：缺省 / 坏值一律当 false（保持「播完即停」的旧行为，不让坏数据把链卡成死循环）。
      loop: o.loop === !0,
      steps: (Array.isArray(o.steps) ? o.steps : []).filter((c) => !!c && typeof c == "object" && typeof c.file == "string").map((c) => ({
        file: c.file,
        loopSec: Xn(c.loopSec, 3),
        stopSec: typeof c.stopSec == "number" && Number.isFinite(c.stopSec) && c.stopSec > 0 ? Xn(c.stopSec, 3) : 0
      }))
    }));
  } catch {
    return [];
  }
}
async function Ii(e, t) {
  const n = { version: 1, model: Ni(e), chains: t };
  return d("write_pet_chains", { modelPath: e, json: JSON.stringify(n, null, 2) });
}
function Sn(e) {
  const t = e.stopSec > 0 ? e.stopSec : e.loopSec;
  return Math.min(e.loopSec, t);
}
function Pi(e) {
  return e.steps.reduce((t, n) => t + Sn(n), 0);
}
function ya(e) {
  return e.split(/[\\/]/).pop() || "";
}
function Mn(e) {
  return {
    version: 1,
    model: ya(e),
    coreIds: { parameters: [], drawables: [], parts: [], parameterRanges: {} },
    params: {}
  };
}
function pn(e) {
  return Array.isArray(e) ? e.filter((t) => typeof t == "string") : [];
}
function Oi(e) {
  const t = {};
  if (e && typeof e == "object")
    for (const [n, a] of Object.entries(e))
      typeof a == "number" && Number.isFinite(a) && (t[n] = a);
  return t;
}
function Di(e) {
  const t = {};
  if (e && typeof e == "object")
    for (const [n, a] of Object.entries(e)) {
      const o = a;
      o && typeof o == "object" && (t[n] = {
        min: typeof o.min == "number" && Number.isFinite(o.min) ? o.min : 0,
        max: typeof o.max == "number" && Number.isFinite(o.max) ? o.max : 0,
        def: typeof o.def == "number" && Number.isFinite(o.def) ? o.def : 0
      });
    }
  return t;
}
async function ke(e) {
  let t = null;
  try {
    t = await d("read_pet_params", { modelPath: e });
  } catch {
    return null;
  }
  if (!t) return null;
  try {
    const n = JSON.parse(t);
    if (!n || typeof n != "object") return null;
    const a = n.coreIds ?? {};
    return {
      version: 1,
      model: typeof n.model == "string" ? n.model : ya(e),
      coreIds: {
        parameters: pn(a.parameters),
        drawables: pn(a.drawables),
        parts: pn(a.parts),
        parameterRanges: Di(a.parameterRanges)
      },
      params: Oi(n.params)
    };
  } catch {
    return null;
  }
}
async function He(e, t) {
  return d("write_pet_params", { modelPath: e, json: JSON.stringify(t, null, 2) });
}
function Oe(e) {
  return String(e).replace(
    /[&<>"']/g,
    (t) => t === "&" ? "&amp;" : t === "<" ? "&lt;" : t === ">" ? "&gt;" : t === '"' ? "&quot;" : "&#39;"
  );
}
function wn(e, t, n = "") {
  var b, y;
  const a = t.map((M) => {
    const L = M.tag ? ` data-tag="${Oe(M.tag)}"` : "", $ = M.deletable ? '<span class="cs-del" title="×">×</span>' : "";
    return `<div class="custom-select-option${M.selected ? " selected" : ""}" data-value="${Oe(M.value)}"${L}>${Oe(M.label)}${$}</div>`;
  }).join(""), o = ((b = t.find((M) => M.selected)) == null ? void 0 : b.label) || ((y = t[0]) == null ? void 0 : y.label) || "", c = "", h = n ? ` ${n}` : "";
  return `<div class="custom-select"${c}${h}><button class="custom-select-trigger" type="button"><span class="custom-select-label">${Oe(o)}</span><svg class="custom-select-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg></button><div class="custom-select-dropdown">${a}</div></div>`;
}
const Yn = "__lunacCustomSelectBound";
function Kn(e) {
  const t = e.querySelector(".custom-select-dropdown"), n = e.querySelector(".custom-select-trigger");
  if (!t || !n) return;
  const a = n.getBoundingClientRect(), o = 8, c = 120, h = e.closest("#results-list"), b = h == null ? void 0 : h.getBoundingClientRect(), y = Math.max(b ? b.top : 0, 0), L = Math.min(b ? b.bottom : window.innerHeight, window.innerHeight) - a.bottom - o, $ = a.top - y - o, K = L < c && $ > L, j = Math.max(60, Math.min(c, K ? $ : L));
  t.style.overflowY = "auto", t.style.overscrollBehavior = "contain", t.style.position = "absolute", t.style.left = "0", t.style.width = "100%", t.style.maxHeight = j + "px", K ? (t.style.top = "auto", t.style.bottom = "calc(100% + 4px)") : (t.style.top = "calc(100% + 4px)", t.style.bottom = "auto"), t.style.marginTop = "0", t.style.marginBottom = "0";
}
function Fi(e) {
  var t;
  return ((t = e.textContent) == null ? void 0 : t.replace(/\s*×$/, "").trim()) || "";
}
function Ri(e, t) {
  const n = e;
  if (n[Yn]) return;
  n[Yn] = !0;
  const a = e.querySelector(".custom-select-trigger"), o = e.querySelector(".custom-select-dropdown"), c = e.querySelector(".custom-select-label");
  if (!a || !o || !c) return;
  const h = t.scope ?? document, b = () => h.querySelectorAll(".custom-select.open").forEach((M) => {
    M !== e && M.classList.remove("open");
  });
  a.addEventListener("click", (M) => {
    var $, K;
    M.preventDefault(), M.stopPropagation();
    const L = e.classList.contains("open");
    b(), L ? (e.classList.remove("open"), ($ = t.onOpenChange) == null || $.call(t, !1)) : (e.classList.add("open"), (K = t.onOpenChange) == null || K.call(t, !0), Kn(e), window.addEventListener("resize", () => Kn(e), { once: !0 }));
  }), o.addEventListener("click", (M) => {
    var j, Q;
    const L = M.target, $ = L.closest(".cs-del");
    if ($) {
      M.preventDefault(), M.stopPropagation();
      const P = $.closest(".custom-select-option");
      P && ((j = t.onDelete) == null || j.call(t, P));
      return;
    }
    const K = L.closest(".custom-select-option");
    if (!K) return;
    M.preventDefault(), M.stopPropagation();
    const q = K.getAttribute("data-value") || "";
    if (q === "__custom__" && t.onCustomEntry) {
      t.onCustomEntry(c);
      return;
    }
    o.querySelectorAll(".custom-select-option").forEach((P) => P.classList.remove("selected")), K.classList.add("selected"), c.textContent = Fi(K), e.classList.remove("open"), (Q = t.onOpenChange) == null || Q.call(t, !1), t.onPick(q);
  }), o.addEventListener(
    "wheel",
    (M) => {
      const L = o.scrollTop > 0, $ = o.scrollTop + o.clientHeight < o.scrollHeight - 1;
      (M.deltaY < 0 && L || M.deltaY > 0 && $) && (M.preventDefault(), o.scrollTop += M.deltaY);
    },
    { passive: !1 }
  );
  const y = (M) => {
    var $;
    if (!e.isConnected) {
      document.removeEventListener("click", y);
      return;
    }
    const L = M.target;
    L && e.contains(L) || e.classList.contains("open") && (e.classList.remove("open"), ($ = t.onOpenChange) == null || $.call(t, !1));
  };
  document.addEventListener("click", y);
}
const va = 1, wa = 4, En = 2, Wi = 12e4;
function tn(e) {
  if (typeof e != "number" || !Number.isFinite(e)) return En;
  const t = Math.round(e * 100) / 100;
  return Math.min(wa, Math.max(va, t));
}
function Jn(e) {
  return e.replace(/\s+/g, " ").trim();
}
const zi = /[\u1100-\u11FF\u2E80-\u2EFF\u3000-\u303F\u3040-\u30FF\u3130-\u318F\u3400-\u4DBF\u4E00-\u9FFF\uA960-\uA97F\uAC00-\uD7AF\uF900-\uFAFF\uFE30-\uFE4F\uFF00-\uFFEF]/u, ji = /[\p{P}\p{S}]/u, Hi = /\s/u;
function Bi(e) {
  const t = [];
  let n = "";
  for (const a of e) {
    if (Hi.test(a)) {
      n ? (t.push(n + a), n = "") : t.length && (t[t.length - 1] += a);
      continue;
    }
    if (ji.test(a)) {
      n ? n += a : t.length ? t[t.length - 1] += a : n += a;
      continue;
    }
    if (zi.test(a)) {
      n && (t.push(n), n = ""), t.push(a);
      continue;
    }
    n += a;
  }
  return n && t.push(n), t;
}
function Vi(e, t, n) {
  if (!(e > 0)) return !0;
  const a = tn(t);
  return e * 1e3 / a > n;
}
const Ui = "lunac.pet.look-screen.v1", H = "pet-control", Gi = "pet-chat-send", qi = "pet-chat-reply", Xi = "pet-chat-stop", Yi = "pet-tts-mouth", Cn = 1, $n = 1440, An = 1, Ln = 200, Ki = 6e3, un = 9e4, Be = 1, Ve = 240, Ue = 5, Ge = 600, qe = 1, Xe = 120, Ji = 75, Zi = 400, Qi = 35, tr = 320, er = Ji + Zi + Qi, xa = "lunac.pet.v1", re = "plugin-pet", Zn = 1.1, dn = [
  { id: "ParamAngleX", min: -100, max: 100, labelKey: "pet.param_head_x" },
  { id: "ParamAngleY", min: -100, max: 100, labelKey: "pet.param_head_y" },
  { id: "ParamAngleZ", min: -100, max: 100, labelKey: "pet.param_head_z" },
  { id: "ParamEyeLOpen", min: 0, max: 100, labelKey: "pet.param_eye_l" },
  { id: "ParamEyeROpen", min: 0, max: 100, labelKey: "pet.param_eye_r" },
  { id: "ParamMouthOpenY", min: 0, max: 100, labelKey: "pet.param_mouth" },
  { id: "ParamBodyAngleX", min: -100, max: 100, labelKey: "pet.param_body_x" },
  { id: "ParamBodyAngleZ", min: -100, max: 100, labelKey: "pet.param_body_z" },
  { id: "ParamBreath", min: 0, max: 100, labelKey: "pet.param_breath" }
], ze = {
  image: "",
  model: "",
  scale: 1,
  offsetX: 0,
  offsetY: 0,
  rotation: 0,
  clickThrough: !1,
  expressions: {},
  params: {},
  paramKinds: {},
  idleMotions: {},
  hotkeyStates: {},
  proactive: { enabled: !1, intervalMin: 30, dailyCap: 20, date: "", used: 0, autoShot: !1, autoShotMin: 5, screenWatch: !1, screenWatchSec: 20, screenDiff: 12 },
  tts: !0,
  speechRate: En
};
function A() {
  try {
    const e = localStorage.getItem(xa);
    if (!e) return { ...ze };
    const t = JSON.parse(e), n = {};
    if (t.expressions && typeof t.expressions == "object")
      for (const [q, j] of Object.entries(t.expressions))
        q && typeof j == "string" && (n[q] = j);
    const a = {};
    if (t.params && typeof t.params == "object")
      for (const [q, j] of Object.entries(t.params)) {
        if (!q || !j || typeof j != "object") continue;
        const Q = {};
        for (const [P, R] of Object.entries(j))
          P && typeof R == "number" && Number.isFinite(R) && (Q[P] = R);
        Object.keys(Q).length && (a[q] = Q);
      }
    const o = {}, c = t.paramKinds;
    if (c && typeof c == "object")
      for (const [q, j] of Object.entries(c)) {
        if (!q || !j || typeof j != "object") continue;
        const Q = {};
        for (const [P, R] of Object.entries(j))
          P && (R === "switch" || R === "range") && (Q[P] = R);
        Object.keys(Q).length && (o[q] = Q);
      }
    const h = {}, b = t.idleMotions;
    if (b && typeof b == "object")
      for (const [q, j] of Object.entries(b)) {
        if (!q || !Array.isArray(j)) continue;
        const Q = j.filter((P) => typeof P == "string" && P.trim().length > 0);
        Q.length && (h[q] = Q);
      }
    const y = {}, M = t.hotkeyStates;
    if (M && typeof M == "object")
      for (const [q, j] of Object.entries(M)) {
        if (!q || !Array.isArray(j)) continue;
        const Q = j.filter((P) => typeof P == "string" && P.trim().length > 0);
        Q.length && (y[q] = Q);
      }
    const L = ze.proactive, $ = t.proactive, K = $ && typeof $ == "object" ? {
      enabled: $.enabled === !0,
      intervalMin: typeof $.intervalMin == "number" && Number.isFinite($.intervalMin) ? Math.min($n, Math.max(Cn, Math.round($.intervalMin))) : L.intervalMin,
      dailyCap: typeof $.dailyCap == "number" && Number.isFinite($.dailyCap) ? Math.min(Ln, Math.max(An, Math.round($.dailyCap))) : L.dailyCap,
      date: typeof $.date == "string" ? $.date : "",
      used: typeof $.used == "number" && Number.isFinite($.used) && $.used > 0 ? Math.floor($.used) : 0,
      // 「自动抓屏」/「屏幕变化触发」两个子开关：**只有显式 true 才算开**（默认关，隐私红线）。
      autoShot: $.autoShot === !0,
      autoShotMin: typeof $.autoShotMin == "number" && Number.isFinite($.autoShotMin) ? Math.min(Ve, Math.max(Be, Math.round($.autoShotMin))) : L.autoShotMin,
      screenWatch: $.screenWatch === !0,
      screenWatchSec: typeof $.screenWatchSec == "number" && Number.isFinite($.screenWatchSec) ? Math.min(Ge, Math.max(Ue, Math.round($.screenWatchSec))) : L.screenWatchSec,
      screenDiff: typeof $.screenDiff == "number" && Number.isFinite($.screenDiff) ? Math.min(Xe, Math.max(qe, Math.round($.screenDiff))) : L.screenDiff
    } : { ...L };
    return {
      image: typeof t.image == "string" ? t.image : "",
      model: typeof t.model == "string" ? t.model : "",
      scale: typeof t.scale == "number" && t.scale >= ha && t.scale <= ma ? t.scale : 1,
      offsetX: typeof t.offsetX == "number" && Number.isFinite(t.offsetX) ? t.offsetX : 0,
      offsetY: typeof t.offsetY == "number" && Number.isFinite(t.offsetY) ? t.offsetY : 0,
      rotation: typeof t.rotation == "number" && Number.isFinite(t.rotation) ? Math.max(-180, Math.min(180, t.rotation)) : 0,
      clickThrough: t.clickThrough === !0,
      expressions: n,
      params: a,
      paramKinds: o,
      idleMotions: h,
      hotkeyStates: y,
      proactive: K,
      // 语音朗读：**默认 true**（老配置缺这个字段 ⇒ 回落到 true）。
      tts: typeof t.tts == "boolean" ? t.tts : !0,
      // 速率：越界 / 非法回落默认（`clampRate` 同一套夹取口径）。
      speechRate: tn(typeof t.speechRate == "number" ? t.speechRate : En)
    };
  } catch {
    return { ...ze };
  }
}
function Y(e) {
  try {
    localStorage.setItem(xa, JSON.stringify(e));
  } catch {
  }
}
function _a() {
  const e = /* @__PURE__ */ new Date(), t = (n) => String(n).padStart(2, "0");
  return `${e.getFullYear()}-${t(e.getMonth() + 1)}-${t(e.getDate())}`;
}
function Pt() {
  const e = A().proactive;
  return e.date !== _a() ? 0 : e.used > 0 ? e.used : 0;
}
function fn() {
  const e = A(), t = _a(), n = (e.proactive.date === t && e.proactive.used || 0) + 1;
  return Y({ ...e, proactive: { ...e.proactive, date: t, used: n } }), n;
}
function nr(e, t) {
  if (e.length !== t.length || e.length === 0) return 0;
  let n = 0;
  for (let a = 0; a < e.length; a++) n += Math.abs(e[a] - t[a]);
  return n / e.length;
}
function hn() {
  const e = /* @__PURE__ */ new Date(), t = new Date(e.getFullYear(), e.getMonth(), e.getDate() + 1, 0, 0, 5);
  return Math.max(1e3, t.getTime() - Date.now());
}
function I(e) {
  return e.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
function en(e) {
  return w(e ? "pet.through_on" : "pet.through_off");
}
function yt(e, t) {
  d("log_frontend", {
    level: "error",
    message: `[pet window] ${e}: ${t instanceof Error ? t.message : String(t)}`
  }).catch(() => {
  });
}
function ka() {
  try {
    return It().label || "";
  } catch {
    return "";
  }
}
function Et() {
  return location.pathname.endsWith("plugin.html") && ka() === re;
}
function Qn() {
  return ka() === `${re}-settings`;
}
let De = null;
function ar() {
  return De || (De = (async () => (await fi(), await import(Ft(await di()))))().catch((e) => {
    throw De = null, e instanceof Error ? e : new Error(String(e));
  })), De;
}
function Sa(e, t) {
  return `${w(e)}：${t ? "开" : "关"}`;
}
function se(e) {
  return e ? "开" : "关";
}
function ir(e) {
  const t = e.proactive, n = Pt(), a = w("pet.proactive_usage", { used: String(n), cap: String(t.dailyCap) }), o = n >= t.dailyCap ? `${a} · ${w("pet.proactive_reached")}` : a;
  return `
  <div class="pet-proactive" id="pet-proactive">
    <div class="pet-debug-title">${w("pet.proactive_title")}</div>
    <div class="pet-row">
      <span class="pet-label">${w("pet.proactive_enable")}</span>
      <button type="button" id="pet-proactive-enabled" class="pet-btn pet-btn-toggle${t.enabled ? " on" : ""}" aria-pressed="${t.enabled ? "true" : "false"}">${I(se(t.enabled))}</button>
    </div>
    <div class="pet-row">
      <span class="pet-label">${w("pet.proactive_interval")}</span>
      <input type="text" id="pet-proactive-interval" class="pet-param-num" inputmode="numeric" autocomplete="off" spellcheck="false" value="${t.intervalMin}" aria-label="${I(w("pet.proactive_interval"))}">
      <span class="pet-val">${w("pet.proactive_minute")}</span>
    </div>
    <div class="pet-row">
      <span class="pet-label">${w("pet.proactive_cap")}</span>
      <input type="text" id="pet-proactive-cap" class="pet-param-num" inputmode="numeric" autocomplete="off" spellcheck="false" value="${t.dailyCap}" aria-label="${I(w("pet.proactive_cap"))}">
      <span class="pet-val">${w("pet.proactive_cap_unit")}</span>
    </div>
    <div class="pet-row">
      <span class="pet-label">${w("pet.proactive_autoshot")}</span>
      <button type="button" id="pet-autoshot-enabled" class="pet-btn pet-btn-toggle${t.autoShot ? " on" : ""}" aria-pressed="${t.autoShot ? "true" : "false"}">${I(se(t.autoShot))}</button>
      <input type="text" id="pet-autoshot-min" class="pet-param-num" inputmode="numeric" autocomplete="off" spellcheck="false" value="${t.autoShotMin}" aria-label="${I(w("pet.proactive_autoshot"))}">
      <span class="pet-val">${w("pet.proactive_minute")}</span>
    </div>
    <div class="pet-row">
      <span class="pet-label">${w("pet.proactive_screenwatch")}</span>
      <button type="button" id="pet-screenwatch-enabled" class="pet-btn pet-btn-toggle${t.screenWatch ? " on" : ""}" aria-pressed="${t.screenWatch ? "true" : "false"}">${I(se(t.screenWatch))}</button>
      <input type="text" id="pet-watch-sec" class="pet-param-num" inputmode="numeric" autocomplete="off" spellcheck="false" value="${t.screenWatchSec}" aria-label="${I(w("pet.proactive_watch_sec"))}">
      <span class="pet-val">${w("pet.proactive_second")}</span>
    </div>
    <div class="pet-row">
      <span class="pet-label">${w("pet.proactive_sensitivity")}</span>
      <input type="text" id="pet-watch-diff" class="pet-param-num" inputmode="numeric" autocomplete="off" spellcheck="false" value="${t.screenDiff}" aria-label="${I(w("pet.proactive_sensitivity"))}">
    </div>
    <div class="pet-note" id="pet-proactive-hint">${I(w("pet.proactive_shot_hint"))}</div>
    <div class="pet-note" id="pet-proactive-usage">${I(o)}</div>
  </div>`;
}
const Ma = 0.5, Ea = 2, xn = 1, Ca = 0, $a = 1, _n = 1;
function ta(e) {
  return typeof e != "number" || !Number.isFinite(e) ? xn : Math.min(Ea, Math.max(Ma, Math.round(e * 100) / 100));
}
function ea(e) {
  return typeof e != "number" || !Number.isFinite(e) ? _n : Math.min($a, Math.max(Ca, Math.round(e * 100) / 100));
}
function rr(e) {
  return `
  <div class="pet-tts" id="pet-tts">
    <div class="pet-debug-title">${w("pet.tts_title")}</div>
    <div class="pet-row">
      <button type="button" id="pet-tts-enabled" class="pet-btn pet-btn-toggle${e.tts ? " on" : ""}" aria-pressed="${e.tts ? "true" : "false"}">${I(Sa("pet.tts_enable", e.tts))}</button>
    </div>
    <div class="pet-row">
      <span class="pet-label">${I(w("pet.tts_rate_label"))}</span>
      <input type="range" id="pet-tts-rate" class="pet-range" min="${va}" max="${wa}" step="0.5" value="${e.speechRate}" aria-label="${I(w("pet.tts_rate_label"))}">
      <span class="pet-val" id="pet-tts-rate-val">${e.speechRate}</span>
    </div>
    <div class="pet-row">
      <span class="pet-label">${I(w("pet.tts_speed_label"))}</span>
      <input type="range" id="pet-tts-speed" class="pet-range" min="${Ma}" max="${Ea}" step="0.1" value="${xn}" aria-label="${I(w("pet.tts_speed_label"))}">
      <span class="pet-val" id="pet-tts-speed-val">${xn.toFixed(1)}×</span>
    </div>
    <div class="pet-row">
      <span class="pet-label">${I(w("pet.tts_volume_label"))}</span>
      <input type="range" id="pet-tts-volume" class="pet-range" min="${Ca}" max="${$a}" step="0.05" value="${_n}" aria-label="${I(w("pet.tts_volume_label"))}">
      <span class="pet-val" id="pet-tts-volume-val">${Math.round(_n * 100)}%</span>
    </div>
    <div class="pet-tts-voice">
      <span class="pet-label">${I(w("pet.tts_voice_label"))}</span>
      <input type="text" id="pet-tts-reftext" class="pet-tts-text" autocomplete="off" spellcheck="false" placeholder="${I(w("pet.tts_ref_text_ph"))}" aria-label="${I(w("pet.tts_voice_label"))}">
      <div class="pet-row">
        <button type="button" id="pet-tts-addfile" class="pet-btn pet-btn-primary">${I(w("pet.tts_add_audio"))}</button>
        <button type="button" id="pet-tts-preview" class="pet-btn">${I(w("pet.tts_preview"))}</button>
      </div>
      <div class="pet-note" id="pet-tts-status"></div>
      <div class="pet-note" id="pet-tts-msg"></div>
    </div>
  </div>`;
}
const or = {
  motion: "播动作",
  chain: "动作链",
  // VTS 侧对应表情的动作类型叫 “Expression on/off” —— 这里同样按**开关**语义（可叠加、再点关闭）。
  expression: "表情开关",
  param: "设参数",
  artmesh: "ArtMesh 显隐",
  artmeshColor: "ArtMesh 染色",
  part: "Part 显隐",
  physics: "开关物理"
}, sr = '<svg viewBox="0 0 16 16" width="13" height="13" aria-hidden="true" focusable="false"><path d="M8 1.6 11.2 5.2H4.8Z" fill="currentColor"/><path d="M8 14.4 4.8 10.8h6.4Z" fill="currentColor"/></svg>';
function lr() {
  return `
  <div class="pet-hotkeys" id="pet-hotkeys">
    <div class="pet-row">
      <button type="button" id="pet-hk-import" class="pet-btn pet-btn-primary" title="以模型文件夹为准重建热键表：优先读同目录 vtube.json 里的作者热键，没有就递归扫文件夹里的「中文名.exp3.json」。会自动分配默认键并落盘；按键仅供 AI 触发，本地不做按键监听。">重新导入（模型文件夹）</button>
    </div>
    <div class="pet-hk-list" id="pet-hk-list"></div>
    <div class="pet-note" id="pet-hk-msg"></div>
  </div>`;
}
function cr() {
  return `
  <div class="pet-motions" id="pet-motions">
    <!-- **动作链**（2026-10-10 用户口径：与「恢复默认」一样放在动作页**最上面**）：
         把多个动作排进一条时间线，每步各设「循环播放时长 / 硬停秒」。 -->
    <div class="pet-chains" id="pet-chains">
      <div class="pet-row">
        <button type="button" id="pet-chain-add" class="pet-btn pet-btn-primary" title="新建一条动作链：把多个动作排进一条时间线，每个动作各设循环播放时长与硬停秒。可在「热键」页把动作链绑成热键，AI 也可按链名触发。">新建动作链</button>
      </div>
      <div class="pet-chain-list" id="pet-chain-list"></div>
      <div class="pet-note" id="pet-chain-msg"></div>
    </div>
    <div class="pet-row">
      <button type="button" id="pet-mo-add" class="pet-btn pet-btn-primary" title="在模型文件夹里生成一个覆盖本模型全部参数的 *.motion3.json 模板（1 秒 / 30fps / 循环），交给 AI 去编曲线。">新建动作（motion3 模板）</button>
    </div>
    <div class="pet-mo-list" id="pet-mo-list"></div>
    <div class="pet-note" id="pet-mo-msg"></div>
  </div>`;
}
const Aa = "lunac.pet.coreids.v1.";
function pr(e) {
  const t = { parameters: [], drawables: [], parts: [], parameterRanges: {} };
  try {
    const n = localStorage.getItem(Aa + e.toLowerCase());
    if (!n) return t;
    const a = JSON.parse(n);
    return {
      parameters: Array.isArray(a.parameters) ? a.parameters : [],
      drawables: Array.isArray(a.drawables) ? a.drawables : [],
      parts: Array.isArray(a.parts) ? a.parts : [],
      parameterRanges: a.parameterRanges && typeof a.parameterRanges == "object" ? a.parameterRanges : {}
    };
  } catch {
    return t;
  }
}
async function Tn(e) {
  const t = pr(e);
  try {
    const n = await ke(e), a = n == null ? void 0 : n.coreIds;
    if (a && (a.parameters.length || a.drawables.length || a.parts.length)) return a;
    if (t.parameters.length || t.drawables.length || t.parts.length) {
      const o = n ?? Mn(e);
      o.coreIds = t;
      const c = A().params[e];
      !Object.keys(o.params).length && c && typeof c == "object" && (o.params = { ...c }), await He(e, o);
    }
  } catch (n) {
    console.warn("[pet] 读/播种 lunac.params.json 失败", n);
  }
  return t;
}
let be = /* @__PURE__ */ new Map(), dt = [], Ot = {
  motions: [],
  expressions: [],
  expressionFiles: {},
  parameters: [],
  drawables: [],
  parts: []
}, le = /* @__PURE__ */ new Set();
function wt(e) {
  const t = document.getElementById("pet-hk-msg");
  t && (t.textContent = e);
}
let Fe = null;
function Se() {
  const e = A().model.trim();
  e && (Fe && clearTimeout(Fe), Fe = setTimeout(() => {
    Fe = null, A().model.trim() === e && Ze(e, dt).catch(
      (t) => wt("保存热键失败：" + (t instanceof Error ? t.message : String(t)))
    );
  }, 400));
}
function La(e) {
  let t = !1;
  return e.forEach((n, a) => {
    n.keys || (n.keys = vi(a), t = !0);
  }), t;
}
async function ur(e) {
  const t = [], n = /* @__PURE__ */ new Set();
  try {
    for (const a of await oe(e)) {
      const o = a.action;
      if (o.type !== "expression" || !o.file) continue;
      const c = o.file.toLowerCase();
      n.has(c) || (n.add(c), t.push({ name: o.target || a.name, file: o.file }));
    }
  } catch {
  }
  return t;
}
function na(e) {
  return e.toLowerCase().replace(/\//g, "\\");
}
async function dr(e, t) {
  const n = t.filter((h) => h.action.type === "expression" && !!h.action.file);
  if (!n.length) return !1;
  let a;
  try {
    a = await pa(e);
  } catch {
    return !1;
  }
  const o = /* @__PURE__ */ new Map();
  for (const h of a) h.file && o.set(na(h.file), h.id);
  let c = !1;
  for (const h of n) {
    if (h.action.type !== "expression" || !h.action.file) continue;
    const b = o.get(na(h.action.file));
    b && b !== h.action.target && (h.action.target = b, c = !0);
  }
  return c;
}
async function fr(e) {
  const t = /* @__PURE__ */ new Set();
  try {
    const n = [];
    for (const a of await oe(e))
      a.action.type === "expression" && a.action.file && n.push(a.action.file);
    await Promise.all(
      n.map(async (a) => {
        for (const o of await ga(a)) t.add(o.id);
      })
    );
  } catch {
  }
  return t;
}
async function aa(e) {
  const t = Ke(e);
  try {
    const n = await d("scan_model_folder", { dir: t });
    return { dir: t, vtube: (n.vtube ?? [])[0] ?? "", cdi3: (n.cdi3 ?? [])[0] ?? "" };
  } catch {
    return { dir: t, vtube: "", cdi3: "" };
  }
}
const hr = { parameters: {} };
async function mr(e, t) {
  var n;
  try {
    const a = await Je(e), o = [];
    for (const c of Object.values(((n = a.FileReferences) == null ? void 0 : n.Motions) ?? {}))
      for (const h of c ?? [])
        h != null && h.File && o.push(Zt(t, h.File));
    return o.length ? await Ci(o) : /* @__PURE__ */ new Map();
  } catch {
    return /* @__PURE__ */ new Map();
  }
}
async function kn(e, t, n) {
  let a = [];
  if (n && (a = (await _i(n)).map((c) => Ei(c, e)).filter((c) => !!c)), !a.length) {
    let o = [];
    try {
      o = await d("list_exp3_files", { dir: e });
    } catch {
      o = [];
    }
    a = o.filter((c) => typeof (c == null ? void 0 : c.path) == "string" && c.path).map((c) => {
      const h = (c.name || "").trim() || "表情";
      return vn(h, "", { type: "expression", target: h, mode: "set", file: c.path });
    });
  }
  return a.length ? (La(a), await dr(t, a), await Ze(t, a), dt = a, Dt(), a.length) : 0;
}
let ot = [], V = [];
const ia = "lunac_";
function vt(e) {
  const t = document.getElementById("pet-mo-msg");
  t && (t.textContent = e);
}
function Ta(e) {
  const t = e ? A().idleMotions[e] ?? [] : [];
  return new Set(t.map((n) => n.toLowerCase()));
}
function ra() {
  const e = A().model.trim();
  if (!e) return;
  const t = A(), n = t.idleMotions[e];
  if (!n || !n.length) return;
  const a = new Set(ot.map((h) => h.name.toLowerCase())), o = n.filter((h) => a.has(h.toLowerCase()));
  if (o.length === n.length) return;
  const c = { ...t.idleMotions };
  o.length ? c[e] = o : delete c[e], Y({ ...t, idleMotions: c }), Ye();
}
function Ye() {
  const e = document.getElementById("pet-mo-list");
  if (!e) return;
  if (!ot.length) {
    e.innerHTML = '<div class="pet-note">模型文件夹里还没有 *.motion3.json —— 点「新建动作」生成一个模板。</div>';
    return;
  }
  const t = Ta(A().model.trim());
  e.innerHTML = ot.map((n, a) => {
    const o = t.has(n.name.toLowerCase());
    return `<div class="pet-mo-row" data-mo-i="${a}">
      <input class="pet-mo-name" data-mo-name="${a}" spellcheck="false" value="${I(n.name)}" title="${I(n.path)}">
      <button type="button" class="pet-btn pet-btn-toggle pet-mo-idle${o ? " on" : ""}" data-mo-idle="${a}" aria-pressed="${o ? "true" : "false"}" title="循环播放：勾上后，模型闲下来（没有别的动作在播）时会按顺序轮流播放它；是否循环由该文件自己的 Meta.Loop 决定">循环播放：${o ? "开" : "关"}</button>
      <button type="button" class="pet-btn pet-mo-run" data-mo-run="${a}">播放</button>
      <button type="button" class="pet-btn pet-mo-del" data-mo-del="${a}">删除</button>
      <div class="pet-chain-bar pet-mo-bar" data-bar-idx="${a}"><i></i><span class="pet-mo-bar-t">${I(n.name)}</span></div>
    </div>`;
  }).join("");
}
async function ge() {
  const e = A().model.trim();
  if (!e) {
    ot = [], Ye(), V = [], mt(), vt("先选一个 Live2D 模型 —— 「更换模型」里选模型文件夹。");
    return;
  }
  ot = await ve(e), Ye(), wr(), vt(ot.length ? `共 ${ot.length} 个动作文件。` : "这个模型文件夹里没扫到 *.motion3.json。");
}
function Na(e) {
  const t = document.getElementById("pet-chain-msg");
  t && (t.textContent = e);
}
function br(e) {
  return ot.findIndex((t) => t.path.toLowerCase() === e.toLowerCase());
}
let we = /* @__PURE__ */ new Set();
const gr = '<svg viewBox="0 0 16 16" width="11" height="11" aria-hidden="true" focusable="false"><path d="M6 3.2 10.8 8 6 12.8" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>', yr = '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><g opacity="0.28" transform="translate(-0.7,-0.7)" stroke-width="1.6"><rect x="5" y="5" width="14" height="14" rx="2.5"/></g><rect x="5" y="5" width="14" height="14" rx="2.5"/><circle cx="8.6" cy="8.6" r="0.9" fill="currentColor" stroke="none"/></svg>';
function vr(e) {
  const t = e.file.split(/[\\/]/).pop() || "(未选)", n = e.stopSec > 0 ? `${e.stopSec.toFixed(1)}s` : "不限";
  return `${t} · 循环 ${e.loopSec.toFixed(1)}s · 硬停 ${n}`;
}
async function Ia(e) {
  var t;
  if (!e) return null;
  try {
    const n = await fetch(Ft(e));
    if (!n.ok) return null;
    const a = await n.json(), o = Number((t = a == null ? void 0 : a.Meta) == null ? void 0 : t.Duration);
    return Number.isFinite(o) && o > 0 ? Math.min(3600, Math.max(0.1, o)) : null;
  } catch {
    return null;
  }
}
function mt() {
  const e = document.getElementById("pet-chain-list");
  if (e) {
    if (!V.length) {
      e.innerHTML = '<div class="pet-note">还没有动作链 —— 点「新建动作链」，再把动作文件排进时间线。</div>';
      return;
    }
    e.innerHTML = V.map((t, n) => {
      const a = we.has(t.id), o = t.steps.map((h, b) => {
        const y = br(h.file), M = h.file.split(/[\\/]/).pop() || "(未选)", L = ot.length ? ot.map((K) => ({ value: K.path, label: K.name, selected: K.path.toLowerCase() === h.file.toLowerCase() })) : [{ value: "", label: "（没有动作文件）", selected: !0 }], $ = Sn(h);
        return `<div class="pet-chain-step">
          <div class="pet-chain-fields">
            ${wn("", L, `data-chain-step-file="${n}:${b}"`)}
            <label class="pet-chain-t">循环<input class="pet-chain-num" type="number" min="0.1" max="3600" step="0.1" data-chain-step-loop="${n}:${b}" value="${h.loopSec}">s</label>
            <label class="pet-chain-t">硬停<input class="pet-chain-num" type="number" min="0" max="3600" step="0.1" data-chain-step-stop="${n}:${b}" value="${h.stopSec}">s</label>
            <button type="button" class="pet-btn pet-chain-del" data-chain-step-del="${n}:${b}" title="删掉这一步">×</button>
          </div>
          <div class="pet-chain-bar" data-bar-chain="${I(t.id)}" data-bar-idx="${y}"><i></i><span>${I(M)} · ${$.toFixed(1)}s</span></div>
        </div>`;
      }).join(""), c = t.steps.length ? t.steps.map(vr).join("  ·  ") : "（还没有步骤）";
      return `<div class="pet-chain${a ? " collapsed" : ""}" data-chain-i="${n}">
      <div class="pet-chain-head">
        <button type="button" class="pet-btn pet-chain-toggle${a ? "" : " on"}" data-chain-toggle="${n}" aria-expanded="${a ? "false" : "true"}" title="${a ? "展开这条链" : "收起这条链"}">${gr}</button>
        <input class="pet-chain-name" data-chain-name="${n}" spellcheck="false" value="${I(t.name)}">
        <span class="pet-chain-total">共 ${Pi(t).toFixed(1)}s</span>
        <button type="button" class="pet-btn pet-btn-toggle pet-chain-loopbtn${t.loop ? " on" : ""}" data-chain-loop="${n}" aria-pressed="${t.loop ? "true" : "false"}" title="整链循环：整条链播完从头再来；关闭则播完即停（每步自己的循环 / 硬停照旧生效）">整链循环：${t.loop ? "开" : "关"}</button>
        <button type="button" class="pet-btn pet-btn-primary pet-chain-run" data-chain-run="${I(t.id)}">播放</button>
        <button type="button" class="pet-btn pet-chain-del" data-chain-del="${n}">删除</button>
      </div>
      <div class="pet-chain-summary">${I(c)}</div>
      <div class="pet-chain-steps">${o}</div>
      <button type="button" class="pet-btn" data-chain-step-add="${n}">添加步骤</button>
    </div>`;
    }).join(""), Da(e);
  }
}
async function wr() {
  const e = A().model.trim();
  if (!e) {
    V = [], mt();
    return;
  }
  V = await We(e), mt(), Dt(), Na(V.length ? `共 ${V.length} 条动作链。` : "");
}
async function Tt() {
  const e = A().model.trim();
  if (e)
    try {
      await Ii(e, V);
    } catch (t) {
      Na("保存动作链失败：" + (t instanceof Error ? t.message : String(t)));
    }
}
function Pa(e, t, n) {
  !V[e] || !Number.isInteger(t) || (async () => {
    const o = await Ia(n), c = V[e];
    if (!c) return;
    const h = c.steps.map(
      (b, y) => y === t ? { ...b, file: n, ...o !== null ? { loopSec: o } : {} } : b
    );
    V = V.map((b, y) => y === e ? { ...b, steps: h } : b), mt(), Tt();
  })();
}
function xr(e, t, n) {
  const a = e ? `[data-bar-chain="${CSS.escape(e)}"][data-bar-idx="${t}"]` : `.pet-mo-row [data-bar-idx="${t}"]`;
  document.querySelectorAll(a).forEach((o) => {
    const c = o.querySelector("i");
    c && (c.style.width = n === null ? "0%" : `${Math.round(n * 100)}%`);
  });
}
async function _r(e) {
  const t = await Tn(e);
  if (!t.parameters.length) return null;
  const n = t.parameters.map((a) => {
    const o = t.parameterRanges[a], c = o && Number.isFinite(o.def) ? o.def : 0;
    return { Target: "Parameter", Id: a, Segments: [0, c, 0, 1, c] };
  });
  return JSON.stringify(
    {
      Version: 3,
      Meta: {
        Duration: 1,
        Fps: 30,
        Loop: !0,
        AreBeziersRestricted: !0,
        CurveCount: n.length,
        TotalSegmentCount: n.length,
        TotalPointCount: n.length * 2,
        UserDataCount: 0,
        TotalUserDataSize: 0
      },
      Curves: n,
      UserData: []
    },
    null,
    2
  );
}
function kr(e) {
  switch (e) {
    case "motion":
      return { type: "motion", group: "", index: 0 };
    case "chain":
      return { type: "chain", id: "" };
    case "param":
      return { type: "param", id: "", value: 0, mode: "set" };
    case "artmesh":
      return { type: "artmesh", id: "", value: 0 };
    case "artmeshColor":
      return { type: "artmeshColor", id: "", color: "#ffffff" };
    case "part":
      return { type: "part", id: "", value: 0 };
    case "physics":
      return { type: "physics", enabled: !1 };
    default:
      return { type: "expression", target: "", mode: "set" };
  }
}
function Oa(e, t, n) {
  const a = () => Number(n) || 0;
  e.type === "motion" ? t === "group" ? e.group = n : t === "index" && (e.index = Math.max(0, Math.round(a()))) : e.type === "chain" ? t === "id" && (e.id = n) : e.type === "expression" ? t === "target" ? (e.target = n, e.file = Ot.expressionFiles[n] || "") : t === "mode" && (e.mode = n === "clear" ? "clear" : "set") : e.type === "param" ? t === "id" ? e.id = n : t === "mode" ? e.mode = n === "add" ? "add" : "set" : t === "value" && (e.value = a()) : e.type === "artmesh" ? t === "id" ? e.id = n : t === "value" && (e.value = Math.min(1, Math.max(0, a()))) : e.type === "artmeshColor" ? t === "id" ? e.id = n : t === "color" && (e.color = Nn(n)) : e.type === "part" ? t === "id" ? e.id = n : t === "value" && (e.value = Math.min(1, Math.max(0, a()))) : e.type === "physics" && t === "enabled" && (e.enabled = n === "1");
}
function Nn(e) {
  const t = (e || "").trim().replace(/^#/, "").toLowerCase();
  return /^[0-9a-f]{3}$/.test(t) ? "#" + t.split("").map((n) => n + n).join("") : /^[0-9a-f]{6}$/.test(t) ? "#" + t : "#ffffff";
}
function Sr(e) {
  const t = Nn(e).slice(1);
  return {
    r: parseInt(t.slice(0, 2), 16) / 255,
    g: parseInt(t.slice(2, 4), 16) / 255,
    b: parseInt(t.slice(4, 6), 16) / 255
  };
}
function ye(e, t) {
  const n = t && !e.includes(t) ? [t, ...e] : e;
  return (n.length ? n : [""]).map((o) => `<option value="${I(o)}"${o === t ? " selected" : ""}>${I(o || "（无可用项）")}</option>`).join("");
}
function Mr(e, t) {
  const n = t && !e.includes(t) ? [t, ...e] : e;
  return (n.length ? n : [""]).map((o) => ({ value: o, label: o || "（无可用项）", selected: o === t }));
}
function Da(e) {
  e.querySelectorAll(".custom-select").forEach((t) => {
    Ri(t, {
      scope: document,
      onPick: (n) => {
        const a = t.closest(".pet-hk-row");
        if (a) {
          const c = dt.find((b) => b.id === a.dataset.hkId);
          if (!c) return;
          const h = t.getAttribute("data-hk-field");
          h === "type" ? (c.action = kr(n), Dt(), Se()) : h === "target" && (Oa(c.action, "target", n), Se());
          return;
        }
        const o = t.getAttribute("data-chain-step-file");
        if (o) {
          const [c, h] = o.split(":").map((b) => Number.parseInt(b, 10));
          Pa(c, h, n);
        }
      }
    });
  });
}
function Dt() {
  const e = document.getElementById("pet-hk-list");
  e && (e.innerHTML = dt.map((t) => {
    const n = t.action, a = bi.map(
      (c) => ({ value: c, label: or[c], selected: c === n.type })
    );
    let o = "";
    if (n.type === "motion")
      o = `<select data-hk-field="group">${ye(Ot.motions.map((c) => c.group), n.group)}</select><input class="pet-hk-num" data-hk-field="index" inputmode="numeric" value="${n.index}">`;
    else if (n.type === "expression")
      o = wn("", Mr(Ot.expressions, n.target), 'data-hk-field="target" title="表情对象（模型可用的表情）"');
    else if (n.type === "chain") {
      const c = V.map((h) => ({ id: h.id, name: h.name }));
      n.id && !c.some((h) => h.id === n.id) && c.unshift({ id: n.id, name: "（已删除的动作链）" }), o = c.length ? `<select data-hk-field="id">${c.map((h) => `<option value="${I(h.id)}"${h.id === n.id ? " selected" : ""}>${I(h.name || h.id)}</option>`).join("")}</select>` : '<span class="pet-hk-target">（还没有动作链）</span>';
    } else n.type === "param" ? o = `<select data-hk-field="id">${ye(Ot.parameters, n.id)}</select><select data-hk-field="mode"><option value="set"${n.mode === "set" ? " selected" : ""}>设为</option><option value="add"${n.mode === "add" ? " selected" : ""}>加</option></select><input class="pet-hk-num" data-hk-field="value" inputmode="decimal" value="${n.value}">` : n.type === "artmesh" ? o = `<select data-hk-field="id">${ye(Ot.drawables, n.id)}</select><input class="pet-hk-num" data-hk-field="value" inputmode="decimal" value="${n.value}">` : n.type === "artmeshColor" ? o = `<select data-hk-field="id">${ye(Ot.drawables, n.id)}</select><input class="pet-hk-color" type="color" data-hk-field="color" value="${I(Nn(n.color))}" title="点一下选颜色（原色 = #ffffff）">` : n.type === "part" ? o = `<select data-hk-field="id">${ye(Ot.parts, n.id)}</select><input class="pet-hk-num" data-hk-field="value" inputmode="decimal" value="${n.value}">` : o = `<select data-hk-field="enabled"><option value="1"${n.enabled ? " selected" : ""}>开</option><option value="0"${n.enabled ? "" : " selected"}>关</option></select>`;
    return `<div class="pet-hk-row" data-hk-id="${I(t.id)}">
        <input class="pet-hk-name" data-hk-field="name" spellcheck="false" value="${I(t.name)}">
        ${wn("", a, 'data-hk-field="type"')}
        ${o}
        <button type="button" class="pet-btn pet-btn-toggle pet-hk-run${le.has(t.id) ? " on" : ""}" data-hk-run="1" aria-pressed="${le.has(t.id) ? "true" : "false"}">${le.has(t.id) ? "开" : "关"}</button>
        <button type="button" class="pet-btn pet-hk-del" data-hk-del="1">删除</button>
      </div>`;
  }).join(""), Da(e));
}
async function mn() {
  const e = A().model.trim();
  if (!e) {
    dt = [], Dt(), wt("先选一个 Live2D 模型 —— 热键要跟它存在同一个文件夹里。");
    return;
  }
  const t = await Tn(e);
  if (Ot = await ba(e, t), dt = await oe(e), La(dt))
    try {
      await Ze(e, dt);
    } catch {
    }
  Dt(), wt(
    t.parameters.length || t.drawables.length ? "" : "提示：先在主界面「显示桌宠」一次，才能拿到该模型的参数 / ArtMesh / Part 清单（现在只有动作、表情、物理可选）。"
  );
}
function Er(e) {
  return `
<div class="pet-console">
  <div class="pet-row pet-row-main">
    <button id="pet-toggle" class="pet-btn pet-btn-primary">显示桌宠</button>
    <button id="pet-change" class="pet-btn">更换模型…</button>
    <button id="pet-clear" class="pet-btn" ${!!e.model.trim() || !!e.image.trim() ? "" : "hidden"}>取消配置</button>
    <button type="button" id="pet-through" class="pet-btn pet-btn-toggle${e.clickThrough ? " on" : ""}" aria-pressed="${e.clickThrough ? "true" : "false"}">${I(en(e.clickThrough))}</button>
  </div>
  <div class="pet-row">
    <span class="pet-label">形象大小</span>
    <input type="range" id="pet-scale" class="pet-range" min="40" max="800" step="5" value="${Math.round(e.scale * 100)}">
    <span class="pet-val" id="pet-scale-val">${Math.round(e.scale * 100)}%</span>
  </div>
  <div class="pet-row">
    <span class="pet-label">旋转角度</span>
    <input type="range" id="pet-rot" class="pet-range" min="-180" max="180" step="1" value="${Math.round(e.rotation)}">
    <span class="pet-val" id="pet-rot-val">${Math.round(e.rotation)}°</span>
  </div>
  <div class="pet-file" id="pet-file"></div>
  <div class="pet-note">该插件只提供 Live2D 模型入口。</div>
  <div class="pet-note">${w("pet.hint_interactions")}</div>
  ${ir(e)}
  ${rr(e)}
  <div class="pet-tabs" id="pet-tabs">
    <button type="button" class="pet-tab on" data-pet-tab="debug">${I(w("pet.debug_title"))}</button>
    <button type="button" class="pet-tab" data-pet-tab="hotkey">${I(w("pet.hotkey_title"))}</button>
    <button type="button" class="pet-tab" data-pet-tab="motion">${I(w("pet.motions_title"))}</button>
  </div>
  <div class="pet-tabpage" data-pet-page="debug">
    <div class="pet-row pet-reset-row">
      <button type="button" id="pet-reset-debug" class="pet-btn" title="把该模型调过的参数全部恢复默认（会清掉你的调整）">恢复默认</button>
    </div>
    <div class="pet-debug" id="pet-debug">
      <div class="pet-debug-note" id="pet-debug-note" hidden></div>
      <div class="pet-debug-body" id="pet-debug-body"></div>
    </div>
  </div>
  <div class="pet-tabpage" data-pet-page="hotkey" hidden>
    <div class="pet-row pet-reset-row">
      <button type="button" id="pet-reset-hotkeys" class="pet-btn" title="清空当前热键表（可再点「重新导入」重建）">恢复默认</button>
    </div>
    ${lr()}
  </div>
  <div class="pet-tabpage" data-pet-page="motion" hidden>
    <div class="pet-row pet-reset-row">
      <button type="button" id="pet-reset-motions" class="pet-btn" title="删掉本模型文件夹里由本插件生成的 *.motion3.json">恢复默认</button>
    </div>
    ${cr()}
  </div>
  <div class="pet-persona" id="pet-persona">
    <div class="pet-debug-title">${w("pet.persona_title")}</div>
    <div class="pet-note">${w("pet.persona_hint")}</div>
    <textarea id="pet-persona-text" class="pet-persona-text" rows="6" spellcheck="false" maxlength="8000" placeholder=""></textarea>
    <div class="pet-row pet-persona-actions">
      <button type="button" id="pet-persona-save" class="pet-btn pet-btn-primary">${w("settings.persona_save")}</button>
      <button type="button" id="pet-persona-clear" class="pet-btn">${w("pet.persona_clear")}</button>
      <button type="button" id="pet-persona-restart" class="pet-btn">${w("settings.persona_restart")}</button>
    </div>
    <div class="pet-note" id="pet-persona-msg"></div>
  </div>
</div>`;
}
function Fa() {
  if (document.getElementById("pet-style")) return;
  const e = document.createElement("style");
  e.id = "pet-style", e.textContent = Ar, document.head.appendChild(e);
}
async function Cr(e) {
  const t = (s) => e.querySelector(`#${s}`);
  let n = null;
  const a = (s, l) => void d("log_frontend", {
    level: "error",
    message: `[pet console] ${s}: ${l instanceof Error ? l.message : String(l)}`
  }).catch(() => {
  }), o = (s = "") => {
    St();
    const l = A(), g = l.model.trim(), f = l.image.trim(), E = t("pet-clear");
    E && (E.hidden = !(g || f));
    const C = t("pet-file");
    if (!C) return;
    const T = s ? `<br><span class="pet-dim">${I(s)}</span>` : "";
    g ? C.innerHTML = `当前用 Live2D 模型：<code>${I(g)}</code>${T}` : f ? C.innerHTML = `当前用图片：<code>${I(f)}</code>${T}` : C.innerHTML = "还没有模型 —— 点「更换模型」选一个文件夹（里面要有 <code>*.model3.json</code>）。";
  };
  async function c() {
    await d("open_plugin_window", { pluginId: "pet", key: null, input: "" });
  }
  const h = (s) => {
    const l = t("pet-toggle");
    l && (l.textContent = s ? "隐藏模型" : "显示桌宠");
  }, b = (s) => {
    const l = t("pet-through");
    l && (l.textContent = en(s), l.classList.toggle("on", s), l.setAttribute("aria-pressed", s ? "true" : "false"));
  }, y = () => new Promise((s) => {
    const l = `p${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
    let g = !1;
    const f = (C) => {
      g || (g = !0, E.then((T) => T()).catch(() => {
      }), s(C));
    }, E = pt(H, (C) => {
      var T, _;
      ((T = C.payload) == null ? void 0 : T.type) === "pong" && ((_ = C.payload) == null ? void 0 : _.token) === l && f({ alive: !0, visible: C.payload.visible !== !1 });
    });
    E.then(() => G(H, { type: "ping", token: l })).catch(() => {
    }), setTimeout(() => f({ alive: !1, visible: !1 }), 400);
  }), M = async () => (await y()).alive, L = () => void y().then((s) => h(s.alive && s.visible)), $ = setInterval(L, 3e3);
  let K = null, q = null;
  const j = (s, l) => {
    if (K = { id: s, value: l }, q) return;
    const g = () => {
      q = null;
      const f = K;
      if (K = null, f) {
        const E = A().model.trim();
        E && it(E, f.id, f.value), G(H, { type: "set-param", id: f.id, value: f.value });
      }
    };
    g(), q = setTimeout(g, 50);
  }, Q = async (s) => {
    try {
      const g = await ke(s);
      if (g && Object.keys(g.params).length) return g.params;
    } catch {
    }
    const l = A().params[s];
    return l && typeof l == "object" ? l : {};
  };
  let P = null, R = null;
  const ce = () => {
    P = null;
    const s = R;
    R = null, s && (async () => {
      try {
        const l = await ke(s) ?? Mn(s), g = A().params[s];
        l.params = g && typeof g == "object" ? { ...g } : {}, await He(s, l);
      } catch (l) {
        console.warn("[pet] 写 lunac.params.json 失败", l);
      }
    })();
  }, pe = (s) => {
    R = s, !P && (P = setTimeout(ce, 400));
  }, it = (s, l, g) => {
    const f = A(), E = { ...f.params };
    E[s] = { ...E[s] ?? {}, [l]: g }, Y({ ...f, params: E }), pe(s);
  }, ht = async (s) => {
    const l = await Q(s);
    for (const g of be.keys()) {
      const f = typeof l[g] == "number" ? l[g] : 0, E = e.querySelector(`.pet-range[data-param="${g}"]`);
      E && (E.value = String(f));
      const C = e.querySelector(`[data-param-val="${g}"]`);
      C && (C.value = String(f));
      const T = e.querySelector(`[data-param-sw="${g}"]`);
      if (T) {
        const _ = f >= 0.5;
        T.classList.toggle("on", _), T.setAttribute("aria-pressed", _ ? "true" : "false"), T.textContent = _ ? "开" : "关";
      }
    }
  }, xt = (s) => {
    const l = s.dataset.paramVal;
    if (!l) return;
    const g = be.get(l);
    if (!g) return;
    const f = e.querySelector(`.pet-range[data-param="${l}"]`), E = Number.parseFloat(s.value.trim());
    if (!Number.isFinite(E)) {
      s.value = (f == null ? void 0 : f.value) ?? "0";
      return;
    }
    const C = Math.round(Math.min(g.max, Math.max(g.min, E)) * 1e3) / 1e3;
    s.value = String(C), f && (f.value = String(C)), j(l, C);
  }, st = () => {
    const s = A().proactive;
    G(H, {
      type: "set-proactive",
      enabled: s.enabled,
      intervalMin: s.intervalMin,
      dailyCap: s.dailyCap,
      autoShot: s.autoShot,
      autoShotMin: s.autoShotMin,
      screenWatch: s.screenWatch,
      screenWatchSec: s.screenWatchSec,
      screenDiff: s.screenDiff
    });
  }, _t = () => {
    const s = t("pet-proactive-usage");
    if (!s) return;
    const l = A().proactive, g = Pt(), f = w("pet.proactive_usage", { used: String(g), cap: String(l.dailyCap) });
    s.textContent = g >= l.dailyCap ? `${f} · ${w("pet.proactive_reached")}` : f;
  }, Ct = (s) => {
    const l = A(), g = Number.parseInt(s.value.trim(), 10);
    if (!Number.isFinite(g)) {
      s.value = String(l.proactive.dailyCap);
      return;
    }
    const f = Math.min(Ln, Math.max(An, g));
    s.value = String(f), Y({ ...l, proactive: { ...l.proactive, dailyCap: f } }), st(), _t();
  }, $t = (s) => {
    const l = A(), g = Number.parseInt(s.value.trim(), 10);
    if (!Number.isFinite(g)) {
      s.value = String(l.proactive.intervalMin);
      return;
    }
    const f = Math.min($n, Math.max(Cn, g));
    s.value = String(f), Y({ ...l, proactive: { ...l.proactive, intervalMin: f } }), st();
  }, kt = (s, l, g, f, E) => {
    const C = A(), T = Number.parseInt(s.value.trim(), 10);
    if (!Number.isFinite(T)) {
      s.value = String(l(C.proactive));
      return;
    }
    const _ = Math.min(f, Math.max(g, T));
    s.value = String(_), Y({ ...C, proactive: E(C.proactive, _) }), st();
  }, At = "pet-agent-restart", at = "pet-agent-restart-done", Qt = w("settings.persona_saved"), ue = w("pet.persona_cleared"), Rt = w("pet.persona_restarting"), Wt = (s) => {
    const l = t("pet-persona-msg");
    l && (l.textContent = s);
  }, Me = async () => {
    try {
      const s = await d("get_pet_persona"), l = t("pet-persona-text");
      l && (s != null && s.maxChars && (l.maxLength = s.maxChars), l.value = (s == null ? void 0 : s.text) ?? "");
    } catch (s) {
      a("读取桌宠人格失败", s);
    }
  }, de = async (s, l) => {
    try {
      await d("set_pet_persona", { text: s }), Wt(l + w("pet.persona_effective"));
    } catch (g) {
      Wt(w("settings.persona_failed", { err: String(g) }));
    }
  }, fe = (s) => {
    const l = t("pet-debug-note");
    l && (l.textContent = s, l.hidden = !s);
  };
  let zt = "";
  const Ee = (s, l) => {
    const g = A(), f = { ...g.expressions };
    l ? f[s] = l : delete f[s], Y({ ...g, expressions: f });
  }, he = () => {
    const s = t("pet-exprs");
    s && s.querySelectorAll("[data-expr]").forEach((l) => {
      l.classList.toggle("on", !!zt && l.dataset.expr === zt);
    });
  }, jt = (s) => {
    zt = s, he();
    const l = A().model.trim();
    l && Ee(l, s), G(H, { type: "set-expression", id: s });
  }, te = (s, l) => {
    const g = dn.find((Z) => Z.id === s), f = l.range ? l.range.min : g ? g.min : -100, E = l.range ? l.range.max : g ? g.max : 100, C = E - f, T = C <= 2 ? 0.01 : C <= 20 ? 0.1 : 1;
    be.set(s, { min: f, max: E });
    const _ = g ? w(g.labelKey) : l.friendly || s, F = l.physIn ? `<span class="pet-phys-tag">${I(w("pet.debug_phys_in"))}</span>` : l.physOut ? `<span class="pet-phys-tag">${I(w("pet.debug_phys_out"))}</span>` : "", B = `<button type="button" class="pet-param-kind" data-param-kind="${I(s)}" data-kind="${l.isSwitch ? "switch" : "range"}" title="切换控件形态（开关 / 拉条）">${sr}</button>`;
    return l.isSwitch ? `<div class="pet-param">
        <span class="pet-label" title="${I(s)}">${I(_)}${F}</span>
        <input type="range" class="pet-range" data-param="${I(s)}" min="0" max="1" step="1" value="0" hidden>
        <button type="button" class="pet-btn pet-btn-toggle pet-param-on" data-param-sw="${I(s)}" aria-pressed="false">关</button>
        ${B}
      </div>` : `<div class="pet-param">
      <span class="pet-label" title="${I(s)}">${I(_)}${F}</span>
      <input type="range" class="pet-range" data-param="${I(s)}" min="${f}" max="${E}" step="${T}" value="0">
      <input type="text" class="pet-param-num" data-param-val="${I(s)}" inputmode="decimal" autocomplete="off" spellcheck="false" value="0" aria-label="${I(s)}">
      ${B}
    </div>`;
  };
  async function St() {
    const s = A(), l = !!s.model.trim(), g = t("pet-debug-body");
    if (g == null || g.classList.toggle("off", !l), !l || !g) {
      fe(w("pet.debug_need_model"));
      return;
    }
    const f = s.model.trim(), E = await Tn(f), C = await aa(f), T = C.cdi3 ? await Si(C.cdi3) : hr;
    let _ = null;
    try {
      _ = await ba(f, E);
    } catch {
      _ = null;
    }
    const F = new Set((_ == null ? void 0 : _.physicsInputs) ?? []), B = new Set((_ == null ? void 0 : _.physicsOutputs) ?? []), Z = [], et = (N) => {
      N && !Z.includes(N) && Z.push(N);
    }, W = E.parameters.length ? E.parameters : dn.map((N) => N.id);
    for (const N of dn) W.includes(N.id) && et(N.id);
    for (const N of W) et(N);
    const u = await fr(f), x = new Set(C.vtube ? await ki(C.vtube) : []), v = Z.filter((N) => !u.has(N) && !x.has(N)), p = s.paramKinds[f] ?? {}, S = await mr(f, C.dir), D = (N) => {
      const nt = p[N];
      if (nt) return nt === "switch";
      const rt = E.parameterRanges[N];
      if (!rt || rt.min !== 0 || rt.max !== 1) return !1;
      const qt = S.get(N);
      if (!qt || !qt.size) return !0;
      for (const bt of qt) if (bt !== 0 && bt !== 1) return !1;
      return !0;
    };
    be = /* @__PURE__ */ new Map(), g.innerHTML = v.map(
      (N) => te(N, {
        range: E.parameterRanges[N],
        physIn: F.has(N),
        physOut: B.has(N),
        friendly: T.parameters[N] ?? "",
        isSwitch: D(N)
      })
    ).join(""), await ht(f), fe(await M() ? "" : w("pet.debug_pet_closed"));
  }
  const Ht = async () => {
    const s = A(), l = s.model.trim();
    if (!l) return;
    const g = { ...s.params };
    delete g[l], Y({ ...s, params: g });
    try {
      const f = await ke(l);
      f && (f.params = {}, await He(l, f));
    } catch (f) {
      console.warn("[pet] 清 lunac.params.json 的 params 失败", f);
    }
    G(H, { type: "reset-params", ids: [...be.keys()] }), await ht(l), fe("参数已恢复默认。");
  }, Ce = () => {
    const s = A().model.trim();
    s && (dt = [], le = /* @__PURE__ */ new Set(), Dt(), Ze(s, []).catch((l) => a("清空热键失败", l)), wt("已清空热键表。"));
  }, nn = () => {
    (async () => {
      const s = A().model.trim();
      if (!s) return;
      const l = ot.filter((f) => f.name.toLowerCase().startsWith(ia));
      if (!l.length) {
        vt("没有本插件生成的动作文件（只删 lunac_ 开头的）。");
        return;
      }
      let g = 0;
      for (const f of l)
        try {
          await d("delete_motion_file", { modelPath: s, name: f.path.split(/[\\/]/).pop() || "" }), g++;
        } catch (E) {
          a("删除动作文件失败", E);
        }
      await ge(), ra(), G(H, { type: "reload" }), vt(`已删除 ${g} 个生成的动作文件。`);
    })();
  }, ut = "__lunacPetConsoleDelegate", Bt = e;
  if (!Bt[ut]) {
    Bt[ut] = !0;
    const s = (W) => {
      var v;
      const u = W.target;
      if (!u) return;
      const x = u.closest("[data-pet-tab]");
      if (x) {
        const p = x.dataset.petTab;
        e.querySelectorAll(".pet-tab").forEach((S) => {
          S.classList.toggle("on", S.dataset.petTab === p);
        }), e.querySelectorAll(".pet-tabpage").forEach((S) => {
          S.hidden = S.dataset.petPage !== p;
        });
        return;
      }
      if (u.closest("#pet-toggle"))
        (async () => {
          const p = await y();
          if (p.alive && p.visible) {
            G(H, { type: "hide" }).catch((D) => a("隐藏模型失败", D)), h(!1);
            return;
          }
          if (p.alive) {
            G(H, { type: "show" }).catch((D) => a("显示模型失败", D)), h(!0), St();
            return;
          }
          const S = A();
          !S.model.trim() && !S.image.trim() && !await Te() || (await c(), h(!0), St());
        })().catch((p) => a("显示桌宠失败", p));
      else if (u.closest("#pet-change"))
        Te().catch((p) => a("更换形象失败", p));
      else if (u.closest("#pet-clear"))
        Y({ ...A(), model: "", image: "" }), o(), G(H, { type: "reload" }), mn(), ge();
      else if (u.closest("#pet-through")) {
        const p = !A().clickThrough;
        Y({ ...A(), clickThrough: p }), b(p), G(H, { type: "set-click-through", value: p });
      } else if (u.closest("#pet-proactive-enabled")) {
        const p = u.closest("#pet-proactive-enabled");
        if (!p) return;
        const S = !p.classList.contains("on"), D = A();
        Y({ ...D, proactive: { ...D.proactive, enabled: S } }), p.classList.toggle("on", S), p.setAttribute("aria-pressed", S ? "true" : "false"), p.textContent = se(S), st(), _t();
      } else if (u.closest("#pet-autoshot-enabled")) {
        const p = u.closest("#pet-autoshot-enabled");
        if (!p) return;
        const S = !p.classList.contains("on"), D = A();
        Y({ ...D, proactive: { ...D.proactive, autoShot: S } }), p.classList.toggle("on", S), p.setAttribute("aria-pressed", S ? "true" : "false"), p.textContent = se(S), st();
      } else if (u.closest("#pet-screenwatch-enabled")) {
        const p = u.closest("#pet-screenwatch-enabled");
        if (!p) return;
        const S = !p.classList.contains("on"), D = A();
        Y({ ...D, proactive: { ...D.proactive, screenWatch: S } }), p.classList.toggle("on", S), p.setAttribute("aria-pressed", S ? "true" : "false"), p.textContent = se(S), st();
      } else if (u.closest("#pet-tts-enabled")) {
        const p = u.closest("#pet-tts-enabled");
        if (!p) return;
        const S = !p.classList.contains("on");
        Y({ ...A(), tts: S }), p.classList.toggle("on", S), p.setAttribute("aria-pressed", S ? "true" : "false"), p.textContent = Sa("pet.tts_enable", S);
      } else if (u.closest("#pet-tts-addfile"))
        Ae().catch((p) => a("导入参考音色失败", p));
      else if (u.closest("#pet-tts-preview"))
        Le();
      else if (u.closest("[data-param-sw]")) {
        if ((v = t("pet-debug-body")) != null && v.classList.contains("off")) return;
        const p = u.closest("[data-param-sw]"), S = (p == null ? void 0 : p.dataset.paramSw) ?? "";
        if (!p || !S) return;
        const D = !p.classList.contains("on");
        p.classList.toggle("on", D), p.setAttribute("aria-pressed", D ? "true" : "false"), p.textContent = D ? "开" : "关";
        const N = e.querySelector(`.pet-range[data-param="${S}"]`);
        N && (N.value = D ? "1" : "0"), j(S, D ? 1 : 0);
      } else if (u.closest("[data-param-kind]")) {
        const p = u.closest("[data-param-kind]"), S = (p == null ? void 0 : p.dataset.paramKind) ?? "", D = A().model.trim();
        if (!p || !S || !D) return;
        const N = A(), nt = { ...N.paramKinds }, rt = p.dataset.kind === "switch" ? "switch" : "range";
        nt[D] = { ...nt[D] ?? {}, [S]: rt === "switch" ? "range" : "switch" }, Y({ ...N, paramKinds: nt }), St();
      } else if (u.closest("#pet-persona-save")) {
        const p = t("pet-persona-text");
        de((p == null ? void 0 : p.value) ?? "", Qt).catch((S) => a("保存桌宠人格失败", S));
      } else if (u.closest("#pet-persona-clear")) {
        const p = t("pet-persona-text");
        p && (p.value = ""), de("", ue).catch((S) => a("清空桌宠人格失败", S));
      } else if (u.closest("#pet-persona-restart"))
        Wt(Rt), G(At).catch((p) => a("重启 AI 请求失败", p));
      else if (u.closest("#pet-reset-debug"))
        Ht();
      else if (u.closest("#pet-reset-hotkeys"))
        Ce();
      else if (u.closest("#pet-reset-motions"))
        nn();
      else {
        const p = u.closest("[data-expr]");
        if (p) {
          const S = p.dataset.expr ?? "";
          jt(S && S === zt ? "" : S);
        }
      }
    }, l = (W) => {
      var x;
      const u = W.target;
      if (u) {
        if (u.id === "pet-proactive-cap") {
          Ct(u);
          return;
        }
        if (u.id === "pet-proactive-interval") {
          $t(u);
          return;
        }
        if (u.id === "pet-autoshot-min") {
          kt(u, (v) => v.autoShotMin, Be, Ve, (v, p) => ({ ...v, autoShotMin: p }));
          return;
        }
        if (u.id === "pet-watch-sec") {
          kt(u, (v) => v.screenWatchSec, Ue, Ge, (v, p) => ({ ...v, screenWatchSec: p }));
          return;
        }
        if (u.id === "pet-watch-diff") {
          kt(u, (v) => v.screenDiff, qe, Xe, (v, p) => ({ ...v, screenDiff: p }));
          return;
        }
        if (u.id === "pet-tts-reftext") {
          Ut(u.value).catch((v) => a("保存参考文本失败", v));
          return;
        }
        if (u.matches("[data-param-val]")) {
          if ((x = t("pet-debug-body")) != null && x.classList.contains("off")) return;
          xt(u);
        }
      }
    }, g = (W) => {
      var x;
      const u = W.target;
      if (!(!u || W.key !== "Enter")) {
        if (u.id === "pet-proactive-cap") {
          W.preventDefault(), Ct(u);
          return;
        }
        if (u.id === "pet-proactive-interval") {
          W.preventDefault(), $t(u);
          return;
        }
        if (u.id === "pet-autoshot-min") {
          W.preventDefault(), kt(u, (v) => v.autoShotMin, Be, Ve, (v, p) => ({ ...v, autoShotMin: p }));
          return;
        }
        if (u.id === "pet-watch-sec") {
          W.preventDefault(), kt(u, (v) => v.screenWatchSec, Ue, Ge, (v, p) => ({ ...v, screenWatchSec: p }));
          return;
        }
        if (u.id === "pet-watch-diff") {
          W.preventDefault(), kt(u, (v) => v.screenDiff, qe, Xe, (v, p) => ({ ...v, screenDiff: p }));
          return;
        }
        if (u.id === "pet-tts-reftext") {
          W.preventDefault(), Ut(u.value).catch((v) => a("保存参考文本失败", v));
          return;
        }
        u.matches("[data-param-val]") && (W.preventDefault(), !((x = t("pet-debug-body")) != null && x.classList.contains("off")) && xt(u));
      }
    }, f = (W) => {
      var S;
      const u = W.target;
      if (!u) return;
      if (u.id === "pet-scale") {
        const D = Math.round(Number(u.value)) / 100, N = t("pet-scale-val");
        N && (N.textContent = `${Math.round(D * 100)}%`), Y({ ...A(), scale: D }), G(H, { type: "set-scale", value: D });
        return;
      }
      if (u.id === "pet-rot") {
        const D = Math.round(Number(u.value)), N = t("pet-rot-val");
        N && (N.textContent = `${D}°`), Y({ ...A(), rotation: D }), G(H, { type: "set-rotation", value: D });
        return;
      }
      if (u.id === "pet-tts-rate") {
        const D = tn(Number(u.value)), N = t("pet-tts-rate-val");
        N && (N.textContent = String(D)), Y({ ...A(), speechRate: D });
        return;
      }
      if (u.id === "pet-tts-speed") {
        const D = ta(Number(u.value)), N = t("pet-tts-speed-val");
        N && (N.textContent = D.toFixed(1) + "×"), an(D).catch((nt) => a("保存语速失败", nt));
        return;
      }
      if (u.id === "pet-tts-volume") {
        const D = ea(Number(u.value)), N = t("pet-tts-volume-val");
        N && (N.textContent = Math.round(D * 100) + "%"), Vt(D).catch((nt) => a("保存音量失败", nt));
        return;
      }
      const x = u.dataset.param;
      if (!x || (S = t("pet-debug-body")) != null && S.classList.contains("off")) return;
      const v = Number(u.value), p = e.querySelector(`[data-param-val="${x}"]`);
      p && document.activeElement !== p && (p.value = String(v)), j(x, v);
    };
    e.addEventListener("click", s), e.addEventListener("change", l), e.addEventListener("input", f), e.addEventListener("keydown", g);
    const E = await pt(H, (W) => {
      const u = W.payload;
      if ((u == null ? void 0 : u.type) !== "scale-changed" || typeof u.value != "number") return;
      const x = Math.round(u.value * 100), v = t("pet-scale");
      v && (v.value = String(x));
      const p = t("pet-scale-val");
      p && (p.textContent = `${x}%`);
    }), C = await pt(H, (W) => {
      const u = W.payload;
      if ((u == null ? void 0 : u.type) !== "rotation-changed" || typeof u.value != "number") return;
      const x = Math.round(u.value), v = t("pet-rot");
      v && (v.value = String(x));
      const p = t("pet-rot-val");
      p && (p.textContent = `${x}°`);
    }), T = await pt(H, (W) => {
      const u = W.payload;
      if ((u == null ? void 0 : u.type) !== "motion-progress") return;
      const x = u.p;
      if (e.querySelectorAll(".pet-chain-bar i").forEach((S) => S.style.width = "0%"), !x || typeof x.index != "number" || typeof x.elapsedMs != "number" || typeof x.totalMs != "number" || !(x.totalMs > 0)) return;
      const v = Math.max(0, Math.min(1, x.elapsedMs / x.totalMs)), p = typeof u.chainId == "string" && u.chainId ? u.chainId : null;
      xr(p, x.index, v);
    }), _ = await pt(H, (W) => {
      var u;
      ((u = W.payload) == null ? void 0 : u.type) === "proactive-used" && _t();
    }), F = await pt(H, (W) => {
      var u;
      ((u = W.payload) == null ? void 0 : u.type) !== "click-through-changed" || typeof W.payload.value != "boolean" || b(W.payload.value);
    }), B = () => {
      e.querySelectorAll(".pet-hk-row").forEach((W) => {
        const u = W.dataset.hkId, x = W.querySelector("[data-hk-run]");
        if (!u || !x) return;
        const v = le.has(u);
        x.classList.toggle("on", v), x.setAttribute("aria-pressed", v ? "true" : "false"), x.textContent = v ? "开" : "关";
      });
    }, Z = await pt(H, (W) => {
      const u = W.payload;
      (u == null ? void 0 : u.type) !== "hotkey-states" || !Array.isArray(u.ids) || (le = new Set(u.ids.filter((x) => typeof x == "string")), B());
    }), et = await pt(at, (W) => {
      var u;
      Wt(((u = W.payload) == null ? void 0 : u.ok) === !1 ? w("pet.persona_restart_failed") : w("pet.persona_restarted"));
    });
    Jt = () => {
      e.removeEventListener("click", s), e.removeEventListener("change", l), e.removeEventListener("input", f), e.removeEventListener("keydown", g), E(), C(), T(), _(), F(), Z(), et(), $ && clearInterval($), q && clearTimeout(q), delete Bt[ut], Jt = null;
    };
  }
  function ee() {
    const s = t("pet-tts-reftext");
    if (n && s && document.activeElement !== s && (s.value = n.config.reference_text), n) {
      const g = t("pet-tts-speed");
      if (g && document.activeElement !== g) {
        const E = ta(n.config.speed);
        g.value = String(E);
        const C = t("pet-tts-speed-val");
        C && (C.textContent = E.toFixed(1) + "×");
      }
      const f = t("pet-tts-volume");
      if (f && document.activeElement !== f) {
        const E = ea(n.config.volume);
        f.value = String(E);
        const C = t("pet-tts-volume-val");
        C && (C.textContent = Math.round(E * 100) + "%");
      }
    }
    const l = t("pet-tts-status");
    if (l) {
      if (!n) {
        l.textContent = "", l.className = "pet-note";
        return;
      }
      n.available ? (l.textContent = w("pet.tts_status_ready"), l.className = "pet-note pet-tts-ok") : (l.textContent = w("pet.tts_status_not_ready") + " · " + w("pet.tts_reason_" + (n.reason || "no_ref_audio")), l.className = "pet-note");
    }
  }
  async function $e() {
    try {
      n = await d("get_pet_voice");
    } catch (s) {
      a("读取语音状态失败", s);
    }
    ee();
  }
  async function an(s) {
    const l = n == null ? void 0 : n.config;
    l && l.speed !== s && (await d("set_pet_voice", { config: { ...l, speed: s } }), n = { ...n, config: { ...l, speed: s } });
  }
  async function Vt(s) {
    const l = n == null ? void 0 : n.config;
    l && l.volume !== s && (await d("set_pet_voice", { config: { ...l, volume: s } }), n = { ...n, config: { ...l, volume: s } });
  }
  async function Ut(s) {
    const l = n == null ? void 0 : n.config;
    !l || l.reference_text === s || (await d("set_pet_voice", { config: { ...l, reference_text: s } }), n = { ...n, config: { ...l, reference_text: s } }, ee());
  }
  async function Ae() {
    var f;
    const s = t("pet-tts-msg"), l = await gn({
      multiple: !1,
      directory: !1,
      title: w("pet.tts_import_title"),
      filters: [{ name: w("pet.tts_import_filter"), extensions: ["wav", "mp3", "flac", "ogg", "m4a", "aac", "opus"] }]
    }), g = typeof l == "string" ? l : "";
    if (g)
      try {
        const E = await d("import_pet_voice_audio", { path: g }), C = n == null ? void 0 : n.config, T = ((f = t("pet-tts-reftext")) == null ? void 0 : f.value) ?? (C == null ? void 0 : C.reference_text) ?? "";
        await d("set_pet_voice", {
          config: { ...C ?? { enabled: !0, reference_text: "", num_steps: 8, num_threads: 4, speed: 1, volume: 1 }, reference_audio: E, reference_text: T }
        }), await $e(), s && (s.textContent = w("pet.tts_import_ok"), s.className = "pet-note");
      } catch (E) {
        s && (s.textContent = w("pet.tts_import_fail") + (E instanceof Error ? E.message : String(E)), s.className = "pet-note pet-bad");
      }
  }
  function Le() {
    const s = t("pet-tts-msg");
    s && (s.textContent = ""), d("tts_speak", { text: w("pet.tts_preview_text"), enabled: !0 }).catch((l) => a("试听失败", l));
  }
  $e();
  async function Te() {
    const s = t("pet-file"), l = await gn({
      multiple: !1,
      directory: !0,
      title: "选择 Live2D 模型文件夹（里面要有 *.model3.json）"
    }), g = typeof l == "string" ? l : "";
    if (!g) return "";
    s && (s.innerHTML = "正在读取模型文件夹…");
    let f = "", E = "", C = "";
    try {
      const F = await d("scan_model_folder", { dir: g });
      f = (F.model3 ?? [])[0] ?? "", E = (F.vtube ?? [])[0] ?? "", C = (F.cdi3 ?? [])[0] ?? "";
    } catch (F) {
      return s && (s.innerHTML = `<span class="pet-bad">读文件夹失败：${I(F instanceof Error ? F.message : String(F))}</span>`), "";
    }
    if (!f)
      return s && (s.innerHTML = '<span class="pet-bad">这个文件夹里没有 *.model3.json。</span>'), "";
    const T = await ua(f);
    if (!T.ok)
      return s && (s.innerHTML = `<span class="pet-bad">这个模型用不了：${I(T.reason)}</span>`), "";
    Y({ ...A(), model: f, image: "" });
    const _ = [];
    try {
      const F = await kn(g, f, E);
      F && _.push(`热键 ${F} 条`);
    } catch (F) {
      a("读取模型热键失败", F);
    }
    return C && _.push("含 cdi3"), o([T.info, _.join(" · ")].filter(Boolean).join("　")), G(H, { type: "reload" }), mn(), St(), ge(), f;
  }
  const Gt = "__lunacPetHotkeyDelegate", ne = e;
  if (!ne[Gt]) {
    ne[Gt] = !0;
    const s = (f) => f.closest(".pet-hk-row"), l = (f) => f ? dt.find((E) => E.id === f.dataset.hkId) : void 0;
    e.addEventListener("click", (f) => {
      const E = f.target;
      if (!E || !E.closest("#pet-hotkeys")) return;
      if (E.closest("#pet-hk-import")) {
        (async () => {
          const _ = A().model.trim();
          if (!_) {
            wt("先选一个 Live2D 模型 —— 「更换形象」里选模型文件夹。");
            return;
          }
          const F = await aa(_);
          try {
            const B = await kn(F.dir, _, F.vtube);
            if (!B) {
              wt("这个模型文件夹里没找到可导入的热键 / 表情。");
              return;
            }
            wt(`已导入 ${B} 条（${F.vtube ? "取自 vtube.json" : "扫自文件夹"}），已落盘。`), G(H, { type: "reload" });
          } catch (B) {
            wt("导入失败：" + (B instanceof Error ? B.message : String(B)));
          }
        })();
        return;
      }
      const C = s(E), T = l(C);
      if (!(!C || !T)) {
        if (E.closest("[data-hk-run]")) {
          M().then((_) => {
            if (!_) {
              wt("桌宠没显示 —— 先点上面「显示桌宠」，模型加载好后再点。");
              return;
            }
            G(H, { type: "hotkey-toggle", id: T.id, action: T.action }), wt("");
          });
          return;
        }
        if (E.closest("[data-hk-del]")) {
          dt = dt.filter((_) => _.id !== T.id), Dt(), Se();
          return;
        }
      }
    });
    const g = (f, E) => {
      const C = f.target;
      if (!C || !C.closest("#pet-hotkeys")) return;
      const T = s(C), _ = l(T);
      if (!T || !_) return;
      const F = C.dataset.hkField;
      if (!F) return;
      const B = C.value;
      if (F === "name") {
        _.name = B, Se();
        return;
      }
      Oa(_.action, F, B), !E && (F === "id" || F === "group") && Dt(), Se();
    };
    e.addEventListener("change", (f) => g(f, !1)), e.addEventListener("input", (f) => g(f, !0));
  }
  const ae = "__lunacPetMotionDelegate";
  if (!ne[ae]) {
    ne[ae] = !0;
    const s = (T, _) => {
      const F = T.closest(_);
      return F ? Number.parseInt(F.getAttribute(_.slice(1, -1)) ?? "", 10) : NaN;
    }, l = (T) => T.split(/[\\/]/).pop() || "", g = async () => {
      await ge(), ra(), G(H, { type: "reload" });
    };
    e.addEventListener("click", (T) => {
      var W, u;
      const _ = T.target;
      if (!_ || !_.closest("#pet-motions")) return;
      const F = (x) => {
        const v = _.closest(`[${x}]`), p = (v == null ? void 0 : v.getAttribute(x)) ?? "", [S, D] = p.split(":").map((N) => Number.parseInt(N, 10));
        return [S, D];
      };
      if (_.closest("#pet-chain-add")) {
        V = [...V, Ti(`动作链 ${V.length + 1}`)], mt(), Tt();
        return;
      }
      if (_.closest("[data-chain-toggle]")) {
        const [x] = F("data-chain-toggle"), v = V[x];
        if (!v) return;
        we.has(v.id) ? we.delete(v.id) : we.add(v.id), mt();
        return;
      }
      if (_.closest("[data-chain-loop]")) {
        const [x] = F("data-chain-loop");
        if (!V[x]) return;
        V = V.map((p, S) => S === x ? { ...p, loop: !p.loop } : p), mt(), Tt();
        return;
      }
      if (_.closest("[data-chain-del]")) {
        const [x] = F("data-chain-del");
        if (!Number.isInteger(x)) return;
        const v = V[x];
        v && we.delete(v.id), V = V.filter((p, S) => S !== x), mt(), Tt();
        return;
      }
      if (_.closest("[data-chain-step-add]")) {
        const [x] = F("data-chain-step-add");
        if (!V[x]) return;
        const p = ((W = ot[0]) == null ? void 0 : W.path) ?? "";
        (async () => {
          const S = await Ia(p), D = V[x];
          if (!D) return;
          const N = S !== null ? { ...qn(p), loopSec: S } : qn(p), nt = { ...D, steps: [...D.steps, N] };
          V = V.map((rt, qt) => qt === x ? nt : rt), mt(), Tt();
        })();
        return;
      }
      if (_.closest("[data-chain-step-del]")) {
        const [x, v] = F("data-chain-step-del"), p = V[x];
        if (!p || !Number.isInteger(v)) return;
        const S = { ...p, steps: p.steps.filter((D, N) => N !== v) };
        V = V.map((D, N) => N === x ? S : D), mt(), Tt();
        return;
      }
      if (_.closest("[data-chain-run]")) {
        const x = ((u = _.closest("[data-chain-run]")) == null ? void 0 : u.getAttribute("data-chain-run")) ?? "";
        x && G(H, { type: "chain-play", id: x });
        return;
      }
      if (_.closest("#pet-mo-add")) {
        (async () => {
          var D;
          const x = A().model.trim();
          if (!x) {
            vt("先选一个 Live2D 模型。");
            return;
          }
          const v = await _r(x);
          if (!v) {
            vt("拿不到参数清单 —— 先「显示桌宠」一次，再来新建动作。");
            return;
          }
          const p = JSON.parse(v), S = `${ia}${Date.now().toString(36)}.motion3.json`;
          try {
            await d("write_motion_file", { modelPath: x, name: S, json: v }), vt(`已生成 ${S}（${((D = p.Curves) == null ? void 0 : D.length) ?? 0} 条参数曲线），可交给 AI 编。`), await g();
          } catch (N) {
            vt("生成失败：" + (N instanceof Error ? N.message : String(N)));
          }
        })();
        return;
      }
      const B = s(_, "[data-mo-idle]");
      if (Number.isInteger(B)) {
        const x = ot[B], v = A().model.trim();
        if (!x || !v) return;
        const p = A(), S = new Set(p.idleMotions[v] ?? []), D = [...S].find((nt) => nt.toLowerCase() === x.name.toLowerCase());
        D !== void 0 ? S.delete(D) : S.add(x.name);
        const N = { ...p.idleMotions };
        S.size ? N[v] = [...S] : delete N[v], Y({ ...p, idleMotions: N }), Ye(), G(H, { type: "reload" });
        return;
      }
      const Z = s(_, "[data-mo-run]");
      if (Number.isInteger(Z)) {
        G(H, { type: "motion-play", group: yn, index: Z });
        return;
      }
      const et = s(_, "[data-mo-del]");
      Number.isInteger(et) && (async () => {
        const x = ot[et], v = A().model.trim();
        if (!(!x || !v))
          try {
            await d("delete_motion_file", { modelPath: v, name: l(x.path) }), await g();
          } catch (p) {
            vt("删除失败：" + (p instanceof Error ? p.message : String(p)));
          }
      })();
    });
    const f = (T, _) => {
      const F = T.target, B = F == null ? void 0 : F.dataset.moName;
      if (!F || B === void 0) return;
      const Z = ot[Number.parseInt(B, 10)], et = A().model.trim();
      if (!Z || !et) return;
      const W = F.value.trim().replace(/\.motion3\.json$/i, "");
      _ && F.blur(), !(!W || W === Z.name) && (async () => {
        try {
          await d("rename_motion_file", {
            modelPath: et,
            from: l(Z.path),
            to: `${W}.motion3.json`
          }), await g();
        } catch (u) {
          vt("改名失败：" + (u instanceof Error ? u.message : String(u)));
        }
      })();
    }, E = (T, _) => {
      const F = (T == null ? void 0 : T.getAttribute(_)) ?? "", [B, Z] = F.split(":").map((et) => Number.parseInt(et, 10));
      return [B, Z];
    }, C = (T) => {
      const _ = T.target;
      if (!_) return;
      if (_.dataset.chainName !== void 0) {
        const Z = Number.parseInt(_.dataset.chainName, 10), et = V[Z];
        if (!et) return;
        const W = _.value.trim() || et.name;
        V = V.map((u, x) => x === Z ? { ...u, name: W } : u), Tt();
        return;
      }
      if (_.dataset.chainStepFile !== void 0) {
        const [Z, et] = E(_, "data-chain-step-file");
        Pa(Z, et, _.value);
        return;
      }
      const F = _.dataset.chainStepLoop !== void 0, B = _.dataset.chainStepStop !== void 0;
      if (F || B) {
        const [Z, et] = E(_, F ? "data-chain-step-loop" : "data-chain-step-stop"), W = V[Z];
        if (!W || !Number.isInteger(et)) return;
        const u = Number.parseFloat(_.value), x = Number.isFinite(u) ? u : 0, v = W.steps.map((p, S) => S !== et ? p : F ? { ...p, loopSec: x > 0 ? Math.min(3600, x) : 3 } : { ...p, stopSec: x > 0 ? Math.min(3600, x) : 0 });
        V = V.map((p, S) => S === Z ? { ...p, steps: v } : p), mt(), Tt();
      }
    };
    e.addEventListener("change", C), e.addEventListener("change", (T) => f(T, !1)), e.addEventListener("keydown", (T) => {
      if (T.key !== "Enter") return;
      const _ = T.target;
      (_ == null ? void 0 : _.dataset.moName) !== void 0 && (T.preventDefault(), f(T, !0));
    });
  }
  Fa(), o(), b(A().clickThrough), Me(), L(), mn(), ge(), (async () => {
    A().model.trim() && (await M() || (await c(), h(!0)));
  })().catch(() => {
  });
}
function $r() {
  return `
<div class="pet-root" id="pet-root">
  <!-- 对话改渲染（2026-10-10 用户口径）：窗口整体变大但模型大小不变，**输出贴上沿、输入贴下沿**，
       且两条**紧贴模型**（无空隙）—— 上 75 / 模型 300×400 / 下 35，合计 510。两条**始终占位**
       （对话收起时只隐藏内容），所以模型不会因开合对话而跳动。整块的显隐由 .pet-root 上的
       chat-on / chat-input-on 两个类控制（见 setChatOpen）。 -->
  <div class="pet-top">
    <div class="pet-chat-output" id="pet-chat-bubble">
      <div class="pet-chat-text" id="pet-chat-text"></div>
    </div>
  </div>
  <div class="pet-stage" id="pet-stage">
    <div class="pet-l2d" id="pet-l2d"></div>
    <img class="pet-img" id="pet-img" alt="" draggable="false">
    <div class="pet-empty" id="pet-empty">还没有形象<br><span>在控制台里选一张图片或一个 Live2D 模型</span></div>
  </div>
  <div class="pet-bottom">
    <div class="pet-chat-inputrow">
      <textarea class="pet-chat-input" id="pet-chat-input" rows="1" spellcheck="false" autocomplete="off" placeholder="${I(w("pet.ai_chat_placeholder"))}" aria-label="${I(w("pet.ai_chat"))}"></textarea>
      <button type="button" class="pet-chat-stop" id="pet-chat-stop" title="${I(w("pet.chat_stop"))}" aria-label="${I(w("pet.chat_stop"))}">${yr}</button>
      <button type="button" class="pet-chat-close" id="pet-chat-close" title="${I(w("pet.ai_chat_close"))}" aria-label="${I(w("pet.ai_chat_close"))}">×</button>
    </div>
  </div>
  <div class="pet-err" id="pet-err"></div>
  <div class="pet-toast" id="pet-toast"></div>
  <div class="pet-menu" id="pet-menu">
    <button data-act="ai-chat">${w("pet.ai_chat")}</button>
    <button data-act="settings">桌宠设置…</button>
    <button data-act="look-screen">${w("pet.look_screen")}</button>
    <button data-act="change">更换模型…</button>
    <button data-act="reset">恢复</button>
    <button data-act="through" id="pet-menu-through">${I(en(A().clickThrough))}</button>
    <button data-act="close" class="danger">关闭桌宠</button>
  </div>
</div>`;
}
const Ar = `
.pet-root{position:fixed;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:flex-start;overflow:hidden;}
/* 上：输出带 固定 75；下：输入带 固定 35 —— **始终占位**（对话收起只隐藏内容、模型不跳动）；
   两条都紧贴模型（无空隙）。数值与 PET_OUT_H / PET_IN_H 一致。 */
.pet-top{flex:0 0 75px;width:100%;display:flex;align-items:flex-start;justify-content:center;overflow:hidden;}
.pet-bottom{flex:0 0 35px;width:100%;display:flex;align-items:flex-end;justify-content:center;overflow:hidden;}
/* 模型区**定尺 300×400**（= 窗口变大之前整窗的大小）—— 用户 2026-10-10 口径：
   窗口整体放大，但**模型本身的大小不变**，上下两条紧贴它（左 10 / 右 10 的留白照旧）。 */
.pet-stage{position:relative;width:300px;height:400px;flex:0 0 auto;display:flex;align-items:flex-end;justify-content:center;cursor:grab;touch-action:none;}
.pet-stage:active{cursor:grabbing;}
.pet-img{width:100%;height:100%;object-fit:contain;object-position:bottom center;transform-origin:50% 100%;pointer-events:none;-webkit-user-drag:none;filter:drop-shadow(0 6px 14px rgba(var(--shade-rgb),.35));}
.pet-l2d{position:absolute;inset:0;display:none;}
.pet-l2d.on{display:block;}
.pet-l2d canvas{display:block;}
.pet-err{position:absolute;left:8px;right:8px;bottom:8px;display:none;font-size:.68rem;line-height:1.6;color:var(--red);background:var(--surface-glass);border:1px solid var(--border-glass);border-radius:var(--radius);padding:8px 10px;word-break:break-all;backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);}
.pet-err.on{display:block;}
.pet-toast{position:absolute;left:50%;top:84px;transform:translateX(-50%);display:none;max-width:92%;font-size:.72rem;line-height:1.6;color:var(--text);background:var(--surface-glass);border:1px solid var(--border-glass);border-radius:var(--radius);padding:8px 12px;text-align:center;word-break:break-all;backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);box-shadow:0 6px 18px rgba(var(--shade-rgb),.28);}
.pet-toast.on{display:block;}
/* 输出框：宽 320、**固定占满预留的 75px 输出带**（用户 2026-10-12 口径：输出框 / 输入框是**提前预留**
   的区域，文字应渲染在这个区域内、**靠顶**，而不是按内容收缩后飘在带里）。
   做法：用 align-self:stretch 覆盖 .pet-top 的 flex-start（= 撑满 75px）；文字靠顶（块级 + 顶部对齐，
   **不做垂直居中**）。长回复满 75px 后在盒内滚动（overflow-y:auto，max-height 兜底）。
   无正文时靠 .pet-chat-output:empty{visibility:hidden} 让它**不可见但仍占位** ⇒ .pet-top 始终 75px、
   开合对话时模型不位移。
   ⚠️ white-space:pre-wrap 会把回复里的换行 / 连续空行渲染成盒子内的**真实空白块**（用户报的段间空白）；
   故正文写进 DOM 前一律先过 JS 的 normalizeReplyText（换行归一 + 连续空白折叠 + 首尾空行丢弃，
   见 pet-typewriter.ts）—— 这里保留 pre-wrap 只为兜底单个空格。
   ⚠️ 滚动条只走全局那一条（ui-style.md 界面 6）：不得写 scrollbar-width / scrollbar-color、
   不得按容器另写、不得藏。 */
.pet-chat-output{display:none;width:320px;align-self:stretch;max-height:75px;box-sizing:border-box;overflow-y:auto;padding:6px 10px;font-size:.72rem;line-height:1.6;color:var(--text);text-align:left;background:var(--surface-glass);border:1px solid var(--border-glass);border-radius:var(--radius);backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px);word-break:break-word;white-space:pre-wrap;}
.pet-root.chat-on .pet-chat-output{display:block;}
.pet-chat-output:empty{visibility:hidden;}
.pet-chat-output.thinking .pet-chat-text{opacity:.55;}
/* 输入行：高 35（贴窗口下沿）；只在 .pet-root.chat-input-on 时显示。
   「桌宠发起」的三种情况（语音输入 / 主动询问 / 抓屏）**不显示输入区** —— 见 setChatOpen 的 showInput。 */
.pet-chat-inputrow{display:none;width:100%;height:35px;box-sizing:border-box;align-items:center;gap:6px;padding:0 8px;}
.pet-root.chat-input-on .pet-chat-inputrow{display:flex;}
.pet-chat-input{box-sizing:border-box;flex:1 1 auto;height:35px;resize:none;padding:6px 10px;font:inherit;font-size:.72rem;line-height:1.5;color:var(--text);background:var(--surface-glass);border:1px solid var(--border-glass);border-radius:var(--radius);outline:none;caret-color:rgb(var(--other-overlay-rgb));backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px);}
.pet-chat-input:focus{border-color:rgba(var(--btn-line-rgb), var(--btn-line-alpha));}
.pet-chat-close{appearance:none;flex:0 0 auto;height:35px;background:var(--surface-glass);border:1px solid var(--border-glass);border-radius:var(--radius);font:inherit;font-size:.9rem;line-height:1;color:var(--text-dim);cursor:pointer;padding:0 9px;}
.pet-chat-close:hover{color:var(--text);background:var(--border-glass);}
/* 「中止对话」图标按钮（形态照 §界面 14.1 的图标按钮：30×30 / 圆角 6px；颜色走按钮背景 + 按钮线条）。
   只在「正在生成」时出现 —— 由 on 类控制（见 setPetGenerating）。 */
.pet-chat-stop{display:none;flex:0 0 auto;align-items:center;justify-content:center;width:30px;height:30px;box-sizing:border-box;background:rgba(var(--btn-bg-rgb),var(--btn-bg-alpha));border:1px solid rgba(var(--btn-line-rgb),var(--btn-line-alpha));border-radius:6px;color:rgb(var(--btn-line-rgb));cursor:pointer;padding:0;}
.pet-chat-stop.on{display:flex;}
.pet-chat-stop:hover{background:rgba(var(--btn-bg-rgb),calc(var(--btn-bg-alpha) + 0.06));}
.pet-empty{position:absolute;left:50%;bottom:38%;transform:translateX(-50%);text-align:center;font-size:.72rem;line-height:1.7;color:var(--text-dim);background:var(--surface-glass);border:1px solid var(--border-glass);border-radius:var(--radius);padding:10px 14px;backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);}
.pet-empty span{font-size:.66rem;opacity:.75;}
.pet-menu{position:absolute;display:none;flex-direction:column;min-width:132px;padding:4px;background:var(--surface-glass);border:1px solid var(--border-glass);border-radius:var(--radius);backdrop-filter:blur(20px);-webkit-backdrop-filter:blur(20px);box-shadow:0 8px 24px rgba(var(--shade-rgb),.28);}
.pet-menu.open{display:flex;}
.pet-menu button{appearance:none;background:none;border:0;text-align:left;font:inherit;font-size:.72rem;color:var(--text);padding:6px 10px;border-radius:6px;cursor:pointer;white-space:nowrap;}
.pet-menu button:hover{background:var(--border-glass);}
.pet-menu button.danger:hover{color:var(--red);}
.pet-console{padding:10px 12px 14px;font-size:.76rem;color:var(--text);}
.pet-row{display:flex;align-items:center;gap:8px;margin-bottom:10px;flex-wrap:wrap;}
/* 开头那排按钮（显示桌宠 / 更换模型 / 取消配置 / 穿透）**必须同一行**（用户 2026-10-10 口径）：
   不换行 + 收窄内边距，四个刚好排得下。 */
.pet-row-main{gap:6px;flex-wrap:nowrap;}
.pet-row-main .pet-btn{padding:6px 8px;font-size:.7rem;flex:0 0 auto;white-space:nowrap;}
.pet-btn{appearance:none;font:inherit;font-size:.74rem;color:var(--text);background:var(--surface-glass);border:1px solid var(--border-glass);border-radius:8px;padding:6px 12px;cursor:pointer;}
.pet-btn:hover{border-color:rgb(var(--other-overlay-rgb));color:rgb(var(--other-overlay-rgb));}
.pet-btn-primary{background:rgb(var(--other-overlay-rgb));border-color:rgb(var(--other-overlay-rgb));color:var(--text);font-weight:600;}
.pet-btn-primary:hover{color:var(--text);opacity:.92;}
.pet-btn-toggle.on{background:rgb(var(--other-overlay-rgb));border-color:rgb(var(--other-overlay-rgb));color:var(--text);font-weight:600;}
.pet-btn-toggle.on:hover{color:var(--text);opacity:.92;}
/* 分页（模型调试 / 热键，2026-10-10）—— 照 .music-tab / .chat-hist-tab 的胶囊芯片语言。 */
.pet-tabs{display:flex;flex-wrap:wrap;gap:6px;margin-top:12px;border-top:1px solid var(--border-glass);padding-top:11px;margin-bottom:10px;}
.pet-tab{appearance:none;font:inherit;font-size:.72rem;color:var(--text-dim);background:transparent;border:1px solid var(--border-glass);border-radius:999px;padding:4px 14px;cursor:pointer;}
.pet-tab:hover{color:var(--text);border-color:rgba(var(--btn-line-rgb), var(--btn-line-alpha));}
.pet-tab.on{color:var(--text);background:rgba(var(--btn-bg-rgb), var(--btn-bg-alpha));border-color:rgba(var(--btn-line-rgb), var(--btn-line-alpha));}
/* 页内的块不再各画一条上分隔线（那一排页签已经承担了分隔）。 */
.pet-tabpage>.pet-hotkeys,.pet-tabpage>.pet-debug{margin-top:0;border-top:0;padding-top:0;}
/* 「恢复默认」按钮行：三个分页各一颗，**贴在页顶**（2026-10-10 用户口径：从页底移上来）。 */
.pet-reset-row{margin-bottom:10px;}
.pet-phys-tag{margin-left:6px;font-size:.62rem;color:var(--text-dim);border:1px solid var(--border-glass);border-radius:999px;padding:0 6px;opacity:.85;}
.pet-check{display:flex;align-items:center;gap:6px;color:var(--text-dim);cursor:pointer;}
.pet-label{color:var(--text-dim);}
.pet-val{color:var(--text-dim);min-width:3.2em;}
.pet-file{margin:2px 0 10px;color:var(--text-dim);word-break:break-all;line-height:1.6;}
.pet-file code{font-size:.7rem;color:var(--text);}
.pet-dim{opacity:.72;}
.pet-bad{color:var(--red);}
.pet-note{color:var(--text-dim);opacity:.72;font-size:.68rem;line-height:1.7;border-top:1px solid var(--border-glass);padding-top:9px;}
.pet-note b{color:var(--text);opacity:.9;}
.pet-persona{margin-top:14px;border-top:1px solid var(--border-glass);padding-top:12px;display:flex;flex-direction:column;gap:8px;}
.pet-persona .pet-note{border-top:0;padding-top:0;}
.pet-persona-text{width:100%;box-sizing:border-box;resize:vertical;min-height:96px;font:inherit;font-size:.72rem;line-height:1.7;color:var(--text);background:rgba(var(--shade-rgb),calc(0.3 * var(--shade-scale)));border:1px solid var(--border-glass);border-radius:8px;padding:8px 10px;outline:none;caret-color:rgb(var(--other-overlay-rgb));}
.pet-persona-text:focus{border-color:rgb(var(--other-overlay-rgb));}
.pet-persona-actions{gap:8px;flex-wrap:wrap;}
.pet-debug{margin-top:12px;border-top:1px solid var(--border-glass);padding-top:11px;}
.pet-debug-title{font-weight:600;color:var(--text);margin-bottom:8px;}
.pet-debug-note{color:var(--text-dim);font-size:.68rem;line-height:1.7;margin-bottom:8px;}
.pet-debug-body.off{opacity:.45;pointer-events:none;}
.pet-param{display:flex;align-items:center;gap:8px;margin-bottom:8px;}
.pet-param .pet-label{min-width:5.5em;}
.pet-range{flex:1;min-width:0;height:4px;appearance:none;-webkit-appearance:none;background:var(--border-glass);border-radius:3px;outline:none;cursor:pointer;}
.pet-range::-webkit-slider-thumb{appearance:none;-webkit-appearance:none;width:14px;height:14px;border-radius:50%;background:rgb(var(--btn-line-rgb));border:0;cursor:pointer;}
.pet-range::-moz-range-thumb{width:14px;height:14px;border-radius:50%;background:rgb(var(--btn-line-rgb));border:0;cursor:pointer;}
.pet-param .pet-param-num{flex:0 0 auto;width:54px;box-sizing:border-box;padding:4px 7px;font:inherit;font-size:.7rem;text-align:right;font-variant-numeric:tabular-nums;color:var(--text);background:rgba(var(--shade-rgb),calc(0.3 * var(--shade-scale)));border:1px solid var(--border-glass);border-radius:5px;outline:none;caret-color:rgb(var(--other-overlay-rgb));}
.pet-param .pet-param-num:focus{border-color:rgba(var(--btn-line-rgb), var(--btn-line-alpha));}
.pet-debug-sub{color:var(--text-dim);margin:10px 0 6px;}
.pet-exprs{display:flex;flex-wrap:wrap;gap:6px;line-height:1.6;max-height:180px;overflow-y:auto;padding-right:4px;align-content:flex-start;}
.pet-expr-btn{appearance:none;font:inherit;font-size:.72rem;color:var(--text);background:var(--surface-glass);border:1px solid var(--border-glass);border-radius:8px;padding:5px 10px;cursor:pointer;}
.pet-expr-btn:hover{border-color:rgb(var(--other-overlay-rgb));color:rgb(var(--other-overlay-rgb));}
.pet-expr-reset{color:var(--text-dim);}
.pet-expr-btn.on{background:rgb(var(--other-overlay-rgb));border-color:rgb(var(--other-overlay-rgb));color:var(--text);font-weight:600;}
.pet-expr-btn.on:hover{color:var(--text);opacity:.92;}
.pet-proactive{margin-top:12px;border-top:1px solid var(--border-glass);padding-top:11px;}
.pet-proactive .pet-note{margin-top:8px;border-top:0;padding-top:0;}
.pet-proactive .pet-param-num{flex:0 0 auto;width:64px;box-sizing:border-box;padding:4px 7px;font:inherit;font-size:.7rem;text-align:right;font-variant-numeric:tabular-nums;color:var(--text);background:rgba(var(--shade-rgb),calc(0.3 * var(--shade-scale)));border:1px solid var(--border-glass);border-radius:5px;outline:none;caret-color:rgb(var(--other-overlay-rgb));}
.pet-proactive .pet-param-num:focus{border-color:rgba(var(--btn-line-rgb), var(--btn-line-alpha));}
.pet-tts{margin-top:12px;border-top:1px solid var(--border-glass);padding-top:11px;}
.pet-tts .pet-note{margin-top:8px;border-top:0;padding-top:0;}
/* 「参考音色」子块（2026-10-12）：参考文本输入框 + 「添加音频文件 / 试听」两枚按钮 + 状态行。 */
.pet-tts-voice{margin-top:10px;padding-top:10px;border-top:1px solid var(--border-glass);}
.pet-tts-voice .pet-label{display:block;margin-bottom:6px;}
.pet-tts-voice .pet-row{margin-top:8px;}
.pet-tts-text{display:block;width:100%;box-sizing:border-box;font:inherit;font-size:.72rem;color:var(--text);background:rgba(var(--shade-rgb),calc(0.3 * var(--shade-scale)));border:1px solid var(--border-glass);border-radius:5px;padding:6px 8px;outline:none;caret-color:rgb(var(--other-overlay-rgb));}
.pet-tts-text:focus{border-color:rgba(var(--btn-line-rgb), var(--btn-line-alpha));}
.pet-tts-ok{color:var(--green);}
.pet-tts .pet-bad{color:var(--red);}
/* 热键区（2026-10-10）—— 行是 JS 渲染的动态列表，样式必须按结构类写，不能绑 id。 */
.pet-hotkeys{margin-top:12px;border-top:1px solid var(--border-glass);padding-top:11px;}
.pet-hotkeys .pet-note{border-top:0;padding-top:0;margin-bottom:8px;}
.pet-hk-list{display:flex;flex-direction:column;gap:8px;margin-bottom:10px;}
.pet-hk-row{display:flex;flex-wrap:wrap;gap:6px;align-items:center;padding:8px;border:1px solid var(--border-glass);border-radius:8px;}
.pet-hk-row input,.pet-hk-row select{font:inherit;font-size:.7rem;color:var(--text);background:rgba(var(--shade-rgb),calc(0.3 * var(--shade-scale)));border:1px solid var(--border-glass);border-radius:5px;padding:4px 7px;outline:none;}
.pet-hk-row input:focus,.pet-hk-row select:focus{border-color:rgba(var(--btn-line-rgb), var(--btn-line-alpha));}
.pet-hk-name{flex:1 1 96px;min-width:72px;}
.pet-hk-target{flex:1 1 96px;min-width:72px;color:var(--text-dim);font-size:.7rem;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
/* 热键行的「类型 / 表情对象」改**自绘下拉**（.custom-select，共享组件，2026-10-11）：
   行内可伸缩（原先原生 select 无 flex、按内容宽度）。 */
.pet-hk-row .custom-select{flex:1 1 110px;min-width:96px;max-width:none;}
.pet-hk-num{flex:0 0 auto;width:56px;box-sizing:border-box;text-align:right;font-variant-numeric:tabular-nums;}
.pet-hk-color{flex:0 0 auto;width:40px;height:24px;box-sizing:border-box;padding:1px 2px;cursor:pointer;}
.pet-hk-run{flex:0 0 auto;color:rgb(var(--other-overlay-rgb));}
.pet-hk-del{flex:0 0 auto;color:var(--red);}
.pet-hk-del:hover{color:var(--red);border-color:var(--red);}
/* 预设动作页（2026-10-10）—— 与热键行同一套结构类写法（动态列表，不绑 id）。 */
.pet-motions{margin:0;}
.pet-mo-list{display:flex;flex-direction:column;gap:8px;margin-bottom:10px;}
.pet-mo-row{display:flex;flex-wrap:wrap;gap:6px;align-items:center;padding:8px;border:1px solid var(--border-glass);border-radius:8px;}
.pet-mo-row input,.pet-mo-row select{font:inherit;font-size:.7rem;color:var(--text);background:rgba(var(--shade-rgb),calc(0.3 * var(--shade-scale)));border:1px solid var(--border-glass);border-radius:5px;padding:4px 7px;outline:none;}
.pet-mo-row input:focus,.pet-mo-row select:focus{border-color:rgba(var(--btn-line-rgb), var(--btn-line-alpha));}
.pet-mo-name{flex:1 1 96px;min-width:72px;}
.pet-mo-row select{flex:1 1 110px;min-width:88px;}
.pet-mo-run{flex:0 0 auto;color:rgb(var(--other-overlay-rgb));}
.pet-mo-del{flex:0 0 auto;color:var(--red);}
.pet-mo-del:hover{color:var(--red);border-color:var(--red);}
/* 调试区的开关形态 + 参数形态覆盖按钮（2026-10-10）。 */
.pet-param-on{flex:0 0 auto;min-width:52px;}
.pet-param-kind{flex:0 0 auto;display:inline-flex;align-items:center;justify-content:center;appearance:none;width:24px;height:20px;color:var(--text-dim);background:transparent;border:1px solid var(--border-glass);border-radius:999px;padding:0;cursor:pointer;line-height:0;}
.pet-param-kind:hover{color:var(--text);border-color:rgba(var(--btn-line-rgb), var(--btn-line-alpha));}
/* ── 动作链（2026-10-10，backlog ㉝②；放在动作页最上面）── */
.pet-chains{margin-bottom:12px;padding-bottom:10px;border-bottom:1px solid var(--border-glass);}
.pet-chain-list{display:flex;flex-direction:column;gap:10px;margin-top:8px;}
.pet-chain{padding:8px;border:1px solid var(--border-glass);border-radius:8px;background:rgba(var(--shade-rgb),calc(0.14 * var(--shade-scale)));}
.pet-chain-head{display:flex;gap:6px;align-items:center;flex-wrap:wrap;}
/* 展开 / 收起箭头（2026-10-11）：小方按钮，SVG 跟随文字色；展开时旋转 90 度。 */
.pet-chain-toggle{flex:0 0 auto;display:inline-flex;align-items:center;justify-content:center;width:22px;height:22px;padding:0;line-height:0;color:var(--text-dim);}
.pet-chain-toggle svg{transition:transform .12s ease;}
.pet-chain-toggle.on svg{transform:rotate(90deg);}
.pet-chain-name{flex:1 1 110px;min-width:80px;font:inherit;font-size:.72rem;color:var(--text);background:rgba(var(--shade-rgb),calc(0.3 * var(--shade-scale)));border:1px solid var(--border-glass);border-radius:5px;padding:4px 7px;outline:none;}
.pet-chain-name:focus{border-color:rgba(var(--btn-line-rgb), var(--btn-line-alpha));}
.pet-chain-total{flex:0 0 auto;font-size:.66rem;color:var(--text-dim);}
.pet-chain-loopbtn{flex:0 0 auto;}
/* 折叠态**摘要**：一行、过长省略（只显示「文件 · 循环 · 硬停」的拼接）。 */
.pet-chain-summary{display:none;margin:6px 0 0;font-size:.66rem;line-height:1.5;color:var(--text-dim);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.pet-chain.collapsed .pet-chain-summary{display:block;}
/* 折叠：藏起步骤列表与「添加步骤」。 */
.pet-chain.collapsed .pet-chain-steps{display:none;}
.pet-chain.collapsed [data-chain-step-add]{display:none;}
.pet-chain-steps{display:flex;flex-direction:column;gap:6px;margin:8px 0;}
/* 每一步 = 上「一行四个控件」（名称 / 循环 / 硬停 / 删除，**不换行**）+ 下「进度条」。 */
.pet-chain-step{display:flex;flex-direction:column;gap:0;}
.pet-chain-fields{display:flex;align-items:center;gap:6px;flex-wrap:nowrap;min-width:0;}
/* 动作链每一步的**动作文件下拉**改自绘 .custom-select（2026-10-11）：占满该行剩余宽度。 */
.pet-chain-fields .custom-select{flex:1 1 auto;min-width:0;max-width:none;}
/* 仍为**原生 select** 的几处（热键行的 group / id / mode / enabled、动作行）：
   收合面按 docs/ui-style.md §界面 12 基准对齐（高 26 / 圆角 6 / 内边距 5px 8px /
   font-size .73rem / 底 rgba(var(--shade-rgb), calc(0.25 * var(--shade-scale))) /
   描边 var(--border-glass) = 按钮线条 α0.10 / 文字 var(--text)）；弹出层由 OS 绘制、
   不可样式化（§界面 12 硬豁免）。
   ⚠️ 热键行的「类型 / 表情对象」与动作链步骤的动作文件**已改自绘 .custom-select**（外观由
   styles.css 的共享规则给），不再进本组。
   单独成组、不并进上面的 input,select 共享规则：那条规则里有一批 input 专有覆盖
   （.pet-hk-color 的圆角 / 内边距等），合并进去会误伤它们。 */
.pet-hk-row select,.pet-mo-row select{box-sizing:border-box;height:26px;font-size:.73rem;background:rgba(var(--shade-rgb),calc(0.25 * var(--shade-scale)));border:1px solid var(--border-glass);border-radius:6px;padding:5px 8px;color:var(--text);}
.pet-chain-t{flex:0 0 auto;display:inline-flex;align-items:center;gap:3px;font-size:.66rem;color:var(--text-dim);white-space:nowrap;}
/* 「循环」「硬停」两个数字框**收窄**到约 4 个字符宽（用户 2026-10-11 口径）：
   字号 .7rem 下 4.2em 约 47px，去掉内边距 / 边框后仍能看清「3.0」「12.5」这类值。
   右对齐 + 等宽数字，多位数字也稳。 */
.pet-chain-num{width:4.2em;box-sizing:border-box;font:inherit;font-size:.7rem;color:var(--text);background:rgba(var(--shade-rgb),calc(0.3 * var(--shade-scale)));border:1px solid var(--border-glass);border-radius:5px;padding:3px 5px;outline:none;text-align:right;font-variant-numeric:tabular-nums;caret-color:rgb(var(--other-overlay-rgb));}
.pet-chain-del{flex:0 0 auto;color:var(--red);padding:2px 8px;}
.pet-chain-run{flex:0 0 auto;}
/* 进度条：动作页每行 / 动作链每步下方（子元素 i 为填充、span 为覆盖文字）。 */
.pet-chain-bar{position:relative;flex:1 1 100%;height:16px;margin-top:3px;border-radius:5px;overflow:hidden;background:rgba(var(--shade-rgb),calc(0.28 * var(--shade-scale)));border:1px solid var(--border-glass);}
/* 动作链里进度条是「一行控件」的下方兄弟（父容器已是竖向 flex）⇒ 改成不收缩、占满整行宽。 */
.pet-chain-step .pet-chain-bar{flex:0 0 auto;width:100%;}
.pet-chain-bar i{position:absolute;left:0;top:0;bottom:0;width:0;background:rgb(var(--other-overlay-rgb));opacity:.35;transition:width .08s linear;}
.pet-chain-bar span{position:absolute;left:6px;right:6px;top:0;bottom:0;display:flex;align-items:center;font-size:.62rem;color:var(--text-dim);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;pointer-events:none;}
`;
let Jt = null;
async function Lr(e) {
  const t = (r) => e.querySelector(`#${r}`), n = t("pet-stage"), a = t("pet-img"), o = t("pet-l2d"), c = t("pet-err"), h = t("pet-toast"), b = t("pet-empty"), y = t("pet-menu"), M = t("pet-root"), L = t("pet-chat-bubble"), $ = t("pet-chat-text"), K = t("pet-chat-close"), q = t("pet-chat-stop"), j = t("pet-chat-input");
  let Q = 0, P = A(), R = null, ce = "", pe = 0, it = !0, ht = null, xt = [], st = 0, _t = "", Ct = null, $t = !0;
  L == null || L.addEventListener("scroll", () => {
    L && ($t = L.scrollHeight - L.scrollTop - L.clientHeight <= 2);
  });
  function kt(r) {
    c && (c.textContent = r, c.classList.toggle("on", !!r));
  }
  let At = null;
  function at(r, i) {
    h && (h.textContent = r, h.classList.add("on"), At && clearTimeout(At), At = setTimeout(() => {
      At = null, h.classList.remove("on");
    }, i));
  }
  function Qt() {
    try {
      R == null || R.destroy();
    } catch (r) {
      console.warn("[pet] dropModel failed:", r);
    }
    R = null;
  }
  async function ue() {
    const r = ++pe;
    P = A(), kt("");
    const i = P.model.trim(), m = P.image.trim();
    if (i && o) {
      a && (a.removeAttribute("src"), a.style.display = "none"), b && (b.style.display = "none"), o.classList.add("on"), he(), Qt(), o.querySelectorAll("canvas").forEach((k) => k.remove()), Xt.clear(), rn();
      try {
        const { mountLive2D: k } = await ar(), O = await ur(i), z = await ve(i), X = z.map((tt) => ({ name: tt.name, file: tt.path })), U = Ta(i), J = z.filter((tt) => U.has(tt.name.toLowerCase())).map((tt) => ({ name: tt.name, file: tt.path })), lt = await k(o, {
          modelPath: i,
          scale: P.scale,
          offsetX: P.offsetX,
          offsetY: P.offsetY,
          rotation: P.rotation,
          extraExpressions: O,
          extraMotions: X,
          idleMotions: J,
          // 动作进度（2026-10-10）：引擎 → 本窗 → 设置窗画进度条（`motion-progress` 广播）。
          onMotionProgress: (tt) => {
            G(H, {
              type: "motion-progress",
              chainId: ce,
              p: tt ? { index: tt.index, elapsedMs: tt.elapsedMs, totalMs: tt.totalMs, chainStep: tt.chainStep } : null
            });
          }
        });
        if (r !== pe) {
          lt.destroy();
          return;
        }
        R = lt;
        const Yt = A();
        let Kt = null;
        try {
          const tt = lt.listCoreIds(), Mt = await ke(i) ?? Mn(i);
          (tt.parameters.length || tt.drawables.length || tt.parts.length) && (Mt.coreIds = tt, localStorage.setItem(Aa + i.toLowerCase(), JSON.stringify(tt)));
          const on = Yt.params[i];
          (!Mt.params || !Object.keys(Mt.params).length) && on && typeof on == "object" && (Mt.params = { ...on }), Kt = Mt.params, await He(i, Mt);
        } catch (tt) {
          console.warn("[pet] 读/写 lunac.params.json 失败", tt);
        }
        lt.setScale(Yt.scale), lt.setOffset(Yt.offsetX, Yt.offsetY), lt.setRunning(it);
        const Lt = Yt.expressions[i];
        Lt && lt.setExpression(Lt);
        const Wn = Kt && Object.keys(Kt).length ? Kt : Yt.params[i];
        if (Wn)
          for (const [tt, Mt] of Object.entries(Wn))
            typeof Mt == "number" && lt.setParameter(tt, Mt);
        await qa(i);
      } catch (k) {
        if (r !== pe) return;
        Qt(), o.classList.remove("on"), kt(`Live2D 载入失败：${k instanceof Error ? k.message : String(k)}`);
      }
      return;
    }
    Qt(), o == null || o.classList.remove("on"), a && b && (m ? (a.src = Ft(m), a.style.display = "", b.style.display = "none") : (a.removeAttribute("src"), a.style.display = "none", b.style.display = "")), a && Rt(0), it && Ee();
  }
  function Rt(r) {
    a && (a.style.transform = `translate(${P.offsetX}px, ${P.offsetY + r}px) scale(${P.scale})`);
  }
  function Wt(r) {
    if (P = { ...P, scale: r }, R) {
      R.setScale(r);
      return;
    }
    Rt(0);
  }
  function Me(r, i) {
    if (P = { ...P, offsetX: r, offsetY: i }, R) {
      R.setOffset(r, i);
      return;
    }
    Rt(0);
  }
  function de(r) {
    P = { ...P, rotation: r }, R == null || R.setRotation(r);
  }
  const fe = performance.now();
  function zt(r) {
    if (Q = requestAnimationFrame(zt), !!e.isConnected && a && a.style.display !== "none") {
      const i = Math.sin((r - fe) / 1400) * 3;
      Rt(i);
    }
  }
  function Ee() {
    Q || (Q = requestAnimationFrame(zt));
  }
  function he() {
    Q && cancelAnimationFrame(Q), Q = 0;
  }
  async function jt(r) {
    try {
      await d("plugin_window_set_click_through", { ignore: r });
    } catch (i) {
      console.error("[lunac pet] 设置穿透失败：", i);
    }
    await d("pet_alt_rclick_watch", { on: r }).catch(() => {
    });
  }
  let te = !1;
  function St() {
    const r = document.getElementById("pet-menu-through");
    r && (r.textContent = en(P.clickThrough));
  }
  function Ht() {
    y == null || y.classList.remove("open"), te && (te = !1, jt(!0));
  }
  function Ce(r, i) {
    y && (St(), y.style.left = `${Math.max(2, Math.min(r, window.innerWidth - 140))}px`, y.style.top = `${Math.max(2, Math.min(i, window.innerHeight - 240))}px`, y.classList.add("open"));
  }
  async function nn(r, i) {
    P.clickThrough && !te && (te = !0, await jt(!1));
    let m = r, k = i;
    try {
      const O = await It().outerPosition(), z = window.devicePixelRatio || 1;
      m = (r - O.x) / z, k = (i - O.y) / z;
    } catch {
      m = window.innerWidth / 2, k = window.innerHeight / 2;
    }
    Ce(m, k);
  }
  n == null || n.addEventListener("contextmenu", (r) => {
    r.preventDefault(), Ce(r.clientX, r.clientY);
  });
  let ut = null;
  const Bt = (r) => {
    ut && Me(ut.ox + (r.clientX - ut.sx), ut.oy + (r.clientY - ut.sy));
  }, ee = () => {
    ut && (ut = null, window.removeEventListener("mousemove", Bt), window.removeEventListener("mouseup", ee), Y(P));
  };
  function $e(r) {
    ut = { sx: r.clientX, sy: r.clientY, ox: P.offsetX, oy: P.offsetY }, window.addEventListener("mousemove", Bt), window.addEventListener("mouseup", ee), r.preventDefault(), Ht();
  }
  n == null || n.addEventListener("mousedown", (r) => {
    if (r.button === 0) {
      if (r.altKey) {
        $e(r);
        return;
      }
      Ht(), It().startDragging().catch(() => {
      });
    }
  }), e.addEventListener("mousedown", (r) => {
    y != null && y.classList.contains("open") && !y.contains(r.target) && Ht();
  }), n == null || n.addEventListener(
    "wheel",
    (r) => {
      const i = n == null ? void 0 : n.getBoundingClientRect();
      if (!i || !R && (!a || a.style.display === "none")) return;
      r.preventDefault();
      const m = r.clientX - i.left, k = r.clientY - i.top, O = r.deltaY < 0 ? Zn : 1 / Zn, z = Math.min(ma, Math.max(ha, P.scale * O));
      if (z !== P.scale) {
        if (R) {
          const X = R.zoomAtPointer(O, m, k);
          P = { ...P, scale: X.scale, offsetX: X.offsetX, offsetY: X.offsetY };
        } else {
          const X = i.width / 2, U = i.height, J = z / P.scale;
          P = {
            ...P,
            scale: z,
            offsetX: (m - X) * (1 - J) + J * P.offsetX,
            offsetY: (k - U) * (1 - J) + J * P.offsetY
          }, Rt(0);
        }
        Y(P), G(H, { type: "scale-changed", value: P.scale });
      }
    },
    { passive: !1 }
  );
  async function an() {
    var O;
    at(w("pet.look_screen_working"), 2e3);
    let r = null;
    try {
      r = await d("screenshot_monitor", {
        label: re
      });
    } catch (z) {
      yt("看一眼屏幕失败", z), at(w("pet.look_screen_failed"), 2600);
      return;
    }
    const i = r == null ? void 0 : r.path;
    if (!i) {
      at(w("pet.look_screen_failed"), 2600);
      return;
    }
    let m = !1;
    try {
      m = !!((O = await d("get_ai_config")) != null && O.vision);
    } catch {
    }
    if (!m) {
      at(w("pet.look_screen_need_vision"), 3400);
      return;
    }
    const k = w("pet.look_screen_query");
    try {
      localStorage.setItem(Ui, JSON.stringify({ query: k, path: i }));
    } catch {
    }
    await d("open_plugin_window", { pluginId: "chat", key: null, input: k, hidden: !0 });
  }
  let Vt = !1;
  function Ut(r, i = !0, m = !0) {
    Vt = r, r || Gt(!0), M == null || M.classList.toggle("chat-on", r), M == null || M.classList.toggle("chat-input-on", r && m), r && m && i && (j == null || j.focus());
  }
  function Ae(r, i = !1) {
    Gt(!1);
    const m = Jn(r);
    $ && ($.textContent = m), L == null || L.classList.toggle("thinking", !!i), $t = !0, $ != null && $.parentElement && ($.parentElement.scrollTop = 0);
  }
  function Le() {
    L && (L.scrollTop = L.scrollHeight);
  }
  function Te() {
    ht && (clearInterval(ht), ht = null);
    const r = Ct;
    Ct = null, xt = [], st = 0, _t = "", r && r();
  }
  function Gt(r) {
    const i = ht !== null;
    ht && (clearInterval(ht), ht = null), i && (r && $ && ($.textContent = xt.join("")), $t && Le()), xt = [], st = 0, _t = "";
    const m = Ct;
    Ct = null, i && m && m();
  }
  function ne(r, i) {
    Gt(!1);
    const m = Jn(r);
    if (L == null || L.classList.remove("thinking"), $t = !0, !$) {
      i == null || i();
      return;
    }
    const k = tn(A().speechRate), O = Bi(m);
    if (!it || Vi(O.length, k, Wi)) {
      $.textContent = m, L && (L.scrollTop = 0), i == null || i();
      return;
    }
    xt = O, st = 0, _t = "", Ct = i ?? null, ht = setInterval(() => {
      _t += xt[st] ?? "", st++, $ && ($.textContent = _t), $t && Le(), st >= xt.length && Te();
    }, 1e3 / k);
  }
  function ae(r) {
    q == null || q.classList.toggle("on", r);
  }
  function s(r, i) {
    const m = r.trim();
    if (!m) return !1;
    Ae(w("pet.ai_chat_thinking"), !0), Vt || On();
    const k = { query: m };
    return i && i.length && (k.files = i), G(Gi, k).catch((O) => yt("发送 AI 消息失败", O)), ae(!0), !0;
  }
  let l = 0, g = 0, f = null, E = null, C = !1, T = null, _ = !1;
  function F() {
    f && (clearTimeout(f), f = null);
  }
  function B(r = !1) {
    F();
    const i = A().proactive;
    if (i.enabled && it) {
      if (Pt() >= i.dailyCap) {
        Z();
        return;
      }
      r && (l = 0), l <= 0 && (l = i.intervalMin * 6e4), g = performance.now() + l, f = setTimeout(W, l);
    }
  }
  function Z() {
    const r = hn();
    l = r, g = performance.now() + r, f = setTimeout(() => {
      f = null, l = 0, B(!0), rt(), bt();
    }, r);
  }
  function et() {
    f && (clearTimeout(f), f = null, l = Math.max(0, g - performance.now()));
  }
  function W() {
    f = null;
    const r = A().proactive;
    if (!(!r.enabled || !it)) {
      if (Pt() >= r.dailyCap) {
        B();
        return;
      }
      if (C) {
        B();
        return;
      }
      if (l = 0, C = !0, !s(w("pet.proactive_prompt"))) {
        C = !1, B();
        return;
      }
      fn(), G(H, { type: "proactive-used" }), E = setTimeout(() => {
        E = null, C && (C = !1, B());
      }, un);
    }
  }
  function u() {
    C && (C = !1, E && (clearTimeout(E), E = null), B());
  }
  let x = null, v = null, p = null, S = !1;
  async function D(r) {
    var O;
    let i = !1;
    try {
      i = !!((O = await d("get_ai_config")) != null && O.vision);
    } catch {
    }
    if (!i)
      return S || (S = !0, d("log_frontend", {
        level: "warn",
        message: "[pet] 抓屏子开关已到点，但当前未开启「图片输入」⇒ 跳过（图片块会被静默丢弃，不白烧 token）。要让它真的发出去，请在 AI 设置里开启图片输入 / 换支持视觉的模型。"
      }).catch(() => {
      })), !1;
    at(w("pet.look_screen_working"), 2e3);
    let m = null;
    try {
      m = await d("screenshot_monitor", { label: re });
    } catch (z) {
      return yt("自动抓屏失败", z), !1;
    }
    const k = m == null ? void 0 : m.path;
    return k ? s(r, [k]) : !1;
  }
  const N = () => {
    x && (clearTimeout(x), x = null);
  }, nt = () => {
    v && (clearTimeout(v), v = null);
  };
  function rt() {
    N();
    const r = A().proactive;
    if (!(!r.autoShot || !it)) {
      if (Pt() >= r.dailyCap) {
        x = setTimeout(rt, hn());
        return;
      }
      x = setTimeout(qt, r.autoShotMin * 6e4);
    }
  }
  async function qt() {
    x = null;
    const r = A().proactive;
    if (!r.autoShot || !it) return;
    if (Pt() >= r.dailyCap || C) {
      rt();
      return;
    }
    if (C = !0, !await D(w("pet.autoshot_prompt"))) {
      C = !1, rt();
      return;
    }
    fn(), G(H, { type: "proactive-used" }), E = setTimeout(() => {
      E = null, C && (C = !1);
    }, un), rt();
  }
  function bt(r = 0) {
    nt();
    const i = A().proactive;
    if (!(!i.screenWatch || !it)) {
      if (Pt() >= i.dailyCap) {
        v = setTimeout(bt, hn());
        return;
      }
      v = setTimeout(Ra, r > 0 ? r : i.screenWatchSec * 1e3);
    }
  }
  async function Ra() {
    v = null;
    const r = A().proactive;
    if (!r.screenWatch || !it || Pt() >= r.dailyCap) return;
    let i = null;
    try {
      const m = await d("screenshot_signature", { label: re });
      Array.isArray(m) && m.length && (i = m.map((k) => Number(k) || 0));
    } catch {
    }
    if (i) {
      const m = !!p && p.length === i.length && nr(p, i) >= r.screenDiff;
      if (p = i, m && !C) {
        Wa(r);
        return;
      }
    }
    bt();
  }
  async function Wa(r) {
    C = !0, await D(w("pet.watch_prompt")) ? (fn(), G(H, { type: "proactive-used" }), E = setTimeout(() => {
      E = null, C && (C = !1);
    }, un)) : C = !1, p = null, bt(Math.max(r.intervalMin, 1) * 6e4);
  }
  function In() {
    it = !1, Gt(!0), he(), R == null || R.setRunning(!1), Ht(), et(), N(), nt(), p = null;
  }
  function Pn() {
    it = !0, R ? R.setRunning(!0) : Ee(), B(), rt(), bt();
  }
  function On() {
    T && (clearTimeout(T), T = null), Vt || (_ = !0, Ut(!0, !1, !1));
  }
  function za() {
    T && (clearTimeout(T), T = null), _ && (T = setTimeout(() => {
      T = null, _ = !1, Vt && Ut(!1);
    }, Ki));
  }
  const Dn = (r) => {
    r.key !== "Enter" || r.shiftKey || r.isComposing || (r.preventDefault(), j && s(j.value) && (j.value = ""));
  }, Fn = () => Ut(!1), ja = () => {
    ae(!1), Ae(w("pet.chat_reply_interrupted"), !0), G(Xi).catch((r) => yt("中止 AI 消息失败", r));
  };
  j == null || j.addEventListener("keydown", Dn), K == null || K.addEventListener("click", Fn), q == null || q.addEventListener("click", ja);
  let gt = null;
  function Ha(r, i) {
    if (gt && (clearInterval(gt), gt = null), !r.length || !i) return;
    const m = 1e3 / i, k = performance.now();
    gt = setInterval(() => {
      const O = Math.floor((performance.now() - k) / m);
      if (O >= r.length) {
        gt && clearInterval(gt), gt = null, R == null || R.setMouthOpen(null);
        return;
      }
      R == null || R.setMouthOpen(r[O] / 255);
    }, m);
  }
  const Ba = await It().listen(
    Yi,
    (r) => {
      var O, z;
      if (!Et()) return;
      const m = (Array.isArray((O = r.payload) == null ? void 0 : O.env) ? r.payload.env : []).map((X) => typeof X == "number" && Number.isFinite(X) ? X : 0), k = typeof ((z = r.payload) == null ? void 0 : z.fps) == "number" && r.payload.fps > 0 ? r.payload.fps : 40;
      Ha(m, k);
    }
  ), Va = await It().listen(qi, (r) => {
    var m;
    if (!Et()) return;
    const i = typeof ((m = r.payload) == null ? void 0 : m.text) == "string" ? r.payload.text : "";
    ae(!1), i && A().tts && d("tts_speak", { text: i, enabled: !0 }).catch(() => {
    }), it && On(), ne(i, () => {
      it && za();
    }), u();
  });
  y == null || y.addEventListener("click", (r) => {
    var m;
    const i = (m = r.target.closest("button")) == null ? void 0 : m.dataset.act;
    i && (Ht(), (async () => {
      if (i === "ai-chat") {
        Ut(!Vt);
        return;
      }
      if (i === "settings") {
        await d("open_plugin_window", { pluginId: "pet", key: "settings", input: "" });
        return;
      }
      if (i === "look-screen") {
        await an();
        return;
      }
      if (i === "change") {
        const k = await gn({
          multiple: !1,
          directory: !0,
          title: "选择 Live2D 模型文件夹（里面要有 *.model3.json）"
        }), O = typeof k == "string" ? k : "";
        if (!O) return;
        let z = "", X = "";
        try {
          const J = await d("scan_model_folder", { dir: O });
          z = (J.model3 ?? [])[0] ?? "", X = (J.vtube ?? [])[0] ?? "";
        } catch (J) {
          at("读文件夹失败", 2600), yt("更换模型：读文件夹失败", J);
          return;
        }
        if (!z) {
          at("这个文件夹里没有 *.model3.json", 2600);
          return;
        }
        const U = await ua(z);
        if (!U.ok) {
          at(`这个模型用不了：${U.reason}`, 3e3);
          return;
        }
        Y({ ...A(), model: z, image: "" });
        try {
          await kn(O, z, X);
        } catch (J) {
          yt("更换模型：读取热键失败", J);
        }
        ue();
        return;
      }
      if (i === "reset") {
        Wt(1), Me(0, 0), de(0), Y(P), G(H, { type: "scale-changed", value: 1 }), G(H, { type: "rotation-changed", value: 0 }), at("已恢复默认大小、位置与角度", 2e3);
        return;
      }
      if (i === "through") {
        const k = !P.clickThrough;
        P = { ...P, clickThrough: k }, Y(P), await jt(k), St(), G(H, { type: "click-through-changed", value: k });
        return;
      }
      i === "close" && await d("plugin_window_close").catch(() => {
      });
    })().catch((k) => yt("菜单动作失败", k)));
  });
  function Ua(r) {
    const i = R;
    if (!i) {
      at("桌宠还没显示 Live2D 模型", 2600);
      return;
    }
    switch (r.type) {
      case "motion":
        i.playMotion(r.group, r.index);
        break;
      case "chain":
        me(r.id);
        break;
      case "expression":
        r.mode === "clear" || !r.target ? i.resetExpressions() : i.setExpression(r.target);
        break;
      case "param":
        i.setParameter(r.id, r.mode === "add" ? i.getParameter(r.id) + r.value : r.value);
        break;
      case "artmesh":
        i.setDrawableOpacity(r.id, r.value);
        break;
      case "part":
        i.setPartOpacity(r.id, r.value);
        break;
      case "physics":
        i.setPhysicsEnabled(r.enabled);
        break;
    }
  }
  const Xt = /* @__PURE__ */ new Set(), Rn = /* @__PURE__ */ new Map(), rn = () => {
    G(H, { type: "hotkey-states", ids: [...Xt] });
  };
  function Ga() {
    const r = A().model.trim();
    if (!r) return;
    const i = [...Xt].filter((O) => {
      const z = Rn.get(O);
      return z !== "motion" && z !== "chain";
    }), m = A(), k = { ...m.hotkeyStates };
    i.length ? k[r] = i : delete k[r], Y({ ...m, hotkeyStates: k });
  }
  async function qa(r) {
    const i = A().hotkeyStates[r] ?? [];
    if (!i.length) return;
    let m;
    try {
      m = await oe(r);
    } catch {
      return;
    }
    const k = new Map(m.map((O) => [O.id, O]));
    for (const O of i) {
      const z = k.get(O);
      !z || z.action.type === "motion" || Xt.has(O) || await Ne(O, z.action);
    }
  }
  async function me(r) {
    const i = R, m = P.model.trim();
    if (!i || !m || !r) {
      at("桌宠还没显示 Live2D 模型", 2600);
      return;
    }
    const O = (await We(m)).find((U) => U.id === r);
    if (!O || !O.steps.length) {
      at("这条动作链是空的", 2200);
      return;
    }
    const z = await ve(m), X = O.steps.map((U) => ({ index: z.findIndex((lt) => lt.path.toLowerCase() === U.file.toLowerCase()), ms: Sn(U) * 1e3, hardMs: U.stopSec > 0 ? U.stopSec * 1e3 : 0 })).filter((U) => U.index >= 0);
    if (!X.length) {
      at("动作链里的动作文件都不在了", 2400);
      return;
    }
    ce = r, i.playChain(X, O.loop);
  }
  async function Ne(r, i) {
    const m = R;
    if (!m) {
      at("桌宠还没显示 Live2D 模型", 2600);
      return;
    }
    const k = !Xt.has(r);
    switch (Rn.set(r, i.type), i.type) {
      case "expression": {
        const O = i.file ? await ga(i.file) : [];
        O.length ? m.setExpressionLayer(r, k ? O : null) : k ? i.target && m.setExpression(i.target) : m.resetExpressions();
        break;
      }
      case "artmesh":
        m.setDrawableOpacity(i.id, k ? i.value : 1);
        break;
      case "artmeshColor":
        m.setDrawableColor(i.id, k ? Sr(i.color) : null);
        break;
      case "part":
        m.setPartOpacity(i.id, k ? i.value : 1);
        break;
      case "physics":
        m.setPhysicsEnabled(k ? i.enabled : !i.enabled);
        break;
      case "param":
        m.setParameter(i.id, k ? i.value : 0);
        break;
      case "motion":
        k && m.playMotion(i.group, i.index);
        break;
      case "chain":
        k ? await me(i.id) : (ce = "", m.stopChain());
        break;
    }
    k ? Xt.add(r) : Xt.delete(r), rn(), Ga();
  }
  async function Xa(r, i, m) {
    const k = R, O = P.model.trim(), z = i.trim();
    if (!(!k || !O || !z)) {
      if (r === "auto") {
        const U = (await oe(O)).find((Lt) => Lt.keys.trim().toLowerCase() === z.toLowerCase());
        if (U) {
          await Ne(U.id, U.action);
          return;
        }
        const lt = (await ve(O)).findIndex((Lt) => Lt.name.trim().toLowerCase() === z.toLowerCase());
        if (lt >= 0) {
          k.playMotion(yn, lt);
          return;
        }
        const Kt = (await We(O)).find((Lt) => Lt.name.trim().toLowerCase() === z.toLowerCase());
        if (Kt) {
          await me(Kt.id);
          return;
        }
        k.setExpression(z);
        return;
      }
      if (r === "chain") {
        const X = await We(O), U = X.find((J) => J.id === z) || X.find((J) => J.name.trim().toLowerCase() === z.toLowerCase());
        U && await me(U.id);
        return;
      }
      if (r === "hotkey") {
        const X = await oe(O), U = X.find((J) => J.keys.trim().toLowerCase() === z.toLowerCase()) || X.find((J) => J.name.trim() === z);
        U && await Ne(U.id, U.action);
        return;
      }
      if (r === "motion") {
        const U = (await ve(O)).findIndex((J) => J.name.trim().toLowerCase() === z.toLowerCase());
        U >= 0 && k.playMotion(yn, U);
        return;
      }
      if (r === "param") {
        k.setParameter(z, typeof m == "number" ? m : 0);
        return;
      }
      if (r === "expression") {
        m === 0 ? k.resetExpressions() : k.setExpression(z);
        return;
      }
      if (r === "artmeshColor") {
        const X = typeof m == "number" && Number.isFinite(m) ? Math.floor(m) : 16777215, U = Math.min(16777215, Math.max(0, X));
        k.setDrawableColor(z, {
          r: (U >> 16 & 255) / 255,
          g: (U >> 8 & 255) / 255,
          b: (U & 255) / 255
        });
      }
    }
  }
  const Ya = await pt(H, (r) => {
    const i = r.payload;
    if (i != null && i.type) {
      if (i.type === "ping") {
        Et() && (G(H, { type: "pong", token: i.token, visible: it }), rn());
        return;
      }
      if (i.type === "reload") {
        ue();
        return;
      }
      if (i.type === "hide" && Et()) {
        In(), It().hide().catch((m) => yt("隐藏模型失败", m));
        return;
      }
      if (i.type === "show" && Et()) {
        (async () => {
          try {
            const m = It();
            await m.unminimize().catch(() => {
            }), await m.show();
          } catch (m) {
            yt("显示模型失败", m);
          }
          Pn();
        })();
        return;
      }
      if (i.type === "set-scale" && typeof i.value == "number") {
        Y({ ...A(), scale: i.value }), Wt(i.value);
        return;
      }
      if (i.type === "set-rotation" && typeof i.value == "number") {
        Y({ ...A(), rotation: i.value }), de(i.value);
        return;
      }
      if (i.type === "set-click-through" && typeof i.value == "boolean" && (P = { ...P, clickThrough: i.value }, jt(i.value), St()), i.type === "set-proactive") {
        const m = A(), k = ze.proactive, O = (z, X, U, J) => typeof z == "number" && Number.isFinite(z) ? Math.min(U, Math.max(X, Math.round(z))) : J;
        Y({
          ...m,
          proactive: {
            ...m.proactive,
            enabled: i.enabled === !0,
            intervalMin: O(i.intervalMin, Cn, $n, m.proactive.intervalMin),
            dailyCap: O(i.dailyCap, An, Ln, m.proactive.dailyCap),
            // 子开关：**只有显式 true 才算开**（同 loadConfig 口径，默认关是隐私红线）。
            autoShot: i.autoShot === !0,
            autoShotMin: O(i.autoShotMin, Be, Ve, k.autoShotMin),
            screenWatch: i.screenWatch === !0,
            screenWatchSec: O(i.screenWatchSec, Ue, Ge, k.screenWatchSec),
            screenDiff: O(i.screenDiff, qe, Xe, k.screenDiff)
          }
        }), B(!0), (i.screenWatch !== !0 || i.screenWatchSec !== m.proactive.screenWatchSec) && (p = null), rt(), bt();
        return;
      }
      if (i.type === "set-param" && typeof i.id == "string" && typeof i.value == "number") {
        R == null || R.setParameter(i.id, i.value);
        return;
      }
      if (i.type === "reset-params" && Array.isArray(i.ids)) {
        const m = R;
        if (m)
          for (const k of i.ids) typeof k == "string" && m.setParameter(k, 0);
        return;
      }
      if (i.type === "set-expression" && typeof i.id == "string") {
        if (!R) return;
        i.id ? R.setExpression(i.id) : R.resetExpressions();
        return;
      }
      if (i.type === "hotkey-run" && i.action && typeof i.action == "object") {
        Ua(i.action);
        return;
      }
      if (i.type === "hotkey-toggle" && typeof i.id == "string" && i.action && typeof i.action == "object") {
        Ne(i.id, i.action);
        return;
      }
      if (i.type === "motion-play" && typeof i.group == "string") {
        const m = R;
        if (!m) {
          at("桌宠还没显示 Live2D 模型", 2600);
          return;
        }
        m.playMotion(i.group, typeof i.index == "number" ? i.index : 0);
        return;
      }
      if (i.type === "chain-play" && typeof i.id == "string" && Et()) {
        me(i.id);
        return;
      }
      i.type === "ai-action" && typeof i.action == "string" && typeof i.name == "string" && Xa(i.action, i.name, typeof i.value == "number" ? i.value : void 0);
    }
  }), Ka = await pt(
    "plugin-window-visibility",
    (r) => {
      var i, m;
      (i = r.payload) != null && i.label && r.payload.label !== re || (((m = r.payload) == null ? void 0 : m.visible) === !1 ? In() : Pn());
    }
  );
  Fa(), d("plugin_window_resize", { width: tr, height: er }).catch(() => {
  }), ue(), P.clickThrough && await jt(!0), G(H, { type: "click-through-changed", value: P.clickThrough }), B(!0), rt(), bt();
  const Ja = await pt("pet-alt-rclick", (r) => {
    var k, O;
    if (!Et()) return;
    const i = Number((k = r.payload) == null ? void 0 : k.x), m = Number((O = r.payload) == null ? void 0 : O.y);
    !Number.isFinite(i) || !Number.isFinite(m) || nn(i, m).catch((z) => yt("Alt+右键唤出菜单失败", z));
  });
  Jt = () => {
    he(), Qt(), At && clearTimeout(At), F(), N(), nt(), E && clearTimeout(E), T && clearTimeout(T), gt && (clearInterval(gt), gt = null), Ya(), Ka(), Ja(), Va(), Ba(), R == null || R.setMouthOpen(null), j == null || j.removeEventListener("keydown", Dn), K == null || K.removeEventListener("click", Fn), window.removeEventListener("mousemove", Bt), window.removeEventListener("mouseup", ee), d("pet_alt_rclick_watch", { on: !1 }).catch(() => {
    });
  };
}
const Tr = {
  id: "pet",
  name: "桌宠",
  keywords: ["桌宠", "宠物", "桌面宠物", "pet", "desktop pet", "live2d", "看板娘", "吉祥物"],
  description: "桌宠 —— 独立透明置顶的桌面形象窗（图片或 Live2D 模型，由你自己导入）",
  icon: "🐾",
  // **刻意不声明 `window.float`**：它的入口是**带 key 的附属窗**（`plugin-pet-settings`），
  // 不是自己的形象窗 —— `main.ts` 的 `executePlugin` 按 id 特判直接开那扇窗（2026-10-09）。
  permissions: [],
  async execute(e) {
    return Et() ? { type: "html", content: $r() } : Qn() ? { type: "html", content: Er(A()) } : { type: "html", content: "" };
  },
  async attach(e) {
    if (Et()) {
      await Lr(e);
      return;
    }
    if (Qn()) {
      await Cr(e);
      return;
    }
  },
  detach() {
    Jt == null || Jt(), Jt = null;
  }
};
export {
  Tr as default
};
