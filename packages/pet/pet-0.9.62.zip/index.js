function Ai(e, t, n, a) {
  if (typeof t == "function" ? e !== t || !a : !t.has(e)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return n === "m" ? a : n === "a" ? a.call(e) : a ? a.value : t.get(e);
}
function Ni(e, t, n, a, o) {
  if (typeof t == "function" ? e !== t || !0 : !t.has(e)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return t.set(e, n), n;
}
var Qe;
const bt = "__TAURI_TO_IPC_KEY__";
function Li(e, t = !1) {
  return window.__TAURI_INTERNALS__.transformCallback(e, t);
}
async function d(e, t = {}, n) {
  return window.__TAURI_INTERNALS__.invoke(e, t, n);
}
function Xt(e, t = "asset") {
  return window.__TAURI_INTERNALS__.convertFileSrc(e, t);
}
class Ii {
  get rid() {
    return Ai(this, Qe, "f");
  }
  constructor(t) {
    Qe.set(this, void 0), Ni(this, Qe, t);
  }
  /**
   * Destroys and cleans up this resource from memory.
   * **You should not call any method on this object anymore and should drop any reference to it.**
   */
  async close() {
    return d("plugin:resources|close", {
      rid: this.rid
    });
  }
}
Qe = /* @__PURE__ */ new WeakMap();
var dt;
(function(e) {
  e.WINDOW_RESIZED = "tauri://resize", e.WINDOW_MOVED = "tauri://move", e.WINDOW_CLOSE_REQUESTED = "tauri://close-requested", e.WINDOW_DESTROYED = "tauri://destroyed", e.WINDOW_FOCUS = "tauri://focus", e.WINDOW_BLUR = "tauri://blur", e.WINDOW_SCALE_FACTOR_CHANGED = "tauri://scale-change", e.WINDOW_THEME_CHANGED = "tauri://theme-changed", e.WINDOW_CREATED = "tauri://window-created", e.WINDOW_SUSPENDED = "tauri://suspended", e.WINDOW_RESUMED = "tauri://resumed", e.WEBVIEW_CREATED = "tauri://webview-created", e.DRAG_ENTER = "tauri://drag-enter", e.DRAG_OVER = "tauri://drag-over", e.DRAG_DROP = "tauri://drag-drop", e.DRAG_LEAVE = "tauri://drag-leave";
})(dt || (dt = {}));
async function Ia(e, t) {
  window.__TAURI_EVENT_PLUGIN_INTERNALS__.unregisterListener(e, t), await d("plugin:event|unlisten", {
    event: e,
    eventId: t
  });
}
async function ft(e, t, n) {
  var a;
  const o = typeof (n == null ? void 0 : n.target) == "string" ? { kind: "AnyLabel", label: n.target } : (a = n == null ? void 0 : n.target) !== null && a !== void 0 ? a : { kind: "Any" };
  return d("plugin:event|listen", {
    event: e,
    target: o,
    handler: Li(t)
  }).then((p) => async () => Ia(e, p));
}
async function Oi(e, t, n) {
  return ft(e, (a) => {
    Ia(e, a.id), t(a);
  }, n);
}
async function q(e, t) {
  await d("plugin:event|emit", {
    event: e,
    payload: t
  });
}
async function Pi(e, t, n) {
  await d("plugin:event|emit_to", {
    target: typeof e == "string" ? { kind: "AnyLabel", label: e } : e,
    event: t,
    payload: n
  });
}
class Oa {
  constructor(...t) {
    this.type = "Logical", t.length === 1 ? "Logical" in t[0] ? (this.width = t[0].Logical.width, this.height = t[0].Logical.height) : (this.width = t[0].width, this.height = t[0].height) : (this.width = t[0], this.height = t[1]);
  }
  /**
   * Converts the logical size to a physical one.
   * @example
   * ```typescript
   * import { LogicalSize } from '@tauri-apps/api/dpi';
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   *
   * const appWindow = getCurrentWindow();
   * const factor = await appWindow.scaleFactor();
   * const size = new LogicalSize(400, 500);
   * const physical = size.toPhysical(factor);
   * ```
   *
   * @since 2.0.0
   */
  toPhysical(t) {
    return new We(this.width * t, this.height * t);
  }
  [bt]() {
    return {
      width: this.width,
      height: this.height
    };
  }
  toJSON() {
    return this[bt]();
  }
}
class We {
  constructor(...t) {
    this.type = "Physical", t.length === 1 ? "Physical" in t[0] ? (this.width = t[0].Physical.width, this.height = t[0].Physical.height) : (this.width = t[0].width, this.height = t[0].height) : (this.width = t[0], this.height = t[1]);
  }
  /**
   * Converts the physical size to a logical one.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const appWindow = getCurrentWindow();
   * const factor = await appWindow.scaleFactor();
   * const size = await appWindow.innerSize(); // PhysicalSize
   * const logical = size.toLogical(factor);
   * ```
   */
  toLogical(t) {
    return new Oa(this.width / t, this.height / t);
  }
  [bt]() {
    return {
      width: this.width,
      height: this.height
    };
  }
  toJSON() {
    return this[bt]();
  }
}
class he {
  constructor(t) {
    this.size = t;
  }
  toLogical(t) {
    return this.size instanceof Oa ? this.size : this.size.toLogical(t);
  }
  toPhysical(t) {
    return this.size instanceof We ? this.size : this.size.toPhysical(t);
  }
  [bt]() {
    return {
      [`${this.size.type}`]: {
        width: this.size.width,
        height: this.size.height
      }
    };
  }
  toJSON() {
    return this[bt]();
  }
}
class Pa {
  constructor(...t) {
    this.type = "Logical", t.length === 1 ? "Logical" in t[0] ? (this.x = t[0].Logical.x, this.y = t[0].Logical.y) : (this.x = t[0].x, this.y = t[0].y) : (this.x = t[0], this.y = t[1]);
  }
  /**
   * Converts the logical position to a physical one.
   * @example
   * ```typescript
   * import { LogicalPosition } from '@tauri-apps/api/dpi';
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   *
   * const appWindow = getCurrentWindow();
   * const factor = await appWindow.scaleFactor();
   * const position = new LogicalPosition(400, 500);
   * const physical = position.toPhysical(factor);
   * ```
   *
   * @since 2.0.0
   */
  toPhysical(t) {
    return new Vt(this.x * t, this.y * t);
  }
  [bt]() {
    return {
      x: this.x,
      y: this.y
    };
  }
  toJSON() {
    return this[bt]();
  }
}
class Vt {
  constructor(...t) {
    this.type = "Physical", t.length === 1 ? "Physical" in t[0] ? (this.x = t[0].Physical.x, this.y = t[0].Physical.y) : (this.x = t[0].x, this.y = t[0].y) : (this.x = t[0], this.y = t[1]);
  }
  /**
   * Converts the physical position to a logical one.
   * @example
   * ```typescript
   * import { PhysicalPosition } from '@tauri-apps/api/dpi';
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   *
   * const appWindow = getCurrentWindow();
   * const factor = await appWindow.scaleFactor();
   * const position = new PhysicalPosition(400, 500);
   * const physical = position.toLogical(factor);
   * ```
   *
   * @since 2.0.0
   */
  toLogical(t) {
    return new Pa(this.x / t, this.y / t);
  }
  [bt]() {
    return {
      x: this.x,
      y: this.y
    };
  }
  toJSON() {
    return this[bt]();
  }
}
class Xe {
  constructor(t) {
    this.position = t;
  }
  toLogical(t) {
    return this.position instanceof Pa ? this.position : this.position.toLogical(t);
  }
  toPhysical(t) {
    return this.position instanceof Vt ? this.position : this.position.toPhysical(t);
  }
  [bt]() {
    return {
      [`${this.position.type}`]: {
        x: this.position.x,
        y: this.position.y
      }
    };
  }
  toJSON() {
    return this[bt]();
  }
}
class ze extends Ii {
  /**
   * Creates an Image from a resource ID. For internal use only.
   *
   * @ignore
   */
  constructor(t) {
    super(t);
  }
  /** Creates a new Image using RGBA data, in row-major order from top to bottom, and with specified width and height. */
  static async new(t, n, a) {
    return d("plugin:image|new", {
      rgba: nn(t),
      width: n,
      height: a
    }).then((o) => new ze(o));
  }
  /**
   * Creates a new image using the provided bytes by inferring the file format.
   * If the format is known, prefer [@link Image.fromPngBytes] or [@link Image.fromIcoBytes].
   *
   * Only `ico` and `png` are supported (based on activated feature flag).
   *
   * Note that you need the `image-ico` or `image-png` Cargo features to use this API.
   * To enable it, change your Cargo.toml file:
   * ```toml
   * [dependencies]
   * tauri = { version = "...", features = ["...", "image-png"] }
   * ```
   */
  static async fromBytes(t) {
    return d("plugin:image|from_bytes", {
      bytes: nn(t)
    }).then((n) => new ze(n));
  }
  /**
   * Creates a new image using the provided path.
   *
   * Only `ico` and `png` are supported (based on activated feature flag).
   *
   * Note that you need the `image-ico` or `image-png` Cargo features to use this API.
   * To enable it, change your Cargo.toml file:
   * ```toml
   * [dependencies]
   * tauri = { version = "...", features = ["...", "image-png"] }
   * ```
   */
  static async fromPath(t) {
    return d("plugin:image|from_path", { path: t }).then((n) => new ze(n));
  }
  /** Returns the RGBA data for this image, in row-major order from top to bottom.  */
  async rgba() {
    return d("plugin:image|rgba", {
      rid: this.rid
    }).then((t) => new Uint8Array(t));
  }
  /** Returns the size of this image.  */
  async size() {
    return d("plugin:image|size", { rid: this.rid });
  }
}
function nn(e) {
  return e == null ? null : typeof e == "string" ? e : e instanceof ze ? e.rid : e;
}
var On;
(function(e) {
  e[e.Critical = 1] = "Critical", e[e.Informational = 2] = "Informational";
})(On || (On = {}));
class Di {
  constructor(t) {
    this._preventDefault = !1, this.event = t.event, this.id = t.id;
  }
  preventDefault() {
    this._preventDefault = !0;
  }
  isPreventDefault() {
    return this._preventDefault;
  }
}
var ua;
(function(e) {
  e.None = "none", e.Normal = "normal", e.Indeterminate = "indeterminate", e.Paused = "paused", e.Error = "error";
})(ua || (ua = {}));
function yt() {
  return new Da(window.__TAURI_INTERNALS__.metadata.currentWindow.label, {
    // @ts-expect-error `skip` is not defined in the public API but it is handled by the constructor
    skip: !0
  });
}
async function Cn() {
  return d("plugin:window|get_all_windows").then((e) => e.map((t) => new Da(t, {
    // @ts-expect-error `skip` is not defined in the public API but it is handled by the constructor
    skip: !0
  })));
}
const $n = ["tauri://created", "tauri://error"];
class Da {
  /**
   * Creates a new Window.
   * @example
   * ```typescript
   * import { Window } from '@tauri-apps/api/window';
   * const appWindow = new Window('my-label');
   * appWindow.once('tauri://created', function () {
   *  // window successfully created
   * });
   * appWindow.once('tauri://error', function (e) {
   *  // an error happened creating the window
   * });
   * ```
   *
   * @param label The unique window label. Must be alphanumeric: `a-zA-Z-/:_`.
   * @returns The {@link Window} instance to communicate with the window.
   */
  constructor(t, n = {}) {
    var a;
    this.label = t, this.listeners = /* @__PURE__ */ Object.create(null), n != null && n.skip || d("plugin:window|create", {
      options: {
        ...n,
        parent: typeof n.parent == "string" ? n.parent : (a = n.parent) === null || a === void 0 ? void 0 : a.label,
        label: t
      }
    }).then(async () => this.emit("tauri://created")).catch(async (o) => this.emit("tauri://error", o));
  }
  /**
   * Gets the Window associated with the given label.
   * @example
   * ```typescript
   * import { Window } from '@tauri-apps/api/window';
   * const mainWindow = Window.getByLabel('main');
   * ```
   *
   * @param label The window label.
   * @returns The Window instance to communicate with the window or null if the window doesn't exist.
   */
  static async getByLabel(t) {
    var n;
    return (n = (await Cn()).find((a) => a.label === t)) !== null && n !== void 0 ? n : null;
  }
  /**
   * Get an instance of `Window` for the current window.
   */
  static getCurrent() {
    return yt();
  }
  /**
   * Gets a list of instances of `Window` for all available windows.
   */
  static async getAll() {
    return Cn();
  }
  /**
   *  Gets the focused window.
   * @example
   * ```typescript
   * import { Window } from '@tauri-apps/api/window';
   * const focusedWindow = Window.getFocusedWindow();
   * ```
   *
   * @returns The Window instance or `undefined` if there is not any focused window.
   */
  static async getFocusedWindow() {
    for (const t of await Cn())
      if (await t.isFocused())
        return t;
    return null;
  }
  /**
   * Listen to an emitted event on this window.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const unlisten = await getCurrentWindow().listen<string>('state-changed', (event) => {
   *   console.log(`Got error: ${payload}`);
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @param event Event name. Must include only alphanumeric characters, `-`, `/`, `:` and `_`.
   * @param handler Event handler.
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async listen(t, n) {
    return this._handleTauriEvent(t, n) ? () => {
      const a = this.listeners[t];
      a.splice(a.indexOf(n), 1);
    } : ft(t, n, {
      target: { kind: "Window", label: this.label }
    });
  }
  /**
   * Listen to an emitted event on this window only once.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const unlisten = await getCurrentWindow().once<null>('initialized', (event) => {
   *   console.log(`Window initialized!`);
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @param event Event name. Must include only alphanumeric characters, `-`, `/`, `:` and `_`.
   * @param handler Event handler.
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async once(t, n) {
    return this._handleTauriEvent(t, n) ? () => {
      const a = this.listeners[t];
      a.splice(a.indexOf(n), 1);
    } : Oi(t, n, {
      target: { kind: "Window", label: this.label }
    });
  }
  /**
   * Emits an event to all {@link EventTarget|targets}.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().emit('window-loaded', { loggedIn: true, token: 'authToken' });
   * ```
   *
   * @param event Event name. Must include only alphanumeric characters, `-`, `/`, `:` and `_`.
   * @param payload Event payload.
   */
  async emit(t, n) {
    if ($n.includes(t)) {
      for (const a of this.listeners[t] || [])
        a({
          event: t,
          id: -1,
          payload: n
        });
      return;
    }
    return q(t, n);
  }
  /**
   * Emits an event to all {@link EventTarget|targets} matching the given target.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().emit('main', 'window-loaded', { loggedIn: true, token: 'authToken' });
   * ```
   * @param target Label of the target Window/Webview/WebviewWindow or raw {@link EventTarget} object.
   * @param event Event name. Must include only alphanumeric characters, `-`, `/`, `:` and `_`.
   * @param payload Event payload.
   */
  async emitTo(t, n, a) {
    if ($n.includes(n)) {
      for (const o of this.listeners[n] || [])
        o({
          event: n,
          id: -1,
          payload: a
        });
      return;
    }
    return Pi(t, n, a);
  }
  /** @ignore */
  _handleTauriEvent(t, n) {
    return $n.includes(t) ? (t in this.listeners ? this.listeners[t].push(n) : this.listeners[t] = [n], !0) : !1;
  }
  // Getters
  /**
   * The scale factor that can be used to map physical pixels to logical pixels.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const factor = await getCurrentWindow().scaleFactor();
   * ```
   *
   * @returns The window's monitor scale factor.
   */
  async scaleFactor() {
    return d("plugin:window|scale_factor", {
      label: this.label
    });
  }
  /**
   * The position of the top-left hand corner of the window's client area relative to the top-left hand corner of the desktop.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const position = await getCurrentWindow().innerPosition();
   * ```
   *
   * @returns The window's inner position.
   */
  async innerPosition() {
    return d("plugin:window|inner_position", {
      label: this.label
    }).then((t) => new Vt(t));
  }
  /**
   * The position of the top-left hand corner of the window relative to the top-left hand corner of the desktop.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const position = await getCurrentWindow().outerPosition();
   * ```
   *
   * @returns The window's outer position.
   */
  async outerPosition() {
    return d("plugin:window|outer_position", {
      label: this.label
    }).then((t) => new Vt(t));
  }
  /**
   * The physical size of the window's client area.
   * The client area is the content of the window, excluding the title bar and borders.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const size = await getCurrentWindow().innerSize();
   * ```
   *
   * @returns The window's inner size.
   */
  async innerSize() {
    return d("plugin:window|inner_size", {
      label: this.label
    }).then((t) => new We(t));
  }
  /**
   * The physical size of the entire window.
   * These dimensions include the title bar and borders. If you don't want that (and you usually don't), use inner_size instead.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const size = await getCurrentWindow().outerSize();
   * ```
   *
   * @returns The window's outer size.
   */
  async outerSize() {
    return d("plugin:window|outer_size", {
      label: this.label
    }).then((t) => new We(t));
  }
  /**
   * Gets the window's current fullscreen state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const fullscreen = await getCurrentWindow().isFullscreen();
   * ```
   *
   * @returns Whether the window is in fullscreen mode or not.
   */
  async isFullscreen() {
    return d("plugin:window|is_fullscreen", {
      label: this.label
    });
  }
  /**
   * Gets the window's current minimized state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const minimized = await getCurrentWindow().isMinimized();
   * ```
   */
  async isMinimized() {
    return d("plugin:window|is_minimized", {
      label: this.label
    });
  }
  /**
   * Gets the window's current maximized state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const maximized = await getCurrentWindow().isMaximized();
   * ```
   *
   * @returns Whether the window is maximized or not.
   */
  async isMaximized() {
    return d("plugin:window|is_maximized", {
      label: this.label
    });
  }
  /**
   * Gets the window's current focus state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const focused = await getCurrentWindow().isFocused();
   * ```
   *
   * @returns Whether the window is focused or not.
   */
  async isFocused() {
    return d("plugin:window|is_focused", {
      label: this.label
    });
  }
  /**
   * Gets the window's current decorated state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const decorated = await getCurrentWindow().isDecorated();
   * ```
   *
   * @returns Whether the window is decorated or not.
   */
  async isDecorated() {
    return d("plugin:window|is_decorated", {
      label: this.label
    });
  }
  /**
   * Gets the window's current resizable state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const resizable = await getCurrentWindow().isResizable();
   * ```
   *
   * @returns Whether the window is resizable or not.
   */
  async isResizable() {
    return d("plugin:window|is_resizable", {
      label: this.label
    });
  }
  /**
   * Gets the window's native maximize button state.
   *
   * #### Platform-specific
   *
   * - **Linux / iOS / Android:** Unsupported.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const maximizable = await getCurrentWindow().isMaximizable();
   * ```
   *
   * @returns Whether the window's native maximize button is enabled or not.
   */
  async isMaximizable() {
    return d("plugin:window|is_maximizable", {
      label: this.label
    });
  }
  /**
   * Gets the window's native minimize button state.
   *
   * #### Platform-specific
   *
   * - **Linux / iOS / Android:** Unsupported.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const minimizable = await getCurrentWindow().isMinimizable();
   * ```
   *
   * @returns Whether the window's native minimize button is enabled or not.
   */
  async isMinimizable() {
    return d("plugin:window|is_minimizable", {
      label: this.label
    });
  }
  /**
   * Gets the window's native close button state.
   *
   * #### Platform-specific
   *
   * - **iOS / Android:** Unsupported.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const closable = await getCurrentWindow().isClosable();
   * ```
   *
   * @returns Whether the window's native close button is enabled or not.
   */
  async isClosable() {
    return d("plugin:window|is_closable", {
      label: this.label
    });
  }
  /**
   * Gets the window's current visible state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const visible = await getCurrentWindow().isVisible();
   * ```
   *
   * @returns Whether the window is visible or not.
   */
  async isVisible() {
    return d("plugin:window|is_visible", {
      label: this.label
    });
  }
  /**
   * Gets the window's current title.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const title = await getCurrentWindow().title();
   * ```
   */
  async title() {
    return d("plugin:window|title", {
      label: this.label
    });
  }
  /**
   * Gets the window's current theme.
   *
   * #### Platform-specific
   *
   * - **macOS:** Theme was introduced on macOS 10.14. Returns `light` on macOS 10.13 and below.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const theme = await getCurrentWindow().theme();
   * ```
   *
   * @returns The window theme.
   */
  async theme() {
    return d("plugin:window|theme", {
      label: this.label
    });
  }
  /**
   * Whether the window is configured to be always on top of other windows or not.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const alwaysOnTop = await getCurrentWindow().isAlwaysOnTop();
   * ```
   *
   * @returns Whether the window is visible or not.
   */
  async isAlwaysOnTop() {
    return d("plugin:window|is_always_on_top", {
      label: this.label
    });
  }
  async activityName() {
    return d("plugin:window|activity_name", {
      label: this.label
    });
  }
  async sceneIdentifier() {
    return d("plugin:window|scene_identifier", {
      label: this.label
    });
  }
  // Setters
  /**
   * Centers the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().center();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async center() {
    return d("plugin:window|center", {
      label: this.label
    });
  }
  /**
   *  Requests user attention to the window, this has no effect if the application
   * is already focused. How requesting for user attention manifests is platform dependent,
   * see `UserAttentionType` for details.
   *
   * Providing `null` will unset the request for user attention. Unsetting the request for
   * user attention might not be done automatically by the WM when the window receives input.
   *
   * #### Platform-specific
   *
   * - **macOS:** `null` has no effect.
   * - **Linux:** Urgency levels have the same effect.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().requestUserAttention();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async requestUserAttention(t) {
    let n = null;
    return t && (t === On.Critical ? n = { type: "Critical" } : n = { type: "Informational" }), d("plugin:window|request_user_attention", {
      label: this.label,
      value: n
    });
  }
  /**
   * Updates the window resizable flag.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setResizable(false);
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async setResizable(t) {
    return d("plugin:window|set_resizable", {
      label: this.label,
      value: t
    });
  }
  /**
   * Enable or disable the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setEnabled(false);
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   *
   * @since 2.0.0
   */
  async setEnabled(t) {
    return d("plugin:window|set_enabled", {
      label: this.label,
      value: t
    });
  }
  /**
   * Whether the window is enabled or disabled.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setEnabled(false);
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   *
   * @since 2.0.0
   */
  async isEnabled() {
    return d("plugin:window|is_enabled", {
      label: this.label
    });
  }
  /**
   * Sets whether the window's native maximize button is enabled or not.
   * If resizable is set to false, this setting is ignored.
   *
   * #### Platform-specific
   *
   * - **macOS:** Disables the "zoom" button in the window titlebar, which is also used to enter fullscreen mode.
   * - **Linux / iOS / Android:** Unsupported.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setMaximizable(false);
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async setMaximizable(t) {
    return d("plugin:window|set_maximizable", {
      label: this.label,
      value: t
    });
  }
  /**
   * Sets whether the window's native minimize button is enabled or not.
   *
   * #### Platform-specific
   *
   * - **Linux / iOS / Android:** Unsupported.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setMinimizable(false);
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async setMinimizable(t) {
    return d("plugin:window|set_minimizable", {
      label: this.label,
      value: t
    });
  }
  /**
   * Sets whether the window's native close button is enabled or not.
   *
   * #### Platform-specific
   *
   * - **Linux:** GTK+ will do its best to convince the window manager not to show a close button. Depending on the system, this function may not have any effect when called on a window that is already visible
   * - **iOS / Android:** Unsupported.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setClosable(false);
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async setClosable(t) {
    return d("plugin:window|set_closable", {
      label: this.label,
      value: t
    });
  }
  /**
   * Sets the window title.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setTitle('Tauri');
   * ```
   *
   * @param title The new title
   * @returns A promise indicating the success or failure of the operation.
   */
  async setTitle(t) {
    return d("plugin:window|set_title", {
      label: this.label,
      value: t
    });
  }
  /**
   * Maximizes the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().maximize();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async maximize() {
    return d("plugin:window|maximize", {
      label: this.label
    });
  }
  /**
   * Unmaximizes the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().unmaximize();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async unmaximize() {
    return d("plugin:window|unmaximize", {
      label: this.label
    });
  }
  /**
   * Toggles the window maximized state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().toggleMaximize();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async toggleMaximize() {
    return d("plugin:window|toggle_maximize", {
      label: this.label
    });
  }
  /**
   * Minimizes the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().minimize();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async minimize() {
    return d("plugin:window|minimize", {
      label: this.label
    });
  }
  /**
   * Unminimizes the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().unminimize();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async unminimize() {
    return d("plugin:window|unminimize", {
      label: this.label
    });
  }
  /**
   * Sets the window visibility to true.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().show();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async show() {
    return d("plugin:window|show", {
      label: this.label
    });
  }
  /**
   * Sets the window visibility to false.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().hide();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async hide() {
    return d("plugin:window|hide", {
      label: this.label
    });
  }
  /**
   * Closes the window.
   *
   * Note this emits a closeRequested event so you can intercept it. To force window close, use {@link Window.destroy}.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().close();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async close() {
    return d("plugin:window|close", {
      label: this.label
    });
  }
  /**
   * Destroys the window. Behaves like {@link Window.close} but forces the window close instead of emitting a closeRequested event.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().destroy();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async destroy() {
    return d("plugin:window|destroy", {
      label: this.label
    });
  }
  /**
   * Whether the window should have borders and bars.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setDecorations(false);
   * ```
   *
   * @param decorations Whether the window should have borders and bars.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setDecorations(t) {
    return d("plugin:window|set_decorations", {
      label: this.label,
      value: t
    });
  }
  /**
   * Whether or not the window should have shadow.
   *
   * #### Platform-specific
   *
   * - **Windows:**
   *   - `false` has no effect on decorated window, shadows are always ON.
   *   - `true` will make undecorated window have a 1px white border,
   * and on Windows 11, it will have a rounded corners.
   * - **Linux:** Unsupported.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setShadow(false);
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async setShadow(t) {
    return d("plugin:window|set_shadow", {
      label: this.label,
      value: t
    });
  }
  /**
   * Set window effects.
   */
  async setEffects(t) {
    return d("plugin:window|set_effects", {
      label: this.label,
      value: t
    });
  }
  /**
   * Clear any applied effects if possible.
   */
  async clearEffects() {
    return d("plugin:window|set_effects", {
      label: this.label,
      value: null
    });
  }
  /**
   * Whether the window should always be on top of other windows.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setAlwaysOnTop(true);
   * ```
   *
   * @param alwaysOnTop Whether the window should always be on top of other windows or not.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setAlwaysOnTop(t) {
    return d("plugin:window|set_always_on_top", {
      label: this.label,
      value: t
    });
  }
  /**
   * Whether the window should always be below other windows.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setAlwaysOnBottom(true);
   * ```
   *
   * @param alwaysOnBottom Whether the window should always be below other windows or not.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setAlwaysOnBottom(t) {
    return d("plugin:window|set_always_on_bottom", {
      label: this.label,
      value: t
    });
  }
  /**
   * Prevents the window contents from being captured by other apps.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setContentProtected(true);
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async setContentProtected(t) {
    return d("plugin:window|set_content_protected", {
      label: this.label,
      value: t
    });
  }
  /**
   * Resizes the window with a new inner size.
   * @example
   * ```typescript
   * import { getCurrentWindow, LogicalSize } from '@tauri-apps/api/window';
   * await getCurrentWindow().setSize(new LogicalSize(600, 500));
   * ```
   *
   * @param size The logical or physical inner size.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setSize(t) {
    return d("plugin:window|set_size", {
      label: this.label,
      value: t instanceof he ? t : new he(t)
    });
  }
  /**
   * Sets the window minimum inner size. If the `size` argument is not provided, the constraint is unset.
   * @example
   * ```typescript
   * import { getCurrentWindow, PhysicalSize } from '@tauri-apps/api/window';
   * await getCurrentWindow().setMinSize(new PhysicalSize(600, 500));
   * ```
   *
   * @param size The logical or physical inner size, or `null` to unset the constraint.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setMinSize(t) {
    return d("plugin:window|set_min_size", {
      label: this.label,
      value: t instanceof he ? t : t ? new he(t) : null
    });
  }
  /**
   * Sets the window maximum inner size. If the `size` argument is undefined, the constraint is unset.
   * @example
   * ```typescript
   * import { getCurrentWindow, LogicalSize } from '@tauri-apps/api/window';
   * await getCurrentWindow().setMaxSize(new LogicalSize(600, 500));
   * ```
   *
   * @param size The logical or physical inner size, or `null` to unset the constraint.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setMaxSize(t) {
    return d("plugin:window|set_max_size", {
      label: this.label,
      value: t instanceof he ? t : t ? new he(t) : null
    });
  }
  /**
   * Sets the window inner size constraints.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setSizeConstraints({ minWidth: 300 });
   * ```
   *
   * @param constraints The logical or physical inner size, or `null` to unset the constraint.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setSizeConstraints(t) {
    function n(a) {
      return a ? { Logical: a } : null;
    }
    return d("plugin:window|set_size_constraints", {
      label: this.label,
      value: {
        minWidth: n(t == null ? void 0 : t.minWidth),
        minHeight: n(t == null ? void 0 : t.minHeight),
        maxWidth: n(t == null ? void 0 : t.maxWidth),
        maxHeight: n(t == null ? void 0 : t.maxHeight)
      }
    });
  }
  /**
   * Sets the window outer position.
   * @example
   * ```typescript
   * import { getCurrentWindow, LogicalPosition } from '@tauri-apps/api/window';
   * await getCurrentWindow().setPosition(new LogicalPosition(600, 500));
   * ```
   *
   * @param position The new position, in logical or physical pixels.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setPosition(t) {
    return d("plugin:window|set_position", {
      label: this.label,
      value: t instanceof Xe ? t : new Xe(t)
    });
  }
  /**
   * Sets the window fullscreen state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setFullscreen(true);
   * ```
   *
   * @param fullscreen Whether the window should go to fullscreen or not.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setFullscreen(t) {
    return d("plugin:window|set_fullscreen", {
      label: this.label,
      value: t
    });
  }
  /**
   * On macOS, Toggles a fullscreen mode that doesn’t require a new macOS space. Returns a boolean indicating whether the transition was successful (this won’t work if the window was already in the native fullscreen).
   * This is how fullscreen used to work on macOS in versions before Lion. And allows the user to have a fullscreen window without using another space or taking control over the entire monitor.
   *
   * On other platforms, this is the same as {@link Window.setFullscreen}.
   *
   * @param fullscreen Whether the window should go to simple fullscreen or not.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setSimpleFullscreen(t) {
    return d("plugin:window|set_simple_fullscreen", {
      label: this.label,
      value: t
    });
  }
  /**
   * Bring the window to front and focus.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setFocus();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async setFocus() {
    return d("plugin:window|set_focus", {
      label: this.label
    });
  }
  /**
   * Sets whether the window can be focused.
   *
   * #### Platform-specific
   *
   * - **macOS**: If the window is already focused, it is not possible to unfocus it after calling `set_focusable(false)`.
   *   In this case, you might consider calling {@link Window.setFocus} but it will move the window to the back i.e. at the bottom in terms of z-order.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setFocusable(true);
   * ```
   *
   * @param focusable Whether the window can be focused.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setFocusable(t) {
    return d("plugin:window|set_focusable", {
      label: this.label,
      value: t
    });
  }
  /**
   * Sets the window icon.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setIcon('/tauri/awesome.png');
   * ```
   *
   * Note that you may need the `image-ico` or `image-png` Cargo features to use this API.
   * To enable it, change your Cargo.toml file:
   * ```toml
   * [dependencies]
   * tauri = { version = "...", features = ["...", "image-png"] }
   * ```
   *
   * @param icon Icon bytes or path to the icon file.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setIcon(t) {
    return d("plugin:window|set_icon", {
      label: this.label,
      value: nn(t)
    });
  }
  /**
   * Whether the window icon should be hidden from the taskbar or not.
   *
   * #### Platform-specific
   *
   * - **macOS:** Unsupported.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setSkipTaskbar(true);
   * ```
   *
   * @param skip true to hide window icon, false to show it.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setSkipTaskbar(t) {
    return d("plugin:window|set_skip_taskbar", {
      label: this.label,
      value: t
    });
  }
  /**
   * Grabs the cursor, preventing it from leaving the window.
   *
   * There's no guarantee that the cursor will be hidden. You should
   * hide it by yourself if you want so.
   *
   * #### Platform-specific
   *
   * - **Linux:** Unsupported.
   * - **macOS:** This locks the cursor in a fixed location, which looks visually awkward.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setCursorGrab(true);
   * ```
   *
   * @param grab `true` to grab the cursor icon, `false` to release it.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setCursorGrab(t) {
    return d("plugin:window|set_cursor_grab", {
      label: this.label,
      value: t
    });
  }
  /**
   * Modifies the cursor's visibility.
   *
   * #### Platform-specific
   *
   * - **Windows:** The cursor is only hidden within the confines of the window.
   * - **macOS:** The cursor is hidden as long as the window has input focus, even if the cursor is
   *   outside of the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setCursorVisible(false);
   * ```
   *
   * @param visible If `false`, this will hide the cursor. If `true`, this will show the cursor.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setCursorVisible(t) {
    return d("plugin:window|set_cursor_visible", {
      label: this.label,
      value: t
    });
  }
  /**
   * Modifies the cursor icon of the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setCursorIcon('help');
   * ```
   *
   * @param icon The new cursor icon.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setCursorIcon(t) {
    return d("plugin:window|set_cursor_icon", {
      label: this.label,
      value: t
    });
  }
  /**
   * Sets the window background color.
   *
   * #### Platform-specific:
   *
   * - **Windows:** alpha channel is ignored.
   * - **iOS / Android:** Unsupported.
   *
   * @returns A promise indicating the success or failure of the operation.
   *
   * @since 2.1.0
   */
  async setBackgroundColor(t) {
    return d("plugin:window|set_background_color", { color: t });
  }
  /**
   * Changes the position of the cursor in window coordinates.
   * @example
   * ```typescript
   * import { getCurrentWindow, LogicalPosition } from '@tauri-apps/api/window';
   * await getCurrentWindow().setCursorPosition(new LogicalPosition(600, 300));
   * ```
   *
   * @param position The new cursor position.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setCursorPosition(t) {
    return d("plugin:window|set_cursor_position", {
      label: this.label,
      value: t instanceof Xe ? t : new Xe(t)
    });
  }
  /**
   * Changes the cursor events behavior.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setIgnoreCursorEvents(true);
   * ```
   *
   * @param ignore `true` to ignore the cursor events; `false` to process them as usual.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setIgnoreCursorEvents(t) {
    return d("plugin:window|set_ignore_cursor_events", {
      label: this.label,
      value: t
    });
  }
  /**
   * Starts dragging the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().startDragging();
   * ```
   *
   * @return A promise indicating the success or failure of the operation.
   */
  async startDragging() {
    return d("plugin:window|start_dragging", {
      label: this.label
    });
  }
  /**
   * Starts resize-dragging the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().startResizeDragging();
   * ```
   *
   * @return A promise indicating the success or failure of the operation.
   */
  async startResizeDragging(t) {
    return d("plugin:window|start_resize_dragging", {
      label: this.label,
      value: t
    });
  }
  /**
   * Sets the badge count. It is app wide and not specific to this window.
   *
   * #### Platform-specific
   *
   * - **Windows**: Unsupported. Use @{linkcode Window.setOverlayIcon} instead.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setBadgeCount(5);
   * ```
   *
   * @param count The badge count. Use `undefined` to remove the badge.
   * @return A promise indicating the success or failure of the operation.
   */
  async setBadgeCount(t) {
    return d("plugin:window|set_badge_count", {
      label: this.label,
      value: t
    });
  }
  /**
   * Sets the badge cont **macOS only**.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setBadgeLabel("Hello");
   * ```
   *
   * @param label The badge label. Use `undefined` to remove the badge.
   * @return A promise indicating the success or failure of the operation.
   */
  async setBadgeLabel(t) {
    return d("plugin:window|set_badge_label", {
      label: this.label,
      value: t
    });
  }
  /**
   * Sets the overlay icon. **Windows only**
   * The overlay icon can be set for every window.
   *
   *
   * Note that you may need the `image-ico` or `image-png` Cargo features to use this API.
   * To enable it, change your Cargo.toml file:
   *
   * ```toml
   * [dependencies]
   * tauri = { version = "...", features = ["...", "image-png"] }
   * ```
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setOverlayIcon("/tauri/awesome.png");
   * ```
   *
   * @param icon Icon bytes or path to the icon file. Use `undefined` to remove the overlay icon.
   * @return A promise indicating the success or failure of the operation.
   */
  async setOverlayIcon(t) {
    return d("plugin:window|set_overlay_icon", {
      label: this.label,
      value: t ? nn(t) : void 0
    });
  }
  /**
   * Sets the taskbar progress state.
   *
   * #### Platform-specific
   *
   * - **Linux / macOS**: Progress bar is app-wide and not specific to this window.
   * - **Linux**: Only supported desktop environments with `libunity` (e.g. GNOME).
   *
   * @example
   * ```typescript
   * import { getCurrentWindow, ProgressBarStatus } from '@tauri-apps/api/window';
   * await getCurrentWindow().setProgressBar({
   *   status: ProgressBarStatus.Normal,
   *   progress: 50,
   * });
   * ```
   *
   * @return A promise indicating the success or failure of the operation.
   */
  async setProgressBar(t) {
    return d("plugin:window|set_progress_bar", {
      label: this.label,
      value: t
    });
  }
  /**
   * Sets whether the window should be visible on all workspaces or virtual desktops.
   *
   * #### Platform-specific
   *
   * - **Windows / iOS / Android:** Unsupported.
   *
   * @since 2.0.0
   */
  async setVisibleOnAllWorkspaces(t) {
    return d("plugin:window|set_visible_on_all_workspaces", {
      label: this.label,
      value: t
    });
  }
  /**
   * Sets the title bar style. **macOS only**.
   *
   * @since 2.0.0
   */
  async setTitleBarStyle(t) {
    return d("plugin:window|set_title_bar_style", {
      label: this.label,
      value: t
    });
  }
  /**
   * Set window theme, pass in `null` or `undefined` to follow system theme
   *
   * #### Platform-specific
   *
   * - **Linux / macOS**: Theme is app-wide and not specific to this window.
   * - **iOS / Android:** Unsupported.
   *
   * @since 2.0.0
   */
  async setTheme(t) {
    return d("plugin:window|set_theme", {
      label: this.label,
      value: t
    });
  }
  // Listeners
  /**
   * Listen to window resize.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from "@tauri-apps/api/window";
   * const unlisten = await getCurrentWindow().onResized(({ payload: size }) => {
   *  console.log('Window resized', size);
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async onResized(t) {
    return this.listen(dt.WINDOW_RESIZED, (n) => {
      n.payload = new We(n.payload), t(n);
    });
  }
  /**
   * Listen to window move.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from "@tauri-apps/api/window";
   * const unlisten = await getCurrentWindow().onMoved(({ payload: position }) => {
   *  console.log('Window moved', position);
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async onMoved(t) {
    return this.listen(dt.WINDOW_MOVED, (n) => {
      n.payload = new Vt(n.payload), t(n);
    });
  }
  /**
   * Listen to window close requested. Emitted when the user requests to closes the window.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from "@tauri-apps/api/window";
   * import { confirm } from '@tauri-apps/api/dialog';
   * const unlisten = await getCurrentWindow().onCloseRequested(async (event) => {
   *   const confirmed = await confirm('Are you sure?');
   *   if (!confirmed) {
   *     // user did not confirm closing the window; let's prevent it
   *     event.preventDefault();
   *   }
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async onCloseRequested(t) {
    return this.listen(dt.WINDOW_CLOSE_REQUESTED, async (n) => {
      const a = new Di(n);
      await t(a), a.isPreventDefault() || await this.destroy();
    });
  }
  /**
   * Listen to a file drop event.
   * The listener is triggered when the user hovers the selected files on the webview,
   * drops the files or cancels the operation.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from "@tauri-apps/api/webview";
   * const unlisten = await getCurrentWindow().onDragDropEvent((event) => {
   *  if (event.payload.type === 'over') {
   *    console.log('User hovering', event.payload.position);
   *  } else if (event.payload.type === 'drop') {
   *    console.log('User dropped', event.payload.paths);
   *  } else {
   *    console.log('File drop cancelled');
   *  }
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async onDragDropEvent(t) {
    const n = await this.listen(dt.DRAG_ENTER, (b) => {
      t({
        ...b,
        payload: {
          type: "enter",
          paths: b.payload.paths,
          position: new Vt(b.payload.position)
        }
      });
    }), a = await this.listen(dt.DRAG_OVER, (b) => {
      t({
        ...b,
        payload: {
          type: "over",
          position: new Vt(b.payload.position)
        }
      });
    }), o = await this.listen(dt.DRAG_DROP, (b) => {
      t({
        ...b,
        payload: {
          type: "drop",
          paths: b.payload.paths,
          position: new Vt(b.payload.position)
        }
      });
    }), p = await this.listen(dt.DRAG_LEAVE, (b) => {
      t({ ...b, payload: { type: "leave" } });
    });
    return () => {
      n(), o(), a(), p();
    };
  }
  /**
   * Listen to window focus change.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from "@tauri-apps/api/window";
   * const unlisten = await getCurrentWindow().onFocusChanged(({ payload: focused }) => {
   *  console.log('Focus changed, window is focused? ' + focused);
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async onFocusChanged(t) {
    const n = await this.listen(dt.WINDOW_FOCUS, (o) => {
      t({ ...o, payload: !0 });
    }), a = await this.listen(dt.WINDOW_BLUR, (o) => {
      t({ ...o, payload: !1 });
    });
    return () => {
      n(), a();
    };
  }
  /**
   * Listen to window scale change. Emitted when the window's scale factor has changed.
   * The following user actions can cause DPI changes:
   * - Changing the display's resolution.
   * - Changing the display's scale factor (e.g. in Control Panel on Windows).
   * - Moving the window to a display with a different scale factor.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from "@tauri-apps/api/window";
   * const unlisten = await getCurrentWindow().onScaleChanged(({ payload }) => {
   *  console.log('Scale changed', payload.scaleFactor, payload.size);
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async onScaleChanged(t) {
    return this.listen(dt.WINDOW_SCALE_FACTOR_CHANGED, t);
  }
  /**
   * Listen to the system theme change.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from "@tauri-apps/api/window";
   * const unlisten = await getCurrentWindow().onThemeChanged(({ payload: theme }) => {
   *  console.log('New theme: ' + theme);
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async onThemeChanged(t) {
    return this.listen(dt.WINDOW_THEME_CHANGED, t);
  }
}
var da;
(function(e) {
  e.Disabled = "disabled", e.Throttle = "throttle", e.Suspend = "suspend";
})(da || (da = {}));
var fa;
(function(e) {
  e.Default = "default", e.FluentOverlay = "fluentOverlay";
})(fa || (fa = {}));
var ha;
(function(e) {
  e.AppearanceBased = "appearanceBased", e.Light = "light", e.Dark = "dark", e.MediumLight = "mediumLight", e.UltraDark = "ultraDark", e.Titlebar = "titlebar", e.Selection = "selection", e.Menu = "menu", e.Popover = "popover", e.Sidebar = "sidebar", e.HeaderView = "headerView", e.Sheet = "sheet", e.WindowBackground = "windowBackground", e.HudWindow = "hudWindow", e.FullScreenUI = "fullScreenUI", e.Tooltip = "tooltip", e.ContentBackground = "contentBackground", e.UnderWindowBackground = "underWindowBackground", e.UnderPageBackground = "underPageBackground", e.Mica = "mica", e.Blur = "blur", e.Acrylic = "acrylic", e.Tabbed = "tabbed", e.TabbedDark = "tabbedDark", e.TabbedLight = "tabbedLight";
})(ha || (ha = {}));
var ma;
(function(e) {
  e.FollowsWindowActiveState = "followsWindowActiveState", e.Active = "active", e.Inactive = "inactive";
})(ma || (ma = {}));
async function Pn(e = {}) {
  return typeof e == "object" && Object.freeze(e), await d("plugin:dialog|open", { options: e });
}
const Fi = "__lunac_host";
function Ri() {
  return globalThis[Fi] ?? null;
}
function h(e, t) {
  const n = Ri();
  return n && typeof n.t == "function" ? n.t(e, t) : e;
}
const Wi = "pet", zi = "engine/live2dcubismcore.min.js", Hi = "engine/live2d-engine.js";
function oe(e, t) {
  const n = e.includes("\\") ? "\\" : "/", a = e.replace(/[\\/]+$/, "").split(/[\\/]+/);
  for (const o of t.split(/[\\/]+/))
    if (!(!o || o === ".")) {
      if (o === "..") {
        a.length > 1 && a.pop();
        continue;
      }
      a.push(o);
    }
  return a.join(n);
}
function dn(e) {
  const t = Math.max(e.lastIndexOf("\\"), e.lastIndexOf("/"));
  return t > 0 ? e.slice(0, t) : e;
}
function ji(e) {
  var n;
  const t = Number((e == null ? void 0 : e.Version) ?? 0);
  if (!((n = e == null ? void 0 : e.FileReferences) != null && n.Moc) || !(t >= 3))
    throw new Error("这不是 Cubism 4 的模型定义（缺 `FileReferences.Moc` 或 `Version < 3`）—— 请选 `*.model3.json`");
}
async function fn(e) {
  let t;
  try {
    t = await fetch(Xt(e));
  } catch (n) {
    throw new Error(`读不到模型文件（asset 协议拒绝或文件已移动）：${n instanceof Error ? n.message : String(n)}`);
  }
  if (!t.ok) throw new Error(`读模型定义失败（HTTP ${t.status}）`);
  try {
    return await t.json();
  } catch {
    throw new Error("模型定义不是合法 JSON");
  }
}
function ga(e) {
  return (e.split(/[\\/]/).pop() || "").replace(/\.[^.]+$/, "");
}
function En(e) {
  return e.replace(/[\\/]+/g, "/").toLowerCase();
}
async function Fa(e, t) {
  var _;
  const n = t ?? await fn(e), a = dn(e), o = ((_ = n.FileReferences) == null ? void 0 : _.Expressions) ?? [], p = [], b = /* @__PURE__ */ new Set();
  for (const x of o) {
    const L = x.File ? oe(a, x.File) : "", E = (x.Name || (x.File ? ga(x.File) : "")).trim();
    E && (L && b.add(En(L)), p.push({ id: E, name: E, file: L, declared: !0 }));
  }
  let v = [];
  try {
    v = await d("list_expression_files", {
      model_path: e
    }) ?? [];
  } catch {
    v = [];
  }
  for (const x of v) {
    const L = typeof (x == null ? void 0 : x.path) == "string" ? x.path : "";
    if (!L || b.has(En(L))) continue;
    const E = (typeof (x == null ? void 0 : x.name) == "string" && x.name.trim() || ga(L)).trim();
    E && (b.add(En(L)), p.push({ id: E, name: E, file: L, declared: !1 }));
  }
  return p;
}
async function Ra(e) {
  var t;
  try {
    const n = await fn(e);
    ji(n);
    const a = n.FileReferences ?? {}, o = Object.keys(a.Motions ?? {});
    return {
      ok: !0,
      info: `Cubism ${Number(n.Version)} · 纹理 ${((t = a.Textures) == null ? void 0 : t.length) ?? 0} · 动作组 ${o.length ? o.join(" / ") : "无"}`
    };
  } catch (n) {
    return { ok: !1, reason: n instanceof Error ? n.message : String(n) };
  }
}
async function Wa() {
  const e = await d("plugins_dir_path");
  return oe(e, Wi);
}
async function Bi() {
  return oe(await Wa(), zi);
}
async function Vi() {
  return oe(await Wa(), Hi);
}
function za() {
  return !!globalThis.Live2DCubismCore;
}
let Ye = null;
function Ui() {
  return za() ? Promise.resolve() : (Ye || (Ye = Gi().catch((e) => {
    throw Ye = null, e instanceof Error ? e : new Error(String(e));
  })), Ye);
}
async function Gi() {
  if (await qi(Xt(await Bi())), !za()) throw new Error("Cubism Core 已注入但全局对象仍不可见（文件可能不完整）");
}
function qi(e) {
  return new Promise((t, n) => {
    const a = document.createElement("script");
    a.src = e, a.async = !1, a.onload = () => t(), a.onerror = () => n(new Error(`引擎文件加载失败（asset 协议拒绝或文件缺失）：${e}`)), document.head.appendChild(a);
  });
}
const Ha = 0.4, ja = 8, Dn = "Lunac", Xi = [
  "motion",
  "chain",
  "expression",
  "param",
  "artmesh",
  "artmeshColor",
  "part",
  "physics"
];
function Yi(e) {
  return e.split(/[\\/]/).pop() || "";
}
function Ki() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
}
function Fn(e = "新热键", t = "", n) {
  return {
    id: Ki(),
    name: e,
    keys: t,
    action: n ?? { type: "expression", target: "", mode: "set" }
  };
}
function Ji(e) {
  const t = [
    "Numpad1",
    "Numpad2",
    "Numpad3",
    "Numpad4",
    "Numpad5",
    "Numpad6",
    "Numpad7",
    "Numpad8",
    "Numpad9"
  ], n = ["Ctrl", "Shift", "Alt", "Ctrl+Shift", "Ctrl+Alt", "Shift+Alt", "Ctrl+Shift+Alt"], a = Math.max(0, Math.floor(e)), o = t[a % t.length], p = Math.floor(a / t.length);
  return p < n.length ? `${n[p]}+${o}` : o;
}
async function ge(e) {
  let t = null;
  try {
    t = await d("read_pet_hotkeys", { modelPath: e });
  } catch {
    return [];
  }
  if (!t) return [];
  try {
    const n = JSON.parse(t);
    return (Array.isArray(n.hotkeys) ? n.hotkeys : []).filter(
      (o) => !!o && typeof o == "object" && typeof o.keys == "string"
    );
  } catch {
    return [];
  }
}
async function hn(e, t) {
  const n = { version: 1, model: Yi(e), hotkeys: t };
  return d("write_pet_hotkeys", {
    modelPath: e,
    json: JSON.stringify(n, null, 2)
  });
}
async function Zi(e) {
  const t = await fetch(Xt(e));
  if (!t.ok) throw new Error(`HTTP ${t.status}`);
  return t.json();
}
async function Qi(e) {
  const t = await Zi(e), n = [], a = [], o = (v, _) => {
    _ && !v.includes(_) && v.push(_);
  }, p = (v) => {
    const _ = v;
    return typeof (_ == null ? void 0 : _.Id) == "string" && _.Id ? _.Id : typeof (_ == null ? void 0 : _.Target) == "string" && _.Target ? _.Target : "";
  }, b = t == null ? void 0 : t.PhysicsSettings;
  if (!Array.isArray(b)) return { inputs: n, outputs: a };
  for (const v of b) {
    const _ = v == null ? void 0 : v.Input;
    if (Array.isArray(_))
      for (const L of _) o(n, p(L == null ? void 0 : L.Source));
    const x = v == null ? void 0 : v.Output;
    if (Array.isArray(x))
      for (const L of x) o(a, p(L == null ? void 0 : L.Destination));
  }
  return { inputs: n, outputs: a };
}
async function Un(e, t) {
  var p, b;
  const n = {
    motions: [],
    expressions: [],
    expressionFiles: {},
    parameters: (t == null ? void 0 : t.parameters) ?? [],
    drawables: (t == null ? void 0 : t.drawables) ?? [],
    parts: (t == null ? void 0 : t.parts) ?? [],
    physicsInputs: [],
    physicsOutputs: []
  };
  let a = null;
  try {
    a = await fn(e);
  } catch {
    a = null;
  }
  if ((p = a == null ? void 0 : a.FileReferences) != null && p.Motions)
    for (const [v, _] of Object.entries(a.FileReferences.Motions))
      n.motions.push({ group: v, count: Array.isArray(_) ? _.length : 0 });
  try {
    const v = await Fa(e, a ?? void 0);
    n.expressions = v.map((_) => _.id);
    for (const _ of v) n.expressionFiles[_.id] = _.file;
  } catch {
    n.expressions = [];
  }
  const o = (b = a == null ? void 0 : a.FileReferences) == null ? void 0 : b.Physics;
  if (typeof o == "string" && o)
    try {
      const v = oe(dn(e), o), { inputs: _, outputs: x } = await Qi(v);
      n.physicsInputs = _, n.physicsOutputs = x;
    } catch {
    }
  return n;
}
const ba = /* @__PURE__ */ new Map();
async function Ba(e) {
  const t = e.toLowerCase(), n = ba.get(t);
  if (n) return n;
  let a = [];
  try {
    const o = await fetch(Xt(e));
    if (o.ok) {
      const p = await o.json();
      a = (Array.isArray(p.Parameters) ? p.Parameters : []).map((v) => {
        const _ = typeof (v == null ? void 0 : v.Id) == "string" ? v.Id : "", x = v == null ? void 0 : v.Value, L = v == null ? void 0 : v.Blend;
        return { id: _, value: typeof x == "number" ? x : NaN, blend: typeof L == "string" && L ? L : "Overwrite" };
      }).filter((v) => !!v.id && Number.isFinite(v.value));
    }
  } catch {
    a = [];
  }
  return ba.set(t, a), a;
}
async function mn(e) {
  try {
    const t = await fetch(Xt(e));
    return t.ok ? await t.json() : null;
  } catch {
    return null;
  }
}
async function tr(e) {
  const t = await mn(e), n = t == null ? void 0 : t.Hotkeys;
  if (!Array.isArray(n)) return [];
  const a = [];
  for (const o of n) {
    const p = o, b = typeof (p == null ? void 0 : p.Action) == "string" ? p.Action.trim() : "";
    if (!b) continue;
    const v = typeof (p == null ? void 0 : p.File) == "string" ? p.File.trim() : "", _ = typeof (p == null ? void 0 : p.Folder) == "string" ? p.Folder.trim() : "", x = typeof (p == null ? void 0 : p.Name) == "string" ? p.Name.trim() : "";
    a.push({ name: x || v, action: b, file: v ? _ ? `${_}/${v}` : v : "" });
  }
  return a;
}
async function er(e) {
  const t = await mn(e), n = t == null ? void 0 : t.ParameterSettings;
  if (!Array.isArray(n)) return [];
  const a = [];
  for (const o of n) {
    const p = o == null ? void 0 : o.OutputLive2D;
    typeof p == "string" && p && !a.includes(p) && a.push(p);
  }
  return a;
}
async function nr(e) {
  const t = { parameters: {}, parts: {}, artMeshes: {} }, n = await mn(e);
  if (!n) return t;
  const a = (o, p) => {
    const b = n[o];
    if (Array.isArray(b))
      for (const v of b) {
        const _ = v;
        typeof (_ == null ? void 0 : _.Id) == "string" && _.Id && typeof (_ == null ? void 0 : _.Name) == "string" && _.Name && (p[_.Id] = _.Name);
      }
  };
  return a("Parameters", t.parameters), a("Parts", t.parts), a("ArtMeshes", t.artMeshes), t;
}
function ar(e) {
  switch (e) {
    case "ToggleExpression":
      return "expression";
    case "TriggerAnimation":
      return "motion";
    default:
      return null;
  }
}
function ir(e, t) {
  const n = ar(e.action);
  if (!n) return null;
  const a = e.name || "热键";
  if (n === "expression") {
    const o = e.file ? oe(t, e.file) : "";
    return Fn(a, "", { type: "expression", target: e.name, mode: "set", file: o });
  }
  return Fn(a, "", { type: "motion", group: "", index: 0 });
}
async function Fe(e) {
  const t = dn(e);
  if (!t) return [];
  try {
    const n = await d("list_motion_files", { dir: t });
    return Array.isArray(n) ? n.filter((a) => !!a && typeof a.path == "string") : [];
  } catch {
    return [];
  }
}
async function rr(e) {
  const t = /* @__PURE__ */ new Map();
  for (const n of e) {
    const a = await mn(n), o = a == null ? void 0 : a.Curves;
    if (Array.isArray(o))
      for (const p of o) {
        const b = p == null ? void 0 : p.Id, v = p == null ? void 0 : p.Segments;
        if (typeof b != "string" || !b || !Array.isArray(v) || v.length < 3) continue;
        const _ = t.get(b) ?? /* @__PURE__ */ new Set();
        typeof v[1] == "number" && _.add(v[1]);
        let x = 2;
        for (; x < v.length; ) {
          const L = v[x];
          x += L === 1 ? 7 : 3;
          const E = v[x - 1];
          typeof E == "number" && _.add(E);
        }
        t.set(b, _);
      }
  }
  return t;
}
const sr = 0.1, or = 3600;
function lr() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
}
function cr(e = "新动作链") {
  return { id: lr(), name: e, steps: [], loop: !1 };
}
function ya(e = "") {
  return { file: e, loopSec: 3, stopSec: 0 };
}
function va(e, t) {
  const n = typeof e == "number" && Number.isFinite(e) ? e : t;
  return n <= 0 ? t : Math.min(or, Math.max(sr, n));
}
function pr(e) {
  return e.split(/[\\/]/).pop() || "";
}
async function tn(e) {
  let t = null;
  try {
    t = await d("read_pet_chains", { modelPath: e });
  } catch {
    return [];
  }
  if (!t) return [];
  try {
    const n = JSON.parse(t);
    return (Array.isArray(n.chains) ? n.chains : []).filter((o) => !!o && typeof o == "object" && typeof o.id == "string").map((o) => ({
      id: String(o.id),
      name: typeof o.name == "string" && o.name ? o.name : "动作链",
      // 整链循环：缺省 / 坏值一律当 false（保持「播完即停」的旧行为，不让坏数据把链卡成死循环）。
      loop: o.loop === !0,
      steps: (Array.isArray(o.steps) ? o.steps : []).filter((p) => !!p && typeof p == "object" && typeof p.file == "string").map((p) => ({
        file: p.file,
        loopSec: va(p.loopSec, 3),
        stopSec: typeof p.stopSec == "number" && Number.isFinite(p.stopSec) && p.stopSec > 0 ? va(p.stopSec, 3) : 0
      }))
    }));
  } catch {
    return [];
  }
}
async function ur(e, t) {
  const n = { version: 1, model: pr(e), chains: t };
  return d("write_pet_chains", { modelPath: e, json: JSON.stringify(n, null, 2) });
}
function Gn(e) {
  const t = e.stopSec > 0 ? e.stopSec : e.loopSec;
  return Math.min(e.loopSec, t);
}
function dr(e) {
  return e.steps.reduce((t, n) => t + Gn(n), 0);
}
function Va(e) {
  return e.split(/[\\/]/).pop() || "";
}
function qn(e) {
  return {
    version: 1,
    model: Va(e),
    coreIds: {
      parameters: [],
      drawables: [],
      parts: [],
      parameterRanges: {},
      physicsInputs: [],
      physicsOutputs: []
    },
    params: {}
  };
}
function Ie(e) {
  return Array.isArray(e) ? e.filter((t) => typeof t == "string") : [];
}
function fr(e) {
  const t = {};
  if (e && typeof e == "object")
    for (const [n, a] of Object.entries(e))
      typeof a == "number" && Number.isFinite(a) && (t[n] = a);
  return t;
}
function hr(e) {
  const t = {};
  if (e && typeof e == "object")
    for (const [n, a] of Object.entries(e)) {
      const o = a;
      o && typeof o == "object" && (t[n] = {
        min: typeof o.min == "number" && Number.isFinite(o.min) ? o.min : 0,
        max: typeof o.max == "number" && Number.isFinite(o.max) ? o.max : 0,
        def: typeof o.def == "number" && Number.isFinite(o.def) ? o.def : 0
      });
    }
  return t;
}
async function He(e) {
  let t = null;
  try {
    t = await d("read_pet_params", { modelPath: e });
  } catch {
    return null;
  }
  if (!t) return null;
  try {
    const n = JSON.parse(t);
    if (!n || typeof n != "object") return null;
    const a = n.coreIds ?? {};
    return {
      version: 1,
      model: typeof n.model == "string" ? n.model : Va(e),
      coreIds: {
        parameters: Ie(a.parameters),
        drawables: Ie(a.drawables),
        parts: Ie(a.parts),
        parameterRanges: hr(a.parameterRanges),
        physicsInputs: Ie(a.physicsInputs),
        physicsOutputs: Ie(a.physicsOutputs)
      },
      params: fr(n.params)
    };
  } catch {
    return null;
  }
}
async function an(e, t) {
  return d("write_pet_params", { modelPath: e, json: JSON.stringify(t, null, 2) });
}
function Ke(e) {
  return String(e).replace(
    /[&<>"']/g,
    (t) => t === "&" ? "&amp;" : t === "<" ? "&lt;" : t === ">" ? "&gt;" : t === '"' ? "&quot;" : "&#39;"
  );
}
function Rn(e, t, n = "") {
  var v, _;
  const a = t.map((x) => {
    const L = x.tag ? ` data-tag="${Ke(x.tag)}"` : "", E = x.deletable ? '<span class="cs-del" title="×">×</span>' : "";
    return `<div class="custom-select-option${x.selected ? " selected" : ""}" data-value="${Ke(x.value)}"${L}>${Ke(x.label)}${E}</div>`;
  }).join(""), o = ((v = t.find((x) => x.selected)) == null ? void 0 : v.label) || ((_ = t[0]) == null ? void 0 : _.label) || "", p = "", b = n ? ` ${n}` : "";
  return `<div class="custom-select"${p}${b}><button class="custom-select-trigger" type="button"><span class="custom-select-label">${Ke(o)}</span><svg class="custom-select-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg></button><div class="custom-select-dropdown">${a}</div></div>`;
}
const wa = "__lunacCustomSelectBound";
function xa(e) {
  const t = e.querySelector(".custom-select-dropdown"), n = e.querySelector(".custom-select-trigger");
  if (!t || !n) return;
  const a = n.getBoundingClientRect(), o = 8, p = 120, b = e.closest("#results-list"), v = b == null ? void 0 : b.getBoundingClientRect(), _ = Math.max(v ? v.top : 0, 0), L = Math.min(v ? v.bottom : window.innerHeight, window.innerHeight) - a.bottom - o, E = a.top - _ - o, Z = L < p && E > L, B = Math.max(60, Math.min(p, Z ? E : L));
  t.style.overflowY = "auto", t.style.overscrollBehavior = "contain", t.style.position = "absolute", t.style.left = "0", t.style.width = "100%", t.style.maxHeight = B + "px", Z ? (t.style.top = "auto", t.style.bottom = "calc(100% + 4px)") : (t.style.top = "calc(100% + 4px)", t.style.bottom = "auto"), t.style.marginTop = "0", t.style.marginBottom = "0";
}
function mr(e) {
  var t;
  return ((t = e.textContent) == null ? void 0 : t.replace(/\s*×$/, "").trim()) || "";
}
function gr(e, t) {
  const n = e;
  if (n[wa]) return;
  n[wa] = !0;
  const a = e.querySelector(".custom-select-trigger"), o = e.querySelector(".custom-select-dropdown"), p = e.querySelector(".custom-select-label");
  if (!a || !o || !p) return;
  const b = t.scope ?? document, v = () => b.querySelectorAll(".custom-select.open").forEach((x) => {
    x !== e && x.classList.remove("open");
  });
  a.addEventListener("click", (x) => {
    var E, Z;
    x.preventDefault(), x.stopPropagation();
    const L = e.classList.contains("open");
    v(), L ? (e.classList.remove("open"), (E = t.onOpenChange) == null || E.call(t, !1)) : (e.classList.add("open"), (Z = t.onOpenChange) == null || Z.call(t, !0), xa(e), window.addEventListener("resize", () => xa(e), { once: !0 }));
  }), o.addEventListener("click", (x) => {
    var B, tt;
    const L = x.target, E = L.closest(".cs-del");
    if (E) {
      x.preventDefault(), x.stopPropagation();
      const K = E.closest(".custom-select-option");
      K && ((B = t.onDelete) == null || B.call(t, K));
      return;
    }
    const Z = L.closest(".custom-select-option");
    if (!Z) return;
    x.preventDefault(), x.stopPropagation();
    const it = Z.getAttribute("data-value") || "";
    if (it === "__custom__" && t.onCustomEntry) {
      t.onCustomEntry(p);
      return;
    }
    o.querySelectorAll(".custom-select-option").forEach((K) => K.classList.remove("selected")), Z.classList.add("selected"), p.textContent = mr(Z), e.classList.remove("open"), (tt = t.onOpenChange) == null || tt.call(t, !1), t.onPick(it);
  }), o.addEventListener(
    "wheel",
    (x) => {
      const L = o.scrollTop > 0, E = o.scrollTop + o.clientHeight < o.scrollHeight - 1;
      (x.deltaY < 0 && L || x.deltaY > 0 && E) && (x.preventDefault(), o.scrollTop += x.deltaY);
    },
    { passive: !1 }
  );
  const _ = (x) => {
    var E;
    if (!e.isConnected) {
      document.removeEventListener("click", _);
      return;
    }
    const L = x.target;
    L && e.contains(L) || e.classList.contains("open") && (e.classList.remove("open"), (E = t.onOpenChange) == null || E.call(t, !1));
  };
  document.addEventListener("click", _);
}
const Ua = 1, Ga = 4, Xn = 2, br = 12e4;
function gn(e) {
  if (typeof e != "number" || !Number.isFinite(e)) return Xn;
  const t = Math.round(e * 100) / 100;
  return Math.min(Ga, Math.max(Ua, t));
}
function _a(e) {
  return e.replace(/\s+/g, " ").trim();
}
const yr = /[\u1100-\u11FF\u2E80-\u2EFF\u3000-\u303F\u3040-\u30FF\u3130-\u318F\u3400-\u4DBF\u4E00-\u9FFF\uA960-\uA97F\uAC00-\uD7AF\uF900-\uFAFF\uFE30-\uFE4F\uFF00-\uFFEF]/u, vr = /[\p{P}\p{S}]/u, wr = /\s/u;
function xr(e) {
  const t = [];
  let n = "";
  for (const a of e) {
    if (wr.test(a)) {
      n ? (t.push(n + a), n = "") : t.length && (t[t.length - 1] += a);
      continue;
    }
    if (vr.test(a)) {
      n ? n += a : t.length ? t[t.length - 1] += a : n += a;
      continue;
    }
    if (yr.test(a)) {
      n && (t.push(n), n = ""), t.push(a);
      continue;
    }
    n += a;
  }
  return n && t.push(n), t;
}
function _r(e, t, n) {
  if (!(e > 0)) return !0;
  const a = gn(t);
  return e * 1e3 / a > n;
}
const ot = 75, Wn = 400, zn = 300, qa = 140, Yn = 35, se = ot + Wn + Yn, re = 255, ve = 320, kr = ve - zn, Sr = 160, Mr = ot + Yn + qa, ka = 2e3, Xa = 20;
function Sa(e) {
  const t = Number.isFinite(e) ? e : se;
  return Math.min(re, Math.max(ot, t - Yn - qa));
}
function Cr(e, t = re) {
  const n = Math.min(re, Math.max(ot, Number.isFinite(t) ? t : re));
  return typeof e != "number" || !Number.isFinite(e) ? ot : Math.min(n, Math.max(ot, Math.ceil(e)));
}
function $r(e, t = Xa, n = re) {
  const a = Math.min(re, Math.max(ot, Number.isFinite(n) ? n : re)), o = Math.min(a, Math.max(ot, e));
  if (o >= a) return a;
  const p = ot + Math.ceil((o - ot) / t) * t;
  return Math.min(a, Math.max(ot, p));
}
function Er(e, t) {
  return e + (t - ot);
}
function Hn(e, t) {
  const n = typeof e == "number" && Number.isFinite(e) ? Math.round(Math.min(ka, Math.max(Sr, e))) : ve, a = typeof t == "number" && Number.isFinite(t) ? Math.round(Math.min(ka, Math.max(Mr, t))) : se;
  return { w: n, h: a };
}
function Tr(e, t) {
  return Math.abs(e - t) >= 1;
}
function Ar(e, t) {
  const n = e - (t - ot);
  return Number.isFinite(n) ? n : se;
}
const Nr = "lunac.pet.look-screen.v1", H = "pet-control", Lr = "pet-chat-send", Ir = "pet-chat-reply", Or = "pet-chat-stop", Pr = "pet-tts-mouth", Dr = "pet-tts-done", Kn = 1, Jn = 1440, Zn = 1, Qn = 200, Fr = 6e3, Tn = 9e4, rn = 1, sn = 240, on = 5, ln = 600, cn = 1, pn = 120, Ya = "lunac.pet.v1", me = "plugin-pet", Ma = 1.1, An = [
  { id: "ParamAngleX", min: -100, max: 100, labelKey: "pet.param_head_x" },
  { id: "ParamAngleY", min: -100, max: 100, labelKey: "pet.param_head_y" },
  { id: "ParamAngleZ", min: -100, max: 100, labelKey: "pet.param_head_z" },
  { id: "ParamEyeLOpen", min: 0, max: 100, labelKey: "pet.param_eye_l" },
  { id: "ParamEyeROpen", min: 0, max: 100, labelKey: "pet.param_eye_r" },
  { id: "ParamMouthOpenY", min: 0, max: 100, labelKey: "pet.param_mouth" },
  { id: "ParamBodyAngleX", min: -100, max: 100, labelKey: "pet.param_body_x" },
  { id: "ParamBodyAngleZ", min: -100, max: 100, labelKey: "pet.param_body_z" },
  { id: "ParamBreath", min: 0, max: 100, labelKey: "pet.param_breath" }
], en = {
  image: "",
  model: "",
  scale: 1,
  offsetX: 0,
  offsetY: 0,
  rotation: 0,
  clickThrough: !1,
  expressions: {},
  params: {},
  paramKinds: {},
  idleMotions: {},
  hotkeyStates: {},
  proactive: { enabled: !1, intervalMin: 30, dailyCap: 20, date: "", used: 0, autoShot: !1, autoShotMin: 5, screenWatch: !1, screenWatchSec: 20, screenDiff: 12 },
  tts: !0,
  speechRate: Xn,
  winW: ve,
  winH: se
};
function N() {
  try {
    const e = localStorage.getItem(Ya);
    if (!e) return { ...en };
    const t = JSON.parse(e), n = {};
    if (t.expressions && typeof t.expressions == "object")
      for (const [B, tt] of Object.entries(t.expressions))
        B && typeof tt == "string" && (n[B] = tt);
    const a = {};
    if (t.params && typeof t.params == "object")
      for (const [B, tt] of Object.entries(t.params)) {
        if (!B || !tt || typeof tt != "object") continue;
        const K = {};
        for (const [D, W] of Object.entries(tt))
          D && typeof W == "number" && Number.isFinite(W) && (K[D] = W);
        Object.keys(K).length && (a[B] = K);
      }
    const o = {}, p = t.paramKinds;
    if (p && typeof p == "object")
      for (const [B, tt] of Object.entries(p)) {
        if (!B || !tt || typeof tt != "object") continue;
        const K = {};
        for (const [D, W] of Object.entries(tt))
          D && (W === "switch" || W === "range") && (K[D] = W);
        Object.keys(K).length && (o[B] = K);
      }
    const b = {}, v = t.idleMotions;
    if (v && typeof v == "object")
      for (const [B, tt] of Object.entries(v)) {
        if (!B || !Array.isArray(tt)) continue;
        const K = tt.filter((D) => typeof D == "string" && D.trim().length > 0);
        K.length && (b[B] = K);
      }
    const _ = {}, x = t.hotkeyStates;
    if (x && typeof x == "object")
      for (const [B, tt] of Object.entries(x)) {
        if (!B || !Array.isArray(tt)) continue;
        const K = tt.filter((D) => typeof D == "string" && D.trim().length > 0);
        K.length && (_[B] = K);
      }
    const L = en.proactive, E = t.proactive, Z = E && typeof E == "object" ? {
      enabled: E.enabled === !0,
      intervalMin: typeof E.intervalMin == "number" && Number.isFinite(E.intervalMin) ? Math.min(Jn, Math.max(Kn, Math.round(E.intervalMin))) : L.intervalMin,
      dailyCap: typeof E.dailyCap == "number" && Number.isFinite(E.dailyCap) ? Math.min(Qn, Math.max(Zn, Math.round(E.dailyCap))) : L.dailyCap,
      date: typeof E.date == "string" ? E.date : "",
      used: typeof E.used == "number" && Number.isFinite(E.used) && E.used > 0 ? Math.floor(E.used) : 0,
      // 「自动抓屏」/「屏幕变化触发」两个子开关：**只有显式 true 才算开**（默认关，隐私红线）。
      autoShot: E.autoShot === !0,
      autoShotMin: typeof E.autoShotMin == "number" && Number.isFinite(E.autoShotMin) ? Math.min(sn, Math.max(rn, Math.round(E.autoShotMin))) : L.autoShotMin,
      screenWatch: E.screenWatch === !0,
      screenWatchSec: typeof E.screenWatchSec == "number" && Number.isFinite(E.screenWatchSec) ? Math.min(ln, Math.max(on, Math.round(E.screenWatchSec))) : L.screenWatchSec,
      screenDiff: typeof E.screenDiff == "number" && Number.isFinite(E.screenDiff) ? Math.min(pn, Math.max(cn, Math.round(E.screenDiff))) : L.screenDiff
    } : { ...L }, it = Hn(
      typeof t.winW == "number" ? t.winW : ve,
      typeof t.winH == "number" ? t.winH : se
    );
    return {
      image: typeof t.image == "string" ? t.image : "",
      model: typeof t.model == "string" ? t.model : "",
      scale: typeof t.scale == "number" && t.scale >= Ha && t.scale <= ja ? t.scale : 1,
      offsetX: typeof t.offsetX == "number" && Number.isFinite(t.offsetX) ? t.offsetX : 0,
      offsetY: typeof t.offsetY == "number" && Number.isFinite(t.offsetY) ? t.offsetY : 0,
      rotation: typeof t.rotation == "number" && Number.isFinite(t.rotation) ? Math.max(-180, Math.min(180, t.rotation)) : 0,
      clickThrough: t.clickThrough === !0,
      expressions: n,
      params: a,
      paramKinds: o,
      idleMotions: b,
      hotkeyStates: _,
      proactive: Z,
      // 语音朗读：**默认 true**（老配置缺这个字段 ⇒ 回落到 true）。
      tts: typeof t.tts == "boolean" ? t.tts : !0,
      // 速率：越界 / 非法回落默认（`clampRate` 同一套夹取口径）。
      speechRate: gn(typeof t.speechRate == "number" ? t.speechRate : Xn),
      // 窗口尺寸记忆：越界 / 非法在 `clampWindowSize` 里夹到合法区间（打开时还会再 clamp 一次）。
      winW: it.w,
      winH: it.h
    };
  } catch {
    return { ...en };
  }
}
function X(e) {
  try {
    localStorage.setItem(Ya, JSON.stringify(e));
  } catch {
  }
}
function Ka() {
  const e = /* @__PURE__ */ new Date(), t = (n) => String(n).padStart(2, "0");
  return `${e.getFullYear()}-${t(e.getMonth() + 1)}-${t(e.getDate())}`;
}
function Ut() {
  const e = N().proactive;
  return e.date !== Ka() ? 0 : e.used > 0 ? e.used : 0;
}
function Nn() {
  const e = N(), t = Ka(), n = (e.proactive.date === t && e.proactive.used || 0) + 1;
  return X({ ...e, proactive: { ...e.proactive, date: t, used: n } }), n;
}
function Rr(e, t) {
  if (e.length !== t.length || e.length === 0) return 0;
  let n = 0;
  for (let a = 0; a < e.length; a++) n += Math.abs(e[a] - t[a]);
  return n / e.length;
}
function Ln() {
  const e = /* @__PURE__ */ new Date(), t = new Date(e.getFullYear(), e.getMonth(), e.getDate() + 1, 0, 0, 5);
  return Math.max(1e3, t.getTime() - Date.now());
}
function $(e) {
  return e.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
function bn(e) {
  return h(e ? "pet.through_on" : "pet.through_off");
}
function Et(e, t) {
  d("log_frontend", {
    level: "error",
    message: `[pet window] ${e}: ${t instanceof Error ? t.message : String(t)}`
  }).catch(() => {
  });
}
function Ja() {
  try {
    return yt().label || "";
  } catch {
    return "";
  }
}
function Tt() {
  return location.pathname.endsWith("plugin.html") && Ja() === me;
}
function Ca() {
  return Ja() === `${me}-settings`;
}
let Je = null;
function Wr() {
  return Je || (Je = (async () => (await Ui(), await import(Xt(await Vi()))))().catch((e) => {
    throw Je = null, e instanceof Error ? e : new Error(String(e));
  })), Je;
}
function Za(e, t) {
  return `${h(e)}：${t ? "开" : "关"}`;
}
function be(e) {
  return e ? "开" : "关";
}
function zr(e) {
  const t = e.proactive, n = Ut(), a = h("pet.proactive_usage", { used: String(n), cap: String(t.dailyCap) }), o = n >= t.dailyCap ? `${a} · ${h("pet.proactive_reached")}` : a;
  return `
  <div class="pet-proactive" id="pet-proactive">
    <div class="pet-debug-title">${h("pet.proactive_title")}</div>
    <div class="pet-row">
      <span class="pet-label">${h("pet.proactive_enable")}</span>
      <button type="button" id="pet-proactive-enabled" class="pet-btn pet-btn-toggle${t.enabled ? " on" : ""}" aria-pressed="${t.enabled ? "true" : "false"}">${$(be(t.enabled))}</button>
    </div>
    <div class="pet-row">
      <span class="pet-label">${h("pet.proactive_interval")}</span>
      <input type="text" id="pet-proactive-interval" class="pet-param-num" inputmode="numeric" autocomplete="off" spellcheck="false" value="${t.intervalMin}" aria-label="${$(h("pet.proactive_interval"))}">
      <span class="pet-val">${h("pet.proactive_minute")}</span>
    </div>
    <div class="pet-row">
      <span class="pet-label">${h("pet.proactive_cap")}</span>
      <input type="text" id="pet-proactive-cap" class="pet-param-num" inputmode="numeric" autocomplete="off" spellcheck="false" value="${t.dailyCap}" aria-label="${$(h("pet.proactive_cap"))}">
      <span class="pet-val">${h("pet.proactive_cap_unit")}</span>
    </div>
    <div class="pet-row">
      <span class="pet-label">${h("pet.proactive_autoshot")}</span>
      <button type="button" id="pet-autoshot-enabled" class="pet-btn pet-btn-toggle${t.autoShot ? " on" : ""}" aria-pressed="${t.autoShot ? "true" : "false"}">${$(be(t.autoShot))}</button>
      <input type="text" id="pet-autoshot-min" class="pet-param-num" inputmode="numeric" autocomplete="off" spellcheck="false" value="${t.autoShotMin}" aria-label="${$(h("pet.proactive_autoshot"))}">
      <span class="pet-val">${h("pet.proactive_minute")}</span>
    </div>
    <div class="pet-row">
      <span class="pet-label">${h("pet.proactive_screenwatch")}</span>
      <button type="button" id="pet-screenwatch-enabled" class="pet-btn pet-btn-toggle${t.screenWatch ? " on" : ""}" aria-pressed="${t.screenWatch ? "true" : "false"}">${$(be(t.screenWatch))}</button>
      <input type="text" id="pet-watch-sec" class="pet-param-num" inputmode="numeric" autocomplete="off" spellcheck="false" value="${t.screenWatchSec}" aria-label="${$(h("pet.proactive_watch_sec"))}">
      <span class="pet-val">${h("pet.proactive_second")}</span>
    </div>
    <div class="pet-row">
      <span class="pet-label">${h("pet.proactive_sensitivity")}</span>
      <input type="text" id="pet-watch-diff" class="pet-param-num" inputmode="numeric" autocomplete="off" spellcheck="false" value="${t.screenDiff}" aria-label="${$(h("pet.proactive_sensitivity"))}">
    </div>
    <div class="pet-note" id="pet-proactive-hint">${$(h("pet.proactive_shot_hint"))}</div>
    <div class="pet-note" id="pet-proactive-usage">${$(o)}</div>
  </div>`;
}
const Qa = 0.5, ti = 2, jn = 1, ei = 0, ni = 1, Bn = 1;
function $a(e) {
  return typeof e != "number" || !Number.isFinite(e) ? jn : Math.min(ti, Math.max(Qa, Math.round(e * 100) / 100));
}
function Ea(e) {
  return typeof e != "number" || !Number.isFinite(e) ? Bn : Math.min(ni, Math.max(ei, Math.round(e * 100) / 100));
}
function Hr(e) {
  return `
  <div class="pet-tts" id="pet-tts">
    <div class="pet-debug-title">${h("pet.tts_title")}</div>
    <div class="pet-row">
      <button type="button" id="pet-tts-enabled" class="pet-btn pet-btn-toggle${e.tts ? " on" : ""}" aria-pressed="${e.tts ? "true" : "false"}">${$(Za("pet.tts_enable", e.tts))}</button>
    </div>
    <div class="pet-row">
      <span class="pet-label">${$(h("pet.tts_rate_label"))}</span>
      <input type="range" id="pet-tts-rate" class="pet-range" min="${Ua}" max="${Ga}" step="0.5" value="${e.speechRate}" aria-label="${$(h("pet.tts_rate_label"))}">
      <span class="pet-val" id="pet-tts-rate-val">${e.speechRate}</span>
    </div>
    <div class="pet-row">
      <span class="pet-label">${$(h("pet.tts_speed_label"))}</span>
      <input type="range" id="pet-tts-speed" class="pet-range" min="${Qa}" max="${ti}" step="0.1" value="${jn}" aria-label="${$(h("pet.tts_speed_label"))}">
      <span class="pet-val" id="pet-tts-speed-val">${jn.toFixed(1)}×</span>
    </div>
    <div class="pet-row">
      <span class="pet-label">${$(h("pet.tts_volume_label"))}</span>
      <input type="range" id="pet-tts-volume" class="pet-range" min="${ei}" max="${ni}" step="0.05" value="${Bn}" aria-label="${$(h("pet.tts_volume_label"))}">
      <span class="pet-val" id="pet-tts-volume-val">${Math.round(Bn * 100)}%</span>
    </div>
    <div class="pet-tts-voice">
      <span class="pet-label">${$(h("pet.tts_voice_label"))}</span>
      <input type="text" id="pet-tts-reftext" class="pet-tts-text" autocomplete="off" spellcheck="false" placeholder="${$(h("pet.tts_ref_text_ph"))}" aria-label="${$(h("pet.tts_voice_label"))}">
      <div class="pet-row">
        <button type="button" id="pet-tts-addfile" class="pet-btn pet-btn-primary">${$(h("pet.tts_add_audio"))}</button>
        <button type="button" id="pet-tts-preview" class="pet-btn">${$(h("pet.tts_preview"))}</button>
      </div>
      <div class="pet-note" id="pet-tts-status"></div>
      <div class="pet-note" id="pet-tts-msg"></div>
    </div>
  </div>`;
}
const jr = {
  motion: "播动作",
  chain: "动作链",
  // VTS 侧对应表情的动作类型叫 “Expression on/off” —— 这里同样按**开关**语义（可叠加、再点关闭）。
  expression: "表情开关",
  param: "设参数",
  artmesh: "ArtMesh 显隐",
  artmeshColor: "ArtMesh 染色",
  part: "Part 显隐",
  physics: "开关物理"
}, Br = '<svg viewBox="0 0 16 16" width="13" height="13" aria-hidden="true" focusable="false"><path d="M8 1.6 11.2 5.2H4.8Z" fill="currentColor"/><path d="M8 14.4 4.8 10.8h6.4Z" fill="currentColor"/></svg>';
function Vr() {
  return `
  <div class="pet-hotkeys" id="pet-hotkeys">
    <div class="pet-row">
      <button type="button" id="pet-hk-import" class="pet-btn pet-btn-primary" title="以模型文件夹为准重建热键表：优先读同目录 vtube.json 里的作者热键，没有就递归扫文件夹里的「中文名.exp3.json」。会自动分配默认键并落盘；按键仅供 AI 触发，本地不做按键监听。">重新导入（模型文件夹）</button>
    </div>
    <div class="pet-hk-list" id="pet-hk-list"></div>
    <div class="pet-note" id="pet-hk-msg"></div>
  </div>`;
}
function Ur() {
  return `
  <div class="pet-motions" id="pet-motions">
    <!-- **动作链**（2026-10-10 用户口径：与「恢复默认」一样放在动作页**最上面**）：
         把多个动作排进一条时间线，每步各设「循环播放时长 / 硬停秒」。 -->
    <div class="pet-chains" id="pet-chains">
      <div class="pet-row">
        <button type="button" id="pet-chain-add" class="pet-btn pet-btn-primary" title="新建一条动作链：把多个动作排进一条时间线，每个动作各设循环播放时长与硬停秒。可在「热键」页把动作链绑成热键，AI 也可按链名触发。">新建动作链</button>
      </div>
      <div class="pet-chain-list" id="pet-chain-list"></div>
      <div class="pet-note" id="pet-chain-msg"></div>
    </div>
    <div class="pet-row">
      <button type="button" id="pet-mo-add" class="pet-btn pet-btn-primary" title="在模型文件夹里生成一个覆盖本模型全部参数的 *.motion3.json 模板（1 秒 / 30fps / 循环），交给 AI 去编曲线。">新建动作（motion3 模板）</button>
    </div>
    <div class="pet-mo-list" id="pet-mo-list"></div>
    <div class="pet-note" id="pet-mo-msg"></div>
  </div>`;
}
const ai = "lunac.pet.coreids.v1.";
function Gr(e) {
  const t = {
    parameters: [],
    drawables: [],
    parts: [],
    parameterRanges: {},
    physicsInputs: [],
    physicsOutputs: []
  };
  try {
    const n = localStorage.getItem(ai + e.toLowerCase());
    if (!n) return t;
    const a = JSON.parse(n);
    return {
      parameters: Array.isArray(a.parameters) ? a.parameters : [],
      drawables: Array.isArray(a.drawables) ? a.drawables : [],
      parts: Array.isArray(a.parts) ? a.parts : [],
      parameterRanges: a.parameterRanges && typeof a.parameterRanges == "object" ? a.parameterRanges : {},
      physicsInputs: Array.isArray(a.physicsInputs) ? a.physicsInputs : [],
      physicsOutputs: Array.isArray(a.physicsOutputs) ? a.physicsOutputs : []
    };
  } catch {
    return t;
  }
}
async function ta(e) {
  const t = Gr(e);
  try {
    const n = await He(e), a = n == null ? void 0 : n.coreIds;
    if (a && (a.parameters.length || a.drawables.length || a.parts.length)) return a;
    if (t.parameters.length || t.drawables.length || t.parts.length) {
      const o = n ?? qn(e);
      o.coreIds = t;
      const p = N().params[e];
      !Object.keys(o.params).length && p && typeof p == "object" && (o.params = { ...p }), await an(e, o);
    }
  } catch (n) {
    console.warn("[pet] 读/播种 lunac.params.json 失败", n);
  }
  return t;
}
let Oe = /* @__PURE__ */ new Map(), gt = [], Gt = {
  motions: [],
  expressions: [],
  expressionFiles: {},
  parameters: [],
  drawables: [],
  parts: []
}, ye = /* @__PURE__ */ new Set();
function Nt(e) {
  const t = document.getElementById("pet-hk-msg");
  t && (t.textContent = e);
}
let Ze = null;
function je() {
  const e = N().model.trim();
  e && (Ze && clearTimeout(Ze), Ze = setTimeout(() => {
    Ze = null, N().model.trim() === e && hn(e, gt).catch(
      (t) => Nt("保存热键失败：" + (t instanceof Error ? t.message : String(t)))
    );
  }, 400));
}
function ii(e) {
  let t = !1;
  return e.forEach((n, a) => {
    n.keys || (n.keys = Ji(a), t = !0);
  }), t;
}
async function qr(e) {
  const t = [], n = /* @__PURE__ */ new Set();
  try {
    for (const a of await ge(e)) {
      const o = a.action;
      if (o.type !== "expression" || !o.file) continue;
      const p = o.file.toLowerCase();
      n.has(p) || (n.add(p), t.push({ name: o.target || a.name, file: o.file }));
    }
  } catch {
  }
  return t;
}
function Ta(e) {
  return e.toLowerCase().replace(/\//g, "\\");
}
async function Xr(e, t) {
  const n = t.filter((b) => b.action.type === "expression" && !!b.action.file);
  if (!n.length) return !1;
  let a;
  try {
    a = await Fa(e);
  } catch {
    return !1;
  }
  const o = /* @__PURE__ */ new Map();
  for (const b of a) b.file && o.set(Ta(b.file), b.id);
  let p = !1;
  for (const b of n) {
    if (b.action.type !== "expression" || !b.action.file) continue;
    const v = o.get(Ta(b.action.file));
    v && v !== b.action.target && (b.action.target = v, p = !0);
  }
  return p;
}
async function Yr(e) {
  const t = /* @__PURE__ */ new Set();
  try {
    const n = [];
    for (const a of await ge(e))
      a.action.type === "expression" && a.action.file && n.push(a.action.file);
    await Promise.all(
      n.map(async (a) => {
        for (const o of await Ba(a)) t.add(o.id);
      })
    );
  } catch {
  }
  return t;
}
async function Aa(e) {
  const t = dn(e);
  try {
    const n = await d("scan_model_folder", { dir: t });
    return { dir: t, vtube: (n.vtube ?? [])[0] ?? "", cdi3: (n.cdi3 ?? [])[0] ?? "" };
  } catch {
    return { dir: t, vtube: "", cdi3: "" };
  }
}
const Kr = { parameters: {} };
async function Jr(e, t) {
  var n;
  try {
    const a = await fn(e), o = [];
    for (const p of Object.values(((n = a.FileReferences) == null ? void 0 : n.Motions) ?? {}))
      for (const b of p ?? [])
        b != null && b.File && o.push(oe(t, b.File));
    return o.length ? await rr(o) : /* @__PURE__ */ new Map();
  } catch {
    return /* @__PURE__ */ new Map();
  }
}
async function Vn(e, t, n) {
  let a = [];
  if (n && (a = (await tr(n)).map((p) => ir(p, e)).filter((p) => !!p)), !a.length) {
    let o = [];
    try {
      o = await d("list_exp3_files", { dir: e });
    } catch {
      o = [];
    }
    a = o.filter((p) => typeof (p == null ? void 0 : p.path) == "string" && p.path).map((p) => {
      const b = (p.name || "").trim() || "表情";
      return Fn(b, "", { type: "expression", target: b, mode: "set", file: p.path });
    });
  }
  return a.length ? (ii(a), await Xr(t, a), await hn(t, a), gt = a, qt(), a.length) : 0;
}
let lt = [], U = [];
const Na = "lunac_";
function At(e) {
  const t = document.getElementById("pet-mo-msg");
  t && (t.textContent = e);
}
function ri(e) {
  const t = e ? N().idleMotions[e] ?? [] : [];
  return new Set(t.map((n) => n.toLowerCase()));
}
function La() {
  const e = N().model.trim();
  if (!e) return;
  const t = N(), n = t.idleMotions[e];
  if (!n || !n.length) return;
  const a = new Set(lt.map((b) => b.name.toLowerCase())), o = n.filter((b) => a.has(b.toLowerCase()));
  if (o.length === n.length) return;
  const p = { ...t.idleMotions };
  o.length ? p[e] = o : delete p[e], X({ ...t, idleMotions: p }), un();
}
function un() {
  const e = document.getElementById("pet-mo-list");
  if (!e) return;
  if (!lt.length) {
    e.innerHTML = '<div class="pet-note">模型文件夹里还没有 *.motion3.json —— 点「新建动作」生成一个模板。</div>';
    return;
  }
  const t = ri(N().model.trim());
  e.innerHTML = lt.map((n, a) => {
    const o = t.has(n.name.toLowerCase());
    return `<div class="pet-mo-row" data-mo-i="${a}">
      <input class="pet-mo-name" data-mo-name="${a}" spellcheck="false" value="${$(n.name)}" title="${$(n.path)}">
      <button type="button" class="pet-btn pet-btn-toggle pet-mo-idle${o ? " on" : ""}" data-mo-idle="${a}" aria-pressed="${o ? "true" : "false"}" title="循环播放：勾上后，模型闲下来（没有别的动作在播）时会按顺序轮流播放它；是否循环由该文件自己的 Meta.Loop 决定">循环播放：${o ? "开" : "关"}</button>
      <button type="button" class="pet-btn pet-mo-run" data-mo-run="${a}">播放</button>
      <button type="button" class="pet-btn pet-mo-del" data-mo-del="${a}">删除</button>
      <div class="pet-chain-bar pet-mo-bar" data-bar-idx="${a}"><i></i><span class="pet-mo-bar-t">${$(n.name)}</span></div>
    </div>`;
  }).join("");
}
async function Pe() {
  const e = N().model.trim();
  if (!e) {
    lt = [], un(), U = [], vt(), At("先选一个 Live2D 模型 —— 「更换模型」里选模型文件夹。");
    return;
  }
  lt = await Fe(e), un(), as(), At(lt.length ? `共 ${lt.length} 个动作文件。` : "这个模型文件夹里没扫到 *.motion3.json。");
}
function si(e) {
  const t = document.getElementById("pet-chain-msg");
  t && (t.textContent = e);
}
function Zr(e) {
  return lt.findIndex((t) => t.path.toLowerCase() === e.toLowerCase());
}
let Re = /* @__PURE__ */ new Set();
const Qr = '<svg viewBox="0 0 16 16" width="11" height="11" aria-hidden="true" focusable="false"><path d="M6 3.2 10.8 8 6 12.8" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>', ts = '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><g opacity="0.28" transform="translate(-0.7,-0.7)" stroke-width="1.6"><rect x="5" y="5" width="14" height="14" rx="2.5"/></g><rect x="5" y="5" width="14" height="14" rx="2.5"/><circle cx="8.6" cy="8.6" r="0.9" fill="currentColor" stroke="none"/></svg>', es = '<svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M22 6 6 22"/><path d="M22 12 12 22"/><path d="M22 18 18 22"/></svg>';
function ns(e) {
  const t = e.file.split(/[\\/]/).pop() || "(未选)", n = e.stopSec > 0 ? `${e.stopSec.toFixed(1)}s` : "不限";
  return `${t} · 循环 ${e.loopSec.toFixed(1)}s · 硬停 ${n}`;
}
async function oi(e) {
  var t;
  if (!e) return null;
  try {
    const n = await fetch(Xt(e));
    if (!n.ok) return null;
    const a = await n.json(), o = Number((t = a == null ? void 0 : a.Meta) == null ? void 0 : t.Duration);
    return Number.isFinite(o) && o > 0 ? Math.min(3600, Math.max(0.1, o)) : null;
  } catch {
    return null;
  }
}
function vt() {
  const e = document.getElementById("pet-chain-list");
  if (e) {
    if (!U.length) {
      e.innerHTML = '<div class="pet-note">还没有动作链 —— 点「新建动作链」，再把动作文件排进时间线。</div>';
      return;
    }
    e.innerHTML = U.map((t, n) => {
      const a = Re.has(t.id), o = t.steps.map((b, v) => {
        const _ = Zr(b.file), x = b.file.split(/[\\/]/).pop() || "(未选)", L = lt.length ? lt.map((Z) => ({ value: Z.path, label: Z.name, selected: Z.path.toLowerCase() === b.file.toLowerCase() })) : [{ value: "", label: "（没有动作文件）", selected: !0 }], E = Gn(b);
        return `<div class="pet-chain-step">
          <div class="pet-chain-fields">
            ${Rn("", L, `data-chain-step-file="${n}:${v}"`)}
            <label class="pet-chain-t">循环<input class="pet-chain-num" type="number" min="0.1" max="3600" step="0.1" data-chain-step-loop="${n}:${v}" value="${b.loopSec}">s</label>
            <label class="pet-chain-t">硬停<input class="pet-chain-num" type="number" min="0" max="3600" step="0.1" data-chain-step-stop="${n}:${v}" value="${b.stopSec}">s</label>
            <button type="button" class="pet-btn pet-chain-del" data-chain-step-del="${n}:${v}" title="删掉这一步">×</button>
          </div>
          <div class="pet-chain-bar" data-bar-chain="${$(t.id)}" data-bar-idx="${_}"><i></i><span>${$(x)} · ${E.toFixed(1)}s</span></div>
        </div>`;
      }).join(""), p = t.steps.length ? t.steps.map(ns).join("  ·  ") : "（还没有步骤）";
      return `<div class="pet-chain${a ? " collapsed" : ""}" data-chain-i="${n}">
      <div class="pet-chain-head">
        <button type="button" class="pet-btn pet-chain-toggle${a ? "" : " on"}" data-chain-toggle="${n}" aria-expanded="${a ? "false" : "true"}" title="${a ? "展开这条链" : "收起这条链"}">${Qr}</button>
        <input class="pet-chain-name" data-chain-name="${n}" spellcheck="false" value="${$(t.name)}">
        <span class="pet-chain-total">共 ${dr(t).toFixed(1)}s</span>
        <button type="button" class="pet-btn pet-btn-toggle pet-chain-loopbtn${t.loop ? " on" : ""}" data-chain-loop="${n}" aria-pressed="${t.loop ? "true" : "false"}" title="整链循环：整条链播完从头再来；关闭则播完即停（每步自己的循环 / 硬停照旧生效）">整链循环：${t.loop ? "开" : "关"}</button>
        <button type="button" class="pet-btn pet-btn-primary pet-chain-run" data-chain-run="${$(t.id)}">播放</button>
        <button type="button" class="pet-btn pet-chain-del" data-chain-del="${n}">删除</button>
      </div>
      <div class="pet-chain-summary">${$(p)}</div>
      <div class="pet-chain-steps">${o}</div>
      <button type="button" class="pet-btn" data-chain-step-add="${n}">添加步骤</button>
    </div>`;
    }).join(""), pi(e);
  }
}
async function as() {
  const e = N().model.trim();
  if (!e) {
    U = [], vt();
    return;
  }
  U = await tn(e), vt(), qt(), si(U.length ? `共 ${U.length} 条动作链。` : "");
}
async function Bt() {
  const e = N().model.trim();
  if (e)
    try {
      await ur(e, U);
    } catch (t) {
      si("保存动作链失败：" + (t instanceof Error ? t.message : String(t)));
    }
}
function li(e, t, n) {
  !U[e] || !Number.isInteger(t) || (async () => {
    const o = await oi(n), p = U[e];
    if (!p) return;
    const b = p.steps.map(
      (v, _) => _ === t ? { ...v, file: n, ...o !== null ? { loopSec: o } : {} } : v
    );
    U = U.map((v, _) => _ === e ? { ...v, steps: b } : v), vt(), Bt();
  })();
}
function is(e, t, n) {
  const a = e ? `[data-bar-chain="${CSS.escape(e)}"][data-bar-idx="${t}"]` : `.pet-mo-row [data-bar-idx="${t}"]`;
  document.querySelectorAll(a).forEach((o) => {
    const p = o.querySelector("i");
    p && (p.style.width = n === null ? "0%" : `${Math.round(n * 100)}%`);
  });
}
async function rs(e) {
  const t = await ta(e);
  if (!t.parameters.length) return null;
  const n = t.parameters.map((a) => {
    const o = t.parameterRanges[a], p = o && Number.isFinite(o.def) ? o.def : 0;
    return { Target: "Parameter", Id: a, Segments: [0, p, 0, 1, p] };
  });
  return JSON.stringify(
    {
      Version: 3,
      Meta: {
        Duration: 1,
        Fps: 30,
        Loop: !0,
        AreBeziersRestricted: !0,
        CurveCount: n.length,
        TotalSegmentCount: n.length,
        TotalPointCount: n.length * 2,
        UserDataCount: 0,
        TotalUserDataSize: 0
      },
      Curves: n,
      UserData: []
    },
    null,
    2
  );
}
function ss(e) {
  switch (e) {
    case "motion":
      return { type: "motion", group: "", index: 0 };
    case "chain":
      return { type: "chain", id: "" };
    case "param":
      return { type: "param", id: "", value: 0, mode: "set" };
    case "artmesh":
      return { type: "artmesh", id: "", value: 0 };
    case "artmeshColor":
      return { type: "artmeshColor", id: "", color: "#ffffff" };
    case "part":
      return { type: "part", id: "", value: 0 };
    case "physics":
      return { type: "physics", enabled: !1 };
    default:
      return { type: "expression", target: "", mode: "set" };
  }
}
function ci(e, t, n) {
  const a = () => Number(n) || 0;
  e.type === "motion" ? t === "group" ? e.group = n : t === "index" && (e.index = Math.max(0, Math.round(a()))) : e.type === "chain" ? t === "id" && (e.id = n) : e.type === "expression" ? t === "target" ? (e.target = n, e.file = Gt.expressionFiles[n] || "") : t === "mode" && (e.mode = n === "clear" ? "clear" : "set") : e.type === "param" ? t === "id" ? e.id = n : t === "mode" ? e.mode = n === "add" ? "add" : "set" : t === "value" && (e.value = a()) : e.type === "artmesh" ? t === "id" ? e.id = n : t === "value" && (e.value = Math.min(1, Math.max(0, a()))) : e.type === "artmeshColor" ? t === "id" ? e.id = n : t === "color" && (e.color = ea(n)) : e.type === "part" ? t === "id" ? e.id = n : t === "value" && (e.value = Math.min(1, Math.max(0, a()))) : e.type === "physics" && t === "enabled" && (e.enabled = n === "1");
}
function ea(e) {
  const t = (e || "").trim().replace(/^#/, "").toLowerCase();
  return /^[0-9a-f]{3}$/.test(t) ? "#" + t.split("").map((n) => n + n).join("") : /^[0-9a-f]{6}$/.test(t) ? "#" + t : "#ffffff";
}
function os(e) {
  const t = ea(e).slice(1);
  return {
    r: parseInt(t.slice(0, 2), 16) / 255,
    g: parseInt(t.slice(2, 4), 16) / 255,
    b: parseInt(t.slice(4, 6), 16) / 255
  };
}
function De(e, t) {
  const n = t && !e.includes(t) ? [t, ...e] : e;
  return (n.length ? n : [""]).map((o) => `<option value="${$(o)}"${o === t ? " selected" : ""}>${$(o || "（无可用项）")}</option>`).join("");
}
function ls(e, t) {
  const n = t && !e.includes(t) ? [t, ...e] : e;
  return (n.length ? n : [""]).map((o) => ({ value: o, label: o || "（无可用项）", selected: o === t }));
}
function pi(e) {
  e.querySelectorAll(".custom-select").forEach((t) => {
    gr(t, {
      scope: document,
      onPick: (n) => {
        const a = t.closest(".pet-hk-row");
        if (a) {
          const p = gt.find((v) => v.id === a.dataset.hkId);
          if (!p) return;
          const b = t.getAttribute("data-hk-field");
          b === "type" ? (p.action = ss(n), qt(), je()) : b === "target" && (ci(p.action, "target", n), je());
          return;
        }
        const o = t.getAttribute("data-chain-step-file");
        if (o) {
          const [p, b] = o.split(":").map((v) => Number.parseInt(v, 10));
          li(p, b, n);
        }
      }
    });
  });
}
function qt() {
  const e = document.getElementById("pet-hk-list");
  e && (e.innerHTML = gt.map((t) => {
    const n = t.action, a = Xi.map(
      (p) => ({ value: p, label: jr[p], selected: p === n.type })
    );
    let o = "";
    if (n.type === "motion")
      o = `<select data-hk-field="group">${De(Gt.motions.map((p) => p.group), n.group)}</select><input class="pet-hk-num" data-hk-field="index" inputmode="numeric" value="${n.index}">`;
    else if (n.type === "expression")
      o = Rn("", ls(Gt.expressions, n.target), 'data-hk-field="target" title="表情对象（模型可用的表情）"');
    else if (n.type === "chain") {
      const p = U.map((b) => ({ id: b.id, name: b.name }));
      n.id && !p.some((b) => b.id === n.id) && p.unshift({ id: n.id, name: "（已删除的动作链）" }), o = p.length ? `<select data-hk-field="id">${p.map((b) => `<option value="${$(b.id)}"${b.id === n.id ? " selected" : ""}>${$(b.name || b.id)}</option>`).join("")}</select>` : '<span class="pet-hk-target">（还没有动作链）</span>';
    } else n.type === "param" ? o = `<select data-hk-field="id">${De(Gt.parameters, n.id)}</select><select data-hk-field="mode"><option value="set"${n.mode === "set" ? " selected" : ""}>设为</option><option value="add"${n.mode === "add" ? " selected" : ""}>加</option></select><input class="pet-hk-num" data-hk-field="value" inputmode="decimal" value="${n.value}">` : n.type === "artmesh" ? o = `<select data-hk-field="id">${De(Gt.drawables, n.id)}</select><input class="pet-hk-num" data-hk-field="value" inputmode="decimal" value="${n.value}">` : n.type === "artmeshColor" ? o = `<select data-hk-field="id">${De(Gt.drawables, n.id)}</select><input class="pet-hk-color" type="color" data-hk-field="color" value="${$(ea(n.color))}" title="点一下选颜色（原色 = #ffffff）">` : n.type === "part" ? o = `<select data-hk-field="id">${De(Gt.parts, n.id)}</select><input class="pet-hk-num" data-hk-field="value" inputmode="decimal" value="${n.value}">` : o = `<select data-hk-field="enabled"><option value="1"${n.enabled ? " selected" : ""}>开</option><option value="0"${n.enabled ? "" : " selected"}>关</option></select>`;
    return `<div class="pet-hk-row" data-hk-id="${$(t.id)}">
        <input class="pet-hk-name" data-hk-field="name" spellcheck="false" value="${$(t.name)}">
        ${Rn("", a, 'data-hk-field="type"')}
        ${o}
        <button type="button" class="pet-btn pet-btn-toggle pet-hk-run${ye.has(t.id) ? " on" : ""}" data-hk-run="1" aria-pressed="${ye.has(t.id) ? "true" : "false"}">${ye.has(t.id) ? "开" : "关"}</button>
        <button type="button" class="pet-btn pet-hk-del" data-hk-del="1">删除</button>
      </div>`;
  }).join(""), pi(e));
}
async function In() {
  const e = N().model.trim();
  if (!e) {
    gt = [], qt(), Nt("先选一个 Live2D 模型 —— 热键要跟它存在同一个文件夹里。");
    return;
  }
  const t = await ta(e);
  if (Gt = await Un(e, t), gt = await ge(e), ii(gt))
    try {
      await hn(e, gt);
    } catch {
    }
  qt(), Nt(
    t.parameters.length || t.drawables.length ? "" : "提示：先在主界面「显示桌宠」一次，才能拿到该模型的参数 / ArtMesh / Part 清单（现在只有动作、表情、物理可选）。"
  );
}
function cs(e) {
  return `
<div class="pet-console">
  <div class="pet-row pet-row-main">
    <button id="pet-toggle" class="pet-btn pet-btn-primary">显示桌宠</button>
    <button id="pet-change" class="pet-btn">更换模型…</button>
    <button id="pet-clear" class="pet-btn" ${!!e.model.trim() || !!e.image.trim() ? "" : "hidden"}>取消配置</button>
    <button type="button" id="pet-through" class="pet-btn pet-btn-toggle${e.clickThrough ? " on" : ""}" aria-pressed="${e.clickThrough ? "true" : "false"}">${$(bn(e.clickThrough))}</button>
  </div>
  <div class="pet-row">
    <span class="pet-label">形象大小</span>
    <input type="range" id="pet-scale" class="pet-range" min="40" max="800" step="5" value="${Math.round(e.scale * 100)}">
    <span class="pet-val" id="pet-scale-val">${Math.round(e.scale * 100)}%</span>
  </div>
  <div class="pet-row">
    <span class="pet-label">旋转角度</span>
    <input type="range" id="pet-rot" class="pet-range" min="-180" max="180" step="1" value="${Math.round(e.rotation)}">
    <span class="pet-val" id="pet-rot-val">${Math.round(e.rotation)}°</span>
  </div>
  <div class="pet-file" id="pet-file"></div>
  <div class="pet-note">该插件只提供 Live2D 模型入口。</div>
  <div class="pet-note">${h("pet.hint_interactions")}</div>
  <div class="pet-tabs" id="pet-tabs">
    <button type="button" class="pet-tab on" data-pet-tab="debug">${$(h("pet.debug_title"))}</button>
    <button type="button" class="pet-tab" data-pet-tab="hotkey">${$(h("pet.hotkey_title"))}</button>
    <button type="button" class="pet-tab" data-pet-tab="motion">${$(h("pet.motions_title"))}</button>
    <button type="button" class="pet-tab" data-pet-tab="proactive">${$(h("pet.proactive_title"))}</button>
    <button type="button" class="pet-tab" data-pet-tab="voice">${$(h("pet.tts_title"))}</button>
    <button type="button" class="pet-tab" data-pet-tab="persona">${$(h("pet.persona_title"))}</button>
  </div>
  <div class="pet-tabpage" data-pet-page="debug">
    <div class="pet-row pet-reset-row">
      <button type="button" id="pet-reset-debug" class="pet-btn" title="把该模型调过的参数全部恢复默认（会清掉你的调整）">恢复默认</button>
    </div>
    <div class="pet-debug" id="pet-debug">
      <div class="pet-debug-note" id="pet-debug-note" hidden></div>
      <div class="pet-debug-body" id="pet-debug-body"></div>
    </div>
  </div>
  <div class="pet-tabpage" data-pet-page="hotkey" hidden>
    <div class="pet-row pet-reset-row">
      <button type="button" id="pet-reset-hotkeys" class="pet-btn" title="清空当前热键表（可再点「重新导入」重建）">恢复默认</button>
    </div>
    ${Vr()}
  </div>
  <div class="pet-tabpage" data-pet-page="motion" hidden>
    <div class="pet-row pet-reset-row">
      <button type="button" id="pet-reset-motions" class="pet-btn" title="删掉本模型文件夹里由本插件生成的 *.motion3.json">恢复默认</button>
    </div>
    ${Ur()}
  </div>
  <!-- 三个新分页（2026-10-13）：把原先散在页签之外的三块控件搬进来。
       迁移只挪节点、接线（事件委托 / 落盘）原样复用，语义不分叉。 -->
  <div class="pet-tabpage" data-pet-page="proactive" hidden>
    ${zr(e)}
  </div>
  <div class="pet-tabpage" data-pet-page="voice" hidden>
    ${Hr(e)}
  </div>
  <div class="pet-tabpage" data-pet-page="persona" hidden>
    <div class="pet-persona" id="pet-persona">
      <div class="pet-debug-title">${h("pet.persona_core_title")}</div>
      <div class="pet-note">${h("pet.persona_hint")}</div>
      <textarea id="pet-persona-text" class="pet-persona-text" rows="6" spellcheck="false" maxlength="8000" placeholder=""></textarea>
      <div class="pet-row pet-persona-actions">
        <button type="button" id="pet-persona-save" class="pet-btn pet-btn-primary">${h("settings.persona_save")}</button>
        <button type="button" id="pet-persona-clear" class="pet-btn">${h("pet.persona_clear")}</button>
        <button type="button" id="pet-persona-restart" class="pet-btn">${h("settings.persona_restart")}</button>
      </div>
      <div class="pet-note" id="pet-persona-msg"></div>
    </div>
    <!-- 事实记忆 = ModuleDatamemorypetMEMORY.md（AI 经 Remember 写） -->
    <div class="pet-list" id="pet-memory">
      <div class="pet-debug-title">${h("pet.memory_title")}</div>
      <div class="pet-note">${h("pet.memory_desc")}</div>
      <div class="pet-list-items" id="pet-memory-items"></div>
      <div class="pet-row">
        <button type="button" id="pet-memory-clear" class="pet-btn pet-list-clear" data-pet-clear="memory" data-armed-text="${$(h("pet.list_clear_armed"))}">${$(h("pet.list_clear"))}</button>
      </div>
      <div class="pet-note" id="pet-memory-msg"></div>
    </div>
    <!-- 成长笔记 = ModuleDatamemorypetGROWTH.md（AI 经 PetGrowth 写）—— 与上面那份**不是一个文件** -->
    <div class="pet-list" id="pet-growth">
      <div class="pet-debug-title">${h("pet.growth_title")}</div>
      <div class="pet-note">${h("pet.growth_desc")}</div>
      <div class="pet-list-items" id="pet-growth-items"></div>
      <div class="pet-row">
        <button type="button" id="pet-growth-clear" class="pet-btn pet-list-clear" data-pet-clear="growth" data-armed-text="${$(h("pet.list_clear_armed"))}">${$(h("pet.list_clear"))}</button>
      </div>
      <div class="pet-note" id="pet-growth-msg"></div>
    </div>
    <!-- 人格建议 = ModuleDatamemorypetPERSONA_SUGGESTIONS.md；「接受」= 事前确认后并入核心
         人格，「清空」= 只丢弃建议（不写核心人格）-->
    <div class="pet-list" id="pet-suggest">
      <div class="pet-debug-title">${h("pet.suggest_title")}</div>
      <div class="pet-note">${h("pet.suggest_desc")}</div>
      <div class="pet-list-items" id="pet-suggest-items"></div>
      <div class="pet-row">
        <button type="button" id="pet-suggest-clear" class="pet-btn pet-list-clear" data-pet-clear="suggest" data-armed-text="${$(h("pet.suggest_clear_armed"))}">${$(h("pet.list_clear"))}</button>
      </div>
      <div class="pet-note" id="pet-suggest-msg"></div>
    </div>
  </div>
</div>`;
}
function ui() {
  if (document.getElementById("pet-style")) return;
  const e = document.createElement("style");
  e.id = "pet-style", e.textContent = ds, document.head.appendChild(e);
}
async function ps(e) {
  const t = (i) => e.querySelector(`#${i}`);
  let n = null;
  const a = (i, l) => void d("log_frontend", {
    level: "error",
    message: `[pet console] ${i}: ${l instanceof Error ? l.message : String(l)}`
  }).catch(() => {
  }), o = (i = "") => {
    Jt();
    const l = N(), m = l.model.trim(), f = l.image.trim(), C = t("pet-clear");
    C && (C.hidden = !(m || f));
    const T = t("pet-file");
    if (!T) return;
    const A = i ? `<br><span class="pet-dim">${$(i)}</span>` : "";
    m ? T.innerHTML = `当前用 Live2D 模型：<code>${$(m)}</code>${A}` : f ? T.innerHTML = `当前用图片：<code>${$(f)}</code>${A}` : T.innerHTML = "还没有模型 —— 点「更换模型」选一个文件夹（里面要有 <code>*.model3.json</code>）。";
  };
  async function p() {
    await d("open_plugin_window", { pluginId: "pet", key: null, input: "" });
  }
  const b = (i) => {
    const l = t("pet-toggle");
    l && (l.textContent = i ? "隐藏模型" : "显示桌宠");
  }, v = (i) => {
    const l = t("pet-through");
    l && (l.textContent = bn(i), l.classList.toggle("on", i), l.setAttribute("aria-pressed", i ? "true" : "false"));
  }, _ = () => new Promise((i) => {
    const l = `p${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
    let m = !1;
    const f = (T) => {
      m || (m = !0, C.then((A) => A()).catch(() => {
      }), i(T));
    }, C = ft(H, (T) => {
      var A, y;
      ((A = T.payload) == null ? void 0 : A.type) === "pong" && ((y = T.payload) == null ? void 0 : y.token) === l && f({ alive: !0, visible: T.payload.visible !== !1 });
    });
    C.then(() => q(H, { type: "ping", token: l })).catch(() => {
    }), setTimeout(() => f({ alive: !1, visible: !1 }), 400);
  }), x = async () => (await _()).alive, L = () => void _().then((i) => b(i.alive && i.visible)), E = setInterval(L, 3e3);
  let Z = null, it = null;
  const B = (i, l) => {
    if (Z = { id: i, value: l }, it) return;
    const m = () => {
      it = null;
      const f = Z;
      if (Z = null, f) {
        const C = N().model.trim();
        C && xe(C, f.id, f.value), q(H, { type: "set-param", id: f.id, value: f.value });
      }
    };
    m(), it = setTimeout(m, 50);
  }, tt = async (i) => {
    try {
      const m = await He(i);
      if (m && Object.keys(m.params).length) return m.params;
    } catch {
    }
    const l = N().params[i];
    return l && typeof l == "object" ? l : {};
  };
  let K = null, D = null;
  const W = () => {
    K = null;
    const i = D;
    D = null, i && (async () => {
      try {
        const l = await He(i) ?? qn(i), m = N().params[i];
        l.params = m && typeof m == "object" ? { ...m } : {}, await an(i, l);
      } catch (l) {
        console.warn("[pet] 写 lunac.params.json 失败", l);
      }
    })();
  }, we = (i) => {
    D = i, !K && (K = setTimeout(W, 400));
  }, xe = (i, l, m) => {
    const f = N(), C = { ...f.params };
    C[i] = { ...C[i] ?? {}, [l]: m }, X({ ...f, params: C }), we(i);
  }, at = async (i) => {
    const l = await tt(i);
    for (const m of Oe.keys()) {
      const f = typeof l[m] == "number" ? l[m] : 0, C = e.querySelector(`.pet-range[data-param="${m}"]`);
      C && (C.value = String(f));
      const T = e.querySelector(`[data-param-val="${m}"]`);
      T && (T.value = String(f));
      const A = e.querySelector(`[data-param-sw="${m}"]`);
      if (A) {
        const y = f >= 0.5;
        A.classList.toggle("on", y), A.setAttribute("aria-pressed", y ? "true" : "false"), A.textContent = y ? "开" : "关";
      }
    }
  }, ht = (i) => {
    const l = i.dataset.paramVal;
    if (!l) return;
    const m = Oe.get(l);
    if (!m) return;
    const f = e.querySelector(`.pet-range[data-param="${l}"]`), C = Number.parseFloat(i.value.trim());
    if (!Number.isFinite(C)) {
      i.value = (f == null ? void 0 : f.value) ?? "0";
      return;
    }
    const T = Math.round(Math.min(m.max, Math.max(m.min, C)) * 1e3) / 1e3;
    i.value = String(T), f && (f.value = String(T)), B(l, T);
  }, ct = () => {
    const i = N().proactive;
    q(H, {
      type: "set-proactive",
      enabled: i.enabled,
      intervalMin: i.intervalMin,
      dailyCap: i.dailyCap,
      autoShot: i.autoShot,
      autoShotMin: i.autoShotMin,
      screenWatch: i.screenWatch,
      screenWatchSec: i.screenWatchSec,
      screenDiff: i.screenDiff
    });
  }, wt = () => {
    const i = t("pet-proactive-usage");
    if (!i) return;
    const l = N().proactive, m = Ut(), f = h("pet.proactive_usage", { used: String(m), cap: String(l.dailyCap) });
    i.textContent = m >= l.dailyCap ? `${f} · ${h("pet.proactive_reached")}` : f;
  }, Ot = (i) => {
    const l = N(), m = Number.parseInt(i.value.trim(), 10);
    if (!Number.isFinite(m)) {
      i.value = String(l.proactive.dailyCap);
      return;
    }
    const f = Math.min(Qn, Math.max(Zn, m));
    i.value = String(f), X({ ...l, proactive: { ...l.proactive, dailyCap: f } }), ct(), wt();
  }, Pt = (i) => {
    const l = N(), m = Number.parseInt(i.value.trim(), 10);
    if (!Number.isFinite(m)) {
      i.value = String(l.proactive.intervalMin);
      return;
    }
    const f = Math.min(Jn, Math.max(Kn, m));
    i.value = String(f), X({ ...l, proactive: { ...l.proactive, intervalMin: f } }), ct();
  }, mt = (i, l, m, f, C) => {
    const T = N(), A = Number.parseInt(i.value.trim(), 10);
    if (!Number.isFinite(A)) {
      i.value = String(l(T.proactive));
      return;
    }
    const y = Math.min(f, Math.max(m, A));
    i.value = String(y), X({ ...T, proactive: C(T.proactive, y) }), ct();
  }, Be = "pet-agent-restart", Dt = "pet-agent-restart-done", rt = h("settings.persona_saved"), le = h("pet.persona_cleared"), _e = h("pet.persona_restarting"), xt = (i) => {
    const l = t("pet-persona-msg");
    l && (l.textContent = i);
  }, ke = async () => {
    try {
      const i = await d("get_pet_persona"), l = t("pet-persona-text");
      l && (i != null && i.maxChars && (l.maxLength = i.maxChars), l.value = (i == null ? void 0 : i.text) ?? "");
    } catch (i) {
      a("读取桌宠人格失败", i);
    }
  }, Se = async (i, l) => {
    try {
      await d("set_pet_persona", { text: i }), xt(l + h("pet.persona_effective"));
    } catch (m) {
      xt(h("settings.persona_failed", { err: String(m) }));
    }
  }, pt = {
    memory: { get: "get_pet_memory", del: "delete_pet_memory_note", clear: "clear_pet_memory", cleared: "pet.memory_cleared", merge: !1, items: "pet-memory-items", msg: "pet-memory-msg" },
    growth: { get: "get_pet_growth", del: "delete_pet_growth_note", clear: "clear_pet_growth", cleared: "pet.growth_cleared", merge: !1, items: "pet-growth-items", msg: "pet-growth-msg" },
    suggest: { get: "get_persona_suggestions", del: "delete_persona_suggestion", clear: "clear_persona_suggestions", cleared: "pet.suggest_cleared", merge: !0, items: "pet-suggest-items", msg: "pet-suggest-msg" }
  }, Ft = (i, l, m = !1) => {
    const f = t(pt[i].msg);
    f && (f.className = m ? "pet-note pet-bad" : "pet-note", f.textContent = l);
  }, ce = (i, l) => {
    if (i.dataset.armed === "1") {
      delete i.dataset.armed, i.textContent = i.dataset.armedRestore ?? i.textContent, delete i.dataset.armedRestore, l();
      return;
    }
    i.dataset.armedRestore = i.textContent ?? "", i.dataset.armed = "1";
    const m = i.dataset.armedText;
    m && (i.textContent = m), window.setTimeout(() => {
      i.dataset.armed === "1" && (delete i.dataset.armed, i.textContent = i.dataset.armedRestore ?? i.textContent, delete i.dataset.armedRestore);
    }, 4e3);
  }, Ve = (i, l) => {
    const m = t(pt[i].items);
    if (!m) return;
    const f = document.createDocumentFragment();
    if (!l.length) {
      const C = document.createElement("div");
      C.className = "pet-list-empty", C.textContent = h(`pet.${i}_empty`), f.appendChild(C), m.replaceChildren(f);
      return;
    }
    for (const C of l) {
      const T = document.createElement("div");
      T.className = "pet-list-row";
      const A = document.createElement("div");
      A.className = "pet-list-text", A.textContent = C, T.appendChild(A);
      const y = document.createElement("div");
      if (y.className = "pet-list-acts", pt[i].merge) {
        const j = document.createElement("button");
        j.type = "button", j.className = "pet-btn pet-suggest-accept", j.dataset.petMerge = C, j.dataset.armedText = h("pet.suggest_accept_armed"), j.textContent = h("pet.suggest_accept"), y.appendChild(j);
      }
      const I = document.createElement("button");
      I.type = "button", I.className = "pet-btn pet-list-del", I.dataset.petDel = C, I.dataset.petList = i, I.dataset.armedText = h("pet.item_del_armed"), I.textContent = h("pet.item_del"), y.appendChild(I), T.appendChild(y), f.appendChild(T);
    }
    m.replaceChildren(f);
  }, _t = async (i) => {
    try {
      const l = await d(pt[i].get);
      Ve(i, l.entries ?? []);
    } catch (l) {
      a(`读取列表失败（${i}）`, l);
      const m = t(pt[i].items);
      if (m) {
        const f = document.createElement("div");
        f.className = "pet-list-empty pet-bad", f.textContent = h("pet.list_load_fail"), m.replaceChildren(f);
      }
    }
  }, Yt = async (i, l) => {
    try {
      await d(pt[i].del, { text: l }), Ft(i, ""), await _t(i);
    } catch (m) {
      a(`删除列表条目失败（${i}）`, m), Ft(i, h("pet.list_fail"), !0);
    }
  }, pe = async (i) => {
    const l = pt[i].clear;
    if (l)
      try {
        await d(l), Ft(i, h(pt[i].cleared)), await _t(i);
      } catch (m) {
        a(`清空列表失败（${i}）`, m), Ft(i, h("pet.list_fail"), !0);
      }
  }, Me = async (i) => {
    try {
      await d("merge_persona_suggestion", { text: i }), await ke(), await _t("suggest"), Ft("suggest", h("pet.suggest_accepted"));
    } catch (l) {
      a("合并人格建议失败", l), Ft("suggest", h("pet.merge_fail"), !0);
    }
  }, kt = (i) => {
    const l = t("pet-debug-note");
    l && (l.textContent = i, l.hidden = !i);
  };
  let Kt = "";
  const yn = (i, l) => {
    const m = N(), f = { ...m.expressions };
    l ? f[i] = l : delete f[i], X({ ...m, expressions: f });
  }, St = () => {
    const i = t("pet-exprs");
    i && i.querySelectorAll("[data-expr]").forEach((l) => {
      l.classList.toggle("on", !!Kt && l.dataset.expr === Kt);
    });
  }, Ce = (i) => {
    Kt = i, St();
    const l = N().model.trim();
    l && yn(l, i), q(H, { type: "set-expression", id: i });
  }, $e = (i, l) => {
    const m = An.find((J) => J.id === i), f = l.range ? l.range.min : m ? m.min : -100, C = l.range ? l.range.max : m ? m.max : 100, T = C - f, A = T <= 2 ? 0.01 : T <= 20 ? 0.1 : 1;
    Oe.set(i, { min: f, max: C });
    const y = m ? h(m.labelKey) : l.friendly || i, I = l.physIn ? `<span class="pet-phys-tag">${$(h("pet.debug_phys_in"))}</span>` : l.physOut ? `<span class="pet-phys-tag">${$(h("pet.debug_phys_out"))}</span>` : "", j = `<button type="button" class="pet-param-kind" data-param-kind="${$(i)}" data-kind="${l.isSwitch ? "switch" : "range"}" title="切换控件形态（开关 / 拉条）">${Br}</button>`;
    return l.isSwitch ? `<div class="pet-param">
        <span class="pet-label" title="${$(i)}">${$(y)}${I}</span>
        <input type="range" class="pet-range" data-param="${$(i)}" min="0" max="1" step="1" value="0" hidden>
        <button type="button" class="pet-btn pet-btn-toggle pet-param-on" data-param-sw="${$(i)}" aria-pressed="false">关</button>
        ${j}
      </div>` : `<div class="pet-param">
      <span class="pet-label" title="${$(i)}">${$(y)}${I}</span>
      <input type="range" class="pet-range" data-param="${$(i)}" min="${f}" max="${C}" step="${A}" value="0">
      <input type="text" class="pet-param-num" data-param-val="${$(i)}" inputmode="decimal" autocomplete="off" spellcheck="false" value="0" aria-label="${$(i)}">
      ${j}
    </div>`;
  };
  async function Jt() {
    const i = N(), l = !!i.model.trim(), m = t("pet-debug-body");
    if (m == null || m.classList.toggle("off", !l), !l || !m) {
      kt(h("pet.debug_need_model"));
      return;
    }
    const f = i.model.trim(), C = await ta(f), T = await Aa(f), A = T.cdi3 ? await nr(T.cdi3) : Kr;
    let y = null;
    try {
      y = await Un(f, C);
    } catch {
      y = null;
    }
    const I = new Set((y == null ? void 0 : y.physicsInputs) ?? []), j = new Set((y == null ? void 0 : y.physicsOutputs) ?? []), J = [], Y = (O) => {
      O && !J.includes(O) && J.push(O);
    }, z = C.parameters.length ? C.parameters : An.map((O) => O.id);
    for (const O of An) z.includes(O.id) && Y(O.id);
    for (const O of z) Y(O);
    const u = await Yr(f), k = new Set(T.vtube ? await er(T.vtube) : []), M = J.filter((O) => !u.has(O) && !k.has(O)), c = i.paramKinds[f] ?? {}, w = await Jr(f, T.dir), F = (O) => {
      const nt = c[O];
      if (nt) return nt === "switch";
      const st = C.parameterRanges[O];
      if (!st || st.min !== 0 || st.max !== 1) return !1;
      const zt = w.get(O);
      if (!zt || !zt.size) return !0;
      for (const Ne of zt) if (Ne !== 0 && Ne !== 1) return !1;
      return !0;
    };
    Oe = /* @__PURE__ */ new Map(), m.innerHTML = M.map(
      (O) => $e(O, {
        range: C.parameterRanges[O],
        physIn: I.has(O),
        physOut: j.has(O),
        friendly: A.parameters[O] ?? "",
        isSwitch: F(O)
      })
    ).join(""), await at(f), kt(await x() ? "" : h("pet.debug_pet_closed"));
  }
  const vn = async () => {
    const i = N(), l = i.model.trim();
    if (!l) return;
    const m = { ...i.params };
    delete m[l], X({ ...i, params: m });
    try {
      const f = await He(l);
      f && (f.params = {}, await an(l, f));
    } catch (f) {
      console.warn("[pet] 清 lunac.params.json 的 params 失败", f);
    }
    q(H, { type: "reset-params", ids: [...Oe.keys()] }), await at(l), kt("参数已恢复默认。");
  }, Rt = () => {
    const i = N().model.trim();
    i && (gt = [], ye = /* @__PURE__ */ new Set(), qt(), hn(i, []).catch((l) => a("清空热键失败", l)), Nt("已清空热键表。"));
  }, ue = () => {
    (async () => {
      const i = N().model.trim();
      if (!i) return;
      const l = lt.filter((f) => f.name.toLowerCase().startsWith(Na));
      if (!l.length) {
        At("没有本插件生成的动作文件（只删 lunac_ 开头的）。");
        return;
      }
      let m = 0;
      for (const f of l)
        try {
          await d("delete_motion_file", { modelPath: i, name: f.path.split(/[\\/]/).pop() || "" }), m++;
        } catch (C) {
          a("删除动作文件失败", C);
        }
      await Pe(), La(), q(H, { type: "reload" }), At(`已删除 ${m} 个生成的动作文件。`);
    })();
  }, Lt = "__lunacPetConsoleDelegate", Mt = e;
  if (!Mt[Lt]) {
    Mt[Lt] = !0;
    const i = (z) => {
      var M;
      const u = z.target;
      if (!u) return;
      const k = u.closest("[data-pet-tab]");
      if (k) {
        const c = k.dataset.petTab;
        e.querySelectorAll(".pet-tab").forEach((w) => {
          w.classList.toggle("on", w.dataset.petTab === c);
        }), e.querySelectorAll(".pet-tabpage").forEach((w) => {
          w.hidden = w.dataset.petPage !== c;
        });
        return;
      }
      if (u.closest("#pet-toggle"))
        (async () => {
          const c = await _();
          if (c.alive && c.visible) {
            q(H, { type: "hide" }).catch((F) => a("隐藏模型失败", F)), b(!1);
            return;
          }
          if (c.alive) {
            q(H, { type: "show" }).catch((F) => a("显示模型失败", F)), b(!0), Jt();
            return;
          }
          const w = N();
          !w.model.trim() && !w.image.trim() && !await Te() || (await p(), b(!0), Jt());
        })().catch((c) => a("显示桌宠失败", c));
      else if (u.closest("#pet-change"))
        Te().catch((c) => a("更换形象失败", c));
      else if (u.closest("#pet-clear"))
        X({ ...N(), model: "", image: "" }), o(), q(H, { type: "reload" }), In(), Pe();
      else if (u.closest("#pet-through")) {
        const c = !N().clickThrough;
        X({ ...N(), clickThrough: c }), v(c), q(H, { type: "set-click-through", value: c });
      } else if (u.closest("#pet-proactive-enabled")) {
        const c = u.closest("#pet-proactive-enabled");
        if (!c) return;
        const w = !c.classList.contains("on"), F = N();
        X({ ...F, proactive: { ...F.proactive, enabled: w } }), c.classList.toggle("on", w), c.setAttribute("aria-pressed", w ? "true" : "false"), c.textContent = be(w), ct(), wt();
      } else if (u.closest("#pet-autoshot-enabled")) {
        const c = u.closest("#pet-autoshot-enabled");
        if (!c) return;
        const w = !c.classList.contains("on"), F = N();
        X({ ...F, proactive: { ...F.proactive, autoShot: w } }), c.classList.toggle("on", w), c.setAttribute("aria-pressed", w ? "true" : "false"), c.textContent = be(w), ct();
      } else if (u.closest("#pet-screenwatch-enabled")) {
        const c = u.closest("#pet-screenwatch-enabled");
        if (!c) return;
        const w = !c.classList.contains("on"), F = N();
        X({ ...F, proactive: { ...F.proactive, screenWatch: w } }), c.classList.toggle("on", w), c.setAttribute("aria-pressed", w ? "true" : "false"), c.textContent = be(w), ct();
      } else if (u.closest("#pet-tts-enabled")) {
        const c = u.closest("#pet-tts-enabled");
        if (!c) return;
        const w = !c.classList.contains("on");
        X({ ...N(), tts: w }), c.classList.toggle("on", w), c.setAttribute("aria-pressed", w ? "true" : "false"), c.textContent = Za("pet.tts_enable", w);
      } else if (u.closest("#pet-tts-addfile"))
        Ge().catch((c) => a("导入参考音色失败", c));
      else if (u.closest("#pet-tts-preview"))
        Ct();
      else if (u.closest("[data-param-sw]")) {
        if ((M = t("pet-debug-body")) != null && M.classList.contains("off")) return;
        const c = u.closest("[data-param-sw]"), w = (c == null ? void 0 : c.dataset.paramSw) ?? "";
        if (!c || !w) return;
        const F = !c.classList.contains("on");
        c.classList.toggle("on", F), c.setAttribute("aria-pressed", F ? "true" : "false"), c.textContent = F ? "开" : "关";
        const O = e.querySelector(`.pet-range[data-param="${w}"]`);
        O && (O.value = F ? "1" : "0"), B(w, F ? 1 : 0);
      } else if (u.closest("[data-param-kind]")) {
        const c = u.closest("[data-param-kind]"), w = (c == null ? void 0 : c.dataset.paramKind) ?? "", F = N().model.trim();
        if (!c || !w || !F) return;
        const O = N(), nt = { ...O.paramKinds }, st = c.dataset.kind === "switch" ? "switch" : "range";
        nt[F] = { ...nt[F] ?? {}, [w]: st === "switch" ? "range" : "switch" }, X({ ...O, paramKinds: nt }), Jt();
      } else if (u.closest("#pet-persona-save")) {
        const c = t("pet-persona-text");
        Se((c == null ? void 0 : c.value) ?? "", rt).catch((w) => a("保存桌宠人格失败", w));
      } else if (u.closest("#pet-persona-clear")) {
        const c = t("pet-persona-text");
        c && (c.value = ""), Se("", le).catch((w) => a("清空桌宠人格失败", w));
      } else if (u.closest("#pet-persona-restart"))
        xt(_e), q(Be).catch((c) => a("重启 AI 请求失败", c));
      else if (u.closest("[data-pet-merge]")) {
        const c = u.closest("[data-pet-merge]");
        if (!c) return;
        const w = c.dataset.petMerge ?? "";
        ce(c, () => {
          w && Me(w).catch((F) => a("合并人格建议失败", F));
        });
      } else if (u.closest("[data-pet-del]")) {
        const c = u.closest("[data-pet-del]");
        if (!c) return;
        const w = c.dataset.petList, F = c.dataset.petDel ?? "";
        if (!w || !pt[w]) return;
        ce(c, () => {
          F && Yt(w, F).catch((O) => a("删除列表条目失败", O));
        });
      } else if (u.closest("[data-pet-clear]")) {
        const c = u.closest("[data-pet-clear]");
        if (!c) return;
        const w = c.dataset.petClear;
        if (!w || !pt[w]) return;
        ce(c, () => void pe(w).catch((F) => a(`清空列表失败（${w}）`, F)));
      } else if (u.closest("#pet-reset-debug"))
        vn();
      else if (u.closest("#pet-reset-hotkeys"))
        Rt();
      else if (u.closest("#pet-reset-motions"))
        ue();
      else {
        const c = u.closest("[data-expr]");
        if (c) {
          const w = c.dataset.expr ?? "";
          Ce(w && w === Kt ? "" : w);
        }
      }
    }, l = (z) => {
      var k;
      const u = z.target;
      if (u) {
        if (u.id === "pet-proactive-cap") {
          Ot(u);
          return;
        }
        if (u.id === "pet-proactive-interval") {
          Pt(u);
          return;
        }
        if (u.id === "pet-autoshot-min") {
          mt(u, (M) => M.autoShotMin, rn, sn, (M, c) => ({ ...M, autoShotMin: c }));
          return;
        }
        if (u.id === "pet-watch-sec") {
          mt(u, (M) => M.screenWatchSec, on, ln, (M, c) => ({ ...M, screenWatchSec: c }));
          return;
        }
        if (u.id === "pet-watch-diff") {
          mt(u, (M) => M.screenDiff, cn, pn, (M, c) => ({ ...M, screenDiff: c }));
          return;
        }
        if (u.id === "pet-tts-reftext") {
          Ue(u.value).catch((M) => a("保存参考文本失败", M));
          return;
        }
        if (u.matches("[data-param-val]")) {
          if ((k = t("pet-debug-body")) != null && k.classList.contains("off")) return;
          ht(u);
        }
      }
    }, m = (z) => {
      var k;
      const u = z.target;
      if (!(!u || z.key !== "Enter")) {
        if (u.id === "pet-proactive-cap") {
          z.preventDefault(), Ot(u);
          return;
        }
        if (u.id === "pet-proactive-interval") {
          z.preventDefault(), Pt(u);
          return;
        }
        if (u.id === "pet-autoshot-min") {
          z.preventDefault(), mt(u, (M) => M.autoShotMin, rn, sn, (M, c) => ({ ...M, autoShotMin: c }));
          return;
        }
        if (u.id === "pet-watch-sec") {
          z.preventDefault(), mt(u, (M) => M.screenWatchSec, on, ln, (M, c) => ({ ...M, screenWatchSec: c }));
          return;
        }
        if (u.id === "pet-watch-diff") {
          z.preventDefault(), mt(u, (M) => M.screenDiff, cn, pn, (M, c) => ({ ...M, screenDiff: c }));
          return;
        }
        if (u.id === "pet-tts-reftext") {
          z.preventDefault(), Ue(u.value).catch((M) => a("保存参考文本失败", M));
          return;
        }
        u.matches("[data-param-val]") && (z.preventDefault(), !((k = t("pet-debug-body")) != null && k.classList.contains("off")) && ht(u));
      }
    }, f = (z) => {
      var w;
      const u = z.target;
      if (!u) return;
      if (u.id === "pet-scale") {
        const F = Math.round(Number(u.value)) / 100, O = t("pet-scale-val");
        O && (O.textContent = `${Math.round(F * 100)}%`), X({ ...N(), scale: F }), q(H, { type: "set-scale", value: F });
        return;
      }
      if (u.id === "pet-rot") {
        const F = Math.round(Number(u.value)), O = t("pet-rot-val");
        O && (O.textContent = `${F}°`), X({ ...N(), rotation: F }), q(H, { type: "set-rotation", value: F });
        return;
      }
      if (u.id === "pet-tts-rate") {
        const F = gn(Number(u.value)), O = t("pet-tts-rate-val");
        O && (O.textContent = String(F)), X({ ...N(), speechRate: F });
        return;
      }
      if (u.id === "pet-tts-speed") {
        const F = $a(Number(u.value)), O = t("pet-tts-speed-val");
        O && (O.textContent = F.toFixed(1) + "×"), de(F).catch((nt) => a("保存语速失败", nt));
        return;
      }
      if (u.id === "pet-tts-volume") {
        const F = Ea(Number(u.value)), O = t("pet-tts-volume-val");
        O && (O.textContent = Math.round(F * 100) + "%"), Wt(F).catch((nt) => a("保存音量失败", nt));
        return;
      }
      const k = u.dataset.param;
      if (!k || (w = t("pet-debug-body")) != null && w.classList.contains("off")) return;
      const M = Number(u.value), c = e.querySelector(`[data-param-val="${k}"]`);
      c && document.activeElement !== c && (c.value = String(M)), B(k, M);
    };
    e.addEventListener("click", i), e.addEventListener("change", l), e.addEventListener("input", f), e.addEventListener("keydown", m);
    const C = await ft(H, (z) => {
      const u = z.payload;
      if ((u == null ? void 0 : u.type) !== "scale-changed" || typeof u.value != "number") return;
      const k = Math.round(u.value * 100), M = t("pet-scale");
      M && (M.value = String(k));
      const c = t("pet-scale-val");
      c && (c.textContent = `${k}%`);
    }), T = await ft(H, (z) => {
      const u = z.payload;
      if ((u == null ? void 0 : u.type) !== "rotation-changed" || typeof u.value != "number") return;
      const k = Math.round(u.value), M = t("pet-rot");
      M && (M.value = String(k));
      const c = t("pet-rot-val");
      c && (c.textContent = `${k}°`);
    }), A = await ft(H, (z) => {
      const u = z.payload;
      if ((u == null ? void 0 : u.type) !== "motion-progress") return;
      const k = u.p;
      if (e.querySelectorAll(".pet-chain-bar i").forEach((w) => w.style.width = "0%"), !k || typeof k.index != "number" || typeof k.elapsedMs != "number" || typeof k.totalMs != "number" || !(k.totalMs > 0)) return;
      const M = Math.max(0, Math.min(1, k.elapsedMs / k.totalMs)), c = typeof u.chainId == "string" && u.chainId ? u.chainId : null;
      is(c, k.index, M);
    }), y = await ft(H, (z) => {
      var u;
      ((u = z.payload) == null ? void 0 : u.type) === "proactive-used" && wt();
    }), I = await ft(H, (z) => {
      var u;
      ((u = z.payload) == null ? void 0 : u.type) !== "click-through-changed" || typeof z.payload.value != "boolean" || v(z.payload.value);
    }), j = () => {
      e.querySelectorAll(".pet-hk-row").forEach((z) => {
        const u = z.dataset.hkId, k = z.querySelector("[data-hk-run]");
        if (!u || !k) return;
        const M = ye.has(u);
        k.classList.toggle("on", M), k.setAttribute("aria-pressed", M ? "true" : "false"), k.textContent = M ? "开" : "关";
      });
    }, J = await ft(H, (z) => {
      const u = z.payload;
      (u == null ? void 0 : u.type) !== "hotkey-states" || !Array.isArray(u.ids) || (ye = new Set(u.ids.filter((k) => typeof k == "string")), j());
    }), Y = await ft(Dt, (z) => {
      var u;
      xt(((u = z.payload) == null ? void 0 : u.ok) === !1 ? h("pet.persona_restart_failed") : h("pet.persona_restarted"));
    });
    ie = () => {
      e.removeEventListener("click", i), e.removeEventListener("change", l), e.removeEventListener("input", f), e.removeEventListener("keydown", m), C(), T(), A(), y(), I(), J(), Y(), E && clearInterval(E), it && clearTimeout(it), delete Mt[Lt], ie = null;
    };
  }
  function Zt() {
    const i = t("pet-tts-reftext");
    if (n && i && document.activeElement !== i && (i.value = n.config.reference_text), n) {
      const m = t("pet-tts-speed");
      if (m && document.activeElement !== m) {
        const C = $a(n.config.speed);
        m.value = String(C);
        const T = t("pet-tts-speed-val");
        T && (T.textContent = C.toFixed(1) + "×");
      }
      const f = t("pet-tts-volume");
      if (f && document.activeElement !== f) {
        const C = Ea(n.config.volume);
        f.value = String(C);
        const T = t("pet-tts-volume-val");
        T && (T.textContent = Math.round(C * 100) + "%");
      }
    }
    const l = t("pet-tts-status");
    if (l) {
      if (!n) {
        l.textContent = "", l.className = "pet-note";
        return;
      }
      n.available ? (l.textContent = h("pet.tts_status_ready"), l.className = "pet-note pet-tts-ok") : (l.textContent = h("pet.tts_status_not_ready") + " · " + h("pet.tts_reason_" + (n.reason || "no_ref_audio")), l.className = "pet-note");
    }
  }
  async function Ee() {
    try {
      n = await d("get_pet_voice");
    } catch (i) {
      a("读取语音状态失败", i);
    }
    Zt();
  }
  async function de(i) {
    const l = n == null ? void 0 : n.config;
    l && l.speed !== i && (await d("set_pet_voice", { config: { ...l, speed: i } }), n = { ...n, config: { ...l, speed: i } });
  }
  async function Wt(i) {
    const l = n == null ? void 0 : n.config;
    l && l.volume !== i && (await d("set_pet_voice", { config: { ...l, volume: i } }), n = { ...n, config: { ...l, volume: i } });
  }
  async function Ue(i) {
    const l = n == null ? void 0 : n.config;
    !l || l.reference_text === i || (await d("set_pet_voice", { config: { ...l, reference_text: i } }), n = { ...n, config: { ...l, reference_text: i } }, Zt());
  }
  async function Ge() {
    var f;
    const i = t("pet-tts-msg"), l = await Pn({
      multiple: !1,
      directory: !1,
      title: h("pet.tts_import_title"),
      filters: [{ name: h("pet.tts_import_filter"), extensions: ["wav", "mp3", "flac", "ogg", "m4a", "aac", "opus"] }]
    }), m = typeof l == "string" ? l : "";
    if (m)
      try {
        const C = await d("import_pet_voice_audio", { path: m }), T = n == null ? void 0 : n.config, A = ((f = t("pet-tts-reftext")) == null ? void 0 : f.value) ?? (T == null ? void 0 : T.reference_text) ?? "";
        await d("set_pet_voice", {
          config: { ...T ?? { enabled: !0, reference_text: "", num_steps: 8, num_threads: 4, speed: 1, volume: 1 }, reference_audio: C, reference_text: A }
        }), await Ee(), i && (i.textContent = h("pet.tts_import_ok"), i.className = "pet-note");
      } catch (C) {
        i && (i.textContent = h("pet.tts_import_fail") + (C instanceof Error ? C.message : String(C)), i.className = "pet-note pet-bad");
      }
  }
  function Ct() {
    const i = t("pet-tts-msg");
    i && (i.textContent = ""), d("tts_speak", { text: h("pet.tts_preview_text"), enabled: !0 }).catch((l) => {
      const m = l instanceof Error ? l.message : String(l), C = ["disabled", "no_ref_audio", "no_ref_text", "ref_missing", "assets_missing"].includes(m) ? h("pet.tts_reason_" + m) : m;
      i && (i.textContent = C, i.className = "pet-note"), a("试听失败", l);
    });
  }
  Ee();
  async function Te() {
    const i = t("pet-file"), l = await Pn({
      multiple: !1,
      directory: !0,
      title: "选择 Live2D 模型文件夹（里面要有 *.model3.json）"
    }), m = typeof l == "string" ? l : "";
    if (!m) return "";
    i && (i.innerHTML = "正在读取模型文件夹…");
    let f = "", C = "", T = "";
    try {
      const I = await d("scan_model_folder", { dir: m });
      f = (I.model3 ?? [])[0] ?? "", C = (I.vtube ?? [])[0] ?? "", T = (I.cdi3 ?? [])[0] ?? "";
    } catch (I) {
      return i && (i.innerHTML = `<span class="pet-bad">读文件夹失败：${$(I instanceof Error ? I.message : String(I))}</span>`), "";
    }
    if (!f)
      return i && (i.innerHTML = '<span class="pet-bad">这个文件夹里没有 *.model3.json。</span>'), "";
    const A = await Ra(f);
    if (!A.ok)
      return i && (i.innerHTML = `<span class="pet-bad">这个模型用不了：${$(A.reason)}</span>`), "";
    X({ ...N(), model: f, image: "" });
    const y = [];
    try {
      const I = await Vn(m, f, C);
      I && y.push(`热键 ${I} 条`);
    } catch (I) {
      a("读取模型热键失败", I);
    }
    return T && y.push("含 cdi3"), o([A.info, y.join(" · ")].filter(Boolean).join("　")), q(H, { type: "reload" }), In(), Jt(), Pe(), f;
  }
  const Ae = "__lunacPetHotkeyDelegate", fe = e;
  if (!fe[Ae]) {
    fe[Ae] = !0;
    const i = (f) => f.closest(".pet-hk-row"), l = (f) => f ? gt.find((C) => C.id === f.dataset.hkId) : void 0;
    e.addEventListener("click", (f) => {
      const C = f.target;
      if (!C || !C.closest("#pet-hotkeys")) return;
      if (C.closest("#pet-hk-import")) {
        (async () => {
          const y = N().model.trim();
          if (!y) {
            Nt("先选一个 Live2D 模型 —— 「更换形象」里选模型文件夹。");
            return;
          }
          const I = await Aa(y);
          try {
            const j = await Vn(I.dir, y, I.vtube);
            if (!j) {
              Nt("这个模型文件夹里没找到可导入的热键 / 表情。");
              return;
            }
            Nt(`已导入 ${j} 条（${I.vtube ? "取自 vtube.json" : "扫自文件夹"}），已落盘。`), q(H, { type: "reload" });
          } catch (j) {
            Nt("导入失败：" + (j instanceof Error ? j.message : String(j)));
          }
        })();
        return;
      }
      const T = i(C), A = l(T);
      if (!(!T || !A)) {
        if (C.closest("[data-hk-run]")) {
          x().then((y) => {
            if (!y) {
              Nt("桌宠没显示 —— 先点上面「显示桌宠」，模型加载好后再点。");
              return;
            }
            q(H, { type: "hotkey-toggle", id: A.id, action: A.action }), Nt("");
          });
          return;
        }
        if (C.closest("[data-hk-del]")) {
          gt = gt.filter((y) => y.id !== A.id), qt(), je();
          return;
        }
      }
    });
    const m = (f, C) => {
      const T = f.target;
      if (!T || !T.closest("#pet-hotkeys")) return;
      const A = i(T), y = l(A);
      if (!A || !y) return;
      const I = T.dataset.hkField;
      if (!I) return;
      const j = T.value;
      if (I === "name") {
        y.name = j, je();
        return;
      }
      ci(y.action, I, j), !C && (I === "id" || I === "group") && qt(), je();
    };
    e.addEventListener("change", (f) => m(f, !1)), e.addEventListener("input", (f) => m(f, !0));
  }
  const Qt = "__lunacPetMotionDelegate";
  if (!fe[Qt]) {
    fe[Qt] = !0;
    const i = (A, y) => {
      const I = A.closest(y);
      return I ? Number.parseInt(I.getAttribute(y.slice(1, -1)) ?? "", 10) : NaN;
    }, l = (A) => A.split(/[\\/]/).pop() || "", m = async () => {
      await Pe(), La(), q(H, { type: "reload" });
    };
    e.addEventListener("click", (A) => {
      var z, u;
      const y = A.target;
      if (!y || !y.closest("#pet-motions")) return;
      const I = (k) => {
        const M = y.closest(`[${k}]`), c = (M == null ? void 0 : M.getAttribute(k)) ?? "", [w, F] = c.split(":").map((O) => Number.parseInt(O, 10));
        return [w, F];
      };
      if (y.closest("#pet-chain-add")) {
        U = [...U, cr(`动作链 ${U.length + 1}`)], vt(), Bt();
        return;
      }
      if (y.closest("[data-chain-toggle]")) {
        const [k] = I("data-chain-toggle"), M = U[k];
        if (!M) return;
        Re.has(M.id) ? Re.delete(M.id) : Re.add(M.id), vt();
        return;
      }
      if (y.closest("[data-chain-loop]")) {
        const [k] = I("data-chain-loop");
        if (!U[k]) return;
        U = U.map((c, w) => w === k ? { ...c, loop: !c.loop } : c), vt(), Bt();
        return;
      }
      if (y.closest("[data-chain-del]")) {
        const [k] = I("data-chain-del");
        if (!Number.isInteger(k)) return;
        const M = U[k];
        M && Re.delete(M.id), U = U.filter((c, w) => w !== k), vt(), Bt();
        return;
      }
      if (y.closest("[data-chain-step-add]")) {
        const [k] = I("data-chain-step-add");
        if (!U[k]) return;
        const c = ((z = lt[0]) == null ? void 0 : z.path) ?? "";
        (async () => {
          const w = await oi(c), F = U[k];
          if (!F) return;
          const O = w !== null ? { ...ya(c), loopSec: w } : ya(c), nt = { ...F, steps: [...F.steps, O] };
          U = U.map((st, zt) => zt === k ? nt : st), vt(), Bt();
        })();
        return;
      }
      if (y.closest("[data-chain-step-del]")) {
        const [k, M] = I("data-chain-step-del"), c = U[k];
        if (!c || !Number.isInteger(M)) return;
        const w = { ...c, steps: c.steps.filter((F, O) => O !== M) };
        U = U.map((F, O) => O === k ? w : F), vt(), Bt();
        return;
      }
      if (y.closest("[data-chain-run]")) {
        const k = ((u = y.closest("[data-chain-run]")) == null ? void 0 : u.getAttribute("data-chain-run")) ?? "";
        k && q(H, { type: "chain-play", id: k });
        return;
      }
      if (y.closest("#pet-mo-add")) {
        (async () => {
          var F;
          const k = N().model.trim();
          if (!k) {
            At("先选一个 Live2D 模型。");
            return;
          }
          const M = await rs(k);
          if (!M) {
            At("拿不到参数清单 —— 先「显示桌宠」一次，再来新建动作。");
            return;
          }
          const c = JSON.parse(M), w = `${Na}${Date.now().toString(36)}.motion3.json`;
          try {
            await d("write_motion_file", { modelPath: k, name: w, json: M }), At(`已生成 ${w}（${((F = c.Curves) == null ? void 0 : F.length) ?? 0} 条参数曲线），可交给 AI 编。`), await m();
          } catch (O) {
            At("生成失败：" + (O instanceof Error ? O.message : String(O)));
          }
        })();
        return;
      }
      const j = i(y, "[data-mo-idle]");
      if (Number.isInteger(j)) {
        const k = lt[j], M = N().model.trim();
        if (!k || !M) return;
        const c = N(), w = new Set(c.idleMotions[M] ?? []), F = [...w].find((nt) => nt.toLowerCase() === k.name.toLowerCase());
        F !== void 0 ? w.delete(F) : w.add(k.name);
        const O = { ...c.idleMotions };
        w.size ? O[M] = [...w] : delete O[M], X({ ...c, idleMotions: O }), un(), q(H, { type: "reload" });
        return;
      }
      const J = i(y, "[data-mo-run]");
      if (Number.isInteger(J)) {
        q(H, { type: "motion-play", group: Dn, index: J });
        return;
      }
      const Y = i(y, "[data-mo-del]");
      Number.isInteger(Y) && (async () => {
        const k = lt[Y], M = N().model.trim();
        if (!(!k || !M))
          try {
            await d("delete_motion_file", { modelPath: M, name: l(k.path) }), await m();
          } catch (c) {
            At("删除失败：" + (c instanceof Error ? c.message : String(c)));
          }
      })();
    });
    const f = (A, y) => {
      const I = A.target, j = I == null ? void 0 : I.dataset.moName;
      if (!I || j === void 0) return;
      const J = lt[Number.parseInt(j, 10)], Y = N().model.trim();
      if (!J || !Y) return;
      const z = I.value.trim().replace(/\.motion3\.json$/i, "");
      y && I.blur(), !(!z || z === J.name) && (async () => {
        try {
          await d("rename_motion_file", {
            modelPath: Y,
            from: l(J.path),
            to: `${z}.motion3.json`
          }), await m();
        } catch (u) {
          At("改名失败：" + (u instanceof Error ? u.message : String(u)));
        }
      })();
    }, C = (A, y) => {
      const I = (A == null ? void 0 : A.getAttribute(y)) ?? "", [j, J] = I.split(":").map((Y) => Number.parseInt(Y, 10));
      return [j, J];
    }, T = (A) => {
      const y = A.target;
      if (!y) return;
      if (y.dataset.chainName !== void 0) {
        const J = Number.parseInt(y.dataset.chainName, 10), Y = U[J];
        if (!Y) return;
        const z = y.value.trim() || Y.name;
        U = U.map((u, k) => k === J ? { ...u, name: z } : u), Bt();
        return;
      }
      if (y.dataset.chainStepFile !== void 0) {
        const [J, Y] = C(y, "data-chain-step-file");
        li(J, Y, y.value);
        return;
      }
      const I = y.dataset.chainStepLoop !== void 0, j = y.dataset.chainStepStop !== void 0;
      if (I || j) {
        const [J, Y] = C(y, I ? "data-chain-step-loop" : "data-chain-step-stop"), z = U[J];
        if (!z || !Number.isInteger(Y)) return;
        const u = Number.parseFloat(y.value), k = Number.isFinite(u) ? u : 0, M = z.steps.map((c, w) => w !== Y ? c : I ? { ...c, loopSec: k > 0 ? Math.min(3600, k) : 3 } : { ...c, stopSec: k > 0 ? Math.min(3600, k) : 0 });
        U = U.map((c, w) => w === J ? { ...c, steps: M } : c), vt(), Bt();
      }
    };
    e.addEventListener("change", T), e.addEventListener("change", (A) => f(A, !1)), e.addEventListener("keydown", (A) => {
      if (A.key !== "Enter") return;
      const y = A.target;
      (y == null ? void 0 : y.dataset.moName) !== void 0 && (A.preventDefault(), f(A, !0));
    });
  }
  ui(), o(), v(N().clickThrough), ke(), L(), In(), Pe(), _t("memory"), _t("growth"), _t("suggest"), (async () => {
    N().model.trim() && (await x() || (await p(), b(!0)));
  })().catch(() => {
  });
}
function us() {
  return `
<div class="pet-root" id="pet-root">
  <!-- 对话改渲染（2026-10-10 用户口径；2026-10-13 第二轮补画布跟随窗口）：
       输出贴窗口上沿、输入贴下沿，两条**紧贴模型区**（无空隙）—— 缺省 上 75 / 模型区（参考）300×400 / 下 35。
       模型区高度**不再定尺**：用 flex 跟随窗口剩余空间（画布变高模型不变大、贴底、上方多出空间）。
       两条**始终占位**（对话收起时只隐藏内容），所以模型不会因开合对话而跳动。整块的显隐由 .pet-root
       上的 chat-on / chat-input-on 两个类控制（见 setChatOpen）。 -->
  <div class="pet-top">
    <div class="pet-chat-output" id="pet-chat-bubble">
      <div class="pet-chat-text" id="pet-chat-text"></div>
    </div>
  </div>
  <div class="pet-stage" id="pet-stage">
    <div class="pet-l2d" id="pet-l2d"></div>
    <img class="pet-img" id="pet-img" alt="" draggable="false">
    <div class="pet-empty" id="pet-empty">还没有形象<br><span>在控制台里选一张图片或一个 Live2D 模型</span></div>
  </div>
  <div class="pet-bottom">
    <div class="pet-chat-inputrow">
      <textarea class="pet-chat-input" id="pet-chat-input" rows="1" spellcheck="false" autocomplete="off" placeholder="${$(h("pet.ai_chat_placeholder"))}" aria-label="${$(h("pet.ai_chat"))}"></textarea>
      <button type="button" class="pet-chat-stop" id="pet-chat-stop" title="${$(h("pet.chat_stop"))}" aria-label="${$(h("pet.chat_stop"))}">${ts}</button>
      <button type="button" class="pet-chat-close" id="pet-chat-close" title="${$(h("pet.ai_chat_close"))}" aria-label="${$(h("pet.ai_chat_close"))}">×</button>
    </div>
  </div>
  <div class="pet-err" id="pet-err"></div>
  <div class="pet-toast" id="pet-toast"></div>
  <div class="pet-menu" id="pet-menu">
    <button data-act="ai-chat">${h("pet.ai_chat")}</button>
    <button data-act="settings">桌宠设置…</button>
    <button data-act="look-screen">${h("pet.look_screen")}</button>
    <button data-act="change">更换模型…</button>
    <button data-act="reset">恢复</button>
    <button data-act="win-reset">${h("pet.win_reset")}</button>
    <button data-act="through" id="pet-menu-through">${$(bn(N().clickThrough))}</button>
    <button data-act="close" class="danger">关闭桌宠</button>
  </div>
  <!-- 窗上缩放手柄（2026-10-13）：无边框窗没有系统边框可抓，靠它给一个**看得见**的缩放入口
       （拖边缘 / 角的能力由宿主 resizable 提供，见 plugin_window.rs 的 .resizable(...)）。
       只在**输入区未展开**时显示 —— 输入区右下角是「关闭 ×」按钮，两者会重叠。
       图标是严格线性 SVG（无 emoji），颜色走 --text-dim → hover --text。 -->
  <div class="pet-resize-handle" id="pet-resize-handle" title="${$(h("pet.resize_handle"))}" aria-label="${$(h("pet.resize_handle"))}">${es}</div>
</div>`;
}
const ds = `
.pet-root{position:fixed;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:flex-start;overflow:hidden;}
/* 上：输出带（**预留下限 75**，可随内容变大 —— 由 JS 改写 --pet-top-h，见 applyOutHeight）；
   下：输入带 固定 35 —— **始终占位**（对话收起只隐藏内容、模型不跳动）；
   两条都紧贴模型（无空隙）。数值与 pet-window-size 的 IN_H / OUT_MIN_H 一致。 */
.pet-top{flex:0 0 var(--pet-top-h,75px);width:100%;display:flex;align-items:flex-start;justify-content:center;overflow:hidden;}
.pet-bottom{flex:0 0 35px;width:100%;display:flex;align-items:flex-end;justify-content:center;overflow:hidden;}
/* 模型区（画布）**跟随窗口剩余空间**（2026-10-13 第二轮）：
   flex:1 1 auto ⇒ 吃掉「输出带 + 输入带」之外的全部高度（= 窗高 − 输出带 − 输入带）；
   宽度 = 窗宽 − 左右留白（--pet-stage-gap，缺省 20 = 左右各 10，与 STAGE_W 一致）。
   画布变大时模型**不放大**（只是周围多出空间）、且**贴底**（模型逻辑见 live2d-engine 的 fit 与
   pet-window-size 的 modelBaseScale「只缩不放」）。min-height:0 让它在窗口很矮时能收到底。
   ⚠️ 2026-10-13 第三轮：模型区**不会低于 STAGE_MIN_H（140）** —— 这个下限由 JS 保证（输出带上限
   动态取 outCap、窗矮则上限降；最小窗高抬到 WIN_H_MIN = 75 + 35 + 140 = 250），CSS 的 min-height:0
   只负责不被内容顶开、不再承担下限。见 pet-window-size 的 STAGE_MIN_H / WIN_H_MIN / outCap。 */
.pet-stage{position:relative;width:calc(100% - var(--pet-stage-gap,20px));flex:1 1 auto;min-height:0;display:flex;align-items:flex-end;justify-content:center;cursor:grab;touch-action:none;}
.pet-stage:active{cursor:grabbing;}
/* 图片分支与模型分支**行为一致**（2026-10-13）：盒子定尺 = **参考模型区**（--pet-stage-ref-w/h，
   缺省 300×400），不随画布放大 ⇒ 画布变大时图片同样不放大、只多空间；画布小于参考时由
   max-width/max-height 收到画布内（object-fit:contain 不裁切）。底对齐 ⇒ object-position:bottom
   center 让它贴底、上方留白（与 Live2D 的 anchor=底边中心对齐）。 */
.pet-img{flex:0 0 auto;width:var(--pet-stage-ref-w,300px);height:var(--pet-stage-ref-h,400px);max-width:100%;max-height:100%;object-fit:contain;object-position:bottom center;transform-origin:50% 100%;pointer-events:none;-webkit-user-drag:none;filter:drop-shadow(0 6px 14px rgba(var(--shade-rgb),.35));}
.pet-l2d{position:absolute;inset:0;display:none;}
.pet-l2d.on{display:block;}
.pet-l2d canvas{display:block;}
.pet-err{position:absolute;left:8px;right:8px;bottom:8px;display:none;font-size:.68rem;line-height:1.6;color:var(--red);background:var(--surface-glass);border:1px solid var(--border-glass);border-radius:var(--radius);padding:8px 10px;word-break:break-all;backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);}
.pet-err.on{display:block;}
.pet-toast{position:absolute;left:50%;top:84px;transform:translateX(-50%);display:none;max-width:92%;font-size:.72rem;line-height:1.6;color:var(--text);background:var(--surface-glass);border:1px solid var(--border-glass);border-radius:var(--radius);padding:8px 12px;text-align:center;word-break:break-all;backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);box-shadow:0 6px 18px rgba(var(--shade-rgb),.28);}
.pet-toast.on{display:block;}
/* 输出框：**随内容封顶**（用户 2026-10-13 口径）—— 宽度**跟随窗口宽**（width:100% = 整窗宽，
   缺省即 320；比参考窄时靠 box-sizing:border-box + min-width:0 + max-width:100% + word-break
   收住，不产生横向溢出）；高度**跟随输出带** --pet-top-h（下限 75 = 预留带，上限 OUT_CAP_H）。
   做法：align-self:stretch 覆盖 .pet-top 的 flex-start（= 撑满输出带）；height / max-height 都取
   --pet-top-h ⇒ 盒高恒等于输出带高（下限 75 时即原「固定占满预留 75px」的行为）；文字靠顶
   （顶部对齐，**不做垂直居中**）。内容**超过上限**（= 输出带已被封在 OUT_CAP_H）时在盒内滚动
   （overflow-y:auto）。短 / 中回复盒高贴合内容 ⇒ **不再出现滚动条**。
   ⚠️ 盒子是 **flex 列**而不是 block（2026-10-13 修）：本模板里 .pet-chat-output 与 .pet-chat-text
   之间夹着换行 + 缩进（HTML 排版的空白文本节点），而本盒带 white-space:pre-wrap、**块级**容器会把
   这种纯空白文本节点当成真内容渲染成空行 —— 于是文字**上方 / 下方各多出约两行空白**（用户 2026-10-13
   报的「文字前面 / 上下都有空白」；无头 Chrome 实测：文字距盒顶 42.84px，而 padding-top 只有 6px，
   盒内容高 104 > 75 还平白多出一条滚动条）。flex 容器**不渲染**纯空白子文本节点（规范把整串空白
   子文本节点按 display:none 处理）⇒ 与模板缩进无关地保证文字贴顶。
   无正文时靠 :has(> .pet-chat-text:empty) 让它**不可见但仍占位** ⇒ 输出带回到下限 75px、
   开合对话时模型不位移。
   ⚠️ white-space:pre-wrap 会把回复里的换行 / 连续空行渲染成盒子内的**真实空白块**（用户报的段间空白）；
   故正文写进 DOM 前一律先过 JS 的 normalizeReplyText（换行归一 + 连续空白折叠 + 首尾空行丢弃，
   见 pet-typewriter.ts）—— 这里保留 pre-wrap 只为兜底单个空格。
   ⚠️ 滚动条只走全局那一条（ui-style.md 界面 6）：不得写 scrollbar-width / scrollbar-color、
   不得按容器另写、不得藏。 */
.pet-chat-output{display:none;width:100%;max-width:100%;min-width:0;align-self:stretch;height:var(--pet-top-h,75px);max-height:var(--pet-top-h,75px);min-height:0;box-sizing:border-box;overflow-y:auto;padding:6px 10px;font-size:.72rem;line-height:1.6;color:var(--text);text-align:left;background:var(--surface-glass);border:1px solid var(--border-glass);border-radius:var(--radius);backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px);word-break:break-word;white-space:pre-wrap;}
.pet-root.chat-on .pet-chat-output{display:flex;flex-direction:column;}
/* 正文**不许被 flex 收缩**（flex-shrink:0）：否则盒子定尺时正文会被压到盒高、内容溢出到
   盒外 —— 那样既量不到正文的真实高度（本来要按它算盒高），滚动也会看不见。撑开 + 盒内滚。 */
.pet-chat-text{flex:0 0 auto;min-width:0;}
.pet-chat-output:has(> .pet-chat-text:empty){visibility:hidden;}
.pet-chat-output.thinking .pet-chat-text{opacity:.55;}
/* 输入行：高 35（贴窗口下沿）；只在 .pet-root.chat-input-on 时显示。
   「桌宠发起」的三种情况（语音输入 / 主动询问 / 抓屏）**不显示输入区** —— 见 setChatOpen 的 showInput。 */
.pet-chat-inputrow{display:none;width:100%;height:35px;box-sizing:border-box;align-items:center;gap:6px;padding:0 8px;}
.pet-root.chat-input-on .pet-chat-inputrow{display:flex;}
.pet-chat-input{box-sizing:border-box;flex:1 1 auto;height:35px;resize:none;padding:6px 10px;font:inherit;font-size:.72rem;line-height:1.5;color:var(--text);background:var(--surface-glass);border:1px solid var(--border-glass);border-radius:var(--radius);outline:none;caret-color:rgb(var(--other-overlay-rgb));backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px);}
.pet-chat-input:focus{border-color:rgba(var(--btn-line-rgb), var(--btn-line-alpha));}
.pet-chat-close{appearance:none;flex:0 0 auto;height:35px;background:var(--surface-glass);border:1px solid var(--border-glass);border-radius:var(--radius);font:inherit;font-size:.9rem;line-height:1;color:var(--text-dim);cursor:pointer;padding:0 9px;}
.pet-chat-close:hover{color:var(--text);background:var(--border-glass);}
/* 「中止对话」图标按钮（形态照 §界面 14.1 的图标按钮：30×30 / 圆角 6px；颜色走按钮背景 + 按钮线条）。
   只在「正在生成」时出现 —— 由 on 类控制（见 setPetGenerating）。 */
.pet-chat-stop{display:none;flex:0 0 auto;align-items:center;justify-content:center;width:30px;height:30px;box-sizing:border-box;background:rgba(var(--btn-bg-rgb),var(--btn-bg-alpha));border:1px solid rgba(var(--btn-line-rgb),var(--btn-line-alpha));border-radius:6px;color:rgb(var(--btn-line-rgb));cursor:pointer;padding:0;}
.pet-chat-stop.on{display:flex;}
.pet-chat-stop:hover{background:rgba(var(--btn-bg-rgb),calc(var(--btn-bg-alpha) + 0.06));}
.pet-empty{position:absolute;left:50%;bottom:38%;transform:translateX(-50%);text-align:center;font-size:.72rem;line-height:1.7;color:var(--text-dim);background:var(--surface-glass);border:1px solid var(--border-glass);border-radius:var(--radius);padding:10px 14px;backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);}
.pet-empty span{font-size:.66rem;opacity:.75;}
.pet-menu{position:absolute;display:none;flex-direction:column;min-width:132px;padding:4px;background:var(--surface-glass);border:1px solid var(--border-glass);border-radius:var(--radius);backdrop-filter:blur(20px);-webkit-backdrop-filter:blur(20px);box-shadow:0 8px 24px rgba(var(--shade-rgb),.28);}
.pet-menu.open{display:flex;}
.pet-menu button{appearance:none;background:none;border:0;text-align:left;font:inherit;font-size:.72rem;color:var(--text);padding:6px 10px;border-radius:6px;cursor:pointer;white-space:nowrap;}
.pet-menu button:hover{background:var(--border-glass);}
.pet-menu button.danger:hover{color:var(--red);}
/* 窗上缩放手柄（2026-10-13）：右下角。**起点是斜向抓握图标**（严格线性 SVG + currentColor），
   色走 --text-dim → hover --text（§界面 2「文字 / 图标走四类派生」）。
   只在**输入区未展开**时显示（.pet-root 无 chat-input-on）—— 输入区右下角是「关闭 ×」按钮，会重叠。
   pointer-events 必须 auto（桌宠窗空白区是穿透 / 拖窗的，手柄要能点）。 */
.pet-resize-handle{position:absolute;right:2px;bottom:2px;width:16px;height:16px;display:none;align-items:center;justify-content:center;color:var(--text-dim);cursor:nwse-resize;z-index:6;pointer-events:auto;touch-action:none;-webkit-user-select:none;user-select:none;}
.pet-root:not(.chat-input-on) .pet-resize-handle{display:flex;}
.pet-resize-handle:hover{color:var(--text);}
.pet-console{padding:10px 12px 14px;font-size:.76rem;color:var(--text);}
.pet-row{display:flex;align-items:center;gap:8px;margin-bottom:10px;flex-wrap:wrap;}
/* 开头那排按钮（显示桌宠 / 更换模型 / 取消配置 / 穿透）**必须同一行**（用户 2026-10-10 口径）：
   不换行 + 收窄内边距，四个刚好排得下。 */
.pet-row-main{gap:6px;flex-wrap:nowrap;}
.pet-row-main .pet-btn{padding:6px 8px;font-size:.7rem;flex:0 0 auto;white-space:nowrap;}
.pet-btn{appearance:none;font:inherit;font-size:.74rem;color:var(--text);background:var(--surface-glass);border:1px solid var(--border-glass);border-radius:8px;padding:6px 12px;cursor:pointer;}
.pet-btn:hover{border-color:rgb(var(--other-overlay-rgb));color:rgb(var(--other-overlay-rgb));}
.pet-btn-primary{background:rgb(var(--other-overlay-rgb));border-color:rgb(var(--other-overlay-rgb));color:var(--text);font-weight:600;}
.pet-btn-primary:hover{color:var(--text);opacity:.92;}
.pet-btn-toggle.on{background:rgb(var(--other-overlay-rgb));border-color:rgb(var(--other-overlay-rgb));color:var(--text);font-weight:600;}
.pet-btn-toggle.on:hover{color:var(--text);opacity:.92;}
/* 分页（模型调试 / 热键，2026-10-10）—— 照 .music-tab / .chat-hist-tab 的胶囊芯片语言。 */
.pet-tabs{display:flex;flex-wrap:wrap;gap:6px;margin-top:12px;border-top:1px solid var(--border-glass);padding-top:11px;margin-bottom:10px;}
.pet-tab{appearance:none;font:inherit;font-size:.72rem;color:var(--text-dim);background:transparent;border:1px solid var(--border-glass);border-radius:999px;padding:4px 14px;cursor:pointer;}
.pet-tab:hover{color:var(--text);border-color:rgba(var(--btn-line-rgb), var(--btn-line-alpha));}
.pet-tab.on{color:var(--text);background:rgba(var(--btn-bg-rgb), var(--btn-bg-alpha));border-color:rgba(var(--btn-line-rgb), var(--btn-line-alpha));}
/* 页内的块不再各画一条上分隔线（那一排页签已经承担了分隔）。
   2026-10-13：主动反应 / 语音朗读 / 人格三页把原先在页签之外的三块搬了进来，同样去掉上分隔。 */
.pet-tabpage>.pet-hotkeys,.pet-tabpage>.pet-debug,.pet-tabpage>.pet-proactive,.pet-tabpage>.pet-tts,.pet-tabpage>.pet-persona{margin-top:0;border-top:0;padding-top:0;}
/* 「恢复默认」按钮行：三个分页各一颗，**贴在页顶**（2026-10-10 用户口径：从页底移上来）。 */
.pet-reset-row{margin-bottom:10px;}
.pet-phys-tag{margin-left:6px;font-size:.62rem;color:var(--text-dim);border:1px solid var(--border-glass);border-radius:999px;padding:0 6px;opacity:.85;}
.pet-check{display:flex;align-items:center;gap:6px;color:var(--text-dim);cursor:pointer;}
.pet-label{color:var(--text-dim);}
.pet-val{color:var(--text-dim);min-width:3.2em;}
.pet-file{margin:2px 0 10px;color:var(--text-dim);word-break:break-all;line-height:1.6;}
.pet-file code{font-size:.7rem;color:var(--text);}
.pet-dim{opacity:.72;}
.pet-bad{color:var(--red);}
.pet-note{color:var(--text-dim);opacity:.72;font-size:.68rem;line-height:1.7;border-top:1px solid var(--border-glass);padding-top:9px;}
.pet-note b{color:var(--text);opacity:.9;}
.pet-persona{margin-top:14px;border-top:1px solid var(--border-glass);padding-top:12px;display:flex;flex-direction:column;gap:8px;}
.pet-persona .pet-note{border-top:0;padding-top:0;}
.pet-persona-text{width:100%;box-sizing:border-box;resize:vertical;min-height:96px;font:inherit;font-size:.72rem;line-height:1.7;color:var(--text);background:rgba(var(--shade-rgb),calc(0.3 * var(--shade-scale)));border:1px solid var(--border-glass);border-radius:8px;padding:8px 10px;outline:none;caret-color:rgb(var(--other-overlay-rgb));}
.pet-persona-text:focus{border-color:rgb(var(--other-overlay-rgb));}
.pet-persona-actions{gap:8px;flex-wrap:wrap;}
/* 人格页的三张列表（事实记忆 / 成长笔记 / 人格建议，2026-10-13）—— 与核心人格块同款分隔线；
   行是 JS 渲染，样式按结构类写（行数 / 文本都来自宿主，样式不绑 id）。 */
.pet-list{margin-top:14px;border-top:1px solid var(--border-glass);padding-top:12px;}
.pet-list .pet-note{border-top:0;padding-top:0;margin-top:8px;}
.pet-list-items{display:flex;flex-direction:column;gap:8px;margin:10px 0;}
.pet-list-row{display:flex;flex-direction:column;gap:8px;padding:8px 10px;border:1px solid var(--border-glass);border-radius:8px;}
.pet-list-text{color:var(--text);font-size:.72rem;line-height:1.7;white-space:pre-wrap;word-break:break-word;}
.pet-list-acts{display:flex;flex-wrap:wrap;gap:6px;}
.pet-list-empty{color:var(--text-muted);font-size:.7rem;line-height:1.7;}
/* 两段式确认态（删除 / 清空 / 接受合并）：红色确认，见 docs/ui-style.md §界面 2 / §界面 11 白名单。 */
.pet-list-del[data-armed="1"],.pet-list-clear[data-armed="1"],.pet-suggest-accept[data-armed="1"]{color:var(--red);background:rgba(192,138,138,0.14);border-color:var(--red);}
.pet-debug{margin-top:12px;border-top:1px solid var(--border-glass);padding-top:11px;}
.pet-debug-title{font-weight:600;color:var(--text);margin-bottom:8px;}
.pet-debug-note{color:var(--text-dim);font-size:.68rem;line-height:1.7;margin-bottom:8px;}
.pet-debug-body.off{opacity:.45;pointer-events:none;}
.pet-param{display:flex;align-items:center;gap:8px;margin-bottom:8px;}
.pet-param .pet-label{min-width:5.5em;}
.pet-range{flex:1;min-width:0;height:4px;appearance:none;-webkit-appearance:none;background:var(--border-glass);border-radius:3px;outline:none;cursor:pointer;}
.pet-range::-webkit-slider-thumb{appearance:none;-webkit-appearance:none;width:14px;height:14px;border-radius:50%;background:rgb(var(--btn-line-rgb));border:0;cursor:pointer;}
.pet-range::-moz-range-thumb{width:14px;height:14px;border-radius:50%;background:rgb(var(--btn-line-rgb));border:0;cursor:pointer;}
.pet-param .pet-param-num{flex:0 0 auto;width:54px;box-sizing:border-box;padding:4px 7px;font:inherit;font-size:.7rem;text-align:right;font-variant-numeric:tabular-nums;color:var(--text);background:rgba(var(--shade-rgb),calc(0.3 * var(--shade-scale)));border:1px solid var(--border-glass);border-radius:5px;outline:none;caret-color:rgb(var(--other-overlay-rgb));}
.pet-param .pet-param-num:focus{border-color:rgba(var(--btn-line-rgb), var(--btn-line-alpha));}
.pet-debug-sub{color:var(--text-dim);margin:10px 0 6px;}
.pet-exprs{display:flex;flex-wrap:wrap;gap:6px;line-height:1.6;max-height:180px;overflow-y:auto;padding-right:4px;align-content:flex-start;}
.pet-expr-btn{appearance:none;font:inherit;font-size:.72rem;color:var(--text);background:var(--surface-glass);border:1px solid var(--border-glass);border-radius:8px;padding:5px 10px;cursor:pointer;}
.pet-expr-btn:hover{border-color:rgb(var(--other-overlay-rgb));color:rgb(var(--other-overlay-rgb));}
.pet-expr-reset{color:var(--text-dim);}
.pet-expr-btn.on{background:rgb(var(--other-overlay-rgb));border-color:rgb(var(--other-overlay-rgb));color:var(--text);font-weight:600;}
.pet-expr-btn.on:hover{color:var(--text);opacity:.92;}
.pet-proactive{margin-top:12px;border-top:1px solid var(--border-glass);padding-top:11px;}
.pet-proactive .pet-note{margin-top:8px;border-top:0;padding-top:0;}
.pet-proactive .pet-param-num{flex:0 0 auto;width:64px;box-sizing:border-box;padding:4px 7px;font:inherit;font-size:.7rem;text-align:right;font-variant-numeric:tabular-nums;color:var(--text);background:rgba(var(--shade-rgb),calc(0.3 * var(--shade-scale)));border:1px solid var(--border-glass);border-radius:5px;outline:none;caret-color:rgb(var(--other-overlay-rgb));}
.pet-proactive .pet-param-num:focus{border-color:rgba(var(--btn-line-rgb), var(--btn-line-alpha));}
.pet-tts{margin-top:12px;border-top:1px solid var(--border-glass);padding-top:11px;}
.pet-tts .pet-note{margin-top:8px;border-top:0;padding-top:0;}
/* 「参考音色」子块（2026-10-12）：参考文本输入框 + 「添加音频文件 / 试听」两枚按钮 + 状态行。 */
.pet-tts-voice{margin-top:10px;padding-top:10px;border-top:1px solid var(--border-glass);}
.pet-tts-voice .pet-label{display:block;margin-bottom:6px;}
.pet-tts-voice .pet-row{margin-top:8px;}
.pet-tts-text{display:block;width:100%;box-sizing:border-box;font:inherit;font-size:.72rem;color:var(--text);background:rgba(var(--shade-rgb),calc(0.3 * var(--shade-scale)));border:1px solid var(--border-glass);border-radius:5px;padding:6px 8px;outline:none;caret-color:rgb(var(--other-overlay-rgb));}
.pet-tts-text:focus{border-color:rgba(var(--btn-line-rgb), var(--btn-line-alpha));}
.pet-tts-ok{color:var(--green);}
.pet-tts .pet-bad{color:var(--red);}
/* 热键区（2026-10-10）—— 行是 JS 渲染的动态列表，样式必须按结构类写，不能绑 id。 */
.pet-hotkeys{margin-top:12px;border-top:1px solid var(--border-glass);padding-top:11px;}
.pet-hotkeys .pet-note{border-top:0;padding-top:0;margin-bottom:8px;}
.pet-hk-list{display:flex;flex-direction:column;gap:8px;margin-bottom:10px;}
.pet-hk-row{display:flex;flex-wrap:wrap;gap:6px;align-items:center;padding:8px;border:1px solid var(--border-glass);border-radius:8px;}
.pet-hk-row input,.pet-hk-row select{font:inherit;font-size:.7rem;color:var(--text);background:rgba(var(--shade-rgb),calc(0.3 * var(--shade-scale)));border:1px solid var(--border-glass);border-radius:5px;padding:4px 7px;outline:none;}
.pet-hk-row input:focus,.pet-hk-row select:focus{border-color:rgba(var(--btn-line-rgb), var(--btn-line-alpha));}
.pet-hk-name{flex:1 1 96px;min-width:72px;}
.pet-hk-target{flex:1 1 96px;min-width:72px;color:var(--text-dim);font-size:.7rem;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
/* 热键行的「类型 / 表情对象」改**自绘下拉**（.custom-select，共享组件，2026-10-11）：
   行内可伸缩（原先原生 select 无 flex、按内容宽度）。 */
.pet-hk-row .custom-select{flex:1 1 110px;min-width:96px;max-width:none;}
.pet-hk-num{flex:0 0 auto;width:56px;box-sizing:border-box;text-align:right;font-variant-numeric:tabular-nums;}
.pet-hk-color{flex:0 0 auto;width:40px;height:24px;box-sizing:border-box;padding:1px 2px;cursor:pointer;}
.pet-hk-run{flex:0 0 auto;color:rgb(var(--other-overlay-rgb));}
.pet-hk-del{flex:0 0 auto;color:var(--red);}
.pet-hk-del:hover{color:var(--red);border-color:var(--red);}
/* 预设动作页（2026-10-10）—— 与热键行同一套结构类写法（动态列表，不绑 id）。 */
.pet-motions{margin:0;}
.pet-mo-list{display:flex;flex-direction:column;gap:8px;margin-bottom:10px;}
.pet-mo-row{display:flex;flex-wrap:wrap;gap:6px;align-items:center;padding:8px;border:1px solid var(--border-glass);border-radius:8px;}
.pet-mo-row input,.pet-mo-row select{font:inherit;font-size:.7rem;color:var(--text);background:rgba(var(--shade-rgb),calc(0.3 * var(--shade-scale)));border:1px solid var(--border-glass);border-radius:5px;padding:4px 7px;outline:none;}
.pet-mo-row input:focus,.pet-mo-row select:focus{border-color:rgba(var(--btn-line-rgb), var(--btn-line-alpha));}
.pet-mo-name{flex:1 1 96px;min-width:72px;}
.pet-mo-row select{flex:1 1 110px;min-width:88px;}
.pet-mo-run{flex:0 0 auto;color:rgb(var(--other-overlay-rgb));}
.pet-mo-del{flex:0 0 auto;color:var(--red);}
.pet-mo-del:hover{color:var(--red);border-color:var(--red);}
/* 调试区的开关形态 + 参数形态覆盖按钮（2026-10-10）。 */
.pet-param-on{flex:0 0 auto;min-width:52px;}
.pet-param-kind{flex:0 0 auto;display:inline-flex;align-items:center;justify-content:center;appearance:none;width:24px;height:20px;color:var(--text-dim);background:transparent;border:1px solid var(--border-glass);border-radius:999px;padding:0;cursor:pointer;line-height:0;}
.pet-param-kind:hover{color:var(--text);border-color:rgba(var(--btn-line-rgb), var(--btn-line-alpha));}
/* ── 动作链（2026-10-10，backlog ㉝②；放在动作页最上面）── */
.pet-chains{margin-bottom:12px;padding-bottom:10px;border-bottom:1px solid var(--border-glass);}
.pet-chain-list{display:flex;flex-direction:column;gap:10px;margin-top:8px;}
.pet-chain{padding:8px;border:1px solid var(--border-glass);border-radius:8px;background:rgba(var(--shade-rgb),calc(0.14 * var(--shade-scale)));}
.pet-chain-head{display:flex;gap:6px;align-items:center;flex-wrap:wrap;}
/* 展开 / 收起箭头（2026-10-11）：小方按钮，SVG 跟随文字色；展开时旋转 90 度。 */
.pet-chain-toggle{flex:0 0 auto;display:inline-flex;align-items:center;justify-content:center;width:22px;height:22px;padding:0;line-height:0;color:var(--text-dim);}
.pet-chain-toggle svg{transition:transform .12s ease;}
.pet-chain-toggle.on svg{transform:rotate(90deg);}
.pet-chain-name{flex:1 1 110px;min-width:80px;font:inherit;font-size:.72rem;color:var(--text);background:rgba(var(--shade-rgb),calc(0.3 * var(--shade-scale)));border:1px solid var(--border-glass);border-radius:5px;padding:4px 7px;outline:none;}
.pet-chain-name:focus{border-color:rgba(var(--btn-line-rgb), var(--btn-line-alpha));}
.pet-chain-total{flex:0 0 auto;font-size:.66rem;color:var(--text-dim);}
.pet-chain-loopbtn{flex:0 0 auto;}
/* 折叠态**摘要**：一行、过长省略（只显示「文件 · 循环 · 硬停」的拼接）。 */
.pet-chain-summary{display:none;margin:6px 0 0;font-size:.66rem;line-height:1.5;color:var(--text-dim);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.pet-chain.collapsed .pet-chain-summary{display:block;}
/* 折叠：藏起步骤列表与「添加步骤」。 */
.pet-chain.collapsed .pet-chain-steps{display:none;}
.pet-chain.collapsed [data-chain-step-add]{display:none;}
.pet-chain-steps{display:flex;flex-direction:column;gap:6px;margin:8px 0;}
/* 每一步 = 上「一行四个控件」（名称 / 循环 / 硬停 / 删除，**不换行**）+ 下「进度条」。 */
.pet-chain-step{display:flex;flex-direction:column;gap:0;}
.pet-chain-fields{display:flex;align-items:center;gap:6px;flex-wrap:nowrap;min-width:0;}
/* 动作链每一步的**动作文件下拉**改自绘 .custom-select（2026-10-11）：占满该行剩余宽度。 */
.pet-chain-fields .custom-select{flex:1 1 auto;min-width:0;max-width:none;}
/* 仍为**原生 select** 的几处（热键行的 group / id / mode / enabled、动作行）：
   收合面按 docs/ui-style.md §界面 12 基准对齐（高 26 / 圆角 6 / 内边距 5px 8px /
   font-size .73rem / 底 rgba(var(--shade-rgb), calc(0.25 * var(--shade-scale))) /
   描边 var(--border-glass) = 按钮线条 α0.10 / 文字 var(--text)）；弹出层由 OS 绘制、
   不可样式化（§界面 12 硬豁免）。
   ⚠️ 热键行的「类型 / 表情对象」与动作链步骤的动作文件**已改自绘 .custom-select**（外观由
   styles.css 的共享规则给），不再进本组。
   单独成组、不并进上面的 input,select 共享规则：那条规则里有一批 input 专有覆盖
   （.pet-hk-color 的圆角 / 内边距等），合并进去会误伤它们。 */
.pet-hk-row select,.pet-mo-row select{box-sizing:border-box;height:26px;font-size:.73rem;background:rgba(var(--shade-rgb),calc(0.25 * var(--shade-scale)));border:1px solid var(--border-glass);border-radius:6px;padding:5px 8px;color:var(--text);}
.pet-chain-t{flex:0 0 auto;display:inline-flex;align-items:center;gap:3px;font-size:.66rem;color:var(--text-dim);white-space:nowrap;}
/* 「循环」「硬停」两个数字框**收窄**到约 4 个字符宽（用户 2026-10-11 口径）：
   字号 .7rem 下 4.2em 约 47px，去掉内边距 / 边框后仍能看清「3.0」「12.5」这类值。
   右对齐 + 等宽数字，多位数字也稳。 */
.pet-chain-num{width:4.2em;box-sizing:border-box;font:inherit;font-size:.7rem;color:var(--text);background:rgba(var(--shade-rgb),calc(0.3 * var(--shade-scale)));border:1px solid var(--border-glass);border-radius:5px;padding:3px 5px;outline:none;text-align:right;font-variant-numeric:tabular-nums;caret-color:rgb(var(--other-overlay-rgb));}
.pet-chain-del{flex:0 0 auto;color:var(--red);padding:2px 8px;}
.pet-chain-run{flex:0 0 auto;}
/* 进度条：动作页每行 / 动作链每步下方（子元素 i 为填充、span 为覆盖文字）。 */
.pet-chain-bar{position:relative;flex:1 1 100%;height:16px;margin-top:3px;border-radius:5px;overflow:hidden;background:rgba(var(--shade-rgb),calc(0.28 * var(--shade-scale)));border:1px solid var(--border-glass);}
/* 动作链里进度条是「一行控件」的下方兄弟（父容器已是竖向 flex）⇒ 改成不收缩、占满整行宽。 */
.pet-chain-step .pet-chain-bar{flex:0 0 auto;width:100%;}
.pet-chain-bar i{position:absolute;left:0;top:0;bottom:0;width:0;background:rgb(var(--other-overlay-rgb));opacity:.35;transition:width .08s linear;}
.pet-chain-bar span{position:absolute;left:6px;right:6px;top:0;bottom:0;display:flex;align-items:center;font-size:.62rem;color:var(--text-dim);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;pointer-events:none;}
`;
let ie = null;
async function fs(e) {
  const t = (s) => e.querySelector(`#${s}`), n = t("pet-stage"), a = t("pet-img"), o = t("pet-l2d"), p = t("pet-err"), b = t("pet-toast"), v = t("pet-empty"), _ = t("pet-menu"), x = t("pet-root"), L = t("pet-chat-bubble"), E = t("pet-chat-text"), Z = t("pet-chat-close"), it = t("pet-chat-stop"), B = t("pet-chat-input"), tt = t("pet-resize-handle");
  x == null || x.style.setProperty("--pet-stage-gap", `${kr}px`), x == null || x.style.setProperty("--pet-stage-ref-w", `${zn}px`), x == null || x.style.setProperty("--pet-stage-ref-h", `${Wn}px`);
  let K = 0, D = N(), W = null, we = "", xe = 0, at = !0, ht = null, ct = [], wt = 0, Ot = "", Pt = null, mt = !0;
  L == null || L.addEventListener("scroll", () => {
    L && (mt = L.scrollHeight - L.scrollTop - L.clientHeight <= 2);
  });
  function Be(s) {
    p && (p.textContent = s, p.classList.toggle("on", !!s));
  }
  let Dt = null;
  function rt(s, r) {
    b && (b.textContent = s, b.classList.add("on"), Dt && clearTimeout(Dt), Dt = setTimeout(() => {
      Dt = null, b.classList.remove("on");
    }, r));
  }
  function le() {
    try {
      W == null || W.destroy();
    } catch (s) {
      console.warn("[pet] dropModel failed:", s);
    }
    W = null;
  }
  async function _e() {
    const s = ++xe;
    D = N(), Be("");
    const r = D.model.trim(), g = D.image.trim();
    if (r && o) {
      a && (a.removeAttribute("src"), a.style.display = "none"), v && (v.style.display = "none"), o.classList.add("on"), _t(), le(), o.querySelectorAll("canvas").forEach((S) => S.remove()), ee.clear(), Sn();
      try {
        const { mountLive2D: S } = await Wr(), P = await qr(r), R = await Fe(r), V = R.map((et) => ({ name: et.name, file: et.path })), G = ri(r), Q = R.filter((et) => G.has(et.name.toLowerCase())).map((et) => ({ name: et.name, file: et.path })), ut = await S(o, {
          modelPath: r,
          scale: D.scale,
          offsetX: D.offsetX,
          offsetY: D.offsetY,
          rotation: D.rotation,
          // 参考模型区尺寸（缺省窗口下的 300×400）：模型基准缩放按它算 ⇒ 画布比它大时不放大、
          // 比它小时按画布收（见 live2d-engine 的 fit 与 pet-window-size 的 modelBaseScale）。
          refStageW: zn,
          refStageH: Wn,
          extraExpressions: P,
          extraMotions: V,
          idleMotions: Q,
          // 动作进度（2026-10-10）：引擎 → 本窗 → 设置窗画进度条（`motion-progress` 广播）。
          onMotionProgress: (et) => {
            q(H, {
              type: "motion-progress",
              chainId: we,
              p: et ? { index: et.index, elapsedMs: et.elapsedMs, totalMs: et.totalMs, chainStep: et.chainStep } : null
            });
          }
        });
        if (s !== xe) {
          ut.destroy();
          return;
        }
        W = ut;
        const ne = N();
        let ae = null;
        try {
          const et = ut.listCoreIds(), It = await He(r) ?? qn(r);
          if (et.parameters.length || et.drawables.length || et.parts.length) {
            const ca = await Un(r, et), pa = {
              ...et,
              physicsInputs: ca.physicsInputs,
              physicsOutputs: ca.physicsOutputs
            };
            It.coreIds = pa, localStorage.setItem(ai + r.toLowerCase(), JSON.stringify(pa));
          }
          const Mn = ne.params[r];
          (!It.params || !Object.keys(It.params).length) && Mn && typeof Mn == "object" && (It.params = { ...Mn }), ae = It.params, await an(r, It);
        } catch (et) {
          console.warn("[pet] 读/写 lunac.params.json 失败", et);
        }
        ut.setScale(ne.scale), ut.setOffset(ne.offsetX, ne.offsetY), ut.setRunning(at);
        const jt = ne.expressions[r];
        jt && ut.setExpression(jt);
        const la = ae && Object.keys(ae).length ? ae : ne.params[r];
        if (la)
          for (const [et, It] of Object.entries(la))
            typeof It == "number" && ut.setParameter(et, It);
        await Si(r);
      } catch (S) {
        if (s !== xe) return;
        le(), o.classList.remove("on"), Be(`Live2D 载入失败：${S instanceof Error ? S.message : String(S)}`);
      }
      return;
    }
    le(), o == null || o.classList.remove("on"), a && v && (g ? (a.src = Xt(g), a.style.display = "", v.style.display = "none") : (a.removeAttribute("src"), a.style.display = "none", v.style.display = "")), a && xt(0), at && Ve();
  }
  function xt(s) {
    a && (a.style.transform = `translate(${D.offsetX}px, ${D.offsetY + s}px) scale(${D.scale})`);
  }
  function ke(s) {
    if (D = { ...D, scale: s }, W) {
      W.setScale(s);
      return;
    }
    xt(0);
  }
  function Se(s, r) {
    if (D = { ...D, offsetX: s, offsetY: r }, W) {
      W.setOffset(s, r);
      return;
    }
    xt(0);
  }
  function pt(s) {
    D = { ...D, rotation: s }, W == null || W.setRotation(s);
  }
  const Ft = performance.now();
  function ce(s) {
    if (K = requestAnimationFrame(ce), !!e.isConnected && a && a.style.display !== "none") {
      const r = Math.sin((s - Ft) / 1400) * 3;
      xt(r);
    }
  }
  function Ve() {
    K || (K = requestAnimationFrame(ce));
  }
  function _t() {
    K && cancelAnimationFrame(K), K = 0;
  }
  async function Yt(s) {
    try {
      await d("plugin_window_set_click_through", { ignore: s });
    } catch (r) {
      console.error("[lunac pet] 设置穿透失败：", r);
    }
    await d("pet_alt_rclick_watch", { on: s }).catch(() => {
    });
  }
  let pe = !1;
  function Me() {
    const s = document.getElementById("pet-menu-through");
    s && (s.textContent = bn(D.clickThrough));
  }
  function kt() {
    _ == null || _.classList.remove("open"), pe && (pe = !1, Yt(!0));
  }
  function Kt(s, r) {
    _ && (Me(), _.style.left = `${Math.max(2, Math.min(s, window.innerWidth - 140))}px`, _.style.top = `${Math.max(2, Math.min(r, window.innerHeight - 240))}px`, _.classList.add("open"));
  }
  async function yn(s, r) {
    D.clickThrough && !pe && (pe = !0, await Yt(!1));
    let g = s, S = r;
    try {
      const P = await yt().outerPosition(), R = window.devicePixelRatio || 1;
      g = (s - P.x) / R, S = (r - P.y) / R;
    } catch {
      g = window.innerWidth / 2, S = window.innerHeight / 2;
    }
    Kt(g, S);
  }
  n == null || n.addEventListener("contextmenu", (s) => {
    s.preventDefault(), Kt(s.clientX, s.clientY);
  });
  let St = null;
  const Ce = (s) => {
    St && Se(St.ox + (s.clientX - St.sx), St.oy + (s.clientY - St.sy));
  }, $e = () => {
    St && (St = null, window.removeEventListener("mousemove", Ce), window.removeEventListener("mouseup", $e), X(D));
  };
  function Jt(s) {
    St = { sx: s.clientX, sy: s.clientY, ox: D.offsetX, oy: D.offsetY }, window.addEventListener("mousemove", Ce), window.addEventListener("mouseup", $e), s.preventDefault(), kt();
  }
  n == null || n.addEventListener("mousedown", (s) => {
    if (s.button === 0) {
      if (s.altKey) {
        Jt(s);
        return;
      }
      kt(), yt().startDragging().catch(() => {
      });
    }
  }), e.addEventListener("mousedown", (s) => {
    _ != null && _.classList.contains("open") && !_.contains(s.target) && kt();
  }), tt == null || tt.addEventListener("mousedown", (s) => {
    s.button === 0 && (s.preventDefault(), s.stopPropagation(), kt(), yt().startResizeDragging("SouthEast").catch(() => {
    }));
  }), n == null || n.addEventListener(
    "wheel",
    (s) => {
      const r = n == null ? void 0 : n.getBoundingClientRect();
      if (!r || !W && (!a || a.style.display === "none")) return;
      s.preventDefault();
      const g = s.clientX - r.left, S = s.clientY - r.top, P = s.deltaY < 0 ? Ma : 1 / Ma, R = Math.min(ja, Math.max(Ha, D.scale * P));
      if (R !== D.scale) {
        if (W) {
          const V = W.zoomAtPointer(P, g, S);
          D = { ...D, scale: V.scale, offsetX: V.offsetX, offsetY: V.offsetY };
        } else {
          const V = r.width / 2, G = r.height, Q = R / D.scale;
          D = {
            ...D,
            scale: R,
            offsetX: (g - V) * (1 - Q) + Q * D.offsetX,
            offsetY: (S - G) * (1 - Q) + Q * D.offsetY
          }, xt(0);
        }
        X(D), q(H, { type: "scale-changed", value: D.scale });
      }
    },
    { passive: !1 }
  );
  async function vn() {
    var P;
    rt(h("pet.look_screen_working"), 2e3);
    let s = null;
    try {
      s = await d("screenshot_monitor", {
        label: me
      });
    } catch (R) {
      Et("看一眼屏幕失败", R), rt(h("pet.look_screen_failed"), 2600);
      return;
    }
    const r = s == null ? void 0 : s.path;
    if (!r) {
      rt(h("pet.look_screen_failed"), 2600);
      return;
    }
    let g = !1;
    try {
      g = !!((P = await d("get_ai_config")) != null && P.vision);
    } catch {
    }
    if (!g) {
      rt(h("pet.look_screen_need_vision"), 3400);
      return;
    }
    const S = h("pet.look_screen_query");
    try {
      localStorage.setItem(Nr, JSON.stringify({ query: S, path: r }));
    } catch {
    }
    await d("open_plugin_window", { pluginId: "chat", key: null, input: S, hidden: !0 });
  }
  let Rt = !1;
  function ue(s, r = !0, g = !0) {
    Rt = s, s || Qt(!0), x == null || x.classList.toggle("chat-on", s), x == null || x.classList.toggle("chat-input-on", s && g), s && g && r && (B == null || B.focus()), Ct(!0);
  }
  let Lt = D.winW, Mt = D.winH, Zt = ot, Ee = -1, de = -1, Wt = null;
  function Ue() {
    if (!E) return 0;
    const s = E.getBoundingClientRect().height;
    return Number.isFinite(s) ? Math.ceil(s + 14) : 0;
  }
  function Ge(s) {
    x == null || x.style.setProperty("--pet-top-h", `${s}px`);
  }
  function Ct(s) {
    const r = Sa(Mt), g = Rt && at ? $r(Cr(Ue(), r), Xa, r) : ot;
    if (Zt = g, Ge(g), !at) return;
    const S = Er(Mt, g);
    if (!s && !Tr(Ee, S) || (s && (de = -1), S === de)) return;
    const P = S;
    d("plugin_window_resize_anchored", { width: Math.round(Lt), height: Math.round(P) }).then(() => {
      Ee = P;
    }).catch(() => {
      de = P;
    });
  }
  function Te(s, r = !1) {
    Qt(!1);
    const g = _a(s);
    E && (E.textContent = g), L == null || L.classList.toggle("thinking", !!r), mt = !0, E != null && E.parentElement && (E.parentElement.scrollTop = 0), Ct(!0);
  }
  function Ae() {
    L && (L.scrollTop = L.scrollHeight);
  }
  function fe() {
    ht && (clearInterval(ht), ht = null);
    const s = Pt;
    Pt = null, ct = [], wt = 0, Ot = "", Ct(!0), s && s();
  }
  function Qt(s) {
    const r = ht !== null;
    ht && (clearInterval(ht), ht = null), r && (s && E && (E.textContent = ct.join("")), mt && Ae()), ct = [], wt = 0, Ot = "";
    const g = Pt;
    Pt = null, r && g && g();
  }
  function i(s, r) {
    Qt(!1);
    const g = _a(s);
    if (L == null || L.classList.remove("thinking"), mt = !0, !E) {
      r == null || r();
      return;
    }
    const S = gn(N().speechRate), P = xr(g);
    if (!at || _r(P.length, S, br)) {
      E.textContent = g, L && (L.scrollTop = 0), Ct(!0), r == null || r();
      return;
    }
    ct = P, wt = 0, Ot = "", Pt = r ?? null, ht = setInterval(() => {
      Ot += ct[wt] ?? "", wt++, E && (E.textContent = Ot), mt && Ae(), Ct(!1), wt >= ct.length && fe();
    }, 1e3 / S);
  }
  function l(s) {
    it == null || it.classList.toggle("on", s);
  }
  function m(s, r) {
    const g = s.trim();
    if (!g) return !1;
    Te(h("pet.ai_chat_thinking"), !0), Rt || ia();
    const S = { query: g };
    return r && r.length && (S.files = r), q(Lr, S).catch((P) => Et("发送 AI 消息失败", P)), l(!0), !0;
  }
  let f = 0, C = 0, T = null, A = null, y = !1, I = null, j = !1, J = !1, Y = null;
  const z = 18e4;
  function u() {
    T && (clearTimeout(T), T = null);
  }
  function k(s = !1) {
    u();
    const r = N().proactive;
    if (r.enabled && at) {
      if (Ut() >= r.dailyCap) {
        M();
        return;
      }
      s && (f = 0), f <= 0 && (f = r.intervalMin * 6e4), C = performance.now() + f, T = setTimeout(w, f);
    }
  }
  function M() {
    const s = Ln();
    f = s, C = performance.now() + s, T = setTimeout(() => {
      T = null, f = 0, k(!0), Ht(), te();
    }, s);
  }
  function c() {
    T && (clearTimeout(T), T = null, f = Math.max(0, C - performance.now()));
  }
  function w() {
    T = null;
    const s = N().proactive;
    if (!(!s.enabled || !at)) {
      if (Ut() >= s.dailyCap) {
        k();
        return;
      }
      if (y) {
        k();
        return;
      }
      if (f = 0, y = !0, !m(h("pet.proactive_prompt"))) {
        y = !1, k();
        return;
      }
      Nn(), q(H, { type: "proactive-used" }), A = setTimeout(() => {
        A = null, y && (y = !1, k());
      }, Tn);
    }
  }
  function F() {
    y && (y = !1, A && (clearTimeout(A), A = null), k());
  }
  let O = null, nt = null, st = null, zt = !1;
  async function Ne(s) {
    var P;
    let r = !1;
    try {
      r = !!((P = await d("get_ai_config")) != null && P.vision);
    } catch {
    }
    if (!r)
      return zt || (zt = !0, d("log_frontend", {
        level: "warn",
        message: "[pet] 抓屏子开关已到点，但当前未开启「图片输入」⇒ 跳过（图片块会被静默丢弃，不白烧 token）。要让它真的发出去，请在 AI 设置里开启图片输入 / 换支持视觉的模型。"
      }).catch(() => {
      })), !1;
    rt(h("pet.look_screen_working"), 2e3);
    let g = null;
    try {
      g = await d("screenshot_monitor", { label: me });
    } catch (R) {
      return Et("自动抓屏失败", R), !1;
    }
    const S = g == null ? void 0 : g.path;
    return S ? m(s, [S]) : !1;
  }
  const wn = () => {
    O && (clearTimeout(O), O = null);
  }, xn = () => {
    nt && (clearTimeout(nt), nt = null);
  };
  function Ht() {
    wn();
    const s = N().proactive;
    if (!(!s.autoShot || !at)) {
      if (Ut() >= s.dailyCap) {
        O = setTimeout(Ht, Ln());
        return;
      }
      O = setTimeout(di, s.autoShotMin * 6e4);
    }
  }
  async function di() {
    O = null;
    const s = N().proactive;
    if (!s.autoShot || !at) return;
    if (Ut() >= s.dailyCap || y) {
      Ht();
      return;
    }
    if (y = !0, !await Ne(h("pet.autoshot_prompt"))) {
      y = !1, Ht();
      return;
    }
    Nn(), q(H, { type: "proactive-used" }), A = setTimeout(() => {
      A = null, y && (y = !1);
    }, Tn), Ht();
  }
  function te(s = 0) {
    xn();
    const r = N().proactive;
    if (!(!r.screenWatch || !at)) {
      if (Ut() >= r.dailyCap) {
        nt = setTimeout(te, Ln());
        return;
      }
      nt = setTimeout(fi, s > 0 ? s : r.screenWatchSec * 1e3);
    }
  }
  async function fi() {
    nt = null;
    const s = N().proactive;
    if (!s.screenWatch || !at || Ut() >= s.dailyCap) return;
    let r = null;
    try {
      const g = await d("screenshot_signature", { label: me });
      Array.isArray(g) && g.length && (r = g.map((S) => Number(S) || 0));
    } catch {
    }
    if (r) {
      const g = !!st && st.length === r.length && Rr(st, r) >= s.screenDiff;
      if (st = r, g && !y) {
        hi(s);
        return;
      }
    }
    te();
  }
  async function hi(s) {
    y = !0, await Ne(h("pet.watch_prompt")) ? (Nn(), q(H, { type: "proactive-used" }), A = setTimeout(() => {
      A = null, y && (y = !1);
    }, Tn)) : y = !1, st = null, te(Math.max(s.intervalMin, 1) * 6e4);
  }
  function na() {
    at = !1, Qt(!0), _t(), W == null || W.setRunning(!1), kt(), c(), wn(), xn(), st = null;
  }
  function aa() {
    at = !0, W ? W.setRunning(!0) : Ve(), k(), Ht(), te(), Ct(!0);
  }
  function ia() {
    I && (clearTimeout(I), I = null), Rt || (j = !0, ue(!0, !1, !1));
  }
  function mi() {
    J = !0, Y && clearTimeout(Y), Y = setTimeout(() => {
      Y = null, J = !1, kn();
    }, z);
  }
  function _n() {
    Y && (clearTimeout(Y), Y = null), J = !1, kn();
  }
  function kn() {
    at && ht === null && (J || gi());
  }
  function gi() {
    I && (clearTimeout(I), I = null), j && (I = setTimeout(() => {
      I = null, j = !1, Rt && ue(!1);
    }, Fr));
  }
  const ra = (s) => {
    s.key !== "Enter" || s.shiftKey || s.isComposing || (s.preventDefault(), B && m(B.value) && (B.value = ""));
  }, sa = () => ue(!1), bi = () => {
    l(!1), _n(), Te(h("pet.chat_reply_interrupted"), !0), q(Or).catch((s) => Et("中止 AI 消息失败", s));
  };
  B == null || B.addEventListener("keydown", ra), Z == null || Z.addEventListener("click", sa), it == null || it.addEventListener("click", bi);
  let $t = null;
  function yi(s, r) {
    if ($t && (clearInterval($t), $t = null), !s.length || !r) return;
    const g = 1e3 / r, S = performance.now();
    $t = setInterval(() => {
      const P = Math.floor((performance.now() - S) / g);
      if (P >= s.length) {
        $t && clearInterval($t), $t = null, W == null || W.setMouthOpen(null);
        return;
      }
      W == null || W.setMouthOpen(s[P] / 255);
    }, g);
  }
  const vi = await yt().listen(
    Pr,
    (s) => {
      var P, R;
      if (!Tt()) return;
      const g = (Array.isArray((P = s.payload) == null ? void 0 : P.env) ? s.payload.env : []).map((V) => typeof V == "number" && Number.isFinite(V) ? V : 0), S = typeof ((R = s.payload) == null ? void 0 : R.fps) == "number" && s.payload.fps > 0 ? s.payload.fps : 40;
      yi(g, S);
    }
  ), wi = await yt().listen(Ir, (s) => {
    var g;
    if (!Tt()) return;
    const r = typeof ((g = s.payload) == null ? void 0 : g.text) == "string" ? s.payload.text : "";
    l(!1), r && N().tts && (mi(), d("tts_speak", { text: r, enabled: !0 }).catch(() => {
      _n();
    })), at && ia(), i(r, () => kn()), F();
  }), xi = await yt().listen(Dr, () => {
    Tt() && _n();
  });
  _ == null || _.addEventListener("click", (s) => {
    var g;
    const r = (g = s.target.closest("button")) == null ? void 0 : g.dataset.act;
    r && (kt(), (async () => {
      if (r === "ai-chat") {
        ue(!Rt);
        return;
      }
      if (r === "settings") {
        await d("open_plugin_window", { pluginId: "pet", key: "settings", input: "" });
        return;
      }
      if (r === "look-screen") {
        await vn();
        return;
      }
      if (r === "change") {
        const S = await Pn({
          multiple: !1,
          directory: !0,
          title: "选择 Live2D 模型文件夹（里面要有 *.model3.json）"
        }), P = typeof S == "string" ? S : "";
        if (!P) return;
        let R = "", V = "";
        try {
          const Q = await d("scan_model_folder", { dir: P });
          R = (Q.model3 ?? [])[0] ?? "", V = (Q.vtube ?? [])[0] ?? "";
        } catch (Q) {
          rt("读文件夹失败", 2600), Et("更换模型：读文件夹失败", Q);
          return;
        }
        if (!R) {
          rt("这个文件夹里没有 *.model3.json", 2600);
          return;
        }
        const G = await Ra(R);
        if (!G.ok) {
          rt(`这个模型用不了：${G.reason}`, 3e3);
          return;
        }
        X({ ...N(), model: R, image: "" });
        try {
          await Vn(P, R, V);
        } catch (Q) {
          Et("更换模型：读取热键失败", Q);
        }
        _e();
        return;
      }
      if (r === "reset") {
        ke(1), Se(0, 0), pt(0), X(D), q(H, { type: "scale-changed", value: 1 }), q(H, { type: "rotation-changed", value: 0 }), rt("已恢复默认大小、位置与角度", 2e3);
        return;
      }
      if (r === "win-reset") {
        Lt = ve, Mt = se, D = { ...D, winW: ve, winH: se }, X(D), de = -1, Ct(!0), rt(h("pet.win_reset_done"), 2e3);
        return;
      }
      if (r === "through") {
        const S = !D.clickThrough;
        D = { ...D, clickThrough: S }, X(D), await Yt(S), Me(), q(H, { type: "click-through-changed", value: S });
        return;
      }
      r === "close" && await d("plugin_window_close").catch(() => {
      });
    })().catch((S) => Et("菜单动作失败", S)));
  });
  function _i(s) {
    const r = W;
    if (!r) {
      rt("桌宠还没显示 Live2D 模型", 2600);
      return;
    }
    switch (s.type) {
      case "motion":
        r.playMotion(s.group, s.index);
        break;
      case "chain":
        Le(s.id);
        break;
      case "expression":
        s.mode === "clear" || !s.target ? r.resetExpressions() : r.setExpression(s.target);
        break;
      case "param":
        r.setParameter(s.id, s.mode === "add" ? r.getParameter(s.id) + s.value : s.value);
        break;
      case "artmesh":
        r.setDrawableOpacity(s.id, s.value);
        break;
      case "part":
        r.setPartOpacity(s.id, s.value);
        break;
      case "physics":
        r.setPhysicsEnabled(s.enabled);
        break;
    }
  }
  const ee = /* @__PURE__ */ new Set(), oa = /* @__PURE__ */ new Map(), Sn = () => {
    q(H, { type: "hotkey-states", ids: [...ee] });
  };
  function ki() {
    const s = N().model.trim();
    if (!s) return;
    const r = [...ee].filter((P) => {
      const R = oa.get(P);
      return R !== "motion" && R !== "chain";
    }), g = N(), S = { ...g.hotkeyStates };
    r.length ? S[s] = r : delete S[s], X({ ...g, hotkeyStates: S });
  }
  async function Si(s) {
    const r = N().hotkeyStates[s] ?? [];
    if (!r.length) return;
    let g;
    try {
      g = await ge(s);
    } catch {
      return;
    }
    const S = new Map(g.map((P) => [P.id, P]));
    for (const P of r) {
      const R = S.get(P);
      !R || R.action.type === "motion" || ee.has(P) || await qe(P, R.action);
    }
  }
  async function Le(s) {
    const r = W, g = D.model.trim();
    if (!r || !g || !s) {
      rt("桌宠还没显示 Live2D 模型", 2600);
      return;
    }
    const P = (await tn(g)).find((G) => G.id === s);
    if (!P || !P.steps.length) {
      rt("这条动作链是空的", 2200);
      return;
    }
    const R = await Fe(g), V = P.steps.map((G) => ({ index: R.findIndex((ut) => ut.path.toLowerCase() === G.file.toLowerCase()), ms: Gn(G) * 1e3, hardMs: G.stopSec > 0 ? G.stopSec * 1e3 : 0 })).filter((G) => G.index >= 0);
    if (!V.length) {
      rt("动作链里的动作文件都不在了", 2400);
      return;
    }
    we = s, r.playChain(V, P.loop);
  }
  async function qe(s, r) {
    const g = W;
    if (!g) {
      rt("桌宠还没显示 Live2D 模型", 2600);
      return;
    }
    const S = !ee.has(s);
    switch (oa.set(s, r.type), r.type) {
      case "expression": {
        const P = r.file ? await Ba(r.file) : [];
        P.length ? g.setExpressionLayer(s, S ? P : null) : S ? r.target && g.setExpression(r.target) : g.resetExpressions();
        break;
      }
      case "artmesh":
        g.setDrawableOpacity(r.id, S ? r.value : 1);
        break;
      case "artmeshColor":
        g.setDrawableColor(r.id, S ? os(r.color) : null);
        break;
      case "part":
        g.setPartOpacity(r.id, S ? r.value : 1);
        break;
      case "physics":
        g.setPhysicsEnabled(S ? r.enabled : !r.enabled);
        break;
      case "param":
        g.setParameter(r.id, S ? r.value : 0);
        break;
      case "motion":
        S && g.playMotion(r.group, r.index);
        break;
      case "chain":
        S ? await Le(r.id) : (we = "", g.stopChain());
        break;
    }
    S ? ee.add(s) : ee.delete(s), Sn(), ki();
  }
  async function Mi(s, r, g) {
    const S = W, P = D.model.trim(), R = r.trim();
    if (!(!S || !P || !R)) {
      if (s === "auto") {
        const G = (await ge(P)).find((jt) => jt.keys.trim().toLowerCase() === R.toLowerCase());
        if (G) {
          await qe(G.id, G.action);
          return;
        }
        const ut = (await Fe(P)).findIndex((jt) => jt.name.trim().toLowerCase() === R.toLowerCase());
        if (ut >= 0) {
          S.playMotion(Dn, ut);
          return;
        }
        const ae = (await tn(P)).find((jt) => jt.name.trim().toLowerCase() === R.toLowerCase());
        if (ae) {
          await Le(ae.id);
          return;
        }
        S.setExpression(R);
        return;
      }
      if (s === "chain") {
        const V = await tn(P), G = V.find((Q) => Q.id === R) || V.find((Q) => Q.name.trim().toLowerCase() === R.toLowerCase());
        G && await Le(G.id);
        return;
      }
      if (s === "hotkey") {
        const V = await ge(P), G = V.find((Q) => Q.keys.trim().toLowerCase() === R.toLowerCase()) || V.find((Q) => Q.name.trim() === R);
        G && await qe(G.id, G.action);
        return;
      }
      if (s === "motion") {
        const G = (await Fe(P)).findIndex((Q) => Q.name.trim().toLowerCase() === R.toLowerCase());
        G >= 0 && S.playMotion(Dn, G);
        return;
      }
      if (s === "param") {
        S.setParameter(R, typeof g == "number" ? g : 0);
        return;
      }
      if (s === "expression") {
        g === 0 ? S.resetExpressions() : S.setExpression(R);
        return;
      }
      if (s === "artmeshColor") {
        const V = typeof g == "number" && Number.isFinite(g) ? Math.floor(g) : 16777215, G = Math.min(16777215, Math.max(0, V));
        S.setDrawableColor(R, {
          r: (G >> 16 & 255) / 255,
          g: (G >> 8 & 255) / 255,
          b: (G & 255) / 255
        });
      }
    }
  }
  const Ci = await ft(H, (s) => {
    const r = s.payload;
    if (r != null && r.type) {
      if (r.type === "ping") {
        Tt() && (q(H, { type: "pong", token: r.token, visible: at }), Sn());
        return;
      }
      if (r.type === "reload") {
        _e();
        return;
      }
      if (r.type === "hide" && Tt()) {
        na(), yt().hide().catch((g) => Et("隐藏模型失败", g));
        return;
      }
      if (r.type === "show" && Tt()) {
        (async () => {
          try {
            const g = yt();
            await g.unminimize().catch(() => {
            }), await g.show();
          } catch (g) {
            Et("显示模型失败", g);
          }
          aa();
        })();
        return;
      }
      if (r.type === "set-scale" && typeof r.value == "number") {
        X({ ...N(), scale: r.value }), ke(r.value);
        return;
      }
      if (r.type === "set-rotation" && typeof r.value == "number") {
        X({ ...N(), rotation: r.value }), pt(r.value);
        return;
      }
      if (r.type === "set-click-through" && typeof r.value == "boolean" && (D = { ...D, clickThrough: r.value }, Yt(r.value), Me()), r.type === "set-proactive") {
        const g = N(), S = en.proactive, P = (R, V, G, Q) => typeof R == "number" && Number.isFinite(R) ? Math.min(G, Math.max(V, Math.round(R))) : Q;
        X({
          ...g,
          proactive: {
            ...g.proactive,
            enabled: r.enabled === !0,
            intervalMin: P(r.intervalMin, Kn, Jn, g.proactive.intervalMin),
            dailyCap: P(r.dailyCap, Zn, Qn, g.proactive.dailyCap),
            // 子开关：**只有显式 true 才算开**（同 loadConfig 口径，默认关是隐私红线）。
            autoShot: r.autoShot === !0,
            autoShotMin: P(r.autoShotMin, rn, sn, S.autoShotMin),
            screenWatch: r.screenWatch === !0,
            screenWatchSec: P(r.screenWatchSec, on, ln, S.screenWatchSec),
            screenDiff: P(r.screenDiff, cn, pn, S.screenDiff)
          }
        }), k(!0), (r.screenWatch !== !0 || r.screenWatchSec !== g.proactive.screenWatchSec) && (st = null), Ht(), te();
        return;
      }
      if (r.type === "set-param" && typeof r.id == "string" && typeof r.value == "number") {
        W == null || W.setParameter(r.id, r.value);
        return;
      }
      if (r.type === "reset-params" && Array.isArray(r.ids)) {
        const g = W;
        if (g)
          for (const S of r.ids) typeof S == "string" && g.setParameter(S, 0);
        return;
      }
      if (r.type === "set-expression" && typeof r.id == "string") {
        if (!W) return;
        r.id ? W.setExpression(r.id) : W.resetExpressions();
        return;
      }
      if (r.type === "hotkey-run" && r.action && typeof r.action == "object") {
        _i(r.action);
        return;
      }
      if (r.type === "hotkey-toggle" && typeof r.id == "string" && r.action && typeof r.action == "object") {
        qe(r.id, r.action);
        return;
      }
      if (r.type === "motion-play" && typeof r.group == "string") {
        const g = W;
        if (!g) {
          rt("桌宠还没显示 Live2D 模型", 2600);
          return;
        }
        g.playMotion(r.group, typeof r.index == "number" ? r.index : 0);
        return;
      }
      if (r.type === "chain-play" && typeof r.id == "string" && Tt()) {
        Le(r.id);
        return;
      }
      r.type === "ai-action" && typeof r.action == "string" && typeof r.name == "string" && Mi(r.action, r.name, typeof r.value == "number" ? r.value : void 0);
    }
  }), $i = await ft(
    "plugin-window-visibility",
    (s) => {
      var r, g;
      (r = s.payload) != null && r.label && s.payload.label !== me || (((g = s.payload) == null ? void 0 : g.visible) === !1 ? na() : aa());
    }
  );
  ui(), d("plugin_window_set_resizable", { resizable: !0 }).catch(() => {
  });
  {
    const s = Hn(D.winW, D.winH);
    Lt = s.w, Mt = s.h;
  }
  Ct(!0);
  const Ei = await yt().onResized((s) => {
    if (!at) return;
    const r = s.payload, g = window.devicePixelRatio || 1, S = r.height / g, P = Sa(S);
    Zt > P && (Zt = P, Ge(P));
    const R = Zt;
    Wt && clearTimeout(Wt), Wt = setTimeout(() => {
      Wt = null;
      const V = Hn(r.width / g, Ar(S, R));
      V.w === Lt && V.h === Mt || (Lt = V.w, Mt = V.h, D = { ...D, winW: V.w, winH: V.h }, X(D));
    }, 250);
  });
  _e(), D.clickThrough && await Yt(!0), q(H, { type: "click-through-changed", value: D.clickThrough }), k(!0), Ht(), te();
  const Ti = await ft("pet-alt-rclick", (s) => {
    var S, P;
    if (!Tt()) return;
    const r = Number((S = s.payload) == null ? void 0 : S.x), g = Number((P = s.payload) == null ? void 0 : P.y);
    !Number.isFinite(r) || !Number.isFinite(g) || yn(r, g).catch((R) => Et("Alt+右键唤出菜单失败", R));
  });
  ie = () => {
    _t(), le(), Dt && clearTimeout(Dt), u(), wn(), xn(), A && clearTimeout(A), I && clearTimeout(I), Y && clearTimeout(Y), Wt && clearTimeout(Wt), $t && (clearInterval($t), $t = null), Ci(), $i(), Ti(), wi(), xi(), vi(), Ei(), W == null || W.setMouthOpen(null), B == null || B.removeEventListener("keydown", ra), Z == null || Z.removeEventListener("click", sa), window.removeEventListener("mousemove", Ce), window.removeEventListener("mouseup", $e), d("pet_alt_rclick_watch", { on: !1 }).catch(() => {
    });
  };
}
const hs = {
  id: "pet",
  name: "桌宠",
  keywords: ["桌宠", "宠物", "桌面宠物", "pet", "desktop pet", "live2d", "看板娘", "吉祥物"],
  description: "桌宠 —— 独立透明置顶的桌面形象窗（图片或 Live2D 模型，由你自己导入）",
  icon: "🐾",
  // **刻意不声明 `window.float`**：它的入口是**带 key 的附属窗**（`plugin-pet-settings`），
  // 不是自己的形象窗 —— `main.ts` 的 `executePlugin` 按 id 特判直接开那扇窗（2026-10-09）。
  permissions: [],
  async execute(e) {
    return Tt() ? { type: "html", content: us() } : Ca() ? { type: "html", content: cs(N()) } : { type: "html", content: "" };
  },
  async attach(e) {
    if (Tt()) {
      await fs(e);
      return;
    }
    if (Ca()) {
      await ps(e);
      return;
    }
  },
  detach() {
    ie == null || ie(), ie = null;
  }
};
export {
  hs as default
};
