function Ui(e, t, n, a) {
  if (typeof t == "function" ? e !== t || !a : !t.has(e)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return n === "m" ? a : n === "a" ? a.call(e) : a ? a.value : t.get(e);
}
function qi(e, t, n, a, o) {
  if (typeof t == "function" ? e !== t || !0 : !t.has(e)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return t.set(e, n), n;
}
var an;
const wt = "__TAURI_TO_IPC_KEY__";
function Yi(e, t = !1) {
  return window.__TAURI_INTERNALS__.transformCallback(e, t);
}
async function d(e, t = {}, n) {
  return window.__TAURI_INTERNALS__.invoke(e, t, n);
}
function Ft(e, t = "asset") {
  return window.__TAURI_INTERNALS__.convertFileSrc(e, t);
}
class Xi {
  get rid() {
    return Ui(this, an, "f");
  }
  constructor(t) {
    an.set(this, void 0), qi(this, an, t);
  }
  /**
   * Destroys and cleans up this resource from memory.
   * **You should not call any method on this object anymore and should drop any reference to it.**
   */
  async close() {
    return d("plugin:resources|close", {
      rid: this.rid
    });
  }
}
an = /* @__PURE__ */ new WeakMap();
var mt;
(function(e) {
  e.WINDOW_RESIZED = "tauri://resize", e.WINDOW_MOVED = "tauri://move", e.WINDOW_CLOSE_REQUESTED = "tauri://close-requested", e.WINDOW_DESTROYED = "tauri://destroyed", e.WINDOW_FOCUS = "tauri://focus", e.WINDOW_BLUR = "tauri://blur", e.WINDOW_SCALE_FACTOR_CHANGED = "tauri://scale-change", e.WINDOW_THEME_CHANGED = "tauri://theme-changed", e.WINDOW_CREATED = "tauri://window-created", e.WINDOW_SUSPENDED = "tauri://suspended", e.WINDOW_RESUMED = "tauri://resumed", e.WEBVIEW_CREATED = "tauri://webview-created", e.DRAG_ENTER = "tauri://drag-enter", e.DRAG_OVER = "tauri://drag-over", e.DRAG_DROP = "tauri://drag-drop", e.DRAG_LEAVE = "tauri://drag-leave";
})(mt || (mt = {}));
async function Ga(e, t) {
  window.__TAURI_EVENT_PLUGIN_INTERNALS__.unregisterListener(e, t), await d("plugin:event|unlisten", {
    event: e,
    eventId: t
  });
}
async function ht(e, t, n) {
  var a;
  const o = typeof (n == null ? void 0 : n.target) == "string" ? { kind: "AnyLabel", label: n.target } : (a = n == null ? void 0 : n.target) !== null && a !== void 0 ? a : { kind: "Any" };
  return d("plugin:event|listen", {
    event: e,
    target: o,
    handler: Yi(t)
  }).then((c) => async () => Ga(e, c));
}
async function Ki(e, t, n) {
  return ht(e, (a) => {
    Ga(e, a.id), t(a);
  }, n);
}
async function Y(e, t) {
  await d("plugin:event|emit", {
    event: e,
    payload: t
  });
}
async function Ji(e, t, n) {
  await d("plugin:event|emit_to", {
    target: typeof e == "string" ? { kind: "AnyLabel", label: e } : e,
    event: t,
    payload: n
  });
}
class Ua {
  constructor(...t) {
    this.type = "Logical", t.length === 1 ? "Logical" in t[0] ? (this.width = t[0].Logical.width, this.height = t[0].Logical.height) : (this.width = t[0].width, this.height = t[0].height) : (this.width = t[0], this.height = t[1]);
  }
  /**
   * Converts the logical size to a physical one.
   * @example
   * ```typescript
   * import { LogicalSize } from '@tauri-apps/api/dpi';
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   *
   * const appWindow = getCurrentWindow();
   * const factor = await appWindow.scaleFactor();
   * const size = new LogicalSize(400, 500);
   * const physical = size.toPhysical(factor);
   * ```
   *
   * @since 2.0.0
   */
  toPhysical(t) {
    return new je(this.width * t, this.height * t);
  }
  [wt]() {
    return {
      width: this.width,
      height: this.height
    };
  }
  toJSON() {
    return this[wt]();
  }
}
class je {
  constructor(...t) {
    this.type = "Physical", t.length === 1 ? "Physical" in t[0] ? (this.width = t[0].Physical.width, this.height = t[0].Physical.height) : (this.width = t[0].width, this.height = t[0].height) : (this.width = t[0], this.height = t[1]);
  }
  /**
   * Converts the physical size to a logical one.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const appWindow = getCurrentWindow();
   * const factor = await appWindow.scaleFactor();
   * const size = await appWindow.innerSize(); // PhysicalSize
   * const logical = size.toLogical(factor);
   * ```
   */
  toLogical(t) {
    return new Ua(this.width / t, this.height / t);
  }
  [wt]() {
    return {
      width: this.width,
      height: this.height
    };
  }
  toJSON() {
    return this[wt]();
  }
}
class be {
  constructor(t) {
    this.size = t;
  }
  toLogical(t) {
    return this.size instanceof Ua ? this.size : this.size.toLogical(t);
  }
  toPhysical(t) {
    return this.size instanceof je ? this.size : this.size.toPhysical(t);
  }
  [wt]() {
    return {
      [`${this.size.type}`]: {
        width: this.size.width,
        height: this.size.height
      }
    };
  }
  toJSON() {
    return this[wt]();
  }
}
class qa {
  constructor(...t) {
    this.type = "Logical", t.length === 1 ? "Logical" in t[0] ? (this.x = t[0].Logical.x, this.y = t[0].Logical.y) : (this.x = t[0].x, this.y = t[0].y) : (this.x = t[0], this.y = t[1]);
  }
  /**
   * Converts the logical position to a physical one.
   * @example
   * ```typescript
   * import { LogicalPosition } from '@tauri-apps/api/dpi';
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   *
   * const appWindow = getCurrentWindow();
   * const factor = await appWindow.scaleFactor();
   * const position = new LogicalPosition(400, 500);
   * const physical = position.toPhysical(factor);
   * ```
   *
   * @since 2.0.0
   */
  toPhysical(t) {
    return new qt(this.x * t, this.y * t);
  }
  [wt]() {
    return {
      x: this.x,
      y: this.y
    };
  }
  toJSON() {
    return this[wt]();
  }
}
class qt {
  constructor(...t) {
    this.type = "Physical", t.length === 1 ? "Physical" in t[0] ? (this.x = t[0].Physical.x, this.y = t[0].Physical.y) : (this.x = t[0].x, this.y = t[0].y) : (this.x = t[0], this.y = t[1]);
  }
  /**
   * Converts the physical position to a logical one.
   * @example
   * ```typescript
   * import { PhysicalPosition } from '@tauri-apps/api/dpi';
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   *
   * const appWindow = getCurrentWindow();
   * const factor = await appWindow.scaleFactor();
   * const position = new PhysicalPosition(400, 500);
   * const physical = position.toLogical(factor);
   * ```
   *
   * @since 2.0.0
   */
  toLogical(t) {
    return new qa(this.x / t, this.y / t);
  }
  [wt]() {
    return {
      x: this.x,
      y: this.y
    };
  }
  toJSON() {
    return this[wt]();
  }
}
class Ze {
  constructor(t) {
    this.position = t;
  }
  toLogical(t) {
    return this.position instanceof qa ? this.position : this.position.toLogical(t);
  }
  toPhysical(t) {
    return this.position instanceof qt ? this.position : this.position.toPhysical(t);
  }
  [wt]() {
    return {
      [`${this.position.type}`]: {
        x: this.position.x,
        y: this.position.y
      }
    };
  }
  toJSON() {
    return this[wt]();
  }
}
class Be extends Xi {
  /**
   * Creates an Image from a resource ID. For internal use only.
   *
   * @ignore
   */
  constructor(t) {
    super(t);
  }
  /** Creates a new Image using RGBA data, in row-major order from top to bottom, and with specified width and height. */
  static async new(t, n, a) {
    return d("plugin:image|new", {
      rgba: on(t),
      width: n,
      height: a
    }).then((o) => new Be(o));
  }
  /**
   * Creates a new image using the provided bytes by inferring the file format.
   * If the format is known, prefer [@link Image.fromPngBytes] or [@link Image.fromIcoBytes].
   *
   * Only `ico` and `png` are supported (based on activated feature flag).
   *
   * Note that you need the `image-ico` or `image-png` Cargo features to use this API.
   * To enable it, change your Cargo.toml file:
   * ```toml
   * [dependencies]
   * tauri = { version = "...", features = ["...", "image-png"] }
   * ```
   */
  static async fromBytes(t) {
    return d("plugin:image|from_bytes", {
      bytes: on(t)
    }).then((n) => new Be(n));
  }
  /**
   * Creates a new image using the provided path.
   *
   * Only `ico` and `png` are supported (based on activated feature flag).
   *
   * Note that you need the `image-ico` or `image-png` Cargo features to use this API.
   * To enable it, change your Cargo.toml file:
   * ```toml
   * [dependencies]
   * tauri = { version = "...", features = ["...", "image-png"] }
   * ```
   */
  static async fromPath(t) {
    return d("plugin:image|from_path", { path: t }).then((n) => new Be(n));
  }
  /** Returns the RGBA data for this image, in row-major order from top to bottom.  */
  async rgba() {
    return d("plugin:image|rgba", {
      rid: this.rid
    }).then((t) => new Uint8Array(t));
  }
  /** Returns the size of this image.  */
  async size() {
    return d("plugin:image|size", { rid: this.rid });
  }
}
function on(e) {
  return e == null ? null : typeof e == "string" ? e : e instanceof Be ? e.rid : e;
}
var In;
(function(e) {
  e[e.Critical = 1] = "Critical", e[e.Informational = 2] = "Informational";
})(In || (In = {}));
class Zi {
  constructor(t) {
    this._preventDefault = !1, this.event = t.event, this.id = t.id;
  }
  preventDefault() {
    this._preventDefault = !0;
  }
  isPreventDefault() {
    return this._preventDefault;
  }
}
var xa;
(function(e) {
  e.None = "none", e.Normal = "normal", e.Indeterminate = "indeterminate", e.Paused = "paused", e.Error = "error";
})(xa || (xa = {}));
function xt() {
  return new Ya(window.__TAURI_INTERNALS__.metadata.currentWindow.label, {
    // @ts-expect-error `skip` is not defined in the public API but it is handled by the constructor
    skip: !0
  });
}
async function En() {
  return d("plugin:window|get_all_windows").then((e) => e.map((t) => new Ya(t, {
    // @ts-expect-error `skip` is not defined in the public API but it is handled by the constructor
    skip: !0
  })));
}
const Cn = ["tauri://created", "tauri://error"];
class Ya {
  /**
   * Creates a new Window.
   * @example
   * ```typescript
   * import { Window } from '@tauri-apps/api/window';
   * const appWindow = new Window('my-label');
   * appWindow.once('tauri://created', function () {
   *  // window successfully created
   * });
   * appWindow.once('tauri://error', function (e) {
   *  // an error happened creating the window
   * });
   * ```
   *
   * @param label The unique window label. Must be alphanumeric: `a-zA-Z-/:_`.
   * @returns The {@link Window} instance to communicate with the window.
   */
  constructor(t, n = {}) {
    var a;
    this.label = t, this.listeners = /* @__PURE__ */ Object.create(null), n != null && n.skip || d("plugin:window|create", {
      options: {
        ...n,
        parent: typeof n.parent == "string" ? n.parent : (a = n.parent) === null || a === void 0 ? void 0 : a.label,
        label: t
      }
    }).then(async () => this.emit("tauri://created")).catch(async (o) => this.emit("tauri://error", o));
  }
  /**
   * Gets the Window associated with the given label.
   * @example
   * ```typescript
   * import { Window } from '@tauri-apps/api/window';
   * const mainWindow = Window.getByLabel('main');
   * ```
   *
   * @param label The window label.
   * @returns The Window instance to communicate with the window or null if the window doesn't exist.
   */
  static async getByLabel(t) {
    var n;
    return (n = (await En()).find((a) => a.label === t)) !== null && n !== void 0 ? n : null;
  }
  /**
   * Get an instance of `Window` for the current window.
   */
  static getCurrent() {
    return xt();
  }
  /**
   * Gets a list of instances of `Window` for all available windows.
   */
  static async getAll() {
    return En();
  }
  /**
   *  Gets the focused window.
   * @example
   * ```typescript
   * import { Window } from '@tauri-apps/api/window';
   * const focusedWindow = Window.getFocusedWindow();
   * ```
   *
   * @returns The Window instance or `undefined` if there is not any focused window.
   */
  static async getFocusedWindow() {
    for (const t of await En())
      if (await t.isFocused())
        return t;
    return null;
  }
  /**
   * Listen to an emitted event on this window.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const unlisten = await getCurrentWindow().listen<string>('state-changed', (event) => {
   *   console.log(`Got error: ${payload}`);
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @param event Event name. Must include only alphanumeric characters, `-`, `/`, `:` and `_`.
   * @param handler Event handler.
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async listen(t, n) {
    return this._handleTauriEvent(t, n) ? () => {
      const a = this.listeners[t];
      a.splice(a.indexOf(n), 1);
    } : ht(t, n, {
      target: { kind: "Window", label: this.label }
    });
  }
  /**
   * Listen to an emitted event on this window only once.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const unlisten = await getCurrentWindow().once<null>('initialized', (event) => {
   *   console.log(`Window initialized!`);
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @param event Event name. Must include only alphanumeric characters, `-`, `/`, `:` and `_`.
   * @param handler Event handler.
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async once(t, n) {
    return this._handleTauriEvent(t, n) ? () => {
      const a = this.listeners[t];
      a.splice(a.indexOf(n), 1);
    } : Ki(t, n, {
      target: { kind: "Window", label: this.label }
    });
  }
  /**
   * Emits an event to all {@link EventTarget|targets}.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().emit('window-loaded', { loggedIn: true, token: 'authToken' });
   * ```
   *
   * @param event Event name. Must include only alphanumeric characters, `-`, `/`, `:` and `_`.
   * @param payload Event payload.
   */
  async emit(t, n) {
    if (Cn.includes(t)) {
      for (const a of this.listeners[t] || [])
        a({
          event: t,
          id: -1,
          payload: n
        });
      return;
    }
    return Y(t, n);
  }
  /**
   * Emits an event to all {@link EventTarget|targets} matching the given target.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().emit('main', 'window-loaded', { loggedIn: true, token: 'authToken' });
   * ```
   * @param target Label of the target Window/Webview/WebviewWindow or raw {@link EventTarget} object.
   * @param event Event name. Must include only alphanumeric characters, `-`, `/`, `:` and `_`.
   * @param payload Event payload.
   */
  async emitTo(t, n, a) {
    if (Cn.includes(n)) {
      for (const o of this.listeners[n] || [])
        o({
          event: n,
          id: -1,
          payload: a
        });
      return;
    }
    return Ji(t, n, a);
  }
  /** @ignore */
  _handleTauriEvent(t, n) {
    return Cn.includes(t) ? (t in this.listeners ? this.listeners[t].push(n) : this.listeners[t] = [n], !0) : !1;
  }
  // Getters
  /**
   * The scale factor that can be used to map physical pixels to logical pixels.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const factor = await getCurrentWindow().scaleFactor();
   * ```
   *
   * @returns The window's monitor scale factor.
   */
  async scaleFactor() {
    return d("plugin:window|scale_factor", {
      label: this.label
    });
  }
  /**
   * The position of the top-left hand corner of the window's client area relative to the top-left hand corner of the desktop.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const position = await getCurrentWindow().innerPosition();
   * ```
   *
   * @returns The window's inner position.
   */
  async innerPosition() {
    return d("plugin:window|inner_position", {
      label: this.label
    }).then((t) => new qt(t));
  }
  /**
   * The position of the top-left hand corner of the window relative to the top-left hand corner of the desktop.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const position = await getCurrentWindow().outerPosition();
   * ```
   *
   * @returns The window's outer position.
   */
  async outerPosition() {
    return d("plugin:window|outer_position", {
      label: this.label
    }).then((t) => new qt(t));
  }
  /**
   * The physical size of the window's client area.
   * The client area is the content of the window, excluding the title bar and borders.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const size = await getCurrentWindow().innerSize();
   * ```
   *
   * @returns The window's inner size.
   */
  async innerSize() {
    return d("plugin:window|inner_size", {
      label: this.label
    }).then((t) => new je(t));
  }
  /**
   * The physical size of the entire window.
   * These dimensions include the title bar and borders. If you don't want that (and you usually don't), use inner_size instead.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const size = await getCurrentWindow().outerSize();
   * ```
   *
   * @returns The window's outer size.
   */
  async outerSize() {
    return d("plugin:window|outer_size", {
      label: this.label
    }).then((t) => new je(t));
  }
  /**
   * Gets the window's current fullscreen state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const fullscreen = await getCurrentWindow().isFullscreen();
   * ```
   *
   * @returns Whether the window is in fullscreen mode or not.
   */
  async isFullscreen() {
    return d("plugin:window|is_fullscreen", {
      label: this.label
    });
  }
  /**
   * Gets the window's current minimized state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const minimized = await getCurrentWindow().isMinimized();
   * ```
   */
  async isMinimized() {
    return d("plugin:window|is_minimized", {
      label: this.label
    });
  }
  /**
   * Gets the window's current maximized state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const maximized = await getCurrentWindow().isMaximized();
   * ```
   *
   * @returns Whether the window is maximized or not.
   */
  async isMaximized() {
    return d("plugin:window|is_maximized", {
      label: this.label
    });
  }
  /**
   * Gets the window's current focus state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const focused = await getCurrentWindow().isFocused();
   * ```
   *
   * @returns Whether the window is focused or not.
   */
  async isFocused() {
    return d("plugin:window|is_focused", {
      label: this.label
    });
  }
  /**
   * Gets the window's current decorated state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const decorated = await getCurrentWindow().isDecorated();
   * ```
   *
   * @returns Whether the window is decorated or not.
   */
  async isDecorated() {
    return d("plugin:window|is_decorated", {
      label: this.label
    });
  }
  /**
   * Gets the window's current resizable state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const resizable = await getCurrentWindow().isResizable();
   * ```
   *
   * @returns Whether the window is resizable or not.
   */
  async isResizable() {
    return d("plugin:window|is_resizable", {
      label: this.label
    });
  }
  /**
   * Gets the window's native maximize button state.
   *
   * #### Platform-specific
   *
   * - **Linux / iOS / Android:** Unsupported.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const maximizable = await getCurrentWindow().isMaximizable();
   * ```
   *
   * @returns Whether the window's native maximize button is enabled or not.
   */
  async isMaximizable() {
    return d("plugin:window|is_maximizable", {
      label: this.label
    });
  }
  /**
   * Gets the window's native minimize button state.
   *
   * #### Platform-specific
   *
   * - **Linux / iOS / Android:** Unsupported.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const minimizable = await getCurrentWindow().isMinimizable();
   * ```
   *
   * @returns Whether the window's native minimize button is enabled or not.
   */
  async isMinimizable() {
    return d("plugin:window|is_minimizable", {
      label: this.label
    });
  }
  /**
   * Gets the window's native close button state.
   *
   * #### Platform-specific
   *
   * - **iOS / Android:** Unsupported.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const closable = await getCurrentWindow().isClosable();
   * ```
   *
   * @returns Whether the window's native close button is enabled or not.
   */
  async isClosable() {
    return d("plugin:window|is_closable", {
      label: this.label
    });
  }
  /**
   * Gets the window's current visible state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const visible = await getCurrentWindow().isVisible();
   * ```
   *
   * @returns Whether the window is visible or not.
   */
  async isVisible() {
    return d("plugin:window|is_visible", {
      label: this.label
    });
  }
  /**
   * Gets the window's current title.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const title = await getCurrentWindow().title();
   * ```
   */
  async title() {
    return d("plugin:window|title", {
      label: this.label
    });
  }
  /**
   * Gets the window's current theme.
   *
   * #### Platform-specific
   *
   * - **macOS:** Theme was introduced on macOS 10.14. Returns `light` on macOS 10.13 and below.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const theme = await getCurrentWindow().theme();
   * ```
   *
   * @returns The window theme.
   */
  async theme() {
    return d("plugin:window|theme", {
      label: this.label
    });
  }
  /**
   * Whether the window is configured to be always on top of other windows or not.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const alwaysOnTop = await getCurrentWindow().isAlwaysOnTop();
   * ```
   *
   * @returns Whether the window is visible or not.
   */
  async isAlwaysOnTop() {
    return d("plugin:window|is_always_on_top", {
      label: this.label
    });
  }
  async activityName() {
    return d("plugin:window|activity_name", {
      label: this.label
    });
  }
  async sceneIdentifier() {
    return d("plugin:window|scene_identifier", {
      label: this.label
    });
  }
  // Setters
  /**
   * Centers the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().center();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async center() {
    return d("plugin:window|center", {
      label: this.label
    });
  }
  /**
   *  Requests user attention to the window, this has no effect if the application
   * is already focused. How requesting for user attention manifests is platform dependent,
   * see `UserAttentionType` for details.
   *
   * Providing `null` will unset the request for user attention. Unsetting the request for
   * user attention might not be done automatically by the WM when the window receives input.
   *
   * #### Platform-specific
   *
   * - **macOS:** `null` has no effect.
   * - **Linux:** Urgency levels have the same effect.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().requestUserAttention();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async requestUserAttention(t) {
    let n = null;
    return t && (t === In.Critical ? n = { type: "Critical" } : n = { type: "Informational" }), d("plugin:window|request_user_attention", {
      label: this.label,
      value: n
    });
  }
  /**
   * Updates the window resizable flag.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setResizable(false);
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async setResizable(t) {
    return d("plugin:window|set_resizable", {
      label: this.label,
      value: t
    });
  }
  /**
   * Enable or disable the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setEnabled(false);
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   *
   * @since 2.0.0
   */
  async setEnabled(t) {
    return d("plugin:window|set_enabled", {
      label: this.label,
      value: t
    });
  }
  /**
   * Whether the window is enabled or disabled.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setEnabled(false);
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   *
   * @since 2.0.0
   */
  async isEnabled() {
    return d("plugin:window|is_enabled", {
      label: this.label
    });
  }
  /**
   * Sets whether the window's native maximize button is enabled or not.
   * If resizable is set to false, this setting is ignored.
   *
   * #### Platform-specific
   *
   * - **macOS:** Disables the "zoom" button in the window titlebar, which is also used to enter fullscreen mode.
   * - **Linux / iOS / Android:** Unsupported.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setMaximizable(false);
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async setMaximizable(t) {
    return d("plugin:window|set_maximizable", {
      label: this.label,
      value: t
    });
  }
  /**
   * Sets whether the window's native minimize button is enabled or not.
   *
   * #### Platform-specific
   *
   * - **Linux / iOS / Android:** Unsupported.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setMinimizable(false);
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async setMinimizable(t) {
    return d("plugin:window|set_minimizable", {
      label: this.label,
      value: t
    });
  }
  /**
   * Sets whether the window's native close button is enabled or not.
   *
   * #### Platform-specific
   *
   * - **Linux:** GTK+ will do its best to convince the window manager not to show a close button. Depending on the system, this function may not have any effect when called on a window that is already visible
   * - **iOS / Android:** Unsupported.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setClosable(false);
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async setClosable(t) {
    return d("plugin:window|set_closable", {
      label: this.label,
      value: t
    });
  }
  /**
   * Sets the window title.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setTitle('Tauri');
   * ```
   *
   * @param title The new title
   * @returns A promise indicating the success or failure of the operation.
   */
  async setTitle(t) {
    return d("plugin:window|set_title", {
      label: this.label,
      value: t
    });
  }
  /**
   * Maximizes the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().maximize();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async maximize() {
    return d("plugin:window|maximize", {
      label: this.label
    });
  }
  /**
   * Unmaximizes the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().unmaximize();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async unmaximize() {
    return d("plugin:window|unmaximize", {
      label: this.label
    });
  }
  /**
   * Toggles the window maximized state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().toggleMaximize();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async toggleMaximize() {
    return d("plugin:window|toggle_maximize", {
      label: this.label
    });
  }
  /**
   * Minimizes the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().minimize();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async minimize() {
    return d("plugin:window|minimize", {
      label: this.label
    });
  }
  /**
   * Unminimizes the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().unminimize();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async unminimize() {
    return d("plugin:window|unminimize", {
      label: this.label
    });
  }
  /**
   * Sets the window visibility to true.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().show();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async show() {
    return d("plugin:window|show", {
      label: this.label
    });
  }
  /**
   * Sets the window visibility to false.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().hide();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async hide() {
    return d("plugin:window|hide", {
      label: this.label
    });
  }
  /**
   * Closes the window.
   *
   * Note this emits a closeRequested event so you can intercept it. To force window close, use {@link Window.destroy}.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().close();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async close() {
    return d("plugin:window|close", {
      label: this.label
    });
  }
  /**
   * Destroys the window. Behaves like {@link Window.close} but forces the window close instead of emitting a closeRequested event.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().destroy();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async destroy() {
    return d("plugin:window|destroy", {
      label: this.label
    });
  }
  /**
   * Whether the window should have borders and bars.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setDecorations(false);
   * ```
   *
   * @param decorations Whether the window should have borders and bars.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setDecorations(t) {
    return d("plugin:window|set_decorations", {
      label: this.label,
      value: t
    });
  }
  /**
   * Whether or not the window should have shadow.
   *
   * #### Platform-specific
   *
   * - **Windows:**
   *   - `false` has no effect on decorated window, shadows are always ON.
   *   - `true` will make undecorated window have a 1px white border,
   * and on Windows 11, it will have a rounded corners.
   * - **Linux:** Unsupported.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setShadow(false);
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async setShadow(t) {
    return d("plugin:window|set_shadow", {
      label: this.label,
      value: t
    });
  }
  /**
   * Set window effects.
   */
  async setEffects(t) {
    return d("plugin:window|set_effects", {
      label: this.label,
      value: t
    });
  }
  /**
   * Clear any applied effects if possible.
   */
  async clearEffects() {
    return d("plugin:window|set_effects", {
      label: this.label,
      value: null
    });
  }
  /**
   * Whether the window should always be on top of other windows.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setAlwaysOnTop(true);
   * ```
   *
   * @param alwaysOnTop Whether the window should always be on top of other windows or not.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setAlwaysOnTop(t) {
    return d("plugin:window|set_always_on_top", {
      label: this.label,
      value: t
    });
  }
  /**
   * Whether the window should always be below other windows.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setAlwaysOnBottom(true);
   * ```
   *
   * @param alwaysOnBottom Whether the window should always be below other windows or not.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setAlwaysOnBottom(t) {
    return d("plugin:window|set_always_on_bottom", {
      label: this.label,
      value: t
    });
  }
  /**
   * Prevents the window contents from being captured by other apps.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setContentProtected(true);
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async setContentProtected(t) {
    return d("plugin:window|set_content_protected", {
      label: this.label,
      value: t
    });
  }
  /**
   * Resizes the window with a new inner size.
   * @example
   * ```typescript
   * import { getCurrentWindow, LogicalSize } from '@tauri-apps/api/window';
   * await getCurrentWindow().setSize(new LogicalSize(600, 500));
   * ```
   *
   * @param size The logical or physical inner size.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setSize(t) {
    return d("plugin:window|set_size", {
      label: this.label,
      value: t instanceof be ? t : new be(t)
    });
  }
  /**
   * Sets the window minimum inner size. If the `size` argument is not provided, the constraint is unset.
   * @example
   * ```typescript
   * import { getCurrentWindow, PhysicalSize } from '@tauri-apps/api/window';
   * await getCurrentWindow().setMinSize(new PhysicalSize(600, 500));
   * ```
   *
   * @param size The logical or physical inner size, or `null` to unset the constraint.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setMinSize(t) {
    return d("plugin:window|set_min_size", {
      label: this.label,
      value: t instanceof be ? t : t ? new be(t) : null
    });
  }
  /**
   * Sets the window maximum inner size. If the `size` argument is undefined, the constraint is unset.
   * @example
   * ```typescript
   * import { getCurrentWindow, LogicalSize } from '@tauri-apps/api/window';
   * await getCurrentWindow().setMaxSize(new LogicalSize(600, 500));
   * ```
   *
   * @param size The logical or physical inner size, or `null` to unset the constraint.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setMaxSize(t) {
    return d("plugin:window|set_max_size", {
      label: this.label,
      value: t instanceof be ? t : t ? new be(t) : null
    });
  }
  /**
   * Sets the window inner size constraints.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setSizeConstraints({ minWidth: 300 });
   * ```
   *
   * @param constraints The logical or physical inner size, or `null` to unset the constraint.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setSizeConstraints(t) {
    function n(a) {
      return a ? { Logical: a } : null;
    }
    return d("plugin:window|set_size_constraints", {
      label: this.label,
      value: {
        minWidth: n(t == null ? void 0 : t.minWidth),
        minHeight: n(t == null ? void 0 : t.minHeight),
        maxWidth: n(t == null ? void 0 : t.maxWidth),
        maxHeight: n(t == null ? void 0 : t.maxHeight)
      }
    });
  }
  /**
   * Sets the window outer position.
   * @example
   * ```typescript
   * import { getCurrentWindow, LogicalPosition } from '@tauri-apps/api/window';
   * await getCurrentWindow().setPosition(new LogicalPosition(600, 500));
   * ```
   *
   * @param position The new position, in logical or physical pixels.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setPosition(t) {
    return d("plugin:window|set_position", {
      label: this.label,
      value: t instanceof Ze ? t : new Ze(t)
    });
  }
  /**
   * Sets the window fullscreen state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setFullscreen(true);
   * ```
   *
   * @param fullscreen Whether the window should go to fullscreen or not.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setFullscreen(t) {
    return d("plugin:window|set_fullscreen", {
      label: this.label,
      value: t
    });
  }
  /**
   * On macOS, Toggles a fullscreen mode that doesn’t require a new macOS space. Returns a boolean indicating whether the transition was successful (this won’t work if the window was already in the native fullscreen).
   * This is how fullscreen used to work on macOS in versions before Lion. And allows the user to have a fullscreen window without using another space or taking control over the entire monitor.
   *
   * On other platforms, this is the same as {@link Window.setFullscreen}.
   *
   * @param fullscreen Whether the window should go to simple fullscreen or not.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setSimpleFullscreen(t) {
    return d("plugin:window|set_simple_fullscreen", {
      label: this.label,
      value: t
    });
  }
  /**
   * Bring the window to front and focus.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setFocus();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async setFocus() {
    return d("plugin:window|set_focus", {
      label: this.label
    });
  }
  /**
   * Sets whether the window can be focused.
   *
   * #### Platform-specific
   *
   * - **macOS**: If the window is already focused, it is not possible to unfocus it after calling `set_focusable(false)`.
   *   In this case, you might consider calling {@link Window.setFocus} but it will move the window to the back i.e. at the bottom in terms of z-order.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setFocusable(true);
   * ```
   *
   * @param focusable Whether the window can be focused.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setFocusable(t) {
    return d("plugin:window|set_focusable", {
      label: this.label,
      value: t
    });
  }
  /**
   * Sets the window icon.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setIcon('/tauri/awesome.png');
   * ```
   *
   * Note that you may need the `image-ico` or `image-png` Cargo features to use this API.
   * To enable it, change your Cargo.toml file:
   * ```toml
   * [dependencies]
   * tauri = { version = "...", features = ["...", "image-png"] }
   * ```
   *
   * @param icon Icon bytes or path to the icon file.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setIcon(t) {
    return d("plugin:window|set_icon", {
      label: this.label,
      value: on(t)
    });
  }
  /**
   * Whether the window icon should be hidden from the taskbar or not.
   *
   * #### Platform-specific
   *
   * - **macOS:** Unsupported.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setSkipTaskbar(true);
   * ```
   *
   * @param skip true to hide window icon, false to show it.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setSkipTaskbar(t) {
    return d("plugin:window|set_skip_taskbar", {
      label: this.label,
      value: t
    });
  }
  /**
   * Grabs the cursor, preventing it from leaving the window.
   *
   * There's no guarantee that the cursor will be hidden. You should
   * hide it by yourself if you want so.
   *
   * #### Platform-specific
   *
   * - **Linux:** Unsupported.
   * - **macOS:** This locks the cursor in a fixed location, which looks visually awkward.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setCursorGrab(true);
   * ```
   *
   * @param grab `true` to grab the cursor icon, `false` to release it.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setCursorGrab(t) {
    return d("plugin:window|set_cursor_grab", {
      label: this.label,
      value: t
    });
  }
  /**
   * Modifies the cursor's visibility.
   *
   * #### Platform-specific
   *
   * - **Windows:** The cursor is only hidden within the confines of the window.
   * - **macOS:** The cursor is hidden as long as the window has input focus, even if the cursor is
   *   outside of the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setCursorVisible(false);
   * ```
   *
   * @param visible If `false`, this will hide the cursor. If `true`, this will show the cursor.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setCursorVisible(t) {
    return d("plugin:window|set_cursor_visible", {
      label: this.label,
      value: t
    });
  }
  /**
   * Modifies the cursor icon of the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setCursorIcon('help');
   * ```
   *
   * @param icon The new cursor icon.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setCursorIcon(t) {
    return d("plugin:window|set_cursor_icon", {
      label: this.label,
      value: t
    });
  }
  /**
   * Sets the window background color.
   *
   * #### Platform-specific:
   *
   * - **Windows:** alpha channel is ignored.
   * - **iOS / Android:** Unsupported.
   *
   * @returns A promise indicating the success or failure of the operation.
   *
   * @since 2.1.0
   */
  async setBackgroundColor(t) {
    return d("plugin:window|set_background_color", { color: t });
  }
  /**
   * Changes the position of the cursor in window coordinates.
   * @example
   * ```typescript
   * import { getCurrentWindow, LogicalPosition } from '@tauri-apps/api/window';
   * await getCurrentWindow().setCursorPosition(new LogicalPosition(600, 300));
   * ```
   *
   * @param position The new cursor position.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setCursorPosition(t) {
    return d("plugin:window|set_cursor_position", {
      label: this.label,
      value: t instanceof Ze ? t : new Ze(t)
    });
  }
  /**
   * Changes the cursor events behavior.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setIgnoreCursorEvents(true);
   * ```
   *
   * @param ignore `true` to ignore the cursor events; `false` to process them as usual.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setIgnoreCursorEvents(t) {
    return d("plugin:window|set_ignore_cursor_events", {
      label: this.label,
      value: t
    });
  }
  /**
   * Starts dragging the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().startDragging();
   * ```
   *
   * @return A promise indicating the success or failure of the operation.
   */
  async startDragging() {
    return d("plugin:window|start_dragging", {
      label: this.label
    });
  }
  /**
   * Starts resize-dragging the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().startResizeDragging();
   * ```
   *
   * @return A promise indicating the success or failure of the operation.
   */
  async startResizeDragging(t) {
    return d("plugin:window|start_resize_dragging", {
      label: this.label,
      value: t
    });
  }
  /**
   * Sets the badge count. It is app wide and not specific to this window.
   *
   * #### Platform-specific
   *
   * - **Windows**: Unsupported. Use @{linkcode Window.setOverlayIcon} instead.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setBadgeCount(5);
   * ```
   *
   * @param count The badge count. Use `undefined` to remove the badge.
   * @return A promise indicating the success or failure of the operation.
   */
  async setBadgeCount(t) {
    return d("plugin:window|set_badge_count", {
      label: this.label,
      value: t
    });
  }
  /**
   * Sets the badge cont **macOS only**.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setBadgeLabel("Hello");
   * ```
   *
   * @param label The badge label. Use `undefined` to remove the badge.
   * @return A promise indicating the success or failure of the operation.
   */
  async setBadgeLabel(t) {
    return d("plugin:window|set_badge_label", {
      label: this.label,
      value: t
    });
  }
  /**
   * Sets the overlay icon. **Windows only**
   * The overlay icon can be set for every window.
   *
   *
   * Note that you may need the `image-ico` or `image-png` Cargo features to use this API.
   * To enable it, change your Cargo.toml file:
   *
   * ```toml
   * [dependencies]
   * tauri = { version = "...", features = ["...", "image-png"] }
   * ```
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setOverlayIcon("/tauri/awesome.png");
   * ```
   *
   * @param icon Icon bytes or path to the icon file. Use `undefined` to remove the overlay icon.
   * @return A promise indicating the success or failure of the operation.
   */
  async setOverlayIcon(t) {
    return d("plugin:window|set_overlay_icon", {
      label: this.label,
      value: t ? on(t) : void 0
    });
  }
  /**
   * Sets the taskbar progress state.
   *
   * #### Platform-specific
   *
   * - **Linux / macOS**: Progress bar is app-wide and not specific to this window.
   * - **Linux**: Only supported desktop environments with `libunity` (e.g. GNOME).
   *
   * @example
   * ```typescript
   * import { getCurrentWindow, ProgressBarStatus } from '@tauri-apps/api/window';
   * await getCurrentWindow().setProgressBar({
   *   status: ProgressBarStatus.Normal,
   *   progress: 50,
   * });
   * ```
   *
   * @return A promise indicating the success or failure of the operation.
   */
  async setProgressBar(t) {
    return d("plugin:window|set_progress_bar", {
      label: this.label,
      value: t
    });
  }
  /**
   * Sets whether the window should be visible on all workspaces or virtual desktops.
   *
   * #### Platform-specific
   *
   * - **Windows / iOS / Android:** Unsupported.
   *
   * @since 2.0.0
   */
  async setVisibleOnAllWorkspaces(t) {
    return d("plugin:window|set_visible_on_all_workspaces", {
      label: this.label,
      value: t
    });
  }
  /**
   * Sets the title bar style. **macOS only**.
   *
   * @since 2.0.0
   */
  async setTitleBarStyle(t) {
    return d("plugin:window|set_title_bar_style", {
      label: this.label,
      value: t
    });
  }
  /**
   * Set window theme, pass in `null` or `undefined` to follow system theme
   *
   * #### Platform-specific
   *
   * - **Linux / macOS**: Theme is app-wide and not specific to this window.
   * - **iOS / Android:** Unsupported.
   *
   * @since 2.0.0
   */
  async setTheme(t) {
    return d("plugin:window|set_theme", {
      label: this.label,
      value: t
    });
  }
  // Listeners
  /**
   * Listen to window resize.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from "@tauri-apps/api/window";
   * const unlisten = await getCurrentWindow().onResized(({ payload: size }) => {
   *  console.log('Window resized', size);
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async onResized(t) {
    return this.listen(mt.WINDOW_RESIZED, (n) => {
      n.payload = new je(n.payload), t(n);
    });
  }
  /**
   * Listen to window move.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from "@tauri-apps/api/window";
   * const unlisten = await getCurrentWindow().onMoved(({ payload: position }) => {
   *  console.log('Window moved', position);
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async onMoved(t) {
    return this.listen(mt.WINDOW_MOVED, (n) => {
      n.payload = new qt(n.payload), t(n);
    });
  }
  /**
   * Listen to window close requested. Emitted when the user requests to closes the window.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from "@tauri-apps/api/window";
   * import { confirm } from '@tauri-apps/api/dialog';
   * const unlisten = await getCurrentWindow().onCloseRequested(async (event) => {
   *   const confirmed = await confirm('Are you sure?');
   *   if (!confirmed) {
   *     // user did not confirm closing the window; let's prevent it
   *     event.preventDefault();
   *   }
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async onCloseRequested(t) {
    return this.listen(mt.WINDOW_CLOSE_REQUESTED, async (n) => {
      const a = new Zi(n);
      await t(a), a.isPreventDefault() || await this.destroy();
    });
  }
  /**
   * Listen to a file drop event.
   * The listener is triggered when the user hovers the selected files on the webview,
   * drops the files or cancels the operation.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from "@tauri-apps/api/webview";
   * const unlisten = await getCurrentWindow().onDragDropEvent((event) => {
   *  if (event.payload.type === 'over') {
   *    console.log('User hovering', event.payload.position);
   *  } else if (event.payload.type === 'drop') {
   *    console.log('User dropped', event.payload.paths);
   *  } else {
   *    console.log('File drop cancelled');
   *  }
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async onDragDropEvent(t) {
    const n = await this.listen(mt.DRAG_ENTER, (u) => {
      t({
        ...u,
        payload: {
          type: "enter",
          paths: u.payload.paths,
          position: new qt(u.payload.position)
        }
      });
    }), a = await this.listen(mt.DRAG_OVER, (u) => {
      t({
        ...u,
        payload: {
          type: "over",
          position: new qt(u.payload.position)
        }
      });
    }), o = await this.listen(mt.DRAG_DROP, (u) => {
      t({
        ...u,
        payload: {
          type: "drop",
          paths: u.payload.paths,
          position: new qt(u.payload.position)
        }
      });
    }), c = await this.listen(mt.DRAG_LEAVE, (u) => {
      t({ ...u, payload: { type: "leave" } });
    });
    return () => {
      n(), o(), a(), c();
    };
  }
  /**
   * Listen to window focus change.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from "@tauri-apps/api/window";
   * const unlisten = await getCurrentWindow().onFocusChanged(({ payload: focused }) => {
   *  console.log('Focus changed, window is focused? ' + focused);
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async onFocusChanged(t) {
    const n = await this.listen(mt.WINDOW_FOCUS, (o) => {
      t({ ...o, payload: !0 });
    }), a = await this.listen(mt.WINDOW_BLUR, (o) => {
      t({ ...o, payload: !1 });
    });
    return () => {
      n(), a();
    };
  }
  /**
   * Listen to window scale change. Emitted when the window's scale factor has changed.
   * The following user actions can cause DPI changes:
   * - Changing the display's resolution.
   * - Changing the display's scale factor (e.g. in Control Panel on Windows).
   * - Moving the window to a display with a different scale factor.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from "@tauri-apps/api/window";
   * const unlisten = await getCurrentWindow().onScaleChanged(({ payload }) => {
   *  console.log('Scale changed', payload.scaleFactor, payload.size);
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async onScaleChanged(t) {
    return this.listen(mt.WINDOW_SCALE_FACTOR_CHANGED, t);
  }
  /**
   * Listen to the system theme change.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from "@tauri-apps/api/window";
   * const unlisten = await getCurrentWindow().onThemeChanged(({ payload: theme }) => {
   *  console.log('New theme: ' + theme);
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async onThemeChanged(t) {
    return this.listen(mt.WINDOW_THEME_CHANGED, t);
  }
}
var _a;
(function(e) {
  e.Disabled = "disabled", e.Throttle = "throttle", e.Suspend = "suspend";
})(_a || (_a = {}));
var ka;
(function(e) {
  e.Default = "default", e.FluentOverlay = "fluentOverlay";
})(ka || (ka = {}));
var Sa;
(function(e) {
  e.AppearanceBased = "appearanceBased", e.Light = "light", e.Dark = "dark", e.MediumLight = "mediumLight", e.UltraDark = "ultraDark", e.Titlebar = "titlebar", e.Selection = "selection", e.Menu = "menu", e.Popover = "popover", e.Sidebar = "sidebar", e.HeaderView = "headerView", e.Sheet = "sheet", e.WindowBackground = "windowBackground", e.HudWindow = "hudWindow", e.FullScreenUI = "fullScreenUI", e.Tooltip = "tooltip", e.ContentBackground = "contentBackground", e.UnderWindowBackground = "underWindowBackground", e.UnderPageBackground = "underPageBackground", e.Mica = "mica", e.Blur = "blur", e.Acrylic = "acrylic", e.Tabbed = "tabbed", e.TabbedDark = "tabbedDark", e.TabbedLight = "tabbedLight";
})(Sa || (Sa = {}));
var Ma;
(function(e) {
  e.FollowsWindowActiveState = "followsWindowActiveState", e.Active = "active", e.Inactive = "inactive";
})(Ma || (Ma = {}));
async function On(e = {}) {
  return typeof e == "object" && Object.freeze(e), await d("plugin:dialog|open", { options: e });
}
const Qi = "__lunac_host";
function tr() {
  return globalThis[Qi] ?? null;
}
function m(e, t) {
  const n = tr();
  return n && typeof n.t == "function" ? n.t(e, t) : e;
}
const er = "pet", nr = "engine/live2dcubismcore.min.js", ar = "engine/live2d-engine.js";
function le(e, t) {
  const n = e.includes("\\") ? "\\" : "/", a = e.replace(/[\\/]+$/, "").split(/[\\/]+/);
  for (const o of t.split(/[\\/]+/))
    if (!(!o || o === ".")) {
      if (o === "..") {
        a.length > 1 && a.pop();
        continue;
      }
      a.push(o);
    }
  return a.join(n);
}
function dn(e) {
  const t = Math.max(e.lastIndexOf("\\"), e.lastIndexOf("/"));
  return t > 0 ? e.slice(0, t) : e;
}
function ir(e) {
  var n;
  const t = Number((e == null ? void 0 : e.Version) ?? 0);
  if (!((n = e == null ? void 0 : e.FileReferences) != null && n.Moc) || !(t >= 3))
    throw new Error("这不是 Cubism 4 的模型定义（缺 `FileReferences.Moc` 或 `Version < 3`）—— 请选 `*.model3.json`");
}
async function Ue(e) {
  let t;
  try {
    t = await fetch(Ft(e));
  } catch (n) {
    throw new Error(`读不到模型文件（asset 协议拒绝或文件已移动）：${n instanceof Error ? n.message : String(n)}`);
  }
  if (!t.ok) throw new Error(`读模型定义失败（HTTP ${t.status}）`);
  try {
    return await t.json();
  } catch {
    throw new Error("模型定义不是合法 JSON");
  }
}
function Ea(e) {
  return (e.split(/[\\/]/).pop() || "").replace(/\.[^.]+$/, "");
}
function $n(e) {
  return e.replace(/[\\/]+/g, "/").toLowerCase();
}
async function Xa(e, t) {
  var T;
  const n = t ?? await Ue(e), a = dn(e), o = ((T = n.FileReferences) == null ? void 0 : T.Expressions) ?? [], c = [], u = /* @__PURE__ */ new Set();
  for (const v of o) {
    const D = v.File ? le(a, v.File) : "", E = (v.Name || (v.File ? Ea(v.File) : "")).trim();
    E && (D && u.add($n(D)), c.push({ id: E, name: E, file: D, declared: !0 }));
  }
  let y = [];
  try {
    y = await d("list_expression_files", {
      model_path: e
    }) ?? [];
  } catch {
    y = [];
  }
  for (const v of y) {
    const D = typeof (v == null ? void 0 : v.path) == "string" ? v.path : "";
    if (!D || u.has($n(D))) continue;
    const E = (typeof (v == null ? void 0 : v.name) == "string" && v.name.trim() || Ea(D)).trim();
    E && (u.add($n(D)), c.push({ id: E, name: E, file: D, declared: !1 }));
  }
  return c;
}
async function Ka(e) {
  var t;
  try {
    const n = await Ue(e);
    ir(n);
    const a = n.FileReferences ?? {}, o = Object.keys(a.Motions ?? {});
    return {
      ok: !0,
      info: `Cubism ${Number(n.Version)} · 纹理 ${((t = a.Textures) == null ? void 0 : t.length) ?? 0} · 动作组 ${o.length ? o.join(" / ") : "无"}`
    };
  } catch (n) {
    return { ok: !1, reason: n instanceof Error ? n.message : String(n) };
  }
}
async function Ja() {
  const e = await d("plugins_dir_path");
  return le(e, er);
}
async function rr() {
  return le(await Ja(), nr);
}
async function sr() {
  return le(await Ja(), ar);
}
function Za() {
  return !!globalThis.Live2DCubismCore;
}
let Qe = null;
function or() {
  return Za() ? Promise.resolve() : (Qe || (Qe = lr().catch((e) => {
    throw Qe = null, e instanceof Error ? e : new Error(String(e));
  })), Qe);
}
async function lr() {
  if (await cr(Ft(await rr())), !Za()) throw new Error("Cubism Core 已注入但全局对象仍不可见（文件可能不完整）");
}
function cr(e) {
  return new Promise((t, n) => {
    const a = document.createElement("script");
    a.src = e, a.async = !1, a.onload = () => t(), a.onerror = () => n(new Error(`引擎文件加载失败（asset 协议拒绝或文件缺失）：${e}`)), document.head.appendChild(a);
  });
}
const Qa = 0.4, ti = 8, Dn = "Lunac", pr = [
  "motion",
  "chain",
  "expression",
  "param",
  "artmesh",
  "artmeshColor",
  "part",
  "physics"
];
function ur(e) {
  return e.split(/[\\/]/).pop() || "";
}
function dr() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
}
function Fn(e = "新热键", t = "", n) {
  return {
    id: dr(),
    name: e,
    keys: t,
    action: n ?? { type: "expression", target: "", mode: "set" }
  };
}
function fr(e) {
  const t = [
    "Numpad1",
    "Numpad2",
    "Numpad3",
    "Numpad4",
    "Numpad5",
    "Numpad6",
    "Numpad7",
    "Numpad8",
    "Numpad9"
  ], n = ["Ctrl", "Shift", "Alt", "Ctrl+Shift", "Ctrl+Alt", "Shift+Alt", "Ctrl+Shift+Alt"], a = Math.max(0, Math.floor(e)), o = t[a % t.length], c = Math.floor(a / t.length);
  return c < n.length ? `${n[c]}+${o}` : o;
}
async function we(e) {
  let t = null;
  try {
    t = await d("read_pet_hotkeys", { modelPath: e });
  } catch {
    return [];
  }
  if (!t) return [];
  try {
    const n = JSON.parse(t);
    return (Array.isArray(n.hotkeys) ? n.hotkeys : []).filter(
      (o) => !!o && typeof o == "object" && typeof o.keys == "string"
    );
  } catch {
    return [];
  }
}
async function fn(e, t) {
  const n = { version: 1, model: ur(e), hotkeys: t };
  return d("write_pet_hotkeys", {
    modelPath: e,
    json: JSON.stringify(n, null, 2)
  });
}
const Tn = /* @__PURE__ */ new Map(), Ca = /* @__PURE__ */ new Set();
function mr(e) {
  let t = 2166136261;
  for (let n = 0; n < e.length; n++)
    t ^= e.charCodeAt(n), t = Math.imul(t, 16777619);
  return (t >>> 0).toString(36);
}
function Rn(e, t) {
  const n = e.toLowerCase();
  Ca.has(n) || (Ca.add(n), console.warn("[pet] 读不到物理文件，已按空集合处理", e, t));
}
function hr(e) {
  const t = [], n = [], a = (u, y) => {
    y && !u.includes(y) && u.push(y);
  }, o = (u) => {
    const y = u;
    return typeof (y == null ? void 0 : y.Id) == "string" ? y.Id : "";
  }, c = e == null ? void 0 : e.PhysicsSettings;
  if (!Array.isArray(c)) return { inputs: t, outputs: n };
  for (const u of c) {
    const y = u == null ? void 0 : u.Input;
    if (Array.isArray(y))
      for (const v of y) a(t, o(v == null ? void 0 : v.Source));
    const T = u == null ? void 0 : u.Output;
    if (Array.isArray(T))
      for (const v of T) a(n, o(v == null ? void 0 : v.Destination));
  }
  return { inputs: t, outputs: n };
}
async function gr(e) {
  const t = e.toLowerCase();
  let n = 0, a = 0, o;
  try {
    const T = await fetch(Ft(e), { method: "HEAD" });
    if (!T.ok) throw new Error(`HTTP ${T.status}`);
    const v = Number(T.headers.get("content-length"));
    Number.isFinite(v) && v >= 0 && (a = v);
    const D = T.headers.get("last-modified");
    if (D) {
      const rt = Date.parse(D);
      Number.isFinite(rt) && (n = rt);
    }
    const E = Tn.get(t);
    if (E && n > 0 && E.mtimeMs === n && E.size === a)
      return E.value;
    const X = await fetch(Ft(e));
    if (!X.ok) throw new Error(`HTTP ${X.status}`);
    o = await X.text();
  } catch (T) {
    return Rn(e, T), { inputs: [], outputs: [] };
  }
  const c = n > 0 ? `m:${n}:${a}` : `h:${o.length}:${mr(o)}`, u = Tn.get(t);
  if (u && u.stamp === c)
    return u.mtimeMs = n, u.size = a, u.value;
  let y;
  try {
    y = hr(JSON.parse(o));
  } catch (T) {
    return Rn(e, T), { inputs: [], outputs: [] };
  }
  return Tn.set(t, { stamp: c, mtimeMs: n, size: a, value: y }), y;
}
async function mn(e) {
  var a;
  let t = null;
  try {
    t = await Ue(e);
  } catch (o) {
    return Rn(e, o), { inputs: [], outputs: [] };
  }
  const n = (a = t == null ? void 0 : t.FileReferences) == null ? void 0 : a.Physics;
  return typeof n != "string" || !n ? { inputs: [], outputs: [] } : gr(le(dn(e), n));
}
async function br(e, t) {
  var c;
  const n = {
    motions: [],
    expressions: [],
    expressionFiles: {},
    parameters: (t == null ? void 0 : t.parameters) ?? [],
    drawables: (t == null ? void 0 : t.drawables) ?? [],
    parts: (t == null ? void 0 : t.parts) ?? [],
    physicsInputs: [],
    physicsOutputs: []
  };
  let a = null;
  try {
    a = await Ue(e);
  } catch {
    a = null;
  }
  if ((c = a == null ? void 0 : a.FileReferences) != null && c.Motions)
    for (const [u, y] of Object.entries(a.FileReferences.Motions))
      n.motions.push({ group: u, count: Array.isArray(y) ? y.length : 0 });
  try {
    const u = await Xa(e, a ?? void 0);
    n.expressions = u.map((y) => y.id);
    for (const y of u) n.expressionFiles[y.id] = y.file;
  } catch {
    n.expressions = [];
  }
  const o = await mn(e);
  return n.physicsInputs = o.inputs, n.physicsOutputs = o.outputs, n;
}
const $a = /* @__PURE__ */ new Map();
async function ei(e) {
  const t = e.toLowerCase(), n = $a.get(t);
  if (n) return n;
  let a = [];
  try {
    const o = await fetch(Ft(e));
    if (o.ok) {
      const c = await o.json();
      a = (Array.isArray(c.Parameters) ? c.Parameters : []).map((y) => {
        const T = typeof (y == null ? void 0 : y.Id) == "string" ? y.Id : "", v = y == null ? void 0 : y.Value, D = y == null ? void 0 : y.Blend;
        return { id: T, value: typeof v == "number" ? v : NaN, blend: typeof D == "string" && D ? D : "Overwrite" };
      }).filter((y) => !!y.id && Number.isFinite(y.value));
    }
  } catch {
    a = [];
  }
  return $a.set(t, a), a;
}
async function hn(e) {
  try {
    const t = await fetch(Ft(e));
    return t.ok ? await t.json() : null;
  } catch {
    return null;
  }
}
async function yr(e) {
  const t = await hn(e), n = t == null ? void 0 : t.Hotkeys;
  if (!Array.isArray(n)) return [];
  const a = [];
  for (const o of n) {
    const c = o, u = typeof (c == null ? void 0 : c.Action) == "string" ? c.Action.trim() : "";
    if (!u) continue;
    const y = typeof (c == null ? void 0 : c.File) == "string" ? c.File.trim() : "", T = typeof (c == null ? void 0 : c.Folder) == "string" ? c.Folder.trim() : "", v = typeof (c == null ? void 0 : c.Name) == "string" ? c.Name.trim() : "";
    a.push({ name: v || y, action: u, file: y ? T ? `${T}/${y}` : y : "" });
  }
  return a;
}
async function vr(e) {
  const t = await hn(e), n = t == null ? void 0 : t.ParameterSettings;
  if (!Array.isArray(n)) return [];
  const a = [];
  for (const o of n) {
    const c = o == null ? void 0 : o.OutputLive2D;
    typeof c == "string" && c && !a.includes(c) && a.push(c);
  }
  return a;
}
async function wr(e) {
  const t = { parameters: {}, parts: {}, artMeshes: {} }, n = await hn(e);
  if (!n) return t;
  const a = (o, c) => {
    const u = n[o];
    if (Array.isArray(u))
      for (const y of u) {
        const T = y;
        typeof (T == null ? void 0 : T.Id) == "string" && T.Id && typeof (T == null ? void 0 : T.Name) == "string" && T.Name && (c[T.Id] = T.Name);
      }
  };
  return a("Parameters", t.parameters), a("Parts", t.parts), a("ArtMeshes", t.artMeshes), t;
}
function xr(e) {
  switch (e) {
    case "ToggleExpression":
      return "expression";
    case "TriggerAnimation":
      return "motion";
    default:
      return null;
  }
}
function _r(e, t) {
  const n = xr(e.action);
  if (!n) return null;
  const a = e.name || "热键";
  if (n === "expression") {
    const o = e.file ? le(t, e.file) : "";
    return Fn(a, "", { type: "expression", target: e.name, mode: "set", file: o });
  }
  return Fn(a, "", { type: "motion", group: "", index: 0 });
}
async function ye(e) {
  const t = dn(e);
  if (!t) return [];
  try {
    const n = await d("list_motion_files", { dir: t });
    return Array.isArray(n) ? n.filter((a) => !!a && typeof a.path == "string") : [];
  } catch {
    return [];
  }
}
async function kr(e) {
  const t = /* @__PURE__ */ new Map();
  for (const n of e) {
    const a = await hn(n), o = a == null ? void 0 : a.Curves;
    if (Array.isArray(o))
      for (const c of o) {
        const u = c == null ? void 0 : c.Id, y = c == null ? void 0 : c.Segments;
        if (typeof u != "string" || !u || !Array.isArray(y) || y.length < 3) continue;
        const T = t.get(u) ?? /* @__PURE__ */ new Set();
        typeof y[1] == "number" && T.add(y[1]);
        let v = 2;
        for (; v < y.length; ) {
          const D = y[v];
          v += D === 1 ? 7 : 3;
          const E = y[v - 1];
          typeof E == "number" && T.add(E);
        }
        t.set(u, T);
      }
  }
  return t;
}
const Sr = 0.1, Mr = 3600;
function Er() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
}
function Cr(e = "新动作链") {
  return { id: Er(), name: e, steps: [], loop: !1 };
}
function Ta(e = "") {
  return { file: e, loopSec: 3, stopSec: 0 };
}
function Aa(e, t) {
  const n = typeof e == "number" && Number.isFinite(e) ? e : t;
  return n <= 0 ? t : Math.min(Mr, Math.max(Sr, n));
}
function $r(e) {
  return e.split(/[\\/]/).pop() || "";
}
async function rn(e) {
  let t = null;
  try {
    t = await d("read_pet_chains", { modelPath: e });
  } catch {
    return [];
  }
  if (!t) return [];
  try {
    const n = JSON.parse(t);
    return (Array.isArray(n.chains) ? n.chains : []).filter((o) => !!o && typeof o == "object" && typeof o.id == "string").map((o) => ({
      id: String(o.id),
      name: typeof o.name == "string" && o.name ? o.name : "动作链",
      // 整链循环：缺省 / 坏值一律当 false（保持「播完即停」的旧行为，不让坏数据把链卡成死循环）。
      loop: o.loop === !0,
      steps: (Array.isArray(o.steps) ? o.steps : []).filter((c) => !!c && typeof c == "object" && typeof c.file == "string").map((c) => ({
        file: c.file,
        loopSec: Aa(c.loopSec, 3),
        stopSec: typeof c.stopSec == "number" && Number.isFinite(c.stopSec) && c.stopSec > 0 ? Aa(c.stopSec, 3) : 0
      }))
    }));
  } catch {
    return [];
  }
}
async function Tr(e, t) {
  const n = { version: 1, model: $r(e), chains: t };
  return d("write_pet_chains", { modelPath: e, json: JSON.stringify(n, null, 2) });
}
function qn(e) {
  const t = e.stopSec > 0 ? e.stopSec : e.loopSec;
  return Math.min(e.loopSec, t);
}
function Ar(e) {
  return e.steps.reduce((t, n) => t + qn(n), 0);
}
function ni(e) {
  return e.split(/[\\/]/).pop() || "";
}
function Yn(e) {
  return {
    version: 1,
    model: ni(e),
    coreIds: {
      parameters: [],
      drawables: [],
      parts: [],
      parameterRanges: {},
      physicsInputs: [],
      physicsOutputs: []
    },
    params: {}
  };
}
function Fe(e) {
  return Array.isArray(e) ? e.filter((t) => typeof t == "string") : [];
}
function Lr(e) {
  const t = {};
  if (e && typeof e == "object")
    for (const [n, a] of Object.entries(e))
      typeof a == "number" && Number.isFinite(a) && (t[n] = a);
  return t;
}
function Nr(e) {
  const t = {};
  if (e && typeof e == "object")
    for (const [n, a] of Object.entries(e)) {
      const o = a;
      o && typeof o == "object" && (t[n] = {
        min: typeof o.min == "number" && Number.isFinite(o.min) ? o.min : 0,
        max: typeof o.max == "number" && Number.isFinite(o.max) ? o.max : 0,
        def: typeof o.def == "number" && Number.isFinite(o.def) ? o.def : 0
      });
    }
  return t;
}
async function Ve(e) {
  let t = null;
  try {
    t = await d("read_pet_params", { modelPath: e });
  } catch {
    return null;
  }
  if (!t) return null;
  try {
    const n = JSON.parse(t);
    if (!n || typeof n != "object") return null;
    const a = n.coreIds ?? {};
    return {
      version: 1,
      model: typeof n.model == "string" ? n.model : ni(e),
      coreIds: {
        parameters: Fe(a.parameters),
        drawables: Fe(a.drawables),
        parts: Fe(a.parts),
        parameterRanges: Nr(a.parameterRanges),
        physicsInputs: Fe(a.physicsInputs),
        physicsOutputs: Fe(a.physicsOutputs)
      },
      params: Lr(n.params)
    };
  } catch {
    return null;
  }
}
async function ln(e, t) {
  return d("write_pet_params", { modelPath: e, json: JSON.stringify(t, null, 2) });
}
function tn(e) {
  return String(e).replace(
    /[&<>"']/g,
    (t) => t === "&" ? "&amp;" : t === "<" ? "&lt;" : t === ">" ? "&gt;" : t === '"' ? "&quot;" : "&#39;"
  );
}
function zn(e, t, n = "") {
  var y, T;
  const a = t.map((v) => {
    const D = v.tag ? ` data-tag="${tn(v.tag)}"` : "", E = v.deletable ? '<span class="cs-del" title="×">×</span>' : "";
    return `<div class="custom-select-option${v.selected ? " selected" : ""}" data-value="${tn(v.value)}"${D}>${tn(v.label)}${E}</div>`;
  }).join(""), o = ((y = t.find((v) => v.selected)) == null ? void 0 : y.label) || ((T = t[0]) == null ? void 0 : T.label) || "", c = "", u = n ? ` ${n}` : "";
  return `<div class="custom-select"${c}${u}><button class="custom-select-trigger" type="button"><span class="custom-select-label">${tn(o)}</span><svg class="custom-select-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg></button><div class="custom-select-dropdown">${a}</div></div>`;
}
const La = "__lunacCustomSelectBound";
function Na(e) {
  const t = e.querySelector(".custom-select-dropdown"), n = e.querySelector(".custom-select-trigger");
  if (!t || !n) return;
  const a = n.getBoundingClientRect(), o = 8, c = 120, u = e.closest("#results-list"), y = u == null ? void 0 : u.getBoundingClientRect(), T = Math.max(y ? y.top : 0, 0), D = Math.min(y ? y.bottom : window.innerHeight, window.innerHeight) - a.bottom - o, E = a.top - T - o, X = D < c && E > D, K = Math.max(60, Math.min(c, X ? E : D));
  t.style.overflowY = "auto", t.style.overscrollBehavior = "contain", t.style.position = "absolute", t.style.left = "0", t.style.width = "100%", t.style.maxHeight = K + "px", X ? (t.style.top = "auto", t.style.bottom = "calc(100% + 4px)") : (t.style.top = "calc(100% + 4px)", t.style.bottom = "auto"), t.style.marginTop = "0", t.style.marginBottom = "0";
}
function Pr(e) {
  var t;
  return ((t = e.textContent) == null ? void 0 : t.replace(/\s*×$/, "").trim()) || "";
}
function Ir(e, t) {
  const n = e;
  if (n[La]) return;
  n[La] = !0;
  const a = e.querySelector(".custom-select-trigger"), o = e.querySelector(".custom-select-dropdown"), c = e.querySelector(".custom-select-label");
  if (!a || !o || !c) return;
  const u = t.scope ?? document, y = () => u.querySelectorAll(".custom-select.open").forEach((v) => {
    v !== e && v.classList.remove("open");
  });
  a.addEventListener("click", (v) => {
    var E, X;
    v.preventDefault(), v.stopPropagation();
    const D = e.classList.contains("open");
    y(), D ? (e.classList.remove("open"), (E = t.onOpenChange) == null || E.call(t, !1)) : (e.classList.add("open"), (X = t.onOpenChange) == null || X.call(t, !0), Na(e), window.addEventListener("resize", () => Na(e), { once: !0 }));
  }), o.addEventListener("click", (v) => {
    var K, it;
    const D = v.target, E = D.closest(".cs-del");
    if (E) {
      v.preventDefault(), v.stopPropagation();
      const J = E.closest(".custom-select-option");
      J && ((K = t.onDelete) == null || K.call(t, J));
      return;
    }
    const X = D.closest(".custom-select-option");
    if (!X) return;
    v.preventDefault(), v.stopPropagation();
    const rt = X.getAttribute("data-value") || "";
    if (rt === "__custom__" && t.onCustomEntry) {
      t.onCustomEntry(c);
      return;
    }
    o.querySelectorAll(".custom-select-option").forEach((J) => J.classList.remove("selected")), X.classList.add("selected"), c.textContent = Pr(X), e.classList.remove("open"), (it = t.onOpenChange) == null || it.call(t, !1), t.onPick(rt);
  }), o.addEventListener(
    "wheel",
    (v) => {
      const D = o.scrollTop > 0, E = o.scrollTop + o.clientHeight < o.scrollHeight - 1;
      (v.deltaY < 0 && D || v.deltaY > 0 && E) && (v.preventDefault(), o.scrollTop += v.deltaY);
    },
    { passive: !1 }
  );
  const T = (v) => {
    var E;
    if (!e.isConnected) {
      document.removeEventListener("click", T);
      return;
    }
    const D = v.target;
    D && e.contains(D) || e.classList.contains("open") && (e.classList.remove("open"), (E = t.onOpenChange) == null || E.call(t, !1));
  };
  document.addEventListener("click", T);
}
const ai = 1, ii = 4, Xn = 2, Or = 12e4;
function gn(e) {
  if (typeof e != "number" || !Number.isFinite(e)) return Xn;
  const t = Math.round(e * 100) / 100;
  return Math.min(ii, Math.max(ai, t));
}
function Pa(e) {
  return e.replace(/\s+/g, " ").trim();
}
const Dr = /[\u1100-\u11FF\u2E80-\u2EFF\u3000-\u303F\u3040-\u30FF\u3130-\u318F\u3400-\u4DBF\u4E00-\u9FFF\uA960-\uA97F\uAC00-\uD7AF\uF900-\uFAFF\uFE30-\uFE4F\uFF00-\uFFEF]/u, Fr = /[\p{P}\p{S}]/u, Rr = /\s/u;
function zr(e) {
  const t = [];
  let n = "";
  for (const a of e) {
    if (Rr.test(a)) {
      n ? (t.push(n + a), n = "") : t.length && (t[t.length - 1] += a);
      continue;
    }
    if (Fr.test(a)) {
      n ? n += a : t.length ? t[t.length - 1] += a : n += a;
      continue;
    }
    if (Dr.test(a)) {
      n && (t.push(n), n = ""), t.push(a);
      continue;
    }
    n += a;
  }
  return n && t.push(n), t;
}
function Hr(e, t, n) {
  if (!(e > 0)) return !0;
  const a = gn(t);
  return e * 1e3 / a > n;
}
const lt = 75, Hn = 400, Wn = 300, ri = 140, Kn = 35, oe = lt + Hn + Kn, se = 255, _e = 320, Wr = _e - Wn, jr = 160, Br = lt + Kn + ri, Ia = 2e3, si = 20;
function Oa(e) {
  const t = Number.isFinite(e) ? e : oe;
  return Math.min(se, Math.max(lt, t - Kn - ri));
}
function Vr(e, t = se) {
  const n = Math.min(se, Math.max(lt, Number.isFinite(t) ? t : se));
  return typeof e != "number" || !Number.isFinite(e) ? lt : Math.min(n, Math.max(lt, Math.ceil(e)));
}
function Gr(e, t = si, n = se) {
  const a = Math.min(se, Math.max(lt, Number.isFinite(n) ? n : se)), o = Math.min(a, Math.max(lt, e));
  if (o >= a) return a;
  const c = lt + Math.ceil((o - lt) / t) * t;
  return Math.min(a, Math.max(lt, c));
}
function Ur(e, t) {
  return e + (t - lt);
}
function jn(e, t) {
  const n = typeof e == "number" && Number.isFinite(e) ? Math.round(Math.min(Ia, Math.max(jr, e))) : _e, a = typeof t == "number" && Number.isFinite(t) ? Math.round(Math.min(Ia, Math.max(Br, t))) : oe;
  return { w: n, h: a };
}
function qr(e, t) {
  return Math.abs(e - t) >= 1;
}
function Yr(e, t) {
  const n = e - (t - lt);
  return Number.isFinite(n) ? n : oe;
}
const Xr = "lunac.pet.look-screen.v1", B = "pet-control", Kr = "pet-chat-send", Jr = "pet-chat-reply", Zr = "pet-chat-stop", Qr = "pet-tts-mouth", ts = "pet-tts-done", Jn = 1, Zn = 1440, Qn = 0, ta = 200, es = 6e3, ns = 9e4, ea = 5, na = 600, as = 20, aa = 1, ia = 64, is = 12, ra = 30, sa = 3600, rs = 600, ss = 6e4, oi = "lunac.pet.v1", ve = "plugin-pet", Da = 1.1, An = [
  { id: "ParamAngleX", min: -100, max: 100, labelKey: "pet.param_head_x" },
  { id: "ParamAngleY", min: -100, max: 100, labelKey: "pet.param_head_y" },
  { id: "ParamAngleZ", min: -100, max: 100, labelKey: "pet.param_head_z" },
  { id: "ParamEyeLOpen", min: 0, max: 100, labelKey: "pet.param_eye_l" },
  { id: "ParamEyeROpen", min: 0, max: 100, labelKey: "pet.param_eye_r" },
  { id: "ParamMouthOpenY", min: 0, max: 100, labelKey: "pet.param_mouth" },
  { id: "ParamBodyAngleX", min: -100, max: 100, labelKey: "pet.param_body_x" },
  { id: "ParamBodyAngleZ", min: -100, max: 100, labelKey: "pet.param_body_z" },
  { id: "ParamBreath", min: 0, max: 100, labelKey: "pet.param_breath" }
], Ln = {
  image: "",
  model: "",
  scale: 1,
  offsetX: 0,
  offsetY: 0,
  rotation: 0,
  clickThrough: !1,
  expressions: {},
  params: {},
  paramKinds: {},
  motionTemplateIncludePhysics: !1,
  idleMotions: {},
  hotkeyStates: {},
  proactive: { enabled: !1, intervalMin: 30, dailyCap: 20, screenPollSec: as, screenMinGapSec: rs, screenDiff: is, date: "", used: 0 },
  tts: !0,
  speechRate: Xn,
  winW: _e,
  winH: oe
};
function ct(e, t, n, a) {
  return typeof e == "number" && Number.isFinite(e) ? Math.min(n, Math.max(t, Math.round(e))) : a;
}
function M() {
  try {
    const e = localStorage.getItem(oi);
    if (!e) return { ...Ln };
    const t = JSON.parse(e), n = {};
    if (t.expressions && typeof t.expressions == "object")
      for (const [J, Z] of Object.entries(t.expressions))
        J && typeof Z == "string" && (n[J] = Z);
    const a = {};
    if (t.params && typeof t.params == "object")
      for (const [J, Z] of Object.entries(t.params)) {
        if (!J || !Z || typeof Z != "object") continue;
        const A = {};
        for (const [z, dt] of Object.entries(Z))
          z && typeof dt == "number" && Number.isFinite(dt) && (A[z] = dt);
        Object.keys(A).length && (a[J] = A);
      }
    const o = {}, c = t.paramKinds;
    if (c && typeof c == "object")
      for (const [J, Z] of Object.entries(c)) {
        if (!J || !Z || typeof Z != "object") continue;
        const A = {};
        for (const [z, dt] of Object.entries(Z))
          z && (dt === "switch" || dt === "range") && (A[z] = dt);
        Object.keys(A).length && (o[J] = A);
      }
    const u = {}, y = t.idleMotions;
    if (y && typeof y == "object")
      for (const [J, Z] of Object.entries(y)) {
        if (!J || !Array.isArray(Z)) continue;
        const A = Z.filter((z) => typeof z == "string" && z.trim().length > 0);
        A.length && (u[J] = A);
      }
    const T = {}, v = t.hotkeyStates;
    if (v && typeof v == "object")
      for (const [J, Z] of Object.entries(v)) {
        if (!J || !Array.isArray(Z)) continue;
        const A = Z.filter((z) => typeof z == "string" && z.trim().length > 0);
        A.length && (T[J] = A);
      }
    const D = Ln.proactive, E = t.proactive, X = !!E && typeof E == "object" && ("autoShot" in E || "autoShotMin" in E || "screenWatch" in E || "screenWatchSec" in E), rt = E && typeof E == "object" ? {
      enabled: E.enabled === !0 || E.autoShot === !0 || E.screenWatch === !0,
      intervalMin: ct(E.intervalMin, Jn, Zn, D.intervalMin),
      dailyCap: ct(E.dailyCap, Qn, ta, D.dailyCap),
      // 轮询秒数：新字段优先；老配置里的 `screenWatchSec` 回填一次（随后随迁移写回消失）。
      screenPollSec: ct(
        E.screenPollSec ?? E.screenWatchSec,
        ea,
        na,
        D.screenPollSec
      ),
      // 最小间隔：老配置没有这个字段 ⇒ 回落默认 600（与放开前的行为一致）。
      screenMinGapSec: ct(
        E.screenMinGapSec,
        ra,
        sa,
        D.screenMinGapSec
      ),
      screenDiff: ct(E.screenDiff, aa, ia, D.screenDiff),
      date: typeof E.date == "string" ? E.date : "",
      used: typeof E.used == "number" && Number.isFinite(E.used) && E.used > 0 ? Math.floor(E.used) : 0
    } : { ...D }, K = jn(
      typeof t.winW == "number" ? t.winW : _e,
      typeof t.winH == "number" ? t.winH : oe
    ), it = {
      image: typeof t.image == "string" ? t.image : "",
      model: typeof t.model == "string" ? t.model : "",
      scale: typeof t.scale == "number" && t.scale >= Qa && t.scale <= ti ? t.scale : 1,
      offsetX: typeof t.offsetX == "number" && Number.isFinite(t.offsetX) ? t.offsetX : 0,
      offsetY: typeof t.offsetY == "number" && Number.isFinite(t.offsetY) ? t.offsetY : 0,
      rotation: typeof t.rotation == "number" && Number.isFinite(t.rotation) ? Math.max(-180, Math.min(180, t.rotation)) : 0,
      clickThrough: t.clickThrough === !0,
      expressions: n,
      params: a,
      paramKinds: o,
      // 动作模板默认**排除物理输出**（老配置缺这个字段 ⇒ false，物理每帧覆盖的曲线没必要生成）。
      motionTemplateIncludePhysics: t.motionTemplateIncludePhysics === !0,
      idleMotions: u,
      hotkeyStates: T,
      proactive: rt,
      // 语音朗读：**默认 true**（老配置缺这个字段 ⇒ 回落到 true）。
      tts: typeof t.tts == "boolean" ? t.tts : !0,
      // 速率：越界 / 非法回落默认（`clampRate` 同一套夹取口径）。
      speechRate: gn(typeof t.speechRate == "number" ? t.speechRate : Xn),
      // 窗口尺寸记忆：越界 / 非法在 `clampWindowSize` 里夹到合法区间（打开时还会再 clamp 一次）。
      winW: K.w,
      winH: K.h
    };
    return X && U(it), it;
  } catch {
    return { ...Ln };
  }
}
function U(e) {
  try {
    localStorage.setItem(oi, JSON.stringify(e));
  } catch {
  }
}
function cn(e) {
  const t = e ? e.replace(/[\\/][^\\/]*$/, "") : "";
  d("set_pet_model_dir", { path: t }).catch(() => {
  });
}
function li() {
  const e = /* @__PURE__ */ new Date(), t = (n) => String(n).padStart(2, "0");
  return `${e.getFullYear()}-${t(e.getMonth() + 1)}-${t(e.getDate())}`;
}
function oa() {
  const e = M().proactive;
  return e.date !== li() ? 0 : e.used > 0 ? e.used : 0;
}
function Ot(e) {
  return e.dailyCap > 0 && oa() >= e.dailyCap;
}
function os() {
  const e = M(), t = li(), n = (e.proactive.date === t && e.proactive.used || 0) + 1;
  return U({ ...e, proactive: { ...e.proactive, date: t, used: n } }), n;
}
function ls(e, t) {
  if (e.length !== t.length || e.length === 0) return 0;
  let n = 0;
  for (let a = 0; a < e.length; a++) n += Math.abs(e[a] - t[a]);
  return n / e.length;
}
function cs() {
  const e = /* @__PURE__ */ new Date(), t = new Date(e.getFullYear(), e.getMonth(), e.getDate() + 1, 0, 0, 5);
  return Math.max(1e3, t.getTime() - Date.now());
}
function k(e) {
  return e.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
function bn(e) {
  return m(e ? "pet.through_on" : "pet.through_off");
}
function yt(e, t) {
  d("log_frontend", {
    level: "error",
    message: `[pet window] ${e}: ${t instanceof Error ? t.message : String(t)}`
  }).catch(() => {
  });
}
function ci() {
  try {
    return xt().label || "";
  } catch {
    return "";
  }
}
function _t() {
  return location.pathname.endsWith("plugin.html") && ci() === ve;
}
function Fa() {
  return ci() === `${ve}-settings`;
}
let en = null;
function ps() {
  return en || (en = (async () => (await or(), await import(Ft(await sr()))))().catch((e) => {
    throw en = null, e instanceof Error ? e : new Error(String(e));
  })), en;
}
function pi(e, t) {
  return `${m(e)}：${t ? "开" : "关"}`;
}
function pn(e) {
  return e ? "开" : "关";
}
function us(e) {
  const t = e.proactive, n = oa(), a = t.dailyCap > 0 ? String(t.dailyCap) : m("pet.proactive_unlimited"), o = m("pet.proactive_usage", { used: String(n), cap: a }), c = Ot(t) ? `${o} · ${m("pet.proactive_reached")}` : o;
  return `
  <div class="pet-proactive" id="pet-proactive">
    <div class="pet-debug-title">${m("pet.proactive_title")}</div>
    <div class="pet-row">
      <span class="pet-label">${m("pet.proactive_enable")}</span>
      <button type="button" id="pet-proactive-enabled" class="pet-btn pet-btn-toggle${t.enabled ? " on" : ""}" aria-pressed="${t.enabled ? "true" : "false"}">${k(pn(t.enabled))}</button>
    </div>
    <div class="pet-row">
      <span class="pet-label">${m("pet.proactive_interval")}</span>
      <input type="text" id="pet-proactive-interval" class="pet-param-num" inputmode="numeric" autocomplete="off" spellcheck="false" value="${t.intervalMin}" aria-label="${k(m("pet.proactive_interval"))}">
      <span class="pet-val">${m("pet.proactive_minute")}</span>
    </div>
    <div class="pet-row">
      <span class="pet-label">${m("pet.proactive_cap")}</span>
      <input type="text" id="pet-proactive-cap" class="pet-param-num" inputmode="numeric" autocomplete="off" spellcheck="false" value="${t.dailyCap}" aria-label="${k(m("pet.proactive_cap"))}">
      <span class="pet-val">${m("pet.proactive_cap_unit")}</span>
    </div>
    <div class="pet-note">${k(m("pet.proactive_cap_hint"))}</div>
    <div class="pet-row">
      <span class="pet-label">${m("pet.proactive_screen_poll")}</span>
      <input type="text" id="pet-proactive-poll" class="pet-param-num" inputmode="numeric" autocomplete="off" spellcheck="false" value="${t.screenPollSec}" aria-label="${k(m("pet.proactive_screen_poll"))}">
      <span class="pet-val">${m("pet.proactive_second")}</span>
    </div>
    <div class="pet-row">
      <span class="pet-label">${m("pet.proactive_screen_gap")}</span>
      <input type="text" id="pet-proactive-gap" class="pet-param-num" inputmode="numeric" autocomplete="off" spellcheck="false" value="${t.screenMinGapSec}" aria-label="${k(m("pet.proactive_screen_gap"))}">
      <span class="pet-val">${m("pet.proactive_second")}</span>
    </div>
    <div class="pet-row">
      <span class="pet-label">${m("pet.proactive_screen_diff")}</span>
      <input type="text" id="pet-proactive-diff" class="pet-param-num" inputmode="numeric" autocomplete="off" spellcheck="false" value="${t.screenDiff}" aria-label="${k(m("pet.proactive_screen_diff"))}">
    </div>
    <div class="pet-note">${k(m("pet.proactive_diff_hint"))}</div>
    <div class="pet-note" id="pet-proactive-usage">${k(c)}</div>
  </div>`;
}
const ui = 0.5, di = 2, Bn = 1, fi = 0, mi = 1, Vn = 1;
function Ra(e) {
  return typeof e != "number" || !Number.isFinite(e) ? Bn : Math.min(di, Math.max(ui, Math.round(e * 100) / 100));
}
function za(e) {
  return typeof e != "number" || !Number.isFinite(e) ? Vn : Math.min(mi, Math.max(fi, Math.round(e * 100) / 100));
}
const ds = ["disabled", "no_ref_audio", "no_ref_text", "ref_missing", "ref_out_of_spec", "assets_missing"];
function fs(e) {
  return `
  <div class="pet-tts" id="pet-tts">
    <div class="pet-debug-title">${m("pet.tts_title")}</div>
    <div class="pet-row">
      <button type="button" id="pet-tts-enabled" class="pet-btn pet-btn-toggle${e.tts ? " on" : ""}" aria-pressed="${e.tts ? "true" : "false"}">${k(pi("pet.tts_enable", e.tts))}</button>
    </div>
    <div class="pet-row">
      <span class="pet-label">${k(m("pet.tts_rate_label"))}</span>
      <input type="range" id="pet-tts-rate" class="pet-range" min="${ai}" max="${ii}" step="0.5" value="${e.speechRate}" aria-label="${k(m("pet.tts_rate_label"))}">
      <span class="pet-val" id="pet-tts-rate-val">${e.speechRate}</span>
    </div>
    <div class="pet-row">
      <span class="pet-label">${k(m("pet.tts_speed_label"))}</span>
      <input type="range" id="pet-tts-speed" class="pet-range" min="${ui}" max="${di}" step="0.1" value="${Bn}" aria-label="${k(m("pet.tts_speed_label"))}">
      <span class="pet-val" id="pet-tts-speed-val">${Bn.toFixed(1)}×</span>
    </div>
    <div class="pet-row">
      <span class="pet-label">${k(m("pet.tts_volume_label"))}</span>
      <input type="range" id="pet-tts-volume" class="pet-range" min="${fi}" max="${mi}" step="0.05" value="${Vn}" aria-label="${k(m("pet.tts_volume_label"))}">
      <span class="pet-val" id="pet-tts-volume-val">${Math.round(Vn * 100)}%</span>
    </div>
    <div class="pet-tts-voice" id="pet-tts-voice">
      <span class="pet-label">${k(m("pet.tts_voice_label"))}</span>
      <input type="text" id="pet-tts-reftext" class="pet-tts-text" autocomplete="off" spellcheck="false" placeholder="${k(m("pet.tts_ref_text_ph"))}" aria-label="${k(m("pet.tts_voice_label"))}">
      <div class="pet-row">
        <button type="button" id="pet-tts-addfile" class="pet-btn pet-btn-primary">${k(m("pet.tts_add_audio"))}</button>
      </div>
    </div>
    <div class="pet-row pet-tts-actions">
      <button type="button" id="pet-tts-preview" class="pet-btn">${k(m("pet.tts_preview"))}</button>
    </div>
    <div class="pet-note" id="pet-tts-status"></div>
    <div class="pet-note" id="pet-tts-msg"></div>
  </div>`;
}
const ms = {
  motion: "播动作",
  chain: "动作链",
  // VTS 侧对应表情的动作类型叫 “Expression on/off” —— 这里同样按**开关**语义（可叠加、再点关闭）。
  expression: "表情开关",
  param: "设参数",
  artmesh: "ArtMesh 显隐",
  artmeshColor: "ArtMesh 染色",
  part: "Part 显隐",
  physics: "开关物理"
}, hs = '<svg viewBox="0 0 16 16" width="13" height="13" aria-hidden="true" focusable="false"><path d="M8 1.6 11.2 5.2H4.8Z" fill="currentColor"/><path d="M8 14.4 4.8 10.8h6.4Z" fill="currentColor"/></svg>';
function gs() {
  return `
  <div class="pet-hotkeys" id="pet-hotkeys">
    <div class="pet-row">
      <button type="button" id="pet-hk-import" class="pet-btn pet-btn-primary" title="以模型文件夹为准重建热键表：优先读同目录 vtube.json 里的作者热键，没有就递归扫文件夹里的「中文名.exp3.json」。会自动分配默认键并落盘；按键仅供 AI 触发，本地不做按键监听。">重新导入（模型文件夹）</button>
    </div>
    <div class="pet-hk-list" id="pet-hk-list"></div>
    <div class="pet-note" id="pet-hk-msg"></div>
  </div>`;
}
function bs(e) {
  return `
  <div class="pet-motions" id="pet-motions">
    <!-- **动作链**（2026-10-10 用户口径：与「恢复默认」一样放在动作页**最上面**）：
         把多个动作排进一条时间线，每步各设「循环播放时长 / 硬停秒」。 -->
    <div class="pet-chains" id="pet-chains">
      <div class="pet-row">
        <button type="button" id="pet-chain-add" class="pet-btn pet-btn-primary" title="新建一条动作链：把多个动作排进一条时间线，每个动作各设循环播放时长与硬停秒。可在「热键」页把动作链绑成热键，AI 也可按链名触发。">新建动作链</button>
      </div>
      <div class="pet-chain-list" id="pet-chain-list"></div>
      <div class="pet-note" id="pet-chain-msg"></div>
    </div>
    <div class="pet-row">
      <button type="button" id="pet-mo-add" class="pet-btn pet-btn-primary" title="在模型文件夹里生成一个参数模板（*.motion3.json，1 秒 / 30fps / 循环），交给 AI 去编曲线。默认跳过物理输出参数。">新建动作（motion3 模板）</button>
    </div>
    <div class="pet-row">
      <span class="pet-label">${k(m("pet.motion_tpl_include_physics"))}</span>
      <button type="button" id="pet-mo-tpl-physics" class="pet-btn pet-btn-toggle${e.motionTemplateIncludePhysics ? " on" : ""}" aria-pressed="${e.motionTemplateIncludePhysics ? "true" : "false"}">${k(pn(e.motionTemplateIncludePhysics))}</button>
    </div>
    <div class="pet-note">${k(m("pet.motion_tpl_include_physics_note"))}</div>
    <div class="pet-mo-list" id="pet-mo-list"></div>
    <div class="pet-note" id="pet-mo-msg"></div>
  </div>`;
}
const hi = "lunac.pet.coreids.v1.";
function ys(e) {
  const t = {
    parameters: [],
    drawables: [],
    parts: [],
    parameterRanges: {},
    physicsInputs: [],
    physicsOutputs: []
  };
  try {
    const n = localStorage.getItem(hi + e.toLowerCase());
    if (!n) return t;
    const a = JSON.parse(n);
    return {
      parameters: Array.isArray(a.parameters) ? a.parameters : [],
      drawables: Array.isArray(a.drawables) ? a.drawables : [],
      parts: Array.isArray(a.parts) ? a.parts : [],
      parameterRanges: a.parameterRanges && typeof a.parameterRanges == "object" ? a.parameterRanges : {},
      physicsInputs: Array.isArray(a.physicsInputs) ? a.physicsInputs : [],
      physicsOutputs: Array.isArray(a.physicsOutputs) ? a.physicsOutputs : []
    };
  } catch {
    return t;
  }
}
async function la(e) {
  const t = ys(e);
  try {
    const n = await Ve(e), a = n == null ? void 0 : n.coreIds;
    if (a && (a.parameters.length || a.drawables.length || a.parts.length)) return a;
    if (t.parameters.length || t.drawables.length || t.parts.length) {
      const o = n ?? Yn(e);
      o.coreIds = t;
      const c = M().params[e];
      !Object.keys(o.params).length && c && typeof c == "object" && (o.params = { ...c }), await ln(e, o);
    }
  } catch (n) {
    console.warn("[pet] 读/播种 lunac.params.json 失败", n);
  }
  return t;
}
let Re = /* @__PURE__ */ new Map();
const qe = /* @__PURE__ */ new Map(), vs = /* @__PURE__ */ new Set();
async function gi(e) {
  const { outputs: t } = await mn(e), n = new Set(t);
  return qe.set(e.toLowerCase(), n), n;
}
async function Nn(e) {
  return qe.get(e.toLowerCase()) ?? gi(e);
}
function sn(e, t) {
  if (!t.size) return { ...e };
  const n = {};
  for (const [a, o] of Object.entries(e))
    t.has(a) || (n[a] = o);
  return n;
}
let vt = [], Dt = {
  motions: [],
  expressions: [],
  expressionFiles: {},
  parameters: [],
  drawables: [],
  parts: [],
  physicsOutputs: []
}, xe = /* @__PURE__ */ new Set();
function Lt(e) {
  const t = document.getElementById("pet-hk-msg");
  t && (t.textContent = e);
}
let nn = null;
function Ge() {
  const e = M().model.trim();
  e && (nn && clearTimeout(nn), nn = setTimeout(() => {
    nn = null, M().model.trim() === e && fn(e, vt).catch(
      (t) => Lt("保存热键失败：" + (t instanceof Error ? t.message : String(t)))
    );
  }, 400));
}
function bi(e) {
  let t = !1;
  return e.forEach((n, a) => {
    n.keys || (n.keys = fr(a), t = !0);
  }), t;
}
async function ws(e) {
  const t = [], n = /* @__PURE__ */ new Set();
  try {
    for (const a of await we(e)) {
      const o = a.action;
      if (o.type !== "expression" || !o.file) continue;
      const c = o.file.toLowerCase();
      n.has(c) || (n.add(c), t.push({ name: o.target || a.name, file: o.file }));
    }
  } catch {
  }
  return t;
}
function Ha(e) {
  return e.toLowerCase().replace(/\//g, "\\");
}
async function xs(e, t) {
  const n = t.filter((u) => u.action.type === "expression" && !!u.action.file);
  if (!n.length) return !1;
  let a;
  try {
    a = await Xa(e);
  } catch {
    return !1;
  }
  const o = /* @__PURE__ */ new Map();
  for (const u of a) u.file && o.set(Ha(u.file), u.id);
  let c = !1;
  for (const u of n) {
    if (u.action.type !== "expression" || !u.action.file) continue;
    const y = o.get(Ha(u.action.file));
    y && y !== u.action.target && (u.action.target = y, c = !0);
  }
  return c;
}
async function _s(e) {
  const t = /* @__PURE__ */ new Set();
  try {
    const n = [];
    for (const a of await we(e))
      a.action.type === "expression" && a.action.file && n.push(a.action.file);
    await Promise.all(
      n.map(async (a) => {
        for (const o of await ei(a)) t.add(o.id);
      })
    );
  } catch {
  }
  return t;
}
async function Wa(e) {
  const t = dn(e);
  try {
    const n = await d("scan_model_folder", { dir: t });
    return { dir: t, vtube: (n.vtube ?? [])[0] ?? "", cdi3: (n.cdi3 ?? [])[0] ?? "" };
  } catch {
    return { dir: t, vtube: "", cdi3: "" };
  }
}
const ks = { parameters: {} };
async function Ss(e, t) {
  var n;
  try {
    const a = await Ue(e), o = [];
    for (const c of Object.values(((n = a.FileReferences) == null ? void 0 : n.Motions) ?? {}))
      for (const u of c ?? [])
        u != null && u.File && o.push(le(t, u.File));
    return o.length ? await kr(o) : /* @__PURE__ */ new Map();
  } catch {
    return /* @__PURE__ */ new Map();
  }
}
async function Gn(e, t, n) {
  let a = [];
  if (n && (a = (await yr(n)).map((c) => _r(c, e)).filter((c) => !!c)), !a.length) {
    let o = [];
    try {
      o = await d("list_exp3_files", { dir: e });
    } catch {
      o = [];
    }
    a = o.filter((c) => typeof (c == null ? void 0 : c.path) == "string" && c.path).map((c) => {
      const u = (c.name || "").trim() || "表情";
      return Fn(u, "", { type: "expression", target: u, mode: "set", file: c.path });
    });
  }
  return a.length ? (bi(a), await xs(t, a), await fn(t, a), vt = a, Yt(), a.length) : 0;
}
let pt = [], V = [];
const ja = "lunac_";
function At(e) {
  const t = document.getElementById("pet-mo-msg");
  t && (t.textContent = e);
}
function Un(e) {
  const t = e ? M().idleMotions[e] ?? [] : [];
  return new Set(t.map((n) => n.toLowerCase()));
}
function Ba() {
  const e = M().model.trim();
  if (!e) return;
  const t = M(), n = t.idleMotions[e];
  if (!n || !n.length) return;
  const a = new Set(pt.map((u) => u.name.toLowerCase())), o = n.filter((u) => a.has(u.toLowerCase()));
  if (o.length === n.length) return;
  const c = { ...t.idleMotions };
  o.length ? c[e] = o : delete c[e], U({ ...t, idleMotions: c }), un();
}
function un() {
  const e = document.getElementById("pet-mo-list");
  if (!e) return;
  if (!pt.length) {
    e.innerHTML = '<div class="pet-note">模型文件夹里还没有 *.motion3.json —— 点「新建动作」生成一个模板。</div>';
    return;
  }
  const t = Un(M().model.trim());
  e.innerHTML = pt.map((n, a) => {
    const o = t.has(n.name.toLowerCase());
    return `<div class="pet-mo-row" data-mo-i="${a}">
      <input class="pet-mo-name" data-mo-name="${a}" spellcheck="false" value="${k(n.name)}" title="${k(n.path)}">
      <button type="button" class="pet-btn pet-btn-toggle pet-mo-idle${o ? " on" : ""}" data-mo-idle="${a}" aria-pressed="${o ? "true" : "false"}" title="循环播放：勾上后，模型闲下来（没有别的动作在播）时会按顺序轮流播放它；是否循环由该文件自己的 Meta.Loop 决定">循环：${o ? "开" : "关"}</button>
      <button type="button" class="pet-btn pet-mo-run" data-mo-run="${a}">播放</button>
      <button type="button" class="pet-btn pet-mo-del" data-mo-del="${a}">删除</button>
      <div class="pet-chain-bar pet-mo-bar" data-bar-idx="${a}"><i></i><span class="pet-mo-bar-t">${k(n.name)}</span></div>
    </div>`;
  }).join("");
}
async function ze() {
  const e = M().model.trim();
  if (!e) {
    pt = [], un(), V = [], kt(), At("先选一个 Live2D 模型 —— 「更换模型」里选模型文件夹。");
    return;
  }
  pt = await ye(e), un(), Ls(), At(pt.length ? `共 ${pt.length} 个动作文件。` : "这个模型文件夹里没扫到 *.motion3.json。");
}
function yi(e) {
  const t = document.getElementById("pet-chain-msg");
  t && (t.textContent = e);
}
function Ms(e) {
  return pt.findIndex((t) => t.path.toLowerCase() === e.toLowerCase());
}
let We = /* @__PURE__ */ new Set();
const Es = '<svg viewBox="0 0 16 16" width="11" height="11" aria-hidden="true" focusable="false"><path d="M6 3.2 10.8 8 6 12.8" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>', Cs = '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><g opacity="0.28" transform="translate(-0.7,-0.7)" stroke-width="1.6"><rect x="5" y="5" width="14" height="14" rx="2.5"/></g><rect x="5" y="5" width="14" height="14" rx="2.5"/><circle cx="8.6" cy="8.6" r="0.9" fill="currentColor" stroke="none"/></svg>', $s = '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><g opacity="0.28" transform="translate(-0.7,-0.7)" stroke-width="1.6"><rect x="9" y="2.8" width="6" height="11.4" rx="3"/><path d="M6.4 11.2a5.6 5.6 0 0 0 11.2 0"/><path d="M12 16.8V20"/></g><rect x="9" y="2.8" width="6" height="11.4" rx="3"/><path d="M6.4 11.2a5.6 5.6 0 0 0 11.2 0"/><path d="M12 16.8V20"/><circle cx="17.5" cy="17.5" r="0.4" fill="currentColor" stroke="none" opacity="0.45"/></svg>', Ts = '<svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M22 6 6 22"/><path d="M22 12 12 22"/><path d="M22 18 18 22"/></svg>';
function As(e) {
  const t = e.file.split(/[\\/]/).pop() || "(未选)", n = e.stopSec > 0 ? `${e.stopSec.toFixed(1)}s` : "不限";
  return `${t} · 循环 ${e.loopSec.toFixed(1)}s · 硬停 ${n}`;
}
async function vi(e) {
  var t;
  if (!e) return null;
  try {
    const n = await fetch(Ft(e));
    if (!n.ok) return null;
    const a = await n.json(), o = Number((t = a == null ? void 0 : a.Meta) == null ? void 0 : t.Duration);
    return Number.isFinite(o) && o > 0 ? Math.min(3600, Math.max(0.1, o)) : null;
  } catch {
    return null;
  }
}
function kt() {
  const e = document.getElementById("pet-chain-list");
  if (e) {
    if (!V.length) {
      e.innerHTML = '<div class="pet-note">还没有动作链 —— 点「新建动作链」，再把动作文件排进时间线。</div>';
      return;
    }
    e.innerHTML = V.map((t, n) => {
      const a = We.has(t.id), o = t.steps.map((u, y) => {
        const T = Ms(u.file), v = u.file.split(/[\\/]/).pop() || "(未选)", D = pt.length ? pt.map((X) => ({ value: X.path, label: X.name, selected: X.path.toLowerCase() === u.file.toLowerCase() })) : [{ value: "", label: "（没有动作文件）", selected: !0 }], E = qn(u);
        return `<div class="pet-chain-step">
          <div class="pet-chain-fields">
            ${zn("", D, `data-chain-step-file="${n}:${y}"`)}
            <label class="pet-chain-t">循环<input class="pet-chain-num" type="number" min="0.1" max="3600" step="0.1" data-chain-step-loop="${n}:${y}" value="${u.loopSec}">s</label>
            <label class="pet-chain-t">硬停<input class="pet-chain-num" type="number" min="0" max="3600" step="0.1" data-chain-step-stop="${n}:${y}" value="${u.stopSec}">s</label>
            <button type="button" class="pet-btn pet-chain-del" data-chain-step-del="${n}:${y}" title="删掉这一步">×</button>
          </div>
          <div class="pet-chain-bar" data-bar-chain="${k(t.id)}" data-bar-idx="${T}"><i></i><span>${k(v)} · ${E.toFixed(1)}s</span></div>
        </div>`;
      }).join(""), c = t.steps.length ? t.steps.map(As).join("  ·  ") : "（还没有步骤）";
      return `<div class="pet-chain${a ? " collapsed" : ""}" data-chain-i="${n}">
      <div class="pet-chain-head">
        <button type="button" class="pet-btn pet-chain-toggle${a ? "" : " on"}" data-chain-toggle="${n}" aria-expanded="${a ? "false" : "true"}" title="${a ? "展开这条链" : "收起这条链"}">${Es}</button>
        <input class="pet-chain-name" data-chain-name="${n}" spellcheck="false" value="${k(t.name)}">
        <span class="pet-chain-total">共 ${Ar(t).toFixed(1)}s</span>
        <button type="button" class="pet-btn pet-btn-toggle pet-chain-loopbtn${t.loop ? " on" : ""}" data-chain-loop="${n}" aria-pressed="${t.loop ? "true" : "false"}" title="整链循环：整条链播完从头再来；关闭则播完即停（每步自己的循环 / 硬停照旧生效）">整链循环：${t.loop ? "开" : "关"}</button>
        <button type="button" class="pet-btn pet-btn-primary pet-chain-run" data-chain-run="${k(t.id)}">播放</button>
        <button type="button" class="pet-btn pet-chain-del" data-chain-del="${n}">删除</button>
      </div>
      <div class="pet-chain-summary">${k(c)}</div>
      <div class="pet-chain-steps">${o}</div>
      <button type="button" class="pet-btn" data-chain-step-add="${n}">添加步骤</button>
    </div>`;
    }).join(""), _i(e);
  }
}
async function Ls() {
  const e = M().model.trim();
  if (!e) {
    V = [], kt();
    return;
  }
  V = await rn(e), kt(), Yt(), yi(V.length ? `共 ${V.length} 条动作链。` : "");
}
async function Ut() {
  const e = M().model.trim();
  if (e)
    try {
      await Tr(e, V);
    } catch (t) {
      yi("保存动作链失败：" + (t instanceof Error ? t.message : String(t)));
    }
}
function wi(e, t, n) {
  !V[e] || !Number.isInteger(t) || (async () => {
    const o = await vi(n), c = V[e];
    if (!c) return;
    const u = c.steps.map(
      (y, T) => T === t ? { ...y, file: n, ...o !== null ? { loopSec: o } : {} } : y
    );
    V = V.map((y, T) => T === e ? { ...y, steps: u } : y), kt(), Ut();
  })();
}
function Ns(e, t, n) {
  const a = e ? `[data-bar-chain="${CSS.escape(e)}"][data-bar-idx="${t}"]` : `.pet-mo-row [data-bar-idx="${t}"]`;
  document.querySelectorAll(a).forEach((o) => {
    const c = o.querySelector("i");
    c && (c.style.width = n === null ? "0%" : `${Math.round(n * 100)}%`);
  });
}
function Ps(e, t, n) {
  if (n) return [...e];
  const a = new Set(t);
  return e.filter((o) => !a.has(o));
}
async function Is(e) {
  const t = await la(e);
  if (!t.parameters.length) return null;
  const n = M().motionTemplateIncludePhysics, a = n ? [] : await gi(e), o = Ps(t.parameters, a, n).map((c) => {
    const u = t.parameterRanges[c], y = u && Number.isFinite(u.def) ? u.def : 0;
    return { Target: "Parameter", Id: c, Segments: [0, y, 0, 1, y] };
  });
  return JSON.stringify(
    {
      Version: 3,
      Meta: {
        Duration: 1,
        Fps: 30,
        Loop: !0,
        AreBeziersRestricted: !0,
        CurveCount: o.length,
        TotalSegmentCount: o.length,
        TotalPointCount: o.length * 2,
        UserDataCount: 0,
        TotalUserDataSize: 0
      },
      Curves: o,
      UserData: []
    },
    null,
    2
  );
}
function Os(e) {
  switch (e) {
    case "motion":
      return { type: "motion", group: "", index: 0 };
    case "chain":
      return { type: "chain", id: "" };
    case "param":
      return { type: "param", id: "", value: 0, mode: "set" };
    case "artmesh":
      return { type: "artmesh", id: "", value: 0 };
    case "artmeshColor":
      return { type: "artmeshColor", id: "", color: "#ffffff" };
    case "part":
      return { type: "part", id: "", value: 0 };
    case "physics":
      return { type: "physics", enabled: !1 };
    default:
      return { type: "expression", target: "", mode: "set" };
  }
}
function xi(e, t, n) {
  const a = () => Number(n) || 0;
  e.type === "motion" ? t === "group" ? e.group = n : t === "index" && (e.index = Math.max(0, Math.round(a()))) : e.type === "chain" ? t === "id" && (e.id = n) : e.type === "expression" ? t === "target" ? (e.target = n, e.file = Dt.expressionFiles[n] || "") : t === "mode" && (e.mode = n === "clear" ? "clear" : "set") : e.type === "param" ? t === "id" ? e.id = n : t === "mode" ? e.mode = n === "add" ? "add" : "set" : t === "value" && (e.value = a()) : e.type === "artmesh" ? t === "id" ? e.id = n : t === "value" && (e.value = Math.min(1, Math.max(0, a()))) : e.type === "artmeshColor" ? t === "id" ? e.id = n : t === "color" && (e.color = ca(n)) : e.type === "part" ? t === "id" ? e.id = n : t === "value" && (e.value = Math.min(1, Math.max(0, a()))) : e.type === "physics" && t === "enabled" && (e.enabled = n === "1");
}
function ca(e) {
  const t = (e || "").trim().replace(/^#/, "").toLowerCase();
  return /^[0-9a-f]{3}$/.test(t) ? "#" + t.split("").map((n) => n + n).join("") : /^[0-9a-f]{6}$/.test(t) ? "#" + t : "#ffffff";
}
function Ds(e) {
  const t = ca(e).slice(1);
  return {
    r: parseInt(t.slice(0, 2), 16) / 255,
    g: parseInt(t.slice(2, 4), 16) / 255,
    b: parseInt(t.slice(4, 6), 16) / 255
  };
}
function He(e, t) {
  const n = t && !e.includes(t) ? [t, ...e] : e;
  return (n.length ? n : [""]).map((o) => `<option value="${k(o)}"${o === t ? " selected" : ""}>${k(o || "（无可用项）")}</option>`).join("");
}
function Fs(e, t) {
  const n = t && !e.includes(t) ? [t, ...e] : e;
  return (n.length ? n : [""]).map((o) => ({ value: o, label: o || "（无可用项）", selected: o === t }));
}
function _i(e) {
  e.querySelectorAll(".custom-select").forEach((t) => {
    Ir(t, {
      scope: document,
      onPick: (n) => {
        const a = t.closest(".pet-hk-row");
        if (a) {
          const c = vt.find((y) => y.id === a.dataset.hkId);
          if (!c) return;
          const u = t.getAttribute("data-hk-field");
          u === "type" ? (c.action = Os(n), Yt(), Ge()) : u === "target" && (xi(c.action, "target", n), Ge());
          return;
        }
        const o = t.getAttribute("data-chain-step-file");
        if (o) {
          const [c, u] = o.split(":").map((y) => Number.parseInt(y, 10));
          wi(c, u, n);
        }
      }
    });
  });
}
function Yt() {
  const e = document.getElementById("pet-hk-list");
  e && (e.innerHTML = vt.map((t) => {
    const n = t.action, a = pr.map(
      (c) => ({ value: c, label: ms[c], selected: c === n.type })
    );
    let o = "";
    if (n.type === "motion")
      o = `<select data-hk-field="group">${He(Dt.motions.map((c) => c.group), n.group)}</select><input class="pet-hk-num" data-hk-field="index" inputmode="numeric" value="${n.index}">`;
    else if (n.type === "expression")
      o = zn("", Fs(Dt.expressions, n.target), 'data-hk-field="target" title="表情对象（模型可用的表情）"');
    else if (n.type === "chain") {
      const c = V.map((u) => ({ id: u.id, name: u.name }));
      n.id && !c.some((u) => u.id === n.id) && c.unshift({ id: n.id, name: "（已删除的动作链）" }), o = c.length ? `<select data-hk-field="id">${c.map((u) => `<option value="${k(u.id)}"${u.id === n.id ? " selected" : ""}>${k(u.name || u.id)}</option>`).join("")}</select>` : '<span class="pet-hk-target">（还没有动作链）</span>';
    } else n.type === "param" ? o = `<select data-hk-field="id">${He(Dt.parameters, n.id)}</select><select data-hk-field="mode"><option value="set"${n.mode === "set" ? " selected" : ""}>设为</option><option value="add"${n.mode === "add" ? " selected" : ""}>加</option></select><input class="pet-hk-num" data-hk-field="value" inputmode="decimal" value="${n.value}">` : n.type === "artmesh" ? o = `<select data-hk-field="id">${He(Dt.drawables, n.id)}</select><input class="pet-hk-num" data-hk-field="value" inputmode="decimal" value="${n.value}">` : n.type === "artmeshColor" ? o = `<select data-hk-field="id">${He(Dt.drawables, n.id)}</select><input class="pet-hk-color" type="color" data-hk-field="color" value="${k(ca(n.color))}" title="点一下选颜色（原色 = #ffffff）">` : n.type === "part" ? o = `<select data-hk-field="id">${He(Dt.parts, n.id)}</select><input class="pet-hk-num" data-hk-field="value" inputmode="decimal" value="${n.value}">` : o = `<select data-hk-field="enabled"><option value="1"${n.enabled ? " selected" : ""}>开</option><option value="0"${n.enabled ? "" : " selected"}>关</option></select>`;
    return `<div class="pet-hk-row" data-hk-id="${k(t.id)}">
        <input class="pet-hk-name" data-hk-field="name" spellcheck="false" value="${k(t.name)}">
        ${zn("", a, 'data-hk-field="type"')}
        ${o}
        <button type="button" class="pet-btn pet-btn-toggle pet-hk-run${xe.has(t.id) ? " on" : ""}" data-hk-run="1" aria-pressed="${xe.has(t.id) ? "true" : "false"}">${xe.has(t.id) ? "开" : "关"}</button>
        <button type="button" class="pet-btn pet-hk-del" data-hk-del="1">删除</button>
      </div>`;
  }).join(""), _i(e));
}
async function Pn() {
  const e = M().model.trim();
  if (!e) {
    vt = [], Yt(), Lt("先选一个 Live2D 模型 —— 热键要跟它存在同一个文件夹里。");
    return;
  }
  const t = await la(e);
  if (Dt = await br(e, t), qe.set(e.toLowerCase(), new Set(Dt.physicsOutputs)), vt = await we(e), bi(vt))
    try {
      await fn(e, vt);
    } catch {
    }
  Yt(), Lt(
    t.parameters.length || t.drawables.length ? "" : "提示：先在主界面「显示桌宠」一次，才能拿到该模型的参数 / ArtMesh / Part 清单（现在只有动作、表情、物理可选）。"
  );
}
const ki = "lunac-pet-settings-tab";
function Rs() {
  try {
    return localStorage.getItem(ki) ?? "";
  } catch {
    return "";
  }
}
function zs(e) {
  try {
    localStorage.setItem(ki, e);
  } catch {
  }
}
function Va(e, t) {
  var c;
  const n = Array.from(e.querySelectorAll(".pet-tabpage")), a = ((c = n[0]) == null ? void 0 : c.dataset.petPage) ?? "", o = n.some((u) => u.dataset.petPage === t) ? t : a;
  return e.querySelectorAll(".pet-tab").forEach((u) => {
    u.classList.toggle("on", u.dataset.petTab === o);
  }), n.forEach((u) => {
    u.hidden = u.dataset.petPage !== o;
  }), o;
}
function Hs(e) {
  return `
<div class="pet-console">
  <div class="pet-row pet-row-main">
    <button id="pet-toggle" class="pet-btn pet-btn-primary">显示桌宠</button>
    <button id="pet-change" class="pet-btn">更换模型…</button>
    <button id="pet-clear" class="pet-btn" ${!!e.model.trim() || !!e.image.trim() ? "" : "hidden"}>取消配置</button>
    <button type="button" id="pet-through" class="pet-btn pet-btn-toggle${e.clickThrough ? " on" : ""}" aria-pressed="${e.clickThrough ? "true" : "false"}">${k(bn(e.clickThrough))}</button>
  </div>
  <div class="pet-row">
    <span class="pet-label">形象大小</span>
    <input type="range" id="pet-scale" class="pet-range" min="40" max="800" step="5" value="${Math.round(e.scale * 100)}">
    <span class="pet-val" id="pet-scale-val">${Math.round(e.scale * 100)}%</span>
  </div>
  <div class="pet-row">
    <span class="pet-label">旋转角度</span>
    <input type="range" id="pet-rot" class="pet-range" min="-180" max="180" step="1" value="${Math.round(e.rotation)}">
    <span class="pet-val" id="pet-rot-val">${Math.round(e.rotation)}°</span>
  </div>
  <div class="pet-file" id="pet-file"></div>
  <div class="pet-note">该插件只提供 Live2D 模型入口。</div>
  <div class="pet-note">${m("pet.hint_interactions")}</div>
  <div class="pet-tabs" id="pet-tabs">
    <button type="button" class="pet-tab on" data-pet-tab="debug">${k(m("pet.debug_title"))}</button>
    <button type="button" class="pet-tab" data-pet-tab="hotkey">${k(m("pet.hotkey_title"))}</button>
    <button type="button" class="pet-tab" data-pet-tab="motion">${k(m("pet.motions_title"))}</button>
    <button type="button" class="pet-tab" data-pet-tab="proactive">${k(m("pet.proactive_title"))}</button>
    <button type="button" class="pet-tab" data-pet-tab="voice">${k(m("pet.tts_title"))}</button>
    <button type="button" class="pet-tab" data-pet-tab="persona">${k(m("pet.persona_title"))}</button>
  </div>
  <div class="pet-tabpage" data-pet-page="debug">
    <div class="pet-row pet-reset-row">
      <button type="button" id="pet-reset-debug" class="pet-btn" title="把该模型调过的参数全部恢复默认（会清掉你的调整）">恢复默认</button>
    </div>
    <div class="pet-note">${k(m("pet.debug_phys_pin_note"))}</div>
    <div class="pet-debug" id="pet-debug">
      <div class="pet-debug-note" id="pet-debug-note" hidden></div>
      <div class="pet-debug-body" id="pet-debug-body"></div>
    </div>
  </div>
  <div class="pet-tabpage" data-pet-page="hotkey" hidden>
    <div class="pet-row pet-reset-row">
      <button type="button" id="pet-reset-hotkeys" class="pet-btn" title="清空当前热键表（可再点「重新导入」重建）">恢复默认</button>
    </div>
    ${gs()}
  </div>
  <div class="pet-tabpage" data-pet-page="motion" hidden>
    <div class="pet-row pet-reset-row">
      <button type="button" id="pet-reset-motions" class="pet-btn" title="删掉本模型文件夹里由本插件生成的 *.motion3.json">恢复默认</button>
    </div>
    ${bs(e)}
  </div>
  <!-- 三个新分页（2026-10-13）：把原先散在页签之外的三块控件搬进来。
       迁移只挪节点、接线（事件委托 / 落盘）原样复用，语义不分叉。 -->
  <div class="pet-tabpage" data-pet-page="proactive" hidden>
    ${us(e)}
  </div>
  <div class="pet-tabpage" data-pet-page="voice" hidden>
    ${fs(e)}
  </div>
  <div class="pet-tabpage" data-pet-page="persona" hidden>
    <div class="pet-persona" id="pet-persona">
      <div class="pet-debug-title">${m("pet.persona_core_title")}</div>
      <div class="pet-note">${m("pet.persona_hint")}</div>
      <textarea id="pet-persona-text" class="pet-persona-text" rows="6" spellcheck="false" maxlength="8000" placeholder=""></textarea>
      <div class="pet-row pet-persona-actions">
        <button type="button" id="pet-persona-save" class="pet-btn pet-btn-primary">${m("settings.persona_save")}</button>
        <button type="button" id="pet-persona-clear" class="pet-btn" data-armed-text="${k(m("pet.list_clear_armed"))}">${m("pet.persona_clear")}</button>
        <button type="button" id="pet-persona-restart" class="pet-btn">${m("settings.persona_restart")}</button>
      </div>
      <div class="pet-note" id="pet-persona-msg"></div>
    </div>
    <!-- 事实记忆 = ModuleDatamemorypetMEMORY.md（AI 经 Remember 写） -->
    <div class="pet-list" id="pet-memory">
      <div class="pet-debug-title">${m("pet.memory_title")}</div>
      <div class="pet-note">${m("pet.memory_desc")}</div>
      <div class="pet-list-items" id="pet-memory-items"></div>
      <div class="pet-row">
        <button type="button" id="pet-memory-clear" class="pet-btn pet-list-clear" data-pet-clear="memory" data-armed-text="${k(m("pet.list_clear_armed"))}">${k(m("pet.list_clear"))}</button>
      </div>
      <div class="pet-note" id="pet-memory-msg"></div>
    </div>
    <!-- 成长笔记 = ModuleDatamemorypetGROWTH.md（AI 经 PetGrowth 写）—— 与上面那份**不是一个文件** -->
    <div class="pet-list" id="pet-growth">
      <div class="pet-debug-title">${m("pet.growth_title")}</div>
      <div class="pet-note">${m("pet.growth_desc")}</div>
      <div class="pet-list-items" id="pet-growth-items"></div>
      <div class="pet-row">
        <button type="button" id="pet-growth-clear" class="pet-btn pet-list-clear" data-pet-clear="growth" data-armed-text="${k(m("pet.list_clear_armed"))}">${k(m("pet.list_clear"))}</button>
      </div>
      <div class="pet-note" id="pet-growth-msg"></div>
    </div>
    <!-- 人格建议 = ModuleDatamemorypetPERSONA_SUGGESTIONS.md；「接受」= 事前确认后并入核心
         人格，「清空」= 只丢弃建议（不写核心人格）-->
    <div class="pet-list" id="pet-suggest">
      <div class="pet-debug-title">${m("pet.suggest_title")}</div>
      <div class="pet-note">${m("pet.suggest_desc")}</div>
      <div class="pet-list-items" id="pet-suggest-items"></div>
      <div class="pet-row">
        <button type="button" id="pet-suggest-clear" class="pet-btn pet-list-clear" data-pet-clear="suggest" data-armed-text="${k(m("pet.suggest_clear_armed"))}">${k(m("pet.list_clear"))}</button>
      </div>
      <div class="pet-note" id="pet-suggest-msg"></div>
    </div>
  </div>
</div>`;
}
function Si() {
  if (document.getElementById("pet-style")) return;
  const e = document.createElement("style");
  e.id = "pet-style", e.textContent = Bs, document.head.appendChild(e);
}
async function Ws(e) {
  const t = (i) => e.querySelector(`#${i}`);
  let n = null;
  const a = (i, l) => void d("log_frontend", {
    level: "error",
    message: `[pet console] ${i}: ${l instanceof Error ? l.message : String(l)}`
  }).catch(() => {
  }), o = (i = "") => {
    Zt();
    const l = M(), b = l.model.trim(), p = l.image.trim(), S = t("pet-clear");
    S && (S.hidden = !(b || p));
    const P = t("pet-file");
    if (!P) return;
    const $ = i ? `<br><span class="pet-dim">${k(i)}</span>` : "";
    b ? P.innerHTML = `当前用 Live2D 模型：<code>${k(b)}</code>${$}` : p ? P.innerHTML = `当前用图片：<code>${k(p)}</code>${$}` : P.innerHTML = "还没有模型 —— 点「更换模型」选一个文件夹（里面要有 <code>*.model3.json</code>）。";
  };
  async function c() {
    await d("open_plugin_window", { pluginId: "pet", key: null, input: "" });
  }
  const u = (i) => {
    const l = t("pet-toggle");
    l && (l.textContent = i ? "隐藏模型" : "显示桌宠");
  }, y = (i) => {
    const l = t("pet-through");
    l && (l.textContent = bn(i), l.classList.toggle("on", i), l.setAttribute("aria-pressed", i ? "true" : "false"));
  }, T = () => new Promise((i) => {
    const l = `p${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
    let b = !1;
    const p = (P) => {
      b || (b = !0, S.then(($) => $()).catch(() => {
      }), i(P));
    }, S = ht(B, (P) => {
      var $, x;
      (($ = P.payload) == null ? void 0 : $.type) === "pong" && ((x = P.payload) == null ? void 0 : x.token) === l && p({ alive: !0, visible: P.payload.visible !== !1 });
    });
    S.then(() => Y(B, { type: "ping", token: l })).catch(() => {
    }), setTimeout(() => p({ alive: !1, visible: !1 }), 400);
  }), v = async () => (await T()).alive, D = () => void T().then((i) => u(i.alive && i.visible)), E = setInterval(D, 3e3);
  let X = null, rt = null;
  const K = (i, l) => {
    if (X = { id: i, value: l }, rt) return;
    const b = () => {
      rt = null;
      const p = X;
      if (X = null, p) {
        const S = M().model.trim();
        S && dt(S, p.id, p.value), Y(B, { type: "set-param", id: p.id, value: p.value });
      }
    };
    b(), rt = setTimeout(b, 50);
  }, it = async (i) => {
    const l = await Nn(i);
    try {
      const p = await Ve(i);
      if (p && Object.keys(p.params).length)
        return sn(p.params, l);
    } catch {
    }
    const b = M().params[i];
    return b && typeof b == "object" ? sn(b, l) : {};
  };
  let J = null, Z = null;
  const A = () => {
    J = null;
    const i = Z;
    Z = null, i && (async () => {
      try {
        const l = await Ve(i) ?? Yn(i), b = M().params[i], p = await Nn(i);
        l.params = b && typeof b == "object" ? sn(b, p) : {}, await ln(i, l);
      } catch (l) {
        console.warn("[pet] 写 lunac.params.json 失败", l);
      }
    })();
  }, z = (i) => {
    Z = i, !J && (J = setTimeout(A, 400));
  }, dt = (i, l, b) => {
    (async () => {
      if ((await Nn(i)).has(l)) return;
      const p = M(), S = { ...p.params };
      S[i] = { ...S[i] ?? {}, [l]: b }, U({ ...p, params: S }), z(i);
    })();
  }, ce = async (i) => {
    const l = await it(i);
    for (const b of Re.keys()) {
      const p = typeof l[b] == "number" ? l[b] : 0, S = e.querySelector(`.pet-range[data-param="${b}"]`);
      S && (S.value = String(p));
      const P = e.querySelector(`[data-param-val="${b}"]`);
      P && (P.value = String(p));
      const $ = e.querySelector(`[data-param-sw="${b}"]`);
      if ($) {
        const x = p >= 0.5;
        $.classList.toggle("on", x), $.setAttribute("aria-pressed", x ? "true" : "false"), $.textContent = x ? "开" : "关";
      }
    }
  }, et = (i) => {
    const l = i.dataset.paramVal;
    if (!l) return;
    const b = Re.get(l);
    if (!b) return;
    const p = e.querySelector(`.pet-range[data-param="${l}"]`), S = Number.parseFloat(i.value.trim());
    if (!Number.isFinite(S)) {
      i.value = (p == null ? void 0 : p.value) ?? "0";
      return;
    }
    const P = Math.round(Math.min(b.max, Math.max(b.min, S)) * 1e3) / 1e3;
    i.value = String(P), p && (p.value = String(P)), K(l, P);
  }, ot = () => {
    const i = M().proactive;
    Y(B, {
      type: "set-proactive",
      enabled: i.enabled,
      intervalMin: i.intervalMin,
      dailyCap: i.dailyCap,
      screenPollSec: i.screenPollSec,
      screenMinGapSec: i.screenMinGapSec,
      screenDiff: i.screenDiff
    });
  }, St = () => {
    const i = t("pet-proactive-usage");
    if (!i) return;
    const l = M().proactive, b = oa(), p = l.dailyCap > 0 ? String(l.dailyCap) : m("pet.proactive_unlimited"), S = m("pet.proactive_usage", { used: String(b), cap: p });
    i.textContent = Ot(l) ? `${S} · ${m("pet.proactive_reached")}` : S;
  }, Nt = (i) => {
    const l = M(), b = Number.parseInt(i.value.trim(), 10);
    if (!Number.isFinite(b) || b < 0) {
      i.value = String(l.proactive.dailyCap);
      return;
    }
    const p = ct(b, Qn, ta, l.proactive.dailyCap);
    i.value = String(p), U({ ...l, proactive: { ...l.proactive, dailyCap: p } }), ot(), St();
  }, Rt = (i) => {
    const l = M(), b = Number.parseInt(i.value.trim(), 10);
    if (!Number.isFinite(b)) {
      i.value = String(l.proactive.intervalMin);
      return;
    }
    const p = ct(b, Jn, Zn, l.proactive.intervalMin);
    i.value = String(p), U({ ...l, proactive: { ...l.proactive, intervalMin: p } }), ot();
  }, zt = (i) => {
    const l = M(), b = Number.parseInt(i.value.trim(), 10);
    if (!Number.isFinite(b)) {
      i.value = String(l.proactive.screenPollSec);
      return;
    }
    const p = ct(b, ea, na, l.proactive.screenPollSec);
    i.value = String(p), U({ ...l, proactive: { ...l.proactive, screenPollSec: p } }), ot();
  }, Ht = (i) => {
    const l = M(), b = Number.parseInt(i.value.trim(), 10);
    if (!Number.isFinite(b)) {
      i.value = String(l.proactive.screenMinGapSec);
      return;
    }
    const p = ct(b, ra, sa, l.proactive.screenMinGapSec);
    i.value = String(p), U({ ...l, proactive: { ...l.proactive, screenMinGapSec: p } }), ot();
  }, ke = (i) => {
    const l = M(), b = Number.parseInt(i.value.trim(), 10);
    if (!Number.isFinite(b)) {
      i.value = String(l.proactive.screenDiff);
      return;
    }
    const p = ct(b, aa, ia, l.proactive.screenDiff);
    i.value = String(p), U({ ...l, proactive: { ...l.proactive, screenDiff: p } }), ot();
  }, Wt = "pet-agent-restart", st = "pet-agent-restart-done", pe = m("settings.persona_saved"), Se = m("pet.persona_cleared"), Xt = m("pet.persona_restarting"), Kt = (i) => {
    const l = t("pet-persona-msg");
    l && (l.textContent = i);
  }, Me = async () => {
    try {
      const i = await d("get_pet_persona"), l = t("pet-persona-text");
      l && (i != null && i.maxChars && (l.maxLength = i.maxChars), l.value = (i == null ? void 0 : i.text) ?? "");
    } catch (i) {
      a("读取桌宠人格失败", i);
    }
  }, Ee = async (i, l) => {
    try {
      await d("set_pet_persona", { text: i }), Kt(l + m("pet.persona_effective"));
    } catch (b) {
      Kt(m("settings.persona_failed", { err: String(b) }));
    }
  }, gt = {
    memory: { get: "get_pet_memory", del: "delete_pet_memory_note", clear: "clear_pet_memory", cleared: "pet.memory_cleared", merge: !1, items: "pet-memory-items", msg: "pet-memory-msg" },
    growth: { get: "get_pet_growth", del: "delete_pet_growth_note", clear: "clear_pet_growth", cleared: "pet.growth_cleared", merge: !1, items: "pet-growth-items", msg: "pet-growth-msg" },
    suggest: { get: "get_persona_suggestions", del: "delete_persona_suggestion", clear: "clear_persona_suggestions", cleared: "pet.suggest_cleared", merge: !0, items: "pet-suggest-items", msg: "pet-suggest-msg" }
  }, Pt = (i, l, b = !1) => {
    const p = t(gt[i].msg);
    p && (p.className = b ? "pet-note pet-bad" : "pet-note", p.textContent = l);
  }, Jt = (i, l) => {
    if (i.dataset.armed === "1") {
      delete i.dataset.armed, i.textContent = i.dataset.armedRestore ?? i.textContent, delete i.dataset.armedRestore, l();
      return;
    }
    i.dataset.armedRestore = i.textContent ?? "", i.dataset.armed = "1";
    const b = i.dataset.armedText;
    b && (i.textContent = b), window.setTimeout(() => {
      i.dataset.armed === "1" && (delete i.dataset.armed, i.textContent = i.dataset.armedRestore ?? i.textContent, delete i.dataset.armedRestore);
    }, 4e3);
  }, Ce = (i, l) => {
    const b = t(gt[i].items);
    if (!b) return;
    const p = document.createDocumentFragment();
    if (!l.length) {
      const S = document.createElement("div");
      S.className = "pet-list-empty", S.textContent = m(`pet.${i}_empty`), p.appendChild(S), b.replaceChildren(p);
      return;
    }
    for (const S of l) {
      const P = document.createElement("div");
      P.className = "pet-list-row";
      const $ = document.createElement("div");
      $.className = "pet-list-text", $.textContent = S, P.appendChild($);
      const x = document.createElement("div");
      if (x.className = "pet-list-acts", gt[i].merge) {
        const j = document.createElement("button");
        j.type = "button", j.className = "pet-btn pet-suggest-accept", j.dataset.petMerge = S, j.dataset.armedText = m("pet.suggest_accept_armed"), j.textContent = m("pet.suggest_accept"), x.appendChild(j);
      }
      const I = document.createElement("button");
      I.type = "button", I.className = "pet-btn pet-list-del", I.dataset.petDel = S, I.dataset.petList = i, I.dataset.armedText = m("pet.item_del_armed"), I.textContent = m("pet.item_del"), x.appendChild(I), P.appendChild(x), p.appendChild(P);
    }
    b.replaceChildren(p);
  }, bt = async (i) => {
    try {
      const l = await d(gt[i].get);
      Ce(i, l.entries ?? []);
    } catch (l) {
      a(`读取列表失败（${i}）`, l);
      const b = t(gt[i].items);
      if (b) {
        const p = document.createElement("div");
        p.className = "pet-list-empty pet-bad", p.textContent = m("pet.list_load_fail"), b.replaceChildren(p);
      }
    }
  }, ue = async (i, l) => {
    try {
      await d(gt[i].del, { text: l }), Pt(i, ""), await bt(i);
    } catch (b) {
      a(`删除列表条目失败（${i}）`, b), Pt(i, m("pet.list_fail"), !0);
    }
  }, $e = async (i) => {
    const l = gt[i].clear;
    if (l)
      try {
        await d(l), Pt(i, m(gt[i].cleared)), await bt(i);
      } catch (b) {
        a(`清空列表失败（${i}）`, b), Pt(i, m("pet.list_fail"), !0);
      }
  }, jt = async (i) => {
    try {
      await d("merge_persona_suggestion", { text: i }), await Me(), await bt("suggest"), Pt("suggest", m("pet.suggest_accepted"));
    } catch (l) {
      a("合并人格建议失败", l), Pt("suggest", m("pet.merge_fail"), !0);
    }
  }, de = (i) => {
    const l = t("pet-debug-note");
    l && (l.textContent = i, l.hidden = !i);
  };
  let fe = "";
  const Mt = (i, l) => {
    const b = M(), p = { ...b.expressions };
    l ? p[i] = l : delete p[i], U({ ...b, expressions: p });
  }, Te = () => {
    const i = t("pet-exprs");
    i && i.querySelectorAll("[data-expr]").forEach((l) => {
      l.classList.toggle("on", !!fe && l.dataset.expr === fe);
    });
  }, Ae = (i) => {
    fe = i, Te();
    const l = M().model.trim();
    l && Mt(l, i), Y(B, { type: "set-expression", id: i });
  }, yn = (i, l) => {
    const b = An.find((q) => q.id === i), p = l.range ? l.range.min : b ? b.min : -100, S = l.range ? l.range.max : b ? b.max : 100, P = S - p, $ = P <= 2 ? 0.01 : P <= 20 ? 0.1 : 1;
    Re.set(i, { min: p, max: S });
    const x = b ? m(b.labelKey) : l.friendly || i, I = l.physIn ? `<span class="pet-phys-tag">${k(m("pet.debug_phys_in"))}</span>` : l.physOut ? `<span class="pet-phys-tag" title="${k(m("pet.debug_phys_pin_note"))}">${k(m("pet.debug_phys_out"))}</span>` : "", j = `<button type="button" class="pet-param-kind" data-param-kind="${k(i)}" data-kind="${l.isSwitch ? "switch" : "range"}" title="切换控件形态（开关 / 拉条）">${hs}</button>`;
    return l.isSwitch ? `<div class="pet-param">
        <span class="pet-label" title="${k(i)}">${k(x)}${I}</span>
        <input type="range" class="pet-range" data-param="${k(i)}" min="0" max="1" step="1" value="0" hidden>
        <button type="button" class="pet-btn pet-btn-toggle pet-param-on" data-param-sw="${k(i)}" aria-pressed="false">关</button>
        ${j}
      </div>` : `<div class="pet-param">
      <span class="pet-label" title="${k(i)}">${k(x)}${I}</span>
      <input type="range" class="pet-range" data-param="${k(i)}" min="${p}" max="${S}" step="${$}" value="0">
      <input type="text" class="pet-param-num" data-param-val="${k(i)}" inputmode="decimal" autocomplete="off" spellcheck="false" value="0" aria-label="${k(i)}">
      ${j}
    </div>`;
  };
  async function Zt() {
    const i = M(), l = !!i.model.trim(), b = t("pet-debug-body");
    if (b == null || b.classList.toggle("off", !l), !l || !b) {
      de(m("pet.debug_need_model"));
      return;
    }
    const p = i.model.trim(), S = await la(p), P = await Wa(p), $ = P.cdi3 ? await wr(P.cdi3) : ks, x = await mn(p);
    qe.set(p.toLowerCase(), new Set(x.outputs));
    const I = new Set(x.inputs), j = new Set(x.outputs), q = [], nt = (O) => {
      O && !q.includes(O) && q.push(O);
    }, R = S.parameters.length ? S.parameters : An.map((O) => O.id);
    for (const O of An) R.includes(O.id) && nt(O.id);
    for (const O of R) nt(O);
    const f = await _s(p), _ = new Set(P.vtube ? await vr(P.vtube) : []), L = q.filter((O) => !f.has(O) && !_.has(O)), h = i.paramKinds[p] ?? {}, C = await Ss(p, P.dir), F = (O) => {
      const tt = h[O];
      if (tt) return tt === "switch";
      const ut = S.parameterRanges[O];
      if (!ut || ut.min !== 0 || ut.max !== 1) return !1;
      const ee = C.get(O);
      if (!ee || !ee.size) return !0;
      for (const Ie of ee) if (Ie !== 0 && Ie !== 1) return !1;
      return !0;
    };
    Re = /* @__PURE__ */ new Map(), b.innerHTML = L.map(
      (O) => yn(O, {
        range: S.parameterRanges[O],
        physIn: I.has(O),
        physOut: j.has(O),
        friendly: $.parameters[O] ?? "",
        isSwitch: F(O)
      })
    ).join(""), await ce(p), de(await v() ? "" : m("pet.debug_pet_closed"));
  }
  const Bt = async () => {
    const i = M(), l = i.model.trim();
    if (!l) return;
    const b = { ...i.params };
    delete b[l], U({ ...i, params: b });
    try {
      const p = await Ve(l);
      p && (p.params = {}, await ln(l, p));
    } catch (p) {
      console.warn("[pet] 清 lunac.params.json 的 params 失败", p);
    }
    Y(B, { type: "reset-params", ids: [...Re.keys()] }), await ce(l), de("参数已恢复默认。");
  }, me = () => {
    const i = M().model.trim();
    i && (vt = [], xe = /* @__PURE__ */ new Set(), Yt(), fn(i, []).catch((l) => a("清空热键失败", l)), Lt("已清空热键表。"));
  }, Qt = () => {
    (async () => {
      const i = M().model.trim();
      if (!i) return;
      const l = pt.filter((p) => p.name.toLowerCase().startsWith(ja));
      if (!l.length) {
        At("没有本插件生成的动作文件（只删 lunac_ 开头的）。");
        return;
      }
      let b = 0;
      for (const p of l)
        try {
          await d("delete_motion_file", { modelPath: i, name: p.path.split(/[\\/]/).pop() || "" }), b++;
        } catch (S) {
          a("删除动作文件失败", S);
        }
      await ze(), Ba(), Y(B, { type: "reload" }), At(`已删除 ${b} 个生成的动作文件。`);
    })();
  }, Et = "__lunacPetConsoleDelegate", Vt = e;
  if (!Vt[Et]) {
    Vt[Et] = !0;
    const i = (R) => {
      var L;
      const f = R.target;
      if (!f) return;
      const _ = f.closest("[data-pet-tab]");
      if (_) {
        const h = Va(e, _.dataset.petTab ?? "");
        h && zs(h);
        return;
      }
      if (f.closest("#pet-toggle"))
        (async () => {
          const h = await T();
          if (h.alive && h.visible) {
            Y(B, { type: "hide" }).catch((F) => a("隐藏模型失败", F)), u(!1);
            return;
          }
          if (h.alive) {
            Y(B, { type: "show" }).catch((F) => a("显示模型失败", F)), u(!0), Zt();
            return;
          }
          const C = M();
          !C.model.trim() && !C.image.trim() && !await Pe() || (await c(), u(!0), Zt());
        })().catch((h) => a("显示桌宠失败", h));
      else if (f.closest("#pet-change"))
        Pe().catch((h) => a("更换形象失败", h));
      else if (f.closest("#pet-clear"))
        U({ ...M(), model: "", image: "" }), cn(""), o(), Y(B, { type: "reload" }), Pn(), ze();
      else if (f.closest("#pet-through")) {
        const h = !M().clickThrough;
        U({ ...M(), clickThrough: h }), y(h), Y(B, { type: "set-click-through", value: h });
      } else if (f.closest("#pet-proactive-enabled")) {
        const h = f.closest("#pet-proactive-enabled");
        if (!h) return;
        const C = !h.classList.contains("on"), F = M();
        U({ ...F, proactive: { ...F.proactive, enabled: C } }), h.classList.toggle("on", C), h.setAttribute("aria-pressed", C ? "true" : "false"), h.textContent = pn(C), ot(), St();
      } else if (f.closest("#pet-tts-enabled")) {
        const h = f.closest("#pet-tts-enabled");
        if (!h) return;
        const C = !h.classList.contains("on");
        U({ ...M(), tts: C }), h.classList.toggle("on", C), h.setAttribute("aria-pressed", C ? "true" : "false"), h.textContent = pi("pet.tts_enable", C);
      } else if (f.closest("#pet-tts-addfile"))
        Ct().catch((h) => a("导入参考音色失败", h));
      else if (f.closest("#pet-tts-preview"))
        Ye();
      else if (f.closest("[data-param-sw]")) {
        if ((L = t("pet-debug-body")) != null && L.classList.contains("off")) return;
        const h = f.closest("[data-param-sw]"), C = (h == null ? void 0 : h.dataset.paramSw) ?? "";
        if (!h || !C) return;
        const F = !h.classList.contains("on");
        h.classList.toggle("on", F), h.setAttribute("aria-pressed", F ? "true" : "false"), h.textContent = F ? "开" : "关";
        const O = e.querySelector(`.pet-range[data-param="${C}"]`);
        O && (O.value = F ? "1" : "0"), K(C, F ? 1 : 0);
      } else if (f.closest("[data-param-kind]")) {
        const h = f.closest("[data-param-kind]"), C = (h == null ? void 0 : h.dataset.paramKind) ?? "", F = M().model.trim();
        if (!h || !C || !F) return;
        const O = M(), tt = { ...O.paramKinds }, ut = h.dataset.kind === "switch" ? "switch" : "range";
        tt[F] = { ...tt[F] ?? {}, [C]: ut === "switch" ? "range" : "switch" }, U({ ...O, paramKinds: tt }), Zt();
      } else if (f.closest("#pet-persona-save")) {
        const h = t("pet-persona-text");
        Ee((h == null ? void 0 : h.value) ?? "", pe).catch((C) => a("保存桌宠人格失败", C));
      } else if (f.closest("#pet-persona-clear")) {
        const h = t("pet-persona-clear");
        if (!h) return;
        Jt(h, () => {
          const C = t("pet-persona-text");
          C && (C.value = ""), Ee("", Se).catch((F) => a("清空桌宠人格失败", F));
        });
      } else if (f.closest("#pet-persona-restart"))
        Kt(Xt), Y(Wt).catch((h) => a("重启 AI 请求失败", h));
      else if (f.closest("[data-pet-merge]")) {
        const h = f.closest("[data-pet-merge]");
        if (!h) return;
        const C = h.dataset.petMerge ?? "";
        Jt(h, () => {
          C && jt(C).catch((F) => a("合并人格建议失败", F));
        });
      } else if (f.closest("[data-pet-del]")) {
        const h = f.closest("[data-pet-del]");
        if (!h) return;
        const C = h.dataset.petList, F = h.dataset.petDel ?? "";
        if (!C || !gt[C]) return;
        Jt(h, () => {
          F && ue(C, F).catch((O) => a("删除列表条目失败", O));
        });
      } else if (f.closest("[data-pet-clear]")) {
        const h = f.closest("[data-pet-clear]");
        if (!h) return;
        const C = h.dataset.petClear;
        if (!C || !gt[C]) return;
        Jt(h, () => void $e(C).catch((F) => a(`清空列表失败（${C}）`, F)));
      } else if (f.closest("#pet-reset-debug"))
        Bt();
      else if (f.closest("#pet-reset-hotkeys"))
        me();
      else if (f.closest("#pet-reset-motions"))
        Qt();
      else {
        const h = f.closest("[data-expr]");
        if (h) {
          const C = h.dataset.expr ?? "";
          Ae(C && C === fe ? "" : C);
        }
      }
    }, l = (R) => {
      var _;
      const f = R.target;
      if (f) {
        if (f.id === "pet-proactive-cap") {
          Nt(f);
          return;
        }
        if (f.id === "pet-proactive-interval") {
          Rt(f);
          return;
        }
        if (f.id === "pet-proactive-poll") {
          zt(f);
          return;
        }
        if (f.id === "pet-proactive-gap") {
          Ht(f);
          return;
        }
        if (f.id === "pet-proactive-diff") {
          ke(f);
          return;
        }
        if (f.id === "pet-tts-reftext") {
          Ne(f.value).catch((L) => a("保存参考文本失败", L));
          return;
        }
        if (f.matches("[data-param-val]")) {
          if ((_ = t("pet-debug-body")) != null && _.classList.contains("off")) return;
          et(f);
        }
      }
    }, b = (R) => {
      var _;
      const f = R.target;
      if (!(!f || R.key !== "Enter")) {
        if (f.id === "pet-proactive-cap") {
          R.preventDefault(), Nt(f);
          return;
        }
        if (f.id === "pet-proactive-interval") {
          R.preventDefault(), Rt(f);
          return;
        }
        if (f.id === "pet-proactive-poll") {
          R.preventDefault(), zt(f);
          return;
        }
        if (f.id === "pet-proactive-gap") {
          R.preventDefault(), Ht(f);
          return;
        }
        if (f.id === "pet-proactive-diff") {
          R.preventDefault(), ke(f);
          return;
        }
        if (f.id === "pet-tts-reftext") {
          R.preventDefault(), Ne(f.value).catch((L) => a("保存参考文本失败", L));
          return;
        }
        f.matches("[data-param-val]") && (R.preventDefault(), !((_ = t("pet-debug-body")) != null && _.classList.contains("off")) && et(f));
      }
    }, p = (R) => {
      var C;
      const f = R.target;
      if (!f) return;
      if (f.id === "pet-scale") {
        const F = Math.round(Number(f.value)) / 100, O = t("pet-scale-val");
        O && (O.textContent = `${Math.round(F * 100)}%`), U({ ...M(), scale: F }), Y(B, { type: "set-scale", value: F });
        return;
      }
      if (f.id === "pet-rot") {
        const F = Math.round(Number(f.value)), O = t("pet-rot-val");
        O && (O.textContent = `${F}°`), U({ ...M(), rotation: F }), Y(B, { type: "set-rotation", value: F });
        return;
      }
      if (f.id === "pet-tts-rate") {
        const F = gn(Number(f.value)), O = t("pet-tts-rate-val");
        O && (O.textContent = String(F)), U({ ...M(), speechRate: F });
        return;
      }
      if (f.id === "pet-tts-speed") {
        const F = Ra(Number(f.value)), O = t("pet-tts-speed-val");
        O && (O.textContent = F.toFixed(1) + "×"), Gt(F).catch((tt) => a("保存语速失败", tt));
        return;
      }
      if (f.id === "pet-tts-volume") {
        const F = za(Number(f.value)), O = t("pet-tts-volume-val");
        O && (O.textContent = Math.round(F * 100) + "%"), vn(F).catch((tt) => a("保存音量失败", tt));
        return;
      }
      const _ = f.dataset.param;
      if (!_ || (C = t("pet-debug-body")) != null && C.classList.contains("off")) return;
      const L = Number(f.value), h = e.querySelector(`[data-param-val="${_}"]`);
      h && document.activeElement !== h && (h.value = String(L)), K(_, L);
    };
    e.addEventListener("click", i), e.addEventListener("change", l), e.addEventListener("input", p), e.addEventListener("keydown", b);
    const S = await ht(B, (R) => {
      const f = R.payload;
      if ((f == null ? void 0 : f.type) !== "scale-changed" || typeof f.value != "number") return;
      const _ = Math.round(f.value * 100), L = t("pet-scale");
      L && (L.value = String(_));
      const h = t("pet-scale-val");
      h && (h.textContent = `${_}%`);
    }), P = await ht(B, (R) => {
      const f = R.payload;
      if ((f == null ? void 0 : f.type) !== "rotation-changed" || typeof f.value != "number") return;
      const _ = Math.round(f.value), L = t("pet-rot");
      L && (L.value = String(_));
      const h = t("pet-rot-val");
      h && (h.textContent = `${_}°`);
    }), $ = await ht(B, (R) => {
      const f = R.payload;
      if ((f == null ? void 0 : f.type) !== "motion-progress") return;
      const _ = f.p;
      if (e.querySelectorAll(".pet-chain-bar i").forEach((C) => C.style.width = "0%"), !_ || typeof _.index != "number" || typeof _.elapsedMs != "number" || typeof _.totalMs != "number" || !(_.totalMs > 0)) return;
      const L = Math.max(0, Math.min(1, _.elapsedMs / _.totalMs)), h = typeof f.chainId == "string" && f.chainId ? f.chainId : null;
      Ns(h, _.index, L);
    }), x = await ht(B, (R) => {
      var f;
      ((f = R.payload) == null ? void 0 : f.type) === "proactive-used" && St();
    }), I = await ht(B, (R) => {
      var f;
      ((f = R.payload) == null ? void 0 : f.type) !== "click-through-changed" || typeof R.payload.value != "boolean" || y(R.payload.value);
    }), j = () => {
      e.querySelectorAll(".pet-hk-row").forEach((R) => {
        const f = R.dataset.hkId, _ = R.querySelector("[data-hk-run]");
        if (!f || !_) return;
        const L = xe.has(f);
        _.classList.toggle("on", L), _.setAttribute("aria-pressed", L ? "true" : "false"), _.textContent = L ? "开" : "关";
      });
    }, q = await ht(B, (R) => {
      const f = R.payload;
      (f == null ? void 0 : f.type) !== "hotkey-states" || !Array.isArray(f.ids) || (xe = new Set(f.ids.filter((_) => typeof _ == "string")), j());
    }), nt = await ht(st, (R) => {
      var f;
      Kt(((f = R.payload) == null ? void 0 : f.ok) === !1 ? m("pet.persona_restart_failed") : m("pet.persona_restarted"));
    });
    re = () => {
      e.removeEventListener("click", i), e.removeEventListener("change", l), e.removeEventListener("input", p), e.removeEventListener("keydown", b), S(), P(), $(), x(), I(), q(), nt(), E && clearInterval(E), rt && clearTimeout(rt), delete Vt[Et], re = null;
    };
  }
  function Le() {
    const i = t("pet-tts-reftext");
    if (n && i && document.activeElement !== i && (i.value = n.config.reference_text), n) {
      const b = t("pet-tts-speed");
      if (b && document.activeElement !== b) {
        const S = Ra(n.config.speed);
        b.value = String(S);
        const P = t("pet-tts-speed-val");
        P && (P.textContent = S.toFixed(1) + "×");
      }
      const p = t("pet-tts-volume");
      if (p && document.activeElement !== p) {
        const S = za(n.config.volume);
        p.value = String(S);
        const P = t("pet-tts-volume-val");
        P && (P.textContent = Math.round(S * 100) + "%");
      }
    }
    const l = t("pet-tts-status");
    if (l) {
      if (!n) {
        l.textContent = "", l.className = "pet-note";
        return;
      }
      n.available ? (l.textContent = m("pet.tts_status_ready"), l.className = "pet-note pet-tts-ok") : (l.textContent = m("pet.tts_status_not_ready") + " · " + m("pet.tts_reason_" + (n.reason || "no_ref_audio")), l.className = "pet-note");
    }
  }
  async function te() {
    try {
      n = await d("get_pet_voice");
    } catch (i) {
      a("读取语音状态失败", i);
    }
    Le();
  }
  async function Gt(i) {
    const l = n == null ? void 0 : n.config;
    l && l.speed !== i && (await d("set_pet_voice", { config: { ...l, speed: i } }), n = { ...n, config: { ...l, speed: i } });
  }
  async function vn(i) {
    const l = n == null ? void 0 : n.config;
    l && l.volume !== i && (await d("set_pet_voice", { config: { ...l, volume: i } }), n = { ...n, config: { ...l, volume: i } });
  }
  async function Ne(i) {
    const l = n == null ? void 0 : n.config;
    !l || l.reference_text === i || (await d("set_pet_voice", { config: { ...l, reference_text: i } }), n = { ...n, config: { ...l, reference_text: i } }, Le());
  }
  async function Ct() {
    var p;
    const i = t("pet-tts-msg"), l = await On({
      multiple: !1,
      directory: !1,
      title: m("pet.tts_import_title"),
      filters: [{ name: m("pet.tts_import_filter"), extensions: ["wav", "mp3", "flac", "ogg", "m4a", "aac", "opus"] }]
    }), b = typeof l == "string" ? l : "";
    if (b)
      try {
        const S = await d("import_pet_voice_audio", { path: b }), P = n == null ? void 0 : n.config, $ = ((p = t("pet-tts-reftext")) == null ? void 0 : p.value) ?? (P == null ? void 0 : P.reference_text) ?? "";
        await d("set_pet_voice", {
          config: { ...P ?? { enabled: !0, reference_text: "", num_steps: 8, num_threads: 4, speed: 1, volume: 1 }, reference_audio: S, reference_text: $ }
        }), await te(), i && (i.textContent = m("pet.tts_import_ok"), i.className = "pet-note");
      } catch (S) {
        i && (i.textContent = m("pet.tts_import_fail") + (S instanceof Error ? S.message : String(S)), i.className = "pet-note pet-bad");
      }
  }
  function Ye() {
    const i = t("pet-tts-msg");
    i && (i.textContent = ""), d("tts_speak", { text: m("pet.tts_preview_text"), enabled: !0 }).catch((l) => {
      const b = l instanceof Error ? l.message : String(l), p = ds.includes(b) ? m("pet.tts_reason_" + b) : b;
      i && (i.textContent = p, i.className = "pet-note"), a("试听失败", l);
    });
  }
  te();
  async function Pe() {
    const i = t("pet-file"), l = await On({
      multiple: !1,
      directory: !0,
      title: "选择 Live2D 模型文件夹（里面要有 *.model3.json）"
    }), b = typeof l == "string" ? l : "";
    if (!b) return "";
    i && (i.innerHTML = "正在读取模型文件夹…");
    let p = "", S = "", P = "";
    try {
      const I = await d("scan_model_folder", { dir: b });
      p = (I.model3 ?? [])[0] ?? "", S = (I.vtube ?? [])[0] ?? "", P = (I.cdi3 ?? [])[0] ?? "";
    } catch (I) {
      return i && (i.innerHTML = `<span class="pet-bad">读文件夹失败：${k(I instanceof Error ? I.message : String(I))}</span>`), "";
    }
    if (!p)
      return i && (i.innerHTML = '<span class="pet-bad">这个文件夹里没有 *.model3.json。</span>'), "";
    const $ = await Ka(p);
    if (!$.ok)
      return i && (i.innerHTML = `<span class="pet-bad">这个模型用不了：${k($.reason)}</span>`), "";
    U({ ...M(), model: p, image: "" }), cn(p);
    const x = [];
    try {
      const I = await Gn(b, p, S);
      I && x.push(`热键 ${I} 条`);
    } catch (I) {
      a("读取模型热键失败", I);
    }
    return P && x.push("含 cdi3"), o([$.info, x.join(" · ")].filter(Boolean).join("　")), Y(B, { type: "reload" }), Pn(), Zt(), ze(), p;
  }
  const Xe = "__lunacPetHotkeyDelegate", It = e;
  if (!It[Xe]) {
    It[Xe] = !0;
    const i = (p) => p.closest(".pet-hk-row"), l = (p) => p ? vt.find((S) => S.id === p.dataset.hkId) : void 0;
    e.addEventListener("click", (p) => {
      const S = p.target;
      if (!S || !S.closest("#pet-hotkeys")) return;
      if (S.closest("#pet-hk-import")) {
        (async () => {
          const x = M().model.trim();
          if (!x) {
            Lt("先选一个 Live2D 模型 —— 「更换形象」里选模型文件夹。");
            return;
          }
          const I = await Wa(x);
          try {
            const j = await Gn(I.dir, x, I.vtube);
            if (!j) {
              Lt("这个模型文件夹里没找到可导入的热键 / 表情。");
              return;
            }
            Lt(`已导入 ${j} 条（${I.vtube ? "取自 vtube.json" : "扫自文件夹"}），已落盘。`), Y(B, { type: "reload" });
          } catch (j) {
            Lt("导入失败：" + (j instanceof Error ? j.message : String(j)));
          }
        })();
        return;
      }
      const P = i(S), $ = l(P);
      if (!(!P || !$)) {
        if (S.closest("[data-hk-run]")) {
          v().then((x) => {
            if (!x) {
              Lt("桌宠没显示 —— 先点上面「显示桌宠」，模型加载好后再点。");
              return;
            }
            Y(B, { type: "hotkey-toggle", id: $.id, action: $.action }), Lt("");
          });
          return;
        }
        if (S.closest("[data-hk-del]")) {
          vt = vt.filter((x) => x.id !== $.id), Yt(), Ge();
          return;
        }
      }
    });
    const b = (p, S) => {
      const P = p.target;
      if (!P || !P.closest("#pet-hotkeys")) return;
      const $ = i(P), x = l($);
      if (!$ || !x) return;
      const I = P.dataset.hkField;
      if (!I) return;
      const j = P.value;
      if (I === "name") {
        x.name = j, Ge();
        return;
      }
      xi(x.action, I, j), !S && (I === "id" || I === "group") && Yt(), Ge();
    };
    e.addEventListener("change", (p) => b(p, !1)), e.addEventListener("input", (p) => b(p, !0));
  }
  const Ke = "__lunacPetMotionDelegate";
  if (!It[Ke]) {
    It[Ke] = !0;
    const i = ($, x) => {
      const I = $.closest(x);
      return I ? Number.parseInt(I.getAttribute(x.slice(1, -1)) ?? "", 10) : NaN;
    }, l = ($) => $.split(/[\\/]/).pop() || "", b = async () => {
      await ze(), Ba(), Y(B, { type: "reload" });
    };
    e.addEventListener("click", ($) => {
      var R, f;
      const x = $.target;
      if (!x || !x.closest("#pet-motions")) return;
      const I = (_) => {
        const L = x.closest(`[${_}]`), h = (L == null ? void 0 : L.getAttribute(_)) ?? "", [C, F] = h.split(":").map((O) => Number.parseInt(O, 10));
        return [C, F];
      };
      if (x.closest("#pet-chain-add")) {
        V = [...V, Cr(`动作链 ${V.length + 1}`)], kt(), Ut();
        return;
      }
      if (x.closest("[data-chain-toggle]")) {
        const [_] = I("data-chain-toggle"), L = V[_];
        if (!L) return;
        We.has(L.id) ? We.delete(L.id) : We.add(L.id), kt();
        return;
      }
      if (x.closest("[data-chain-loop]")) {
        const [_] = I("data-chain-loop");
        if (!V[_]) return;
        V = V.map((h, C) => C === _ ? { ...h, loop: !h.loop } : h), kt(), Ut();
        return;
      }
      if (x.closest("[data-chain-del]")) {
        const [_] = I("data-chain-del");
        if (!Number.isInteger(_)) return;
        const L = V[_];
        L && We.delete(L.id), V = V.filter((h, C) => C !== _), kt(), Ut();
        return;
      }
      if (x.closest("[data-chain-step-add]")) {
        const [_] = I("data-chain-step-add");
        if (!V[_]) return;
        const h = ((R = pt[0]) == null ? void 0 : R.path) ?? "";
        (async () => {
          const C = await vi(h), F = V[_];
          if (!F) return;
          const O = C !== null ? { ...Ta(h), loopSec: C } : Ta(h), tt = { ...F, steps: [...F.steps, O] };
          V = V.map((ut, ee) => ee === _ ? tt : ut), kt(), Ut();
        })();
        return;
      }
      if (x.closest("[data-chain-step-del]")) {
        const [_, L] = I("data-chain-step-del"), h = V[_];
        if (!h || !Number.isInteger(L)) return;
        const C = { ...h, steps: h.steps.filter((F, O) => O !== L) };
        V = V.map((F, O) => O === _ ? C : F), kt(), Ut();
        return;
      }
      if (x.closest("[data-chain-run]")) {
        const _ = ((f = x.closest("[data-chain-run]")) == null ? void 0 : f.getAttribute("data-chain-run")) ?? "";
        _ && Y(B, { type: "chain-play", id: _ });
        return;
      }
      if (x.closest("#pet-mo-tpl-physics")) {
        const _ = M(), L = !_.motionTemplateIncludePhysics;
        U({ ..._, motionTemplateIncludePhysics: L });
        const h = x.closest("#pet-mo-tpl-physics");
        h && (h.classList.toggle("on", L), h.setAttribute("aria-pressed", L ? "true" : "false"), h.textContent = pn(L));
        return;
      }
      if (x.closest("#pet-mo-add")) {
        (async () => {
          var F;
          const _ = M().model.trim();
          if (!_) {
            At("先选一个 Live2D 模型。");
            return;
          }
          const L = await Is(_);
          if (!L) {
            At("拿不到参数清单 —— 先「显示桌宠」一次，再来新建动作。");
            return;
          }
          const h = JSON.parse(L), C = `${ja}${Date.now().toString(36)}.motion3.json`;
          try {
            await d("write_motion_file", { modelPath: _, name: C, json: L }), At(`已生成 ${C}（${((F = h.Curves) == null ? void 0 : F.length) ?? 0} 条参数曲线），可交给 AI 编。`), await b();
          } catch (O) {
            At("生成失败：" + (O instanceof Error ? O.message : String(O)));
          }
        })();
        return;
      }
      const j = i(x, "[data-mo-idle]");
      if (Number.isInteger(j)) {
        const _ = pt[j], L = M().model.trim();
        if (!_ || !L) return;
        const h = M(), C = new Set(h.idleMotions[L] ?? []), F = [...C].find((tt) => tt.toLowerCase() === _.name.toLowerCase());
        F !== void 0 ? C.delete(F) : C.add(_.name);
        const O = { ...h.idleMotions };
        C.size ? O[L] = [...C] : delete O[L], U({ ...h, idleMotions: O }), un(), Y(B, { type: "idle-set" });
        return;
      }
      const q = i(x, "[data-mo-run]");
      if (Number.isInteger(q)) {
        Y(B, { type: "motion-play", group: Dn, index: q });
        return;
      }
      const nt = i(x, "[data-mo-del]");
      Number.isInteger(nt) && (async () => {
        const _ = pt[nt], L = M().model.trim();
        if (!(!_ || !L))
          try {
            await d("delete_motion_file", { modelPath: L, name: l(_.path) }), await b();
          } catch (h) {
            At("删除失败：" + (h instanceof Error ? h.message : String(h)));
          }
      })();
    });
    const p = ($, x) => {
      const I = $.target, j = I == null ? void 0 : I.dataset.moName;
      if (!I || j === void 0) return;
      const q = pt[Number.parseInt(j, 10)], nt = M().model.trim();
      if (!q || !nt) return;
      const R = I.value.trim().replace(/\.motion3\.json$/i, "");
      x && I.blur(), !(!R || R === q.name) && (async () => {
        try {
          await d("rename_motion_file", {
            modelPath: nt,
            from: l(q.path),
            to: `${R}.motion3.json`
          }), await b();
        } catch (f) {
          At("改名失败：" + (f instanceof Error ? f.message : String(f)));
        }
      })();
    }, S = ($, x) => {
      const I = ($ == null ? void 0 : $.getAttribute(x)) ?? "", [j, q] = I.split(":").map((nt) => Number.parseInt(nt, 10));
      return [j, q];
    }, P = ($) => {
      const x = $.target;
      if (!x) return;
      if (x.dataset.chainName !== void 0) {
        const q = Number.parseInt(x.dataset.chainName, 10), nt = V[q];
        if (!nt) return;
        const R = x.value.trim() || nt.name;
        V = V.map((f, _) => _ === q ? { ...f, name: R } : f), Ut();
        return;
      }
      if (x.dataset.chainStepFile !== void 0) {
        const [q, nt] = S(x, "data-chain-step-file");
        wi(q, nt, x.value);
        return;
      }
      const I = x.dataset.chainStepLoop !== void 0, j = x.dataset.chainStepStop !== void 0;
      if (I || j) {
        const [q, nt] = S(x, I ? "data-chain-step-loop" : "data-chain-step-stop"), R = V[q];
        if (!R || !Number.isInteger(nt)) return;
        const f = Number.parseFloat(x.value), _ = Number.isFinite(f) ? f : 0, L = R.steps.map((h, C) => C !== nt ? h : I ? { ...h, loopSec: _ > 0 ? Math.min(3600, _) : 3 } : { ...h, stopSec: _ > 0 ? Math.min(3600, _) : 0 });
        V = V.map((h, C) => C === q ? { ...h, steps: L } : h), kt(), Ut();
      }
    };
    e.addEventListener("change", P), e.addEventListener("change", ($) => p($, !1)), e.addEventListener("keydown", ($) => {
      if ($.key !== "Enter") return;
      const x = $.target;
      (x == null ? void 0 : x.dataset.moName) !== void 0 && ($.preventDefault(), p($, !0));
    });
  }
  Si(), Va(e, Rs()), o(), y(M().clickThrough), Me(), D(), Pn(), ze(), bt("memory"), bt("growth"), bt("suggest"), (async () => {
    M().model.trim() && (await v() || (await c(), u(!0)));
  })().catch(() => {
  });
}
function js() {
  return `
<div class="pet-root" id="pet-root">
  <!-- 对话改渲染（2026-10-10 用户口径；2026-10-13 第二轮补画布跟随窗口）：
       输出贴窗口上沿、输入贴下沿，两条**紧贴模型区**（无空隙）—— 缺省 上 75 / 模型区（参考）300×400 / 下 35。
       模型区高度**不再定尺**：用 flex 跟随窗口剩余空间（画布变高模型不变大、贴底、上方多出空间）。
       两条**始终占位**（对话收起时只隐藏内容），所以模型不会因开合对话而跳动。整块的显隐由 .pet-root
       上的 chat-on / chat-input-on 两个类控制（见 setChatOpen）。 -->
  <div class="pet-top">
    <div class="pet-chat-output" id="pet-chat-bubble">
      <div class="pet-chat-text" id="pet-chat-text"></div>
    </div>
  </div>
  <div class="pet-stage" id="pet-stage">
    <div class="pet-l2d" id="pet-l2d"></div>
    <img class="pet-img" id="pet-img" alt="" draggable="false">
    <div class="pet-empty" id="pet-empty">还没有形象<br><span>在控制台里选一张图片或一个 Live2D 模型</span></div>
  </div>
  <div class="pet-bottom">
    <div class="pet-chat-inputrow">
      <textarea class="pet-chat-input" id="pet-chat-input" rows="1" spellcheck="false" autocomplete="off" placeholder="${k(m("pet.ai_chat_placeholder"))}" aria-label="${k(m("pet.ai_chat"))}"></textarea>
      <button type="button" class="pet-chat-mic" id="pet-chat-mic" title="${k(m("pet.voice_input"))}" aria-label="${k(m("pet.voice_input"))}">${$s}</button>
      <button type="button" class="pet-chat-stop" id="pet-chat-stop" title="${k(m("pet.chat_stop"))}" aria-label="${k(m("pet.chat_stop"))}">${Cs}</button>
      <button type="button" class="pet-chat-close" id="pet-chat-close" title="${k(m("pet.ai_chat_close"))}" aria-label="${k(m("pet.ai_chat_close"))}">×</button>
    </div>
  </div>
  <div class="pet-err" id="pet-err"></div>
  <div class="pet-toast" id="pet-toast"></div>
  <div class="pet-menu" id="pet-menu">
    <button data-act="ai-chat">${m("pet.ai_chat")}</button>
    <button data-act="settings">桌宠设置…</button>
    <button data-act="look-screen">${m("pet.look_screen")}</button>
    <button data-act="change">更换模型…</button>
    <button data-act="reset">恢复</button>
    <button data-act="win-reset">${m("pet.win_reset")}</button>
    <button data-act="through" id="pet-menu-through">${k(bn(M().clickThrough))}</button>
    <button data-act="close" class="danger">关闭桌宠</button>
  </div>
  <!-- 窗上缩放手柄（2026-10-13）：无边框窗没有系统边框可抓，靠它给一个**看得见**的缩放入口
       （拖边缘 / 角的能力由宿主 resizable 提供，见 plugin_window.rs 的 .resizable(...)）。
       只在**输入区未展开**时显示 —— 输入区右下角是「关闭 ×」按钮，两者会重叠。
       图标是严格线性 SVG（无 emoji），颜色走 --text-dim → hover --text。 -->
  <div class="pet-resize-handle" id="pet-resize-handle" title="${k(m("pet.resize_handle"))}" aria-label="${k(m("pet.resize_handle"))}">${Ts}</div>
</div>`;
}
const Bs = `
.pet-root{position:fixed;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:flex-start;overflow:hidden;}
/* 上：输出带（**预留下限 75**，可随内容变大 —— 由 JS 改写 --pet-top-h，见 applyOutHeight）；
   下：输入带 固定 35 —— **始终占位**（对话收起只隐藏内容、模型不跳动）；
   两条都紧贴模型（无空隙）。数值与 pet-window-size 的 IN_H / OUT_MIN_H 一致。 */
.pet-top{flex:0 0 var(--pet-top-h,75px);width:100%;display:flex;align-items:flex-start;justify-content:center;overflow:hidden;}
.pet-bottom{flex:0 0 35px;width:100%;display:flex;align-items:flex-end;justify-content:center;overflow:hidden;}
/* 模型区（画布）**跟随窗口剩余空间**（2026-10-13 第二轮）：
   flex:1 1 auto ⇒ 吃掉「输出带 + 输入带」之外的全部高度（= 窗高 − 输出带 − 输入带）；
   宽度 = 窗宽 − 左右留白（--pet-stage-gap，缺省 20 = 左右各 10，与 STAGE_W 一致）。
   画布变大时模型**不放大**（只是周围多出空间）、且**贴底**（模型逻辑见 live2d-engine 的 fit 与
   pet-window-size 的 modelBaseScale「只缩不放」）。min-height:0 让它在窗口很矮时能收到底。
   ⚠️ 2026-10-13 第三轮：模型区**不会低于 STAGE_MIN_H（140）** —— 这个下限由 JS 保证（输出带上限
   动态取 outCap、窗矮则上限降；最小窗高抬到 WIN_H_MIN = 75 + 35 + 140 = 250），CSS 的 min-height:0
   只负责不被内容顶开、不再承担下限。见 pet-window-size 的 STAGE_MIN_H / WIN_H_MIN / outCap。 */
.pet-stage{position:relative;width:calc(100% - var(--pet-stage-gap,20px));flex:1 1 auto;min-height:0;display:flex;align-items:flex-end;justify-content:center;cursor:grab;touch-action:none;}
.pet-stage:active{cursor:grabbing;}
/* 图片分支与模型分支**行为一致**（2026-10-13）：盒子定尺 = **参考模型区**（--pet-stage-ref-w/h，
   缺省 300×400），不随画布放大 ⇒ 画布变大时图片同样不放大、只多空间；画布小于参考时由
   max-width/max-height 收到画布内（object-fit:contain 不裁切）。底对齐 ⇒ object-position:bottom
   center 让它贴底、上方留白（与 Live2D 的 anchor=底边中心对齐）。 */
.pet-img{flex:0 0 auto;width:var(--pet-stage-ref-w,300px);height:var(--pet-stage-ref-h,400px);max-width:100%;max-height:100%;object-fit:contain;object-position:bottom center;transform-origin:50% 100%;pointer-events:none;-webkit-user-drag:none;filter:drop-shadow(0 6px 14px rgba(var(--shade-rgb),.35));}
.pet-l2d{position:absolute;inset:0;display:none;}
.pet-l2d.on{display:block;}
.pet-l2d canvas{display:block;}
.pet-err{position:absolute;left:8px;right:8px;bottom:8px;display:none;font-size:.68rem;line-height:1.6;color:var(--red);background:var(--surface-glass);border:1px solid var(--border-glass);border-radius:var(--radius);padding:8px 10px;word-break:break-all;backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);}
.pet-err.on{display:block;}
.pet-toast{position:absolute;left:50%;top:84px;transform:translateX(-50%);display:none;max-width:92%;font-size:.72rem;line-height:1.6;color:var(--text);background:var(--surface-glass);border:1px solid var(--border-glass);border-radius:var(--radius);padding:8px 12px;text-align:center;word-break:break-all;backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);box-shadow:0 6px 18px rgba(var(--shade-rgb),.28);}
.pet-toast.on{display:block;}
/* 输出框：**随内容封顶**（用户 2026-10-13 口径）—— 宽度**跟随窗口宽**（width:100% = 整窗宽，
   缺省即 320；比参考窄时靠 box-sizing:border-box + min-width:0 + max-width:100% + word-break
   收住，不产生横向溢出）；高度**跟随输出带** --pet-top-h（下限 75 = 预留带，上限 OUT_CAP_H）。
   做法：align-self:stretch 覆盖 .pet-top 的 flex-start（= 撑满输出带）；height / max-height 都取
   --pet-top-h ⇒ 盒高恒等于输出带高（下限 75 时即原「固定占满预留 75px」的行为）；文字靠顶
   （顶部对齐，**不做垂直居中**）。内容**超过上限**（= 输出带已被封在 OUT_CAP_H）时在盒内滚动
   （overflow-y:auto）。短 / 中回复盒高贴合内容 ⇒ **不再出现滚动条**。
   ⚠️ 盒子是 **flex 列**而不是 block（2026-10-13 修）：本模板里 .pet-chat-output 与 .pet-chat-text
   之间夹着换行 + 缩进（HTML 排版的空白文本节点），而本盒带 white-space:pre-wrap、**块级**容器会把
   这种纯空白文本节点当成真内容渲染成空行 —— 于是文字**上方 / 下方各多出约两行空白**（用户 2026-10-13
   报的「文字前面 / 上下都有空白」；无头 Chrome 实测：文字距盒顶 42.84px，而 padding-top 只有 6px，
   盒内容高 104 > 75 还平白多出一条滚动条）。flex 容器**不渲染**纯空白子文本节点（规范把整串空白
   子文本节点按 display:none 处理）⇒ 与模板缩进无关地保证文字贴顶。
   无正文时靠 :has(> .pet-chat-text:empty) 让它**不可见但仍占位** ⇒ 输出带回到下限 75px、
   开合对话时模型不位移。
   ⚠️ white-space:pre-wrap 会把回复里的换行 / 连续空行渲染成盒子内的**真实空白块**（用户报的段间空白）；
   故正文写进 DOM 前一律先过 JS 的 normalizeReplyText（换行归一 + 连续空白折叠 + 首尾空行丢弃，
   见 pet-typewriter.ts）—— 这里保留 pre-wrap 只为兜底单个空格。
   ⚠️ 滚动条只走全局那一条（ui-style.md 界面 6）：不得写 scrollbar-width / scrollbar-color、
   不得按容器另写、不得藏。 */
.pet-chat-output{display:none;width:100%;max-width:100%;min-width:0;align-self:stretch;height:var(--pet-top-h,75px);max-height:var(--pet-top-h,75px);min-height:0;box-sizing:border-box;overflow-y:auto;padding:6px 10px;font-size:.72rem;line-height:1.6;color:var(--text);text-align:left;background:var(--surface-glass);border:1px solid var(--border-glass);border-radius:var(--radius);backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px);word-break:break-word;white-space:pre-wrap;}
.pet-root.chat-on .pet-chat-output{display:flex;flex-direction:column;}
/* 正文**不许被 flex 收缩**（flex-shrink:0）：否则盒子定尺时正文会被压到盒高、内容溢出到
   盒外 —— 那样既量不到正文的真实高度（本来要按它算盒高），滚动也会看不见。撑开 + 盒内滚。 */
.pet-chat-text{flex:0 0 auto;min-width:0;}
.pet-chat-output:has(> .pet-chat-text:empty){visibility:hidden;}
.pet-chat-output.thinking .pet-chat-text{opacity:.55;}
/* 输入行：高 35（贴窗口下沿）；只在 .pet-root.chat-input-on 时显示。
   「桌宠发起」的三种情况（语音输入 / 主动询问 / 抓屏）**不显示输入区** —— 见 setChatOpen 的 showInput。 */
.pet-chat-inputrow{display:none;width:100%;height:35px;box-sizing:border-box;align-items:center;gap:6px;padding:0 8px;}
.pet-root.chat-input-on .pet-chat-inputrow{display:flex;}
.pet-chat-input{box-sizing:border-box;flex:1 1 auto;height:35px;resize:none;padding:6px 10px;font:inherit;font-size:.72rem;line-height:1.5;color:var(--text);background:var(--surface-glass);border:1px solid var(--border-glass);border-radius:var(--radius);outline:none;caret-color:rgb(var(--other-overlay-rgb));backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px);}
.pet-chat-input:focus{border-color:rgba(var(--btn-line-rgb), var(--btn-line-alpha));}
.pet-chat-close{appearance:none;flex:0 0 auto;height:35px;background:var(--surface-glass);border:1px solid var(--border-glass);border-radius:var(--radius);font:inherit;font-size:.9rem;line-height:1;color:var(--text-dim);cursor:pointer;padding:0 9px;}
.pet-chat-close:hover{color:var(--text);background:var(--border-glass);}
/* 「中止对话」图标按钮（形态照 §界面 14.1 的图标按钮：30×30 / 圆角 6px；颜色走按钮背景 + 按钮线条）。
   只在「正在生成」时出现 —— 由 on 类控制（见 setPetGenerating）。 */
.pet-chat-stop{display:none;flex:0 0 auto;align-items:center;justify-content:center;width:30px;height:30px;box-sizing:border-box;background:rgba(var(--btn-bg-rgb),var(--btn-bg-alpha));border:1px solid rgba(var(--btn-line-rgb),var(--btn-line-alpha));border-radius:6px;color:rgb(var(--btn-line-rgb));cursor:pointer;padding:0;}
.pet-chat-stop.on{display:flex;}
.pet-chat-stop:hover{background:rgba(var(--btn-bg-rgb),calc(var(--btn-bg-alpha) + 0.06));}
/* 语音输入（2026-10-22）：与中止按钮同形同色，常显；识别中挂 .on = 线条色淡底，按钮禁用。 */
.pet-chat-mic{appearance:none;display:flex;flex:0 0 auto;align-items:center;justify-content:center;width:30px;height:30px;box-sizing:border-box;background:rgba(var(--btn-bg-rgb),var(--btn-bg-alpha));border:1px solid rgba(var(--btn-line-rgb),var(--btn-line-alpha));border-radius:6px;color:rgb(var(--btn-line-rgb));cursor:pointer;padding:0;}
.pet-chat-mic:hover{background:rgba(var(--btn-bg-rgb),calc(var(--btn-bg-alpha) + 0.06));}
.pet-chat-mic.on{background:rgba(var(--btn-line-rgb),.18);}
.pet-chat-mic:disabled{cursor:default;opacity:.55;}
.pet-empty{position:absolute;left:50%;bottom:38%;transform:translateX(-50%);text-align:center;font-size:.72rem;line-height:1.7;color:var(--text-dim);background:var(--surface-glass);border:1px solid var(--border-glass);border-radius:var(--radius);padding:10px 14px;backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);}
.pet-empty span{font-size:.66rem;opacity:.75;}
.pet-menu{position:absolute;display:none;flex-direction:column;min-width:132px;padding:4px;background:var(--surface-glass);border:1px solid var(--border-glass);border-radius:var(--radius);backdrop-filter:blur(20px);-webkit-backdrop-filter:blur(20px);box-shadow:0 8px 24px rgba(var(--shade-rgb),.28);}
.pet-menu.open{display:flex;}
.pet-menu button{appearance:none;background:none;border:0;text-align:left;font:inherit;font-size:.72rem;color:var(--text);padding:6px 10px;border-radius:6px;cursor:pointer;white-space:nowrap;}
.pet-menu button:hover{background:var(--border-glass);}
.pet-menu button.danger:hover{color:var(--red);}
/* 窗上缩放手柄（2026-10-13）：右下角。**起点是斜向抓握图标**（严格线性 SVG + currentColor），
   色走 --text-dim → hover --text（§界面 2「文字 / 图标走四类派生」）。
   只在**输入区未展开**时显示（.pet-root 无 chat-input-on）—— 输入区右下角是「关闭 ×」按钮，会重叠。
   pointer-events 必须 auto（桌宠窗空白区是穿透 / 拖窗的，手柄要能点）。 */
.pet-resize-handle{position:absolute;right:2px;bottom:2px;width:16px;height:16px;display:none;align-items:center;justify-content:center;color:var(--text-dim);cursor:nwse-resize;z-index:6;pointer-events:auto;touch-action:none;-webkit-user-select:none;user-select:none;}
.pet-root:not(.chat-input-on) .pet-resize-handle{display:flex;}
.pet-resize-handle:hover{color:var(--text);}
.pet-console{padding:10px 12px 14px;font-size:.76rem;color:var(--text);}
.pet-row{display:flex;align-items:center;gap:8px;margin-bottom:10px;flex-wrap:wrap;}
/* 开头那排按钮（显示桌宠 / 更换模型 / 取消配置 / 穿透）**必须同一行**（用户 2026-10-10 口径）：
   不换行 + 收窄内边距，四个刚好排得下。 */
.pet-row-main{gap:6px;flex-wrap:nowrap;}
.pet-row-main .pet-btn{padding:6px 8px;font-size:.7rem;flex:0 0 auto;white-space:nowrap;}
.pet-btn{appearance:none;font:inherit;font-size:.74rem;color:var(--text);background:var(--surface-glass);border:1px solid var(--border-glass);border-radius:8px;padding:6px 12px;cursor:pointer;}
.pet-btn:hover{border-color:rgb(var(--other-overlay-rgb));color:rgb(var(--other-overlay-rgb));}
.pet-btn-primary{background:rgb(var(--other-overlay-rgb));border-color:rgb(var(--other-overlay-rgb));color:var(--text);font-weight:600;}
.pet-btn-primary:hover{color:var(--text);opacity:.92;}
.pet-btn-toggle.on{background:rgb(var(--other-overlay-rgb));border-color:rgb(var(--other-overlay-rgb));color:var(--text);font-weight:600;}
.pet-btn-toggle.on:hover{color:var(--text);opacity:.92;}
/* 分页（模型调试 / 热键，2026-10-10）—— 照 .music-tab / .chat-hist-tab 的胶囊芯片语言。 */
.pet-tabs{display:flex;flex-wrap:wrap;gap:6px;margin-top:12px;border-top:1px solid var(--border-glass);padding-top:11px;margin-bottom:10px;}
.pet-tab{appearance:none;font:inherit;font-size:.72rem;color:var(--text-dim);background:transparent;border:1px solid var(--border-glass);border-radius:999px;padding:4px 14px;cursor:pointer;}
.pet-tab:hover{color:var(--text);border-color:rgba(var(--btn-line-rgb), var(--btn-line-alpha));}
.pet-tab.on{color:var(--text);background:rgba(var(--btn-bg-rgb), var(--btn-bg-alpha));border-color:rgba(var(--btn-line-rgb), var(--btn-line-alpha));}
/* 页内的块不再各画一条上分隔线（那一排页签已经承担了分隔）。
   2026-10-13：主动反应 / 语音朗读 / 人格三页把原先在页签之外的三块搬了进来，同样去掉上分隔。 */
.pet-tabpage>.pet-hotkeys,.pet-tabpage>.pet-debug,.pet-tabpage>.pet-proactive,.pet-tabpage>.pet-tts,.pet-tabpage>.pet-persona{margin-top:0;border-top:0;padding-top:0;}
/* 「恢复默认」按钮行：三个分页各一颗，**贴在页顶**（2026-10-10 用户口径：从页底移上来）。 */
.pet-reset-row{margin-bottom:10px;}
.pet-phys-tag{margin-left:6px;font-size:.62rem;color:var(--text-dim);border:1px solid var(--border-glass);border-radius:999px;padding:0 6px;opacity:.85;}
.pet-check{display:flex;align-items:center;gap:6px;color:var(--text-dim);cursor:pointer;}
.pet-label{color:var(--text-dim);}
.pet-val{color:var(--text-dim);min-width:3.2em;}
.pet-file{margin:2px 0 10px;color:var(--text-dim);word-break:break-all;line-height:1.6;}
.pet-file code{font-size:.7rem;color:var(--text);}
.pet-dim{opacity:.72;}
.pet-bad{color:var(--red);}
.pet-note{color:var(--text-dim);opacity:.72;font-size:.68rem;line-height:1.7;border-top:1px solid var(--border-glass);padding-top:9px;}
.pet-note b{color:var(--text);opacity:.9;}
.pet-persona{margin-top:14px;border-top:1px solid var(--border-glass);padding-top:12px;display:flex;flex-direction:column;gap:8px;}
.pet-persona .pet-note{border-top:0;padding-top:0;}
.pet-persona-text{width:100%;box-sizing:border-box;resize:vertical;min-height:96px;font:inherit;font-size:.72rem;line-height:1.7;color:var(--text);background:rgba(var(--shade-rgb),calc(0.3 * var(--shade-scale)));border:1px solid var(--border-glass);border-radius:8px;padding:8px 10px;outline:none;caret-color:rgb(var(--other-overlay-rgb));}
.pet-persona-text:focus{border-color:rgb(var(--other-overlay-rgb));}
.pet-persona-actions{gap:8px;flex-wrap:wrap;}
/* 人格页的三张列表（事实记忆 / 成长笔记 / 人格建议，2026-10-13）—— 与核心人格块同款分隔线；
   行是 JS 渲染，样式按结构类写（行数 / 文本都来自宿主，样式不绑 id）。 */
.pet-list{margin-top:14px;border-top:1px solid var(--border-glass);padding-top:12px;}
.pet-list .pet-note{border-top:0;padding-top:0;margin-top:8px;}
.pet-list-items{display:flex;flex-direction:column;gap:8px;margin:10px 0;}
.pet-list-row{display:flex;flex-direction:column;gap:8px;padding:8px 10px;border:1px solid var(--border-glass);border-radius:8px;}
.pet-list-text{color:var(--text);font-size:.72rem;line-height:1.7;white-space:pre-wrap;word-break:break-word;}
.pet-list-acts{display:flex;flex-wrap:wrap;gap:6px;}
.pet-list-empty{color:var(--text-muted);font-size:.7rem;line-height:1.7;}
/* 两段式确认态（删除 / 清空 / 接受合并）：红色确认，见 docs/ui-style.md §界面 2 / §界面 11 白名单。 */
.pet-list-del[data-armed="1"],.pet-list-clear[data-armed="1"],.pet-suggest-accept[data-armed="1"]{color:var(--red);background:rgba(var(--danger-rgb),0.14);border-color:var(--red);}
.pet-debug{margin-top:12px;border-top:1px solid var(--border-glass);padding-top:11px;}
.pet-debug-title{font-weight:600;color:var(--text);margin-bottom:8px;}
.pet-debug-note{color:var(--text-dim);font-size:.68rem;line-height:1.7;margin-bottom:8px;}
.pet-debug-body.off{opacity:.45;pointer-events:none;}
.pet-param{display:flex;align-items:center;gap:8px;margin-bottom:8px;}
.pet-param .pet-label{min-width:5.5em;}
.pet-range{flex:1;min-width:0;height:4px;appearance:none;-webkit-appearance:none;background:var(--border-glass);border-radius:3px;outline:none;cursor:pointer;}
.pet-range::-webkit-slider-thumb{appearance:none;-webkit-appearance:none;width:14px;height:14px;border-radius:50%;background:rgb(var(--btn-line-rgb));border:0;cursor:pointer;}
.pet-range::-moz-range-thumb{width:14px;height:14px;border-radius:50%;background:rgb(var(--btn-line-rgb));border:0;cursor:pointer;}
.pet-param .pet-param-num{flex:0 0 auto;width:54px;box-sizing:border-box;padding:4px 7px;font:inherit;font-size:.7rem;text-align:right;font-variant-numeric:tabular-nums;color:var(--text);background:rgba(var(--shade-rgb),calc(0.3 * var(--shade-scale)));border:1px solid var(--border-glass);border-radius:5px;outline:none;caret-color:rgb(var(--other-overlay-rgb));}
.pet-param .pet-param-num:focus{border-color:rgba(var(--btn-line-rgb), var(--btn-line-alpha));}
.pet-debug-sub{color:var(--text-dim);margin:10px 0 6px;}
.pet-exprs{display:flex;flex-wrap:wrap;gap:6px;line-height:1.6;max-height:180px;overflow-y:auto;padding-right:4px;align-content:flex-start;}
.pet-expr-btn{appearance:none;font:inherit;font-size:.72rem;color:var(--text);background:var(--surface-glass);border:1px solid var(--border-glass);border-radius:8px;padding:5px 10px;cursor:pointer;}
.pet-expr-btn:hover{border-color:rgb(var(--other-overlay-rgb));color:rgb(var(--other-overlay-rgb));}
.pet-expr-reset{color:var(--text-dim);}
.pet-expr-btn.on{background:rgb(var(--other-overlay-rgb));border-color:rgb(var(--other-overlay-rgb));color:var(--text);font-weight:600;}
.pet-expr-btn.on:hover{color:var(--text);opacity:.92;}
.pet-proactive{margin-top:12px;border-top:1px solid var(--border-glass);padding-top:11px;}
.pet-proactive .pet-note{margin-top:8px;border-top:0;padding-top:0;}
.pet-proactive .pet-param-num{flex:0 0 auto;width:64px;box-sizing:border-box;padding:4px 7px;font:inherit;font-size:.7rem;text-align:right;font-variant-numeric:tabular-nums;color:var(--text);background:rgba(var(--shade-rgb),calc(0.3 * var(--shade-scale)));border:1px solid var(--border-glass);border-radius:5px;outline:none;caret-color:rgb(var(--other-overlay-rgb));}
.pet-proactive .pet-param-num:focus{border-color:rgba(var(--btn-line-rgb), var(--btn-line-alpha));}
.pet-tts{margin-top:12px;border-top:1px solid var(--border-glass);padding-top:11px;}
.pet-tts .pet-note{margin-top:8px;border-top:0;padding-top:0;}
/* 「参考音色」子块（2026-10-12）：参考文本输入框 + 「添加音频文件 / 试听」两枚按钮 + 状态行。 */
.pet-tts-voice{margin-top:10px;padding-top:10px;border-top:1px solid var(--border-glass);}
.pet-tts-voice .pet-label{display:block;margin-bottom:6px;}
.pet-tts-voice .pet-row{margin-top:8px;}
.pet-tts-actions{margin-top:8px;}
.pet-tts-text{display:block;width:100%;box-sizing:border-box;font:inherit;font-size:.72rem;color:var(--text);background:rgba(var(--shade-rgb),calc(0.3 * var(--shade-scale)));border:1px solid var(--border-glass);border-radius:5px;padding:6px 8px;outline:none;caret-color:rgb(var(--other-overlay-rgb));}
.pet-tts-text:focus{border-color:rgba(var(--btn-line-rgb), var(--btn-line-alpha));}
.pet-tts-ok{color:var(--green);}
.pet-tts .pet-bad{color:var(--red);}
/* 热键区（2026-10-10）—— 行是 JS 渲染的动态列表，样式必须按结构类写，不能绑 id。 */
.pet-hotkeys{margin-top:12px;border-top:1px solid var(--border-glass);padding-top:11px;}
.pet-hotkeys .pet-note{border-top:0;padding-top:0;margin-bottom:8px;}
.pet-hk-list{display:flex;flex-direction:column;gap:8px;margin-bottom:10px;}
.pet-hk-row{display:flex;flex-wrap:wrap;gap:6px;align-items:center;padding:8px;border:1px solid var(--border-glass);border-radius:8px;}
.pet-hk-row input,.pet-hk-row select{font:inherit;font-size:.7rem;color:var(--text);background:rgba(var(--shade-rgb),calc(0.3 * var(--shade-scale)));border:1px solid var(--border-glass);border-radius:5px;padding:4px 7px;outline:none;}
.pet-hk-row input:focus,.pet-hk-row select:focus{border-color:rgba(var(--btn-line-rgb), var(--btn-line-alpha));}
.pet-hk-name{flex:1 1 96px;min-width:72px;}
.pet-hk-target{flex:1 1 96px;min-width:72px;color:var(--text-dim);font-size:.7rem;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
/* 热键行的「类型 / 表情对象」改**自绘下拉**（.custom-select，共享组件，2026-10-11）：
   行内可伸缩（原先原生 select 无 flex、按内容宽度）。 */
.pet-hk-row .custom-select{flex:1 1 110px;min-width:96px;max-width:none;}
.pet-hk-num{flex:0 0 auto;width:56px;box-sizing:border-box;text-align:right;font-variant-numeric:tabular-nums;}
.pet-hk-color{flex:0 0 auto;width:40px;height:24px;box-sizing:border-box;padding:1px 2px;cursor:pointer;}
.pet-hk-run{flex:0 0 auto;color:rgb(var(--other-overlay-rgb));}
.pet-hk-del{flex:0 0 auto;color:var(--red);}
.pet-hk-del:hover{color:var(--red);border-color:var(--red);}
/* 预设动作页（2026-10-10）—— 与热键行同一套结构类写法（动态列表，不绑 id）。 */
.pet-motions{margin:0;}
.pet-mo-list{display:flex;flex-direction:column;gap:8px;margin-bottom:10px;}
.pet-mo-row{display:flex;flex-wrap:wrap;gap:6px;align-items:center;padding:8px;border:1px solid var(--border-glass);border-radius:8px;}
.pet-mo-row input,.pet-mo-row select{font:inherit;font-size:.7rem;color:var(--text);background:rgba(var(--shade-rgb),calc(0.3 * var(--shade-scale)));border:1px solid var(--border-glass);border-radius:5px;padding:4px 7px;outline:none;}
.pet-mo-row input:focus,.pet-mo-row select:focus{border-color:rgba(var(--btn-line-rgb), var(--btn-line-alpha));}
.pet-mo-name{flex:1 1 96px;min-width:72px;}
.pet-mo-row select{flex:1 1 110px;min-width:88px;}
.pet-mo-run{flex:0 0 auto;color:rgb(var(--other-overlay-rgb));}
.pet-mo-del{flex:0 0 auto;color:var(--red);}
.pet-mo-del:hover{color:var(--red);border-color:var(--red);}
/* 调试区的开关形态 + 参数形态覆盖按钮（2026-10-10）。 */
.pet-param-on{flex:0 0 auto;min-width:52px;}
.pet-param-kind{flex:0 0 auto;display:inline-flex;align-items:center;justify-content:center;appearance:none;width:24px;height:20px;color:var(--text-dim);background:transparent;border:1px solid var(--border-glass);border-radius:999px;padding:0;cursor:pointer;line-height:0;}
.pet-param-kind:hover{color:var(--text);border-color:rgba(var(--btn-line-rgb), var(--btn-line-alpha));}
/* ── 动作链（2026-10-10，backlog ㉝②；放在动作页最上面）── */
.pet-chains{margin-bottom:12px;padding-bottom:10px;border-bottom:1px solid var(--border-glass);}
.pet-chain-list{display:flex;flex-direction:column;gap:10px;margin-top:8px;}
.pet-chain{padding:8px;border:1px solid var(--border-glass);border-radius:8px;background:rgba(var(--shade-rgb),calc(0.14 * var(--shade-scale)));}
.pet-chain-head{display:flex;gap:6px;align-items:center;flex-wrap:wrap;}
/* 展开 / 收起箭头（2026-10-11）：小方按钮，SVG 跟随文字色；展开时旋转 90 度。 */
.pet-chain-toggle{flex:0 0 auto;display:inline-flex;align-items:center;justify-content:center;width:22px;height:22px;padding:0;line-height:0;color:var(--text-dim);}
.pet-chain-toggle svg{transition:transform .12s ease;}
.pet-chain-toggle.on svg{transform:rotate(90deg);}
.pet-chain-name{flex:1 1 110px;min-width:80px;font:inherit;font-size:.72rem;color:var(--text);background:rgba(var(--shade-rgb),calc(0.3 * var(--shade-scale)));border:1px solid var(--border-glass);border-radius:5px;padding:4px 7px;outline:none;}
.pet-chain-name:focus{border-color:rgba(var(--btn-line-rgb), var(--btn-line-alpha));}
.pet-chain-total{flex:0 0 auto;font-size:.66rem;color:var(--text-dim);}
.pet-chain-loopbtn{flex:0 0 auto;}
/* 折叠态**摘要**：一行、过长省略（只显示「文件 · 循环 · 硬停」的拼接）。 */
.pet-chain-summary{display:none;margin:6px 0 0;font-size:.66rem;line-height:1.5;color:var(--text-dim);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.pet-chain.collapsed .pet-chain-summary{display:block;}
/* 折叠：藏起步骤列表与「添加步骤」。 */
.pet-chain.collapsed .pet-chain-steps{display:none;}
.pet-chain.collapsed [data-chain-step-add]{display:none;}
.pet-chain-steps{display:flex;flex-direction:column;gap:6px;margin:8px 0;}
/* 每一步 = 上「一行四个控件」（名称 / 循环 / 硬停 / 删除，**不换行**）+ 下「进度条」。 */
.pet-chain-step{display:flex;flex-direction:column;gap:0;}
.pet-chain-fields{display:flex;align-items:center;gap:6px;flex-wrap:nowrap;min-width:0;}
/* 动作链每一步的**动作文件下拉**改自绘 .custom-select（2026-10-11）：占满该行剩余宽度。 */
.pet-chain-fields .custom-select{flex:1 1 auto;min-width:0;max-width:none;}
/* 仍为**原生 select** 的几处（热键行的 group / id / mode / enabled、动作行）：
   收合面按 docs/ui-style.md §界面 12 基准对齐（高 26 / 圆角 6 / 内边距 5px 8px /
   font-size .73rem / 底 rgba(var(--shade-rgb), calc(0.25 * var(--shade-scale))) /
   描边 var(--border-glass) = 按钮线条 α0.10 / 文字 var(--text)）；弹出层由 OS 绘制、
   不可样式化（§界面 12 硬豁免）。
   ⚠️ 热键行的「类型 / 表情对象」与动作链步骤的动作文件**已改自绘 .custom-select**（外观由
   styles.css 的共享规则给），不再进本组。
   单独成组、不并进上面的 input,select 共享规则：那条规则里有一批 input 专有覆盖
   （.pet-hk-color 的圆角 / 内边距等），合并进去会误伤它们。 */
.pet-hk-row select,.pet-mo-row select{box-sizing:border-box;height:26px;font-size:.73rem;background:rgba(var(--shade-rgb),calc(0.25 * var(--shade-scale)));border:1px solid var(--border-glass);border-radius:6px;padding:5px 8px;color:var(--text);}
.pet-chain-t{flex:0 0 auto;display:inline-flex;align-items:center;gap:3px;font-size:.66rem;color:var(--text-dim);white-space:nowrap;}
/* 「循环」「硬停」两个数字框**收窄**到约 4 个字符宽（用户 2026-10-11 口径）：
   字号 .7rem 下 4.2em 约 47px，去掉内边距 / 边框后仍能看清「3.0」「12.5」这类值。
   右对齐 + 等宽数字，多位数字也稳。 */
.pet-chain-num{width:4.2em;box-sizing:border-box;font:inherit;font-size:.7rem;color:var(--text);background:rgba(var(--shade-rgb),calc(0.3 * var(--shade-scale)));border:1px solid var(--border-glass);border-radius:5px;padding:3px 5px;outline:none;text-align:right;font-variant-numeric:tabular-nums;caret-color:rgb(var(--other-overlay-rgb));}
.pet-chain-del{flex:0 0 auto;color:var(--red);padding:2px 8px;}
.pet-chain-run{flex:0 0 auto;}
/* 进度条：动作页每行 / 动作链每步下方（子元素 i 为填充、span 为覆盖文字）。 */
.pet-chain-bar{position:relative;flex:1 1 100%;height:16px;margin-top:3px;border-radius:5px;overflow:hidden;background:rgba(var(--shade-rgb),calc(0.28 * var(--shade-scale)));border:1px solid var(--border-glass);}
/* 动作链里进度条是「一行控件」的下方兄弟（父容器已是竖向 flex）⇒ 改成不收缩、占满整行宽。 */
.pet-chain-step .pet-chain-bar{flex:0 0 auto;width:100%;}
.pet-chain-bar i{position:absolute;left:0;top:0;bottom:0;width:0;background:rgb(var(--other-overlay-rgb));opacity:.35;transition:width .08s linear;}
.pet-chain-bar span{position:absolute;left:6px;right:6px;top:0;bottom:0;display:flex;align-items:center;font-size:.62rem;color:var(--text-dim);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;pointer-events:none;}
`;
let re = null;
async function Vs(e) {
  const t = (s) => e.querySelector(`#${s}`), n = t("pet-stage"), a = t("pet-img"), o = t("pet-l2d"), c = t("pet-err"), u = t("pet-toast"), y = t("pet-empty"), T = t("pet-menu"), v = t("pet-root"), D = t("pet-chat-bubble"), E = t("pet-chat-text"), X = t("pet-chat-close"), rt = t("pet-chat-stop"), K = t("pet-chat-mic"), it = t("pet-chat-input"), J = t("pet-resize-handle");
  v == null || v.style.setProperty("--pet-stage-gap", `${Wr}px`), v == null || v.style.setProperty("--pet-stage-ref-w", `${Wn}px`), v == null || v.style.setProperty("--pet-stage-ref-h", `${Hn}px`);
  let Z = 0, A = M(), z = null, dt = "", ce = 0, et = !0, ot = null, St = [], Nt = 0, Rt = "", zt = null, Ht = !0;
  D == null || D.addEventListener("scroll", () => {
    D && (Ht = D.scrollHeight - D.scrollTop - D.clientHeight <= 2);
  });
  function ke(s) {
    c && (c.textContent = s, c.classList.toggle("on", !!s));
  }
  let Wt = null;
  function st(s, r) {
    u && (u.textContent = s, u.classList.add("on"), Wt && clearTimeout(Wt), Wt = setTimeout(() => {
      Wt = null, u.classList.remove("on");
    }, r));
  }
  function pe() {
    try {
      z == null || z.destroy();
    } catch (s) {
      console.warn("[pet] dropModel failed:", s);
    }
    z = null;
  }
  async function Se() {
    const s = ++ce;
    A = M(), ke("");
    const r = A.model.trim(), g = A.image.trim();
    if (r && o) {
      a && (a.removeAttribute("src"), a.style.display = "none"), y && (y.style.display = "none"), o.classList.add("on"), Ce(), pe(), o.querySelectorAll("canvas").forEach((w) => w.remove()), ne.clear(), Sn();
      try {
        const { mountLive2D: w } = await ps(), N = await ws(r), H = await ye(r), W = H.map((at) => ({ name: at.name, file: at.path })), G = Un(r), Q = H.filter((at) => G.has(at.name.toLowerCase())).map((at) => ({ name: at.name, file: at.path })), ft = await w(o, {
          modelPath: r,
          scale: A.scale,
          offsetX: A.offsetX,
          offsetY: A.offsetY,
          rotation: A.rotation,
          // 参考模型区尺寸（缺省窗口下的 300×400）：模型基准缩放按它算 ⇒ 画布比它大时不放大、
          // 比它小时按画布收（见 live2d-engine 的 fit 与 pet-window-size 的 modelBaseScale）。
          refStageW: Wn,
          refStageH: Hn,
          extraExpressions: N,
          extraMotions: W,
          idleMotions: Q,
          // 动作进度（2026-10-10）：引擎 → 本窗 → 设置窗画进度条（`motion-progress` 广播）。
          onMotionProgress: (at) => {
            Y(B, {
              type: "motion-progress",
              chainId: dt,
              p: at ? { index: at.index, elapsedMs: at.elapsedMs, totalMs: at.totalMs, chainStep: at.chainStep } : null
            });
          }
        });
        if (s !== ce) {
          ft.destroy();
          return;
        }
        z = ft;
        const ae = M();
        let ie = null, Tt = vs;
        try {
          const at = ft.listCoreIds(), he = await mn(r);
          Tt = new Set(he.outputs), qe.set(r.toLowerCase(), Tt);
          const ge = await Ve(r) ?? Yn(r);
          if (at.parameters.length || at.drawables.length || at.parts.length) {
            const wa = {
              ...at,
              physicsInputs: he.inputs,
              physicsOutputs: he.outputs
            };
            ge.coreIds = wa, localStorage.setItem(hi + r.toLowerCase(), JSON.stringify(wa));
          }
          const Mn = ae.params[r];
          (!ge.params || !Object.keys(ge.params).length) && Mn && typeof Mn == "object" && (ge.params = sn(Mn, Tt)), ie = ge.params, await ln(r, ge);
        } catch (at) {
          console.warn("[pet] 读/写 lunac.params.json 失败", at);
        }
        ft.setScale(ae.scale), ft.setOffset(ae.offsetX, ae.offsetY), ft.setRunning(et);
        const ya = ae.expressions[r];
        ya && ft.setExpression(ya);
        const va = ie && Object.keys(ie).length ? ie : ae.params[r];
        if (va)
          for (const [at, he] of Object.entries(va))
            typeof he == "number" && (Tt.has(at) || ft.setParameter(at, he));
        await Hi(r);
      } catch (w) {
        if (s !== ce) return;
        pe(), o.classList.remove("on"), ke(`Live2D 载入失败：${w instanceof Error ? w.message : String(w)}`);
      }
      return;
    }
    pe(), o == null || o.classList.remove("on"), a && y && (g ? (a.src = Ft(g), a.style.display = "", y.style.display = "none") : (a.removeAttribute("src"), a.style.display = "none", y.style.display = "")), a && Xt(0), et && Jt();
  }
  function Xt(s) {
    a && (a.style.transform = `translate(${A.offsetX}px, ${A.offsetY + s}px) scale(${A.scale})`);
  }
  function Kt(s) {
    if (A = { ...A, scale: s }, z) {
      z.setScale(s);
      return;
    }
    Xt(0);
  }
  function Me(s, r) {
    if (A = { ...A, offsetX: s, offsetY: r }, z) {
      z.setOffset(s, r);
      return;
    }
    Xt(0);
  }
  function Ee(s) {
    A = { ...A, rotation: s }, z == null || z.setRotation(s);
  }
  const gt = performance.now();
  function Pt(s) {
    if (Z = requestAnimationFrame(Pt), !!e.isConnected && a && a.style.display !== "none") {
      const r = Math.sin((s - gt) / 1400) * 3;
      Xt(r);
    }
  }
  function Jt() {
    Z || (Z = requestAnimationFrame(Pt));
  }
  function Ce() {
    Z && cancelAnimationFrame(Z), Z = 0;
  }
  async function bt(s) {
    try {
      await d("plugin_window_set_click_through", { ignore: s });
    } catch (r) {
      console.error("[lunac pet] 设置穿透失败：", r);
    }
    await d("pet_alt_rclick_watch", { on: s }).catch(() => {
    });
  }
  let ue = !1;
  function $e() {
    const s = document.getElementById("pet-menu-through");
    s && (s.textContent = bn(A.clickThrough));
  }
  function jt() {
    T == null || T.classList.remove("open"), ue && (ue = !1, bt(!0));
  }
  function de(s, r) {
    T && ($e(), T.style.left = `${Math.max(2, Math.min(s, window.innerWidth - 140))}px`, T.style.top = `${Math.max(2, Math.min(r, window.innerHeight - 240))}px`, T.classList.add("open"));
  }
  async function fe(s, r) {
    A.clickThrough && !ue && (ue = !0, await bt(!1));
    let g = s, w = r;
    try {
      const N = await xt().outerPosition(), H = window.devicePixelRatio || 1;
      g = (s - N.x) / H, w = (r - N.y) / H;
    } catch {
      g = window.innerWidth / 2, w = window.innerHeight / 2;
    }
    de(g, w);
  }
  n == null || n.addEventListener("contextmenu", (s) => {
    s.preventDefault(), de(s.clientX, s.clientY);
  });
  let Mt = null;
  const Te = (s) => {
    Mt && Me(Mt.ox + (s.clientX - Mt.sx), Mt.oy + (s.clientY - Mt.sy));
  }, Ae = () => {
    Mt && (Mt = null, window.removeEventListener("mousemove", Te), window.removeEventListener("mouseup", Ae), U(A));
  };
  function yn(s) {
    Mt = { sx: s.clientX, sy: s.clientY, ox: A.offsetX, oy: A.offsetY }, window.addEventListener("mousemove", Te), window.addEventListener("mouseup", Ae), s.preventDefault(), jt();
  }
  n == null || n.addEventListener("mousedown", (s) => {
    if (s.button === 0) {
      if (s.altKey) {
        yn(s);
        return;
      }
      jt(), xt().startDragging().catch(() => {
      });
    }
  }), e.addEventListener("mousedown", (s) => {
    T != null && T.classList.contains("open") && !T.contains(s.target) && jt();
  }), J == null || J.addEventListener("mousedown", (s) => {
    s.button === 0 && (s.preventDefault(), s.stopPropagation(), jt(), xt().startResizeDragging("SouthEast").catch(() => {
    }));
  }), n == null || n.addEventListener(
    "wheel",
    (s) => {
      const r = n == null ? void 0 : n.getBoundingClientRect();
      if (!r || !z && (!a || a.style.display === "none")) return;
      s.preventDefault();
      const g = s.clientX - r.left, w = s.clientY - r.top, N = s.deltaY < 0 ? Da : 1 / Da, H = Math.min(ti, Math.max(Qa, A.scale * N));
      if (H !== A.scale) {
        if (z) {
          const W = z.zoomAtPointer(N, g, w);
          A = { ...A, scale: W.scale, offsetX: W.offsetX, offsetY: W.offsetY };
        } else {
          const W = r.width / 2, G = r.height, Q = H / A.scale;
          A = {
            ...A,
            scale: H,
            offsetX: (g - W) * (1 - Q) + Q * A.offsetX,
            offsetY: (w - G) * (1 - Q) + Q * A.offsetY
          }, Xt(0);
        }
        U(A), Y(B, { type: "scale-changed", value: A.scale });
      }
    },
    { passive: !1 }
  );
  async function Zt() {
    var N;
    st(m("pet.look_screen_working"), 2e3);
    let s = null;
    try {
      s = await d("screenshot_monitor", {
        label: ve
      });
    } catch (H) {
      yt("看一眼屏幕失败", H), st(m("pet.look_screen_failed"), 2600);
      return;
    }
    const r = s == null ? void 0 : s.path;
    if (!r) {
      st(m("pet.look_screen_failed"), 2600);
      return;
    }
    let g = !1;
    try {
      g = !!((N = await d("get_ai_config")) != null && N.vision);
    } catch {
    }
    if (!g) {
      st(m("pet.look_screen_need_vision"), 3400);
      return;
    }
    const w = m("pet.look_screen_query");
    try {
      localStorage.setItem(Xr, JSON.stringify({ query: w, path: r }));
    } catch {
    }
    await d("open_plugin_window", { pluginId: "chat", key: null, input: w, hidden: !0 });
  }
  let Bt = !1;
  function me(s, r = !0, g = !0) {
    Bt = s, s || It(!0), v == null || v.classList.toggle("chat-on", s), v == null || v.classList.toggle("chat-input-on", s && g), s && g && r && (it == null || it.focus()), Ct(!0);
  }
  let Qt = A.winW, Et = A.winH, Vt = lt, Le = -1, te = -1, Gt = null;
  function vn() {
    if (!E) return 0;
    const s = E.getBoundingClientRect().height;
    return Number.isFinite(s) ? Math.ceil(s + 14) : 0;
  }
  function Ne(s) {
    v == null || v.style.setProperty("--pet-top-h", `${s}px`);
  }
  function Ct(s) {
    const r = Oa(Et), g = Bt && et ? Gr(Vr(vn(), r), si, r) : lt;
    if (Vt = g, Ne(g), !et) return;
    const w = Ur(Et, g);
    if (!s && !qr(Le, w) || (s && (te = -1), w === te)) return;
    const N = w;
    d("plugin_window_resize_anchored", { width: Math.round(Qt), height: Math.round(N) }).then(() => {
      Le = N;
    }).catch(() => {
      te = N;
    });
  }
  function Ye(s, r = !1) {
    It(!1);
    const g = Pa(s);
    E && (E.textContent = g), D == null || D.classList.toggle("thinking", !!r), Ht = !0, E != null && E.parentElement && (E.parentElement.scrollTop = 0), Ct(!0);
  }
  function Pe() {
    D && (D.scrollTop = D.scrollHeight);
  }
  function Xe() {
    ot && (clearInterval(ot), ot = null);
    const s = zt;
    zt = null, St = [], Nt = 0, Rt = "", Ct(!0), s && s();
  }
  function It(s) {
    const r = ot !== null;
    ot && (clearInterval(ot), ot = null), r && (s && E && (E.textContent = St.join("")), Ht && Pe()), St = [], Nt = 0, Rt = "";
    const g = zt;
    zt = null, r && g && g();
  }
  function Ke(s, r) {
    It(!1);
    const g = Pa(s);
    if (D == null || D.classList.remove("thinking"), Ht = !0, !E) {
      r == null || r();
      return;
    }
    const w = gn(M().speechRate), N = zr(g);
    if (!et || Hr(N.length, w, Or)) {
      E.textContent = g, D && (D.scrollTop = 0), Ct(!0), r == null || r();
      return;
    }
    St = N, Nt = 0, Rt = "", zt = r ?? null, ot = setInterval(() => {
      Rt += St[Nt] ?? "", Nt++, E && (E.textContent = Rt), Ht && Pe(), Ct(!1), Nt >= St.length && Xe();
    }, 1e3 / w);
  }
  function i(s) {
    rt == null || rt.classList.toggle("on", s);
  }
  function l(s, r) {
    const g = s.trim();
    if (!g) return !1;
    Ye(m("pet.ai_chat_thinking"), !0), Bt || fa();
    const w = { query: g };
    return r && r.length && (w.files = r), Y(Kr, w).catch((N) => yt("发送 AI 消息失败", N)), i(!0), !0;
  }
  function b(s) {
    return s ? { promptKey: "pet.watch_prompt", needsShot: !0 } : { promptKey: "pet.proactive_prompt", needsShot: !1 };
  }
  const p = {
    timer: null,
    remainMs: 0,
    deadline: 0
  };
  let S = null, P = null, $ = !1, x = null, I = !1, j = 0, q = null, nt = !1, R = null, f = !1, _ = !1, L = null;
  const h = 18e4;
  function C() {
    p.timer && (clearTimeout(p.timer), p.timer = null);
  }
  function F() {
    q && (clearTimeout(q), q = null);
  }
  function O(s, r = !1) {
    C(), p.remainMs = s, p.deadline = performance.now() + s, p.timer = setTimeout(() => {
      p.timer = null, p.remainMs = 0, r ? (tt({ reset: !0 }), Oe()) : Mi();
    }, s);
  }
  function tt(s = {}) {
    C();
    const r = M().proactive;
    if (!r.enabled || !et) return;
    if (Ot(r)) {
      ut();
      return;
    }
    s.reset && (p.remainMs = 0);
    const g = p.remainMs > 0 ? p.remainMs : r.intervalMin * 6e4;
    O(g);
  }
  function ut() {
    !et || !M().proactive.enabled || O(cs(), !0);
  }
  function ee() {
    p.timer && (clearTimeout(p.timer), p.timer = null, p.remainMs = Math.max(0, p.deadline - performance.now()));
  }
  async function Ie(s) {
    if ($) return !1;
    $ = !0;
    const r = m(s.promptKey);
    return (s.needsShot ? await Ci(r) : l(r)) ? (os(), Y(B, { type: "proactive-used" }), P = setTimeout(() => {
      P = null, $ && ($ = !1, tt());
    }, ns), !0) : ($ = !1, !1);
  }
  async function pa() {
    if ($) return !1;
    const s = M().proactive;
    if (!et || !s.enabled) return !1;
    if (Ot(s))
      return ut(), !1;
    const r = I && Date.now() - j >= s.screenMinGapSec * 1e3;
    r && (I = !1);
    let g = b(r), w = await Ie(g);
    return !w && g.needsShot && !$ && et && s.enabled && (g = b(!1), w = await Ie(g)), w ? g.needsShot && (j = Date.now(), x = null) : $ || tt(), w;
  }
  async function Mi() {
    const s = M().proactive;
    if (!(!et || !s.enabled)) {
      if (Ot(s)) {
        ut();
        return;
      }
      if ($) {
        tt();
        return;
      }
      if (q) {
        tt();
        return;
      }
      await pa();
    }
  }
  function Ei() {
    $ && ($ = !1, P && (clearTimeout(P), P = null), tt());
  }
  async function Ci(s) {
    var N;
    let r = !1;
    try {
      r = !!((N = await d("get_ai_config")) != null && N.vision);
    } catch {
    }
    if (!r)
      return nt || (nt = !0, d("log_frontend", {
        level: "warn",
        message: "[pet] 主动反应检测到屏幕变化，但当前未开启「图片输入」⇒ 回落为纯文字（图片块会被静默丢弃，不白烧 token）。要让它真的发出去，请在 AI 设置里开启图片输入 / 换支持视觉的模型。"
      }).catch(() => {
      })), !1;
    st(m("pet.look_screen_working"), 2e3);
    let g = null;
    try {
      g = await d("screenshot_monitor", { label: ve });
    } catch (H) {
      return yt("自动抓屏失败", H), !1;
    }
    const w = g == null ? void 0 : g.path;
    return w ? l(s, [w]) : !1;
  }
  function Oe() {
    if (S || !et) return;
    const s = M().proactive;
    !s.enabled || Ot(s) || (S = setTimeout(() => {
      S = null, Ti();
    }, s.screenPollSec * 1e3));
  }
  function wn() {
    S && (clearTimeout(S), S = null);
  }
  function $i() {
    if (q || !I) return;
    const s = M().proactive;
    if (!(!et || !s.enabled || $)) {
      if (Ot(s)) {
        ut();
        return;
      }
      Date.now() - j < s.screenMinGapSec * 1e3 || (q = setTimeout(() => {
        q = null, Ai();
      }, ss));
    }
  }
  async function Ti() {
    const s = M().proactive;
    if (!et || !s.enabled) return;
    if (Ot(s)) {
      ut();
      return;
    }
    let r = null;
    try {
      const g = await d("screenshot_signature", { label: ve });
      Array.isArray(g) && g.length && (r = g.map((w) => Number(w) || 0));
    } catch {
    }
    r && (x && x.length === r.length && ls(x, r) >= s.screenDiff && (I = !0), x = r), $i(), Oe();
  }
  async function Ai() {
    const s = M().proactive;
    if (!(!et || !s.enabled)) {
      if (Ot(s)) {
        ut();
        return;
      }
      $ || await pa();
    }
  }
  function ua() {
    et = !1, It(!0), Ce(), z == null || z.setRunning(!1), jt(), ee(), wn(), F(), I = !1, x = null;
  }
  function da() {
    et = !0, z ? z.setRunning(!0) : Jt(), tt(), Oe(), Ct(!0);
  }
  function fa() {
    R && (clearTimeout(R), R = null), Bt || (f = !0, me(!0, !1, !1));
  }
  function Li() {
    _ = !0, L && clearTimeout(L), L = setTimeout(() => {
      L = null, _ = !1, _n();
    }, h);
  }
  function xn() {
    L && (clearTimeout(L), L = null), _ = !1, _n();
  }
  function _n() {
    et && ot === null && (_ || Ni());
  }
  function Ni() {
    R && (clearTimeout(R), R = null), f && (R = setTimeout(() => {
      R = null, f = !1, Bt && me(!1);
    }, es));
  }
  const ma = (s) => {
    s.key !== "Enter" || s.shiftKey || s.isComposing || (s.preventDefault(), it && l(it.value) && (it.value = ""));
  }, ha = () => me(!1), Pi = () => {
    i(!1), xn(), Ye(m("pet.chat_reply_interrupted"), !0), Y(Zr).catch((s) => yt("中止 AI 消息失败", s));
  };
  it == null || it.addEventListener("keydown", ma), X == null || X.addEventListener("click", ha), rt == null || rt.addEventListener("click", Pi);
  let kn = !1;
  const ga = () => {
    kn || (kn = !0, K == null || K.classList.add("on"), K && (K.disabled = !0), st(m("pet.voice_listening"), 2600), d("recognize_speech").then((s) => {
      if (s && s.reason === "ok" && typeof s.text == "string" && s.text.trim()) {
        it && (it.value = ""), l(s.text);
        return;
      }
      const r = (s == null ? void 0 : s.reason) ?? "unknown";
      st(
        m(r === "no-speech" || r === "canceled" ? "pet.voice_no_speech" : r === "microphone-unavailable" ? "pet.voice_no_mic" : r === "language-not-supported" ? "pet.voice_no_language" : "pet.voice_failed"),
        3200
      );
    }).catch((s) => {
      yt("语音识别失败", s), st(m("pet.voice_failed"), 3200);
    }).finally(() => {
      kn = !1, K == null || K.classList.remove("on"), K && (K.disabled = !1);
    }));
  };
  K == null || K.addEventListener("click", ga);
  let $t = null;
  function Ii(s, r) {
    if ($t && (clearInterval($t), $t = null), !s.length || !r) return;
    const g = 1e3 / r, w = performance.now();
    $t = setInterval(() => {
      const N = Math.floor((performance.now() - w) / g);
      if (N >= s.length) {
        $t && clearInterval($t), $t = null, z == null || z.setMouthOpen(null);
        return;
      }
      z == null || z.setMouthOpen(s[N] / 255);
    }, g);
  }
  const Oi = await xt().listen(
    Qr,
    (s) => {
      var N, H;
      if (!_t()) return;
      const g = (Array.isArray((N = s.payload) == null ? void 0 : N.env) ? s.payload.env : []).map((W) => typeof W == "number" && Number.isFinite(W) ? W : 0), w = typeof ((H = s.payload) == null ? void 0 : H.fps) == "number" && s.payload.fps > 0 ? s.payload.fps : 40;
      Ii(g, w);
    }
  ), Di = await xt().listen(Jr, (s) => {
    var g;
    if (!_t()) return;
    const r = typeof ((g = s.payload) == null ? void 0 : g.text) == "string" ? s.payload.text : "";
    i(!1), r && M().tts && (Li(), d("tts_speak", { text: r, enabled: !0 }).catch(() => {
      xn();
    })), et && fa(), Ke(r, () => _n()), Ei();
  }), Fi = await xt().listen(ts, () => {
    _t() && xn();
  });
  T == null || T.addEventListener("click", (s) => {
    var g;
    const r = (g = s.target.closest("button")) == null ? void 0 : g.dataset.act;
    r && (jt(), (async () => {
      if (r === "ai-chat") {
        me(!Bt);
        return;
      }
      if (r === "settings") {
        await d("open_plugin_window", { pluginId: "pet", key: "settings", input: "" });
        return;
      }
      if (r === "look-screen") {
        await Zt();
        return;
      }
      if (r === "change") {
        const w = await On({
          multiple: !1,
          directory: !0,
          title: "选择 Live2D 模型文件夹（里面要有 *.model3.json）"
        }), N = typeof w == "string" ? w : "";
        if (!N) return;
        let H = "", W = "";
        try {
          const Q = await d("scan_model_folder", { dir: N });
          H = (Q.model3 ?? [])[0] ?? "", W = (Q.vtube ?? [])[0] ?? "";
        } catch (Q) {
          st("读文件夹失败", 2600), yt("更换模型：读文件夹失败", Q);
          return;
        }
        if (!H) {
          st("这个文件夹里没有 *.model3.json", 2600);
          return;
        }
        const G = await Ka(H);
        if (!G.ok) {
          st(`这个模型用不了：${G.reason}`, 3e3);
          return;
        }
        U({ ...M(), model: H, image: "" }), cn(H);
        try {
          await Gn(N, H, W);
        } catch (Q) {
          yt("更换模型：读取热键失败", Q);
        }
        Se();
        return;
      }
      if (r === "reset") {
        Kt(1), Me(0, 0), Ee(0), U(A), Y(B, { type: "scale-changed", value: 1 }), Y(B, { type: "rotation-changed", value: 0 }), st("已恢复默认大小、位置与角度", 2e3);
        return;
      }
      if (r === "win-reset") {
        Qt = _e, Et = oe, A = { ...A, winW: _e, winH: oe }, U(A), te = -1, Ct(!0), st(m("pet.win_reset_done"), 2e3);
        return;
      }
      if (r === "through") {
        const w = !A.clickThrough;
        A = { ...A, clickThrough: w }, U(A), await bt(w), $e(), Y(B, { type: "click-through-changed", value: w });
        return;
      }
      r === "close" && await d("plugin_window_close").catch(() => {
      });
    })().catch((w) => yt("菜单动作失败", w)));
  });
  function Ri(s) {
    const r = z;
    if (!r) {
      st("桌宠还没显示 Live2D 模型", 2600);
      return;
    }
    switch (s.type) {
      case "motion":
        r.playMotion(s.group, s.index);
        break;
      case "chain":
        De(s.id);
        break;
      case "expression":
        s.mode === "clear" || !s.target ? r.resetExpressions() : r.setExpression(s.target);
        break;
      case "param":
        r.setParameter(s.id, s.mode === "add" ? r.getParameter(s.id) + s.value : s.value);
        break;
      case "artmesh":
        r.setDrawableOpacity(s.id, s.value);
        break;
      case "part":
        r.setPartOpacity(s.id, s.value);
        break;
      case "physics":
        r.setPhysicsEnabled(s.enabled);
        break;
    }
  }
  const ne = /* @__PURE__ */ new Set(), ba = /* @__PURE__ */ new Map(), Sn = () => {
    Y(B, { type: "hotkey-states", ids: [...ne] });
  };
  function zi() {
    const s = M().model.trim();
    if (!s) return;
    const r = [...ne].filter((N) => {
      const H = ba.get(N);
      return H !== "motion" && H !== "chain";
    }), g = M(), w = { ...g.hotkeyStates };
    r.length ? w[s] = r : delete w[s], U({ ...g, hotkeyStates: w });
  }
  async function Hi(s) {
    const r = M().hotkeyStates[s] ?? [];
    if (!r.length) return;
    let g;
    try {
      g = await we(s);
    } catch {
      return;
    }
    const w = new Map(g.map((N) => [N.id, N]));
    for (const N of r) {
      const H = w.get(N);
      !H || H.action.type === "motion" || ne.has(N) || await Je(N, H.action);
    }
  }
  async function De(s) {
    const r = z, g = A.model.trim();
    if (!r || !g || !s) {
      st("桌宠还没显示 Live2D 模型", 2600);
      return;
    }
    const N = (await rn(g)).find((G) => G.id === s);
    if (!N || !N.steps.length) {
      st("这条动作链是空的", 2200);
      return;
    }
    const H = await ye(g), W = N.steps.map((G) => ({ index: H.findIndex((ft) => ft.path.toLowerCase() === G.file.toLowerCase()), ms: qn(G) * 1e3, hardMs: G.stopSec > 0 ? G.stopSec * 1e3 : 0 })).filter((G) => G.index >= 0);
    if (!W.length) {
      st("动作链里的动作文件都不在了", 2400);
      return;
    }
    dt = s, r.playChain(W, N.loop);
  }
  async function Je(s, r) {
    const g = z;
    if (!g) {
      st("桌宠还没显示 Live2D 模型", 2600);
      return;
    }
    const w = !ne.has(s);
    switch (ba.set(s, r.type), r.type) {
      case "expression": {
        const N = r.file ? await ei(r.file) : [];
        N.length ? g.setExpressionLayer(s, w ? N : null) : w ? r.target && g.setExpression(r.target) : g.resetExpressions();
        break;
      }
      case "artmesh":
        g.setDrawableOpacity(r.id, w ? r.value : 1);
        break;
      case "artmeshColor":
        g.setDrawableColor(r.id, w ? Ds(r.color) : null);
        break;
      case "part":
        g.setPartOpacity(r.id, w ? r.value : 1);
        break;
      case "physics":
        g.setPhysicsEnabled(w ? r.enabled : !r.enabled);
        break;
      case "param":
        g.setParameter(r.id, w ? r.value : 0);
        break;
      case "motion":
        w && g.playMotion(r.group, r.index);
        break;
      case "chain":
        w ? await De(r.id) : (dt = "", g.stopChain());
        break;
    }
    w ? ne.add(s) : ne.delete(s), Sn(), zi();
  }
  async function Wi(s, r, g) {
    const w = z, N = A.model.trim(), H = r.trim();
    if (!(!w || !N || !H)) {
      if (s === "auto") {
        const G = (await we(N)).find((Tt) => Tt.keys.trim().toLowerCase() === H.toLowerCase());
        if (G) {
          await Je(G.id, G.action);
          return;
        }
        const ft = (await ye(N)).findIndex((Tt) => Tt.name.trim().toLowerCase() === H.toLowerCase());
        if (ft >= 0) {
          w.playMotion(Dn, ft);
          return;
        }
        const ie = (await rn(N)).find((Tt) => Tt.name.trim().toLowerCase() === H.toLowerCase());
        if (ie) {
          await De(ie.id);
          return;
        }
        w.setExpression(H);
        return;
      }
      if (s === "chain") {
        const W = await rn(N), G = W.find((Q) => Q.id === H) || W.find((Q) => Q.name.trim().toLowerCase() === H.toLowerCase());
        G && await De(G.id);
        return;
      }
      if (s === "hotkey") {
        const W = await we(N), G = W.find((Q) => Q.keys.trim().toLowerCase() === H.toLowerCase()) || W.find((Q) => Q.name.trim() === H);
        G && await Je(G.id, G.action);
        return;
      }
      if (s === "motion") {
        const G = (await ye(N)).findIndex((Q) => Q.name.trim().toLowerCase() === H.toLowerCase());
        G >= 0 && w.playMotion(Dn, G);
        return;
      }
      if (s === "param") {
        w.setParameter(H, typeof g == "number" ? g : 0);
        return;
      }
      if (s === "expression") {
        g === 0 ? w.resetExpressions() : w.setExpression(H);
        return;
      }
      if (s === "artmeshColor") {
        const W = typeof g == "number" && Number.isFinite(g) ? Math.floor(g) : 16777215, G = Math.min(16777215, Math.max(0, W));
        w.setDrawableColor(H, {
          r: (G >> 16 & 255) / 255,
          g: (G >> 8 & 255) / 255,
          b: (G & 255) / 255
        });
      }
    }
  }
  const ji = await ht(B, (s) => {
    const r = s.payload;
    if (r != null && r.type) {
      if (r.type === "ping") {
        _t() && (Y(B, { type: "pong", token: r.token, visible: et }), Sn());
        return;
      }
      if (r.type === "reload") {
        Se();
        return;
      }
      if (r.type === "idle-set" && _t()) {
        (async () => {
          const g = z, w = M().model.trim();
          if (!(!g || !w))
            try {
              const N = await ye(w), H = Un(w);
              g.setIdleMotions(N.filter((W) => H.has(W.name.toLowerCase())).map((W) => W.path));
            } catch (N) {
              yt("更新循环播放列表失败", N);
            }
        })();
        return;
      }
      if (r.type === "hide" && _t()) {
        ua(), xt().hide().catch((g) => yt("隐藏模型失败", g));
        return;
      }
      if (r.type === "show" && _t()) {
        (async () => {
          try {
            const g = xt();
            await g.unminimize().catch(() => {
            }), await g.show();
          } catch (g) {
            yt("显示模型失败", g);
          }
          da();
        })();
        return;
      }
      if (r.type === "set-scale" && typeof r.value == "number") {
        U({ ...M(), scale: r.value }), Kt(r.value);
        return;
      }
      if (r.type === "set-rotation" && typeof r.value == "number") {
        U({ ...M(), rotation: r.value }), Ee(r.value);
        return;
      }
      if (r.type === "set-click-through" && typeof r.value == "boolean" && (A = { ...A, clickThrough: r.value }, bt(r.value), $e()), r.type === "set-proactive") {
        const g = M();
        U({
          ...g,
          proactive: {
            ...g.proactive,
            enabled: r.enabled === !0,
            intervalMin: ct(r.intervalMin, Jn, Zn, g.proactive.intervalMin),
            dailyCap: ct(r.dailyCap, Qn, ta, g.proactive.dailyCap),
            screenPollSec: ct(r.screenPollSec, ea, na, g.proactive.screenPollSec),
            screenMinGapSec: ct(
              r.screenMinGapSec,
              ra,
              sa,
              g.proactive.screenMinGapSec
            ),
            screenDiff: ct(r.screenDiff, aa, ia, g.proactive.screenDiff)
          }
        }), I = !1, x = null, F(), tt({ reset: !0 }), wn(), Oe();
        return;
      }
      if (r.type === "set-param" && typeof r.id == "string" && typeof r.value == "number") {
        z == null || z.setParameter(r.id, r.value);
        return;
      }
      if (r.type === "reset-params" && Array.isArray(r.ids)) {
        const g = z;
        if (g)
          for (const w of r.ids) typeof w == "string" && g.setParameter(w, 0);
        return;
      }
      if (r.type === "set-expression" && typeof r.id == "string") {
        if (!z) return;
        r.id ? z.setExpression(r.id) : z.resetExpressions();
        return;
      }
      if (r.type === "hotkey-run" && r.action && typeof r.action == "object") {
        Ri(r.action);
        return;
      }
      if (r.type === "hotkey-toggle" && typeof r.id == "string" && r.action && typeof r.action == "object") {
        Je(r.id, r.action);
        return;
      }
      if (r.type === "motion-play" && typeof r.group == "string") {
        const g = z;
        if (!g) {
          st("桌宠还没显示 Live2D 模型", 2600);
          return;
        }
        g.playMotion(r.group, typeof r.index == "number" ? r.index : 0);
        return;
      }
      if (r.type === "chain-play" && typeof r.id == "string" && _t()) {
        De(r.id);
        return;
      }
      r.type === "ai-action" && typeof r.action == "string" && typeof r.name == "string" && Wi(r.action, r.name, typeof r.value == "number" ? r.value : void 0);
    }
  }), Bi = await ht(
    "plugin-window-visibility",
    (s) => {
      var r, g;
      (r = s.payload) != null && r.label && s.payload.label !== ve || (((g = s.payload) == null ? void 0 : g.visible) === !1 ? ua() : da());
    }
  );
  Si(), d("plugin_window_set_resizable", { resizable: !0 }).catch(() => {
  });
  {
    const s = jn(A.winW, A.winH);
    Qt = s.w, Et = s.h;
  }
  Ct(!0);
  const Vi = await xt().onResized((s) => {
    if (!et) return;
    const r = s.payload, g = window.devicePixelRatio || 1, w = r.height / g, N = Oa(w);
    Vt > N && (Vt = N, Ne(N));
    const H = Vt;
    Gt && clearTimeout(Gt), Gt = setTimeout(() => {
      Gt = null;
      const W = jn(r.width / g, Yr(w, H));
      W.w === Qt && W.h === Et || (Qt = W.w, Et = W.h, A = { ...A, winW: W.w, winH: W.h }, U(A));
    }, 250);
  });
  Se(), A.clickThrough && await bt(!0), Y(B, { type: "click-through-changed", value: A.clickThrough }), tt({ reset: !0 }), Oe();
  const Gi = await ht("pet-alt-rclick", (s) => {
    var w, N;
    if (!_t()) return;
    const r = Number((w = s.payload) == null ? void 0 : w.x), g = Number((N = s.payload) == null ? void 0 : N.y);
    !Number.isFinite(r) || !Number.isFinite(g) || fe(r, g).catch((H) => yt("Alt+右键唤出菜单失败", H));
  });
  re = () => {
    Ce(), pe(), Wt && clearTimeout(Wt), C(), wn(), F(), P && clearTimeout(P), R && clearTimeout(R), L && clearTimeout(L), Gt && clearTimeout(Gt), $t && (clearInterval($t), $t = null), ji(), Bi(), Gi(), Di(), Fi(), Oi(), Vi(), z == null || z.setMouthOpen(null), it == null || it.removeEventListener("keydown", ma), K == null || K.removeEventListener("click", ga), X == null || X.removeEventListener("click", ha), window.removeEventListener("mousemove", Te), window.removeEventListener("mouseup", Ae), d("pet_alt_rclick_watch", { on: !1 }).catch(() => {
    });
  };
}
const Gs = {
  id: "pet",
  name: "桌宠",
  keywords: ["桌宠", "宠物", "桌面宠物", "pet", "desktop pet", "live2d", "看板娘", "吉祥物"],
  description: "桌宠 —— 独立透明置顶的桌面形象窗（图片或 Live2D 模型，由你自己导入）",
  icon: "🐾",
  // **刻意不声明 `window.float`**：它的入口是**带 key 的附属窗**（`plugin-pet-settings`），
  // 不是自己的形象窗 —— `main.ts` 的 `executePlugin` 按 id 特判直接开那扇窗（2026-10-09）。
  permissions: [],
  async execute(e) {
    return _t() ? { type: "html", content: js() } : Fa() ? { type: "html", content: Hs(M()) } : { type: "html", content: "" };
  },
  async attach(e) {
    if (cn(M().model), _t()) {
      await Vs(e);
      return;
    }
    if (Fa()) {
      await Ws(e);
      return;
    }
  },
  detach() {
    re == null || re(), re = null;
  }
};
export {
  Gs as default,
  Ps as motionTemplateParamIds
};
