function b(t, e = !1) {
  return window.__TAURI_INTERNALS__.transformCallback(t, e);
}
async function l(t, e = {}, n) {
  return window.__TAURI_INTERNALS__.invoke(t, e, n);
}
function w(t, e = "asset") {
  return window.__TAURI_INTERNALS__.convertFileSrc(t, e);
}
const C = "__lunac_host";
function I() {
  return globalThis[C] ?? null;
}
function a(t, e) {
  const n = I();
  return n && typeof n.t == "function" ? n.t(t, e) : t;
}
var y;
(function(t) {
  t.WINDOW_RESIZED = "tauri://resize", t.WINDOW_MOVED = "tauri://move", t.WINDOW_CLOSE_REQUESTED = "tauri://close-requested", t.WINDOW_DESTROYED = "tauri://destroyed", t.WINDOW_FOCUS = "tauri://focus", t.WINDOW_BLUR = "tauri://blur", t.WINDOW_SCALE_FACTOR_CHANGED = "tauri://scale-change", t.WINDOW_THEME_CHANGED = "tauri://theme-changed", t.WINDOW_CREATED = "tauri://window-created", t.WINDOW_SUSPENDED = "tauri://suspended", t.WINDOW_RESUMED = "tauri://resumed", t.WEBVIEW_CREATED = "tauri://webview-created", t.DRAG_ENTER = "tauri://drag-enter", t.DRAG_OVER = "tauri://drag-over", t.DRAG_DROP = "tauri://drag-drop", t.DRAG_LEAVE = "tauri://drag-leave";
})(y || (y = {}));
async function v(t, e) {
  window.__TAURI_EVENT_PLUGIN_INTERNALS__.unregisterListener(t, e), await l("plugin:event|unlisten", {
    event: t,
    eventId: e
  });
}
async function D(t, e, n) {
  var i;
  const r = (i = void 0) !== null && i !== void 0 ? i : { kind: "Any" };
  return l("plugin:event|listen", {
    event: t,
    target: r,
    handler: b(e)
  }).then((s) => async () => v(t, s));
}
const g = class g {
  constructor() {
    this.lastBytes = 0, this.lastAt = 0, this.speed = 0, this.primed = !1;
  }
  push(e, n, i = Date.now()) {
    const r = n > 0 ? Math.min(100, Math.round(e / n * 100)) : -1;
    if (!this.primed)
      return this.primed = !0, this.lastBytes = e, this.lastAt = i, { percent: r, speed: 0, downloaded: e, total: n };
    const s = (i - this.lastAt) / 1e3;
    if (s >= g.MIN_DT) {
      const c = Math.max(0, (e - this.lastBytes) / s);
      this.speed = this.speed === 0 ? c : this.speed * 0.65 + c * 0.35, this.lastBytes = e, this.lastAt = i;
    }
    return { percent: r, speed: this.speed, downloaded: e, total: n };
  }
  reset() {
    this.lastBytes = 0, this.lastAt = 0, this.speed = 0, this.primed = !1;
  }
};
g.MIN_DT = 0.4;
let m = g;
function B(t) {
  if (!(t > 0)) return "0 B";
  const e = ["B", "KB", "MB", "GB"];
  let n = t, i = 0;
  for (; n >= 1024 && i < e.length - 1; )
    n /= 1024, i++;
  return `${n >= 100 || i === 0 ? Math.round(n) : n.toFixed(1)} ${e[i]}`;
}
function L(t) {
  return t > 0 ? `${B(t)}/s` : "—";
}
function R(t) {
  return `
    <span class="dl-ring-wrap is-unknown">
      <svg class="dl-ring" viewBox="0 0 36 36" aria-hidden="true">
        <circle class="dl-ring-track" cx="18" cy="18" r="15.5" pathLength="100"></circle>
        <circle class="dl-ring-fill" cx="18" cy="18" r="15.5" pathLength="100"
                style="stroke-dashoffset:100"></circle>
      </svg>
      <span class="dl-ring-pct"></span>
    </span>`;
}
function $(t, e) {
  const n = t.querySelector(".dl-ring-wrap"), i = t.querySelector(".dl-ring-fill"), r = t.querySelector(".dl-ring-pct");
  if (!n || !i) return !1;
  const s = e >= 0;
  return n.classList.toggle("is-unknown", !s), i.style.strokeDashoffset = String(s ? 100 - Math.max(0, Math.min(100, e)) : 100), r && (r.textContent = s ? String(Math.round(e)) : ""), !0;
}
function N(t) {
  return new Promise((e) => {
    let n;
    const i = new m();
    (async () => {
      try {
        n = await D("plugin-install-progress", (s) => {
          const c = s.payload;
          c.id === "ocr" && (t == null || t({ ...i.push(c.downloaded, c.total), phase: c.phase }));
        });
      } catch {
      }
      let r = !1;
      try {
        await l("install_plugin_dependencies", { id: "ocr" }), r = !0;
      } catch {
        r = !1;
      } finally {
        try {
          n == null || n();
        } catch {
        }
      }
      e(r);
    })();
  });
}
function S(t) {
  if (!t) return;
  t.innerHTML = `${a("ocr.engine_missing")} `;
  const e = document.createElement("button");
  e.className = "ocr-action-btn ocr-primary-btn", e.style.marginLeft = "6px", e.textContent = a("ocr.engine_download"), e.addEventListener("click", async () => {
    e.disabled = !0;
    const n = document.createElement("span");
    n.className = "dl-inline", n.style.marginLeft = "6px", n.innerHTML = R() + `<span class="dl-meta">
         <span class="dl-phase">${a("ocr.engine_downloading_unknown").replace("{mb}", "0")}</span>
         <span class="dl-speed">—</span>
       </span>`, e.replaceWith(n);
    const i = n.querySelector(".dl-phase"), r = n.querySelector(".dl-speed"), s = await N(({ percent: o, speed: d, downloaded: u }) => {
      $(n, o), i && (i.textContent = o >= 0 ? a("ocr.engine_downloading").replace("{percent}", String(o)) : a("ocr.engine_downloading_unknown").replace("{mb}", (u / 1048576).toFixed(1))), r && (r.textContent = L(d));
    });
    n.remove();
    let c = !1;
    if (s)
      try {
        c = await l("ocr_engine_status");
      } catch {
        c = !1;
      }
    c ? t.textContent = a("ocr.engine_ready") : s ? t.textContent = a("ocr.engine_not_declared") : t.textContent = a("ocr.engine_failed");
  }), t.appendChild(e);
}
async function f(t) {
  try {
    if (await l("ocr_engine_status")) return !0;
  } catch {
    return !0;
  }
  return S(t), !1;
}
async function x() {
  try {
    const t = await l("read_clipboard_files");
    if (t.length > 0)
      return `__file__${t[0]}`;
  } catch {
  }
  try {
    const t = await l("read_clipboard_backup_image");
    if (t) {
      const e = t.lastIndexOf("|");
      return `__file__${e > 0 ? t.substring(0, e) : t}`;
    }
  } catch {
  }
  return null;
}
function O(t) {
  return new Promise((e, n) => {
    const i = new FileReader();
    i.onload = () => e(i.result), i.onerror = () => n(new Error("Failed to read blob")), i.readAsDataURL(t);
  });
}
async function A(t) {
  return { text: (await l("run_paddle_ocr", { path: t })).trim() };
}
async function h(t) {
  const e = await l("save_temp_image", { dataUrl: t }), n = await l("run_paddle_ocr", { path: e });
  return l("delete_temp_image", { path: e }).catch(() => {
  }), { text: n.trim() };
}
async function W(t) {
  return w(t);
}
const T = {
  id: "ocr",
  name: "OCR 文字识别",
  keywords: [
    "ocr",
    "识别",
    "文字识别",
    "图像识别",
    "图片转文字",
    "截图识别",
    "图识字",
    "文字提取"
  ],
  description: "OCR 图片文字识别 (PaddleOCR · 离线高精度)",
  icon: "🔍",
  badge: "AI",
  // 接管整个窗口（双栏：左图右文）。宿主据此决定「不套 .plugin-result、直接 detach、
  // 把 attach 的 root 传成文档根」—— 见 main.ts 的 isTakeoverPlugin()。
  permissions: ["layout.takeover"],
  async execute(t) {
    return { type: "html", content: M() };
  }
};
function M() {
  return `
    <div class="ocr-detached-layout">
      <!-- 左半：图片预览 -->
      <div class="ocr-image-panel">
        <div id="ocr-image-preview" class="ocr-image-preview">
          <span class="ocr-image-placeholder">${a("ocr.no_image")}</span>
        </div>
        <div class="ocr-image-actions">
          <button id="ocr-clipboard-btn" class="ocr-action-btn ocr-primary-btn">
            ${a("ocr.clipboard_btn")}
          </button>
          <button id="ocr-file-btn" class="ocr-action-btn">
            ${a("ocr.file_btn")}
          </button>
        </div>
      </div>

      <!-- 右半：文字编辑区 -->
      <div class="ocr-text-panel">
        <div id="ocr-status-line" class="ocr-status-line">
          ${a("ocr.default_status")}
        </div>
        <button id="ocr-copy-btn" class="ocr-copy-btn">${a("ocr.copy_btn")}</button>
        <textarea
          id="ocr-result" class="ocr-textarea"
          spellcheck="false"
          placeholder="${a("ocr.placeholder")}"
        ></textarea>
      </div>
    </div>`;
}
async function k() {
  const t = document.getElementById("ocr-status-line"), e = document.getElementById("ocr-result"), n = document.getElementById("ocr-image-preview");
  t && (t.textContent = a("ocr.reading"));
  const i = await x();
  if (!i) {
    t && (t.textContent = a("ocr.no_clipboard"));
    return;
  }
  if (i.startsWith("__file__")) {
    const r = i.slice(8);
    await _(r);
    return;
  }
  if (n && (n.innerHTML = `<img src="${i}" class="ocr-preview-img" alt="Clipboard image" />`), !!await f(t)) {
    t && (t.textContent = a("ocr.recognizing"));
    try {
      const r = await h(i);
      t && (t.textContent = a("ocr.done")), e && (e.value = r.text || a("ocr.no_text"), e.style.height = "auto", e.style.height = Math.max(e.scrollHeight, 120) + "px");
    } catch (r) {
      t && (t.textContent = `${a("ocr.failed")}${r}`);
    }
  }
}
async function _(t) {
  const e = document.getElementById("ocr-status-line"), n = document.getElementById("ocr-result"), i = document.getElementById("ocr-image-preview");
  if (e && (e.textContent = a("ocr.loading_image")), !!await f(e)) {
    if (i)
      try {
        const r = await W(t);
        i.innerHTML = `<img src="${r}" class="ocr-preview-img" alt="OCR image" onerror="this.parentElement!.innerHTML='<span class=\\'ocr-image-placeholder\\'>${a("ocr.load_failed").replace("'", "\\'")}</span>'" />`;
      } catch {
        i.innerHTML = `<img src="${w(t)}" class="ocr-preview-img" alt="OCR image" onerror="this.parentElement!.innerHTML='<span class=\\'ocr-image-placeholder\\'>${t.split("\\").pop()}</span>'" />`;
      }
    e && (e.textContent = a("ocr.recognizing"));
    try {
      const r = await A(t);
      e && (e.textContent = a("ocr.done")), n && (n.value = r.text || a("ocr.no_text"), n.style.height = "auto", n.style.height = Math.max(n.scrollHeight, 120) + "px");
    } catch (r) {
      e && (e.textContent = `${a("ocr.failed")}${r}`);
    }
  }
}
function H(t) {
  var e, n, i;
  (e = t.getElementById("ocr-clipboard-btn")) == null || e.addEventListener("click", async () => {
    const r = t.getElementById("ocr-status-line"), s = t.getElementById("ocr-result"), c = t.getElementById("ocr-image-preview");
    r && (r.textContent = a("ocr.reading")), s && (s.value = "");
    const o = await x();
    if (!o) {
      r && (r.textContent = a("ocr.no_clipboard"));
      return;
    }
    if (o.startsWith("__file__")) {
      await _(o.slice(8));
      return;
    }
    if (c && (c.innerHTML = `<img src="${o}" class="ocr-preview-img" alt="Clipboard image" />`), !!await f(r)) {
      r && (r.textContent = a("ocr.recognizing"));
      try {
        const d = await h(o);
        r && (r.textContent = a("ocr.done")), s && (s.value = d.text || a("ocr.no_text"), s.style.height = "auto", s.style.height = Math.max(s.scrollHeight, 120) + "px");
      } catch (d) {
        r && (r.textContent = `${a("ocr.failed")}${d}`);
      }
    }
  }), (n = t.getElementById("ocr-file-btn")) == null || n.addEventListener("click", () => {
    const r = document.createElement("input");
    r.type = "file", r.accept = "image/*", r.style.display = "none", r.onchange = async () => {
      var u;
      const s = (u = r.files) == null ? void 0 : u[0];
      if (!s) return;
      const c = t.getElementById("ocr-status-line"), o = t.getElementById("ocr-result"), d = t.getElementById("ocr-image-preview");
      if (await f(c)) {
        c && (c.textContent = a("ocr.recognizing")), o && (o.value = "");
        try {
          const p = await O(s);
          d && (d.innerHTML = `<img src="${p}" class="ocr-preview-img" alt="Selected image" />`);
          const E = await h(p);
          c && (c.textContent = a("ocr.done")), o && (o.value = E.text || a("ocr.no_text"), o.style.height = "auto", o.style.height = Math.max(o.scrollHeight, 120) + "px");
        } catch (p) {
          c && (c.textContent = `${a("ocr.failed")}${p}`);
        }
      }
    }, document.body.appendChild(r), r.click();
  }), (i = t.getElementById("ocr-copy-btn")) == null || i.addEventListener("click", () => {
    const r = t.getElementById("ocr-result"), s = (r == null ? void 0 : r.value) || "";
    navigator.clipboard.writeText(s).then(() => {
      const c = t.getElementById("ocr-copy-btn");
      c && (c.textContent = a("ocr.copied"), c.classList.add("ocr-copied"), setTimeout(() => {
        c.textContent = a("ocr.copy_btn"), c.classList.remove("ocr-copied");
      }, 1500));
    }).catch(() => {
      const c = t.getElementById("ocr-result");
      c && c.select();
    });
  });
}
async function U(t) {
  H(document);
  const e = window.__lunac_ocr_image;
  e ? (delete window.__lunac_ocr_image, await _(e)) : await k();
}
export {
  U as attach,
  H as attachOcrListeners,
  k as autoStartClipboardOcr,
  T as default,
  _ as ocrImageFile,
  T as ocrPlugin
};
