const e = {
  id: "local-model",
  name: "本地决策模型",
  keywords: ["本地模型", "local model", "llama", "llama-server", "决策", "离线", "gguf", "省钱"],
  description: "本地小模型（llama-server）—— 只参与「要不要把消息发给云模型」的决策，省钱",
  icon: "🧠",
  permissions: [],
  async execute() {
    return {
      type: "html",
      content: '<div style="padding:12px 14px;font-size:.78rem;color:var(--text);line-height:1.7;">本地决策模型没有独立界面 —— 请在「设置 → AI → 本地模型决策」里开关。</div>'
    };
  }
};
export {
  e as default
};
