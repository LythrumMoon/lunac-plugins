const qn = "__lunac_host";
function En() {
  return globalThis[qn] ?? null;
}
function n(e, t) {
  const i = En();
  return i && typeof i.t == "function" ? i.t(e, t) : e;
}
function Mn(e, t = !1) {
  return window.__TAURI_INTERNALS__.transformCallback(e, t);
}
async function h(e, t = {}, i) {
  return window.__TAURI_INTERNALS__.invoke(e, t, i);
}
function vi(e, t = "asset") {
  return window.__TAURI_INTERNALS__.convertFileSrc(e, t);
}
var Ds;
(function(e) {
  e.WINDOW_RESIZED = "tauri://resize", e.WINDOW_MOVED = "tauri://move", e.WINDOW_CLOSE_REQUESTED = "tauri://close-requested", e.WINDOW_DESTROYED = "tauri://destroyed", e.WINDOW_FOCUS = "tauri://focus", e.WINDOW_BLUR = "tauri://blur", e.WINDOW_SCALE_FACTOR_CHANGED = "tauri://scale-change", e.WINDOW_THEME_CHANGED = "tauri://theme-changed", e.WINDOW_CREATED = "tauri://window-created", e.WINDOW_SUSPENDED = "tauri://suspended", e.WINDOW_RESUMED = "tauri://resumed", e.WEBVIEW_CREATED = "tauri://webview-created", e.DRAG_ENTER = "tauri://drag-enter", e.DRAG_OVER = "tauri://drag-over", e.DRAG_DROP = "tauri://drag-drop", e.DRAG_LEAVE = "tauri://drag-leave";
})(Ds || (Ds = {}));
async function Tn(e, t) {
  window.__TAURI_EVENT_PLUGIN_INTERNALS__.unregisterListener(e, t), await h("plugin:event|unlisten", {
    event: e,
    eventId: t
  });
}
async function Cn(e, t, i) {
  var s;
  const a = (s = void 0) !== null && s !== void 0 ? s : { kind: "Any" };
  return h("plugin:event|listen", {
    event: e,
    target: a,
    handler: Mn(t)
  }).then((c) => async () => Tn(e, c));
}
async function In(e, t) {
  await h("plugin:shell|open", {
    path: e,
    with: t
  });
}
async function Rn(e, t) {
  await h("plugin:clipboard-manager|write_text", {
    label: t == null ? void 0 : t.label,
    text: e
  });
}
async function Ks(e = {}) {
  return typeof e == "object" && Object.freeze(e), await h("plugin:dialog|open", { options: e });
}
function An(e) {
  return e === "top" ? "artist" : e;
}
const Dn = {
  album: "spotify_albums",
  artist: "spotify_artists",
  show: "spotify_shows",
  top: "spotify_top_artists"
}, Nn = 1280, Pn = 720, Bn = 550, On = 300, Zs = 180, en = 520, Hn = 4e3, jn = 450, Wn = 800, Fn = 8e3, Un = 200, Vn = 15e3, zn = 500, Gn = 500, Yn = 250, Qn = 500, Xn = 0.3, f = {
  play: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polygon points="6 4 20 12 6 20 6 4"/></svg>',
  pause: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="9" y1="4" x2="9" y2="20"/><line x1="15" y1="4" x2="15" y2="20"/></svg>',
  prev: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polygon points="19 5 9 12 19 19 19 5"/><line x1="5" y1="5" x2="5" y2="19"/></svg>',
  next: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polygon points="5 5 15 12 5 19 5 5"/><line x1="19" y1="5" x2="19" y2="19"/></svg>',
  /** 随机（关 / 随机共用这一个；「关」靠 `data-mode` 变暗区分）。 */
  shuffle: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="16 3 21 3 21 8"/><line x1="4" y1="20" x2="21" y2="3"/><polyline points="21 16 21 21 16 21"/><line x1="15" y1="15" x2="21" y2="21"/><line x1="4" y1="4" x2="9" y2="9"/></svg>',
  /** 循环（单曲循环；那个「1」由 CSS `::after` 加，SVG 里不写字）。 */
  repeat: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="17 1 21 5 17 9"/><path d="M3 11V9a4 4 0 0 1 4-4h14"/><polyline points="7 23 3 19 7 15"/><path d="M21 13v2a4 4 0 0 1-4 4H3"/></svg>',
  list: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="9" y1="6" x2="21" y2="6"/><line x1="9" y1="12" x2="21" y2="12"/><line x1="9" y1="18" x2="21" y2="18"/><circle cx="4" cy="6" r="1" fill="currentColor" stroke="none"/><circle cx="4" cy="12" r="1" fill="currentColor" stroke="none"/><circle cx="4" cy="18" r="1" fill="currentColor" stroke="none"/></svg>',
  /** 进播放界面。 */
  expand: '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 3 21 3 21 9"/><polyline points="9 21 3 21 3 15"/><line x1="21" y1="3" x2="14" y2="10"/><line x1="3" y1="21" x2="10" y2="14"/></svg>',
  /** 回默认界面。**唯一**的退出播放界面的入口 —— 播放停止不会自动退出。 */
  back: '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/><line x1="3" y1="12" x2="9" y2="12"/></svg>',
  chevron: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg>',
  copy: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15V5a2 2 0 0 1 2-2h10"/></svg>',
  link: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.5 1.5"/><path d="M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7L12 19"/></svg>',
  power: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M18.4 6.6a9 9 0 1 1-12.8 0"/><line x1="12" y1="2" x2="12" y2="12"/></svg>',
  gear: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>',
  volume: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M15.5 8.5a5 5 0 0 1 0 7"/></svg>',
  /** 工具条上的「设备」按钮（2026-09-28）。画成一台小音箱，比「显示器」更贴
   *  Spotify 那种「可选的播放设备」语义。 */
  speaker: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="2" width="14" height="20" rx="2"/><circle cx="12" cy="14" r="3.2"/><circle cx="12" cy="6" r="1" fill="currentColor" stroke="none"/></svg>',
  /** 实心心形（「我喜欢的歌曲」那块封面上的图案）。**这个是 `fill`，不是描边** ——
   *  它是一块封面图（Spotify 的收藏夹封面就是实心心 + 渐变底），不是可点按钮。 */
  heart: '<svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" stroke="none"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>',
  // ── 本地媒体库那一页用到的四个（2026-10-01）──
  /** 「本地音乐」入口 + 目录行（画成文件夹）。 */
  folder: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/></svg>',
  /** 「添加目录」。 */
  plus: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>',
  /** 移除一根目录（行尾那枚）。`music.pl-x` 用。 */
  x: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="6" y1="6" x2="18" y2="18"/><line x1="18" y1="6" x2="6" y2="18"/></svg>',
  /** 没有封面的曲目行左侧占位（一个八分音符）。 */
  note: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18V6l10-2v12"/><circle cx="6.5" cy="18" r="2.5"/><circle cx="16.5" cy="16" r="2.5"/></svg>',
  /** 「重新扫描」/「刷新」—— 画成环形箭头。 */
  refresh: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="21 3 21 9 15 9"/><path d="M20.4 14a8.5 8.5 0 1 1-1.6-7.5L21 9"/></svg>',
  /** 「测量」—— 一条起伏的响应曲线（Lucide 的 `activity` 那一族的形状）。 */
  wave: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12h3l2.5-6 3.5 12 3-8 2 2h4"/></svg>',
  /** 编辑（改列表）。**路径逐字抄自 icon-style.md §3 的「编辑 ✎」** —— 规范里已经
   *  给好这条了，不许自己另画一条（§4.2 最后一条：已有的图形不要重复造路径）。 */
  edit: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 3a2.8 2.8 0 0 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/></svg>',
  /** 删除（垃圾桶）。**同样逐字抄自 icon-style.md §3** —— 它是危险操作，
   *  按 §4.2 用同风格线性图标 + 语义色（hover 变 `--red`，见 styles.css）。 */
  trash: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6M14 11v6M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>',
  /** 停止本地播放（本地播放条右端那枚）。**它与暂停不是一回事**：暂停留着这台
   *  音频设备，停止会把设备一起放掉（见 player.rs 的 `player_stop`）。 */
  stop: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="6" y="6" width="12" height="12" rx="1.5"/></svg>',
  /** 「本地与 Spotify 同时出声」那把开关（2026-10-01）。画成**两个相交的圆** ——
   *  「两路并存」最直白的图形（Lucide 里叫 `blend`）。**不画成两个喇叭**：12px 下
   *  两个喇叭会糊成一团，而两个圆在任何尺寸下都认得出来。
   *  开关的「开着」不用第二个图形表达，靠 `.on` 的强调色（与其他开关一致）。 */
  dual: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="9" r="6.5"/><circle cx="15" cy="15" r="6.5"/></svg>',
  /** 「最常听的歌曲」那一行的图标（2026-10-01 用户第 4 条）。画成一条上扬的折线
   *  —— 「最常听 / 热度」最直白的图形（Lucide 的 `trending-up`，与上面这些同源）。
   *  与 `SVG.heart` 一样是 20px 的封面图案，但**保持描边风格**（它不是实心封面，
   *  它是「一行合成出来的入口」，与收藏夹那块渐变实心封面刻意区分开）。 */
  trend: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/></svg>'
  // （工具条上那枚「调音推子」图标 2026-10-01 随入口一起删掉了：调音改成标题栏
  //  三段切换的第三段，那枚图标就没有地方落了。图形本身仍在 icon-style.md §3 里。）
};
let r = null, m = null, X = null, Ci = "", Ii = !1, dt = [], ze = -1, Qt = null, Lt = null, Xt = !1, E = null, tt = 0, F = [], de = -1, De = 0, Ge = null, Ye = !1, Oi = null, ut = -1, xt = !1, qt = !1, Jt = 0, xi = null;
function Jn() {
  return { kind: "peaking", freq_hz: 1e3, gain_db: 0, q: 0.707, on: !0 };
}
function hi() {
  tt = (E == null ? void 0 : E.preamp_db) ?? 0, F = ((E == null ? void 0 : E.filters) ?? []).map((e) => ({ ...e }));
}
let I = "default", Ri = null, Qe = null, ce = !1, tn = "", j = null, Li = !1, it = "", fe = "", O = null, bt = !1, Et, ee = "playlist";
const yt = /* @__PURE__ */ new Map(), It = /* @__PURE__ */ new Set(), Ht = /* @__PURE__ */ new Map();
let S = null, le = null, mt = !1, Ne = "", me = !1, He = !1, we = "tracks", nt = null, Ie = !1, z = null, ue = "", qi = !1, Kt = 0;
const Kn = 2e4;
let je = !1, li = "", ui = 0, oi = !1, Rt = On, Ai = null, At = "", Q = !1, K = null, ri = !1, gt = "", ve = "", pe = !1, ke = /* @__PURE__ */ new Set(), jt = /* @__PURE__ */ new Set(), $e = !1, U = null, _t = !1, We = "", ae = null, Wt = "", te, pt = null, Dt, _ = null, Ut = 0, Pe = [], Se = -1, Xe = !1, J = -1, Nt;
const sn = "lunac-music-dual-play";
let Re = Zn();
function Zn() {
  try {
    return localStorage.getItem(sn) === "1";
  } catch {
    return !1;
  }
}
function ec(e) {
  try {
    localStorage.setItem(sn, e ? "1" : "0");
  } catch {
  }
}
const nn = "lunac-music-local-mode";
let G = tc();
function tc() {
  try {
    const e = localStorage.getItem(nn);
    return e === "shuffle" || e === "repeat_all" || e === "repeat_one" ? e : "off";
  } catch {
    return "off";
  }
}
function ic(e) {
  try {
    localStorage.setItem(nn, e);
  } catch {
  }
}
function Hi() {
  return n(G === "shuffle" ? "music.mode_shuffle" : G === "repeat_all" ? "music.mode_repeat_all" : G === "repeat_one" ? "music.mode_repeat_one" : "music.mode_off");
}
let Ae, Zt = !1, Je, Ns = !1, ei, cn = 0, an = 0, Ke = null, Ft = null, Ze = 0, wt = !1, Ve = -1, et = [], Pt = 0, xe, st, ti = "", ii = 0, Di = "";
function bi() {
  return I === "player" || I === "lplayer";
}
function l(e) {
  return e.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
function Bt(e) {
  if (!isFinite(e) || e < 0) return "0:00";
  const t = Math.floor(e / 1e3), i = Math.floor(t / 60), s = t % 60;
  return `${i}:${String(s).padStart(2, "0")}`;
}
function H(e) {
  if (!isFinite(e) || e < 0) return "00:00";
  const t = Math.floor(e / 1e3);
  return `${String(Math.floor(t / 60)).padStart(2, "0")}:${String(t % 60).padStart(2, "0")}`;
}
function R(e) {
  const t = e instanceof Error ? e.message : String(e);
  if (t.includes("ERR_NO_CLIENT_ID")) return n("music.err_no_client_id");
  if (t.includes("ERR_NOT_CONNECTED")) return n("music.err_not_connected");
  if (t.includes("ERR_NO_QUERY")) return n("music.err_no_query");
  if (t.includes("ERR_PORT_BUSY")) return n("music.err_port_busy", { port: String((r == null ? void 0 : r.port) ?? "") });
  if (t.includes("ERR_BAD_URI") || t.includes("ERR_BAD_ID")) return n("music.err_bad_uri");
  if (t.includes("ERR_SPOTIFY_STOPPED"))
    return je = !0, n("music.err_spotify_stopped");
  const i = t.match(/ERR_RATE_LIMITED:(\S*)/);
  return i ? n("music.err_rate_limited", { s: i[1] || "?" }) : t.includes("Insufficient client scope") ? n("music.err_scope") : t.includes("No active device") || t.includes("NO_ACTIVE_DEVICE") ? n("music.err_no_device") : t.includes("Premium required") || t.includes("PREMIUM_REQUIRED") ? n("music.err_premium") : t.includes("Restriction violated") ? n("music.err_restricted") : t;
}
function sc(e) {
  const t = [];
  for (const i of e.split(/\r?\n/)) {
    const s = [...i.matchAll(/\[(\d{1,3}):(\d{1,2})(?:[.:](\d{1,3}))?\]/g)];
    if (s.length === 0) continue;
    const a = i.replace(/\[[^\]]*\]/g, "").trim();
    if (a)
      for (const c of s) {
        const p = c[3] ? Number(c[3].padEnd(3, "0")) / 1e3 : 0;
        t.push({ at: Number(c[1]) * 60 + Number(c[2]) + p, text: a });
      }
  }
  return t.sort((i, s) => i.at - s.at), t;
}
function nc() {
  return `
  <div class="music-root">
    <!-- ── 默认界面：顶部工具条 + 状态行 + 连接设置 + 歌单列 / 搜索结果 ──
         工具条与「返回」按钮**分属两态**：默认态用底部栏那个「进播放界面」，
         播放态用**标题栏那个 ←**（syncTitlebarClose 把 × 换成它；歌名模块右端
         原来还有一枚「返回歌单」，2026-10-01 已按用户口径删掉）。
         ⚠️ 本段在模板字符串里，注释里一个反引号都不能出现（预检 #15 / #39 ⑩）。 -->
    <div class="music-view" id="music-v-default">
      <!-- 顶部工具条：头像 / 账号 / 搜索（**带下拉预览**）/ 状态 / 设置。
           2026-09-28 第二次改：设备按钮与「展开播放面板」都**下移到最底下那条控制栏**
           （用户要求「严格对齐 Spotify」，Spotify 的工具条上本来就没有这两样）。 -->
      <div class="music-toolbar">
        <button class="music-avatar" id="music-avatar" title="${l(n("music.account_btn"))}"></button>
        <span class="music-acc" id="music-acc"></span>
        <div class="music-search-wrap">
          <input class="music-search" id="music-search" type="search" autocomplete="off" spellcheck="false" placeholder="${l(n("music.search_ph"))}">
          <!-- 下拉预览：绝对定位挂在工具条下方（**不占布局**，否则窗口高会跟着抖） -->
          <div class="music-dd hidden" id="music-search-dd"></div>
        </div>
        <span class="music-status" id="music-status">${n("music.loading")}</span>
        <!-- 「恢复」按钮（2026-10-02）：**只在 429 硬闸拉着时显示**（见 renderResumeBtn）。
             它是用户唯一的出口 —— 宿主一旦收到 429 就停掉所有 Spotify 请求、且不自动重试。
             放工具条而不是底部提示行：提示行在播放态是绝对定位 + pointer-events:none，点不到。
             ⚠️ 本段是 JS 模板字符串，注释里不能出现反引号（预检 #15 / #39 ⑩）。 -->
        <button class="music-ghost-btn hidden" id="music-resume">${n("music.resume")}</button>
        <!-- 这里原来的「本地音乐」文件夹按钮与「调音」推子按钮**已删除**（2026-10-01
             用户口径）：这两个入口收进了**标题栏那枚三段切换**（在线歌单 / 本地音乐 /
             调音，见 renderTitlebarSwitch）。标题栏是悬浮窗独有的，插件若被嵌在主窗口里
             就没有那一条 —— 那种情况下切换器会退到本工具条里（见 placeSwitcher），
             所以这里不给它们留第二份入口，否则「删掉」就变成了「多一份」。
             ⚠️ 本段是 JS 模板字符串，注释里不能出现反引号（预检 #15 / #39 ⑩）。 -->
        <button class="music-ghost-btn music-icon-btn" id="music-setup-toggle" title="${l(n("music.settings"))}">${f.gear}</button>
      </div>

      <div class="music-setup hidden" id="music-setup">
        <div class="music-hint" id="music-setup-hint">${n("music.setup_hint")}</div>
        <!-- 凭据字段默认只在「没有内置 Client ID」或用户主动展开时显示：
             内置值让「登录」变成一步操作，Redirect URI 那一串对普通用户是噪音。 -->
        <button class="music-ghost-btn music-fields-toggle hidden" id="music-fields-toggle"></button>
        <div id="music-setup-fields">
          <div class="music-field">
            <label for="music-client-id">${n("music.client_id")}</label>
            <input id="music-client-id" type="text" spellcheck="false" autocomplete="off" placeholder="${l(n("music.client_id_ph"))}">
          </div>
          <div class="music-field music-field-port">
            <label for="music-port">${n("music.port")}</label>
            <input id="music-port" type="text" inputmode="numeric" autocomplete="off">
          </div>
          <div class="music-field">
            <label>${n("music.redirect")}</label>
            <div class="music-redirect-row">
              <code id="music-redirect"></code>
              <button class="music-ghost-btn music-icon-btn" id="music-copy-redirect" title="${l(n("music.copy"))}">${f.copy}</button>
            </div>
          </div>
          <!-- 本机播放（librespot）的两项设置：路径留空 = 自动探测；代理留空 = 直连。
               两者都不是「必填」，所以各带一行小字说明（见 renderSetup）。 -->
          <div class="music-field">
            <label for="music-librespot">${n("music.local_play")}</label>
            <input id="music-librespot" type="text" spellcheck="false" autocomplete="off" placeholder="librespot.exe">
          </div>
          <div class="music-field">
            <label for="music-librespot-proxy">proxy</label>
            <input id="music-librespot-proxy" type="text" spellcheck="false" autocomplete="off" placeholder="${l(n("music.librespot_proxy_ph"))}">
          </div>
        </div>
        <div class="music-actions">
          <button class="music-btn" id="music-save">${n("music.save")}</button>
          <button class="music-btn music-primary" id="music-connect">${f.link} ${n("music.connect")}</button>
          <button class="music-btn" id="music-disconnect">${f.power} ${n("music.disconnect")}</button>
        </div>
      </div>

      <!-- 主体：**左栏（宽度可拖）+ 分隔条 + 主区**（用户 2026-09-28 的
           「歌单列作为单独的一列可拉动」「中间大的大部分区域作为歌曲列表」）。
           两栏各自内部滚动 —— 窗口是定尺 1280×720，不是靠内容撑出来的。 -->
      <div class="music-body hidden" id="music-body">
        <aside class="music-side" id="music-side">
          <div class="music-side-tabs" id="music-side-tabs">
            <button class="music-tab on" data-act="side-tab" data-tab="playlist">${n("music.playlists")}</button>
            <button class="music-tab" data-act="side-tab" data-tab="album">${n("music.tab_albums")}</button>
            <button class="music-tab" data-act="side-tab" data-tab="artist">${n("music.tab_artists")}</button>
            <button class="music-tab" data-act="side-tab" data-tab="show">${n("music.tab_shows")}</button>
            <!-- 「最常听」栏（2026-10-01 用户第 4 条）。**放在最后**：那四栏是「我的库」，
                 这一栏是「库外的东西」，顺序上按这个分组走。
                 原先与它并列的「新发行」2026-10-02 删除（端点永久 403）。
                 注：本段在模板字符串里，注释里不能出现反引号（预检 #15 / #39 ⑩）。 -->
            <button class="music-tab" data-act="side-tab" data-tab="top">${n("music.tab_top")}</button>
          </div>
          <!-- 「本地音乐」那一页的左栏头（与上面那排 Spotify 页签**互斥显示**）：
               一个标题 + 一个「添加目录」。它跟着 localPage 切，见 renderLocalSide。 -->
          <div class="music-local-head hidden" id="music-local-head">
            <span class="music-local-title">${n("music.local_library")}</span>
            <div class="music-local-head-btns">
              <!-- 正常态三枚（2026-10-01 用户口径）：
                   ＋ = 添加（**目录或播放列表文件**，两个入口合一）
                   ✎ = 修改列表（进编辑态）—— 取代原来那枚「打开播放列表文件」
                   ⟳ = 重扫。
                   图标一律取自 icon-style.md §3，不自己画（见 SVG.edit / SVG.trash）。 -->
              <button class="music-ghost-btn music-icon-btn" id="music-local-add" title="${l(n("music.local_add"))}">${f.plus}</button>
              <button class="music-ghost-btn music-icon-btn" id="music-local-list" title="${l(n("music.local_edit"))}">${f.edit}</button>
              <button class="music-ghost-btn music-icon-btn" id="music-local-scan" title="${l(n("music.local_rescan"))}">${f.refresh}</button>
              <!-- 编辑态两枚（正常态隐藏，切法见 renderLocalHead）：
                   🗑 = 把勾选的行**摘出列表**（暂存，还能反悔）
                   × = 退出并保存（到这一步才真落盘） -->
              <button class="music-ghost-btn music-icon-btn hidden" id="music-local-del" title="${l(n("music.local_del_sel"))}">${f.trash}</button>
              <button class="music-ghost-btn music-icon-btn hidden" id="music-local-editdone" title="${l(n("music.local_edit_done"))}">${f.x}</button>
              <!-- 那个「＋」的二选一浮层（目录 / 播放列表文件）。画法见 renderLocalAddMenu，
                   定位参照是上面那排按钮（.music-local-head-btns 是 relative）。
                   注：本段在**模板字符串**里，注释里一个反引号都不能出现（预检 #15 / #39 ⑩）。 -->
              <div class="music-dd music-local-add-dd hidden" id="music-local-add-dd"></div>
            </div>
          </div>
          <div class="music-side-list" id="music-side-list"></div>
        </aside>
        <div class="music-split" id="music-split" role="separator" aria-orientation="vertical"></div>
        <main class="music-main" id="music-main"></main>
      </div>

      <!-- ── 底部控制栏（2026-09-28，Spotify 复刻）─────────────────────────
           用户要求「在默认面板下方添加 Spotify 那样的播放控制，并把一些按钮也
           移动到下方控制」。三列 grid：左 = 正在播放（点它 = 打开播放面板）、
           中 = 播放键组、右 = 设备 / 音量 / 队列 / 展开。
           栏顶那条 2px 细进度线**绝对定位**（不占高），拖动即可跳转。
           **两个弹层都挂在右端那一簇里、向上弹**：这条栏贴着窗口下沿，
           向下弹会跑到窗口外面（见 styles.css 里那两条覆盖 top 的规则）。
           注意本段是 JS 模板字符串 —— 注释里不能出现反引号（会把字符串截断）。 -->
      <div class="music-nowbar hidden" id="music-nowbar">
        <div class="music-bp music-bp-timed" id="music-bp" title="${l(n("music.seek"))}">
          <div class="music-bp-fill" id="music-bp-fill"></div>
          <div class="music-progress-tip" id="music-bp-tip">0:00</div>
          <span class="music-btime" id="music-b-time">00:00 / 00:00</span>
        </div>
        <button class="music-bnow" id="music-bnow" title="${l(n("music.open_player"))}">
          <span class="music-bnow-cover" id="music-bnow-cover"></span>
          <span class="music-bnow-main">
            <span class="music-bnow-n" id="music-bnow-n"></span>
            <span class="music-bnow-a" id="music-bnow-a"></span>
          </span>
        </button>
        <div class="music-bctl">
          <button class="music-round-btn music-mode-btn" id="music-b-mode" data-mode="off"></button>
          <button class="music-round-btn" id="music-b-prev" title="${l(n("music.prev"))}">${f.prev}</button>
          <button class="music-round-btn music-play-btn" id="music-b-play" title="${l(n("music.play_pause"))}">${f.play}</button>
          <button class="music-round-btn" id="music-b-next" title="${l(n("music.next"))}">${f.next}</button>
        </div>
        <div class="music-bend">
          <!-- 与本地播放条上那一枚是**同一个状态**（见 dualPlay 的注释）。
               两枚按钮各自长在自己的控制区里，用户在哪条栏上都够得着。 -->
          <button class="music-ghost-btn music-icon-btn music-dual-btn" id="music-dual-btn" title="${l(n("music.dual_play"))}">${f.dual}</button>
          <button class="music-ghost-btn music-icon-btn" id="music-devices-btn" title="${l(n("music.devices"))}">${f.speaker}</button>
          <span class="music-vol-ico">${f.volume}</span>
          <input class="music-vol" id="music-b-vol" type="range" min="0" max="100" step="1" value="50" style="--vol-pct:50%" title="${l(n("music.volume"))}">
          <button class="music-round-btn" id="music-b-queue" title="${l(n("music.queue"))}">${f.list}</button>
          <button class="music-ghost-btn music-icon-btn hidden" id="music-open-player" title="${l(n("music.open_player"))}">${f.expand}</button>
          <div class="music-dd music-dev-dd hidden" id="music-dev-dd"></div>
          <div class="music-dd hidden" id="music-q-dd"></div>
        </div>
      </div>

      <!-- ── 本地文件播放条（2026-10-01）───────────────────────────────
           与上面那条 Spotify 控制栏**不是一条**：那条的对象是远端播放器
           （Web API 的 spotify_* 命令），这条的对象是宿主里那条本机音频流
           （player.rs 的 player_* 命令）。两者的数据源、可用条件（这条不要求
           登录 Spotify）、能做的事都不一样 —— 合成一条会到处长出
           「如果是本地就…」的分支，那正是两套东西被缝在一起的样子。
           只在「本地页 + 有本地会话」时出现，见 renderLocalNowbar。
           注意本段是 JS 模板字符串 —— 注释里不能出现反引号。 -->
      <div class="music-nowbar music-lnowbar hidden" id="music-lnowbar">
        <div class="music-bp" id="music-lbp" title="${l(n("music.seek"))}">
          <div class="music-bp-fill" id="music-lbp-fill"></div>
          <div class="music-progress-tip" id="music-lbp-tip">0:00</div>
        </div>
        <div class="music-bnow music-lnow">
          <span class="music-bnow-cover" id="music-lnow-cover"></span>
          <span class="music-bnow-main">
            <span class="music-bnow-n" id="music-lnow-n"></span>
            <span class="music-bnow-a" id="music-lnow-a"></span>
          </span>
        </div>
        <div class="music-bctl">
          <!-- 播放模式（关 / 随机 / 循环列表 / 单曲循环，2026-10-01 用户第 8 条）。
               与 Spotify 那枚 #music-b-mode **不是一件事**：那枚是远端真相，
               这枚是前端自己算的（见 localMode 的注释），所以两枚各记各的状态。
               注：本段在模板字符串里，注释里不能出现反引号（预检 #15 / #39 ⑩）。 -->
          <button class="music-round-btn music-mode-btn" id="music-l-mode" data-mode="off" title="${l(n("music.mode_off"))}"></button>
          <button class="music-round-btn" id="music-l-prev" title="${l(n("music.prev"))}">${f.prev}</button>
          <button class="music-round-btn music-play-btn" id="music-l-play" title="${l(n("music.play_pause"))}">${f.play}</button>
          <button class="music-round-btn" id="music-l-next" title="${l(n("music.next"))}">${f.next}</button>
          <button class="music-round-btn" id="music-l-stop" title="${l(n("music.local_stop"))}">${f.stop}</button>
        </div>
        <div class="music-bend">
          <button class="music-ghost-btn music-icon-btn music-dual-btn" id="music-l-dual-btn" title="${l(n("music.dual_play"))}">${f.dual}</button>
          <span class="music-ltime" id="music-l-time">0:00 / 0:00</span>
          <span class="music-vol-ico">${f.volume}</span>
          <input class="music-vol" id="music-l-vol" type="range" min="0" max="100" step="1" value="80" style="--vol-pct:80%" title="${l(n("music.volume"))}">
          <!-- 小窗入口（2026-10-01 用户口径：本地播放也要有）。与 Spotify 那条栏
               右端那枚 #music-open-player 同形同义 —— 只是它带去的是**本地**那条
               长条（#music-v-lplayer），由 mode = "lplayer" 切。 -->
          <button class="music-ghost-btn music-icon-btn" id="music-l-open-player" title="${l(n("music.open_player"))}">${f.expand}</button>
        </div>
      </div>
    </div>

    <!-- ── 播放界面：**550×130 的长条**（封面 100 + 右侧列 450）──────────
         右侧列三块的高度加起来正好是长条高：歌名 30 + 歌词 65 + 控制 35 = 130。
         **这几个数都是用户 2026-09-27 给的定尺**：改任何一个都要同步
         styles.css 的 .music-name / .music-lyr / .music-bar，以及宿主
         plugin_window.rs 的 MUSIC_W（见 ai-spec §4.6 与预检 #39 ④）。 -->
    <!-- 注意：本段是 JS 模板字符串，**注释里不能出现反引号**（会把字符串截断）。 -->
    <div class="music-view music-player hidden" id="music-v-player">
      <div class="music-pv-card">
        <div class="music-pv-cover" id="music-pv-cover"></div>
        <div class="music-pv-col">
          <!-- 歌名模块 H30：歌名（亮）+ 歌手·专辑（暗）。 -->
          <div class="music-name">
            <div class="music-name-text">
              <span class="music-title" id="music-pv-title"></span>
              <span class="music-sub" id="music-pv-sub"></span>
            </div>
            <!-- 「返回歌单」那枚**已删除**（2026-10-01 用户口径：小窗播放里那个不是
                 状态栏里的返回按钮要去掉）。退出去仍然走**标题栏那个 ←** ——
                 它在播放态由 syncTitlebarClose 把 × 换成 ←，语义是「停播 + 回默认面板」
                 （见 stopAndBack），也是用户当初指定的出口。所以这里删掉不留缺口。 -->
          </div>

          <!-- 歌词模块 H65：正好两行可见（行高 32）。已过 + 正在 = 亮，未到 = 暗；
               点某一行 = 跳到那一句的进度。 -->
          <div class="music-lyr" id="music-lyr"></div>

          <!-- 控制面板 H35：进度条**叠在本块顶部**（绝对定位 ⇒ 不占高度，总高仍是 130），
               四个播放键在块内居中，右端音量条 80px + 播放列表按钮。 -->
          <div class="music-bar">
            <!-- 时间在控制块**最左端、进度条下方**（用户 2026-09-27 定）。
                 绝对定位 ⇒ 不参与四钮的居中计算。 -->
            <div class="music-time">
              <span id="music-pv-pos">0:00</span><span class="music-time-sep">/</span><span id="music-pv-dur">0:00</span>
            </div>
            <div class="music-progress" id="music-pv-progress" title="${l(n("music.seek"))}">
              <div class="music-progress-fill" id="music-pv-fill"></div>
              <div class="music-progress-dot" id="music-pv-dot"></div>
              <div class="music-progress-tip" id="music-pv-tip">0:00</div>
            </div>
            <div class="music-bar-main">
              <button class="music-round-btn music-mode-btn" id="music-mode" data-mode="off"></button>
              <button class="music-round-btn" id="music-prev" title="${l(n("music.prev"))}">${f.prev}</button>
              <button class="music-round-btn music-play-btn" id="music-play" title="${l(n("music.play_pause"))}">${f.play}</button>
              <button class="music-round-btn" id="music-next" title="${l(n("music.next"))}">${f.next}</button>
            </div>
            <div class="music-bar-end">
              <span class="music-vol-ico">${f.volume}</span>
              <input class="music-vol" id="music-vol" type="range" min="0" max="100" step="1" value="50" style="--vol-pct:50%" title="${l(n("music.volume"))}">
              <button class="music-round-btn" id="music-queue-btn" title="${l(n("music.queue"))}">${f.list}</button>
            </div>
          </div>
        </div>
      </div>

      <!-- 播放列表（队列）挂在长条**下方**、不再与歌词互斥：长条是定尺 130，
           塞不进队列。开着时窗口按内容长高（applyResize 实测贴合）。 -->
      <div class="music-q-wrap hidden" id="music-q-wrap">
        <div class="music-sec-head">
          <span class="music-sec-title">${n("music.queue")}</span>
          <span class="music-sec-note">${n("music.queue_hint")}</span>
        </div>
        <div class="music-q" id="music-q"></div>
      </div>
    </div>

    <!-- ── 本地小窗：**本地文件播放也有的那条长条**（2026-10-01 用户口径
         「在本地文件播放的情况下也添加小窗模式」）────────────────────────
         与上一个视图**共用同一套外壳类**（music-player / music-pv-card / music-pv-cover /
         music-name / music-bar / music-bp…）⇒ 尺寸（550×130）、圆角、配色、
         进度条的细线与命中区，一行业务 CSS 都不用重写。
         唯一的差别在**中间那一块**：远端那条长条放的是歌词（H65，见 .music-lyr），
         本地文件没有歌词 —— 那一格换成**大号进度线 + 时间**（见 .music-lp-mid）。
         三块的高度仍是 30 + 65 + 35 = 130，与 MUSIC_W_BAR / applyResize 对齐。
         数据与动作**都只有一份**：状态来自 localPlayer，按钮走的是本地播放那几条
         既有函数（见 attachMusicListeners 里那几条绑定）。
         注意本段是 JS 模板字符串 —— 注释里不能出现反引号（预检 #15 / #39 ⑩）。 -->
    <div class="music-view music-player hidden" id="music-v-lplayer">
      <div class="music-pv-card">
        <div class="music-pv-cover" id="music-lp-cover"></div>
        <div class="music-pv-col">
          <div class="music-name">
            <div class="music-name-text">
              <span class="music-title" id="music-lp-title"></span>
              <span class="music-sub" id="music-lp-sub"></span>
            </div>
          </div>
          <div class="music-lp-mid">
            <div class="music-bp music-lp-seek" id="music-lp-progress" title="${l(n("music.seek"))}">
              <div class="music-bp-fill" id="music-lp-fill"></div>
              <div class="music-progress-tip" id="music-lp-tip">0:00</div>
            </div>
            <div class="music-lp-time" id="music-lp-time">0:00 / 0:00</div>
          </div>
          <div class="music-bar">
            <div class="music-bar-main">
              <button class="music-round-btn music-mode-btn" id="music-lp-mode" data-mode="off" title="${l(n("music.mode_off"))}"></button>
              <button class="music-round-btn" id="music-lp-prev" title="${l(n("music.prev"))}">${f.prev}</button>
              <button class="music-round-btn music-play-btn" id="music-lp-play" title="${l(n("music.play_pause"))}">${f.play}</button>
              <button class="music-round-btn" id="music-lp-next" title="${l(n("music.next"))}">${f.next}</button>
              <button class="music-round-btn" id="music-lp-stop" title="${l(n("music.local_stop"))}">${f.stop}</button>
            </div>
            <div class="music-bar-end">
              <span class="music-vol-ico">${f.volume}</span>
              <input class="music-vol" id="music-lp-vol" type="range" min="0" max="100" step="1" value="80" style="--vol-pct:80%" title="${l(n("music.volume"))}">
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- ── 设置页：**整屏**（2026-10-01 用户要求「设置图标进到一个新的设置页面」）──
         与 #music-v-player 同为整屏视图，由 mode = "settings" 切（见 renderMode）。
         职责划分是硬的：**这里只放「偏好」，「连接」仍归头像点开的 #music-setup**
         （Client ID / 端口 / 回调 / librespot 路径与代理），**「调音」也有自己的一页**
         （#music-v-tuning，2026-10-01 用户要求搬出去的）。理由与那张卡片里的
         「保存」按钮直接相关 —— 一个卡片里塞两套保存语义必然出岔子，而现在这几页
         各有各的保存。
         ⚠️ 本段是 JS 模板字符串 —— 注释里**不许出现反引号**，连「引用一个标识符」
         那种写法都不行：它会把模板字符串提前截断（预检 #15 / #39 ⑩，本轮又踩了一次）。 -->
    <div class="music-view music-setview hidden" id="music-v-settings">
      <div class="music-set-head">
        <button class="music-ghost-btn music-icon-btn" id="music-set-back" title="${l(n("music.settings_back"))}">${f.back}</button>
        <span class="music-set-title">${n("music.settings")}</span>
      </div>
      <div class="music-set-body">
        <!-- 串流质量：三档互斥按钮。**不用原生 select 元素** —— WebView2 透明窗口里
             它不渲染弹出层（code-rules §5.2）。三档值只允许 96/160/320（宿主侧
             LIBRESPOT_BITRATES，抄自 librespot --help 的原文）。
             ⚠️ 模板字符串 ⇒ 本段注释里也不许出现反引号（预检 #39 ⑩）。 -->
        <div class="music-field">
          <label>${n("music.quality")}</label>
          <div class="music-seg" id="music-quality">
            ${[96, 160, 320].map((e) => `<button type="button" class="music-seg-btn" data-q="${e}">${e}k</button>`).join("")}
          </div>
          <div class="music-hint">${l(n("music.quality_hint"))}</div>
          <div class="music-hint">${l(n("music.quality_local_note"))}</div>
        </div>
        <div class="music-actions">
          <button class="music-btn" id="music-set-save">${n("music.save")}</button>
        </div>
      </div>
    </div>

    <!-- ── 调音页：**自己一页**（2026-10-01 用户口径）────────────────────
         用户明确「调音插件的界面不能放置到设置界面里，要新建一个界面专门用来显示调音」
         —— 所以它在 2026-10-01 从设置页那一块**整段搬过来**（上一版是「调音分区」）。
         入口只有一个：标题栏那枚三段切换的第三段（见 renderTitlebarSwitch）——
         **页内那枚返回按钮 2026-10-02 按用户要求取掉了**：切换器本身就是「回得去」的
         那一条路（点回「在线歌单 / 本地音乐」即离页），再摆一个返回是重复入口。
         版面顺序（2026-10-02 用户要求）：总开关 → **频响曲线** → 测量按钮 →
         **预设**（放在曲线**下方**，紧挨着它）→ 预增益 → 滤波器表 → 说明。
         五条纪律：① 控件**按下就生效、也当场落盘**（与设置页「音质」那两条攒着
         等保存完全不同：音质要重启 librespot 才生效，调音是实时的）；
         ② 预设按钮的**键来自宿主**（tuning.presets）、滤波器类型的**名单也来自宿主**
         （tuning.kinds，与引擎 Kind::ALL 同源）—— 前端不维护第二份名单；
         ③ 只对**本地文件播放**生效（Spotify 那条流在本机之外，宿主碰不到）；
         ④ 表格行里的控件**全部动态渲染**（见 renderTuningFilters），这里只留容器；
         ⑤ 总开关是**切换按钮**（role="switch" + aria-checked），不是两个互斥按钮 ——
         「开 / 关」本来是二元状态，两个按钮把它摆成了「二选一」，反倒要多想一步。
         ⚠️ 本段是 JS 模板字符串 ⇒ 注释里不许出现反引号（预检 #15 / #39 ⑩）。 -->
    <div class="music-view music-setview hidden" id="music-v-tuning">
      <div class="music-set-head">
        <span class="music-set-title">${n("music.tuning")}</span>
      </div>
      <div class="music-set-body">
        <div class="music-field">
          <label>${n("music.tuning")}</label>
          <button type="button" class="music-switch" id="music-tuning-on" role="switch" aria-checked="false" title="${l(n("music.tuning"))}">
            <span class="music-switch-knob"></span>
          </button>
          <div class="music-hint">${l(n("music.tuning_hint"))}</div>
        </div>
        <div class="music-tune-plot">
          <canvas id="music-tune-canvas" width="640" height="170"></canvas>
          <div class="music-hint" id="music-tune-rate"></div>
        </div>
        <div class="music-tune-probe">
          <button type="button" class="music-btn" id="music-tune-measure">${f.wave}${n("music.tuning_measure")}</button>
          <div class="music-hint" id="music-tune-probe-hint">${l(n("music.tuning_probe_hint"))}</div>
        </div>
        <div class="music-field">
          <label>${n("music.tuning_presets")}</label>
          <div class="music-seg music-seg-wrap" id="music-tuning-preset"></div>
          <div class="music-hint hidden" id="music-tuning-custom-hint">${l(n("music.tuning_custom"))}</div>
        </div>
        <div class="music-field music-field-narrow">
          <label>${n("music.tuning_preamp")}</label>
          <input type="text" id="music-tune-preamp" inputmode="decimal" autocomplete="off" spellcheck="false" />
        </div>
        <div class="music-field">
          <label>${n("music.tuning_filters")}</label>
          <div class="music-tune-filters" id="music-tuning-filters"></div>
          <div class="music-actions">
            <button type="button" class="music-btn" id="music-tune-add">${f.plus}${n("music.tuning_add")}</button>
          </div>
        </div>
        <div class="music-hint">${l(n("music.tuning_note"))}</div>
      </div>
    </div>

    <div class="music-msg" id="music-msg"></div>
  </div>`;
}
function $(e, t) {
  e && e.textContent !== t && (e.textContent = t);
}
function M(e, t) {
  e && e.innerHTML !== t && (e.innerHTML = t);
}
function C(e, t) {
  e == null || e.classList.toggle("hidden", !t);
}
function he(e, t, i) {
  e && e.getAttribute(t) !== i && e.setAttribute(t, i);
}
function ft(e, t) {
  if (!e) return;
  const i = Math.max(0, Math.min(100, Math.round(t)));
  e.style.setProperty("--vol-pct", `${i}%`);
}
function cc(e) {
  const t = e.querySelector("#music-msg");
  if (!t) return;
  const i = t.textContent ?? "";
  if (i !== ti) {
    ti = i, ii = Date.now();
    return;
  }
  i && Date.now() - ii >= Fn && (t.textContent = "", ti = "", ii = 0);
}
function Z(e) {
  const t = bi();
  C(e.querySelector("#music-v-default"), I === "default"), C(e.querySelector("#music-v-player"), I === "player"), C(e.querySelector("#music-v-lplayer"), I === "lplayer"), C(e.querySelector("#music-v-settings"), I === "settings");
  const i = I === "tuning";
  C(e.querySelector("#music-v-tuning"), i), i && yi(e), e.classList.toggle("music-player-on", t), ac(t), lc(), ji(e), dc(), I === "player" ? (ze = -1, fi(e), wi(e)) : I === "lplayer" ? fn(e) : I === "default" && (C(e.querySelector("#music-body"), !!(r != null && r.connected) || Q), ct(e), oe(e), Le(e), $t(e)), Ot(e);
}
function ac(e) {
  const t = !e;
  document.getElementById("plugin-titlebar") && Ai !== t && (Ai = t, h("plugin_window_set_resizable", { resizable: t }).catch(() => {
  }));
}
function lc() {
  const e = document.getElementById("plugin-close");
  if (!e) return;
  At || (At = e.innerHTML);
  const t = bi() ? "back" : "close";
  if (e.dataset.mode === t) return;
  e.dataset.mode = t, e.innerHTML = t === "back" ? f.back : At;
  const i = t === "back" ? n("music.back") : "Close";
  e.title = i, e.setAttribute("aria-label", i);
}
function uc() {
  const e = document.getElementById("plugin-close");
  !e || !At || e.dataset.mode !== "back" || (e.innerHTML = At, e.title = "Close", e.setAttribute("aria-label", "Close"), e.dataset.mode = "close");
}
function oc() {
  return I === "tuning" ? "tuning" : I !== "default" ? "" : Q ? "local" : "online";
}
function rc(e) {
  const t = document.getElementById("music-tb-switch");
  if (t) return t;
  const i = document.createElement("div");
  i.id = "music-tb-switch", i.className = "music-tb-switch", i.setAttribute("role", "tablist"), i.setAttribute("data-tauri-drag-region", "");
  const s = [
    ["online", n("music.tb_online")],
    ["local", n("music.tb_local")],
    ["tuning", n("music.tb_tuning")]
  ];
  i.innerHTML = s.map(([p, g]) => `<button type="button" class="music-tb-seg" role="tab" data-seg="${p}" title="${l(g)}">${l(g)}</button>`).join("");
  const a = document.getElementById("plugin-titlebar"), c = document.getElementById("plugin-title");
  if (a && c)
    a.insertBefore(i, c.nextSibling);
  else {
    const p = e.querySelector("#music-setup-toggle"), g = e.querySelector(".music-toolbar");
    if (!g) return null;
    g.insertBefore(i, p);
  }
  return i;
}
function dc() {
  const e = document.getElementById("music-tb-switch");
  if (!e) return;
  const t = oc();
  for (const i of e.querySelectorAll(".music-tb-seg"))
    he(i, "aria-pressed", String(i.dataset.seg === t));
}
function mc() {
  var e;
  (e = document.getElementById("music-tb-switch")) == null || e.remove();
}
async function pc(e) {
  try {
    await h("spotify_control", { action: "pause" });
  } catch (t) {
    L(e, R(t));
  }
  I = "default", Z(e);
}
function ln(e) {
  const t = e.querySelector("#music-setup-toggle"), i = e.querySelector(".music-toolbar");
  if (!t || !i) return;
  const s = e.querySelector(".music-local-head-row"), a = Q && s ? s : i;
  t.parentElement !== a && a.appendChild(t);
}
function ji(e) {
  const t = I === "player";
  C(e.querySelector("#music-open-player"), !t && !!(m != null && m.track)), C(e.querySelector("#music-nowbar"), !t && !!(r != null && r.connected) && !Q);
  for (const i of [".music-search-wrap", "#music-avatar", "#music-acc", "#music-status"])
    C(e.querySelector(i), !Q);
  ln(e), e.querySelectorAll(".music-dual-btn").forEach((i) => i.classList.toggle("on", Re));
}
function rt(e, t) {
  const i = e.querySelector("#music-status");
  r != null && r.client_id ? r.connected ? m ? m.active ? m.playing ? $(i, n("music.status_playing")) : $(i, n("music.status_paused")) : $(i, n("music.status_no_device")) : $(i, n("music.status_connecting")) : $(i, n("music.status_disconnected")) : $(i, n("music.status_unconfigured"));
  const s = e.querySelector("#music-avatar");
  if (s) {
    const c = r != null && r.connected && r.avatar || "";
    M(s, c ? `<img src="${l(c)}" alt="">` : "");
  }
  $(e.querySelector("#music-acc"), r != null && r.connected && r.display_name || "");
  const a = e.querySelector("#music-devices-btn");
  a && (he(a, "title", `${n("music.devices")}：${(m == null ? void 0 : m.device) || n("music.device_none")}`), a.classList.toggle("warn", !!(r != null && r.connected) && !(m != null && m.active)));
}
function ot(e) {
  C(e.querySelector("#music-setup"), !(r != null && r.connected) || Xt), C(e.querySelector("#music-body"), !!(r != null && r.connected) || Q), ct(e), oe(e), r != null && r.connected && (_n(e, ee), $n(e));
  const t = Qt ?? !(r != null && r.builtin);
  C(e.querySelector("#music-setup-fields"), t), C(e.querySelector("#music-save"), t);
  const i = e.querySelector("#music-fields-toggle");
  C(i, !!(r != null && r.builtin)), $(i, n(t ? "music.hide_fields" : "music.use_own_client_id")), $(
    e.querySelector("#music-setup-hint"),
    r != null && r.builtin ? n("music.setup_builtin") : n("music.setup_hint")
  );
  const s = e.querySelector("#music-client-id"), a = e.querySelector("#music-port"), c = e.querySelector("#music-librespot"), p = e.querySelector("#music-librespot-proxy");
  s && document.activeElement !== s && (s.value = (r == null ? void 0 : r.client_id) ?? ""), a && document.activeElement !== a && (a.value = String((r == null ? void 0 : r.port) ?? 8899)), c && document.activeElement !== c && (c.value = (r == null ? void 0 : r.librespot_path) ?? ""), p && document.activeElement !== p && (p.value = (r == null ? void 0 : r.librespot_proxy) ?? "");
  const g = Lt ?? (r == null ? void 0 : r.librespot_bitrate) ?? 320;
  for (const k of e.querySelectorAll("#music-quality .music-seg-btn"))
    he(k, "aria-pressed", String(Number(k.dataset.q) === g));
  $(e.querySelector("#music-redirect"), (r == null ? void 0 : r.redirect_uri) ?? "");
}
function fc(e) {
  const t = n(`music.tuning_p_${e}`);
  return t.startsWith("music.") ? e : t;
}
function Ps(e) {
  const t = n(`music.tk_${e}`);
  return t.startsWith("music.") ? e : t;
}
function Bs(e) {
  return Number.isFinite(e) ? Math.min(2e4, Math.max(20, e)) : 1e3;
}
function Os(e) {
  return Number.isFinite(e) ? Math.min(24, Math.max(-24, e)) : 0;
}
function ie(e, t = 3) {
  return e === void 0 || !Number.isFinite(e) ? "" : String(Math.round(e * 10 ** t) / 10 ** t);
}
function Ei(e, t) {
  return t === "freq_hz" ? ie(e.freq_hz, 1) : t === "gain_db" ? ie(e.gain_db ?? 0, 1) : t === "q" ? ie(e.q ?? 0.707, 3) : "";
}
async function yi(e) {
  let t;
  try {
    t = await h("player_tuning_get");
  } catch (i) {
    L(e, R(i));
    return;
  }
  JSON.stringify(t) !== JSON.stringify(E) && (E = t, hi(), de = -1), Vt(e);
}
function un(e) {
  const t = e.querySelector("#music-tune-measure");
  t && t.disabled !== Ye && (t.disabled = Ye), he(t, "aria-busy", String(Ye));
  const i = e.querySelector("#music-tune-probe-hint");
  if (!i) return;
  if (Ye) {
    $(i, n("music.tuning_measuring"));
    return;
  }
  const s = Ge;
  if (!s) {
    $(i, n("music.tuning_probe_hint"));
    return;
  }
  let a = 0, c = 0;
  for (let g = 0; g < s.db.length && g < s.ref_db.length; g++)
    a += s.db[g] - s.ref_db[g], c += 1;
  const p = c > 0 ? a / c : 0;
  $(
    i,
    n("music.tuning_probe_result", {
      cov: String(Math.round(s.coverage * 100)),
      dev: `${p >= 0 ? "+" : ""}${p.toFixed(1)}`,
      ms: String(s.elapsed_ms)
    })
  );
}
function Vt(e) {
  if (!E) return;
  he(e.querySelector("#music-tuning-on"), "aria-checked", String(E.enabled)), un(e);
  const t = e.querySelector("#music-tuning-preset");
  t && M(
    t,
    E.presets.map((s) => {
      const a = E.preset === s;
      return `<button type="button" class="music-seg-btn" data-preset="${l(s)}" aria-pressed="${a}">${l(fc(s))}</button>`;
    }).join("")
  ), C(e.querySelector("#music-tuning-custom-hint"), E.preset === "custom");
  const i = e.querySelector("#music-tune-preamp");
  i && document.activeElement !== i && i.value !== ie(tt, 1) && (i.value = ie(tt, 1)), on(e), si(e), $(
    e.querySelector("#music-tune-rate"),
    n("music.tuning_rate", { rate: ie(E.response.sample_rate / 1e3, 1) })
  );
}
function vc(e, t, i, s) {
  const a = i.find((N) => N.name === e.kind), c = a ? a.gain : e.gain_db !== void 0, p = a ? a.order !== 1 : e.q !== void 0, g = c ? `<input type="text" class="music-tune-num" data-f="gain_db" inputmode="decimal" autocomplete="off" spellcheck="false" value="${l(ie(e.gain_db ?? 0, 1))}" placeholder="${l(n("music.tuning_gain"))}" aria-label="${l(n("music.tuning_gain"))}" />` : "", k = p ? `<input type="text" class="music-tune-num" data-f="q" inputmode="decimal" autocomplete="off" spellcheck="false" value="${l(ie(e.q ?? 0.707, 3))}" placeholder="${l(n("music.tuning_q"))}" aria-label="${l(n("music.tuning_q"))}" />` : "", D = s ? `<div class="music-tune-menu">${i.map(
    (N) => `<button type="button" class="music-seg-btn" data-act="pick" data-kind="${l(N.name)}" aria-pressed="${N.name === e.kind}">${l(Ps(N.name))}</button>`
  ).join("")}</div>` : "", x = e.gain_db ?? 0, se = e.q ?? 0.707, T = (N, at, Me, re, be, P, ye) => `<label class="music-tune-slider" title="${l(ye)}">
        <span>${l(ye)}</span>
        <input type="range" data-f="${N}" min="${at}" max="${Me}" step="${re}" value="${l(ie(be, P))}" aria-label="${l(ye)}" />
        <em>${l(ie(be, P))}</em>
      </label>`, Ee = c || p ? `<div class="music-tune-sliders">
          ${c ? T("gain_db", "-24", "24", "0.5", x, 1, n("music.tuning_gain")) : ""}
          ${p ? T("q", "0.1", "10", "0.01", se, 3, n("music.tuning_q")) : ""}
        </div>` : "";
  return `<div class="music-tune-row${e.on ? "" : " off"}" data-i="${t}">
      <div class="music-tune-line">
        <button type="button" class="music-tune-sw" data-act="on" aria-pressed="${e.on}" title="${l(e.on ? n("music.tuning_off") : n("music.tuning_on"))}">${f.power}</button>
        <button type="button" class="music-tune-kind" data-act="kind" aria-expanded="${s}"><span>${l(Ps(e.kind))}</span>${f.chevron}</button>
        <input type="text" class="music-tune-num" data-f="freq_hz" inputmode="decimal" autocomplete="off" spellcheck="false" value="${l(ie(e.freq_hz, 1))}" placeholder="${l(n("music.tuning_freq"))}" aria-label="${l(n("music.tuning_freq"))}" />
        ${g}${k}
        <button type="button" class="music-tune-del" data-act="del" title="${l(n("music.tuning_del"))}">${f.trash}</button>
      </div>
      ${Ee}
      ${D}
    </div>`;
}
function on(e) {
  if (qt) return;
  const t = e.querySelector("#music-tuning-filters");
  if (!t || !E) return;
  const i = E.kinds;
  M(
    t,
    F.length === 0 ? `<div class="music-hint">${l(n("music.tuning_empty"))}</div>` : F.map((s, a) => vc(s, a, i, de === a)).join("")
  );
}
function Hs(e, t, i) {
  const s = Oi;
  if (!s) return null;
  const a = e.getBoundingClientRect(), c = s.w / (a.width || s.w), p = s.h / (a.height || s.h), g = (t - a.left) * c, k = (i - a.top) * p, D = Math.log10(20), x = Math.log10(2e4), se = (g - s.padL) / s.plotW, T = 10 ** (D + se * (x - D)), Ee = s.span - (k - s.padT) / s.plotH * (2 * s.span);
  return { f: T, db: Ee, x: g, y: k };
}
function rn(e, t, i) {
  const s = Math.log10(20), a = Math.log10(2e4), c = e.padL + (Math.log10(Math.max(1, t)) - s) / (a - s) * e.plotW, p = e.padT + (e.span - i) / (2 * e.span) * e.plotH;
  return { x: c, y: p };
}
function si(e) {
  var Si;
  const t = e.querySelector("#music-tune-canvas");
  if (!t || !E) return;
  const i = t.clientWidth || t.width, s = t.clientHeight || t.height;
  if (i < 2 || s < 2) return;
  const a = window.devicePixelRatio || 1;
  (t.width !== Math.round(i * a) || t.height !== Math.round(s * a)) && (t.width = Math.round(i * a), t.height = Math.round(s * a));
  const c = t.getContext("2d");
  if (!c) return;
  c.setTransform(a, 0, 0, a, 0, 0), c.clearRect(0, 0, i, s);
  const p = getComputedStyle(e), g = p.getPropertyValue("--accent").trim() || "#7aa2f7", k = p.getPropertyValue("--border-glass").trim() || "rgba(255,255,255,0.12)", D = p.getPropertyValue("--text-dim").trim() || "rgba(255,255,255,0.55)", { freqs: x, db: se } = E.response, T = 30, Ee = 8, N = 8, at = 16, Me = Math.max(1, i - T - Ee), re = Math.max(1, s - N - at);
  let be = 0;
  for (const w of se) Number.isFinite(w) && (be = Math.max(be, Math.abs(w)));
  for (const w of (Ge == null ? void 0 : Ge.db) ?? [])
    Number.isFinite(w) && (be = Math.max(be, Math.abs(w)));
  const P = Math.min(60, Math.max(12, Math.ceil((be + 1) / 6) * 6)), ye = Math.log10(20), ki = Math.log10(2e4), Oe = (w) => T + (Math.log10(Math.max(1, w)) - ye) / (ki - ye) * Me, B = (w) => N + (P - w) / (2 * P) * re, Te = { w: i, h: s, padL: T, padT: N, plotW: Me, plotH: re, span: P };
  Oi = Te, c.lineWidth = 1, c.font = "9px system-ui, -apple-system, sans-serif", c.textBaseline = "middle";
  for (const w of [P, P / 2, 0, -P / 2, -P])
    c.strokeStyle = k, c.globalAlpha = w === 0 ? 0.9 : 0.45, c.setLineDash(w === 0 ? [] : [3, 3]), c.beginPath(), c.moveTo(T, B(w)), c.lineTo(T + Me, B(w)), c.stroke();
  c.setLineDash([]), c.fillStyle = D;
  for (const w of [20, 100, 1e3, 1e4, 2e4]) {
    const A = Oe(w);
    c.globalAlpha = 0.45, c.strokeStyle = k, c.beginPath(), c.moveTo(A, N), c.lineTo(A, N + re), c.stroke(), c.globalAlpha = 0.9, c.textAlign = w === 20 ? "left" : w === 2e4 ? "right" : "center", c.fillText(w >= 1e3 ? `${w / 1e3}k` : String(w), A, N + re + 8);
  }
  c.textAlign = "right";
  for (const w of [P, P / 2, 0, -P / 2, -P])
    c.globalAlpha = 0.9, c.fillStyle = D, c.fillText(`${w > 0 ? "+" : ""}${ie(w, 0)}`, T - 3, B(w));
  if (c.textAlign = "left", c.globalAlpha = 1, x.length >= 2 && se.length === x.length) {
    c.beginPath();
    for (let w = 0; w < x.length; w++) {
      const A = Oe(x[w]), V = B(se[w]);
      w === 0 ? c.moveTo(A, V) : c.lineTo(A, V);
    }
    c.lineTo(Oe(x[x.length - 1]), B(0)), c.lineTo(Oe(x[0]), B(0)), c.closePath(), c.globalAlpha = 0.12, c.fillStyle = g, c.fill(), c.globalAlpha = 1, c.beginPath();
    for (let w = 0; w < x.length; w++) {
      const A = Oe(x[w]), V = B(se[w]);
      w === 0 ? c.moveTo(A, V) : c.lineTo(A, V);
    }
    c.strokeStyle = g, c.lineWidth = 1.5, c.stroke();
  }
  const ne = Ge;
  if (ne && ne.freqs.length >= 2) {
    const w = p.getPropertyValue("--green").trim() || "#8fc99a";
    c.save(), c.beginPath(), c.rect(T, N, Me, re), c.clip(), c.beginPath();
    for (let A = 0; A < ne.freqs.length; A++) {
      const V = Oe(ne.freqs[A]), ge = B(ne.db[A]);
      A === 0 ? c.moveTo(V, ge) : c.lineTo(V, ge);
    }
    c.setLineDash([5, 3]), c.strokeStyle = w, c.lineWidth = 1.4, c.stroke(), c.setLineDash([]), c.restore();
  }
  if (F.length > 0) {
    c.save(), c.font = "9px system-ui, -apple-system, sans-serif", c.textAlign = "center", c.textBaseline = "middle";
    for (let w = 0; w < F.length; w++) {
      const A = F[w], V = ((Si = E.kinds.find((Gt) => Gt.name === A.kind)) == null ? void 0 : Si.gain) ?? A.gain_db !== void 0, { x: ge, y: W } = rn(Te, A.freq_hz, V ? A.gain_db ?? 0 : 0), Ue = w === ut;
      c.globalAlpha = A.on ? 1 : 0.4, c.beginPath(), V ? c.arc(ge, W, Ue ? 6 : 4.5, 0, Math.PI * 2) : (c.moveTo(ge, W - 5), c.lineTo(ge + 5, W + 3), c.lineTo(ge - 5, W + 3), c.closePath()), c.fillStyle = Ue ? g : "rgba(0,0,0,0.65)", c.fill(), c.strokeStyle = g, c.lineWidth = 1.5, c.stroke(), V && w < 9 && (c.globalAlpha = 1, c.fillStyle = Ue ? "rgba(0,0,0,0.8)" : g, c.fillText(String(w + 1), ge, W + 0.5));
    }
    c.globalAlpha = 1, c.restore();
  }
}
function hc(e, t, i) {
  e.kind = t;
  const s = i.find((a) => a.name === t);
  s && (s.gain ? e.gain_db === void 0 && (e.gain_db = 0) : delete e.gain_db, s.order === 1 ? delete e.q : e.q === void 0 && (e.q = 0.707));
}
async function Ce(e, t = !1) {
  var k, D;
  const i = ++De, s = document.activeElement, a = (k = s == null ? void 0 : s.closest) == null ? void 0 : k.call(s, ".music-tune-row"), c = s instanceof HTMLInputElement && s.type === "text" ? s.dataset.f : void 0, p = a ? Number(a.dataset.i) : -1;
  let g;
  try {
    g = await h("player_tuning_set_chain", {
      preampDb: tt,
      filters: F
    });
  } catch (x) {
    if (i !== De) return;
    L(e, R(x)), await yi(e);
    return;
  }
  i === De && (E = g, hi(), t || L(e, n("music.tuning_saved")), Vt(e), c && p >= 0 && p < F.length && ((D = e.querySelector(`.music-tune-row[data-i="${p}"] input[data-f="${c}"]`)) == null || D.focus()));
}
async function bc(e, t) {
  const i = ++De;
  let s;
  try {
    s = await h("player_tuning_set_enabled", { enabled: t });
  } catch (a) {
    if (i !== De) return;
    L(e, R(a)), await yi(e);
    return;
  }
  i === De && (E = s, hi(), L(e, n("music.tuning_saved")), Vt(e));
}
async function yc(e, t) {
  const i = ++De;
  let s;
  try {
    s = await h("player_tuning_set", { enabled: !0, preset: t });
  } catch (a) {
    if (i !== De) return;
    L(e, R(a)), await yi(e);
    return;
  }
  i === De && (E = s, hi(), de = -1, Ge = null, L(e, n("music.tuning_saved")), Vt(e));
}
function js(e) {
  const t = Date.now();
  if (t - Jt >= 120) {
    Jt = t, Ce(e, !0);
    return;
  }
  xi == null && (xi = window.setTimeout(() => {
    xi = null, Jt = Date.now(), Ce(e, !0);
  }, 120));
}
async function gc(e) {
  if (!Ye) {
    Ye = !0, un(e);
    try {
      Ge = await h("player_tuning_measure");
    } catch (t) {
      L(e, R(t));
    } finally {
      Ye = !1, Vt(e);
    }
  }
}
function _c(e) {
  var t;
  return !!e.uri && ((t = m == null ? void 0 : m.track) == null ? void 0 : t.uri) === e.uri;
}
function L(e, t) {
  $(e.querySelector("#music-msg"), t);
}
function gi(e, t, i, s = "", a = "") {
  return `<button class="music-tr${_c(e) ? " playing" : ""}" data-act="${i}" data-uri="${l(e.uri)}"${s ? ` data-i="${l(s)}"` : ""}${a ? ` title="${l(a)}"` : ""}>
    <span class="music-tr-i">${t + 1}</span>
    <span class="music-tr-main">
      <span class="music-tr-n">${l(e.name || "?")}</span>
      <span class="music-tr-a">${l(e.artists || e.album)}</span>
    </span>
    <span class="music-tr-d">${Bt(e.duration_ms)}</span>
  </button>`;
}
function _i(e) {
  return { id: e.id, uri: e.uri, name: e.name, cover: e.cover, subtitle: e.owner, total: e.total };
}
function ni(e, t) {
  const i = !!t.uri && (m == null ? void 0 : m.context_uri) === t.uri, s = (S == null ? void 0 : S.kind) === e && S.id === t.id, a = t.cover ? `<img src="${l(t.cover)}" alt="">` : "";
  return `<div class="music-pl${i ? " playing" : ""}${s ? " on" : ""}" data-uri="${l(t.uri)}">
    <button class="music-pl-btn" data-act="open" data-kind="${e}" data-id="${l(t.id)}" title="${l(t.name || "?")}">
      <span class="music-pl-cover">${a}</span>
      <span class="music-pl-main">
        <span class="music-pl-name">${l(t.name || "?")}</span>
        <span class="music-pl-sub">${l(t.subtitle)}</span>
      </span>
    </button>
  </div>`;
}
function wc() {
  return `<div class="music-pl${(S == null ? void 0 : S.kind) === "top-tracks" ? " on" : ""}">
    <button class="music-pl-btn" data-act="open" data-kind="top-tracks" data-id="top-tracks" title="${l(n("music.top_tracks"))}">
      <span class="music-pl-cover music-pl-trend-cover">${f.trend}</span>
      <span class="music-pl-main">
        <span class="music-pl-name">${l(n("music.top_tracks"))}</span>
        <span class="music-pl-sub">${l(n("music.top_tracks_sub"))}</span>
      </span>
    </button>
  </div>`;
}
function $c(e, t) {
  const i = t.cover ? `<img src="${l(t.cover)}" alt="">` : "";
  return `<button class="music-card" data-act="open" data-kind="${e}" data-id="${l(t.id)}" title="${l(t.name)}">
    <span class="music-card-cover${e === "artist" ? " round" : ""}">${i}</span>
    <span class="music-card-n">${l(t.name)}</span>
    <span class="music-card-s">${l(t.subtitle)}</span>
  </button>`;
}
function kc() {
  const e = (S == null ? void 0 : S.kind) === "liked", t = j ? String(j.total) : "", i = it || [(r == null ? void 0 : r.display_name) || "", t].filter(Boolean).join(" · ");
  return `<div class="music-pl music-pl-liked${e ? " on" : ""}${it ? " err" : ""}">
    <button class="music-pl-btn" data-act="open" data-kind="liked" data-id="liked" title="${l(n("music.liked_songs"))}">
      <span class="music-pl-cover music-pl-liked-cover">${f.heart}</span>
      <span class="music-pl-main">
        <span class="music-pl-name">${l(n("music.liked_songs"))}</span>
        <span class="music-pl-sub">${l(i)}</span>
      </span>
    </button>
  </div>`;
}
function ct(e) {
  if (Q) {
    Fe(e);
    return;
  }
  C(e.querySelector("#music-side-tabs"), !0), C(e.querySelector("#music-local-head"), !1), e.querySelectorAll("#music-side-tabs .music-tab").forEach((c) => {
    c.classList.toggle("on", c.dataset.tab === ee);
  });
  const t = e.querySelector("#music-side-list");
  if (!t) return;
  if (!(r != null && r.connected)) {
    M(t, `<div class="music-empty">${n("music.playlists_login")}</div>`);
    return;
  }
  const i = yt.get(ee), s = Ht.get(ee);
  let a = ee === "playlist" ? kc() : ee === "top" ? wc() : "";
  It.has(ee) ? a += `<div class="music-empty">${n("music.loading")}</div>` : s ? a += `<div class="music-empty music-empty-err">${l(s)}</div>` : i && (a += i.length === 0 ? `<div class="music-empty">${n(ee === "playlist" ? "music.playlists_empty" : "music.lib_empty")}</div>` : i.map((c) => ni(ee, c)).join("")), M(t, a);
}
function Mi(e) {
  e.querySelectorAll("#music-side-list .music-pl").forEach((t) => {
    const i = t.querySelector(".music-pl-btn"), s = !!S && (i == null ? void 0 : i.dataset.kind) === S.kind && (i == null ? void 0 : i.dataset.id) === S.id;
    t.classList.toggle("on", s);
  });
}
function oe(e) {
  if (Q) {
    mn(e);
    return;
  }
  const t = e.querySelector("#music-main");
  if (!t) return;
  if (He && fe) {
    M(t, Sc());
    return;
  }
  if (!S) {
    M(t, `<div class="music-empty">${r != null && r.connected ? n("music.pick_hint") : n("music.playlists_login")}</div>`);
    return;
  }
  const i = S.cover ? `<img src="${l(S.cover)}" alt="">` : "", s = S.kind === "liked" ? n("music.liked_songs") : S.kind === "top-tracks" ? n("music.top_tracks") : S.kind === "playlist" ? n("music.playlists") : S.kind === "album" ? n("music.tab_albums") : S.kind === "artist" ? n("music.tab_artists") : S.kind === "top" ? n("music.tab_top") : n("music.tab_shows");
  let a;
  mt ? a = `<div class="music-empty">${n("music.loading")}</div>` : Ne ? a = `<div class="music-empty music-empty-err">${l(Ne)}</div>` : !le || le.length === 0 ? a = `<div class="music-empty">${n("music.playlist_empty")}</div>` : a = le.map((c, p) => gi(c, p, "main-track", String(p))).join(""), M(t, `<div class="music-page">
    <div class="music-page-head">
      <span class="music-page-cover${S.kind === "artist" ? " round" : ""}">${i}</span>
      <div class="music-page-info">
        <span class="music-page-kind">${l(s)}</span>
        <span class="music-page-name">${l(S.name || "?")}</span>
        <span class="music-page-sub">${l(S.subtitle)}</span>
        <div class="music-page-actions">
          <button class="music-btn music-primary" data-act="main-play-all">${f.play} ${n("music.play_all")}</button>
        </div>
      </div>
    </div>
    <div class="music-list">${a}</div>
  </div>`);
}
function Sc() {
  const e = O, i = [
    ["tracks", n("music.tracks")],
    ["artists", n("music.tab_artists")],
    ["albums", n("music.tab_albums")],
    ["playlists", n("music.playlists")],
    ["shows", n("music.tab_shows")]
  ].map(([a, c]) => `<button class="music-tab${we === a ? " on" : ""}" data-act="search-tab" data-tab="${a}">${l(c)}</button>`).join("");
  let s;
  if (bt || !e)
    s = `<div class="music-empty">${n("music.loading")}</div>`;
  else if (we === "tracks")
    s = e.tracks.length ? e.tracks.map((a, c) => gi(a, c, "main-track", String(c))).join("") : `<div class="music-empty">${n("music.search_empty")}</div>`;
  else {
    const c = (we === "artists" ? e.artists : we === "albums" ? e.albums : we === "shows" ? e.shows : e.playlists.map(_i)).map((p) => $c(we === "playlists" ? "playlist" : we === "artists" ? "artist" : we === "albums" ? "album" : "show", p));
    s = c.length ? `<div class="music-grid">${c.join("")}</div>` : `<div class="music-empty">${n("music.search_empty")}</div>`;
  }
  return `<div class="music-page">
    <div class="music-page-info music-page-info-flat">
      <span class="music-page-kind">${n("music.search_result")}</span>
      <span class="music-page-name">${l(fe)}</span>
    </div>
    <div class="music-tabs">${i}</div>
    <div class="music-list">${s}</div>
  </div>`;
}
function Le(e) {
  const t = e.querySelector("#music-search-dd");
  if (!t) return;
  const i = !!(r != null && r.connected) && me && !!fe;
  if (C(t, i), !i) return;
  if (!O) {
    M(t, bt ? `<div class="music-empty">${n("music.loading")}</div>` : "");
    return;
  }
  const s = O, a = [];
  s.tracks.slice(0, 3).forEach((c, p) => a.push(gi(c, p, "dd-track"))), s.artists.slice(0, 2).forEach((c) => a.push(ni("artist", c))), s.albums.slice(0, 2).forEach((c) => a.push(ni("album", c))), s.playlists.slice(0, 2).forEach((c) => a.push(ni("playlist", _i(c)))), a.length || a.push(`<div class="music-empty">${n("music.search_empty")}</div>`), a.push(`<button class="music-dd-all" data-act="search-all">${n("music.search_all")}</button>`), M(t, a.join(""));
}
function $t(e) {
  const t = e.querySelector("#music-dev-dd");
  if (!t || (C(t, Ie), !Ie)) return;
  const i = z;
  let s = `<div class="music-dd-head">${n("music.devices")}</div>`;
  i != null && i.available && !i.has_credentials ? s += `<button class="music-dev-row" data-act="local-login">
      <span class="music-dev-ico">${f.power}</span>
      <span class="music-dev-main">
        <span class="music-dev-n">${n("music.local_login")}</span>
        <span class="music-dev-s">${n("music.local_login_hint")}</span>
      </span>
    </button>` : i != null && i.available ? s += `<button class="music-dev-row${i.running ? " on" : ""}" data-act="local-toggle">
      <span class="music-dev-ico">${f.power}</span>
      <span class="music-dev-main">
        <span class="music-dev-n">${n("music.local_play")}</span>
        <span class="music-dev-s">${l(i.path || "")}</span>
      </span>
    </button>` : s += `<div class="music-dev-row disabled">
      <span class="music-dev-ico">${f.power}</span>
      <span class="music-dev-main">
        <span class="music-dev-n">${n("music.local_play")}</span>
        <span class="music-dev-s">${n("music.local_no_exe")}</span>
      </span>
    </div>`;
  const a = nt ?? [];
  s += a.length ? a.map((c) => `<button class="music-dev-row${c.active ? " on" : ""}" data-act="dev-pick" data-id="${l(c.id)}">
        <span class="music-dev-ico">${f.speaker}</span>
        <span class="music-dev-main">
          <span class="music-dev-n">${l(c.name || "?")}</span>
          <span class="music-dev-s">${l(c.kind)}</span>
        </span>
      </button>`).join("") : `<div class="music-empty">${n("music.device_none")}</div>`, M(t, s);
}
function xc(e) {
  var s;
  const t = (m == null ? void 0 : m.context_uri) ?? "", i = ((s = m == null ? void 0 : m.track) == null ? void 0 : s.uri) ?? "";
  e.querySelectorAll(".music-pl").forEach((a) => {
    a.classList.toggle("playing", !!t && a.dataset.uri === t);
  }), e.querySelectorAll(".music-tr").forEach((a) => {
    a.classList.toggle("playing", !!i && a.dataset.uri === i);
  });
}
function Lc(e) {
  if (!e) return "";
  const t = new Date(e), i = (s) => String(s).padStart(2, "0");
  return `${t.getFullYear()}-${i(t.getMonth() + 1)}-${i(t.getDate())} ${i(t.getHours())}:${i(t.getMinutes())}`;
}
function dn(e) {
  pe && ($e = !1);
  const t = (i, s) => C(e.querySelector(i), s);
  t("#music-local-add", !pe), t("#music-local-list", !pe), t("#music-local-scan", !pe), t("#music-local-del", pe), t("#music-local-editdone", pe), Mt(e);
}
function Mt(e) {
  const t = e.querySelector("#music-local-add-dd");
  t && (C(t, $e), $e && M(t, `
    <div class="music-dd-head">${l(n("music.local_add_head"))}</div>
    <button class="music-dev-row" data-act="media-add-dir">
      <span class="music-dev-ico">${f.folder}</span>
      <span class="music-dev-main">
        <span class="music-dev-n">${l(n("music.local_add_dir"))}</span>
        <span class="music-dev-s">${l(n("music.local_add_dir_hint"))}</span>
      </span>
    </button>
    <button class="music-dev-row" data-act="media-add-list">
      <span class="music-dev-ico">${f.list}</span>
      <span class="music-dev-main">
        <span class="music-dev-n">${l(n("music.local_open_playlist"))}</span>
        <span class="music-dev-s">${l(n("music.local_add_list_hint"))}</span>
      </span>
    </button>`));
}
function qc(e) {
  const t = e.missing ? n("music.local_missing") : [
    n("music.local_n_tracks", { n: String(e.tracks) }),
    e.last_scan_at ? Lc(e.last_scan_at) : n("music.local_never_scanned")
  ].join(" · "), i = pe && ke.has(e.path);
  return `<div class="music-pl${ve === e.path ? " on" : ""}${e.missing ? " err" : ""}${i ? " sel" : ""}">
    <button class="music-pl-btn" data-act="media-root" data-path="${l(e.path)}" title="${l(e.path)}">
      <span class="music-pl-cover music-pl-dir">${f.folder}</span>
      <span class="music-pl-main">
        <span class="music-pl-name">${l(e.name || e.path)}</span>
        <span class="music-pl-sub">${l(t)}</span>
      </span>
    </button>
  </div>`;
}
function Fe(e) {
  C(e.querySelector("#music-side-tabs"), !1), C(e.querySelector("#music-local-head"), !0), dn(e);
  const t = e.querySelector("#music-side-list");
  if (!t) return;
  const i = (K ?? []).filter((c) => !jt.has(c.path)), s = i.reduce((c, p) => c + p.tracks, 0);
  let a = `<div class="music-pl${ve === "" ? " on" : ""}">
    <button class="music-pl-btn" data-act="media-root" data-path="" title="${l(n("music.local_all"))}">
      <span class="music-pl-cover music-pl-dir">${f.note}</span>
      <span class="music-pl-main">
        <span class="music-pl-name">${l(n("music.local_all"))}</span>
        <span class="music-pl-sub">${l(n("music.local_n_tracks", { n: String(s) }))}</span>
      </span>
    </button>
  </div>`;
  ri ? a += `<div class="music-empty">${n("music.loading")}</div>` : gt ? a += `<div class="music-empty music-empty-err">${l(gt)}</div>` : K && i.length === 0 ? a += `<div class="music-empty">${l(n("music.local_no_roots"))}</div>` : K && (a += i.map((c) => qc(c)).join("")), M(t, a);
}
function Ec(e, t) {
  const i = e.cover ? `<img src="${l(vi(e.cover))}" alt="">` : `<span class="music-mt-ico">${f.note}</span>`, s = [e.artist, e.album].filter(Boolean).join(" · ");
  return `<button class="music-mt${!!(_ != null && _.active) && _.path === e.path ? " playing" : ""}" data-act="local-track" data-i="${t}" data-path="${l(e.path)}" title="${l(e.path)}">
    <span class="music-mt-i">${t + 1}</span>
    <span class="music-mt-cover">${i}</span>
    <span class="music-mt-main">
      <span class="music-mt-n">${l(e.title || "?")}</span>
      <span class="music-mt-a">${l(s)}</span>
    </span>
    <span class="music-mt-d">${Bt(e.duration_ms)}</span>
  </button>`;
}
function mn(e) {
  const t = e.querySelector("#music-main");
  if (!t) return;
  t.querySelector("#music-local-page") || (t.innerHTML = `<div class="music-local-page" id="music-local-page">
      <div class="music-local-head-row">
        <input class="music-local-q" id="music-mt-q" type="search" autocomplete="off" spellcheck="false"
               placeholder="${l(n("music.local_filter_ph"))}" value="${l(Wt)}">
        <span class="music-list-chip hidden" id="music-list-chip">
          <span class="music-list-chip-n" id="music-list-chip-n"></span>
          <button class="music-pl-x" data-act="media-list-close" title="${l(n("music.local_close_playlist"))}">${f.x}</button>
        </span>
        <!-- 重扫（2026-10-01 用户口径）：**只留图标**，「重扫」那两个可见字去掉 ——
             它右边紧挨着设置齿轮（见 placeGear），带文字那一行会挤。
             title 仍然留着（鼠标悬浮还能问出这是什么）；去掉的是**可见文字**。
             ⚠️ 本行属于**动态骨架**（#music-main 会被 renderMain 整块重写、回来时重建），
             所以它只能走 data-act 委托，直接 addEventListener 会在下次重建时失效。 -->
        <button class="music-ghost-btn music-icon-btn" data-act="media-scan" title="${l(n("music.local_rescan"))}">${f.refresh}</button>
      </div>
      <div class="music-scan hidden" id="music-scan"></div>
      <!-- 视频的**画面层**（2026-10-01 用户第 8 条）。里面那个 video 元素由
           renderLocalVideo 现造现拆（离开 / 换曲时整块清掉，见那里的注释）。
           注：本段在模板字符串里，注释里一个反引号都不能出现（预检 #15 / #39 ⑩）。 -->
      <div class="music-video hidden" id="music-video"></div>
      <div class="music-list" id="music-mt-list"></div>
    </div>`), C(e.querySelector("#music-mt-q"), !ae);
  const i = e.querySelector("#music-list-chip");
  C(i, !!ae), ae && $(
    e.querySelector("#music-list-chip-n"),
    `${ae.name} · ${n("music.local_n_tracks", { n: String((U == null ? void 0 : U.total) ?? 0) })}`
  ), Mc(e), pn(e), Tc(e), ln(e);
}
function Mc(e) {
  const t = e.querySelector("#music-scan");
  if (!t) return;
  const i = pt;
  let s = "";
  if (i != null && i.running) {
    const a = i.total, c = a > 0 ? Math.min(100, Math.round(i.scanned / a * 100)) : 0, p = a > 0 ? n("music.local_scanning", { a: String(i.scanned), b: String(a) }) : n("music.local_scanning_n", { a: String(i.scanned) });
    s = `<div class="music-scan-row">
      <span class="music-scan-bar"><span class="music-scan-fill" style="width:${c}%"></span></span>
      <span class="music-scan-txt">${l(p)}</span>
    </div>`;
  } else i != null && i.error ? s = `<div class="music-scan-row music-scan-err">${l(i.error)}</div>` : i != null && i.done_at && (s = `<div class="music-scan-row music-scan-done">${l(n("music.local_scan_done", {
    added: String(i.added),
    updated: String(i.updated),
    removed: String(i.removed),
    failed: String(i.failed)
  }))}</div>`);
  M(t, s), C(t, !!s);
}
function Tc(e) {
  const t = e.querySelector("#music-mt-list");
  if (!t) return;
  let i;
  _t ? i = `<div class="music-empty">${n("music.loading")}</div>` : We ? i = `<div class="music-empty music-empty-err">${l(We)}</div>` : !ae && K && K.length === 0 ? i = `<div class="music-empty">${l(n("music.local_add_hint"))}</div>` : !U || U.items.length === 0 ? i = `<div class="music-empty">${l(n(ae ? "music.local_list_empty" : "music.local_empty"))}</div>` : (i = U.items.map((s, a) => Ec(s, a)).join(""), U.total > U.items.length && (i += `<div class="music-empty">${l(n("music.local_more", {
    a: String(U.items.length),
    b: String(U.total)
  }))}</div>`)), M(t, i);
}
function pn(e) {
  const t = e.querySelector("#music-video");
  if (!t) return;
  const i = _, s = !!i && i.video && i.path !== "";
  if (C(t, s), !s) {
    t.firstChild && (t.innerHTML = "");
    return;
  }
  const a = vi(i.path);
  let c = t.querySelector(".music-video-el");
  if (!c || c.dataset.src !== a) {
    if (t.innerHTML = '<video class="music-video-el" muted playsinline preload="auto"></video>', c = t.querySelector(".music-video-el"), !c) return;
    c.dataset.src = a, c.src = a, c.addEventListener("loadedmetadata", () => Ws(c, i), { once: !0 }), c.addEventListener("error", () => {
      $(e.querySelector("#music-msg"), n("music.video_unsupported"));
    });
  }
  Ws(c, i);
}
function Ws(e, t) {
  t.playing ? e.paused && e.play().catch(() => {
  }) : e.paused || e.pause();
  const i = t.playing ? Date.now() - Ut : 0, s = (t.position_ms + Math.max(0, i)) / 1e3;
  e.readyState >= 1 && !e.seeking && Math.abs(e.currentTime - s) > Xn && (e.currentTime = s);
}
function fn(e) {
  if (I !== "lplayer") return;
  const t = e.querySelector("#music-v-lplayer"), i = _;
  if (!t || !i || !i.path) return;
  const s = Pe[Se], a = (s == null ? void 0 : s.title) || i.path.split(/[\\/]/).pop() || i.path;
  $(t.querySelector("#music-lp-title"), a), $(t.querySelector("#music-lp-sub"), s ? [s.artist, s.album].filter(Boolean).join(" · ") : ""), M(
    t.querySelector("#music-lp-cover"),
    s != null && s.cover ? `<img src="${l(vi(s.cover))}" alt="">` : f.note
  ), M(t.querySelector("#music-lp-play"), i.active && i.playing ? f.pause : f.play);
  const c = t.querySelector("#music-lp-mode");
  c && (he(c, "data-mode", G), he(c, "title", Hi()), M(c, G === "repeat_all" || G === "repeat_one" ? f.repeat : f.shuffle));
  const p = i.duration_ms, g = J >= 0 ? J : p > 0 ? Math.min(1, i.position_ms / p) : 0, k = t.querySelector("#music-lp-progress");
  k && J < 0 && k.style.setProperty("--seek-pct", `${g * 100}%`), $(t.querySelector("#music-lp-time"), p > 0 ? `${H(i.position_ms)} / ${H(p)}` : H(i.position_ms));
  const D = t.querySelector("#music-lp-vol");
  D && document.activeElement !== D && (D.value = String(Math.round(i.volume * 100)), ft(D, i.volume * 100));
}
function Be(e) {
  pn(e), fn(e);
  const t = e.querySelector("#music-lnowbar");
  if (!t) return;
  const i = _, s = (Q || Re) && !!i && i.path !== "";
  if (C(t, s), !s || !i) return;
  const a = Pe[Se], c = (a == null ? void 0 : a.title) || i.path.split(/[\\/]/).pop() || i.path;
  $(t.querySelector("#music-lnow-n"), c), $(t.querySelector("#music-lnow-a"), a ? [a.artist, a.album].filter(Boolean).join(" · ") : ""), M(
    t.querySelector("#music-lnow-cover"),
    a != null && a.cover ? `<img src="${l(vi(a.cover))}" alt="">` : f.note
  ), M(t.querySelector("#music-l-play"), i.active && i.playing ? f.pause : f.play);
  const p = t.querySelector("#music-l-mode");
  p && (he(p, "data-mode", G), he(p, "title", Hi()), M(p, G === "repeat_all" || G === "repeat_one" ? f.repeat : f.shuffle));
  const g = i.duration_ms, k = J >= 0 ? J : g > 0 ? Math.min(1, i.position_ms / g) : 0, D = t.querySelector("#music-lbp");
  D && J < 0 && D.style.setProperty("--seek-pct", `${k * 100}%`), $(t.querySelector("#music-l-time"), g > 0 ? `${H(i.position_ms)} / ${H(g)}` : H(i.position_ms));
  const x = t.querySelector("#music-l-vol");
  x && document.activeElement !== x && (x.value = String(Math.round(i.volume * 100)), ft(x, i.volume * 100));
}
function Wi(e) {
  const t = _ != null && _.active ? _.path : "";
  e.querySelectorAll(".music-mt").forEach((i) => {
    i.classList.toggle("playing", !!t && i.dataset.path === t);
  });
}
function qe(e) {
  Q && (Fe(e), mn(e), Be(e));
}
async function vn(e) {
  ri = !0, gt = "", qe(e);
  try {
    K = await h("media_roots");
  } catch (t) {
    gt = String(t);
  } finally {
    ri = !1, qe(e);
  }
}
async function kt(e) {
  ae = null, _t = !0, We = "", qe(e);
  try {
    U = await h("media_tracks", {
      // 空串 ⇒ 传 null（宿主的 `Option<String>` 收 None = 全库 / 不筛选）
      root: ve || null,
      query: Wt || null,
      limit: zn
    });
  } catch (t) {
    We = String(t);
  } finally {
    _t = !1, qe(e);
  }
}
function vt() {
  Dt !== void 0 && (window.clearInterval(Dt), Dt = void 0);
}
function hn(e) {
  Dt === void 0 && (Dt = window.setInterval(() => {
    (async () => {
      if (!e.isConnected) {
        vt();
        return;
      }
      try {
        const t = await h("media_scan_status");
        pt = t, t.running || (vt(), await vn(e), await kt(e));
      } catch {
        vt();
      }
      qe(e);
    })();
  }, Gn));
}
async function Ni(e, t) {
  try {
    pt = await h("media_scan_start", { root: t || null });
  } catch (i) {
    const s = String(i);
    L(e, s.includes("ERR_SCAN_RUNNING") ? n("music.local_scan_busy") : s);
    return;
  }
  qe(e), hn(e);
}
async function Cc(e) {
  let t = null;
  try {
    t = await Ks({ directory: !0, multiple: !1, title: n("music.local_add_dir") });
  } catch (i) {
    L(e, String(i));
    return;
  }
  if (!(typeof t != "string" || !t)) {
    try {
      K = await h("media_add_root", { path: t });
    } catch (i) {
      L(e, String(i));
      return;
    }
    ve = Ic(t), qe(e), await Ni(e, ve || t);
  }
}
function Ic(e) {
  var s;
  const t = (a) => a.replace(/[\\/]+$/, "").toLowerCase(), i = t(e);
  return ((s = K == null ? void 0 : K.find((a) => t(a.path) === i)) == null ? void 0 : s.path) ?? "";
}
function Rc(e) {
  pe = !0, ke.clear(), Fe(e);
}
function Ac(e) {
  if (ke.size) {
    for (const t of ke) jt.add(t);
    ke.clear(), Fe(e);
  }
}
async function Dc(e) {
  const t = Array.from(jt);
  if (pe = !1, ke.clear(), jt.clear(), dn(e), !t.length) {
    Fe(e);
    return;
  }
  let i = "";
  for (const s of t)
    try {
      K = await h("media_remove_root", { path: s });
    } catch (a) {
      const c = String(a);
      i = c.includes("ERR_SCAN_RUNNING") ? n("music.local_remove_busy") : c;
    }
  ve && !(K ?? []).some((s) => s.path === ve) && (ve = ""), Fe(e), await kt(e), i && L(e, i);
}
function Nc(e) {
  const t = e instanceof Error ? e.message : String(e);
  return t.includes("ERR_NOT_PLAYLIST") ? n("music.local_not_playlist") : t;
}
async function Pc(e) {
  let t = null;
  try {
    t = await Ks({
      multiple: !1,
      title: n("music.local_open_playlist"),
      filters: [{ name: "Playlist", extensions: ["m3u", "m3u8", "pls"] }]
    });
  } catch (i) {
    L(e, String(i));
    return;
  }
  if (!(typeof t != "string" || !t)) {
    _t = !0, We = "", U = null, qe(e);
    try {
      U = await h("media_playlist", { path: t }), ae = { path: t, name: t.split(/[\\/]/).pop() || t }, ve = "";
    } catch (i) {
      ae = null, We = Nc(i);
    } finally {
      _t = !1, qe(e);
    }
  }
}
function Bc(e) {
  ae = null, kt(e);
}
function bn(e) {
  const t = e instanceof Error ? e.message : String(e);
  return t.includes("ERR_NO_AUDIO_DEVICE") ? n("music.local_no_device") : t.includes("找不到这个文件") ? n("music.local_file_missing") : t.includes("解不开") || t.includes("打不开") ? n("music.local_decode_failed") : t;
}
async function di(e, t) {
  if (!Xe) {
    await zt(e, "local"), Xe = !0;
    try {
      _ = await h("player_play", { path: t });
    } catch (i) {
      L(e, bn(i)), Xe = !1;
      return;
    }
    Xe = !1, Ut = Date.now(), Be(e), Wi(e), yn(e);
  }
}
async function Oc(e, t) {
  const i = (U == null ? void 0 : U.items) ?? [], s = i[t];
  s && (Pe = i.slice(), Se = t, await di(e, s.path));
}
async function Tt(e, t, i) {
  var c;
  const s = Pe.length;
  if (s === 0) return;
  if (i && G === "repeat_one") {
    await di(e, ((c = Pe[Se]) == null ? void 0 : c.path) ?? "");
    return;
  }
  let a;
  if (G === "shuffle" && s > 1)
    do
      a = Math.floor(Math.random() * s);
    while (a === Se);
  else
    a = Se + t;
  if (G === "repeat_all" || G === "shuffle")
    a = (a % s + s) % s;
  else if (a < 0 || a >= s) {
    i || L(e, n("music.local_queue_end"));
    return;
  }
  Se = a, await di(e, Pe[a].path);
}
async function Fs(e) {
  const t = _;
  if (!(!t || t.path === "") && !Xe) {
    if (!t.active) {
      await di(e, t.path);
      return;
    }
    try {
      _ = await h(t.playing ? "player_pause" : "player_resume");
    } catch (i) {
      L(e, bn(i));
      return;
    }
    Ut = Date.now(), Be(e), _ != null && _.active && yn(e);
  }
}
async function Ct(e) {
  ht(), Pe = [], Se = -1, J = -1, _ = null, Ut = 0;
  const t = I === "lplayer";
  t && (I = "default"), Be(e), Wi(e), t && Z(e);
  try {
    await h("player_stop");
  } catch {
  }
}
async function zt(e, t) {
  if (!Re) {
    if (t === "local") {
      if (r != null && r.connected && (m != null && m.playing))
        try {
          await h("spotify_control", { action: "pause" });
        } catch {
        }
      return;
    }
    _ && await Ct(e);
  }
}
async function Hc(e, t) {
  try {
    _ = await h("player_seek", { positionMs: t });
  } catch {
    return;
  }
  Be(e);
}
async function Us(e, t) {
  try {
    _ = await h("player_volume", { volume: t });
  } catch {
    return;
  }
  Be(e);
}
function ht() {
  Nt !== void 0 && (window.clearInterval(Nt), Nt = void 0);
}
function yn(e) {
  Nt === void 0 && (Nt = window.setInterval(() => {
    (async () => {
      if (!e.isConnected) {
        ht();
        return;
      }
      if (J >= 0 || Xe) return;
      let t;
      try {
        t = await h("player_status");
      } catch {
        return;
      }
      if (!e.isConnected) {
        ht();
        return;
      }
      const i = !t.active && t.path !== "" && t.path === (_ == null ? void 0 : _.path);
      _ = t, Ut = Date.now(), Be(e), Wi(e), i && (ht(), await Tt(e, 1, !0));
    })();
  }, Qn));
}
function jc(e, t) {
  Wt = t, te !== void 0 && window.clearTimeout(te), te = window.setTimeout(() => {
    te = void 0, kt(e);
  }, Yn);
}
function Vs(e) {
  Rt = Math.min(en, Math.max(Zs, Math.round(Rt))), e.style.setProperty("--music-side-w", `${Rt}px`);
}
function gn(e, t) {
  var s;
  if (e === "liked")
    return { id: "liked", uri: "", name: n("music.liked_songs"), cover: "", subtitle: "", total: (j == null ? void 0 : j.total) ?? 0 };
  if (e === "top-tracks")
    return {
      id: "top-tracks",
      uri: "",
      name: n("music.top_tracks"),
      cover: "",
      subtitle: n("music.top_tracks_sub"),
      total: 0
    };
  const i = e === "artist" ? O == null ? void 0 : O.artists : e === "album" ? O == null ? void 0 : O.albums : e === "show" ? O == null ? void 0 : O.shows : O == null ? void 0 : O.playlists.map(_i);
  return ((s = yt.get(e)) == null ? void 0 : s.find((a) => a.id === t)) ?? (i == null ? void 0 : i.find((a) => a.id === t)) ?? null;
}
async function _n(e, t) {
  if (!(!(r != null && r.connected) || It.has(t) || yt.has(t))) {
    It.add(t), Ht.delete(t), ct(e);
    try {
      const i = t === "playlist" ? (Ri = await h("spotify_playlists")).map(_i) : await h(Dn[t]);
      yt.set(t, i);
    } catch (i) {
      Ht.set(t, R(i));
    } finally {
      It.delete(t), ct(e);
    }
  }
}
async function Wc(e, t, i) {
  const s = gn(t, i);
  if (s) {
    if (He = !1, me = !1, S = { kind: t, id: s.id, uri: s.uri, name: s.name, cover: s.cover, subtitle: s.subtitle }, le = null, Ne = "", t === "liked") {
      le = (j == null ? void 0 : j.items) ?? null, Ne = it, mt = !j, Le(e), Mi(e), oe(e), j || await $n(e);
      return;
    }
    mt = !0, Le(e), Mi(e), oe(e);
    try {
      le = t === "top-tracks" ? await h("spotify_top_tracks") : await h("spotify_item_tracks", { kind: An(t), id: s.id });
    } catch (a) {
      Ne = R(a);
    } finally {
      mt = !1, Mi(e), oe(e);
    }
  }
}
async function zs(e, t, i, s = 0) {
  const a = gn(t, i);
  if (a) {
    await zt(e, "spotify");
    try {
      if (t === "liked" || t === "show" || t === "top-tracks") {
        const c = (t === "liked" ? j == null ? void 0 : j.items : le) ?? [];
        if (!c.length) return;
        await h("spotify_play_uris", { uris: c.slice(Math.max(0, s)).map((p) => p.uri), deviceId: ue || void 0 });
      } else if (a.uri)
        await h("spotify_play_context", { contextUri: a.uri, offsetUri: "", deviceId: ue || void 0 });
      else
        return;
    } catch (c) {
      L(e, R(c));
    }
  }
}
async function Fc(e, t) {
  if (!S) return;
  const i = le ?? [], s = i[t];
  if (s) {
    await zt(e, "spotify");
    try {
      S.kind === "liked" || S.kind === "show" ? await h("spotify_play_uris", { uris: i.slice(t).map((a) => a.uri), deviceId: ue || void 0 }) : await h("spotify_play_context", { contextUri: S.uri, offsetUri: s.uri, deviceId: ue || void 0 });
    } catch (a) {
      L(e, R(a));
    }
  }
}
async function mi(e, t = !1) {
  if (!(r != null && r.connected)) return;
  if (!t && ue && Date.now() - Kt < Kn) {
    await St(e);
    return;
  }
  if (qi) return;
  qi = !0;
  const i = !!(z != null && z.running), s = window.setTimeout(() => L(e, n("music.auto_starting")), 600);
  try {
    const a = await h("music_autoconfigure", { allowLocal: !oi });
    ue = a.device_id || "", Kt = Date.now(), a.source === "needs_login" ? L(e, n("music.auto_need_login")) : a.source === "local" && !a.device_id ? L(e, n("music.auto_local_unregistered")) : a.started_local && !i ? L(e, n("music.auto_local_started")) : a.source === "start_failed" ? L(e, n("music.auto_start_failed")) : a.source === "none" && !oi && L(e, n("music.auto_none"));
  } catch (a) {
    ue = "", Kt = 0, String(a) !== "ERR_NOT_CONNECTED" && L(e, R(a));
  } finally {
    window.clearTimeout(s), qi = !1;
  }
  await St(e);
}
function Uc(e) {
  if (e <= 0) return "";
  if (e >= 3600) {
    const t = Math.floor(e / 3600), i = Math.round(e % 3600 / 60);
    return i > 0 ? n("music.wait_hm", { h: String(t), m: String(i) }) : n("music.wait_h", { h: String(t) });
  }
  return e >= 60 ? n("music.wait_m", { m: String(Math.round(e / 60)) }) : n("music.wait_s", { s: String(Math.ceil(e)) });
}
function Vc() {
  return ui <= 0 ? 0 : Math.max(0, Math.round((ui - Date.now()) / 1e3));
}
async function wn(e) {
  try {
    const t = await h("spotify_api_state");
    je = t.stopped, li = t.reason, ui = t.retry_at_ms;
  } catch {
  }
  pi(e);
}
function pi(e) {
  const t = e.querySelector("#music-resume");
  if (C(t, je), !t) return;
  if (!je) {
    t.textContent = n("music.resume"), t.title = "";
    return;
  }
  const i = Uc(Vc());
  t.textContent = i ? n("music.resume_in", { wait: i }) : n("music.resume"), t.title = i ? n("music.resume_hint", { wait: i, reason: li }) : li;
}
async function zc(e) {
  try {
    await h("spotify_resume");
  } catch {
  }
  je = !1, li = "", ui = 0, pi(e), L(e, n("music.resumed")), mi(e, !0);
}
async function St(e) {
  try {
    nt = await h("spotify_devices");
  } catch (t) {
    nt = [], L(e, R(t));
  }
  try {
    z = await h("librespot_status");
  } catch {
    z = null;
  }
  $t(e);
}
async function Gc(e) {
  if (!(z != null && z.available)) return;
  const t = z.running;
  try {
    z = await h(t ? "librespot_stop" : "librespot_start");
  } catch (i) {
    L(e, R(i));
    return;
  }
  if (oi = t, $t(e), t) {
    ue = "", Kt = 0, await mi(e, !0);
    return;
  }
  for (let i = 0; i < 6; i++) {
    await new Promise((s) => window.setTimeout(s, 1500));
    try {
      const s = await h("spotify_devices");
      nt = s;
      const a = s.find((c) => c.name === "Lunac");
      if (a && !a.active && await h("spotify_transfer", { deviceId: a.id, play: !0 }), a) {
        ue = a.id;
        break;
      }
    } catch {
    }
  }
  await St(e);
}
async function Yc(e) {
  try {
    z = await h("librespot_login");
  } catch (t) {
    L(e, R(t));
    return;
  }
  oi = !1, $t(e), L(e, n("music.local_login_started"));
  for (let t = 0; t < 60; t++) {
    if (await new Promise((s) => window.setTimeout(s, 2e3)), !e.isConnected) return;
    let i;
    try {
      i = await h("librespot_status");
    } catch {
      continue;
    }
    if (z = i, !!i.has_credentials) {
      i.running || (z = await h("librespot_start").catch(() => i));
      for (let s = 0; s < 8; s++) {
        if (await new Promise((p) => window.setTimeout(p, 1500)), !e.isConnected) return;
        const a = await h("spotify_devices").catch(() => []);
        nt = a;
        const c = a.find((p) => p.name === "Lunac");
        if (c) {
          c.active || await h("spotify_transfer", { deviceId: c.id, play: !1 }), ue = c.id;
          break;
        }
      }
      L(e, n("music.local_login_ok"));
      break;
    }
  }
  await St(e);
}
async function Qc(e, t) {
  if (t) {
    try {
      await h("spotify_transfer", { deviceId: t, play: !1 }), Ie = !1;
    } catch (i) {
      L(e, R(i));
    }
    await St(e);
  }
}
async function $n(e) {
  if (!(!(r != null && r.connected) || Li || j)) {
    Li = !0, it = "", ct(e);
    try {
      j = await h("spotify_liked");
    } catch (t) {
      it = R(t);
    } finally {
      Li = !1, (S == null ? void 0 : S.kind) === "liked" && (le = (j == null ? void 0 : j.items) ?? null, mt = !1, Ne = it), ct(e), oe(e);
    }
  }
}
function Gs(e, t) {
  if (fe = t, me = !!t, Et !== void 0 && (window.clearTimeout(Et), Et = void 0), !t) {
    O = null, bt = !1, He = !1, Le(e), oe(e);
    return;
  }
  bt = !0, Le(e), oe(e), Et = window.setTimeout(() => void Xc(e, t), jn);
}
async function Xc(e, t) {
  Et = void 0;
  try {
    const i = await h("spotify_search", { query: t });
    if (fe !== t) return;
    O = i;
  } catch (i) {
    if (fe !== t) return;
    O = null, L(e, R(i));
  } finally {
    fe === t && (bt = !1, Le(e), oe(e));
  }
}
function ci(e) {
  const t = (Qe == null ? void 0 : Qe.items) ?? [], i = n("music.play_from_here"), s = t.length === 0 ? `<div class="music-empty">${n(Qe ? "music.queue_empty" : "music.loading")}</div>` : t.map((a, c) => gi(a, c, "play-uri", "", i)).join("");
  for (const a of ["#music-q", "#music-q-dd"]) M(e.querySelector(a), s);
}
async function kn(e) {
  var t;
  try {
    Qe = await h("spotify_queue"), tn = ((t = m == null ? void 0 : m.track) == null ? void 0 : t.id) ?? "";
  } catch (i) {
    Qe = null, $(e.querySelector("#music-msg"), R(i));
  }
  ci(e);
}
function Pi(e) {
  const t = (m == null ? void 0 : m.track) ?? null, i = t != null && t.cover ? `<img src="${l(t.cover)}" alt="">` : "", s = [t == null ? void 0 : t.artists, t == null ? void 0 : t.album].filter(Boolean).join(" · ") || (m != null && m.active ? "" : n("music.no_device_hint"));
  M(e.querySelector("#music-pv-cover"), i), M(e.querySelector("#music-bnow-cover"), i), $(e.querySelector("#music-pv-title"), (t == null ? void 0 : t.name) || n("music.no_track")), $(e.querySelector("#music-bnow-n"), (t == null ? void 0 : t.name) || n("music.no_track")), $(e.querySelector("#music-pv-sub"), s), $(e.querySelector("#music-bnow-a"), s);
  const a = (t == null ? void 0 : t.duration_ms) ?? 0, c = Math.min((m == null ? void 0 : m.progress_ms) ?? 0, a || Number.MAX_SAFE_INTEGER), p = a > 0 ? Math.max(0, Math.min(100, c / a * 100)) : 0;
  if (cn = c, an = Date.now(), Ve < 0)
    for (const T of et) T.style.setProperty("--seek-pct", `${p}%`);
  $(e.querySelector("#music-pv-pos"), H(c)), $(e.querySelector("#music-pv-dur"), H(a)), $(e.querySelector("#music-b-time"), `${H(c)} / ${H(a)}`);
  const g = m != null && m.playing ? f.pause : f.play;
  M(e.querySelector("#music-play"), g), M(e.querySelector("#music-b-play"), g);
  const k = Sn(), D = n(k === "shuffle" ? "music.mode_shuffle" : k === "repeat_one" ? "music.mode_repeat_one" : "music.mode_off");
  for (const T of [e.querySelector("#music-mode"), e.querySelector("#music-b-mode")])
    T && (he(T, "data-mode", k), he(T, "title", D), M(T, k === "repeat_one" ? f.repeat : f.shuffle));
  const x = m && m.volume_percent >= 0 ? m.volume_percent : -1;
  for (const T of [e.querySelector("#music-vol"), e.querySelector("#music-b-vol")])
    T && x >= 0 && document.activeElement !== T && (T.value = String(x), ft(T, x));
  const se = !(m != null && m.active);
  e.querySelectorAll("#music-v-player .music-bar button, #music-nowbar button").forEach((T) => {
    T.id === "music-devices-btn" || T.id === "music-open-player" || T.id === "music-bnow" || (T.disabled = se);
  });
}
function Jc(e) {
  var a;
  if (!e.isConnected || !(m != null && m.playing) || Ve >= 0) return;
  const t = ((a = m.track) == null ? void 0 : a.duration_ms) ?? 0;
  if (t <= 0) return;
  const i = Math.min(cn + (Date.now() - an), t), s = Math.max(0, Math.min(100, i / t * 100));
  for (const c of et) c.style.setProperty("--seek-pct", `${s}%`);
  $(e.querySelector("#music-pv-pos"), H(i)), $(e.querySelector("#music-b-time"), `${H(i)} / ${H(t)}`);
}
function Sn() {
  return (m == null ? void 0 : m.repeat) === "track" ? "repeat_one" : m != null && m.shuffle ? "shuffle" : "off";
}
function Ti(e) {
  var t, i;
  C(e.querySelector("#music-q-wrap"), ce), C(e.querySelector("#music-q-dd"), ce), (t = e.querySelector("#music-queue-btn")) == null || t.classList.toggle("on", ce), (i = e.querySelector("#music-b-queue")) == null || i.classList.toggle("on", ce);
}
function fi(e) {
  const t = e.querySelector("#music-lyr");
  if (!t) return;
  if (Fi(), ze = -1, dt = [], wt && (wt = !1, xe !== void 0 && (window.clearTimeout(xe), xe = void 0)), Ii) {
    M(t, `<div class="music-empty">${n("music.lyrics_loading")}</div>`);
    return;
  }
  if (X != null && X.synced) {
    const s = sc(X.synced);
    if (s.length > 0) {
      dt = s;
      const a = l(n("music.seek_line"));
      M(
        t,
        `<div class="music-lyr-lines">${s.map((c, p) => `<div class="music-lyr-line" data-i="${p}" title="${a}">${l(c.text)}</div>`).join("")}</div>`
      );
      return;
    }
  }
  const i = ((X == null ? void 0 : X.plain) || "").trim();
  if (i) {
    M(t, `<div class="music-lyr-plain">${l(i)}</div>`);
    return;
  }
  if (X != null && X.instrumental) {
    M(t, `<div class="music-empty">${n("music.lyrics_instrumental")}</div>`);
    return;
  }
  M(t, `<div class="music-empty">${n("music.lyrics_none")}</div>`);
}
function Fi() {
  Pt && (cancelAnimationFrame(Pt), Pt = 0);
}
function Ys(e, t) {
  Fi();
  const i = e.scrollTop, s = t - i;
  if (Math.abs(s) < 1) {
    e.scrollTop = t;
    return;
  }
  let a = 0;
  const c = (p) => {
    a || (a = p);
    const g = Math.min(1, (p - a) / Wn);
    e.scrollTop = i + s * (1 - Math.pow(1 - g, 5)), Pt = g < 1 ? requestAnimationFrame(c) : 0;
  };
  Pt = requestAnimationFrame(c);
}
function wi(e) {
  var k, D;
  if (dt.length === 0) return;
  const t = e.querySelector("#music-lyr");
  if (!t || !t.isConnected || t.clientHeight === 0) return;
  const i = ((m == null ? void 0 : m.progress_ms) ?? 0) / 1e3;
  let s = -1;
  for (let x = 0; x < dt.length && dt[x].at <= i; x++)
    s = x;
  if (s === ze) return;
  const a = Math.min(ze, s), c = Math.max(ze, s);
  for (let x = Math.max(0, a + 1); x <= c; x++)
    (k = t.querySelector(`.music-lyr-line[data-i="${x}"]`)) == null || k.classList.toggle("done", x <= s);
  (D = t.querySelector(".music-lyr-line.on")) == null || D.classList.remove("on"), ze = s;
  const p = t.querySelector(`.music-lyr-line[data-i="${s}"]`);
  if (!p) {
    wt || Ys(t, 0);
    return;
  }
  if (p.classList.add("on"), wt) return;
  const g = p.getBoundingClientRect().top - t.getBoundingClientRect().top + t.scrollTop;
  Ys(t, Math.max(0, g));
}
function Qs(e) {
  wt = !0, Fi(), xe !== void 0 && window.clearTimeout(xe), xe = window.setTimeout(() => {
    xe = void 0, wt = !1, ze = -1, wi(e);
  }, Hn);
}
async function ai(e) {
  try {
    r = await h("music_config_get");
  } catch (t) {
    $(e.querySelector("#music-msg"), R(t));
    return;
  }
  !r.connected && I === "player" && (I = "default", Z(e)), ot(e), rt(e);
}
async function Kc(e) {
  if (Ci === e.id) return;
  Ci = e.id, Ii = !0, X = null;
  const t = Ft;
  t && fi(t);
  try {
    X = await h("lyrics_get", {
      title: e.name,
      artist: e.artists,
      album: e.album,
      duration: e.duration_ms / 1e3
    });
  } catch (i) {
    X = { found: !1, instrumental: !1, track: "", artist: "", album: "", duration: 0, synced: null, plain: null }, t && $(t.querySelector("#music-msg"), R(i));
  } finally {
    Ii = !1, t && (fi(t), wi(t));
  }
}
async function Ui(e, t) {
  if (t === Ze) {
    if (!e.isConnected) {
      $i();
      return;
    }
    if (cc(e), r != null && r.connected) {
      if (!je) {
        if (!document.hidden && !Zt) {
          Zt = !0;
          try {
            if (m = await h("spotify_status"), t !== Ze) return;
            rt(e), Pi(e), wi(e), xc(e), ji(e), Ot(e), je && pi(e);
          } catch (i) {
            if (t !== Ze) return;
            String(i).includes("ERR_NOT_CONNECTED") ? await ai(e) : ($(e.querySelector("#music-msg"), R(i)), pi(e), je && wn(e));
          } finally {
            Zt = !1;
          }
        }
        ce && (m != null && m.track) && m.track.id !== tn && kn(e);
      }
      m != null && m.track && Kc(m.track);
    }
    t === Ze && (Ae = window.setTimeout(() => void Ui(e, t), Vn));
  }
}
function $i() {
  Ae !== void 0 && (window.clearTimeout(Ae), Ae = void 0), Je !== void 0 && (window.clearTimeout(Je), Je = void 0), ei !== void 0 && (window.clearInterval(ei), ei = void 0), Ze++, Zt = !1;
}
function Bi(e) {
  $i();
  const t = Ze;
  Ae = window.setTimeout(() => void Ui(e, t), 200), ei = window.setInterval(() => Jc(e), Un);
}
const Zc = 2e3;
let Xs = 0;
function ea(e) {
  const t = Math.max(400, Zc - (Date.now() - Xs));
  Je !== void 0 && window.clearTimeout(Je), Je = window.setTimeout(() => {
    Je = void 0, !(!e.isConnected || document.hidden) && (Xs = Date.now(), Ae !== void 0 && (window.clearTimeout(Ae), Ae = void 0), Ae = window.setTimeout(() => void Ui(e, Ze), 0));
  }, t);
}
function ta() {
  if (Ns) return;
  Ns = !0, document.addEventListener("visibilitychange", () => {
    const t = Ft;
    !t || !t.isConnected || (document.hidden ? $i() : Bi(t));
  });
  const e = (t) => {
    const i = Ft;
    if (!i || !i.isConnected || document.hidden) return;
    const s = t.target;
    !s || !i.contains(s) || ea(i);
  };
  document.addEventListener("click", e, !0), document.addEventListener("input", e, !0), document.addEventListener("change", e, !0);
}
function Ot(e) {
  document.getElementById("plugin-titlebar") && (st !== void 0 && window.clearTimeout(st), st = window.setTimeout(() => void ia(e), 80));
}
async function ia(e) {
  if (st = void 0, !document.getElementById("plugin-titlebar")) return;
  let t = Nn, i = Pn;
  if (bi()) {
    const a = e.closest(".plugin-result"), c = a == null ? void 0 : a.closest("#results-list");
    if (!a || !c) return;
    const p = getComputedStyle(c), g = parseFloat(p.paddingTop || "0") + parseFloat(p.paddingBottom || "0"), k = window.innerHeight - c.clientHeight;
    i = Math.round(k + g + a.getBoundingClientRect().height), t = Bn;
  }
  const s = `${t}x${i}`;
  if (s !== Di)
    try {
      await h("plugin_window_resize", { width: t, height: i }), Di = s;
    } catch {
    }
}
async function na(e) {
  var Vi, zi, Gi, Yi, Qi, Xi, Ji, Ki, Zi, es, ts, is, ss, ns, cs, as, ls, us, os, rs, ds, ms, ps, fs, vs, hs, bs, ys, gs, _s, ws, $s, ks, Ss, xs, Ls, qs, Es, Ms, Ts, Cs, Is;
  const t = e.querySelector(".music-root");
  if (!t) return;
  Ft = t, ta(), I = "default", Qt = null, Xt = !1, Lt = null, ce = !1, Di = "", Ai = null, ti = "", ii = 0, j = null, it = "", Ri = null, yt.clear(), It.clear(), Ht.clear(), ee = "playlist", S = null, le = null, mt = !1, Ne = "", nt = null, Ie = !1, z = null, ue = "", fe = "", O = null, bt = !1, me = !1, He = !1, we = "tracks", et = [], Q = !1, K = null, ri = !1, gt = "", ve = "", pe = !1, ke.clear(), jt.clear(), $e = !1, U = null, _t = !1, We = "", ae = null, Wt = "", pt = null, vt(), te !== void 0 && (window.clearTimeout(te), te = void 0), _ = null, Pe = [], Se = -1, Xe = !1, J = -1, ht();
  const i = (u) => $(t.querySelector("#music-msg"), u), s = (u) => t.querySelector(u);
  Ke && (Ke(), Ke = null), Ke = await Cn("spotify-auth", (u) => {
    t.isConnected && (u.payload.ok ? (i(n("music.auth_ok")), ai(t).then(() => {
      Bi(t), mi(t, !0);
    })) : i(u.payload.message || n("music.auth_failed")));
  });
  const a = () => {
    I = "player", Z(t);
  }, c = () => {
    I = "default", Z(t);
  }, p = () => {
    I = "settings", Z(t);
  };
  (Vi = s("#music-setup-toggle")) == null || Vi.addEventListener("click", p), (zi = s("#music-resume")) == null || zi.addEventListener("click", () => void zc(t)), (Gi = s("#music-set-back")) == null || Gi.addEventListener("click", c), (Yi = s("#music-tuning-on")) == null || Yi.addEventListener("click", () => {
    E && bc(t, !E.enabled);
  }), (Qi = s("#music-tune-measure")) == null || Qi.addEventListener("click", () => {
    gc(t);
  }), (Xi = s("#music-tuning-preset")) == null || Xi.addEventListener("click", (u) => {
    const o = u.target.closest(".music-seg-btn"), d = o == null ? void 0 : o.dataset.preset;
    d && yc(t, d);
  });
  const g = () => s("#music-tuning-filters");
  (Ji = g()) == null || Ji.addEventListener("click", (u) => {
    const o = u.target.closest("[data-act]"), d = o == null ? void 0 : o.closest(".music-tune-row"), b = Number(d == null ? void 0 : d.dataset.i), v = F[b];
    if (!o || !d || !v) return;
    const y = o.dataset.act;
    if (y === "on")
      v.on = !v.on, Ce(t);
    else if (y === "del")
      F.splice(b, 1), de === b ? de = -1 : de > b && (de -= 1), Ce(t);
    else if (y === "kind")
      de = de === b ? -1 : b, on(t);
    else if (y === "pick") {
      const q = o.dataset.kind;
      if (!q) return;
      hc(v, q, (E == null ? void 0 : E.kinds) ?? []), de = -1, Ce(t);
    }
  }), (Ki = g()) == null || Ki.addEventListener("input", (u) => {
    var _e;
    const o = u.target;
    if (!(o instanceof HTMLInputElement) || o.type !== "range") return;
    const d = o.dataset.f, b = o.closest(".music-tune-row"), v = F[Number(b == null ? void 0 : b.dataset.i)];
    if (!d || !v) return;
    const y = Number.parseFloat(o.value);
    if (!Number.isFinite(y)) return;
    if (d === "gain_db") v.gain_db = y;
    else if (d === "q") v.q = y;
    else return;
    const q = b == null ? void 0 : b.querySelector(`input.music-tune-num[data-f="${d}"]`);
    q && (q.value = Ei(v, d));
    const Y = (_e = o.closest(".music-tune-slider")) == null ? void 0 : _e.querySelector("em");
    Y && (Y.textContent = Ei(v, d)), qt = !0, si(t), js(t);
  }), (Zi = g()) == null || Zi.addEventListener("change", (u) => {
    var Y;
    const o = u.target, d = (Y = o == null ? void 0 : o.dataset) == null ? void 0 : Y.f;
    if (!d) return;
    const b = o.closest(".music-tune-row"), v = F[Number(b == null ? void 0 : b.dataset.i)];
    if (!v) return;
    o.type === "range" && (qt = !1);
    const y = Number.parseFloat(o.value.trim());
    if (!Number.isFinite(y)) {
      o.value = Ei(v, d);
      return;
    }
    let q = !1;
    if (d === "freq_hz")
      q = y !== v.freq_hz, v.freq_hz = y;
    else if (d === "gain_db")
      q = y !== v.gain_db, v.gain_db = y;
    else if (d === "q")
      q = y !== v.q, v.q = y;
    else
      return;
    !q && o.type !== "range" || Ce(t);
  }), (es = s("#music-tune-preamp")) == null || es.addEventListener("change", (u) => {
    const o = u.target, d = Number.parseFloat(o.value.trim());
    if (!Number.isFinite(d)) {
      o.value = ie(tt, 1);
      return;
    }
    d !== tt && (tt = d, Ce(t));
  }), (ts = s("#music-tune-add")) == null || ts.addEventListener("click", () => {
    F.push(Jn()), Ce(t);
  });
  const k = s("#music-tune-canvas"), D = (u, o, d) => {
    var _e;
    const b = Hs(u, o, d), v = Oi;
    if (!b || !v) return null;
    let y = -1, q = 14;
    for (let lt = 0; lt < F.length; lt++) {
      const Yt = F[lt], xn = ((_e = E == null ? void 0 : E.kinds.find((Ln) => Ln.name === Yt.kind)) == null ? void 0 : _e.gain) ?? Yt.gain_db !== void 0, Rs = rn(v, Yt.freq_hz, xn ? Yt.gain_db ?? 0 : 0), As = Math.hypot(Rs.x - b.x, Rs.y - b.y);
      As < q && (q = As, y = lt);
    }
    const Y = b.x >= v.padL - 6 && b.x <= v.padL + v.plotW + 6 && b.y >= v.padT - 6 && b.y <= v.padT + v.plotH + 6;
    return { p: b, idx: y, inside: Y };
  };
  k == null || k.addEventListener("pointerdown", (u) => {
    const o = u.currentTarget, d = D(o, u.clientX, u.clientY);
    if (!d) return;
    let b = d.idx;
    xt = !1, !(b < 0 && !d.inside) && (b < 0 && (F.push({
      kind: "peaking",
      freq_hz: Bs(d.p.f),
      gain_db: Os(d.p.db),
      q: 0.707,
      on: !0
    }), b = F.length - 1, de = -1, xt = !0), ut = b, qt = !0, o.setPointerCapture(u.pointerId), si(t), u.preventDefault());
  }), k == null || k.addEventListener("pointermove", (u) => {
    var Y;
    if (ut < 0) return;
    const o = u.currentTarget, d = F[ut], b = Hs(o, u.clientX, u.clientY);
    if (!d || !b) return;
    const v = ((Y = E == null ? void 0 : E.kinds.find((_e) => _e.name === d.kind)) == null ? void 0 : Y.gain) ?? d.gain_db !== void 0, y = Bs(b.f), q = Os(b.db);
    (y !== d.freq_hz || v && q !== d.gain_db) && (xt = !0), d.freq_hz = y, v && (d.gain_db = q), si(t), js(t), u.preventDefault();
  });
  const x = (u) => {
    var b;
    if (ut < 0) return;
    const o = u.currentTarget, d = xt;
    ut = -1, xt = !1, qt = !1, (b = o.hasPointerCapture) != null && b.call(o, u.pointerId) && o.releasePointerCapture(u.pointerId), Jt = 0, d && Ce(t);
  };
  k == null || k.addEventListener("pointerup", x), k == null || k.addEventListener("pointercancel", x), (is = s("#music-avatar")) == null || is.addEventListener("click", () => {
    I !== "default" && (I = "default", Z(t)), Xt = !Xt, ot(t);
  }), (ss = s("#music-open-player")) == null || ss.addEventListener("click", a), (ns = s("#music-bnow")) == null || ns.addEventListener("click", a);
  const se = (u) => {
    Q !== u && (Q = u, u ? (He = !1, me = !1, S = null, le = null, Ne = "", K = null, U = null, gt = "", We = "", pt = null, ae = null) : (vt(), Wt = "", te !== void 0 && (window.clearTimeout(te), te = void 0), ee = "playlist", _ != null && _.path && !Re && Ct(t)), Z(t), rt(t), u && (vn(t), kt(t), h("media_scan_status").then((o) => {
      !Q || !t.isConnected || (pt = o, o.running && hn(t), qe(t));
    }).catch(() => {
    })));
  }, T = (u) => {
    if (u === "tuning") {
      I = "tuning", Z(t);
      return;
    }
    I = "default", se(u === "local"), Z(t);
  }, Ee = rc(t);
  Ee == null || Ee.addEventListener("click", (u) => {
    const o = u.target.closest(".music-tb-seg"), d = o == null ? void 0 : o.dataset.seg;
    d && T(d);
  }), (cs = s("#music-local-add")) == null || cs.addEventListener("click", () => {
    $e = !$e, Mt(t);
  }), (as = s("#music-local-list")) == null || as.addEventListener("click", () => Rc(t)), (ls = s("#music-local-del")) == null || ls.addEventListener("click", () => Ac(t)), (us = s("#music-local-editdone")) == null || us.addEventListener("click", () => void Dc(t)), (os = s("#music-local-scan")) == null || os.addEventListener("click", () => void Ni(t)), (rs = s("#music-main")) == null || rs.addEventListener("input", (u) => {
    const o = u.target;
    (o == null ? void 0 : o.id) === "music-mt-q" && jc(t, o.value.trim());
  }), (ds = s("#music-l-prev")) == null || ds.addEventListener("click", () => void Tt(t, -1, !1)), (ms = s("#music-l-next")) == null || ms.addEventListener("click", () => void Tt(t, 1, !1)), (ps = s("#music-l-play")) == null || ps.addEventListener("click", () => void Fs(t)), (fs = s("#music-l-stop")) == null || fs.addEventListener("click", () => void Ct(t));
  const N = s("#music-l-vol");
  N == null || N.addEventListener("input", () => {
    ft(N, Number(N.value)), Us(t, Number(N.value) / 100);
  });
  const at = () => {
    const u = ["off", "shuffle", "repeat_all", "repeat_one"];
    G = u[(u.indexOf(G) + 1) % u.length], ic(G), Be(t), L(t, Hi());
  };
  (vs = s("#music-l-mode")) == null || vs.addEventListener("click", at);
  const Me = (u, o) => {
    const d = (y) => {
      const q = u.getBoundingClientRect();
      return Math.max(0, Math.min(1, (y - q.left) / Math.max(1, q.width)));
    }, b = (y) => {
      J = y, u.style.setProperty("--seek-pct", `${y * 100}%`), o(y);
    };
    u.addEventListener("pointerdown", (y) => {
      if (!(((_ == null ? void 0 : _.duration_ms) ?? 0) <= 0)) {
        try {
          u.setPointerCapture(y.pointerId);
        } catch {
        }
        u.classList.add("music-dragging"), b(d(y.clientX));
      }
    }), u.addEventListener("pointermove", (y) => {
      J < 0 || b(d(y.clientX));
    });
    const v = (y) => {
      if (J < 0) return;
      const q = J;
      J = -1, u.classList.remove("music-dragging");
      try {
        u.releasePointerCapture(y.pointerId);
      } catch {
      }
      Hc(t, Math.round(((_ == null ? void 0 : _.duration_ms) ?? 0) * q));
    };
    u.addEventListener("pointerup", v), u.addEventListener("pointercancel", v);
  }, re = s("#music-lbp");
  re && Me(re, (u) => {
    const o = (_ == null ? void 0 : _.duration_ms) ?? 0;
    $(re.querySelector(".music-progress-tip"), Bt(o * u));
    const d = t.querySelector("#music-l-time");
    d && $(d, `${H(o * u)} / ${H(o)}`);
  });
  const be = () => {
    !_ || !_.path || (I = "lplayer", Z(t));
  };
  (hs = s("#music-l-open-player")) == null || hs.addEventListener("click", be), (bs = s("#music-lp-prev")) == null || bs.addEventListener("click", () => void Tt(t, -1, !1)), (ys = s("#music-lp-next")) == null || ys.addEventListener("click", () => void Tt(t, 1, !1)), (gs = s("#music-lp-play")) == null || gs.addEventListener("click", () => void Fs(t)), (_s = s("#music-lp-stop")) == null || _s.addEventListener("click", () => void Ct(t)), (ws = s("#music-lp-mode")) == null || ws.addEventListener("click", at);
  const P = s("#music-lp-vol");
  P == null || P.addEventListener("input", () => {
    ft(P, Number(P.value)), Us(t, Number(P.value) / 100);
  });
  const ye = s("#music-lp-progress");
  ye && Me(ye, (u) => {
    const o = (_ == null ? void 0 : _.duration_ms) ?? 0;
    $(ye.querySelector(".music-progress-tip"), Bt(o * u));
    const d = t.querySelector("#music-lp-time");
    d && $(d, `${H(o * u)} / ${H(o)}`);
  });
  const ki = (u) => {
    var o;
    !t.isConnected || !bi() || (o = u.target) != null && o.closest("#plugin-close") && (u.stopPropagation(), u.preventDefault(), I === "lplayer" ? c() : pc(t));
  };
  document.addEventListener("click", ki, !0), ($s = s("#music-fields-toggle")) == null || $s.addEventListener("click", () => {
    Qt = !(Qt ?? !(r != null && r.builtin)), ot(t);
  }), (ks = s("#music-copy-redirect")) == null || ks.addEventListener("click", () => {
    const u = (r == null ? void 0 : r.redirect_uri) || "";
    u && Rn(u).then(() => i(n("music.copied"))).catch(() => {
    });
  });
  for (const u of t.querySelectorAll("#music-quality .music-seg-btn"))
    u.addEventListener("click", () => {
      Lt = Number(u.dataset.q), ot(t);
    });
  (Ss = s("#music-set-save")) == null || Ss.addEventListener("click", async () => {
    try {
      r = await h("music_config_set", { librespotBitrate: Lt }), Lt = null, i(n("music.saved")), ot(t), rt(t);
    } catch (u) {
      i(R(u));
    }
  }), (xs = s("#music-save")) == null || xs.addEventListener("click", async () => {
    var b, v, y, q;
    const u = ((b = s("#music-client-id")) == null ? void 0 : b.value.trim()) ?? "", o = ((v = s("#music-port")) == null ? void 0 : v.value.trim()) ?? "", d = Number(o);
    if (!u) {
      i(n("music.err_no_client_id"));
      return;
    }
    if (!Number.isInteger(d) || d < 1024 || d > 65535) {
      i(n("music.err_bad_port"));
      return;
    }
    try {
      r = await h("music_config_set", {
        clientId: u,
        port: d,
        // 本机播放那两项**一起交上去**（留空 = 自动探测 / 直连，都是合法值）
        librespotPath: ((y = s("#music-librespot")) == null ? void 0 : y.value.trim()) ?? "",
        librespotProxy: ((q = s("#music-librespot-proxy")) == null ? void 0 : q.value.trim()) ?? ""
        // 音质**不在这里提交**（2026-10-01 起它归设置页，那个页面有自己的「保存」）：
        // 不传 = `None` = 别动，宿主本来就是这个语义。把两页的保存混在一处，
        // 就会出现「在设置页点了 320、回连接卡片点保存、结果把它一起落盘了」。
      }), i(n("music.saved")), ot(t), rt(t), z = null;
    } catch (Y) {
      i(R(Y));
    }
  }), (Ls = s("#music-connect")) == null || Ls.addEventListener("click", async () => {
    var d, b;
    const u = ((d = s("#music-client-id")) == null ? void 0 : d.value.trim()) ?? "", o = Number(((b = s("#music-port")) == null ? void 0 : b.value.trim()) ?? "");
    if (u && Number.isInteger(o) && o >= 1024)
      try {
        r = await h("music_config_set", {
          clientId: u,
          port: o,
          librespotPath: null,
          librespotProxy: null,
          // 串流质量同上：这条路径只是「先落盘再连」，别动用户选的档
          librespotBitrate: null
        });
      } catch (v) {
        i(R(v));
        return;
      }
    try {
      const v = await h("spotify_connect");
      i(n("music.browser_hint")), await In(v);
    } catch (v) {
      i(R(v));
    }
  }), (qs = s("#music-disconnect")) == null || qs.addEventListener("click", async () => {
    try {
      await h("spotify_disconnect"), m = null, X = null, Ci = "", Ri = null, yt.clear(), Ht.clear(), Qe = null, ce = !1, S = null, le = null, Ne = "", O = null, fe = "", me = !1, He = !1, nt = null, I = "default", await ai(t), Z(t), ci(t), i(n("music.disconnected"));
    } catch (u) {
      i(R(u));
    }
  });
  const Oe = (u) => {
    var v;
    const o = (v = u.target) == null ? void 0 : v.closest("[data-act]");
    if (!o) return;
    const d = o.dataset.kind || "", b = o.dataset.id || "";
    switch (o.dataset.act) {
      case "side-tab":
        ee = o.dataset.tab || "playlist", ct(t), _n(t, ee);
        break;
      case "search-tab":
        we = o.dataset.tab || "tracks", oe(t);
        break;
      case "open":
        Wc(t, d, b);
        break;
      case "main-track":
        Fc(t, Number(o.dataset.i || "0"));
        break;
      case "main-play-all":
        S && zs(t, S.kind, S.id);
        break;
      case "dd-track":
        o.dataset.uri && Js(t, o.dataset.uri);
        break;
      case "play-uri":
        o.dataset.uri && Js(t, o.dataset.uri);
        break;
      case "search-all":
        me = !1, He = !0, Le(t), oe(t);
        break;
      case "dev-pick":
        Qc(t, b);
        break;
      case "local-toggle":
        Gc(t);
        break;
      case "local-login":
        Yc(t);
        break;
      // ── 本地音乐页（2026-10-01）──
      case "media-root": {
        const y = o.dataset.path || "";
        if (pe) {
          y && (ke.has(y) ? ke.delete(y) : ke.add(y)), Fe(t);
          break;
        }
        ve = y, Fe(t), kt(t);
        break;
      }
      case "media-scan":
        Ni(t);
        break;
      // `＋` 浮层里的两行（2026-10-01）：目录 vs 播放列表文件。
      // **先关浮层再干活** —— 目录对话框是模态的，浮层留着会在对话框背后一闪一闪。
      case "media-add-dir":
        $e = !1, Mt(t), Cc(t);
        break;
      case "media-add-list":
        $e = !1, Mt(t), Pc(t);
        break;
      case "media-list-close":
        Bc(t);
        break;
      case "local-track":
        Oc(t, Number(o.dataset.i || "0"));
        break;
    }
  };
  for (const u of ["#music-side-list", "#music-side-tabs", "#music-main", "#music-search-dd", "#music-dev-dd", "#music-q", "#music-q-dd", "#music-local-add-dd"])
    (Es = s(u)) == null || Es.addEventListener("click", Oe);
  (Ms = s("#music-side-list")) == null || Ms.addEventListener("dblclick", (u) => {
    var v;
    const o = (v = u.target) == null ? void 0 : v.closest('[data-act="open"]');
    if (!o) return;
    const d = o.dataset.kind || "", b = o.dataset.id || "";
    b && zs(t, d, b);
  }), (Ts = s("#music-devices-btn")) == null || Ts.addEventListener("click", () => {
    Ie = !Ie, $t(t), Ie && St(t);
  }), Vs(t), (Cs = s("#music-split")) == null || Cs.addEventListener("pointerdown", (u) => {
    var y;
    u.preventDefault();
    const o = u.clientX, d = ((y = s("#music-side")) == null ? void 0 : y.getBoundingClientRect().width) ?? Rt, b = (q) => {
      Rt = Math.min(en, Math.max(Zs, Math.round(d + q.clientX - o))), Vs(t);
    }, v = () => {
      window.removeEventListener("pointermove", b), window.removeEventListener("pointerup", v), document.body.classList.remove("music-resizing");
    };
    document.body.classList.add("music-resizing"), window.addEventListener("pointermove", b), window.addEventListener("pointerup", v);
  }), document.addEventListener("pointerdown", (u) => {
    const o = u.target;
    o && (Ie && !o.closest("#music-dev-dd") && !o.closest("#music-devices-btn") && (Ie = !1, $t(t)), me && !o.closest(".music-search-wrap") && (me = !1, Le(t)), $e && !o.closest("#music-local-add-dd") && !o.closest("#music-local-add") && ($e = !1, Mt(t)), ce && !o.closest("#music-q-dd") && !o.closest("#music-b-queue") && !o.closest("#music-queue-btn") && (ce = !1, Ti(t)));
  });
  const B = s("#music-search");
  B == null || B.addEventListener("input", () => Gs(t, B.value.trim())), B == null || B.addEventListener("focus", () => {
    fe && (me = !0, Le(t));
  }), B == null || B.addEventListener("keydown", (u) => {
    if (u.key === "Enter" && fe) {
      me = !1, He = !0, Le(t), oe(t);
      return;
    }
    u.key === "Escape" && (B.value = "", Gs(t, ""));
  }), document.body.addEventListener("mouseenter", () => Ot(t)), document.body.addEventListener("mouseleave", () => Ot(t));
  const Te = async (u, o) => {
    u === "play" && await zt(t, "spotify");
    try {
      await h("spotify_control", { action: u, value: o });
    } catch (d) {
      i(R(d));
    }
  }, ne = (u, o) => {
    var d;
    for (const b of u) (d = s(`#${b}`)) == null || d.addEventListener("click", o);
  };
  ne(["music-queue-btn", "music-b-queue"], () => {
    ce = !ce, Ti(t), ci(t), ce ? kn(t) : Pi(t), Ot(t);
  }), ne(["music-prev", "music-b-prev"], () => void Te("previous")), ne(["music-next", "music-b-next"], () => void Te("next")), ne(["music-play", "music-b-play"], () => void Te(m != null && m.playing ? "pause" : "play")), ne(["music-dual-btn", "music-l-dual-btn"], () => {
    Re = !Re, ec(Re), !Re && !Q && _ && Ct(t), Be(t), ji(t), L(t, n(Re ? "music.dual_on" : "music.dual_off"));
  });
  let A = null, V = !1;
  const ge = async (u) => {
    if (A = u, !V) {
      V = !0;
      try {
        for (; A !== null; ) {
          const o = A;
          A = null, await Te("volume", o);
        }
      } finally {
        V = !1;
      }
    }
  };
  for (const u of ["music-vol", "music-b-vol"])
    (Is = s(`#${u}`)) == null || Is.addEventListener("input", (o) => {
      const d = o.target, b = Number(d.value);
      ft(d, b), ge(b);
    });
  ne(["music-mode", "music-b-mode"], () => {
    const u = Sn();
    h("spotify_set_play_mode", { mode: u === "off" ? "shuffle" : u === "shuffle" ? "repeat_one" : "off" }).catch((d) => i(R(d)));
  }), et = ["#music-pv-progress", "#music-bp"].map((u) => s(u)).filter((u) => !!u);
  for (const u of et) {
    const o = (v) => {
      const y = u.getBoundingClientRect();
      return Math.max(0, Math.min(1, (v - y.left) / Math.max(1, y.width)));
    }, d = (v) => {
      var _e;
      Ve = v;
      const y = `${v * 100}%`;
      for (const lt of et) lt.style.setProperty("--seek-pct", y);
      const q = ((_e = m == null ? void 0 : m.track) == null ? void 0 : _e.duration_ms) ?? 0, Y = H(q * v);
      $(u.querySelector(".music-progress-tip"), Bt(q * v)), $(s("#music-pv-pos"), Y), $(s("#music-b-time"), `${Y} / ${H(q)}`);
    };
    u.addEventListener("pointerdown", (v) => {
      var y;
      if (!((((y = m == null ? void 0 : m.track) == null ? void 0 : y.duration_ms) ?? 0) <= 0)) {
        try {
          u.setPointerCapture(v.pointerId);
        } catch {
        }
        u.classList.add("music-dragging"), d(o(v.clientX));
      }
    }), u.addEventListener("pointermove", (v) => {
      Ve < 0 || d(o(v.clientX));
    });
    const b = (v) => {
      var q;
      if (Ve < 0) return;
      const y = Ve;
      Ve = -1, u.classList.remove("music-dragging");
      try {
        u.releasePointerCapture(v.pointerId);
      } catch {
      }
      Te("seek", Math.round((((q = m == null ? void 0 : m.track) == null ? void 0 : q.duration_ms) ?? 0) * y));
    };
    u.addEventListener("pointerup", b), u.addEventListener("pointercancel", b);
  }
  const W = s("#music-lyr");
  let Ue = !1, Gt = 0;
  W == null || W.addEventListener("wheel", () => Qs(t), { passive: !0 }), W == null || W.addEventListener("pointerdown", (u) => {
    Ue = !1, Gt = u.clientY, Qs(t);
  }), W == null || W.addEventListener("pointermove", (u) => {
    Math.abs(u.clientY - Gt) > 4 && (Ue = !0);
  }), W == null || W.addEventListener("click", (u) => {
    if (Ue) return;
    const o = u.target.closest(".music-lyr-line"), d = o ? dt[Number(o.dataset.i)] : void 0;
    d && Te("seek", Math.round(d.at * 1e3));
  }), await ai(t), Z(t), Pi(t), fi(t), ci(t), Ti(t), rt(t), await wn(t), Bi(t), mi(t);
}
async function Js(e, t) {
  await zt(e, "spotify");
  try {
    await h("spotify_play_uri", { uri: t, deviceId: ue || void 0 });
  } catch (i) {
    $(e.querySelector("#music-msg"), R(i));
  }
}
function sa() {
  $i(), Ft = null, xe !== void 0 && (window.clearTimeout(xe), xe = void 0), st !== void 0 && (window.clearTimeout(st), st = void 0), vt(), te !== void 0 && (window.clearTimeout(te), te = void 0), ht(), _ != null && _.path && (_ = null, Pe = [], Se = -1, h("player_stop").catch(() => {
  })), Ke && (Ke(), Ke = null), et = [], uc(), mc();
}
window.__lunac_music_stop = sa;
const ca = {
  id: "music",
  name: "音乐歌词",
  keywords: ["音乐", "歌词", "歌曲", "正在播放", "music", "lyrics", "spotify", "播放控制", "暂停", "下一首", "歌单", "播放列表"],
  description: "歌词自动抓取 (LRCLIB + 网易云兜底) + Spotify 播放控制 / 歌单 / 队列",
  icon: "🎵",
  badge: "music",
  // 「本插件一律在**悬浮窗**里打开」（2026-09-29 从 main.ts 的硬编码 `id === "music"` 改成声明）。
  // 为什么要声明而不是让宿主按 id 判：音乐已归入**拓展插件**，要能从市场独立打包分发
  // —— 磁盘插件的代码宿主没法写死，行为只能由插件自己声明（见 ai-spec §3.5「插件契约」）。
  // 这也是「用户 2026-09-28 定的：从 Lunac 进音乐界面时自动展开成独立界面」那条的执行点。
  permissions: ["window.float"],
  async execute() {
    return { type: "html", content: nc() };
  }
};
export {
  na as attach,
  na as attachMusicListeners,
  ca as default,
  sa as detach,
  ca as musicPlugin,
  sa as stopMusicPolling
};
