function C(t, e = !1) {
  return window.__TAURI_INTERNALS__.transformCallback(t, e);
}
async function u(t, e = {}, n) {
  return window.__TAURI_INTERNALS__.invoke(t, e, n);
}
function b(t, e = "asset") {
  return window.__TAURI_INTERNALS__.convertFileSrc(t, e);
}
var x;
(function(t) {
  t.WINDOW_RESIZED = "tauri://resize", t.WINDOW_MOVED = "tauri://move", t.WINDOW_CLOSE_REQUESTED = "tauri://close-requested", t.WINDOW_DESTROYED = "tauri://destroyed", t.WINDOW_FOCUS = "tauri://focus", t.WINDOW_BLUR = "tauri://blur", t.WINDOW_SCALE_FACTOR_CHANGED = "tauri://scale-change", t.WINDOW_THEME_CHANGED = "tauri://theme-changed", t.WINDOW_CREATED = "tauri://window-created", t.WINDOW_SUSPENDED = "tauri://suspended", t.WINDOW_RESUMED = "tauri://resumed", t.WEBVIEW_CREATED = "tauri://webview-created", t.DRAG_ENTER = "tauri://drag-enter", t.DRAG_OVER = "tauri://drag-over", t.DRAG_DROP = "tauri://drag-drop", t.DRAG_LEAVE = "tauri://drag-leave";
})(x || (x = {}));
async function I(t, e) {
  window.__TAURI_EVENT_PLUGIN_INTERNALS__.unregisterListener(t, e), await u("plugin:event|unlisten", {
    event: t,
    eventId: e
  });
}
async function _(t, e, n) {
  var a;
  const c = (a = void 0) !== null && a !== void 0 ? a : { kind: "Any" };
  return u("plugin:event|listen", {
    event: t,
    target: c,
    handler: C(e)
  }).then((i) => async () => I(t, i));
}
const $ = "__lunac_host";
function B() {
  return globalThis[$] ?? null;
}
function r(t, e) {
  const n = B();
  return n && typeof n.t == "function" ? n.t(t, e) : t;
}
const m = class m {
  constructor() {
    this.lastBytes = 0, this.lastAt = 0, this.speed = 0, this.primed = !1;
  }
  push(e, n, a = Date.now()) {
    const c = n > 0 ? Math.min(100, Math.round(e / n * 100)) : -1;
    if (!this.primed)
      return this.primed = !0, this.lastBytes = e, this.lastAt = a, { percent: c, speed: 0, downloaded: e, total: n };
    const i = (a - this.lastAt) / 1e3;
    if (i >= m.MIN_DT) {
      const o = Math.max(0, (e - this.lastBytes) / i);
      this.speed = this.speed === 0 ? o : this.speed * 0.65 + o * 0.35, this.lastBytes = e, this.lastAt = a;
    }
    return { percent: c, speed: this.speed, downloaded: e, total: n };
  }
  reset() {
    this.lastBytes = 0, this.lastAt = 0, this.speed = 0, this.primed = !1;
  }
};
m.MIN_DT = 0.4;
let y = m;
function D(t) {
  if (!(t > 0)) return "0 B";
  const e = ["B", "KB", "MB", "GB"];
  let n = t, a = 0;
  for (; n >= 1024 && a < e.length - 1; )
    n /= 1024, a++;
  return `${n >= 100 || a === 0 ? Math.round(n) : n.toFixed(1)} ${e[a]}`;
}
function L(t) {
  return t > 0 ? `${D(t)}/s` : "—";
}
function R(t) {
  return `
    <span class="dl-ring-wrap is-unknown">
      <svg class="dl-ring" viewBox="0 0 36 36" aria-hidden="true">
        <circle class="dl-ring-track" cx="18" cy="18" r="15.5" pathLength="100"></circle>
        <circle class="dl-ring-fill" cx="18" cy="18" r="15.5" pathLength="100"
                style="stroke-dashoffset:100"></circle>
      </svg>
      <span class="dl-ring-pct"></span>
    </span>`;
}
function S(t, e) {
  const n = t.querySelector(".dl-ring-wrap"), a = t.querySelector(".dl-ring-fill"), c = t.querySelector(".dl-ring-pct");
  if (!n || !a) return !1;
  const i = e >= 0;
  return n.classList.toggle("is-unknown", !i), a.style.strokeDashoffset = String(i ? 100 - Math.max(0, Math.min(100, e)) : 100), c && (c.textContent = i ? String(Math.round(e)) : ""), !0;
}
function N(t) {
  return new Promise((e) => {
    let n;
    const a = new y();
    (async () => {
      try {
        n = await _("plugin-install-progress", (i) => {
          const o = i.payload;
          o.id === "ocr" && (t == null || t({ ...a.push(o.downloaded, o.total), phase: o.phase }));
        });
      } catch {
      }
      let c = !1;
      try {
        await u("install_plugin_dependencies", { id: "ocr" }), c = !0;
      } catch {
        c = !1;
      } finally {
        try {
          n == null || n();
        } catch {
        }
      }
      e(c);
    })();
  });
}
function O(t) {
  if (!t) return;
  t.innerHTML = `${r("ocr.engine_missing")} `;
  const e = document.createElement("button");
  e.className = "ocr-action-btn ocr-primary-btn", e.style.marginLeft = "6px", e.textContent = r("ocr.engine_download"), e.addEventListener("click", async () => {
    e.disabled = !0;
    const n = document.createElement("span");
    n.className = "dl-inline", n.style.marginLeft = "6px", n.innerHTML = R() + `<span class="dl-meta">
         <span class="dl-phase">${r("ocr.engine_downloading_unknown").replace("{mb}", "0")}</span>
         <span class="dl-speed">—</span>
       </span>`, e.replaceWith(n);
    const a = n.querySelector(".dl-phase"), c = n.querySelector(".dl-speed"), i = await N(({ percent: s, speed: l, downloaded: d }) => {
      S(n, s), a && (a.textContent = s >= 0 ? r("ocr.engine_downloading").replace("{percent}", String(s)) : r("ocr.engine_downloading_unknown").replace("{mb}", (d / 1048576).toFixed(1))), c && (c.textContent = L(l));
    });
    n.remove();
    let o = !1;
    if (i)
      try {
        o = await u("ocr_engine_status");
      } catch {
        o = !1;
      }
    o ? t.textContent = r("ocr.engine_ready") : i ? t.textContent = r("ocr.engine_not_declared") : t.textContent = r("ocr.engine_failed");
  }), t.appendChild(e);
}
async function f(t) {
  try {
    if (await u("ocr_engine_status")) return !0;
  } catch {
    return !0;
  }
  return O(t), !1;
}
async function v() {
  try {
    const t = await u("read_clipboard_files");
    if (t.length > 0)
      return `__file__${t[0]}`;
  } catch {
  }
  try {
    const t = await u("read_clipboard_backup_image");
    if (t) {
      const e = t.lastIndexOf("|");
      return `__file__${e > 0 ? t.substring(0, e) : t}`;
    }
  } catch {
  }
  return null;
}
function A(t) {
  return new Promise((e, n) => {
    const a = new FileReader();
    a.onload = () => e(a.result), a.onerror = () => n(new Error("Failed to read blob")), a.readAsDataURL(t);
  });
}
async function W(t) {
  return { text: (await u("run_paddle_ocr", { path: t })).trim() };
}
async function h(t) {
  const e = await u("save_temp_image", { dataUrl: t }), n = await u("run_paddle_ocr", { path: e });
  return u("delete_temp_image", { path: e }).catch(() => {
  }), { text: n.trim() };
}
async function M(t) {
  return b(t);
}
const F = {
  id: "ocr",
  name: "OCR 文字识别",
  keywords: [
    "ocr",
    "识别",
    "文字识别",
    "图像识别",
    "图片转文字",
    "截图识别",
    "图识字",
    "文字提取"
  ],
  description: "OCR 图片文字识别 (PaddleOCR · 离线高精度)",
  icon: "🔍",
  badge: "AI",
  // 接管整个窗口（双栏：左图右文）。宿主据此决定「不套 .plugin-result、直接 detach、
  // 把 attach 的 root 传成文档根」—— 见 main.ts 的 isTakeoverPlugin()。
  permissions: ["layout.takeover"],
  async execute(t) {
    return { type: "html", content: k() };
  }
};
function k() {
  return `
    <div class="ocr-detached-layout">
      <!-- 左半：图片预览 -->
      <div class="ocr-image-panel">
        <div id="ocr-image-preview" class="ocr-image-preview">
          <span class="ocr-image-placeholder">${r("ocr.no_image")}</span>
        </div>
        <div class="ocr-image-actions">
          <button id="ocr-screen-btn" class="ocr-action-btn">
            ${r("ocr.screen_btn")}
          </button>
          <button id="ocr-clipboard-btn" class="ocr-action-btn ocr-primary-btn">
            ${r("ocr.clipboard_btn")}
          </button>
          <button id="ocr-file-btn" class="ocr-action-btn">
            ${r("ocr.file_btn")}
          </button>
        </div>
      </div>

      <!-- 右半：文字编辑区 -->
      <div class="ocr-text-panel">
        <div id="ocr-status-line" class="ocr-status-line">
          ${r("ocr.default_status")}
        </div>
        <button id="ocr-copy-btn" class="ocr-copy-btn">${r("ocr.copy_btn")}</button>
        <textarea
          id="ocr-result" class="ocr-textarea"
          spellcheck="false"
          placeholder="${r("ocr.placeholder")}"
        ></textarea>
      </div>
    </div>`;
}
async function H() {
  const t = document.getElementById("ocr-status-line"), e = document.getElementById("ocr-result"), n = document.getElementById("ocr-image-preview");
  t && (t.textContent = r("ocr.reading"));
  const a = await v();
  if (!a) {
    t && (t.textContent = r("ocr.no_clipboard"));
    return;
  }
  if (a.startsWith("__file__")) {
    const c = a.slice(8);
    await w(c);
    return;
  }
  if (n && (n.innerHTML = `<img src="${a}" class="ocr-preview-img" alt="Clipboard image" />`), !!await f(t)) {
    t && (t.textContent = r("ocr.recognizing"));
    try {
      const c = await h(a);
      t && (t.textContent = r("ocr.done")), e && (e.value = c.text || r("ocr.no_text"), e.style.height = "auto", e.style.height = Math.max(e.scrollHeight, 120) + "px");
    } catch (c) {
      t && (t.textContent = `${r("ocr.failed")}${c}`);
    }
  }
}
async function w(t) {
  const e = document.getElementById("ocr-status-line"), n = document.getElementById("ocr-result"), a = document.getElementById("ocr-image-preview");
  if (e && (e.textContent = r("ocr.loading_image")), !!await f(e)) {
    if (a)
      try {
        const c = await M(t);
        a.innerHTML = `<img src="${c}" class="ocr-preview-img" alt="OCR image" onerror="this.parentElement!.innerHTML='<span class=\\'ocr-image-placeholder\\'>${r("ocr.load_failed").replace("'", "\\'")}</span>'" />`;
      } catch {
        a.innerHTML = `<img src="${b(t)}" class="ocr-preview-img" alt="OCR image" onerror="this.parentElement!.innerHTML='<span class=\\'ocr-image-placeholder\\'>${t.split("\\").pop()}</span>'" />`;
      }
    e && (e.textContent = r("ocr.recognizing"));
    try {
      const c = await W(t);
      e && (e.textContent = r("ocr.done")), n && (n.value = c.text || r("ocr.no_text"), n.style.height = "auto", n.style.height = Math.max(n.scrollHeight, 120) + "px");
    } catch (c) {
      e && (e.textContent = `${r("ocr.failed")}${c}`);
    }
  }
}
async function T(t, e, n, a) {
  if (a && (a.innerHTML = `<img src="${t}" class="ocr-preview-img" alt="Screen capture" />`), n && (n.value = ""), !!await f(e)) {
    e && (e.textContent = r("ocr.recognizing"));
    try {
      const c = await h(t);
      e && (e.textContent = r("ocr.done")), n && (n.value = c.text || r("ocr.no_text"), n.style.height = "auto", n.style.height = Math.max(n.scrollHeight, 120) + "px");
    } catch (c) {
      e && (e.textContent = `${r("ocr.failed")}${c}`);
    }
  }
}
function U(t) {
  var e, n, a, c;
  (e = t.getElementById("ocr-screen-btn")) == null || e.addEventListener("click", async () => {
    const i = t.getElementById("ocr-status-line"), o = t.getElementById("ocr-result"), s = t.getElementById("ocr-image-preview");
    i && (i.textContent = r("ocr.shot_capturing"));
    const l = [], d = () => {
      for (const p of l) p();
      l.length = 0;
    };
    l.push(
      await _("screenshot-overlay-done", (p) => {
        d(), T(p.payload.dataUrl, i, o, s);
      })
    ), l.push(
      await _("screenshot-overlay-cancelled", () => {
        d(), i && (i.textContent = r("ocr.default_status"));
      })
    );
    try {
      await u("screenshot_overlay_begin");
    } catch (p) {
      d(), i && (i.textContent = `${r("ocr.shot_failed")}${p}`);
    }
  }), (n = t.getElementById("ocr-clipboard-btn")) == null || n.addEventListener("click", async () => {
    const i = t.getElementById("ocr-status-line"), o = t.getElementById("ocr-result"), s = t.getElementById("ocr-image-preview");
    i && (i.textContent = r("ocr.reading")), o && (o.value = "");
    const l = await v();
    if (!l) {
      i && (i.textContent = r("ocr.no_clipboard"));
      return;
    }
    if (l.startsWith("__file__")) {
      await w(l.slice(8));
      return;
    }
    if (s && (s.innerHTML = `<img src="${l}" class="ocr-preview-img" alt="Clipboard image" />`), !!await f(i)) {
      i && (i.textContent = r("ocr.recognizing"));
      try {
        const d = await h(l);
        i && (i.textContent = r("ocr.done")), o && (o.value = d.text || r("ocr.no_text"), o.style.height = "auto", o.style.height = Math.max(o.scrollHeight, 120) + "px");
      } catch (d) {
        i && (i.textContent = `${r("ocr.failed")}${d}`);
      }
    }
  }), (a = t.getElementById("ocr-file-btn")) == null || a.addEventListener("click", () => {
    const i = document.createElement("input");
    i.type = "file", i.accept = "image/*", i.style.display = "none", i.onchange = async () => {
      var p;
      const o = (p = i.files) == null ? void 0 : p[0];
      if (!o) return;
      const s = t.getElementById("ocr-status-line"), l = t.getElementById("ocr-result"), d = t.getElementById("ocr-image-preview");
      if (await f(s)) {
        s && (s.textContent = r("ocr.recognizing")), l && (l.value = "");
        try {
          const g = await A(o);
          d && (d.innerHTML = `<img src="${g}" class="ocr-preview-img" alt="Selected image" />`);
          const E = await h(g);
          s && (s.textContent = r("ocr.done")), l && (l.value = E.text || r("ocr.no_text"), l.style.height = "auto", l.style.height = Math.max(l.scrollHeight, 120) + "px");
        } catch (g) {
          s && (s.textContent = `${r("ocr.failed")}${g}`);
        }
      }
    }, document.body.appendChild(i), i.click();
  }), (c = t.getElementById("ocr-copy-btn")) == null || c.addEventListener("click", () => {
    const i = t.getElementById("ocr-result"), o = (i == null ? void 0 : i.value) || "";
    navigator.clipboard.writeText(o).then(() => {
      const s = t.getElementById("ocr-copy-btn");
      s && (s.textContent = r("ocr.copied"), s.classList.add("ocr-copied"), setTimeout(() => {
        s.textContent = r("ocr.copy_btn"), s.classList.remove("ocr-copied");
      }, 1500));
    }).catch(() => {
      const s = t.getElementById("ocr-result");
      s && s.select();
    });
  });
}
async function G(t) {
  U(document);
  const e = window.__lunac_ocr_image;
  e ? (delete window.__lunac_ocr_image, await w(e)) : await H();
}
export {
  G as attach,
  U as attachOcrListeners,
  H as autoStartClipboardOcr,
  F as default,
  w as ocrImageFile,
  F as ocrPlugin
};
