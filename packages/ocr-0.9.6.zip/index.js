function x(t, e = !1) {
  return window.__TAURI_INTERNALS__.transformCallback(t, e);
}
async function l(t, e = {}, i) {
  return window.__TAURI_INTERNALS__.invoke(t, e, i);
}
function h(t, e = "asset") {
  return window.__TAURI_INTERNALS__.convertFileSrc(t, e);
}
const b = "__lunac_host";
function I() {
  return globalThis[b] ?? null;
}
function r(t, e) {
  const i = I();
  return i && typeof i.t == "function" ? i.t(t, e) : t;
}
var y;
(function(t) {
  t.WINDOW_RESIZED = "tauri://resize", t.WINDOW_MOVED = "tauri://move", t.WINDOW_CLOSE_REQUESTED = "tauri://close-requested", t.WINDOW_DESTROYED = "tauri://destroyed", t.WINDOW_FOCUS = "tauri://focus", t.WINDOW_BLUR = "tauri://blur", t.WINDOW_SCALE_FACTOR_CHANGED = "tauri://scale-change", t.WINDOW_THEME_CHANGED = "tauri://theme-changed", t.WINDOW_CREATED = "tauri://window-created", t.WINDOW_SUSPENDED = "tauri://suspended", t.WINDOW_RESUMED = "tauri://resumed", t.WEBVIEW_CREATED = "tauri://webview-created", t.DRAG_ENTER = "tauri://drag-enter", t.DRAG_OVER = "tauri://drag-over", t.DRAG_DROP = "tauri://drag-drop", t.DRAG_LEAVE = "tauri://drag-leave";
})(y || (y = {}));
async function C(t, e) {
  window.__TAURI_EVENT_PLUGIN_INTERNALS__.unregisterListener(t, e), await l("plugin:event|unlisten", {
    event: t,
    eventId: e
  });
}
async function g(t, e, i) {
  var o;
  const n = (o = void 0) !== null && o !== void 0 ? o : { kind: "Any" };
  return l("plugin:event|listen", {
    event: t,
    target: n,
    handler: x(e)
  }).then((c) => async () => C(t, c));
}
function v(t) {
  return new Promise((e) => {
    const i = [], o = () => {
      for (const n of i)
        try {
          n();
        } catch {
        }
    };
    (async () => {
      i.push(await g("ocr-engine-progress", (n) => {
        const { downloaded: c, total: a } = n.payload;
        t == null || t({
          percent: a > 0 ? Math.round(c / a * 100) : 0,
          mb: c / 1048576
        });
      })), i.push(await g("ocr-engine-ready", () => {
        o(), e(!0);
      })), i.push(await g("ocr-engine-error", () => {
        o(), e(!1);
      }));
      try {
        await l("ocr_engine_install");
      } catch {
        o(), e(!1);
      }
    })();
  });
}
function D(t) {
  if (!t) return;
  t.innerHTML = `${r("ocr.engine_missing")} `;
  const e = document.createElement("button");
  e.className = "ocr-action-btn ocr-primary-btn", e.style.marginLeft = "6px", e.textContent = r("ocr.engine_download"), e.addEventListener("click", async () => {
    e.disabled = !0, e.textContent = r("ocr.engine_downloading").replace("{percent}", "0");
    const i = await v(({ percent: o, mb: n }) => {
      e.textContent = o > 0 ? r("ocr.engine_downloading").replace("{percent}", String(o)) : r("ocr.engine_downloading_unknown").replace("{mb}", n.toFixed(1));
    });
    t.textContent = i ? `${r("ocr.engine_ready")}` : `${r("ocr.engine_failed")}`;
  }), t.appendChild(e);
}
async function p(t) {
  try {
    if (await l("ocr_engine_status")) return !0;
  } catch {
    return !0;
  }
  return D(t), !1;
}
async function w() {
  try {
    const t = await l("read_clipboard_files");
    if (t.length > 0)
      return `__file__${t[0]}`;
  } catch {
  }
  try {
    const t = await l("read_clipboard_backup_image");
    if (t) {
      const e = t.lastIndexOf("|");
      return `__file__${e > 0 ? t.substring(0, e) : t}`;
    }
  } catch {
  }
  return null;
}
function R(t) {
  return new Promise((e, i) => {
    const o = new FileReader();
    o.onload = () => e(o.result), o.onerror = () => i(new Error("Failed to read blob")), o.readAsDataURL(t);
  });
}
async function O(t) {
  return { text: (await l("run_paddle_ocr", { path: t })).trim() };
}
async function _(t) {
  const e = await l("save_temp_image", { dataUrl: t }), i = await l("run_paddle_ocr", { path: e });
  return l("delete_temp_image", { path: e }).catch(() => {
  }), { text: i.trim() };
}
async function L(t) {
  return h(t);
}
const A = {
  id: "ocr",
  name: "OCR 文字识别",
  keywords: [
    "ocr",
    "识别",
    "文字识别",
    "图像识别",
    "图片转文字",
    "截图识别",
    "图识字",
    "文字提取"
  ],
  description: "OCR 图片文字识别 (PaddleOCR · 离线高精度)",
  icon: "🔍",
  badge: "AI",
  // 接管整个窗口（双栏：左图右文）。宿主据此决定「不套 .plugin-result、直接 detach、
  // 把 attach 的 root 传成文档根」—— 见 main.ts 的 isTakeoverPlugin()。
  permissions: ["layout.takeover"],
  async execute(t) {
    return { type: "html", content: N() };
  }
};
function N() {
  return `
    <div class="ocr-detached-layout">
      <!-- 左半：图片预览 -->
      <div class="ocr-image-panel">
        <div id="ocr-image-preview" class="ocr-image-preview">
          <span class="ocr-image-placeholder">${r("ocr.no_image")}</span>
        </div>
        <div class="ocr-image-actions">
          <button id="ocr-clipboard-btn" class="ocr-action-btn ocr-primary-btn">
            ${r("ocr.clipboard_btn")}
          </button>
          <button id="ocr-file-btn" class="ocr-action-btn">
            ${r("ocr.file_btn")}
          </button>
        </div>
      </div>

      <!-- 右半：文字编辑区 -->
      <div class="ocr-text-panel">
        <div id="ocr-status-line" class="ocr-status-line">
          ${r("ocr.default_status")}
        </div>
        <button id="ocr-copy-btn" class="ocr-copy-btn">${r("ocr.copy_btn")}</button>
        <textarea
          id="ocr-result" class="ocr-textarea"
          spellcheck="false"
          placeholder="${r("ocr.placeholder")}"
        ></textarea>
      </div>
    </div>`;
}
async function W() {
  const t = document.getElementById("ocr-status-line"), e = document.getElementById("ocr-result"), i = document.getElementById("ocr-image-preview");
  t && (t.textContent = r("ocr.reading"));
  const o = await w();
  if (!o) {
    t && (t.textContent = r("ocr.no_clipboard"));
    return;
  }
  if (o.startsWith("__file__")) {
    const n = o.slice(8);
    await f(n);
    return;
  }
  if (i && (i.innerHTML = `<img src="${o}" class="ocr-preview-img" alt="Clipboard image" />`), !!await p(t)) {
    t && (t.textContent = r("ocr.recognizing"));
    try {
      const n = await _(o);
      t && (t.textContent = r("ocr.done")), e && (e.value = n.text || r("ocr.no_text"), e.style.height = "auto", e.style.height = Math.max(e.scrollHeight, 120) + "px");
    } catch (n) {
      t && (t.textContent = `${r("ocr.failed")}${n}`);
    }
  }
}
async function f(t) {
  const e = document.getElementById("ocr-status-line"), i = document.getElementById("ocr-result"), o = document.getElementById("ocr-image-preview");
  if (e && (e.textContent = r("ocr.loading_image")), !!await p(e)) {
    if (o)
      try {
        const n = await L(t);
        o.innerHTML = `<img src="${n}" class="ocr-preview-img" alt="OCR image" onerror="this.parentElement!.innerHTML='<span class=\\'ocr-image-placeholder\\'>${r("ocr.load_failed").replace("'", "\\'")}</span>'" />`;
      } catch {
        o.innerHTML = `<img src="${h(t)}" class="ocr-preview-img" alt="OCR image" onerror="this.parentElement!.innerHTML='<span class=\\'ocr-image-placeholder\\'>${t.split("\\").pop()}</span>'" />`;
      }
    e && (e.textContent = r("ocr.recognizing"));
    try {
      const n = await O(t);
      e && (e.textContent = r("ocr.done")), i && (i.value = n.text || r("ocr.no_text"), i.style.height = "auto", i.style.height = Math.max(i.scrollHeight, 120) + "px");
    } catch (n) {
      e && (e.textContent = `${r("ocr.failed")}${n}`);
    }
  }
}
function $(t) {
  var e, i, o;
  (e = t.getElementById("ocr-clipboard-btn")) == null || e.addEventListener("click", async () => {
    const n = t.getElementById("ocr-status-line"), c = t.getElementById("ocr-result"), a = t.getElementById("ocr-image-preview");
    n && (n.textContent = r("ocr.reading")), c && (c.value = "");
    const s = await w();
    if (!s) {
      n && (n.textContent = r("ocr.no_clipboard"));
      return;
    }
    if (s.startsWith("__file__")) {
      await f(s.slice(8));
      return;
    }
    if (a && (a.innerHTML = `<img src="${s}" class="ocr-preview-img" alt="Clipboard image" />`), !!await p(n)) {
      n && (n.textContent = r("ocr.recognizing"));
      try {
        const d = await _(s);
        n && (n.textContent = r("ocr.done")), c && (c.value = d.text || r("ocr.no_text"), c.style.height = "auto", c.style.height = Math.max(c.scrollHeight, 120) + "px");
      } catch (d) {
        n && (n.textContent = `${r("ocr.failed")}${d}`);
      }
    }
  }), (i = t.getElementById("ocr-file-btn")) == null || i.addEventListener("click", () => {
    const n = document.createElement("input");
    n.type = "file", n.accept = "image/*", n.style.display = "none", n.onchange = async () => {
      var m;
      const c = (m = n.files) == null ? void 0 : m[0];
      if (!c) return;
      const a = t.getElementById("ocr-status-line"), s = t.getElementById("ocr-result"), d = t.getElementById("ocr-image-preview");
      if (await p(a)) {
        a && (a.textContent = r("ocr.recognizing")), s && (s.value = "");
        try {
          const u = await R(c);
          d && (d.innerHTML = `<img src="${u}" class="ocr-preview-img" alt="Selected image" />`);
          const E = await _(u);
          a && (a.textContent = r("ocr.done")), s && (s.value = E.text || r("ocr.no_text"), s.style.height = "auto", s.style.height = Math.max(s.scrollHeight, 120) + "px");
        } catch (u) {
          a && (a.textContent = `${r("ocr.failed")}${u}`);
        }
      }
    }, document.body.appendChild(n), n.click();
  }), (o = t.getElementById("ocr-copy-btn")) == null || o.addEventListener("click", () => {
    const n = t.getElementById("ocr-result"), c = (n == null ? void 0 : n.value) || "";
    navigator.clipboard.writeText(c).then(() => {
      const a = t.getElementById("ocr-copy-btn");
      a && (a.textContent = r("ocr.copied"), a.classList.add("ocr-copied"), setTimeout(() => {
        a.textContent = r("ocr.copy_btn"), a.classList.remove("ocr-copied");
      }, 1500));
    }).catch(() => {
      const a = t.getElementById("ocr-result");
      a && a.select();
    });
  });
}
async function S(t) {
  $(document);
  const e = window.__lunac_ocr_image;
  e ? (delete window.__lunac_ocr_image, await f(e)) : await W();
}
export {
  S as attach,
  $ as attachOcrListeners,
  W as autoStartClipboardOcr,
  A as default,
  f as ocrImageFile,
  A as ocrPlugin
};
