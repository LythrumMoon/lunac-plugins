function C(t, e = !1) {
  return window.__TAURI_INTERNALS__.transformCallback(t, e);
}
async function u(t, e = {}, n) {
  return window.__TAURI_INTERNALS__.invoke(t, e, n);
}
function b(t, e = "asset") {
  return window.__TAURI_INTERNALS__.convertFileSrc(t, e);
}
var x;
(function(t) {
  t.WINDOW_RESIZED = "tauri://resize", t.WINDOW_MOVED = "tauri://move", t.WINDOW_CLOSE_REQUESTED = "tauri://close-requested", t.WINDOW_DESTROYED = "tauri://destroyed", t.WINDOW_FOCUS = "tauri://focus", t.WINDOW_BLUR = "tauri://blur", t.WINDOW_SCALE_FACTOR_CHANGED = "tauri://scale-change", t.WINDOW_THEME_CHANGED = "tauri://theme-changed", t.WINDOW_CREATED = "tauri://window-created", t.WINDOW_SUSPENDED = "tauri://suspended", t.WINDOW_RESUMED = "tauri://resumed", t.WEBVIEW_CREATED = "tauri://webview-created", t.DRAG_ENTER = "tauri://drag-enter", t.DRAG_OVER = "tauri://drag-over", t.DRAG_DROP = "tauri://drag-drop", t.DRAG_LEAVE = "tauri://drag-leave";
})(x || (x = {}));
async function I(t, e) {
  window.__TAURI_EVENT_PLUGIN_INTERNALS__.unregisterListener(t, e), await u("plugin:event|unlisten", {
    event: t,
    eventId: e
  });
}
async function _(t, e, n) {
  var a;
  const o = (a = void 0) !== null && a !== void 0 ? a : { kind: "Any" };
  return u("plugin:event|listen", {
    event: t,
    target: o,
    handler: C(e)
  }).then((r) => async () => I(t, r));
}
const D = "__lunac_host";
function $() {
  return globalThis[D] ?? null;
}
function i(t, e) {
  const n = $();
  return n && typeof n.t == "function" ? n.t(t, e) : t;
}
const m = class m {
  constructor() {
    this.lastBytes = 0, this.lastAt = 0, this.speed = 0, this.primed = !1;
  }
  push(e, n, a = Date.now()) {
    const o = n > 0 ? Math.min(100, Math.round(e / n * 100)) : -1;
    if (!this.primed)
      return this.primed = !0, this.lastBytes = e, this.lastAt = a, { percent: o, speed: 0, downloaded: e, total: n };
    const r = (a - this.lastAt) / 1e3;
    if (r >= m.MIN_DT) {
      const c = Math.max(0, (e - this.lastBytes) / r);
      this.speed = this.speed === 0 ? c : this.speed * 0.65 + c * 0.35, this.lastBytes = e, this.lastAt = a;
    }
    return { percent: o, speed: this.speed, downloaded: e, total: n };
  }
  reset() {
    this.lastBytes = 0, this.lastAt = 0, this.speed = 0, this.primed = !1;
  }
};
m.MIN_DT = 0.4;
let y = m;
function B(t) {
  if (!(t > 0)) return "0 B";
  const e = ["B", "KB", "MB", "GB"];
  let n = t, a = 0;
  for (; n >= 1024 && a < e.length - 1; )
    n /= 1024, a++;
  return `${n >= 100 || a === 0 ? Math.round(n) : n.toFixed(1)} ${e[a]}`;
}
function L(t) {
  return t > 0 ? `${B(t)}/s` : "—";
}
function S(t) {
  return `
    <span class="dl-ring-wrap is-unknown">
      <svg class="dl-ring" viewBox="0 0 36 36" aria-hidden="true">
        <circle class="dl-ring-track" cx="18" cy="18" r="15.5" pathLength="100"></circle>
        <circle class="dl-ring-fill" cx="18" cy="18" r="15.5" pathLength="100"
                style="stroke-dashoffset:100"></circle>
      </svg>
      <span class="dl-ring-pct"></span>
    </span>`;
}
function R(t, e) {
  const n = t.querySelector(".dl-ring-wrap"), a = t.querySelector(".dl-ring-fill"), o = t.querySelector(".dl-ring-pct");
  if (!n || !a) return !1;
  const r = e >= 0;
  return n.classList.toggle("is-unknown", !r), a.style.strokeDashoffset = String(r ? 100 - Math.max(0, Math.min(100, e)) : 100), o && (o.textContent = r ? String(Math.round(e)) : ""), !0;
}
class M {
  constructor() {
    this.meter = new y(), this.segKey = "", this.offset = 0, this.lastDownloaded = 0, this.lastTotal = 0, this.bodySeen = !1;
  }
  push(e, n = Date.now()) {
    const a = `${e.phase}#${e.index}`;
    a !== this.segKey && (this.offset += this.lastTotal > 0 ? Math.min(this.lastDownloaded, this.lastTotal) : this.lastDownloaded, this.segKey = a), e.index === 0 && (this.bodySeen = !0), this.lastDownloaded = e.downloaded, this.lastTotal = e.total;
    const { speed: o } = this.meter.push(this.offset + e.downloaded, 0, n), r = e.phase === "extract", c = this.offset + e.downloaded;
    if (e.count === 0)
      return { percent: -1, speed: o, downloaded: c, total: 0, index: 0, count: 0, extracting: r };
    const s = e.count + (this.bodySeen ? 1 : 0), l = (this.bodySeen ? 1 : 0) + Math.max(0, e.index - 1), d = r ? 1 : e.total > 0 ? Math.min(1, e.downloaded / e.total) : 0;
    return {
      percent: Math.floor((l + d) / s * 100),
      speed: o,
      downloaded: c,
      total: 0,
      index: e.index,
      count: e.count,
      extracting: r
    };
  }
}
function N(t) {
  return new Promise((e) => {
    let n;
    const a = new M();
    (async () => {
      try {
        n = await _("plugin-install-progress", (r) => {
          const c = r.payload;
          c.id === "ocr" && (t == null || t({ ...a.push(c), phase: c.phase }));
        });
      } catch {
      }
      let o = !1;
      try {
        await u("install_plugin_dependencies", { id: "ocr" }), o = !0;
      } catch {
        o = !1;
      } finally {
        try {
          n == null || n();
        } catch {
        }
      }
      e(o);
    })();
  });
}
function O(t) {
  if (!t) return;
  t.innerHTML = `${i("ocr.engine_missing")} `;
  const e = document.createElement("button");
  e.className = "ocr-action-btn ocr-primary-btn", e.style.marginLeft = "6px", e.textContent = i("ocr.engine_download"), e.addEventListener("click", async () => {
    e.disabled = !0;
    const n = document.createElement("span");
    n.className = "dl-inline", n.style.marginLeft = "6px", n.innerHTML = S() + `<span class="dl-meta">
         <span class="dl-phase">${i("ocr.engine_downloading_unknown").replace("{mb}", "0")}</span>
         <span class="dl-speed">—</span>
       </span>`, e.replaceWith(n);
    const a = n.querySelector(".dl-phase"), o = n.querySelector(".dl-speed"), r = await N(({ percent: s, speed: l, downloaded: d }) => {
      R(n, s), a && (a.textContent = s >= 0 ? i("ocr.engine_downloading").replace("{percent}", String(s)) : i("ocr.engine_downloading_unknown").replace("{mb}", (d / 1048576).toFixed(1))), o && (o.textContent = L(l));
    });
    n.remove();
    let c = !1;
    if (r)
      try {
        c = await u("ocr_engine_status");
      } catch {
        c = !1;
      }
    c ? t.textContent = i("ocr.engine_ready") : r ? t.textContent = i("ocr.engine_not_declared") : t.textContent = i("ocr.engine_failed");
  }), t.appendChild(e);
}
async function h(t) {
  try {
    if (await u("ocr_engine_status")) return !0;
  } catch {
    return !0;
  }
  return O(t), !1;
}
async function v() {
  try {
    const t = await u("read_clipboard_files");
    if (t.length > 0)
      return `__file__${t[0]}`;
  } catch {
  }
  try {
    const t = await u("read_clipboard_backup_image");
    if (t) {
      const e = t.lastIndexOf("|");
      return `__file__${e > 0 ? t.substring(0, e) : t}`;
    }
  } catch {
  }
  return null;
}
function A(t) {
  return new Promise((e, n) => {
    const a = new FileReader();
    a.onload = () => e(a.result), a.onerror = () => n(new Error("Failed to read blob")), a.readAsDataURL(t);
  });
}
async function W(t) {
  return { text: (await u("run_paddle_ocr", { path: t })).trim() };
}
async function g(t) {
  const e = await u("save_temp_image", { dataUrl: t }), n = await u("run_paddle_ocr", { path: e });
  return u("delete_temp_image", { path: e }).catch(() => {
  }), { text: n.trim() };
}
async function k(t) {
  return b(t);
}
const G = {
  id: "ocr",
  name: "OCR 文字识别",
  keywords: [
    "ocr",
    "识别",
    "文字识别",
    "图像识别",
    "图片转文字",
    "截图识别",
    "图识字",
    "文字提取"
  ],
  description: "OCR 图片文字识别 (PaddleOCR · 离线高精度)",
  icon: "🔍",
  badge: "AI",
  // 接管整个窗口（双栏：左图右文）。宿主据此决定「不套 .plugin-result、直接 detach、
  // 把 attach 的 root 传成文档根」—— 见 main.ts 的 isTakeoverPlugin()。
  permissions: ["layout.takeover"],
  async execute(t) {
    return { type: "html", content: T() };
  }
};
function T() {
  return `
    <div class="ocr-detached-layout">
      <!-- 左半：图片预览 -->
      <div class="ocr-image-panel">
        <div id="ocr-image-preview" class="ocr-image-preview">
          <span class="ocr-image-placeholder">${i("ocr.no_image")}</span>
        </div>
        <div class="ocr-image-actions">
          <button id="ocr-screen-btn" class="ocr-action-btn">
            ${i("ocr.screen_btn")}
          </button>
          <button id="ocr-clipboard-btn" class="ocr-action-btn ocr-primary-btn">
            ${i("ocr.clipboard_btn")}
          </button>
          <button id="ocr-file-btn" class="ocr-action-btn">
            ${i("ocr.file_btn")}
          </button>
        </div>
      </div>

      <!-- 右半：文字编辑区 -->
      <div class="ocr-text-panel">
        <div id="ocr-status-line" class="ocr-status-line">
          ${i("ocr.default_status")}
        </div>
        <button id="ocr-copy-btn" class="ocr-copy-btn">${i("ocr.copy_btn")}</button>
        <textarea
          id="ocr-result" class="ocr-textarea"
          spellcheck="false"
          placeholder="${i("ocr.placeholder")}"
        ></textarea>
      </div>
    </div>`;
}
async function H() {
  const t = document.getElementById("ocr-status-line"), e = document.getElementById("ocr-result"), n = document.getElementById("ocr-image-preview");
  t && (t.textContent = i("ocr.reading"));
  const a = await v();
  if (!a) {
    t && (t.textContent = i("ocr.no_clipboard"));
    return;
  }
  if (a.startsWith("__file__")) {
    const o = a.slice(8);
    await w(o);
    return;
  }
  if (n && (n.innerHTML = `<img src="${a}" class="ocr-preview-img" alt="Clipboard image" />`), !!await h(t)) {
    t && (t.textContent = i("ocr.recognizing"));
    try {
      const o = await g(a);
      t && (t.textContent = i("ocr.done")), e && (e.value = o.text || i("ocr.no_text"), e.style.height = "auto", e.style.height = Math.max(e.scrollHeight, 120) + "px");
    } catch (o) {
      t && (t.textContent = `${i("ocr.failed")}${o}`);
    }
  }
}
async function w(t) {
  const e = document.getElementById("ocr-status-line"), n = document.getElementById("ocr-result"), a = document.getElementById("ocr-image-preview");
  if (e && (e.textContent = i("ocr.loading_image")), !!await h(e)) {
    if (a)
      try {
        const o = await k(t);
        a.innerHTML = `<img src="${o}" class="ocr-preview-img" alt="OCR image" onerror="this.parentElement!.innerHTML='<span class=\\'ocr-image-placeholder\\'>${i("ocr.load_failed").replace("'", "\\'")}</span>'" />`;
      } catch {
        a.innerHTML = `<img src="${b(t)}" class="ocr-preview-img" alt="OCR image" onerror="this.parentElement!.innerHTML='<span class=\\'ocr-image-placeholder\\'>${t.split("\\").pop()}</span>'" />`;
      }
    e && (e.textContent = i("ocr.recognizing"));
    try {
      const o = await W(t);
      e && (e.textContent = i("ocr.done")), n && (n.value = o.text || i("ocr.no_text"), n.style.height = "auto", n.style.height = Math.max(n.scrollHeight, 120) + "px");
    } catch (o) {
      e && (e.textContent = `${i("ocr.failed")}${o}`);
    }
  }
}
async function U(t, e, n, a) {
  if (a && (a.innerHTML = `<img src="${t}" class="ocr-preview-img" alt="Screen capture" />`), n && (n.value = ""), !!await h(e)) {
    e && (e.textContent = i("ocr.recognizing"));
    try {
      const o = await g(t);
      e && (e.textContent = i("ocr.done")), n && (n.value = o.text || i("ocr.no_text"), n.style.height = "auto", n.style.height = Math.max(n.scrollHeight, 120) + "px");
    } catch (o) {
      e && (e.textContent = `${i("ocr.failed")}${o}`);
    }
  }
}
function F(t) {
  var e, n, a, o;
  (e = t.getElementById("ocr-screen-btn")) == null || e.addEventListener("click", async () => {
    const r = t.getElementById("ocr-status-line"), c = t.getElementById("ocr-result"), s = t.getElementById("ocr-image-preview");
    r && (r.textContent = i("ocr.shot_capturing"));
    const l = [], d = () => {
      for (const f of l) f();
      l.length = 0;
    };
    l.push(
      await _("screenshot-overlay-done", (f) => {
        d(), U(f.payload.dataUrl, r, c, s);
      })
    ), l.push(
      await _("screenshot-overlay-cancelled", () => {
        d(), r && (r.textContent = i("ocr.default_status"));
      })
    );
    try {
      await u("screenshot_overlay_begin");
    } catch (f) {
      d(), r && (r.textContent = `${i("ocr.shot_failed")}${f}`);
    }
  }), (n = t.getElementById("ocr-clipboard-btn")) == null || n.addEventListener("click", async () => {
    const r = t.getElementById("ocr-status-line"), c = t.getElementById("ocr-result"), s = t.getElementById("ocr-image-preview");
    r && (r.textContent = i("ocr.reading")), c && (c.value = "");
    const l = await v();
    if (!l) {
      r && (r.textContent = i("ocr.no_clipboard"));
      return;
    }
    if (l.startsWith("__file__")) {
      await w(l.slice(8));
      return;
    }
    if (s && (s.innerHTML = `<img src="${l}" class="ocr-preview-img" alt="Clipboard image" />`), !!await h(r)) {
      r && (r.textContent = i("ocr.recognizing"));
      try {
        const d = await g(l);
        r && (r.textContent = i("ocr.done")), c && (c.value = d.text || i("ocr.no_text"), c.style.height = "auto", c.style.height = Math.max(c.scrollHeight, 120) + "px");
      } catch (d) {
        r && (r.textContent = `${i("ocr.failed")}${d}`);
      }
    }
  }), (a = t.getElementById("ocr-file-btn")) == null || a.addEventListener("click", () => {
    const r = document.createElement("input");
    r.type = "file", r.accept = "image/*", r.style.display = "none", r.onchange = async () => {
      var f;
      const c = (f = r.files) == null ? void 0 : f[0];
      if (!c) return;
      const s = t.getElementById("ocr-status-line"), l = t.getElementById("ocr-result"), d = t.getElementById("ocr-image-preview");
      if (await h(s)) {
        s && (s.textContent = i("ocr.recognizing")), l && (l.value = "");
        try {
          const p = await A(c);
          d && (d.innerHTML = `<img src="${p}" class="ocr-preview-img" alt="Selected image" />`);
          const E = await g(p);
          s && (s.textContent = i("ocr.done")), l && (l.value = E.text || i("ocr.no_text"), l.style.height = "auto", l.style.height = Math.max(l.scrollHeight, 120) + "px");
        } catch (p) {
          s && (s.textContent = `${i("ocr.failed")}${p}`);
        }
      }
    }, document.body.appendChild(r), r.click();
  }), (o = t.getElementById("ocr-copy-btn")) == null || o.addEventListener("click", () => {
    const r = t.getElementById("ocr-result"), c = (r == null ? void 0 : r.value) || "";
    navigator.clipboard.writeText(c).then(() => {
      const s = t.getElementById("ocr-copy-btn");
      s && (s.textContent = i("ocr.copied"), s.classList.add("ocr-copied"), setTimeout(() => {
        s.textContent = i("ocr.copy_btn"), s.classList.remove("ocr-copied");
      }, 1500));
    }).catch(() => {
      const s = t.getElementById("ocr-result");
      s && s.select();
    });
  });
}
async function q(t) {
  F(document);
  const e = window.__lunac_ocr_image;
  e ? (delete window.__lunac_ocr_image, await w(e)) : await H();
}
export {
  q as attach,
  F as attachOcrListeners,
  H as autoStartClipboardOcr,
  G as default,
  w as ocrImageFile,
  G as ocrPlugin
};
