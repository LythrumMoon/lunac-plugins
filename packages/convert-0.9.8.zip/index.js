const x = "__lunac_host";
function C() {
  return globalThis[x] ?? null;
}
function o(t, e) {
  const n = C();
  return n && typeof n.t == "function" ? n.t(t, e) : t;
}
function M(t, e = !1) {
  return window.__TAURI_INTERNALS__.transformCallback(t, e);
}
async function l(t, e = {}, n) {
  return window.__TAURI_INTERNALS__.invoke(t, e, n);
}
var I;
(function(t) {
  t.WINDOW_RESIZED = "tauri://resize", t.WINDOW_MOVED = "tauri://move", t.WINDOW_CLOSE_REQUESTED = "tauri://close-requested", t.WINDOW_DESTROYED = "tauri://destroyed", t.WINDOW_FOCUS = "tauri://focus", t.WINDOW_BLUR = "tauri://blur", t.WINDOW_SCALE_FACTOR_CHANGED = "tauri://scale-change", t.WINDOW_THEME_CHANGED = "tauri://theme-changed", t.WINDOW_CREATED = "tauri://window-created", t.WINDOW_SUSPENDED = "tauri://suspended", t.WINDOW_RESUMED = "tauri://resumed", t.WEBVIEW_CREATED = "tauri://webview-created", t.DRAG_ENTER = "tauri://drag-enter", t.DRAG_OVER = "tauri://drag-over", t.DRAG_DROP = "tauri://drag-drop", t.DRAG_LEAVE = "tauri://drag-leave";
})(I || (I = {}));
async function H(t, e) {
  window.__TAURI_EVENT_PLUGIN_INTERNALS__.unregisterListener(t, e), await l("plugin:event|unlisten", {
    event: t,
    eventId: e
  });
}
async function G(t, e, n) {
  var r;
  const u = (r = void 0) !== null && r !== void 0 ? r : { kind: "Any" };
  return l("plugin:event|listen", {
    event: t,
    target: u,
    handler: M(e)
  }).then((d) => async () => H(t, d));
}
async function B(t = {}) {
  return typeof t == "object" && Object.freeze(t), await l("plugin:dialog|open", { options: t });
}
const D = {
  file: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>',
  play: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polygon points="6 4 20 12 6 20 6 4"/></svg>',
  folder: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>'
};
let k = null, c = null, f = "", b = !1, s = null, a = 0, p = null, v = 0;
function y(t) {
  return t.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
function q(t) {
  return !isFinite(t) || t <= 0 ? "0 B" : t < 1024 ? `${t} B` : t < 1048576 ? `${(t / 1024).toFixed(1)} KB` : t < 1073741824 ? `${(t / 1048576).toFixed(1)} MB` : `${(t / 1073741824).toFixed(2)} GB`;
}
function F(t) {
  if (!isFinite(t) || t <= 0) return "";
  const e = Math.round(t), n = Math.floor(e / 60), r = e % 60;
  return n > 0 ? `${n}:${String(r).padStart(2, "0")}` : `${r}s`;
}
function U(t) {
  switch (t) {
    case "image":
      return o("convert.kind_image");
    case "audio":
      return o("convert.kind_audio");
    case "video":
      return o("convert.kind_video");
    default:
      return o("convert.kind_unknown");
  }
}
function N(t) {
  const e = t instanceof Error ? t.message : String(t);
  return e.includes("ERR_NO_FILE") ? o("convert.err_no_file") : e.includes("ERR_NO_ENGINE") ? o("convert.err_no_engine") : e;
}
function V() {
  return `
  <div class="convert-root">
    <div class="convert-head">
      <span class="convert-engine" id="convert-engine">${o("convert.engine_checking")}</span>
      <button class="convert-btn" id="convert-pick">${D.file} ${o("convert.pick")}</button>
    </div>

    <div class="convert-source" id="convert-source">${o("convert.pick_hint")}</div>

    <div class="convert-target-wrap hidden" id="convert-target-wrap">
      <div class="convert-label">${o("convert.target")}</div>
      <div class="convert-targets" id="convert-targets"></div>
    </div>

    <div class="convert-actions">
      <button class="convert-btn convert-primary" id="convert-start" disabled>${o("convert.start")}</button>
      <span class="convert-status" id="convert-status"></span>
    </div>

    <div class="convert-progress hidden" id="convert-progress-wrap">
      <div class="convert-progress-bar"><div class="convert-progress-fill" id="convert-progress-fill"></div></div>
      <span class="convert-percent" id="convert-percent"></span>
    </div>

    <div class="convert-done hidden" id="convert-done">
      <div class="convert-out" id="convert-out"></div>
      <div class="convert-done-actions">
        <button class="convert-btn" id="convert-open-file">${D.play} ${o("convert.open_file")}</button>
        <button class="convert-btn" id="convert-reveal">${D.folder} ${o("convert.reveal")}</button>
      </div>
    </div>
  </div>`;
}
function _(t, e) {
  t && t.textContent !== e && (t.textContent = e);
}
function E(t, e) {
  t && t.innerHTML !== e && (t.innerHTML = e);
}
function m(t, e) {
  t == null || t.classList.toggle("hidden", !e);
}
function z(t) {
  var n;
  const e = t.querySelector("#convert-engine");
  if (k)
    if (k.found)
      _(e, k.version ? `${o("convert.engine")} ${k.version}` : o("convert.engine"));
    else {
      _(e, o("convert.engine_missing")), e == null || e.classList.add("convert-warn");
      const r = t.querySelector("#convert-source");
      r && (r.innerHTML = `<span class="convert-warn">${o("convert.engine_missing_hint")}</span>`), (n = t.querySelector("#convert-pick")) == null || n.setAttribute("disabled", "true");
    }
}
function S(t) {
  const e = t.querySelector("#convert-source"), n = t.querySelector("#convert-target-wrap"), r = t.querySelector("#convert-start");
  if (!e || !n || !r) return;
  if (!c) {
    E(e, o("convert.pick_hint")), m(n, !1), r.disabled = !0;
    return;
  }
  const u = [U(c.kind), q(c.size)], d = F(c.duration);
  if (d && u.push(d), c.kind === "unknown" || c.targets.length === 0) {
    E(
      e,
      `<div class="convert-file">${y(c.name)}</div><div class="convert-sub convert-warn">${o("convert.unsupported")}</div>`
    ), m(n, !1), r.disabled = !0;
    return;
  }
  E(
    e,
    `<div class="convert-file">${y(c.name)}</div><div class="convert-sub">${y(u.join(" · "))}</div>`
  ), E(
    t.querySelector("#convert-targets"),
    c.targets.map((g) => `<button class="convert-chip${g === f ? " active" : ""}" data-ext="${y(g)}">${y(g)}</button>`).join("")
  ), m(n, !0), r.disabled = b || !f;
}
function w(t) {
  const e = t.querySelector("#convert-progress-wrap"), n = t.querySelector("#convert-progress-fill"), r = t.querySelector("#convert-percent");
  m(e, b || a > 0), !(!b && a <= 0) && (a < 0 ? (n == null || n.classList.add("indeterminate"), n && (n.style.width = ""), _(r, "")) : (n == null || n.classList.remove("indeterminate"), n && (n.style.width = `${Math.min(100, a)}%`), _(r, `${Math.round(a)}%`)));
}
function $(t) {
  const e = t.querySelector("#convert-done"), n = t.querySelector("#convert-out");
  if (m(e, !!s), !s || !n) return;
  const r = s.output.split(/[\\/]/).pop() || s.output;
  E(n, `${y(r)} · ${q(s.size)} · ${(s.elapsed_ms / 1e3).toFixed(1)}s`);
}
async function O(t, e) {
  s = null, a = 0, $(t), w(t), _(t.querySelector("#convert-status"), "");
  try {
    const n = await l("convert_probe", { path: e });
    c = n, f = n.targets[0] ?? "", S(t);
  } catch (n) {
    c = null, f = "", S(t), _(t.querySelector("#convert-status"), N(n));
  }
}
async function T(t) {
  var g, R, W, L, A;
  const e = t.querySelector(".convert-root");
  if (!e) return;
  const n = ++v, r = (i) => e.querySelector(i), u = (i) => _(r("#convert-status"), i);
  p && (p(), p = null), p = await G("convert-progress", (i) => {
    n !== v || !e.isConnected || (a = i.payload.percent, w(e));
  });
  try {
    k = await l("convert_engine_status");
  } catch {
    k = { found: !1, path: "", version: "" };
  }
  if (n !== v) return;
  z(e);
  const d = window.__lunac_convert_file;
  d && (delete window.__lunac_convert_file, await O(e, d)), (g = r("#convert-pick")) == null || g.addEventListener("click", async () => {
    try {
      const i = await B({
        multiple: !1,
        directory: !1,
        title: o("convert.pick")
      }), h = Array.isArray(i) ? i[0] : i;
      typeof h == "string" && h && await O(e, h);
    } catch (i) {
      u(N(i));
    }
  }), (R = r("#convert-targets")) == null || R.addEventListener("click", (i) => {
    const h = i.target.closest(".convert-chip");
    h && (f = h.dataset.ext || "", S(e));
  }), (W = r("#convert-start")) == null || W.addEventListener("click", async () => {
    if (!(!c || !f || b)) {
      b = !0, s = null, a = 0, $(e), S(e), u(o("convert.converting")), w(e);
      try {
        const i = await l("convert_run", { input: c.path, target: f });
        if (n !== v) return;
        s = i, a = 100, u(o("convert.done")), $(e), w(e);
      } catch (i) {
        if (n !== v) return;
        a = 0, u(N(i)), w(e);
      } finally {
        b = !1, n === v && S(e);
      }
    }
  }), (L = r("#convert-open-file")) == null || L.addEventListener("click", () => {
    s && l("open_path", { path: s.output }).catch(() => {
    });
  }), (A = r("#convert-reveal")) == null || A.addEventListener("click", () => {
    s && l("reveal_in_explorer", { path: s.output }).catch(() => {
    });
  }), S(e), w(e), $(e);
}
function j() {
  v++, p && (p(), p = null);
}
window.__lunac_convert_stop = j;
const P = {
  id: "convert",
  name: "文件转换",
  keywords: ["转换", "格式转换", "转格式", "convert", "格式", "转码", "提取音频", "图片转换", "视频转换", "音频转换"],
  description: "图片 / 音频 / 视频格式互转 (Image / Audio / Video converter · ffmpeg)",
  icon: "🔄",
  badge: "convert",
  async execute(t) {
    const e = t.trim();
    if (/^[a-zA-Z]:[\\/]/.test(e))
      try {
        await l("check_file_exists", { path: e }) && (window.__lunac_convert_file = e);
      } catch {
      }
    return { type: "html", content: V() };
  }
};
export {
  T as attach,
  T as attachConvertListeners,
  P as convertPlugin,
  P as default,
  j as detach,
  j as stopConvertWatch
};
