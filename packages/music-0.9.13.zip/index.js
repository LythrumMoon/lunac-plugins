const Ms = "__lunac_host";
function Cs() {
  return globalThis[Ms] ?? null;
}
function n(e, i) {
  const t = Cs();
  return t && typeof t.t == "function" ? t.t(e, i) : e;
}
function Ts(e, i = !1) {
  return window.__TAURI_INTERNALS__.transformCallback(e, i);
}
async function p(e, i = {}, t) {
  return window.__TAURI_INTERNALS__.invoke(e, i, t);
}
function Te(e, i = "asset") {
  return window.__TAURI_INTERNALS__.convertFileSrc(e, i);
}
var jt;
(function(e) {
  e.WINDOW_RESIZED = "tauri://resize", e.WINDOW_MOVED = "tauri://move", e.WINDOW_CLOSE_REQUESTED = "tauri://close-requested", e.WINDOW_DESTROYED = "tauri://destroyed", e.WINDOW_FOCUS = "tauri://focus", e.WINDOW_BLUR = "tauri://blur", e.WINDOW_SCALE_FACTOR_CHANGED = "tauri://scale-change", e.WINDOW_THEME_CHANGED = "tauri://theme-changed", e.WINDOW_CREATED = "tauri://window-created", e.WINDOW_SUSPENDED = "tauri://suspended", e.WINDOW_RESUMED = "tauri://resumed", e.WEBVIEW_CREATED = "tauri://webview-created", e.DRAG_ENTER = "tauri://drag-enter", e.DRAG_OVER = "tauri://drag-over", e.DRAG_DROP = "tauri://drag-drop", e.DRAG_LEAVE = "tauri://drag-leave";
})(jt || (jt = {}));
async function Is(e, i) {
  window.__TAURI_EVENT_PLUGIN_INTERNALS__.unregisterListener(e, i), await p("plugin:event|unlisten", {
    event: e,
    eventId: i
  });
}
async function Rs(e, i, t) {
  var s;
  const c = (s = void 0) !== null && s !== void 0 ? s : { kind: "Any" };
  return p("plugin:event|listen", {
    event: e,
    target: c,
    handler: Ts(i)
  }).then((l) => async () => Is(e, l));
}
async function As(e, i) {
  await p("plugin:shell|open", {
    path: e,
    with: i
  });
}
async function Ds(e, i) {
  await p("plugin:clipboard-manager|write_text", {
    label: i == null ? void 0 : i.label,
    text: e
  });
}
async function Kt(e = {}) {
  return typeof e == "object" && Object.freeze(e), await p("plugin:dialog|open", { options: e });
}
function Ns(e) {
  return e === "new" ? "album" : e === "top" ? "artist" : e;
}
const Bs = {
  album: "spotify_albums",
  artist: "spotify_artists",
  show: "spotify_shows",
  new: "spotify_new_releases",
  top: "spotify_top_artists"
}, Os = 1280, Ps = 720, js = 550, Hs = 300, Zt = 180, is = 520, Ws = 4e3, Us = 450, Vs = 800, Fs = 8e3, zs = 200, Gs = 500, Qs = 500, Ys = 250, Xs = 500, Js = 0.3, m = {
  play: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polygon points="6 4 20 12 6 20 6 4"/></svg>',
  pause: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="9" y1="4" x2="9" y2="20"/><line x1="15" y1="4" x2="15" y2="20"/></svg>',
  prev: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polygon points="19 5 9 12 19 19 19 5"/><line x1="5" y1="5" x2="5" y2="19"/></svg>',
  next: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polygon points="5 5 15 12 5 19 5 5"/><line x1="19" y1="5" x2="19" y2="19"/></svg>',
  /** 随机（关 / 随机共用这一个；「关」靠 `data-mode` 变暗区分）。 */
  shuffle: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="16 3 21 3 21 8"/><line x1="4" y1="20" x2="21" y2="3"/><polyline points="21 16 21 21 16 21"/><line x1="15" y1="15" x2="21" y2="21"/><line x1="4" y1="4" x2="9" y2="9"/></svg>',
  /** 循环（单曲循环；那个「1」由 CSS `::after` 加，SVG 里不写字）。 */
  repeat: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="17 1 21 5 17 9"/><path d="M3 11V9a4 4 0 0 1 4-4h14"/><polyline points="7 23 3 19 7 15"/><path d="M21 13v2a4 4 0 0 1-4 4H3"/></svg>',
  list: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="9" y1="6" x2="21" y2="6"/><line x1="9" y1="12" x2="21" y2="12"/><line x1="9" y1="18" x2="21" y2="18"/><circle cx="4" cy="6" r="1" fill="currentColor" stroke="none"/><circle cx="4" cy="12" r="1" fill="currentColor" stroke="none"/><circle cx="4" cy="18" r="1" fill="currentColor" stroke="none"/></svg>',
  /** 进播放界面。 */
  expand: '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 3 21 3 21 9"/><polyline points="9 21 3 21 3 15"/><line x1="21" y1="3" x2="14" y2="10"/><line x1="3" y1="21" x2="10" y2="14"/></svg>',
  /** 回默认界面。**唯一**的退出播放界面的入口 —— 播放停止不会自动退出。 */
  back: '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/><line x1="3" y1="12" x2="9" y2="12"/></svg>',
  copy: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15V5a2 2 0 0 1 2-2h10"/></svg>',
  link: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.5 1.5"/><path d="M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7L12 19"/></svg>',
  power: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M18.4 6.6a9 9 0 1 1-12.8 0"/><line x1="12" y1="2" x2="12" y2="12"/></svg>',
  gear: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>',
  volume: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M15.5 8.5a5 5 0 0 1 0 7"/></svg>',
  /** 工具条上的「设备」按钮（2026-09-28）。画成一台小音箱，比「显示器」更贴
   *  Spotify 那种「可选的播放设备」语义。 */
  speaker: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="2" width="14" height="20" rx="2"/><circle cx="12" cy="14" r="3.2"/><circle cx="12" cy="6" r="1" fill="currentColor" stroke="none"/></svg>',
  /** 实心心形（「我喜欢的歌曲」那块封面上的图案）。**这个是 `fill`，不是描边** ——
   *  它是一块封面图（Spotify 的收藏夹封面就是实心心 + 渐变底），不是可点按钮。 */
  heart: '<svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" stroke="none"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>',
  // ── 本地媒体库那一页用到的四个（2026-10-01）──
  /** 「本地音乐」入口 + 目录行（画成文件夹）。 */
  folder: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/></svg>',
  /** 「添加目录」。 */
  plus: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>',
  /** 移除一根目录（行尾那枚）。`music.pl-x` 用。 */
  x: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="6" y1="6" x2="18" y2="18"/><line x1="18" y1="6" x2="6" y2="18"/></svg>',
  /** 没有封面的曲目行左侧占位（一个八分音符）。 */
  note: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18V6l10-2v12"/><circle cx="6.5" cy="18" r="2.5"/><circle cx="16.5" cy="16" r="2.5"/></svg>',
  /** 「重新扫描」/「刷新」—— 画成环形箭头。 */
  refresh: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="21 3 21 9 15 9"/><path d="M20.4 14a8.5 8.5 0 1 1-1.6-7.5L21 9"/></svg>',
  /** 编辑（改列表）。**路径逐字抄自 icon-style.md §3 的「编辑 ✎」** —— 规范里已经
   *  给好这条了，不许自己另画一条（§4.2 最后一条：已有的图形不要重复造路径）。 */
  edit: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 3a2.8 2.8 0 0 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/></svg>',
  /** 删除（垃圾桶）。**同样逐字抄自 icon-style.md §3** —— 它是危险操作，
   *  按 §4.2 用同风格线性图标 + 语义色（hover 变 `--red`，见 styles.css）。 */
  trash: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6M14 11v6M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>',
  /** 停止本地播放（本地播放条右端那枚）。**它与暂停不是一回事**：暂停留着这台
   *  音频设备，停止会把设备一起放掉（见 player.rs 的 `player_stop`）。 */
  stop: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="6" y="6" width="12" height="12" rx="1.5"/></svg>',
  /** 「本地与 Spotify 同时出声」那把开关（2026-10-01）。画成**两个相交的圆** ——
   *  「两路并存」最直白的图形（Lucide 里叫 `blend`）。**不画成两个喇叭**：12px 下
   *  两个喇叭会糊成一团，而两个圆在任何尺寸下都认得出来。
   *  开关的「开着」不用第二个图形表达，靠 `.on` 的强调色（与其他开关一致）。 */
  dual: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="9" r="6.5"/><circle cx="15" cy="15" r="6.5"/></svg>',
  /** 「最常听的歌曲」那一行的图标（2026-10-01 用户第 4 条）。画成一条上扬的折线
   *  —— 「最常听 / 热度」最直白的图形（Lucide 的 `trending-up`，与上面这些同源）。
   *  与 `SVG.heart` 一样是 20px 的封面图案，但**保持描边风格**（它不是实心封面，
   *  它是「一行合成出来的入口」，与收藏夹那块渐变实心封面刻意区分开）。 */
  trend: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/></svg>'
  // （工具条上那枚「调音推子」图标 2026-10-01 随入口一起删掉了：调音改成标题栏
  //  三段切换的第三段，那枚图标就没有地方落了。图形本身仍在 icon-style.md §3 里。）
};
let o = null, r = null, j = null, Ue = "", Ve = !1, Ni = [], wi = -1, he = null, Yi = null, ge = !1, V = null, $ = "default", Fe = null, $i = null, Q = !1, es = "", R = null, je = !1, Li = "", ei = "", M = null, Wi = !1, Xi, F = "playlist";
const Ui = /* @__PURE__ */ new Map(), ie = /* @__PURE__ */ new Set(), oe = /* @__PURE__ */ new Map();
let h = null, X = null, Bi = !1, vi = "", Z = !1, bi = !1, ni = "tracks", qi = null, mi = !1, B = null, si = "", xe = !1, ee = Hs, ze = null, te = "", P = !1, W = null, qe = !1, Vi = "", ti = "", ii = !1, ai = /* @__PURE__ */ new Set(), re = /* @__PURE__ */ new Set(), ci = !1, A = null, Fi = !1, hi = "", Y = null, de = "", z, Oi = null, se, f = null, me = 0, fi = [], li = -1, ki = !1, H = -1, ne;
const ts = "lunac-music-dual-play";
let pi = Ks();
function Ks() {
  try {
    return localStorage.getItem(ts) === "1";
  } catch {
    return !1;
  }
}
function Zs(e) {
  try {
    localStorage.setItem(ts, e ? "1" : "0");
  } catch {
  }
}
const ss = "lunac-music-local-mode";
let O = en();
function en() {
  try {
    const e = localStorage.getItem(ss);
    return e === "shuffle" || e === "repeat_all" || e === "repeat_one" ? e : "off";
  } catch {
    return "off";
  }
}
function tn(e) {
  try {
    localStorage.setItem(ss, e);
  } catch {
  }
}
function Je() {
  return n(O === "shuffle" ? "music.mode_shuffle" : O === "repeat_all" ? "music.mode_repeat_all" : O === "repeat_one" ? "music.mode_repeat_one" : "music.mode_off");
}
let ce, _e = !1, we, ns = 0, cs = 0, Si = null, as = null, Ai = 0, zi = !1, _i = -1, Ei = [], ae = 0, ui, xi, $e = "", ke = 0, Ge = "";
function Ie() {
  return $ === "player" || $ === "lplayer";
}
function a(e) {
  return e.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
function le(e) {
  if (!isFinite(e) || e < 0) return "0:00";
  const i = Math.floor(e / 1e3), t = Math.floor(i / 60), s = i % 60;
  return `${t}:${String(s).padStart(2, "0")}`;
}
function I(e) {
  if (!isFinite(e) || e < 0) return "00:00";
  const i = Math.floor(e / 1e3);
  return `${String(Math.floor(i / 60)).padStart(2, "0")}:${String(i % 60).padStart(2, "0")}`;
}
function L(e) {
  const i = e instanceof Error ? e.message : String(e);
  if (i.includes("ERR_NO_CLIENT_ID")) return n("music.err_no_client_id");
  if (i.includes("ERR_NOT_CONNECTED")) return n("music.err_not_connected");
  if (i.includes("ERR_NO_QUERY")) return n("music.err_no_query");
  if (i.includes("ERR_PORT_BUSY")) return n("music.err_port_busy", { port: String((o == null ? void 0 : o.port) ?? "") });
  if (i.includes("ERR_BAD_URI") || i.includes("ERR_BAD_ID")) return n("music.err_bad_uri");
  const t = i.match(/ERR_RATE_LIMITED:(\S*)/);
  return t ? n("music.err_rate_limited", { s: t[1] || "?" }) : i.includes("Insufficient client scope") ? n("music.err_scope") : i.includes("No active device") || i.includes("NO_ACTIVE_DEVICE") ? n("music.err_no_device") : i.includes("Premium required") || i.includes("PREMIUM_REQUIRED") ? n("music.err_premium") : i.includes("Restriction violated") ? n("music.err_restricted") : i;
}
function sn(e) {
  const i = [];
  for (const t of e.split(/\r?\n/)) {
    const s = [...t.matchAll(/\[(\d{1,3}):(\d{1,2})(?:[.:](\d{1,3}))?\]/g)];
    if (s.length === 0) continue;
    const c = t.replace(/\[[^\]]*\]/g, "").trim();
    if (c)
      for (const l of s) {
        const v = l[3] ? Number(l[3].padEnd(3, "0")) / 1e3 : 0;
        i.push({ at: Number(l[1]) * 60 + Number(l[2]) + v, text: c });
      }
  }
  return i.sort((t, s) => t.at - s.at), i;
}
function nn() {
  return `
  <div class="music-root">
    <!-- ── 默认界面：顶部工具条 + 状态行 + 连接设置 + 歌单列 / 搜索结果 ──
         工具条与「返回」按钮**分属两态**：默认态用底部栏那个「进播放界面」，
         播放态用**标题栏那个 ←**（syncTitlebarClose 把 × 换成它；歌名模块右端
         原来还有一枚「返回歌单」，2026-10-01 已按用户口径删掉）。
         ⚠️ 本段在模板字符串里，注释里一个反引号都不能出现（预检 #15 / #39 ⑩）。 -->
    <div class="music-view" id="music-v-default">
      <!-- 顶部工具条：头像 / 账号 / 搜索（**带下拉预览**）/ 状态 / 设置。
           2026-09-28 第二次改：设备按钮与「展开播放面板」都**下移到最底下那条控制栏**
           （用户要求「严格对齐 Spotify」，Spotify 的工具条上本来就没有这两样）。 -->
      <div class="music-toolbar">
        <button class="music-avatar" id="music-avatar" title="${a(n("music.account_btn"))}"></button>
        <span class="music-acc" id="music-acc"></span>
        <div class="music-search-wrap">
          <input class="music-search" id="music-search" type="search" autocomplete="off" spellcheck="false" placeholder="${a(n("music.search_ph"))}">
          <!-- 下拉预览：绝对定位挂在工具条下方（**不占布局**，否则窗口高会跟着抖） -->
          <div class="music-dd hidden" id="music-search-dd"></div>
        </div>
        <span class="music-status" id="music-status">${n("music.loading")}</span>
        <!-- 这里原来的「本地音乐」文件夹按钮与「调音」推子按钮**已删除**（2026-10-01
             用户口径）：这两个入口收进了**标题栏那枚三段切换**（在线歌单 / 本地音乐 /
             调音，见 renderTitlebarSwitch）。标题栏是悬浮窗独有的，插件若被嵌在主窗口里
             就没有那一条 —— 那种情况下切换器会退到本工具条里（见 placeSwitcher），
             所以这里不给它们留第二份入口，否则「删掉」就变成了「多一份」。
             ⚠️ 本段是 JS 模板字符串，注释里不能出现反引号（预检 #15 / #39 ⑩）。 -->
        <button class="music-ghost-btn music-icon-btn" id="music-setup-toggle" title="${a(n("music.settings"))}">${m.gear}</button>
      </div>

      <div class="music-setup hidden" id="music-setup">
        <div class="music-hint" id="music-setup-hint">${n("music.setup_hint")}</div>
        <!-- 凭据字段默认只在「没有内置 Client ID」或用户主动展开时显示：
             内置值让「登录」变成一步操作，Redirect URI 那一串对普通用户是噪音。 -->
        <button class="music-ghost-btn music-fields-toggle hidden" id="music-fields-toggle"></button>
        <div id="music-setup-fields">
          <div class="music-field">
            <label for="music-client-id">${n("music.client_id")}</label>
            <input id="music-client-id" type="text" spellcheck="false" autocomplete="off" placeholder="${a(n("music.client_id_ph"))}">
          </div>
          <div class="music-field music-field-port">
            <label for="music-port">${n("music.port")}</label>
            <input id="music-port" type="text" inputmode="numeric" autocomplete="off">
          </div>
          <div class="music-field">
            <label>${n("music.redirect")}</label>
            <div class="music-redirect-row">
              <code id="music-redirect"></code>
              <button class="music-ghost-btn music-icon-btn" id="music-copy-redirect" title="${a(n("music.copy"))}">${m.copy}</button>
            </div>
          </div>
          <!-- 本机播放（librespot）的两项设置：路径留空 = 自动探测；代理留空 = 直连。
               两者都不是「必填」，所以各带一行小字说明（见 renderSetup）。 -->
          <div class="music-field">
            <label for="music-librespot">${n("music.local_play")}</label>
            <input id="music-librespot" type="text" spellcheck="false" autocomplete="off" placeholder="librespot.exe">
          </div>
          <div class="music-field">
            <label for="music-librespot-proxy">proxy</label>
            <input id="music-librespot-proxy" type="text" spellcheck="false" autocomplete="off" placeholder="http://127.0.0.1:7890">
          </div>
        </div>
        <div class="music-actions">
          <button class="music-btn" id="music-save">${n("music.save")}</button>
          <button class="music-btn music-primary" id="music-connect">${m.link} ${n("music.connect")}</button>
          <button class="music-btn" id="music-disconnect">${m.power} ${n("music.disconnect")}</button>
        </div>
      </div>

      <!-- 主体：**左栏（宽度可拖）+ 分隔条 + 主区**（用户 2026-09-28 的
           「歌单列作为单独的一列可拉动」「中间大的大部分区域作为歌曲列表」）。
           两栏各自内部滚动 —— 窗口是定尺 1280×720，不是靠内容撑出来的。 -->
      <div class="music-body hidden" id="music-body">
        <aside class="music-side" id="music-side">
          <div class="music-side-tabs" id="music-side-tabs">
            <button class="music-tab on" data-act="side-tab" data-tab="playlist">${n("music.playlists")}</button>
            <button class="music-tab" data-act="side-tab" data-tab="album">${n("music.tab_albums")}</button>
            <button class="music-tab" data-act="side-tab" data-tab="artist">${n("music.tab_artists")}</button>
            <button class="music-tab" data-act="side-tab" data-tab="show">${n("music.tab_shows")}</button>
            <!-- 「发现」两栏（2026-10-01 用户第 4 条）。**放在最后**：那四栏是「我的库」，
                 这两栏是「库外的东西」，顺序上按这个分组走。
                 注：本段在模板字符串里，注释里不能出现反引号（预检 #15 / #39 ⑩）。 -->
            <button class="music-tab" data-act="side-tab" data-tab="new">${n("music.tab_new")}</button>
            <button class="music-tab" data-act="side-tab" data-tab="top">${n("music.tab_top")}</button>
          </div>
          <!-- 「本地音乐」那一页的左栏头（与上面那排 Spotify 页签**互斥显示**）：
               一个标题 + 一个「添加目录」。它跟着 localPage 切，见 renderLocalSide。 -->
          <div class="music-local-head hidden" id="music-local-head">
            <span class="music-local-title">${n("music.local_library")}</span>
            <div class="music-local-head-btns">
              <!-- 正常态三枚（2026-10-01 用户口径）：
                   ＋ = 添加（**目录或播放列表文件**，两个入口合一）
                   ✎ = 修改列表（进编辑态）—— 取代原来那枚「打开播放列表文件」
                   ⟳ = 重扫。
                   图标一律取自 icon-style.md §3，不自己画（见 SVG.edit / SVG.trash）。 -->
              <button class="music-ghost-btn music-icon-btn" id="music-local-add" title="${a(n("music.local_add"))}">${m.plus}</button>
              <button class="music-ghost-btn music-icon-btn" id="music-local-list" title="${a(n("music.local_edit"))}">${m.edit}</button>
              <button class="music-ghost-btn music-icon-btn" id="music-local-scan" title="${a(n("music.local_rescan"))}">${m.refresh}</button>
              <!-- 编辑态两枚（正常态隐藏，切法见 renderLocalHead）：
                   🗑 = 把勾选的行**摘出列表**（暂存，还能反悔）
                   × = 退出并保存（到这一步才真落盘） -->
              <button class="music-ghost-btn music-icon-btn hidden" id="music-local-del" title="${a(n("music.local_del_sel"))}">${m.trash}</button>
              <button class="music-ghost-btn music-icon-btn hidden" id="music-local-editdone" title="${a(n("music.local_edit_done"))}">${m.x}</button>
              <!-- 那个「＋」的二选一浮层（目录 / 播放列表文件）。画法见 renderLocalAddMenu，
                   定位参照是上面那排按钮（.music-local-head-btns 是 relative）。
                   注：本段在**模板字符串**里，注释里一个反引号都不能出现（预检 #15 / #39 ⑩）。 -->
              <div class="music-dd music-local-add-dd hidden" id="music-local-add-dd"></div>
            </div>
          </div>
          <div class="music-side-list" id="music-side-list"></div>
        </aside>
        <div class="music-split" id="music-split" role="separator" aria-orientation="vertical"></div>
        <main class="music-main" id="music-main"></main>
      </div>

      <!-- ── 底部控制栏（2026-09-28，Spotify 复刻）─────────────────────────
           用户要求「在默认面板下方添加 Spotify 那样的播放控制，并把一些按钮也
           移动到下方控制」。三列 grid：左 = 正在播放（点它 = 打开播放面板）、
           中 = 播放键组、右 = 设备 / 音量 / 队列 / 展开。
           栏顶那条 2px 细进度线**绝对定位**（不占高），拖动即可跳转。
           **两个弹层都挂在右端那一簇里、向上弹**：这条栏贴着窗口下沿，
           向下弹会跑到窗口外面（见 styles.css 里那两条覆盖 top 的规则）。
           注意本段是 JS 模板字符串 —— 注释里不能出现反引号（会把字符串截断）。 -->
      <div class="music-nowbar hidden" id="music-nowbar">
        <div class="music-bp music-bp-timed" id="music-bp" title="${a(n("music.seek"))}">
          <div class="music-bp-fill" id="music-bp-fill"></div>
          <div class="music-progress-tip" id="music-bp-tip">0:00</div>
          <span class="music-btime" id="music-b-time">00:00 / 00:00</span>
        </div>
        <button class="music-bnow" id="music-bnow" title="${a(n("music.open_player"))}">
          <span class="music-bnow-cover" id="music-bnow-cover"></span>
          <span class="music-bnow-main">
            <span class="music-bnow-n" id="music-bnow-n"></span>
            <span class="music-bnow-a" id="music-bnow-a"></span>
          </span>
        </button>
        <div class="music-bctl">
          <button class="music-round-btn music-mode-btn" id="music-b-mode" data-mode="off"></button>
          <button class="music-round-btn" id="music-b-prev" title="${a(n("music.prev"))}">${m.prev}</button>
          <button class="music-round-btn music-play-btn" id="music-b-play" title="${a(n("music.play_pause"))}">${m.play}</button>
          <button class="music-round-btn" id="music-b-next" title="${a(n("music.next"))}">${m.next}</button>
        </div>
        <div class="music-bend">
          <!-- 与本地播放条上那一枚是**同一个状态**（见 dualPlay 的注释）。
               两枚按钮各自长在自己的控制区里，用户在哪条栏上都够得着。 -->
          <button class="music-ghost-btn music-icon-btn music-dual-btn" id="music-dual-btn" title="${a(n("music.dual_play"))}">${m.dual}</button>
          <button class="music-ghost-btn music-icon-btn" id="music-devices-btn" title="${a(n("music.devices"))}">${m.speaker}</button>
          <span class="music-vol-ico">${m.volume}</span>
          <input class="music-vol" id="music-b-vol" type="range" min="0" max="100" step="1" value="50" style="--vol-pct:50%" title="${a(n("music.volume"))}">
          <button class="music-round-btn" id="music-b-queue" title="${a(n("music.queue"))}">${m.list}</button>
          <button class="music-ghost-btn music-icon-btn hidden" id="music-open-player" title="${a(n("music.open_player"))}">${m.expand}</button>
          <div class="music-dd music-dev-dd hidden" id="music-dev-dd"></div>
          <div class="music-dd hidden" id="music-q-dd"></div>
        </div>
      </div>

      <!-- ── 本地文件播放条（2026-10-01）───────────────────────────────
           与上面那条 Spotify 控制栏**不是一条**：那条的对象是远端播放器
           （Web API 的 spotify_* 命令），这条的对象是宿主里那条本机音频流
           （player.rs 的 player_* 命令）。两者的数据源、可用条件（这条不要求
           登录 Spotify）、能做的事都不一样 —— 合成一条会到处长出
           「如果是本地就…」的分支，那正是两套东西被缝在一起的样子。
           只在「本地页 + 有本地会话」时出现，见 renderLocalNowbar。
           注意本段是 JS 模板字符串 —— 注释里不能出现反引号。 -->
      <div class="music-nowbar music-lnowbar hidden" id="music-lnowbar">
        <div class="music-bp" id="music-lbp" title="${a(n("music.seek"))}">
          <div class="music-bp-fill" id="music-lbp-fill"></div>
          <div class="music-progress-tip" id="music-lbp-tip">0:00</div>
        </div>
        <div class="music-bnow music-lnow">
          <span class="music-bnow-cover" id="music-lnow-cover"></span>
          <span class="music-bnow-main">
            <span class="music-bnow-n" id="music-lnow-n"></span>
            <span class="music-bnow-a" id="music-lnow-a"></span>
          </span>
        </div>
        <div class="music-bctl">
          <!-- 播放模式（关 / 随机 / 循环列表 / 单曲循环，2026-10-01 用户第 8 条）。
               与 Spotify 那枚 #music-b-mode **不是一件事**：那枚是远端真相，
               这枚是前端自己算的（见 localMode 的注释），所以两枚各记各的状态。
               注：本段在模板字符串里，注释里不能出现反引号（预检 #15 / #39 ⑩）。 -->
          <button class="music-round-btn music-mode-btn" id="music-l-mode" data-mode="off" title="${a(n("music.mode_off"))}"></button>
          <button class="music-round-btn" id="music-l-prev" title="${a(n("music.prev"))}">${m.prev}</button>
          <button class="music-round-btn music-play-btn" id="music-l-play" title="${a(n("music.play_pause"))}">${m.play}</button>
          <button class="music-round-btn" id="music-l-next" title="${a(n("music.next"))}">${m.next}</button>
          <button class="music-round-btn" id="music-l-stop" title="${a(n("music.local_stop"))}">${m.stop}</button>
        </div>
        <div class="music-bend">
          <button class="music-ghost-btn music-icon-btn music-dual-btn" id="music-l-dual-btn" title="${a(n("music.dual_play"))}">${m.dual}</button>
          <span class="music-ltime" id="music-l-time">0:00 / 0:00</span>
          <span class="music-vol-ico">${m.volume}</span>
          <input class="music-vol" id="music-l-vol" type="range" min="0" max="100" step="1" value="80" style="--vol-pct:80%" title="${a(n("music.volume"))}">
          <!-- 小窗入口（2026-10-01 用户口径：本地播放也要有）。与 Spotify 那条栏
               右端那枚 #music-open-player 同形同义 —— 只是它带去的是**本地**那条
               长条（#music-v-lplayer），由 mode = "lplayer" 切。 -->
          <button class="music-ghost-btn music-icon-btn" id="music-l-open-player" title="${a(n("music.open_player"))}">${m.expand}</button>
        </div>
      </div>
    </div>

    <!-- ── 播放界面：**550×130 的长条**（封面 100 + 右侧列 450）──────────
         右侧列三块的高度加起来正好是长条高：歌名 30 + 歌词 65 + 控制 35 = 130。
         **这几个数都是用户 2026-09-27 给的定尺**：改任何一个都要同步
         styles.css 的 .music-name / .music-lyr / .music-bar，以及宿主
         plugin_window.rs 的 MUSIC_W（见 ai-spec §4.6 与预检 #39 ④）。 -->
    <!-- 注意：本段是 JS 模板字符串，**注释里不能出现反引号**（会把字符串截断）。 -->
    <div class="music-view music-player hidden" id="music-v-player">
      <div class="music-pv-card">
        <div class="music-pv-cover" id="music-pv-cover"></div>
        <div class="music-pv-col">
          <!-- 歌名模块 H30：歌名（亮）+ 歌手·专辑（暗）。 -->
          <div class="music-name">
            <div class="music-name-text">
              <span class="music-title" id="music-pv-title"></span>
              <span class="music-sub" id="music-pv-sub"></span>
            </div>
            <!-- 「返回歌单」那枚**已删除**（2026-10-01 用户口径：小窗播放里那个不是
                 状态栏里的返回按钮要去掉）。退出去仍然走**标题栏那个 ←** ——
                 它在播放态由 syncTitlebarClose 把 × 换成 ←，语义是「停播 + 回默认面板」
                 （见 stopAndBack），也是用户当初指定的出口。所以这里删掉不留缺口。 -->
          </div>

          <!-- 歌词模块 H65：正好两行可见（行高 32）。已过 + 正在 = 亮，未到 = 暗；
               点某一行 = 跳到那一句的进度。 -->
          <div class="music-lyr" id="music-lyr"></div>

          <!-- 控制面板 H35：进度条**叠在本块顶部**（绝对定位 ⇒ 不占高度，总高仍是 130），
               四个播放键在块内居中，右端音量条 80px + 播放列表按钮。 -->
          <div class="music-bar">
            <!-- 时间在控制块**最左端、进度条下方**（用户 2026-09-27 定）。
                 绝对定位 ⇒ 不参与四钮的居中计算。 -->
            <div class="music-time">
              <span id="music-pv-pos">0:00</span><span class="music-time-sep">/</span><span id="music-pv-dur">0:00</span>
            </div>
            <div class="music-progress" id="music-pv-progress" title="${a(n("music.seek"))}">
              <div class="music-progress-fill" id="music-pv-fill"></div>
              <div class="music-progress-dot" id="music-pv-dot"></div>
              <div class="music-progress-tip" id="music-pv-tip">0:00</div>
            </div>
            <div class="music-bar-main">
              <button class="music-round-btn music-mode-btn" id="music-mode" data-mode="off"></button>
              <button class="music-round-btn" id="music-prev" title="${a(n("music.prev"))}">${m.prev}</button>
              <button class="music-round-btn music-play-btn" id="music-play" title="${a(n("music.play_pause"))}">${m.play}</button>
              <button class="music-round-btn" id="music-next" title="${a(n("music.next"))}">${m.next}</button>
            </div>
            <div class="music-bar-end">
              <span class="music-vol-ico">${m.volume}</span>
              <input class="music-vol" id="music-vol" type="range" min="0" max="100" step="1" value="50" style="--vol-pct:50%" title="${a(n("music.volume"))}">
              <button class="music-round-btn" id="music-queue-btn" title="${a(n("music.queue"))}">${m.list}</button>
            </div>
          </div>
        </div>
      </div>

      <!-- 播放列表（队列）挂在长条**下方**、不再与歌词互斥：长条是定尺 130，
           塞不进队列。开着时窗口按内容长高（applyResize 实测贴合）。 -->
      <div class="music-q-wrap hidden" id="music-q-wrap">
        <div class="music-sec-head">
          <span class="music-sec-title">${n("music.queue")}</span>
          <span class="music-sec-note">${n("music.queue_hint")}</span>
        </div>
        <div class="music-q" id="music-q"></div>
      </div>
    </div>

    <!-- ── 本地小窗：**本地文件播放也有的那条长条**（2026-10-01 用户口径
         「在本地文件播放的情况下也添加小窗模式」）────────────────────────
         与上一个视图**共用同一套外壳类**（music-player / music-pv-card / music-pv-cover /
         music-name / music-bar / music-bp…）⇒ 尺寸（550×130）、圆角、配色、
         进度条的细线与命中区，一行业务 CSS 都不用重写。
         唯一的差别在**中间那一块**：远端那条长条放的是歌词（H65，见 .music-lyr），
         本地文件没有歌词 —— 那一格换成**大号进度线 + 时间**（见 .music-lp-mid）。
         三块的高度仍是 30 + 65 + 35 = 130，与 MUSIC_W_BAR / applyResize 对齐。
         数据与动作**都只有一份**：状态来自 localPlayer，按钮走的是本地播放那几条
         既有函数（见 attachMusicListeners 里那几条绑定）。
         注意本段是 JS 模板字符串 —— 注释里不能出现反引号（预检 #15 / #39 ⑩）。 -->
    <div class="music-view music-player hidden" id="music-v-lplayer">
      <div class="music-pv-card">
        <div class="music-pv-cover" id="music-lp-cover"></div>
        <div class="music-pv-col">
          <div class="music-name">
            <div class="music-name-text">
              <span class="music-title" id="music-lp-title"></span>
              <span class="music-sub" id="music-lp-sub"></span>
            </div>
          </div>
          <div class="music-lp-mid">
            <div class="music-bp music-lp-seek" id="music-lp-progress" title="${a(n("music.seek"))}">
              <div class="music-bp-fill" id="music-lp-fill"></div>
              <div class="music-progress-tip" id="music-lp-tip">0:00</div>
            </div>
            <div class="music-lp-time" id="music-lp-time">0:00 / 0:00</div>
          </div>
          <div class="music-bar">
            <div class="music-bar-main">
              <button class="music-round-btn music-mode-btn" id="music-lp-mode" data-mode="off" title="${a(n("music.mode_off"))}"></button>
              <button class="music-round-btn" id="music-lp-prev" title="${a(n("music.prev"))}">${m.prev}</button>
              <button class="music-round-btn music-play-btn" id="music-lp-play" title="${a(n("music.play_pause"))}">${m.play}</button>
              <button class="music-round-btn" id="music-lp-next" title="${a(n("music.next"))}">${m.next}</button>
              <button class="music-round-btn" id="music-lp-stop" title="${a(n("music.local_stop"))}">${m.stop}</button>
            </div>
            <div class="music-bar-end">
              <span class="music-vol-ico">${m.volume}</span>
              <input class="music-vol" id="music-lp-vol" type="range" min="0" max="100" step="1" value="80" style="--vol-pct:80%" title="${a(n("music.volume"))}">
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- ── 设置页：**整屏**（2026-10-01 用户要求「设置图标进到一个新的设置页面」）──
         与 #music-v-player 同为整屏视图，由 mode = "settings" 切（见 renderMode）。
         职责划分是硬的：**这里只放「偏好」，「连接」仍归头像点开的 #music-setup**
         （Client ID / 端口 / 回调 / librespot 路径与代理），**「调音」也有自己的一页**
         （#music-v-tuning，2026-10-01 用户要求搬出去的）。理由与那张卡片里的
         「保存」按钮直接相关 —— 一个卡片里塞两套保存语义必然出岔子，而现在这几页
         各有各的保存。
         ⚠️ 本段是 JS 模板字符串 —— 注释里**不许出现反引号**，连「引用一个标识符」
         那种写法都不行：它会把模板字符串提前截断（预检 #15 / #39 ⑩，本轮又踩了一次）。 -->
    <div class="music-view music-setview hidden" id="music-v-settings">
      <div class="music-set-head">
        <button class="music-ghost-btn music-icon-btn" id="music-set-back" title="${a(n("music.settings_back"))}">${m.back}</button>
        <span class="music-set-title">${n("music.settings")}</span>
      </div>
      <div class="music-set-body">
        <!-- 串流质量：三档互斥按钮。**不用原生 select 元素** —— WebView2 透明窗口里
             它不渲染弹出层（code-rules §5.2）。三档值只允许 96/160/320（宿主侧
             LIBRESPOT_BITRATES，抄自 librespot --help 的原文）。
             ⚠️ 模板字符串 ⇒ 本段注释里也不许出现反引号（预检 #39 ⑩）。 -->
        <div class="music-field">
          <label>${n("music.quality")}</label>
          <div class="music-seg" id="music-quality">
            ${[96, 160, 320].map((e) => `<button type="button" class="music-seg-btn" data-q="${e}">${e}k</button>`).join("")}
          </div>
          <div class="music-hint">${a(n("music.quality_hint"))}</div>
          <div class="music-hint">${a(n("music.quality_local_note"))}</div>
        </div>
        <div class="music-actions">
          <button class="music-btn" id="music-set-save">${n("music.save")}</button>
        </div>
      </div>
    </div>

    <!-- ── 调音页：**自己一页**（2026-10-01 用户口径）────────────────────
         用户明确「调音插件的界面不能放置到设置界面里，要新建一个界面专门用来显示调音」
         —— 所以它在 2026-10-01 从设置页那一块**整段搬过来**（上一版是「调音分区」）。
         入口只有一个：标题栏那枚三段切换的第三段（见 renderTitlebarSwitch），
         另配一枚返回（与设置页同形）。
         三条纪律不变：① 控件**按下就生效、也当场落盘**（与设置页「音质」那两条攒着
         等保存完全不同：音质要重启 librespot 才生效，调音是实时的）；
         ② 预设按钮的**键来自宿主**（tuning.presets 那个字段），文案由 i18n 出 ——
         前端不维护第二份名单，加一档只改宿主那一张表；
         ③ 只对**本地文件播放**生效（Spotify 那条流在本机之外，宿主碰不到）。
         ⚠️ 本段是 JS 模板字符串 ⇒ 注释里不许出现反引号（预检 #15 / #39 ⑩）。 -->
    <div class="music-view music-setview hidden" id="music-v-tuning">
      <div class="music-set-head">
        <button class="music-ghost-btn music-icon-btn" id="music-tune-back" title="${a(n("music.settings_back"))}">${m.back}</button>
        <span class="music-set-title">${n("music.tuning")}</span>
      </div>
      <div class="music-set-body">
        <div class="music-field">
          <label>${n("music.tuning")}</label>
          <div class="music-seg" id="music-tuning-on">
            <button type="button" class="music-seg-btn" data-on="1">${n("music.tuning_on")}</button>
            <button type="button" class="music-seg-btn" data-on="0">${n("music.tuning_off")}</button>
          </div>
          <div class="music-seg music-seg-wrap" id="music-tuning-preset"></div>
          <div class="music-hint">${a(n("music.tuning_hint"))}</div>
          <div class="music-hint">${a(n("music.tuning_note"))}</div>
        </div>
      </div>
    </div>

    <div class="music-msg" id="music-msg"></div>
  </div>`;
}
function b(e, i) {
  e && e.textContent !== i && (e.textContent = i);
}
function w(e, i) {
  e && e.innerHTML !== i && (e.innerHTML = i);
}
function S(e, i) {
  e == null || e.classList.toggle("hidden", !i);
}
function ri(e, i, t) {
  e && e.getAttribute(i) !== t && e.setAttribute(i, t);
}
function Pi(e, i) {
  if (!e) return;
  const t = Math.max(0, Math.min(100, Math.round(i)));
  e.style.setProperty("--vol-pct", `${t}%`);
}
function cn(e) {
  const i = e.querySelector("#music-msg");
  if (!i) return;
  const t = i.textContent ?? "";
  if (t !== $e) {
    $e = t, ke = Date.now();
    return;
  }
  t && Date.now() - ke >= Fs && (i.textContent = "", $e = "", ke = 0);
}
function U(e) {
  const i = Ie();
  S(e.querySelector("#music-v-default"), $ === "default"), S(e.querySelector("#music-v-player"), $ === "player"), S(e.querySelector("#music-v-lplayer"), $ === "lplayer"), S(e.querySelector("#music-v-settings"), $ === "settings");
  const t = $ === "tuning";
  S(e.querySelector("#music-v-tuning"), t), t && us(e), e.classList.toggle("music-player-on", i), an(i), ln(), Ke(e), dn(), $ === "player" ? (wi = -1, Ce(e), De(e)) : $ === "lplayer" ? ps(e) : $ === "default" && (S(e.querySelector("#music-body"), !!(o != null && o.connected) || P), Mi(e), J(e), oi(e), Gi(e)), ue(e);
}
function an(e) {
  const i = !e;
  document.getElementById("plugin-titlebar") && ze !== i && (ze = i, p("plugin_window_set_resizable", { resizable: i }).catch(() => {
  }));
}
function ln() {
  const e = document.getElementById("plugin-close");
  if (!e) return;
  te || (te = e.innerHTML);
  const i = Ie() ? "back" : "close";
  if (e.dataset.mode === i) return;
  e.dataset.mode = i, e.innerHTML = i === "back" ? m.back : te;
  const t = i === "back" ? n("music.back") : "Close";
  e.title = t, e.setAttribute("aria-label", t);
}
function un() {
  const e = document.getElementById("plugin-close");
  !e || !te || e.dataset.mode !== "back" || (e.innerHTML = te, e.title = "Close", e.setAttribute("aria-label", "Close"), e.dataset.mode = "close");
}
function on() {
  return $ === "tuning" ? "tuning" : $ !== "default" ? "" : P ? "local" : "online";
}
function rn(e) {
  const i = document.getElementById("music-tb-switch");
  if (i) return i;
  const t = document.createElement("div");
  t.id = "music-tb-switch", t.className = "music-tb-switch", t.setAttribute("role", "tablist"), t.setAttribute("data-tauri-drag-region", "");
  const s = [
    ["online", n("music.tb_online")],
    ["local", n("music.tb_local")],
    ["tuning", n("music.tb_tuning")]
  ];
  t.innerHTML = s.map(([v, E]) => `<button type="button" class="music-tb-seg" role="tab" data-seg="${v}" title="${a(E)}">${a(E)}</button>`).join("");
  const c = document.getElementById("plugin-titlebar"), l = document.getElementById("plugin-title");
  if (c && l)
    c.insertBefore(t, l.nextSibling);
  else {
    const v = e.querySelector("#music-setup-toggle"), E = e.querySelector(".music-toolbar");
    if (!E) return null;
    E.insertBefore(t, v);
  }
  return t;
}
function dn() {
  const e = document.getElementById("music-tb-switch");
  if (!e) return;
  const i = on();
  for (const t of e.querySelectorAll(".music-tb-seg"))
    ri(t, "aria-pressed", String(t.dataset.seg === i));
}
function mn() {
  var e;
  (e = document.getElementById("music-tb-switch")) == null || e.remove();
}
async function pn(e) {
  try {
    await p("spotify_control", { action: "pause" });
  } catch (i) {
    k(e, L(i));
  }
  $ = "default", U(e);
}
function ls(e) {
  const i = e.querySelector("#music-setup-toggle"), t = e.querySelector(".music-toolbar");
  if (!i || !t) return;
  const s = e.querySelector(".music-local-head-row"), c = P && s ? s : t;
  i.parentElement !== c && c.appendChild(i);
}
function Ke(e) {
  const i = $ === "player";
  S(e.querySelector("#music-open-player"), !i && !!(r != null && r.track)), S(e.querySelector("#music-nowbar"), !i && !!(o != null && o.connected) && !P);
  for (const t of [".music-search-wrap", "#music-avatar", "#music-acc", "#music-status"])
    S(e.querySelector(t), !P);
  ls(e), e.querySelectorAll(".music-dual-btn").forEach((t) => t.classList.toggle("on", pi));
}
function Di(e, i) {
  const t = e.querySelector("#music-status");
  o != null && o.client_id ? o.connected ? r ? r.active ? r.playing ? b(t, n("music.status_playing")) : b(t, n("music.status_paused")) : b(t, n("music.status_no_device")) : b(t, n("music.status_connecting")) : b(t, n("music.status_disconnected")) : b(t, n("music.status_unconfigured"));
  const s = e.querySelector("#music-avatar");
  if (s) {
    const l = o != null && o.connected && o.avatar || "";
    w(s, l ? `<img src="${a(l)}" alt="">` : "");
  }
  b(e.querySelector("#music-acc"), o != null && o.connected && o.display_name || "");
  const c = e.querySelector("#music-devices-btn");
  c && (ri(c, "title", `${n("music.devices")}：${(r == null ? void 0 : r.device) || n("music.device_none")}`), c.classList.toggle("warn", !!(o != null && o.connected) && !(r != null && r.active)));
}
function Ri(e) {
  S(e.querySelector("#music-setup"), !(o != null && o.connected) || ge), S(e.querySelector("#music-body"), !!(o != null && o.connected) || P), Mi(e), J(e), o != null && o.connected && (gs(e, F), _s(e));
  const i = he ?? !(o != null && o.builtin);
  S(e.querySelector("#music-setup-fields"), i), S(e.querySelector("#music-save"), i);
  const t = e.querySelector("#music-fields-toggle");
  S(t, !!(o != null && o.builtin)), b(t, n(i ? "music.hide_fields" : "music.use_own_client_id")), b(
    e.querySelector("#music-setup-hint"),
    o != null && o.builtin ? n("music.setup_builtin") : n("music.setup_hint")
  );
  const s = e.querySelector("#music-client-id"), c = e.querySelector("#music-port"), l = e.querySelector("#music-librespot"), v = e.querySelector("#music-librespot-proxy");
  s && document.activeElement !== s && (s.value = (o == null ? void 0 : o.client_id) ?? ""), c && document.activeElement !== c && (c.value = String((o == null ? void 0 : o.port) ?? 8899)), l && document.activeElement !== l && (l.value = (o == null ? void 0 : o.librespot_path) ?? ""), v && document.activeElement !== v && (v.value = (o == null ? void 0 : o.librespot_proxy) ?? "");
  const E = Yi ?? (o == null ? void 0 : o.librespot_bitrate) ?? 320;
  for (const C of e.querySelectorAll("#music-quality .music-seg-btn"))
    ri(C, "aria-pressed", String(Number(C.dataset.q) === E));
  b(e.querySelector("#music-redirect"), (o == null ? void 0 : o.redirect_uri) ?? "");
}
function vn(e) {
  const i = n(`music.tuning_p_${e}`);
  return i.startsWith("music.") ? e : i;
}
async function us(e) {
  try {
    V = await p("player_tuning_get");
  } catch (i) {
    k(e, L(i));
    return;
  }
  os(e);
}
function os(e) {
  const i = e.querySelector("#music-tuning-preset");
  if (!i) return;
  const t = (V == null ? void 0 : V.presets) ?? [];
  w(
    i,
    t.map((s) => {
      const c = (V == null ? void 0 : V.preset) === s;
      return `<button type="button" class="music-seg-btn" data-preset="${a(s)}" aria-pressed="${c}">${a(vn(s))}</button>`;
    }).join("")
  );
  for (const s of e.querySelectorAll("#music-tuning-on .music-seg-btn")) {
    const c = s.dataset.on === "1";
    ri(s, "aria-pressed", String(!!V && V.enabled === c));
  }
}
async function Ht(e, i, t) {
  try {
    V = await p("player_tuning_set", { enabled: i, preset: t }), k(e, n("music.tuning_saved"));
  } catch (s) {
    k(e, L(s)), await us(e);
    return;
  }
  os(e);
}
function fn(e) {
  var i;
  return !!e.uri && ((i = r == null ? void 0 : r.track) == null ? void 0 : i.uri) === e.uri;
}
function k(e, i) {
  b(e.querySelector("#music-msg"), i);
}
function Re(e, i, t, s = "", c = "") {
  return `<button class="music-tr${fn(e) ? " playing" : ""}" data-act="${t}" data-uri="${a(e.uri)}"${s ? ` data-i="${a(s)}"` : ""}${c ? ` title="${a(c)}"` : ""}>
    <span class="music-tr-i">${i + 1}</span>
    <span class="music-tr-main">
      <span class="music-tr-n">${a(e.name || "?")}</span>
      <span class="music-tr-a">${a(e.artists || e.album)}</span>
    </span>
    <span class="music-tr-d">${le(e.duration_ms)}</span>
  </button>`;
}
function Ae(e) {
  return { id: e.id, uri: e.uri, name: e.name, cover: e.cover, subtitle: e.owner, total: e.total };
}
function Se(e, i) {
  const t = !!i.uri && (r == null ? void 0 : r.context_uri) === i.uri, s = (h == null ? void 0 : h.kind) === e && h.id === i.id, c = i.cover ? `<img src="${a(i.cover)}" alt="">` : "";
  return `<div class="music-pl${t ? " playing" : ""}${s ? " on" : ""}" data-uri="${a(i.uri)}">
    <button class="music-pl-btn" data-act="open" data-kind="${e}" data-id="${a(i.id)}" title="${a(i.name || "?")}">
      <span class="music-pl-cover">${c}</span>
      <span class="music-pl-main">
        <span class="music-pl-name">${a(i.name || "?")}</span>
        <span class="music-pl-sub">${a(i.subtitle)}</span>
      </span>
    </button>
  </div>`;
}
function yn() {
  return `<div class="music-pl${(h == null ? void 0 : h.kind) === "top-tracks" ? " on" : ""}">
    <button class="music-pl-btn" data-act="open" data-kind="top-tracks" data-id="top-tracks" title="${a(n("music.top_tracks"))}">
      <span class="music-pl-cover music-pl-trend-cover">${m.trend}</span>
      <span class="music-pl-main">
        <span class="music-pl-name">${a(n("music.top_tracks"))}</span>
        <span class="music-pl-sub">${a(n("music.top_tracks_sub"))}</span>
      </span>
    </button>
  </div>`;
}
function bn(e, i) {
  const t = i.cover ? `<img src="${a(i.cover)}" alt="">` : "";
  return `<button class="music-card" data-act="open" data-kind="${e}" data-id="${a(i.id)}" title="${a(i.name)}">
    <span class="music-card-cover${e === "artist" ? " round" : ""}">${t}</span>
    <span class="music-card-n">${a(i.name)}</span>
    <span class="music-card-s">${a(i.subtitle)}</span>
  </button>`;
}
function hn() {
  const e = (h == null ? void 0 : h.kind) === "liked", i = R ? String(R.total) : "", t = Li || [(o == null ? void 0 : o.display_name) || "", i].filter(Boolean).join(" · ");
  return `<div class="music-pl music-pl-liked${e ? " on" : ""}${Li ? " err" : ""}">
    <button class="music-pl-btn" data-act="open" data-kind="liked" data-id="liked" title="${a(n("music.liked_songs"))}">
      <span class="music-pl-cover music-pl-liked-cover">${m.heart}</span>
      <span class="music-pl-main">
        <span class="music-pl-name">${a(n("music.liked_songs"))}</span>
        <span class="music-pl-sub">${a(t)}</span>
      </span>
    </button>
  </div>`;
}
function Mi(e) {
  if (P) {
    gi(e);
    return;
  }
  S(e.querySelector("#music-side-tabs"), !0), S(e.querySelector("#music-local-head"), !1), e.querySelectorAll("#music-side-tabs .music-tab").forEach((l) => {
    l.classList.toggle("on", l.dataset.tab === F);
  });
  const i = e.querySelector("#music-side-list");
  if (!i) return;
  if (!(o != null && o.connected)) {
    w(i, `<div class="music-empty">${n("music.playlists_login")}</div>`);
    return;
  }
  const t = Ui.get(F), s = oe.get(F);
  let c = F === "playlist" ? hn() : F === "top" ? yn() : "";
  ie.has(F) ? c += `<div class="music-empty">${n("music.loading")}</div>` : s ? c += `<div class="music-empty music-empty-err">${a(s)}</div>` : t && (c += t.length === 0 ? `<div class="music-empty">${n(F === "playlist" ? "music.playlists_empty" : "music.lib_empty")}</div>` : t.map((l) => Se(F, l)).join("")), w(i, c);
}
function He(e) {
  e.querySelectorAll("#music-side-list .music-pl").forEach((i) => {
    const t = i.querySelector(".music-pl-btn"), s = !!h && (t == null ? void 0 : t.dataset.kind) === h.kind && (t == null ? void 0 : t.dataset.id) === h.id;
    i.classList.toggle("on", s);
  });
}
function J(e) {
  if (P) {
    ds(e);
    return;
  }
  const i = e.querySelector("#music-main");
  if (!i) return;
  if (bi && ei) {
    w(i, gn());
    return;
  }
  if (!h) {
    w(i, `<div class="music-empty">${o != null && o.connected ? n("music.pick_hint") : n("music.playlists_login")}</div>`);
    return;
  }
  const t = h.cover ? `<img src="${a(h.cover)}" alt="">` : "", s = h.kind === "liked" ? n("music.liked_songs") : h.kind === "top-tracks" ? n("music.top_tracks") : h.kind === "playlist" ? n("music.playlists") : h.kind === "album" ? n("music.tab_albums") : h.kind === "artist" ? n("music.tab_artists") : h.kind === "new" ? n("music.tab_new") : h.kind === "top" ? n("music.tab_top") : n("music.tab_shows");
  let c;
  Bi ? c = `<div class="music-empty">${n("music.loading")}</div>` : vi ? c = `<div class="music-empty music-empty-err">${a(vi)}</div>` : !X || X.length === 0 ? c = `<div class="music-empty">${n("music.playlist_empty")}</div>` : c = X.map((l, v) => Re(l, v, "main-track", String(v))).join(""), w(i, `<div class="music-page">
    <div class="music-page-head">
      <span class="music-page-cover${h.kind === "artist" ? " round" : ""}">${t}</span>
      <div class="music-page-info">
        <span class="music-page-kind">${a(s)}</span>
        <span class="music-page-name">${a(h.name || "?")}</span>
        <span class="music-page-sub">${a(h.subtitle)}</span>
        <div class="music-page-actions">
          <button class="music-btn music-primary" data-act="main-play-all">${m.play} ${n("music.play_all")}</button>
        </div>
      </div>
    </div>
    <div class="music-list">${c}</div>
  </div>`);
}
function gn() {
  const e = M, t = [
    ["tracks", n("music.tracks")],
    ["artists", n("music.tab_artists")],
    ["albums", n("music.tab_albums")],
    ["playlists", n("music.playlists")],
    ["shows", n("music.tab_shows")]
  ].map(([c, l]) => `<button class="music-tab${ni === c ? " on" : ""}" data-act="search-tab" data-tab="${c}">${a(l)}</button>`).join("");
  let s;
  if (Wi || !e)
    s = `<div class="music-empty">${n("music.loading")}</div>`;
  else if (ni === "tracks")
    s = e.tracks.length ? e.tracks.map((c, l) => Re(c, l, "main-track", String(l))).join("") : `<div class="music-empty">${n("music.search_empty")}</div>`;
  else {
    const l = (ni === "artists" ? e.artists : ni === "albums" ? e.albums : ni === "shows" ? e.shows : e.playlists.map(Ae)).map((v) => bn(ni === "playlists" ? "playlist" : ni === "artists" ? "artist" : ni === "albums" ? "album" : "show", v));
    s = l.length ? `<div class="music-grid">${l.join("")}</div>` : `<div class="music-empty">${n("music.search_empty")}</div>`;
  }
  return `<div class="music-page">
    <div class="music-page-info music-page-info-flat">
      <span class="music-page-kind">${n("music.search_result")}</span>
      <span class="music-page-name">${a(ei)}</span>
    </div>
    <div class="music-tabs">${t}</div>
    <div class="music-list">${s}</div>
  </div>`;
}
function oi(e) {
  const i = e.querySelector("#music-search-dd");
  if (!i) return;
  const t = !!(o != null && o.connected) && Z && !!ei;
  if (S(i, t), !t) return;
  if (!M) {
    w(i, Wi ? `<div class="music-empty">${n("music.loading")}</div>` : "");
    return;
  }
  const s = M, c = [];
  s.tracks.slice(0, 3).forEach((l, v) => c.push(Re(l, v, "dd-track"))), s.artists.slice(0, 2).forEach((l) => c.push(Se("artist", l))), s.albums.slice(0, 2).forEach((l) => c.push(Se("album", l))), s.playlists.slice(0, 2).forEach((l) => c.push(Se("playlist", Ae(l)))), c.length || c.push(`<div class="music-empty">${n("music.search_empty")}</div>`), c.push(`<button class="music-dd-all" data-act="search-all">${n("music.search_all")}</button>`), w(i, c.join(""));
}
function Gi(e) {
  const i = e.querySelector("#music-dev-dd");
  if (!i || (S(i, mi), !mi)) return;
  const t = B;
  let s = `<div class="music-dd-head">${n("music.devices")}</div>`;
  t != null && t.available && !t.has_credentials ? s += `<button class="music-dev-row" data-act="local-login">
      <span class="music-dev-ico">${m.power}</span>
      <span class="music-dev-main">
        <span class="music-dev-n">${n("music.local_login")}</span>
        <span class="music-dev-s">${n("music.local_login_hint")}</span>
      </span>
    </button>` : t != null && t.available ? s += `<button class="music-dev-row${t.running ? " on" : ""}" data-act="local-toggle">
      <span class="music-dev-ico">${m.power}</span>
      <span class="music-dev-main">
        <span class="music-dev-n">${n("music.local_play")}</span>
        <span class="music-dev-s">${a(t.path || "")}</span>
      </span>
    </button>` : s += `<div class="music-dev-row disabled">
      <span class="music-dev-ico">${m.power}</span>
      <span class="music-dev-main">
        <span class="music-dev-n">${n("music.local_play")}</span>
        <span class="music-dev-s">${n("music.local_no_exe")}</span>
      </span>
    </div>`;
  const c = qi ?? [];
  s += c.length ? c.map((l) => `<button class="music-dev-row${l.active ? " on" : ""}" data-act="dev-pick" data-id="${a(l.id)}">
        <span class="music-dev-ico">${m.speaker}</span>
        <span class="music-dev-main">
          <span class="music-dev-n">${a(l.name || "?")}</span>
          <span class="music-dev-s">${a(l.kind)}</span>
        </span>
      </button>`).join("") : `<div class="music-empty">${n("music.device_none")}</div>`, w(i, s);
}
function _n(e) {
  var s;
  const i = (r == null ? void 0 : r.context_uri) ?? "", t = ((s = r == null ? void 0 : r.track) == null ? void 0 : s.uri) ?? "";
  e.querySelectorAll(".music-pl").forEach((c) => {
    c.classList.toggle("playing", !!i && c.dataset.uri === i);
  }), e.querySelectorAll(".music-tr").forEach((c) => {
    c.classList.toggle("playing", !!t && c.dataset.uri === t);
  });
}
function wn(e) {
  if (!e) return "";
  const i = new Date(e), t = (s) => String(s).padStart(2, "0");
  return `${i.getFullYear()}-${t(i.getMonth() + 1)}-${t(i.getDate())} ${t(i.getHours())}:${t(i.getMinutes())}`;
}
function rs(e) {
  ii && (ci = !1);
  const i = (t, s) => S(e.querySelector(t), s);
  i("#music-local-add", !ii), i("#music-local-list", !ii), i("#music-local-scan", !ii), i("#music-local-del", ii), i("#music-local-editdone", ii), Ji(e);
}
function Ji(e) {
  const i = e.querySelector("#music-local-add-dd");
  i && (S(i, ci), ci && w(i, `
    <div class="music-dd-head">${a(n("music.local_add_head"))}</div>
    <button class="music-dev-row" data-act="media-add-dir">
      <span class="music-dev-ico">${m.folder}</span>
      <span class="music-dev-main">
        <span class="music-dev-n">${a(n("music.local_add_dir"))}</span>
        <span class="music-dev-s">${a(n("music.local_add_dir_hint"))}</span>
      </span>
    </button>
    <button class="music-dev-row" data-act="media-add-list">
      <span class="music-dev-ico">${m.list}</span>
      <span class="music-dev-main">
        <span class="music-dev-n">${a(n("music.local_open_playlist"))}</span>
        <span class="music-dev-s">${a(n("music.local_add_list_hint"))}</span>
      </span>
    </button>`));
}
function $n(e) {
  const i = e.missing ? n("music.local_missing") : [
    n("music.local_n_tracks", { n: String(e.tracks) }),
    e.last_scan_at ? wn(e.last_scan_at) : n("music.local_never_scanned")
  ].join(" · "), t = ii && ai.has(e.path);
  return `<div class="music-pl${ti === e.path ? " on" : ""}${e.missing ? " err" : ""}${t ? " sel" : ""}">
    <button class="music-pl-btn" data-act="media-root" data-path="${a(e.path)}" title="${a(e.path)}">
      <span class="music-pl-cover music-pl-dir">${m.folder}</span>
      <span class="music-pl-main">
        <span class="music-pl-name">${a(e.name || e.path)}</span>
        <span class="music-pl-sub">${a(i)}</span>
      </span>
    </button>
  </div>`;
}
function gi(e) {
  S(e.querySelector("#music-side-tabs"), !1), S(e.querySelector("#music-local-head"), !0), rs(e);
  const i = e.querySelector("#music-side-list");
  if (!i) return;
  const t = (W ?? []).filter((l) => !re.has(l.path)), s = t.reduce((l, v) => l + v.tracks, 0);
  let c = `<div class="music-pl${ti === "" ? " on" : ""}">
    <button class="music-pl-btn" data-act="media-root" data-path="" title="${a(n("music.local_all"))}">
      <span class="music-pl-cover music-pl-dir">${m.note}</span>
      <span class="music-pl-main">
        <span class="music-pl-name">${a(n("music.local_all"))}</span>
        <span class="music-pl-sub">${a(n("music.local_n_tracks", { n: String(s) }))}</span>
      </span>
    </button>
  </div>`;
  qe ? c += `<div class="music-empty">${n("music.loading")}</div>` : Vi ? c += `<div class="music-empty music-empty-err">${a(Vi)}</div>` : W && t.length === 0 ? c += `<div class="music-empty">${a(n("music.local_no_roots"))}</div>` : W && (c += t.map((l) => $n(l)).join("")), w(i, c);
}
function kn(e, i) {
  const t = e.cover ? `<img src="${a(Te(e.cover))}" alt="">` : `<span class="music-mt-ico">${m.note}</span>`, s = [e.artist, e.album].filter(Boolean).join(" · ");
  return `<button class="music-mt${!!(f != null && f.active) && f.path === e.path ? " playing" : ""}" data-act="local-track" data-i="${i}" data-path="${a(e.path)}" title="${a(e.path)}">
    <span class="music-mt-i">${i + 1}</span>
    <span class="music-mt-cover">${t}</span>
    <span class="music-mt-main">
      <span class="music-mt-n">${a(e.title || "?")}</span>
      <span class="music-mt-a">${a(s)}</span>
    </span>
    <span class="music-mt-d">${le(e.duration_ms)}</span>
  </button>`;
}
function ds(e) {
  const i = e.querySelector("#music-main");
  if (!i) return;
  i.querySelector("#music-local-page") || (i.innerHTML = `<div class="music-local-page" id="music-local-page">
      <div class="music-local-head-row">
        <input class="music-local-q" id="music-mt-q" type="search" autocomplete="off" spellcheck="false"
               placeholder="${a(n("music.local_filter_ph"))}" value="${a(de)}">
        <span class="music-list-chip hidden" id="music-list-chip">
          <span class="music-list-chip-n" id="music-list-chip-n"></span>
          <button class="music-pl-x" data-act="media-list-close" title="${a(n("music.local_close_playlist"))}">${m.x}</button>
        </span>
        <!-- 重扫（2026-10-01 用户口径）：**只留图标**，「重扫」那两个可见字去掉 ——
             它右边紧挨着设置齿轮（见 placeGear），带文字那一行会挤。
             title 仍然留着（鼠标悬浮还能问出这是什么）；去掉的是**可见文字**。
             ⚠️ 本行属于**动态骨架**（#music-main 会被 renderMain 整块重写、回来时重建），
             所以它只能走 data-act 委托，直接 addEventListener 会在下次重建时失效。 -->
        <button class="music-ghost-btn music-icon-btn" data-act="media-scan" title="${a(n("music.local_rescan"))}">${m.refresh}</button>
      </div>
      <div class="music-scan hidden" id="music-scan"></div>
      <!-- 视频的**画面层**（2026-10-01 用户第 8 条）。里面那个 video 元素由
           renderLocalVideo 现造现拆（离开 / 换曲时整块清掉，见那里的注释）。
           注：本段在模板字符串里，注释里一个反引号都不能出现（预检 #15 / #39 ⑩）。 -->
      <div class="music-video hidden" id="music-video"></div>
      <div class="music-list" id="music-mt-list"></div>
    </div>`), S(e.querySelector("#music-mt-q"), !Y);
  const t = e.querySelector("#music-list-chip");
  S(t, !!Y), Y && b(
    e.querySelector("#music-list-chip-n"),
    `${Y.name} · ${n("music.local_n_tracks", { n: String((A == null ? void 0 : A.total) ?? 0) })}`
  ), Sn(e), ms(e), En(e), ls(e);
}
function Sn(e) {
  const i = e.querySelector("#music-scan");
  if (!i) return;
  const t = Oi;
  let s = "";
  if (t != null && t.running) {
    const c = t.total, l = c > 0 ? Math.min(100, Math.round(t.scanned / c * 100)) : 0, v = c > 0 ? n("music.local_scanning", { a: String(t.scanned), b: String(c) }) : n("music.local_scanning_n", { a: String(t.scanned) });
    s = `<div class="music-scan-row">
      <span class="music-scan-bar"><span class="music-scan-fill" style="width:${l}%"></span></span>
      <span class="music-scan-txt">${a(v)}</span>
    </div>`;
  } else t != null && t.error ? s = `<div class="music-scan-row music-scan-err">${a(t.error)}</div>` : t != null && t.done_at && (s = `<div class="music-scan-row music-scan-done">${a(n("music.local_scan_done", {
    added: String(t.added),
    updated: String(t.updated),
    removed: String(t.removed),
    failed: String(t.failed)
  }))}</div>`);
  w(i, s), S(i, !!s);
}
function En(e) {
  const i = e.querySelector("#music-mt-list");
  if (!i) return;
  let t;
  Fi ? t = `<div class="music-empty">${n("music.loading")}</div>` : hi ? t = `<div class="music-empty music-empty-err">${a(hi)}</div>` : !Y && W && W.length === 0 ? t = `<div class="music-empty">${a(n("music.local_add_hint"))}</div>` : !A || A.items.length === 0 ? t = `<div class="music-empty">${a(n(Y ? "music.local_list_empty" : "music.local_empty"))}</div>` : (t = A.items.map((s, c) => kn(s, c)).join(""), A.total > A.items.length && (t += `<div class="music-empty">${a(n("music.local_more", {
    a: String(A.items.length),
    b: String(A.total)
  }))}</div>`)), w(i, t);
}
function ms(e) {
  const i = e.querySelector("#music-video");
  if (!i) return;
  const t = f, s = !!t && t.video && t.path !== "";
  if (S(i, s), !s) {
    i.firstChild && (i.innerHTML = "");
    return;
  }
  const c = Te(t.path);
  let l = i.querySelector(".music-video-el");
  if (!l || l.dataset.src !== c) {
    if (i.innerHTML = '<video class="music-video-el" muted playsinline preload="auto"></video>', l = i.querySelector(".music-video-el"), !l) return;
    l.dataset.src = c, l.src = c, l.addEventListener("loadedmetadata", () => Wt(l, t), { once: !0 }), l.addEventListener("error", () => {
      b(e.querySelector("#music-msg"), n("music.video_unsupported"));
    });
  }
  Wt(l, t);
}
function Wt(e, i) {
  i.playing ? e.paused && e.play().catch(() => {
  }) : e.paused || e.pause();
  const t = i.playing ? Date.now() - me : 0, s = (i.position_ms + Math.max(0, t)) / 1e3;
  e.readyState >= 1 && !e.seeking && Math.abs(e.currentTime - s) > Js && (e.currentTime = s);
}
function ps(e) {
  if ($ !== "lplayer") return;
  const i = e.querySelector("#music-v-lplayer"), t = f;
  if (!i || !t || !t.path) return;
  const s = fi[li], c = (s == null ? void 0 : s.title) || t.path.split(/[\\/]/).pop() || t.path;
  b(i.querySelector("#music-lp-title"), c), b(i.querySelector("#music-lp-sub"), s ? [s.artist, s.album].filter(Boolean).join(" · ") : ""), w(
    i.querySelector("#music-lp-cover"),
    s != null && s.cover ? `<img src="${a(Te(s.cover))}" alt="">` : m.note
  ), w(i.querySelector("#music-lp-play"), t.active && t.playing ? m.pause : m.play);
  const l = i.querySelector("#music-lp-mode");
  l && (ri(l, "data-mode", O), ri(l, "title", Je()), w(l, O === "repeat_all" || O === "repeat_one" ? m.repeat : m.shuffle));
  const v = t.duration_ms, E = H >= 0 ? H : v > 0 ? Math.min(1, t.position_ms / v) : 0, C = i.querySelector("#music-lp-progress");
  C && H < 0 && C.style.setProperty("--seek-pct", `${E * 100}%`), b(i.querySelector("#music-lp-time"), v > 0 ? `${I(t.position_ms)} / ${I(v)}` : I(t.position_ms));
  const D = i.querySelector("#music-lp-vol");
  D && document.activeElement !== D && (D.value = String(Math.round(t.volume * 100)), Pi(D, t.volume * 100));
}
function yi(e) {
  ms(e), ps(e);
  const i = e.querySelector("#music-lnowbar");
  if (!i) return;
  const t = f, s = (P || pi) && !!t && t.path !== "";
  if (S(i, s), !s || !t) return;
  const c = fi[li], l = (c == null ? void 0 : c.title) || t.path.split(/[\\/]/).pop() || t.path;
  b(i.querySelector("#music-lnow-n"), l), b(i.querySelector("#music-lnow-a"), c ? [c.artist, c.album].filter(Boolean).join(" · ") : ""), w(
    i.querySelector("#music-lnow-cover"),
    c != null && c.cover ? `<img src="${a(Te(c.cover))}" alt="">` : m.note
  ), w(i.querySelector("#music-l-play"), t.active && t.playing ? m.pause : m.play);
  const v = i.querySelector("#music-l-mode");
  v && (ri(v, "data-mode", O), ri(v, "title", Je()), w(v, O === "repeat_all" || O === "repeat_one" ? m.repeat : m.shuffle));
  const E = t.duration_ms, C = H >= 0 ? H : E > 0 ? Math.min(1, t.position_ms / E) : 0, D = i.querySelector("#music-lbp");
  D && H < 0 && D.style.setProperty("--seek-pct", `${C * 100}%`), b(i.querySelector("#music-l-time"), E > 0 ? `${I(t.position_ms)} / ${I(E)}` : I(t.position_ms));
  const x = i.querySelector("#music-l-vol");
  x && document.activeElement !== x && (x.value = String(Math.round(t.volume * 100)), Pi(x, t.volume * 100));
}
function Ze(e) {
  const i = f != null && f.active ? f.path : "";
  e.querySelectorAll(".music-mt").forEach((t) => {
    t.classList.toggle("playing", !!i && t.dataset.path === i);
  });
}
function di(e) {
  P && (gi(e), ds(e), yi(e));
}
async function vs(e) {
  qe = !0, Vi = "", di(e);
  try {
    W = await p("media_roots");
  } catch (i) {
    Vi = String(i);
  } finally {
    qe = !1, di(e);
  }
}
async function Qi(e) {
  Y = null, Fi = !0, hi = "", di(e);
  try {
    A = await p("media_tracks", {
      // 空串 ⇒ 传 null（宿主的 `Option<String>` 收 None = 全库 / 不筛选）
      root: ti || null,
      query: de || null,
      limit: Gs
    });
  } catch (i) {
    hi = String(i);
  } finally {
    Fi = !1, di(e);
  }
}
function ji() {
  se !== void 0 && (window.clearInterval(se), se = void 0);
}
function fs(e) {
  se === void 0 && (se = window.setInterval(() => {
    (async () => {
      if (!e.isConnected) {
        ji();
        return;
      }
      try {
        const i = await p("media_scan_status");
        Oi = i, i.running || (ji(), await vs(e), await Qi(e));
      } catch {
        ji();
      }
      di(e);
    })();
  }, Qs));
}
async function Qe(e, i) {
  try {
    Oi = await p("media_scan_start", { root: i || null });
  } catch (t) {
    const s = String(t);
    k(e, s.includes("ERR_SCAN_RUNNING") ? n("music.local_scan_busy") : s);
    return;
  }
  di(e), fs(e);
}
async function Ln(e) {
  let i = null;
  try {
    i = await Kt({ directory: !0, multiple: !1, title: n("music.local_add_dir") });
  } catch (t) {
    k(e, String(t));
    return;
  }
  if (!(typeof i != "string" || !i)) {
    try {
      W = await p("media_add_root", { path: i });
    } catch (t) {
      k(e, String(t));
      return;
    }
    ti = xn(i), di(e), await Qe(e, ti || i);
  }
}
function xn(e) {
  var s;
  const i = (c) => c.replace(/[\\/]+$/, "").toLowerCase(), t = i(e);
  return ((s = W == null ? void 0 : W.find((c) => i(c.path) === t)) == null ? void 0 : s.path) ?? "";
}
function qn(e) {
  ii = !0, ai.clear(), gi(e);
}
function Mn(e) {
  if (ai.size) {
    for (const i of ai) re.add(i);
    ai.clear(), gi(e);
  }
}
async function Cn(e) {
  const i = Array.from(re);
  if (ii = !1, ai.clear(), re.clear(), rs(e), !i.length) {
    gi(e);
    return;
  }
  let t = "";
  for (const s of i)
    try {
      W = await p("media_remove_root", { path: s });
    } catch (c) {
      const l = String(c);
      t = l.includes("ERR_SCAN_RUNNING") ? n("music.local_remove_busy") : l;
    }
  ti && !(W ?? []).some((s) => s.path === ti) && (ti = ""), gi(e), await Qi(e), t && k(e, t);
}
function Tn(e) {
  const i = e instanceof Error ? e.message : String(e);
  return i.includes("ERR_NOT_PLAYLIST") ? n("music.local_not_playlist") : i;
}
async function In(e) {
  let i = null;
  try {
    i = await Kt({
      multiple: !1,
      title: n("music.local_open_playlist"),
      filters: [{ name: "Playlist", extensions: ["m3u", "m3u8", "pls"] }]
    });
  } catch (t) {
    k(e, String(t));
    return;
  }
  if (!(typeof i != "string" || !i)) {
    Fi = !0, hi = "", A = null, di(e);
    try {
      A = await p("media_playlist", { path: i }), Y = { path: i, name: i.split(/[\\/]/).pop() || i }, ti = "";
    } catch (t) {
      Y = null, hi = Tn(t);
    } finally {
      Fi = !1, di(e);
    }
  }
}
function Rn(e) {
  Y = null, Qi(e);
}
function ys(e) {
  const i = e instanceof Error ? e.message : String(e);
  return i.includes("ERR_NO_AUDIO_DEVICE") ? n("music.local_no_device") : i.includes("找不到这个文件") ? n("music.local_file_missing") : i.includes("解不开") || i.includes("打不开") ? n("music.local_decode_failed") : i;
}
async function Me(e, i) {
  if (!ki) {
    await pe(e, "local"), ki = !0;
    try {
      f = await p("player_play", { path: i });
    } catch (t) {
      k(e, ys(t)), ki = !1;
      return;
    }
    ki = !1, me = Date.now(), yi(e), Ze(e), bs(e);
  }
}
async function An(e, i) {
  const t = (A == null ? void 0 : A.items) ?? [], s = t[i];
  s && (fi = t.slice(), li = i, await Me(e, s.path));
}
async function Ki(e, i, t) {
  var l;
  const s = fi.length;
  if (s === 0) return;
  if (t && O === "repeat_one") {
    await Me(e, ((l = fi[li]) == null ? void 0 : l.path) ?? "");
    return;
  }
  let c;
  if (O === "shuffle" && s > 1)
    do
      c = Math.floor(Math.random() * s);
    while (c === li);
  else
    c = li + i;
  if (O === "repeat_all" || O === "shuffle")
    c = (c % s + s) % s;
  else if (c < 0 || c >= s) {
    t || k(e, n("music.local_queue_end"));
    return;
  }
  li = c, await Me(e, fi[c].path);
}
async function Ut(e) {
  const i = f;
  if (!(!i || i.path === "") && !ki) {
    if (!i.active) {
      await Me(e, i.path);
      return;
    }
    try {
      f = await p(i.playing ? "player_pause" : "player_resume");
    } catch (t) {
      k(e, ys(t));
      return;
    }
    me = Date.now(), yi(e), f != null && f.active && bs(e);
  }
}
async function Zi(e) {
  Hi(), fi = [], li = -1, H = -1, f = null, me = 0;
  const i = $ === "lplayer";
  i && ($ = "default"), yi(e), Ze(e), i && U(e);
  try {
    await p("player_stop");
  } catch {
  }
}
async function pe(e, i) {
  if (!pi) {
    if (i === "local") {
      if (o != null && o.connected && (r != null && r.playing))
        try {
          await p("spotify_control", { action: "pause" });
        } catch {
        }
      return;
    }
    f && await Zi(e);
  }
}
async function Dn(e, i) {
  try {
    f = await p("player_seek", { positionMs: i });
  } catch {
    return;
  }
  yi(e);
}
async function Vt(e, i) {
  try {
    f = await p("player_volume", { volume: i });
  } catch {
    return;
  }
  yi(e);
}
function Hi() {
  ne !== void 0 && (window.clearInterval(ne), ne = void 0);
}
function bs(e) {
  ne === void 0 && (ne = window.setInterval(() => {
    (async () => {
      if (!e.isConnected) {
        Hi();
        return;
      }
      if (H >= 0 || ki) return;
      let i;
      try {
        i = await p("player_status");
      } catch {
        return;
      }
      if (!e.isConnected) {
        Hi();
        return;
      }
      const t = !i.active && i.path !== "" && i.path === (f == null ? void 0 : f.path);
      f = i, me = Date.now(), yi(e), Ze(e), t && (Hi(), await Ki(e, 1, !0));
    })();
  }, Xs));
}
function Nn(e, i) {
  de = i, z !== void 0 && window.clearTimeout(z), z = window.setTimeout(() => {
    z = void 0, Qi(e);
  }, Ys);
}
function Ft(e) {
  ee = Math.min(is, Math.max(Zt, Math.round(ee))), e.style.setProperty("--music-side-w", `${ee}px`);
}
function hs(e, i) {
  var s;
  if (e === "liked")
    return { id: "liked", uri: "", name: n("music.liked_songs"), cover: "", subtitle: "", total: (R == null ? void 0 : R.total) ?? 0 };
  if (e === "top-tracks")
    return {
      id: "top-tracks",
      uri: "",
      name: n("music.top_tracks"),
      cover: "",
      subtitle: n("music.top_tracks_sub"),
      total: 0
    };
  const t = e === "artist" ? M == null ? void 0 : M.artists : e === "album" ? M == null ? void 0 : M.albums : e === "show" ? M == null ? void 0 : M.shows : M == null ? void 0 : M.playlists.map(Ae);
  return ((s = Ui.get(e)) == null ? void 0 : s.find((c) => c.id === i)) ?? (t == null ? void 0 : t.find((c) => c.id === i)) ?? null;
}
async function gs(e, i) {
  if (!(!(o != null && o.connected) || ie.has(i) || Ui.has(i))) {
    ie.add(i), oe.delete(i), Mi(e);
    try {
      const t = i === "playlist" ? (Fe = await p("spotify_playlists")).map(Ae) : await p(Bs[i]);
      Ui.set(i, t);
    } catch (t) {
      oe.set(i, L(t));
    } finally {
      ie.delete(i), Mi(e);
    }
  }
}
async function Bn(e, i, t) {
  const s = hs(i, t);
  if (s) {
    if (bi = !1, Z = !1, h = { kind: i, id: s.id, uri: s.uri, name: s.name, cover: s.cover, subtitle: s.subtitle }, X = null, vi = "", i === "liked") {
      X = (R == null ? void 0 : R.items) ?? null, vi = Li, Bi = !R, oi(e), He(e), J(e), R || await _s(e);
      return;
    }
    Bi = !0, oi(e), He(e), J(e);
    try {
      X = i === "top-tracks" ? await p("spotify_top_tracks") : await p("spotify_item_tracks", { kind: Ns(i), id: s.id });
    } catch (c) {
      vi = L(c);
    } finally {
      Bi = !1, He(e), J(e);
    }
  }
}
async function zt(e, i, t, s = 0) {
  const c = hs(i, t);
  if (c) {
    await pe(e, "spotify");
    try {
      if (i === "liked" || i === "show" || i === "top-tracks") {
        const l = (i === "liked" ? R == null ? void 0 : R.items : X) ?? [];
        if (!l.length) return;
        await p("spotify_play_uris", { uris: l.slice(Math.max(0, s)).map((v) => v.uri), deviceId: si || void 0 });
      } else if (c.uri)
        await p("spotify_play_context", { contextUri: c.uri, offsetUri: "", deviceId: si || void 0 });
      else
        return;
    } catch (l) {
      k(e, L(l));
    }
  }
}
async function On(e, i) {
  if (!h) return;
  const t = X ?? [], s = t[i];
  if (s) {
    await pe(e, "spotify");
    try {
      h.kind === "liked" || h.kind === "show" ? await p("spotify_play_uris", { uris: t.slice(i).map((c) => c.uri), deviceId: si || void 0 }) : await p("spotify_play_context", { contextUri: h.uri, offsetUri: s.uri, deviceId: si || void 0 });
    } catch (c) {
      k(e, L(c));
    }
  }
}
async function Ye(e) {
  if (!(o != null && o.connected)) return;
  const i = !!(B != null && B.running), t = window.setTimeout(() => k(e, n("music.auto_starting")), 600);
  try {
    const s = await p("music_autoconfigure", { allowLocal: !xe });
    si = s.device_id || "", s.source === "needs_login" ? k(e, n("music.auto_need_login")) : s.source === "local" && !s.device_id ? k(e, n("music.auto_local_unregistered")) : s.started_local && !i ? k(e, n("music.auto_local_started")) : s.source === "start_failed" ? k(e, n("music.auto_start_failed")) : s.source === "none" && !xe && k(e, n("music.auto_none"));
  } catch (s) {
    si = "", String(s) !== "ERR_NOT_CONNECTED" && k(e, L(s));
  } finally {
    window.clearTimeout(t);
  }
  await ve(e);
}
async function ve(e) {
  try {
    qi = await p("spotify_devices");
  } catch (i) {
    qi = [], k(e, L(i));
  }
  try {
    B = await p("librespot_status");
  } catch {
    B = null;
  }
  Gi(e);
}
async function Pn(e) {
  if (!(B != null && B.available)) return;
  const i = B.running;
  try {
    B = await p(i ? "librespot_stop" : "librespot_start");
  } catch (t) {
    k(e, L(t));
    return;
  }
  if (xe = i, Gi(e), i) {
    si = "", await Ye(e);
    return;
  }
  for (let t = 0; t < 6; t++) {
    await new Promise((s) => window.setTimeout(s, 1500));
    try {
      const s = await p("spotify_devices");
      qi = s;
      const c = s.find((l) => l.name === "Lunac");
      if (c && !c.active && await p("spotify_transfer", { deviceId: c.id, play: !0 }), c) {
        si = c.id;
        break;
      }
    } catch {
    }
  }
  await ve(e);
}
async function jn(e) {
  try {
    B = await p("librespot_login");
  } catch (i) {
    k(e, L(i));
    return;
  }
  xe = !1, Gi(e), k(e, n("music.local_login_started"));
  for (let i = 0; i < 60; i++) {
    if (await new Promise((s) => window.setTimeout(s, 2e3)), !e.isConnected) return;
    let t;
    try {
      t = await p("librespot_status");
    } catch {
      continue;
    }
    if (B = t, !!t.has_credentials) {
      t.running || (B = await p("librespot_start").catch(() => t));
      for (let s = 0; s < 8; s++) {
        if (await new Promise((v) => window.setTimeout(v, 1500)), !e.isConnected) return;
        const c = await p("spotify_devices").catch(() => []);
        qi = c;
        const l = c.find((v) => v.name === "Lunac");
        if (l) {
          l.active || await p("spotify_transfer", { deviceId: l.id, play: !1 }), si = l.id;
          break;
        }
      }
      k(e, n("music.local_login_ok"));
      break;
    }
  }
  await ve(e);
}
async function Hn(e, i) {
  if (i) {
    try {
      await p("spotify_transfer", { deviceId: i, play: !1 }), mi = !1;
    } catch (t) {
      k(e, L(t));
    }
    await ve(e);
  }
}
async function _s(e) {
  if (!(!(o != null && o.connected) || je || R)) {
    je = !0, Li = "", Mi(e);
    try {
      R = await p("spotify_liked");
    } catch (i) {
      Li = L(i);
    } finally {
      je = !1, (h == null ? void 0 : h.kind) === "liked" && (X = (R == null ? void 0 : R.items) ?? null, Bi = !1, vi = Li), Mi(e), J(e);
    }
  }
}
function Gt(e, i) {
  if (ei = i, Z = !!i, Xi !== void 0 && (window.clearTimeout(Xi), Xi = void 0), !i) {
    M = null, Wi = !1, bi = !1, oi(e), J(e);
    return;
  }
  Wi = !0, oi(e), J(e), Xi = window.setTimeout(() => void Wn(e, i), Us);
}
async function Wn(e, i) {
  Xi = void 0;
  try {
    const t = await p("spotify_search", { query: i });
    if (ei !== i) return;
    M = t;
  } catch (t) {
    if (ei !== i) return;
    M = null, k(e, L(t));
  } finally {
    ei === i && (Wi = !1, oi(e), J(e));
  }
}
function Ee(e) {
  const i = ($i == null ? void 0 : $i.items) ?? [], t = n("music.play_from_here"), s = i.length === 0 ? `<div class="music-empty">${n($i ? "music.queue_empty" : "music.loading")}</div>` : i.map((c, l) => Re(c, l, "play-uri", "", t)).join("");
  for (const c of ["#music-q", "#music-q-dd"]) w(e.querySelector(c), s);
}
async function ws(e) {
  var i;
  try {
    $i = await p("spotify_queue"), es = ((i = r == null ? void 0 : r.track) == null ? void 0 : i.id) ?? "";
  } catch (t) {
    $i = null, b(e.querySelector("#music-msg"), L(t));
  }
  Ee(e);
}
function Xe(e) {
  const i = (r == null ? void 0 : r.track) ?? null, t = i != null && i.cover ? `<img src="${a(i.cover)}" alt="">` : "", s = [i == null ? void 0 : i.artists, i == null ? void 0 : i.album].filter(Boolean).join(" · ") || (r != null && r.active ? "" : n("music.no_device_hint"));
  w(e.querySelector("#music-pv-cover"), t), w(e.querySelector("#music-bnow-cover"), t), b(e.querySelector("#music-pv-title"), (i == null ? void 0 : i.name) || n("music.no_track")), b(e.querySelector("#music-bnow-n"), (i == null ? void 0 : i.name) || n("music.no_track")), b(e.querySelector("#music-pv-sub"), s), b(e.querySelector("#music-bnow-a"), s);
  const c = (i == null ? void 0 : i.duration_ms) ?? 0, l = Math.min((r == null ? void 0 : r.progress_ms) ?? 0, c || Number.MAX_SAFE_INTEGER), v = c > 0 ? Math.max(0, Math.min(100, l / c * 100)) : 0;
  if (ns = l, cs = Date.now(), _i < 0)
    for (const T of Ei) T.style.setProperty("--seek-pct", `${v}%`);
  b(e.querySelector("#music-pv-pos"), I(l)), b(e.querySelector("#music-pv-dur"), I(c)), b(e.querySelector("#music-b-time"), `${I(l)} / ${I(c)}`);
  const E = r != null && r.playing ? m.pause : m.play;
  w(e.querySelector("#music-play"), E), w(e.querySelector("#music-b-play"), E);
  const C = $s(), D = n(C === "shuffle" ? "music.mode_shuffle" : C === "repeat_one" ? "music.mode_repeat_one" : "music.mode_off");
  for (const T of [e.querySelector("#music-mode"), e.querySelector("#music-b-mode")])
    T && (ri(T, "data-mode", C), ri(T, "title", D), w(T, C === "repeat_one" ? m.repeat : m.shuffle));
  const x = r && r.volume_percent >= 0 ? r.volume_percent : -1;
  for (const T of [e.querySelector("#music-vol"), e.querySelector("#music-b-vol")])
    T && x >= 0 && document.activeElement !== T && (T.value = String(x), Pi(T, x));
  const fe = !(r != null && r.active);
  e.querySelectorAll("#music-v-player .music-bar button, #music-nowbar button").forEach((T) => {
    T.id === "music-devices-btn" || T.id === "music-open-player" || T.id === "music-bnow" || (T.disabled = fe);
  });
}
function Un(e) {
  var c;
  if (!e.isConnected || !(r != null && r.playing) || _i >= 0) return;
  const i = ((c = r.track) == null ? void 0 : c.duration_ms) ?? 0;
  if (i <= 0) return;
  const t = Math.min(ns + (Date.now() - cs), i), s = Math.max(0, Math.min(100, t / i * 100));
  for (const l of Ei) l.style.setProperty("--seek-pct", `${s}%`);
  b(e.querySelector("#music-pv-pos"), I(t)), b(e.querySelector("#music-b-time"), `${I(t)} / ${I(i)}`);
}
function $s() {
  return (r == null ? void 0 : r.repeat) === "track" ? "repeat_one" : r != null && r.shuffle ? "shuffle" : "off";
}
function We(e) {
  var i, t;
  S(e.querySelector("#music-q-wrap"), Q), S(e.querySelector("#music-q-dd"), Q), (i = e.querySelector("#music-queue-btn")) == null || i.classList.toggle("on", Q), (t = e.querySelector("#music-b-queue")) == null || t.classList.toggle("on", Q);
}
function Ce(e) {
  const i = e.querySelector("#music-lyr");
  if (!i) return;
  if (it(), wi = -1, Ni = [], zi && (zi = !1, ui !== void 0 && (window.clearTimeout(ui), ui = void 0)), Ve) {
    w(i, `<div class="music-empty">${n("music.lyrics_loading")}</div>`);
    return;
  }
  if (j != null && j.synced) {
    const s = sn(j.synced);
    if (s.length > 0) {
      Ni = s;
      const c = a(n("music.seek_line"));
      w(
        i,
        `<div class="music-lyr-lines">${s.map((l, v) => `<div class="music-lyr-line" data-i="${v}" title="${c}">${a(l.text)}</div>`).join("")}</div>`
      );
      return;
    }
  }
  const t = ((j == null ? void 0 : j.plain) || "").trim();
  if (t) {
    w(i, `<div class="music-lyr-plain">${a(t)}</div>`);
    return;
  }
  if (j != null && j.instrumental) {
    w(i, `<div class="music-empty">${n("music.lyrics_instrumental")}</div>`);
    return;
  }
  w(i, `<div class="music-empty">${n("music.lyrics_none")}</div>`);
}
function it() {
  ae && (cancelAnimationFrame(ae), ae = 0);
}
function Qt(e, i) {
  it();
  const t = e.scrollTop, s = i - t;
  if (Math.abs(s) < 1) {
    e.scrollTop = i;
    return;
  }
  let c = 0;
  const l = (v) => {
    c || (c = v);
    const E = Math.min(1, (v - c) / Vs);
    e.scrollTop = t + s * (1 - Math.pow(1 - E, 5)), ae = E < 1 ? requestAnimationFrame(l) : 0;
  };
  ae = requestAnimationFrame(l);
}
function De(e) {
  var C, D;
  if (Ni.length === 0) return;
  const i = e.querySelector("#music-lyr");
  if (!i || !i.isConnected || i.clientHeight === 0) return;
  const t = ((r == null ? void 0 : r.progress_ms) ?? 0) / 1e3;
  let s = -1;
  for (let x = 0; x < Ni.length && Ni[x].at <= t; x++)
    s = x;
  if (s === wi) return;
  const c = Math.min(wi, s), l = Math.max(wi, s);
  for (let x = Math.max(0, c + 1); x <= l; x++)
    (C = i.querySelector(`.music-lyr-line[data-i="${x}"]`)) == null || C.classList.toggle("done", x <= s);
  (D = i.querySelector(".music-lyr-line.on")) == null || D.classList.remove("on"), wi = s;
  const v = i.querySelector(`.music-lyr-line[data-i="${s}"]`);
  if (!v) {
    zi || Qt(i, 0);
    return;
  }
  if (v.classList.add("on"), zi) return;
  const E = v.getBoundingClientRect().top - i.getBoundingClientRect().top + i.scrollTop;
  Qt(i, Math.max(0, E));
}
function Yt(e) {
  zi = !0, it(), ui !== void 0 && window.clearTimeout(ui), ui = window.setTimeout(() => {
    ui = void 0, zi = !1, wi = -1, De(e);
  }, Ws);
}
async function Le(e) {
  try {
    o = await p("music_config_get");
  } catch (i) {
    b(e.querySelector("#music-msg"), L(i));
    return;
  }
  !o.connected && $ === "player" && ($ = "default", U(e)), Ri(e), Di(e);
}
async function Vn(e) {
  if (Ue === e.id) return;
  Ue = e.id, Ve = !0, j = null;
  const i = as;
  i && Ce(i);
  try {
    j = await p("lyrics_get", {
      title: e.name,
      artist: e.artists,
      album: e.album,
      duration: e.duration_ms / 1e3
    });
  } catch (t) {
    j = { found: !1, instrumental: !1, track: "", artist: "", album: "", duration: 0, synced: null, plain: null }, i && b(i.querySelector("#music-msg"), L(t));
  } finally {
    Ve = !1, i && (Ce(i), De(i));
  }
}
async function ks(e, i) {
  if (i === Ai) {
    if (!e.isConnected) {
      et();
      return;
    }
    if (cn(e), o != null && o.connected) {
      if (!document.hidden && !_e) {
        _e = !0;
        try {
          if (r = await p("spotify_status"), i !== Ai) return;
          Di(e), Xe(e), De(e), _n(e), Ke(e), ue(e);
        } catch (t) {
          if (i !== Ai) return;
          String(t).includes("ERR_NOT_CONNECTED") ? await Le(e) : b(e.querySelector("#music-msg"), L(t));
        } finally {
          _e = !1;
        }
      }
      r != null && r.track && Vn(r.track), Q && (r != null && r.track) && r.track.id !== es && ws(e);
    }
    i === Ai && (ce = window.setTimeout(() => void ks(e, i), 1e3));
  }
}
function et() {
  ce !== void 0 && (window.clearTimeout(ce), ce = void 0), we !== void 0 && (window.clearInterval(we), we = void 0), Ai++, _e = !1;
}
function Xt(e) {
  et();
  const i = Ai;
  ce = window.setTimeout(() => void ks(e, i), 200), we = window.setInterval(() => Un(e), zs);
}
function ue(e) {
  document.getElementById("plugin-titlebar") && (xi !== void 0 && window.clearTimeout(xi), xi = window.setTimeout(() => void Fn(e), 80));
}
async function Fn(e) {
  if (xi = void 0, !document.getElementById("plugin-titlebar")) return;
  let i = Os, t = Ps;
  if (Ie()) {
    const c = e.closest(".plugin-result"), l = c == null ? void 0 : c.closest("#results-list");
    if (!c || !l) return;
    const v = getComputedStyle(l), E = parseFloat(v.paddingTop || "0") + parseFloat(v.paddingBottom || "0"), C = window.innerHeight - l.clientHeight;
    t = Math.round(C + E + c.getBoundingClientRect().height), i = js;
  }
  const s = `${i}x${t}`;
  if (s !== Ge)
    try {
      await p("plugin_window_resize", { width: i, height: t }), Ge = s;
    } catch {
    }
}
async function Yn(e) {
  var st, nt, ct, at, lt, ut, ot, rt, dt, mt, pt, vt, ft, yt, bt, ht, gt, _t, wt, $t, kt, St, Et, Lt, xt, qt, Mt, Ct, Tt, It, Rt, At, Dt, Nt, Bt, Ot;
  const i = e.querySelector(".music-root");
  if (!i) return;
  as = i, $ = "default", he = null, ge = !1, Yi = null, Q = !1, Ge = "", ze = null, $e = "", ke = 0, R = null, Li = "", Fe = null, Ui.clear(), ie.clear(), oe.clear(), F = "playlist", h = null, X = null, Bi = !1, vi = "", qi = null, mi = !1, B = null, si = "", ei = "", M = null, Wi = !1, Z = !1, bi = !1, ni = "tracks", Ei = [], P = !1, W = null, qe = !1, Vi = "", ti = "", ii = !1, ai.clear(), re.clear(), ci = !1, A = null, Fi = !1, hi = "", Y = null, de = "", Oi = null, ji(), z !== void 0 && (window.clearTimeout(z), z = void 0), f = null, fi = [], li = -1, ki = !1, H = -1, Hi();
  const t = (u) => b(i.querySelector("#music-msg"), u), s = (u) => i.querySelector(u);
  Si && (Si(), Si = null), Si = await Rs("spotify-auth", (u) => {
    i.isConnected && (u.payload.ok ? (t(n("music.auth_ok")), Le(i).then(() => {
      Xt(i), Ye(i);
    })) : t(u.payload.message || n("music.auth_failed")));
  });
  const c = () => {
    $ = "player", U(i);
  }, l = () => {
    $ = "default", U(i);
  }, v = () => {
    $ = "settings", U(i);
  };
  (st = s("#music-setup-toggle")) == null || st.addEventListener("click", v), (nt = s("#music-set-back")) == null || nt.addEventListener("click", l), (ct = s("#music-tune-back")) == null || ct.addEventListener("click", l), (at = s("#music-tuning-on")) == null || at.addEventListener("click", (u) => {
    const d = u.target.closest(".music-seg-btn");
    d && Ht(i, d.dataset.on === "1", (V == null ? void 0 : V.preset) ?? "flat");
  }), (lt = s("#music-tuning-preset")) == null || lt.addEventListener("click", (u) => {
    const d = u.target.closest(".music-seg-btn"), y = d == null ? void 0 : d.dataset.preset;
    y && Ht(i, !0, y);
  }), (ut = s("#music-avatar")) == null || ut.addEventListener("click", () => {
    $ !== "default" && ($ = "default", U(i)), ge = !ge, Ri(i);
  }), (ot = s("#music-open-player")) == null || ot.addEventListener("click", c), (rt = s("#music-bnow")) == null || rt.addEventListener("click", c);
  const E = (u) => {
    P !== u && (P = u, u ? (bi = !1, Z = !1, h = null, X = null, vi = "", W = null, A = null, Vi = "", hi = "", Oi = null, Y = null) : (ji(), de = "", z !== void 0 && (window.clearTimeout(z), z = void 0), F = "playlist", f != null && f.path && !pi && Zi(i)), U(i), Di(i), u && (vs(i), Qi(i), p("media_scan_status").then((d) => {
      !P || !i.isConnected || (Oi = d, d.running && fs(i), di(i));
    }).catch(() => {
    })));
  }, C = (u) => {
    if (u === "tuning") {
      $ = "tuning", U(i);
      return;
    }
    $ = "default", E(u === "local"), U(i);
  }, D = rn(i);
  D == null || D.addEventListener("click", (u) => {
    const d = u.target.closest(".music-tb-seg"), y = d == null ? void 0 : d.dataset.seg;
    y && C(y);
  }), (dt = s("#music-local-add")) == null || dt.addEventListener("click", () => {
    ci = !ci, Ji(i);
  }), (mt = s("#music-local-list")) == null || mt.addEventListener("click", () => qn(i)), (pt = s("#music-local-del")) == null || pt.addEventListener("click", () => Mn(i)), (vt = s("#music-local-editdone")) == null || vt.addEventListener("click", () => void Cn(i)), (ft = s("#music-local-scan")) == null || ft.addEventListener("click", () => void Qe(i)), (yt = s("#music-main")) == null || yt.addEventListener("input", (u) => {
    const d = u.target;
    (d == null ? void 0 : d.id) === "music-mt-q" && Nn(i, d.value.trim());
  }), (bt = s("#music-l-prev")) == null || bt.addEventListener("click", () => void Ki(i, -1, !1)), (ht = s("#music-l-next")) == null || ht.addEventListener("click", () => void Ki(i, 1, !1)), (gt = s("#music-l-play")) == null || gt.addEventListener("click", () => void Ut(i)), (_t = s("#music-l-stop")) == null || _t.addEventListener("click", () => void Zi(i));
  const x = s("#music-l-vol");
  x == null || x.addEventListener("input", () => {
    Pi(x, Number(x.value)), Vt(i, Number(x.value) / 100);
  });
  const fe = () => {
    const u = ["off", "shuffle", "repeat_all", "repeat_one"];
    O = u[(u.indexOf(O) + 1) % u.length], tn(O), yi(i), k(i, Je());
  };
  (wt = s("#music-l-mode")) == null || wt.addEventListener("click", fe);
  const T = (u, d) => {
    const y = (_) => {
      const N = u.getBoundingClientRect();
      return Math.max(0, Math.min(1, (_ - N.left) / Math.max(1, N.width)));
    }, q = (_) => {
      H = _, u.style.setProperty("--seek-pct", `${_ * 100}%`), d(_);
    };
    u.addEventListener("pointerdown", (_) => {
      if (!(((f == null ? void 0 : f.duration_ms) ?? 0) <= 0)) {
        try {
          u.setPointerCapture(_.pointerId);
        } catch {
        }
        u.classList.add("music-dragging"), q(y(_.clientX));
      }
    }), u.addEventListener("pointermove", (_) => {
      H < 0 || q(y(_.clientX));
    });
    const g = (_) => {
      if (H < 0) return;
      const N = H;
      H = -1, u.classList.remove("music-dragging");
      try {
        u.releasePointerCapture(_.pointerId);
      } catch {
      }
      Dn(i, Math.round(((f == null ? void 0 : f.duration_ms) ?? 0) * N));
    };
    u.addEventListener("pointerup", g), u.addEventListener("pointercancel", g);
  }, Ne = s("#music-lbp");
  Ne && T(Ne, (u) => {
    const d = (f == null ? void 0 : f.duration_ms) ?? 0;
    b(Ne.querySelector(".music-progress-tip"), le(d * u));
    const y = i.querySelector("#music-l-time");
    y && b(y, `${I(d * u)} / ${I(d)}`);
  });
  const Ss = () => {
    !f || !f.path || ($ = "lplayer", U(i));
  };
  ($t = s("#music-l-open-player")) == null || $t.addEventListener("click", Ss), (kt = s("#music-lp-prev")) == null || kt.addEventListener("click", () => void Ki(i, -1, !1)), (St = s("#music-lp-next")) == null || St.addEventListener("click", () => void Ki(i, 1, !1)), (Et = s("#music-lp-play")) == null || Et.addEventListener("click", () => void Ut(i)), (Lt = s("#music-lp-stop")) == null || Lt.addEventListener("click", () => void Zi(i)), (xt = s("#music-lp-mode")) == null || xt.addEventListener("click", fe);
  const Ci = s("#music-lp-vol");
  Ci == null || Ci.addEventListener("input", () => {
    Pi(Ci, Number(Ci.value)), Vt(i, Number(Ci.value) / 100);
  });
  const Be = s("#music-lp-progress");
  Be && T(Be, (u) => {
    const d = (f == null ? void 0 : f.duration_ms) ?? 0;
    b(Be.querySelector(".music-progress-tip"), le(d * u));
    const y = i.querySelector("#music-lp-time");
    y && b(y, `${I(d * u)} / ${I(d)}`);
  });
  const Es = (u) => {
    var d;
    !i.isConnected || !Ie() || (d = u.target) != null && d.closest("#plugin-close") && (u.stopPropagation(), u.preventDefault(), $ === "lplayer" ? l() : pn(i));
  };
  document.addEventListener("click", Es, !0), (qt = s("#music-fields-toggle")) == null || qt.addEventListener("click", () => {
    he = !(he ?? !(o != null && o.builtin)), Ri(i);
  }), (Mt = s("#music-copy-redirect")) == null || Mt.addEventListener("click", () => {
    const u = (o == null ? void 0 : o.redirect_uri) || "";
    u && Ds(u).then(() => t(n("music.copied"))).catch(() => {
    });
  });
  for (const u of i.querySelectorAll("#music-quality .music-seg-btn"))
    u.addEventListener("click", () => {
      Yi = Number(u.dataset.q), Ri(i);
    });
  (Ct = s("#music-set-save")) == null || Ct.addEventListener("click", async () => {
    try {
      o = await p("music_config_set", { librespotBitrate: Yi }), Yi = null, t(n("music.saved")), Ri(i), Di(i);
    } catch (u) {
      t(L(u));
    }
  }), (Tt = s("#music-save")) == null || Tt.addEventListener("click", async () => {
    var q, g, _, N;
    const u = ((q = s("#music-client-id")) == null ? void 0 : q.value.trim()) ?? "", d = ((g = s("#music-port")) == null ? void 0 : g.value.trim()) ?? "", y = Number(d);
    if (!u) {
      t(n("music.err_no_client_id"));
      return;
    }
    if (!Number.isInteger(y) || y < 1024 || y > 65535) {
      t(n("music.err_bad_port"));
      return;
    }
    try {
      o = await p("music_config_set", {
        clientId: u,
        port: y,
        // 本机播放那两项**一起交上去**（留空 = 自动探测 / 直连，都是合法值）
        librespotPath: ((_ = s("#music-librespot")) == null ? void 0 : _.value.trim()) ?? "",
        librespotProxy: ((N = s("#music-librespot-proxy")) == null ? void 0 : N.value.trim()) ?? ""
        // 音质**不在这里提交**（2026-10-01 起它归设置页，那个页面有自己的「保存」）：
        // 不传 = `None` = 别动，宿主本来就是这个语义。把两页的保存混在一处，
        // 就会出现「在设置页点了 320、回连接卡片点保存、结果把它一起落盘了」。
      }), t(n("music.saved")), Ri(i), Di(i), B = null;
    } catch (be) {
      t(L(be));
    }
  }), (It = s("#music-connect")) == null || It.addEventListener("click", async () => {
    var y, q;
    const u = ((y = s("#music-client-id")) == null ? void 0 : y.value.trim()) ?? "", d = Number(((q = s("#music-port")) == null ? void 0 : q.value.trim()) ?? "");
    if (u && Number.isInteger(d) && d >= 1024)
      try {
        o = await p("music_config_set", {
          clientId: u,
          port: d,
          librespotPath: null,
          librespotProxy: null,
          // 串流质量同上：这条路径只是「先落盘再连」，别动用户选的档
          librespotBitrate: null
        });
      } catch (g) {
        t(L(g));
        return;
      }
    try {
      const g = await p("spotify_connect");
      t(n("music.browser_hint")), await As(g);
    } catch (g) {
      t(L(g));
    }
  }), (Rt = s("#music-disconnect")) == null || Rt.addEventListener("click", async () => {
    try {
      await p("spotify_disconnect"), r = null, j = null, Ue = "", Fe = null, Ui.clear(), oe.clear(), $i = null, Q = !1, h = null, X = null, vi = "", M = null, ei = "", Z = !1, bi = !1, qi = null, $ = "default", await Le(i), U(i), Ee(i), t(n("music.disconnected"));
    } catch (u) {
      t(L(u));
    }
  });
  const Ls = (u) => {
    var g;
    const d = (g = u.target) == null ? void 0 : g.closest("[data-act]");
    if (!d) return;
    const y = d.dataset.kind || "", q = d.dataset.id || "";
    switch (d.dataset.act) {
      case "side-tab":
        F = d.dataset.tab || "playlist", Mi(i), gs(i, F);
        break;
      case "search-tab":
        ni = d.dataset.tab || "tracks", J(i);
        break;
      case "open":
        Bn(i, y, q);
        break;
      case "main-track":
        On(i, Number(d.dataset.i || "0"));
        break;
      case "main-play-all":
        h && zt(i, h.kind, h.id);
        break;
      case "dd-track":
        d.dataset.uri && Jt(i, d.dataset.uri);
        break;
      case "play-uri":
        d.dataset.uri && Jt(i, d.dataset.uri);
        break;
      case "search-all":
        Z = !1, bi = !0, oi(i), J(i);
        break;
      case "dev-pick":
        Hn(i, q);
        break;
      case "local-toggle":
        Pn(i);
        break;
      case "local-login":
        jn(i);
        break;
      // ── 本地音乐页（2026-10-01）──
      case "media-root": {
        const _ = d.dataset.path || "";
        if (ii) {
          _ && (ai.has(_) ? ai.delete(_) : ai.add(_)), gi(i);
          break;
        }
        ti = _, gi(i), Qi(i);
        break;
      }
      case "media-scan":
        Qe(i);
        break;
      // `＋` 浮层里的两行（2026-10-01）：目录 vs 播放列表文件。
      // **先关浮层再干活** —— 目录对话框是模态的，浮层留着会在对话框背后一闪一闪。
      case "media-add-dir":
        ci = !1, Ji(i), Ln(i);
        break;
      case "media-add-list":
        ci = !1, Ji(i), In(i);
        break;
      case "media-list-close":
        Rn(i);
        break;
      case "local-track":
        An(i, Number(d.dataset.i || "0"));
        break;
    }
  };
  for (const u of ["#music-side-list", "#music-side-tabs", "#music-main", "#music-search-dd", "#music-dev-dd", "#music-q", "#music-q-dd", "#music-local-add-dd"])
    (At = s(u)) == null || At.addEventListener("click", Ls);
  (Dt = s("#music-side-list")) == null || Dt.addEventListener("dblclick", (u) => {
    var g;
    const d = (g = u.target) == null ? void 0 : g.closest('[data-act="open"]');
    if (!d) return;
    const y = d.dataset.kind || "", q = d.dataset.id || "";
    q && zt(i, y, q);
  }), (Nt = s("#music-devices-btn")) == null || Nt.addEventListener("click", () => {
    mi = !mi, Gi(i), mi && ve(i);
  }), Ft(i), (Bt = s("#music-split")) == null || Bt.addEventListener("pointerdown", (u) => {
    var _;
    u.preventDefault();
    const d = u.clientX, y = ((_ = s("#music-side")) == null ? void 0 : _.getBoundingClientRect().width) ?? ee, q = (N) => {
      ee = Math.min(is, Math.max(Zt, Math.round(y + N.clientX - d))), Ft(i);
    }, g = () => {
      window.removeEventListener("pointermove", q), window.removeEventListener("pointerup", g), document.body.classList.remove("music-resizing");
    };
    document.body.classList.add("music-resizing"), window.addEventListener("pointermove", q), window.addEventListener("pointerup", g);
  }), document.addEventListener("pointerdown", (u) => {
    const d = u.target;
    d && (mi && !d.closest("#music-dev-dd") && !d.closest("#music-devices-btn") && (mi = !1, Gi(i)), Z && !d.closest(".music-search-wrap") && (Z = !1, oi(i)), ci && !d.closest("#music-local-add-dd") && !d.closest("#music-local-add") && (ci = !1, Ji(i)), Q && !d.closest("#music-q-dd") && !d.closest("#music-b-queue") && !d.closest("#music-queue-btn") && (Q = !1, We(i)));
  });
  const K = s("#music-search");
  K == null || K.addEventListener("input", () => Gt(i, K.value.trim())), K == null || K.addEventListener("focus", () => {
    ei && (Z = !0, oi(i));
  }), K == null || K.addEventListener("keydown", (u) => {
    if (u.key === "Enter" && ei) {
      Z = !1, bi = !0, oi(i), J(i);
      return;
    }
    u.key === "Escape" && (K.value = "", Gt(i, ""));
  }), document.body.addEventListener("mouseenter", () => ue(i)), document.body.addEventListener("mouseleave", () => ue(i));
  const Ti = async (u, d) => {
    u === "play" && await pe(i, "spotify");
    try {
      await p("spotify_control", { action: u, value: d });
    } catch (y) {
      t(L(y));
    }
  }, Ii = (u, d) => {
    var y;
    for (const q of u) (y = s(`#${q}`)) == null || y.addEventListener("click", d);
  };
  Ii(["music-queue-btn", "music-b-queue"], () => {
    Q = !Q, We(i), Ee(i), Q ? ws(i) : Xe(i), ue(i);
  }), Ii(["music-prev", "music-b-prev"], () => void Ti("previous")), Ii(["music-next", "music-b-next"], () => void Ti("next")), Ii(["music-play", "music-b-play"], () => void Ti(r != null && r.playing ? "pause" : "play")), Ii(["music-dual-btn", "music-l-dual-btn"], () => {
    pi = !pi, Zs(pi), !pi && !P && f && Zi(i), yi(i), Ke(i), k(i, n(pi ? "music.dual_on" : "music.dual_off"));
  });
  let ye = null, Oe = !1;
  const xs = async (u) => {
    if (ye = u, !Oe) {
      Oe = !0;
      try {
        for (; ye !== null; ) {
          const d = ye;
          ye = null, await Ti("volume", d);
        }
      } finally {
        Oe = !1;
      }
    }
  };
  for (const u of ["music-vol", "music-b-vol"])
    (Ot = s(`#${u}`)) == null || Ot.addEventListener("input", (d) => {
      const y = d.target, q = Number(y.value);
      Pi(y, q), xs(q);
    });
  Ii(["music-mode", "music-b-mode"], () => {
    const u = $s();
    p("spotify_set_play_mode", { mode: u === "off" ? "shuffle" : u === "shuffle" ? "repeat_one" : "off" }).catch((y) => t(L(y)));
  }), Ei = ["#music-pv-progress", "#music-bp"].map((u) => s(u)).filter((u) => !!u);
  for (const u of Ei) {
    const d = (g) => {
      const _ = u.getBoundingClientRect();
      return Math.max(0, Math.min(1, (g - _.left) / Math.max(1, _.width)));
    }, y = (g) => {
      var Pt;
      _i = g;
      const _ = `${g * 100}%`;
      for (const qs of Ei) qs.style.setProperty("--seek-pct", _);
      const N = ((Pt = r == null ? void 0 : r.track) == null ? void 0 : Pt.duration_ms) ?? 0, be = I(N * g);
      b(u.querySelector(".music-progress-tip"), le(N * g)), b(s("#music-pv-pos"), be), b(s("#music-b-time"), `${be} / ${I(N)}`);
    };
    u.addEventListener("pointerdown", (g) => {
      var _;
      if (!((((_ = r == null ? void 0 : r.track) == null ? void 0 : _.duration_ms) ?? 0) <= 0)) {
        try {
          u.setPointerCapture(g.pointerId);
        } catch {
        }
        u.classList.add("music-dragging"), y(d(g.clientX));
      }
    }), u.addEventListener("pointermove", (g) => {
      _i < 0 || y(d(g.clientX));
    });
    const q = (g) => {
      var N;
      if (_i < 0) return;
      const _ = _i;
      _i = -1, u.classList.remove("music-dragging");
      try {
        u.releasePointerCapture(g.pointerId);
      } catch {
      }
      Ti("seek", Math.round((((N = r == null ? void 0 : r.track) == null ? void 0 : N.duration_ms) ?? 0) * _));
    };
    u.addEventListener("pointerup", q), u.addEventListener("pointercancel", q);
  }
  const G = s("#music-lyr");
  let Pe = !1, tt = 0;
  G == null || G.addEventListener("wheel", () => Yt(i), { passive: !0 }), G == null || G.addEventListener("pointerdown", (u) => {
    Pe = !1, tt = u.clientY, Yt(i);
  }), G == null || G.addEventListener("pointermove", (u) => {
    Math.abs(u.clientY - tt) > 4 && (Pe = !0);
  }), G == null || G.addEventListener("click", (u) => {
    if (Pe) return;
    const d = u.target.closest(".music-lyr-line"), y = d ? Ni[Number(d.dataset.i)] : void 0;
    y && Ti("seek", Math.round(y.at * 1e3));
  }), await Le(i), U(i), Xe(i), Ce(i), Ee(i), We(i), Di(i), Xt(i), Ye(i);
}
async function Jt(e, i) {
  await pe(e, "spotify");
  try {
    await p("spotify_play_uri", { uri: i, deviceId: si || void 0 });
  } catch (t) {
    b(e.querySelector("#music-msg"), L(t));
  }
}
function zn() {
  et(), ui !== void 0 && (window.clearTimeout(ui), ui = void 0), xi !== void 0 && (window.clearTimeout(xi), xi = void 0), ji(), z !== void 0 && (window.clearTimeout(z), z = void 0), Hi(), f != null && f.path && (f = null, fi = [], li = -1, p("player_stop").catch(() => {
  })), Si && (Si(), Si = null), Ei = [], un(), mn();
}
window.__lunac_music_stop = zn;
const Xn = {
  id: "music",
  name: "音乐歌词",
  keywords: ["音乐", "歌词", "歌曲", "正在播放", "music", "lyrics", "spotify", "播放控制", "暂停", "下一首", "歌单", "播放列表"],
  description: "歌词自动抓取 (LRCLIB + 网易云兜底) + Spotify 播放控制 / 歌单 / 队列",
  icon: "🎵",
  badge: "music",
  // 「本插件一律在**悬浮窗**里打开」（2026-09-29 从 main.ts 的硬编码 `id === "music"` 改成声明）。
  // 为什么要声明而不是让宿主按 id 判：音乐已归入**拓展插件**，要能从市场独立打包分发
  // —— 磁盘插件的代码宿主没法写死，行为只能由插件自己声明（见 ai-spec §3.5「插件契约」）。
  // 这也是「用户 2026-09-28 定的：从 Lunac 进音乐界面时自动展开成独立界面」那条的执行点。
  permissions: ["window.float"],
  async execute() {
    return { type: "html", content: nn() };
  }
};
export {
  Yn as attach,
  Yn as attachMusicListeners,
  Xn as default,
  zn as detach,
  Xn as musicPlugin,
  zn as stopMusicPolling
};
