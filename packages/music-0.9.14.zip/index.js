const Us = "__lunac_host";
function Vs() {
  return globalThis[Us] ?? null;
}
function n(t, e) {
  const i = Vs();
  return i && typeof i.t == "function" ? i.t(t, e) : t;
}
function zs(t, e = !1) {
  return window.__TAURI_INTERNALS__.transformCallback(t, e);
}
async function p(t, e = {}, i) {
  return window.__TAURI_INTERNALS__.invoke(t, e, i);
}
function Ve(t, e = "asset") {
  return window.__TAURI_INTERNALS__.convertFileSrc(t, e);
}
var cs;
(function(t) {
  t.WINDOW_RESIZED = "tauri://resize", t.WINDOW_MOVED = "tauri://move", t.WINDOW_CLOSE_REQUESTED = "tauri://close-requested", t.WINDOW_DESTROYED = "tauri://destroyed", t.WINDOW_FOCUS = "tauri://focus", t.WINDOW_BLUR = "tauri://blur", t.WINDOW_SCALE_FACTOR_CHANGED = "tauri://scale-change", t.WINDOW_THEME_CHANGED = "tauri://theme-changed", t.WINDOW_CREATED = "tauri://window-created", t.WINDOW_SUSPENDED = "tauri://suspended", t.WINDOW_RESUMED = "tauri://resumed", t.WEBVIEW_CREATED = "tauri://webview-created", t.DRAG_ENTER = "tauri://drag-enter", t.DRAG_OVER = "tauri://drag-over", t.DRAG_DROP = "tauri://drag-drop", t.DRAG_LEAVE = "tauri://drag-leave";
})(cs || (cs = {}));
async function Gs(t, e) {
  window.__TAURI_EVENT_PLUGIN_INTERNALS__.unregisterListener(t, e), await p("plugin:event|unlisten", {
    event: t,
    eventId: e
  });
}
async function Qs(t, e, i) {
  var s;
  const c = (s = void 0) !== null && s !== void 0 ? s : { kind: "Any" };
  return p("plugin:event|listen", {
    event: t,
    target: c,
    handler: zs(e)
  }).then((a) => async () => Gs(t, a));
}
async function Ys(t, e) {
  await p("plugin:shell|open", {
    path: t,
    with: e
  });
}
async function Js(t, e) {
  await p("plugin:clipboard-manager|write_text", {
    label: e == null ? void 0 : e.label,
    text: t
  });
}
async function ys(t = {}) {
  return typeof t == "object" && Object.freeze(t), await p("plugin:dialog|open", { options: t });
}
function Xs(t) {
  return t === "new" ? "album" : t === "top" ? "artist" : t;
}
const Ks = {
  album: "spotify_albums",
  artist: "spotify_artists",
  show: "spotify_shows",
  new: "spotify_new_releases",
  top: "spotify_top_artists"
}, Zs = 1280, tn = 720, en = 550, sn = 300, hs = 180, gs = 520, nn = 4e3, cn = 450, an = 800, ln = 8e3, un = 200, on = 500, rn = 500, dn = 250, mn = 500, pn = 0.3, m = {
  play: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polygon points="6 4 20 12 6 20 6 4"/></svg>',
  pause: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="9" y1="4" x2="9" y2="20"/><line x1="15" y1="4" x2="15" y2="20"/></svg>',
  prev: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polygon points="19 5 9 12 19 19 19 5"/><line x1="5" y1="5" x2="5" y2="19"/></svg>',
  next: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polygon points="5 5 15 12 5 19 5 5"/><line x1="19" y1="5" x2="19" y2="19"/></svg>',
  /** 随机（关 / 随机共用这一个；「关」靠 `data-mode` 变暗区分）。 */
  shuffle: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="16 3 21 3 21 8"/><line x1="4" y1="20" x2="21" y2="3"/><polyline points="21 16 21 21 16 21"/><line x1="15" y1="15" x2="21" y2="21"/><line x1="4" y1="4" x2="9" y2="9"/></svg>',
  /** 循环（单曲循环；那个「1」由 CSS `::after` 加，SVG 里不写字）。 */
  repeat: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="17 1 21 5 17 9"/><path d="M3 11V9a4 4 0 0 1 4-4h14"/><polyline points="7 23 3 19 7 15"/><path d="M21 13v2a4 4 0 0 1-4 4H3"/></svg>',
  list: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="9" y1="6" x2="21" y2="6"/><line x1="9" y1="12" x2="21" y2="12"/><line x1="9" y1="18" x2="21" y2="18"/><circle cx="4" cy="6" r="1" fill="currentColor" stroke="none"/><circle cx="4" cy="12" r="1" fill="currentColor" stroke="none"/><circle cx="4" cy="18" r="1" fill="currentColor" stroke="none"/></svg>',
  /** 进播放界面。 */
  expand: '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 3 21 3 21 9"/><polyline points="9 21 3 21 3 15"/><line x1="21" y1="3" x2="14" y2="10"/><line x1="3" y1="21" x2="10" y2="14"/></svg>',
  /** 回默认界面。**唯一**的退出播放界面的入口 —— 播放停止不会自动退出。 */
  back: '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/><line x1="3" y1="12" x2="9" y2="12"/></svg>',
  chevron: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg>',
  copy: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15V5a2 2 0 0 1 2-2h10"/></svg>',
  link: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.5 1.5"/><path d="M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7L12 19"/></svg>',
  power: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M18.4 6.6a9 9 0 1 1-12.8 0"/><line x1="12" y1="2" x2="12" y2="12"/></svg>',
  gear: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>',
  volume: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M15.5 8.5a5 5 0 0 1 0 7"/></svg>',
  /** 工具条上的「设备」按钮（2026-09-28）。画成一台小音箱，比「显示器」更贴
   *  Spotify 那种「可选的播放设备」语义。 */
  speaker: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="2" width="14" height="20" rx="2"/><circle cx="12" cy="14" r="3.2"/><circle cx="12" cy="6" r="1" fill="currentColor" stroke="none"/></svg>',
  /** 实心心形（「我喜欢的歌曲」那块封面上的图案）。**这个是 `fill`，不是描边** ——
   *  它是一块封面图（Spotify 的收藏夹封面就是实心心 + 渐变底），不是可点按钮。 */
  heart: '<svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" stroke="none"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>',
  // ── 本地媒体库那一页用到的四个（2026-10-01）──
  /** 「本地音乐」入口 + 目录行（画成文件夹）。 */
  folder: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/></svg>',
  /** 「添加目录」。 */
  plus: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>',
  /** 移除一根目录（行尾那枚）。`music.pl-x` 用。 */
  x: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="6" y1="6" x2="18" y2="18"/><line x1="18" y1="6" x2="6" y2="18"/></svg>',
  /** 没有封面的曲目行左侧占位（一个八分音符）。 */
  note: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18V6l10-2v12"/><circle cx="6.5" cy="18" r="2.5"/><circle cx="16.5" cy="16" r="2.5"/></svg>',
  /** 「重新扫描」/「刷新」—— 画成环形箭头。 */
  refresh: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="21 3 21 9 15 9"/><path d="M20.4 14a8.5 8.5 0 1 1-1.6-7.5L21 9"/></svg>',
  /** 编辑（改列表）。**路径逐字抄自 icon-style.md §3 的「编辑 ✎」** —— 规范里已经
   *  给好这条了，不许自己另画一条（§4.2 最后一条：已有的图形不要重复造路径）。 */
  edit: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 3a2.8 2.8 0 0 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/></svg>',
  /** 删除（垃圾桶）。**同样逐字抄自 icon-style.md §3** —— 它是危险操作，
   *  按 §4.2 用同风格线性图标 + 语义色（hover 变 `--red`，见 styles.css）。 */
  trash: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6M14 11v6M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>',
  /** 停止本地播放（本地播放条右端那枚）。**它与暂停不是一回事**：暂停留着这台
   *  音频设备，停止会把设备一起放掉（见 player.rs 的 `player_stop`）。 */
  stop: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="6" y="6" width="12" height="12" rx="1.5"/></svg>',
  /** 「本地与 Spotify 同时出声」那把开关（2026-10-01）。画成**两个相交的圆** ——
   *  「两路并存」最直白的图形（Lucide 里叫 `blend`）。**不画成两个喇叭**：12px 下
   *  两个喇叭会糊成一团，而两个圆在任何尺寸下都认得出来。
   *  开关的「开着」不用第二个图形表达，靠 `.on` 的强调色（与其他开关一致）。 */
  dual: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="9" r="6.5"/><circle cx="15" cy="15" r="6.5"/></svg>',
  /** 「最常听的歌曲」那一行的图标（2026-10-01 用户第 4 条）。画成一条上扬的折线
   *  —— 「最常听 / 热度」最直白的图形（Lucide 的 `trending-up`，与上面这些同源）。
   *  与 `SVG.heart` 一样是 20px 的封面图案，但**保持描边风格**（它不是实心封面，
   *  它是「一行合成出来的入口」，与收藏夹那块渐变实心封面刻意区分开）。 */
  trend: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/></svg>'
  // （工具条上那枚「调音推子」图标 2026-10-01 随入口一起删掉了：调音改成标题栏
  //  三段切换的第三段，那枚图标就没有地方落了。图形本身仍在 icon-style.md §3 里。）
};
let r = null, d = null, U = null, ni = "", ci = !1, Jt = [], Dt = -1, Ie = null, re = null, Re = !1, I = null, Ht = 0, St = [], dt = -1, xt = 0;
function fn() {
  return { kind: "peaking", freq_hz: 1e3, gain_db: 0, q: 0.707, on: !0 };
}
function ze() {
  Ht = (I == null ? void 0 : I.preamp_db) ?? 0, St = ((I == null ? void 0 : I.filters) ?? []).map((t) => ({ ...t }));
}
let L = "default", ai = null, Bt = null, tt = !1, _s = "", B = null, ei = !1, Wt = "", at = "", N = null, ie = !1, de, Y = "playlist";
const se = /* @__PURE__ */ new Map(), ve = /* @__PURE__ */ new Set(), Se = /* @__PURE__ */ new Map();
let _ = null, it = null, Xt = !1, Et = "", nt = !1, Ct = !1, rt = "tracks", Ut = null, $t = !1, P = null, ot = "", He = !1, be = sn, li = null, ye = "", H = !1, z = null, We = !1, ne = "", lt = "", ct = !1, pt = /* @__PURE__ */ new Set(), xe = /* @__PURE__ */ new Set(), mt = !1, O = null, ce = !1, It = "", et = null, Ee = "", J, Kt = null, he, y = null, Le = 0, Lt = [], ft = -1, Ot = !1, V = -1, ge;
const ws = "lunac-music-dual-play";
let kt = vn();
function vn() {
  try {
    return localStorage.getItem(ws) === "1";
  } catch {
    return !1;
  }
}
function bn(t) {
  try {
    localStorage.setItem(ws, t ? "1" : "0");
  } catch {
  }
}
const $s = "lunac-music-local-mode";
let j = yn();
function yn() {
  try {
    const t = localStorage.getItem($s);
    return t === "shuffle" || t === "repeat_all" || t === "repeat_one" ? t : "off";
  } catch {
    return "off";
  }
}
function hn(t) {
  try {
    localStorage.setItem($s, t);
  } catch {
  }
}
function mi() {
  return n(j === "shuffle" ? "music.mode_shuffle" : j === "repeat_all" ? "music.mode_repeat_all" : j === "repeat_one" ? "music.mode_repeat_one" : "music.mode_off");
}
let _e, Ae = !1, Ne, ks = 0, Ss = 0, Pt = null, xs = null, Qt = 0, ae = !1, Nt = -1, jt = [], we = 0, vt, Ft, De = "", Be = 0, ui = "";
function Ge() {
  return L === "player" || L === "lplayer";
}
function l(t) {
  return t.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
function $e(t) {
  if (!isFinite(t) || t < 0) return "0:00";
  const e = Math.floor(t / 1e3), i = Math.floor(e / 60), s = e % 60;
  return `${i}:${String(s).padStart(2, "0")}`;
}
function D(t) {
  if (!isFinite(t) || t < 0) return "00:00";
  const e = Math.floor(t / 1e3);
  return `${String(Math.floor(e / 60)).padStart(2, "0")}:${String(e % 60).padStart(2, "0")}`;
}
function M(t) {
  const e = t instanceof Error ? t.message : String(t);
  if (e.includes("ERR_NO_CLIENT_ID")) return n("music.err_no_client_id");
  if (e.includes("ERR_NOT_CONNECTED")) return n("music.err_not_connected");
  if (e.includes("ERR_NO_QUERY")) return n("music.err_no_query");
  if (e.includes("ERR_PORT_BUSY")) return n("music.err_port_busy", { port: String((r == null ? void 0 : r.port) ?? "") });
  if (e.includes("ERR_BAD_URI") || e.includes("ERR_BAD_ID")) return n("music.err_bad_uri");
  const i = e.match(/ERR_RATE_LIMITED:(\S*)/);
  return i ? n("music.err_rate_limited", { s: i[1] || "?" }) : e.includes("Insufficient client scope") ? n("music.err_scope") : e.includes("No active device") || e.includes("NO_ACTIVE_DEVICE") ? n("music.err_no_device") : e.includes("Premium required") || e.includes("PREMIUM_REQUIRED") ? n("music.err_premium") : e.includes("Restriction violated") ? n("music.err_restricted") : e;
}
function gn(t) {
  const e = [];
  for (const i of t.split(/\r?\n/)) {
    const s = [...i.matchAll(/\[(\d{1,3}):(\d{1,2})(?:[.:](\d{1,3}))?\]/g)];
    if (s.length === 0) continue;
    const c = i.replace(/\[[^\]]*\]/g, "").trim();
    if (c)
      for (const a of s) {
        const f = a[3] ? Number(a[3].padEnd(3, "0")) / 1e3 : 0;
        e.push({ at: Number(a[1]) * 60 + Number(a[2]) + f, text: c });
      }
  }
  return e.sort((i, s) => i.at - s.at), e;
}
function _n() {
  return `
  <div class="music-root">
    <!-- ── 默认界面：顶部工具条 + 状态行 + 连接设置 + 歌单列 / 搜索结果 ──
         工具条与「返回」按钮**分属两态**：默认态用底部栏那个「进播放界面」，
         播放态用**标题栏那个 ←**（syncTitlebarClose 把 × 换成它；歌名模块右端
         原来还有一枚「返回歌单」，2026-10-01 已按用户口径删掉）。
         ⚠️ 本段在模板字符串里，注释里一个反引号都不能出现（预检 #15 / #39 ⑩）。 -->
    <div class="music-view" id="music-v-default">
      <!-- 顶部工具条：头像 / 账号 / 搜索（**带下拉预览**）/ 状态 / 设置。
           2026-09-28 第二次改：设备按钮与「展开播放面板」都**下移到最底下那条控制栏**
           （用户要求「严格对齐 Spotify」，Spotify 的工具条上本来就没有这两样）。 -->
      <div class="music-toolbar">
        <button class="music-avatar" id="music-avatar" title="${l(n("music.account_btn"))}"></button>
        <span class="music-acc" id="music-acc"></span>
        <div class="music-search-wrap">
          <input class="music-search" id="music-search" type="search" autocomplete="off" spellcheck="false" placeholder="${l(n("music.search_ph"))}">
          <!-- 下拉预览：绝对定位挂在工具条下方（**不占布局**，否则窗口高会跟着抖） -->
          <div class="music-dd hidden" id="music-search-dd"></div>
        </div>
        <span class="music-status" id="music-status">${n("music.loading")}</span>
        <!-- 这里原来的「本地音乐」文件夹按钮与「调音」推子按钮**已删除**（2026-10-01
             用户口径）：这两个入口收进了**标题栏那枚三段切换**（在线歌单 / 本地音乐 /
             调音，见 renderTitlebarSwitch）。标题栏是悬浮窗独有的，插件若被嵌在主窗口里
             就没有那一条 —— 那种情况下切换器会退到本工具条里（见 placeSwitcher），
             所以这里不给它们留第二份入口，否则「删掉」就变成了「多一份」。
             ⚠️ 本段是 JS 模板字符串，注释里不能出现反引号（预检 #15 / #39 ⑩）。 -->
        <button class="music-ghost-btn music-icon-btn" id="music-setup-toggle" title="${l(n("music.settings"))}">${m.gear}</button>
      </div>

      <div class="music-setup hidden" id="music-setup">
        <div class="music-hint" id="music-setup-hint">${n("music.setup_hint")}</div>
        <!-- 凭据字段默认只在「没有内置 Client ID」或用户主动展开时显示：
             内置值让「登录」变成一步操作，Redirect URI 那一串对普通用户是噪音。 -->
        <button class="music-ghost-btn music-fields-toggle hidden" id="music-fields-toggle"></button>
        <div id="music-setup-fields">
          <div class="music-field">
            <label for="music-client-id">${n("music.client_id")}</label>
            <input id="music-client-id" type="text" spellcheck="false" autocomplete="off" placeholder="${l(n("music.client_id_ph"))}">
          </div>
          <div class="music-field music-field-port">
            <label for="music-port">${n("music.port")}</label>
            <input id="music-port" type="text" inputmode="numeric" autocomplete="off">
          </div>
          <div class="music-field">
            <label>${n("music.redirect")}</label>
            <div class="music-redirect-row">
              <code id="music-redirect"></code>
              <button class="music-ghost-btn music-icon-btn" id="music-copy-redirect" title="${l(n("music.copy"))}">${m.copy}</button>
            </div>
          </div>
          <!-- 本机播放（librespot）的两项设置：路径留空 = 自动探测；代理留空 = 直连。
               两者都不是「必填」，所以各带一行小字说明（见 renderSetup）。 -->
          <div class="music-field">
            <label for="music-librespot">${n("music.local_play")}</label>
            <input id="music-librespot" type="text" spellcheck="false" autocomplete="off" placeholder="librespot.exe">
          </div>
          <div class="music-field">
            <label for="music-librespot-proxy">proxy</label>
            <input id="music-librespot-proxy" type="text" spellcheck="false" autocomplete="off" placeholder="http://127.0.0.1:7890">
          </div>
        </div>
        <div class="music-actions">
          <button class="music-btn" id="music-save">${n("music.save")}</button>
          <button class="music-btn music-primary" id="music-connect">${m.link} ${n("music.connect")}</button>
          <button class="music-btn" id="music-disconnect">${m.power} ${n("music.disconnect")}</button>
        </div>
      </div>

      <!-- 主体：**左栏（宽度可拖）+ 分隔条 + 主区**（用户 2026-09-28 的
           「歌单列作为单独的一列可拉动」「中间大的大部分区域作为歌曲列表」）。
           两栏各自内部滚动 —— 窗口是定尺 1280×720，不是靠内容撑出来的。 -->
      <div class="music-body hidden" id="music-body">
        <aside class="music-side" id="music-side">
          <div class="music-side-tabs" id="music-side-tabs">
            <button class="music-tab on" data-act="side-tab" data-tab="playlist">${n("music.playlists")}</button>
            <button class="music-tab" data-act="side-tab" data-tab="album">${n("music.tab_albums")}</button>
            <button class="music-tab" data-act="side-tab" data-tab="artist">${n("music.tab_artists")}</button>
            <button class="music-tab" data-act="side-tab" data-tab="show">${n("music.tab_shows")}</button>
            <!-- 「发现」两栏（2026-10-01 用户第 4 条）。**放在最后**：那四栏是「我的库」，
                 这两栏是「库外的东西」，顺序上按这个分组走。
                 注：本段在模板字符串里，注释里不能出现反引号（预检 #15 / #39 ⑩）。 -->
            <button class="music-tab" data-act="side-tab" data-tab="new">${n("music.tab_new")}</button>
            <button class="music-tab" data-act="side-tab" data-tab="top">${n("music.tab_top")}</button>
          </div>
          <!-- 「本地音乐」那一页的左栏头（与上面那排 Spotify 页签**互斥显示**）：
               一个标题 + 一个「添加目录」。它跟着 localPage 切，见 renderLocalSide。 -->
          <div class="music-local-head hidden" id="music-local-head">
            <span class="music-local-title">${n("music.local_library")}</span>
            <div class="music-local-head-btns">
              <!-- 正常态三枚（2026-10-01 用户口径）：
                   ＋ = 添加（**目录或播放列表文件**，两个入口合一）
                   ✎ = 修改列表（进编辑态）—— 取代原来那枚「打开播放列表文件」
                   ⟳ = 重扫。
                   图标一律取自 icon-style.md §3，不自己画（见 SVG.edit / SVG.trash）。 -->
              <button class="music-ghost-btn music-icon-btn" id="music-local-add" title="${l(n("music.local_add"))}">${m.plus}</button>
              <button class="music-ghost-btn music-icon-btn" id="music-local-list" title="${l(n("music.local_edit"))}">${m.edit}</button>
              <button class="music-ghost-btn music-icon-btn" id="music-local-scan" title="${l(n("music.local_rescan"))}">${m.refresh}</button>
              <!-- 编辑态两枚（正常态隐藏，切法见 renderLocalHead）：
                   🗑 = 把勾选的行**摘出列表**（暂存，还能反悔）
                   × = 退出并保存（到这一步才真落盘） -->
              <button class="music-ghost-btn music-icon-btn hidden" id="music-local-del" title="${l(n("music.local_del_sel"))}">${m.trash}</button>
              <button class="music-ghost-btn music-icon-btn hidden" id="music-local-editdone" title="${l(n("music.local_edit_done"))}">${m.x}</button>
              <!-- 那个「＋」的二选一浮层（目录 / 播放列表文件）。画法见 renderLocalAddMenu，
                   定位参照是上面那排按钮（.music-local-head-btns 是 relative）。
                   注：本段在**模板字符串**里，注释里一个反引号都不能出现（预检 #15 / #39 ⑩）。 -->
              <div class="music-dd music-local-add-dd hidden" id="music-local-add-dd"></div>
            </div>
          </div>
          <div class="music-side-list" id="music-side-list"></div>
        </aside>
        <div class="music-split" id="music-split" role="separator" aria-orientation="vertical"></div>
        <main class="music-main" id="music-main"></main>
      </div>

      <!-- ── 底部控制栏（2026-09-28，Spotify 复刻）─────────────────────────
           用户要求「在默认面板下方添加 Spotify 那样的播放控制，并把一些按钮也
           移动到下方控制」。三列 grid：左 = 正在播放（点它 = 打开播放面板）、
           中 = 播放键组、右 = 设备 / 音量 / 队列 / 展开。
           栏顶那条 2px 细进度线**绝对定位**（不占高），拖动即可跳转。
           **两个弹层都挂在右端那一簇里、向上弹**：这条栏贴着窗口下沿，
           向下弹会跑到窗口外面（见 styles.css 里那两条覆盖 top 的规则）。
           注意本段是 JS 模板字符串 —— 注释里不能出现反引号（会把字符串截断）。 -->
      <div class="music-nowbar hidden" id="music-nowbar">
        <div class="music-bp music-bp-timed" id="music-bp" title="${l(n("music.seek"))}">
          <div class="music-bp-fill" id="music-bp-fill"></div>
          <div class="music-progress-tip" id="music-bp-tip">0:00</div>
          <span class="music-btime" id="music-b-time">00:00 / 00:00</span>
        </div>
        <button class="music-bnow" id="music-bnow" title="${l(n("music.open_player"))}">
          <span class="music-bnow-cover" id="music-bnow-cover"></span>
          <span class="music-bnow-main">
            <span class="music-bnow-n" id="music-bnow-n"></span>
            <span class="music-bnow-a" id="music-bnow-a"></span>
          </span>
        </button>
        <div class="music-bctl">
          <button class="music-round-btn music-mode-btn" id="music-b-mode" data-mode="off"></button>
          <button class="music-round-btn" id="music-b-prev" title="${l(n("music.prev"))}">${m.prev}</button>
          <button class="music-round-btn music-play-btn" id="music-b-play" title="${l(n("music.play_pause"))}">${m.play}</button>
          <button class="music-round-btn" id="music-b-next" title="${l(n("music.next"))}">${m.next}</button>
        </div>
        <div class="music-bend">
          <!-- 与本地播放条上那一枚是**同一个状态**（见 dualPlay 的注释）。
               两枚按钮各自长在自己的控制区里，用户在哪条栏上都够得着。 -->
          <button class="music-ghost-btn music-icon-btn music-dual-btn" id="music-dual-btn" title="${l(n("music.dual_play"))}">${m.dual}</button>
          <button class="music-ghost-btn music-icon-btn" id="music-devices-btn" title="${l(n("music.devices"))}">${m.speaker}</button>
          <span class="music-vol-ico">${m.volume}</span>
          <input class="music-vol" id="music-b-vol" type="range" min="0" max="100" step="1" value="50" style="--vol-pct:50%" title="${l(n("music.volume"))}">
          <button class="music-round-btn" id="music-b-queue" title="${l(n("music.queue"))}">${m.list}</button>
          <button class="music-ghost-btn music-icon-btn hidden" id="music-open-player" title="${l(n("music.open_player"))}">${m.expand}</button>
          <div class="music-dd music-dev-dd hidden" id="music-dev-dd"></div>
          <div class="music-dd hidden" id="music-q-dd"></div>
        </div>
      </div>

      <!-- ── 本地文件播放条（2026-10-01）───────────────────────────────
           与上面那条 Spotify 控制栏**不是一条**：那条的对象是远端播放器
           （Web API 的 spotify_* 命令），这条的对象是宿主里那条本机音频流
           （player.rs 的 player_* 命令）。两者的数据源、可用条件（这条不要求
           登录 Spotify）、能做的事都不一样 —— 合成一条会到处长出
           「如果是本地就…」的分支，那正是两套东西被缝在一起的样子。
           只在「本地页 + 有本地会话」时出现，见 renderLocalNowbar。
           注意本段是 JS 模板字符串 —— 注释里不能出现反引号。 -->
      <div class="music-nowbar music-lnowbar hidden" id="music-lnowbar">
        <div class="music-bp" id="music-lbp" title="${l(n("music.seek"))}">
          <div class="music-bp-fill" id="music-lbp-fill"></div>
          <div class="music-progress-tip" id="music-lbp-tip">0:00</div>
        </div>
        <div class="music-bnow music-lnow">
          <span class="music-bnow-cover" id="music-lnow-cover"></span>
          <span class="music-bnow-main">
            <span class="music-bnow-n" id="music-lnow-n"></span>
            <span class="music-bnow-a" id="music-lnow-a"></span>
          </span>
        </div>
        <div class="music-bctl">
          <!-- 播放模式（关 / 随机 / 循环列表 / 单曲循环，2026-10-01 用户第 8 条）。
               与 Spotify 那枚 #music-b-mode **不是一件事**：那枚是远端真相，
               这枚是前端自己算的（见 localMode 的注释），所以两枚各记各的状态。
               注：本段在模板字符串里，注释里不能出现反引号（预检 #15 / #39 ⑩）。 -->
          <button class="music-round-btn music-mode-btn" id="music-l-mode" data-mode="off" title="${l(n("music.mode_off"))}"></button>
          <button class="music-round-btn" id="music-l-prev" title="${l(n("music.prev"))}">${m.prev}</button>
          <button class="music-round-btn music-play-btn" id="music-l-play" title="${l(n("music.play_pause"))}">${m.play}</button>
          <button class="music-round-btn" id="music-l-next" title="${l(n("music.next"))}">${m.next}</button>
          <button class="music-round-btn" id="music-l-stop" title="${l(n("music.local_stop"))}">${m.stop}</button>
        </div>
        <div class="music-bend">
          <button class="music-ghost-btn music-icon-btn music-dual-btn" id="music-l-dual-btn" title="${l(n("music.dual_play"))}">${m.dual}</button>
          <span class="music-ltime" id="music-l-time">0:00 / 0:00</span>
          <span class="music-vol-ico">${m.volume}</span>
          <input class="music-vol" id="music-l-vol" type="range" min="0" max="100" step="1" value="80" style="--vol-pct:80%" title="${l(n("music.volume"))}">
          <!-- 小窗入口（2026-10-01 用户口径：本地播放也要有）。与 Spotify 那条栏
               右端那枚 #music-open-player 同形同义 —— 只是它带去的是**本地**那条
               长条（#music-v-lplayer），由 mode = "lplayer" 切。 -->
          <button class="music-ghost-btn music-icon-btn" id="music-l-open-player" title="${l(n("music.open_player"))}">${m.expand}</button>
        </div>
      </div>
    </div>

    <!-- ── 播放界面：**550×130 的长条**（封面 100 + 右侧列 450）──────────
         右侧列三块的高度加起来正好是长条高：歌名 30 + 歌词 65 + 控制 35 = 130。
         **这几个数都是用户 2026-09-27 给的定尺**：改任何一个都要同步
         styles.css 的 .music-name / .music-lyr / .music-bar，以及宿主
         plugin_window.rs 的 MUSIC_W（见 ai-spec §4.6 与预检 #39 ④）。 -->
    <!-- 注意：本段是 JS 模板字符串，**注释里不能出现反引号**（会把字符串截断）。 -->
    <div class="music-view music-player hidden" id="music-v-player">
      <div class="music-pv-card">
        <div class="music-pv-cover" id="music-pv-cover"></div>
        <div class="music-pv-col">
          <!-- 歌名模块 H30：歌名（亮）+ 歌手·专辑（暗）。 -->
          <div class="music-name">
            <div class="music-name-text">
              <span class="music-title" id="music-pv-title"></span>
              <span class="music-sub" id="music-pv-sub"></span>
            </div>
            <!-- 「返回歌单」那枚**已删除**（2026-10-01 用户口径：小窗播放里那个不是
                 状态栏里的返回按钮要去掉）。退出去仍然走**标题栏那个 ←** ——
                 它在播放态由 syncTitlebarClose 把 × 换成 ←，语义是「停播 + 回默认面板」
                 （见 stopAndBack），也是用户当初指定的出口。所以这里删掉不留缺口。 -->
          </div>

          <!-- 歌词模块 H65：正好两行可见（行高 32）。已过 + 正在 = 亮，未到 = 暗；
               点某一行 = 跳到那一句的进度。 -->
          <div class="music-lyr" id="music-lyr"></div>

          <!-- 控制面板 H35：进度条**叠在本块顶部**（绝对定位 ⇒ 不占高度，总高仍是 130），
               四个播放键在块内居中，右端音量条 80px + 播放列表按钮。 -->
          <div class="music-bar">
            <!-- 时间在控制块**最左端、进度条下方**（用户 2026-09-27 定）。
                 绝对定位 ⇒ 不参与四钮的居中计算。 -->
            <div class="music-time">
              <span id="music-pv-pos">0:00</span><span class="music-time-sep">/</span><span id="music-pv-dur">0:00</span>
            </div>
            <div class="music-progress" id="music-pv-progress" title="${l(n("music.seek"))}">
              <div class="music-progress-fill" id="music-pv-fill"></div>
              <div class="music-progress-dot" id="music-pv-dot"></div>
              <div class="music-progress-tip" id="music-pv-tip">0:00</div>
            </div>
            <div class="music-bar-main">
              <button class="music-round-btn music-mode-btn" id="music-mode" data-mode="off"></button>
              <button class="music-round-btn" id="music-prev" title="${l(n("music.prev"))}">${m.prev}</button>
              <button class="music-round-btn music-play-btn" id="music-play" title="${l(n("music.play_pause"))}">${m.play}</button>
              <button class="music-round-btn" id="music-next" title="${l(n("music.next"))}">${m.next}</button>
            </div>
            <div class="music-bar-end">
              <span class="music-vol-ico">${m.volume}</span>
              <input class="music-vol" id="music-vol" type="range" min="0" max="100" step="1" value="50" style="--vol-pct:50%" title="${l(n("music.volume"))}">
              <button class="music-round-btn" id="music-queue-btn" title="${l(n("music.queue"))}">${m.list}</button>
            </div>
          </div>
        </div>
      </div>

      <!-- 播放列表（队列）挂在长条**下方**、不再与歌词互斥：长条是定尺 130，
           塞不进队列。开着时窗口按内容长高（applyResize 实测贴合）。 -->
      <div class="music-q-wrap hidden" id="music-q-wrap">
        <div class="music-sec-head">
          <span class="music-sec-title">${n("music.queue")}</span>
          <span class="music-sec-note">${n("music.queue_hint")}</span>
        </div>
        <div class="music-q" id="music-q"></div>
      </div>
    </div>

    <!-- ── 本地小窗：**本地文件播放也有的那条长条**（2026-10-01 用户口径
         「在本地文件播放的情况下也添加小窗模式」）────────────────────────
         与上一个视图**共用同一套外壳类**（music-player / music-pv-card / music-pv-cover /
         music-name / music-bar / music-bp…）⇒ 尺寸（550×130）、圆角、配色、
         进度条的细线与命中区，一行业务 CSS 都不用重写。
         唯一的差别在**中间那一块**：远端那条长条放的是歌词（H65，见 .music-lyr），
         本地文件没有歌词 —— 那一格换成**大号进度线 + 时间**（见 .music-lp-mid）。
         三块的高度仍是 30 + 65 + 35 = 130，与 MUSIC_W_BAR / applyResize 对齐。
         数据与动作**都只有一份**：状态来自 localPlayer，按钮走的是本地播放那几条
         既有函数（见 attachMusicListeners 里那几条绑定）。
         注意本段是 JS 模板字符串 —— 注释里不能出现反引号（预检 #15 / #39 ⑩）。 -->
    <div class="music-view music-player hidden" id="music-v-lplayer">
      <div class="music-pv-card">
        <div class="music-pv-cover" id="music-lp-cover"></div>
        <div class="music-pv-col">
          <div class="music-name">
            <div class="music-name-text">
              <span class="music-title" id="music-lp-title"></span>
              <span class="music-sub" id="music-lp-sub"></span>
            </div>
          </div>
          <div class="music-lp-mid">
            <div class="music-bp music-lp-seek" id="music-lp-progress" title="${l(n("music.seek"))}">
              <div class="music-bp-fill" id="music-lp-fill"></div>
              <div class="music-progress-tip" id="music-lp-tip">0:00</div>
            </div>
            <div class="music-lp-time" id="music-lp-time">0:00 / 0:00</div>
          </div>
          <div class="music-bar">
            <div class="music-bar-main">
              <button class="music-round-btn music-mode-btn" id="music-lp-mode" data-mode="off" title="${l(n("music.mode_off"))}"></button>
              <button class="music-round-btn" id="music-lp-prev" title="${l(n("music.prev"))}">${m.prev}</button>
              <button class="music-round-btn music-play-btn" id="music-lp-play" title="${l(n("music.play_pause"))}">${m.play}</button>
              <button class="music-round-btn" id="music-lp-next" title="${l(n("music.next"))}">${m.next}</button>
              <button class="music-round-btn" id="music-lp-stop" title="${l(n("music.local_stop"))}">${m.stop}</button>
            </div>
            <div class="music-bar-end">
              <span class="music-vol-ico">${m.volume}</span>
              <input class="music-vol" id="music-lp-vol" type="range" min="0" max="100" step="1" value="80" style="--vol-pct:80%" title="${l(n("music.volume"))}">
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- ── 设置页：**整屏**（2026-10-01 用户要求「设置图标进到一个新的设置页面」）──
         与 #music-v-player 同为整屏视图，由 mode = "settings" 切（见 renderMode）。
         职责划分是硬的：**这里只放「偏好」，「连接」仍归头像点开的 #music-setup**
         （Client ID / 端口 / 回调 / librespot 路径与代理），**「调音」也有自己的一页**
         （#music-v-tuning，2026-10-01 用户要求搬出去的）。理由与那张卡片里的
         「保存」按钮直接相关 —— 一个卡片里塞两套保存语义必然出岔子，而现在这几页
         各有各的保存。
         ⚠️ 本段是 JS 模板字符串 —— 注释里**不许出现反引号**，连「引用一个标识符」
         那种写法都不行：它会把模板字符串提前截断（预检 #15 / #39 ⑩，本轮又踩了一次）。 -->
    <div class="music-view music-setview hidden" id="music-v-settings">
      <div class="music-set-head">
        <button class="music-ghost-btn music-icon-btn" id="music-set-back" title="${l(n("music.settings_back"))}">${m.back}</button>
        <span class="music-set-title">${n("music.settings")}</span>
      </div>
      <div class="music-set-body">
        <!-- 串流质量：三档互斥按钮。**不用原生 select 元素** —— WebView2 透明窗口里
             它不渲染弹出层（code-rules §5.2）。三档值只允许 96/160/320（宿主侧
             LIBRESPOT_BITRATES，抄自 librespot --help 的原文）。
             ⚠️ 模板字符串 ⇒ 本段注释里也不许出现反引号（预检 #39 ⑩）。 -->
        <div class="music-field">
          <label>${n("music.quality")}</label>
          <div class="music-seg" id="music-quality">
            ${[96, 160, 320].map((t) => `<button type="button" class="music-seg-btn" data-q="${t}">${t}k</button>`).join("")}
          </div>
          <div class="music-hint">${l(n("music.quality_hint"))}</div>
          <div class="music-hint">${l(n("music.quality_local_note"))}</div>
        </div>
        <div class="music-actions">
          <button class="music-btn" id="music-set-save">${n("music.save")}</button>
        </div>
      </div>
    </div>

    <!-- ── 调音页：**自己一页**（2026-10-01 用户口径）────────────────────
         用户明确「调音插件的界面不能放置到设置界面里，要新建一个界面专门用来显示调音」
         —— 所以它在 2026-10-01 从设置页那一块**整段搬过来**（上一版是「调音分区」）。
         入口只有一个：标题栏那枚三段切换的第三段（见 renderTitlebarSwitch），
         另配一枚返回（与设置页同形）。
         四条纪律：① 控件**按下就生效、也当场落盘**（与设置页「音质」那两条攒着
         等保存完全不同：音质要重启 librespot 才生效，调音是实时的）；
         ② 预设按钮的**键来自宿主**（tuning.presets）、滤波器类型的**名单也来自宿主**
         （tuning.kinds，与引擎 Kind::ALL 同源）—— 前端不维护第二份名单；
         ③ 只对**本地文件播放**生效（Spotify 那条流在本机之外，宿主碰不到）；
         ④ 表格行里的控件**全部动态渲染**（见 renderTuningFilters），这里只留容器。
         ⚠️ 本段是 JS 模板字符串 ⇒ 注释里不许出现反引号（预检 #15 / #39 ⑩）。 -->
    <div class="music-view music-setview hidden" id="music-v-tuning">
      <div class="music-set-head">
        <button class="music-ghost-btn music-icon-btn" id="music-tune-back" title="${l(n("music.settings_back"))}">${m.back}</button>
        <span class="music-set-title">${n("music.tuning")}</span>
      </div>
      <div class="music-set-body">
        <div class="music-field">
          <label>${n("music.tuning")}</label>
          <div class="music-seg" id="music-tuning-on">
            <button type="button" class="music-seg-btn" data-on="1">${n("music.tuning_on")}</button>
            <button type="button" class="music-seg-btn" data-on="0">${n("music.tuning_off")}</button>
          </div>
          <div class="music-hint">${l(n("music.tuning_hint"))}</div>
        </div>
        <div class="music-field">
          <label>${n("music.tuning_presets")}</label>
          <div class="music-seg music-seg-wrap" id="music-tuning-preset"></div>
          <div class="music-hint hidden" id="music-tuning-custom-hint">${l(n("music.tuning_custom"))}</div>
        </div>
        <div class="music-tune-plot">
          <canvas id="music-tune-canvas" width="640" height="170"></canvas>
          <div class="music-hint" id="music-tune-rate"></div>
        </div>
        <div class="music-field music-field-narrow">
          <label>${n("music.tuning_preamp")}</label>
          <input type="text" id="music-tune-preamp" inputmode="decimal" autocomplete="off" spellcheck="false" />
        </div>
        <div class="music-field">
          <label>${n("music.tuning_filters")}</label>
          <div class="music-tune-filters" id="music-tuning-filters"></div>
          <div class="music-actions">
            <button type="button" class="music-btn" id="music-tune-add">${m.plus}${n("music.tuning_add")}</button>
          </div>
        </div>
        <div class="music-hint">${l(n("music.tuning_note"))}</div>
      </div>
    </div>

    <div class="music-msg" id="music-msg"></div>
  </div>`;
}
function g(t, e) {
  t && t.textContent !== e && (t.textContent = e);
}
function E(t, e) {
  t && t.innerHTML !== e && (t.innerHTML = e);
}
function q(t, e) {
  t == null || t.classList.toggle("hidden", !e);
}
function yt(t, e, i) {
  t && t.getAttribute(e) !== i && t.setAttribute(e, i);
}
function Zt(t, e) {
  if (!t) return;
  const i = Math.max(0, Math.min(100, Math.round(e)));
  t.style.setProperty("--vol-pct", `${i}%`);
}
function wn(t) {
  const e = t.querySelector("#music-msg");
  if (!e) return;
  const i = e.textContent ?? "";
  if (i !== De) {
    De = i, Be = Date.now();
    return;
  }
  i && Date.now() - Be >= ln && (e.textContent = "", De = "", Be = 0);
}
function Q(t) {
  const e = Ge();
  q(t.querySelector("#music-v-default"), L === "default"), q(t.querySelector("#music-v-player"), L === "player"), q(t.querySelector("#music-v-lplayer"), L === "lplayer"), q(t.querySelector("#music-v-settings"), L === "settings");
  const i = L === "tuning";
  q(t.querySelector("#music-v-tuning"), i), i && Qe(t), t.classList.toggle("music-player-on", e), $n(e), kn(), pi(t), Ln(), L === "player" ? (Dt = -1, Ue(t), Ke(t)) : L === "lplayer" ? Cs(t) : L === "default" && (q(t.querySelector("#music-body"), !!(r != null && r.connected) || H), Vt(t), st(t), bt(t), le(t)), ke(t);
}
function $n(t) {
  const e = !t;
  document.getElementById("plugin-titlebar") && li !== e && (li = e, p("plugin_window_set_resizable", { resizable: e }).catch(() => {
  }));
}
function kn() {
  const t = document.getElementById("plugin-close");
  if (!t) return;
  ye || (ye = t.innerHTML);
  const e = Ge() ? "back" : "close";
  if (t.dataset.mode === e) return;
  t.dataset.mode = e, t.innerHTML = e === "back" ? m.back : ye;
  const i = e === "back" ? n("music.back") : "Close";
  t.title = i, t.setAttribute("aria-label", i);
}
function Sn() {
  const t = document.getElementById("plugin-close");
  !t || !ye || t.dataset.mode !== "back" || (t.innerHTML = ye, t.title = "Close", t.setAttribute("aria-label", "Close"), t.dataset.mode = "close");
}
function xn() {
  return L === "tuning" ? "tuning" : L !== "default" ? "" : H ? "local" : "online";
}
function En(t) {
  const e = document.getElementById("music-tb-switch");
  if (e) return e;
  const i = document.createElement("div");
  i.id = "music-tb-switch", i.className = "music-tb-switch", i.setAttribute("role", "tablist"), i.setAttribute("data-tauri-drag-region", "");
  const s = [
    ["online", n("music.tb_online")],
    ["local", n("music.tb_local")],
    ["tuning", n("music.tb_tuning")]
  ];
  i.innerHTML = s.map(([f, k]) => `<button type="button" class="music-tb-seg" role="tab" data-seg="${f}" title="${l(k)}">${l(k)}</button>`).join("");
  const c = document.getElementById("plugin-titlebar"), a = document.getElementById("plugin-title");
  if (c && a)
    c.insertBefore(i, a.nextSibling);
  else {
    const f = t.querySelector("#music-setup-toggle"), k = t.querySelector(".music-toolbar");
    if (!k) return null;
    k.insertBefore(i, f);
  }
  return i;
}
function Ln() {
  const t = document.getElementById("music-tb-switch");
  if (!t) return;
  const e = xn();
  for (const i of t.querySelectorAll(".music-tb-seg"))
    yt(i, "aria-pressed", String(i.dataset.seg === e));
}
function qn() {
  var t;
  (t = document.getElementById("music-tb-switch")) == null || t.remove();
}
async function Mn(t) {
  try {
    await p("spotify_control", { action: "pause" });
  } catch (e) {
    x(t, M(e));
  }
  L = "default", Q(t);
}
function Es(t) {
  const e = t.querySelector("#music-setup-toggle"), i = t.querySelector(".music-toolbar");
  if (!e || !i) return;
  const s = t.querySelector(".music-local-head-row"), c = H && s ? s : i;
  e.parentElement !== c && c.appendChild(e);
}
function pi(t) {
  const e = L === "player";
  q(t.querySelector("#music-open-player"), !e && !!(d != null && d.track)), q(t.querySelector("#music-nowbar"), !e && !!(r != null && r.connected) && !H);
  for (const i of [".music-search-wrap", "#music-avatar", "#music-acc", "#music-status"])
    q(t.querySelector(i), !H);
  Es(t), t.querySelectorAll(".music-dual-btn").forEach((i) => i.classList.toggle("on", kt));
}
function Yt(t, e) {
  const i = t.querySelector("#music-status");
  r != null && r.client_id ? r.connected ? d ? d.active ? d.playing ? g(i, n("music.status_playing")) : g(i, n("music.status_paused")) : g(i, n("music.status_no_device")) : g(i, n("music.status_connecting")) : g(i, n("music.status_disconnected")) : g(i, n("music.status_unconfigured"));
  const s = t.querySelector("#music-avatar");
  if (s) {
    const a = r != null && r.connected && r.avatar || "";
    E(s, a ? `<img src="${l(a)}" alt="">` : "");
  }
  g(t.querySelector("#music-acc"), r != null && r.connected && r.display_name || "");
  const c = t.querySelector("#music-devices-btn");
  c && (yt(c, "title", `${n("music.devices")}：${(d == null ? void 0 : d.device) || n("music.device_none")}`), c.classList.toggle("warn", !!(r != null && r.connected) && !(d != null && d.active)));
}
function Gt(t) {
  q(t.querySelector("#music-setup"), !(r != null && r.connected) || Re), q(t.querySelector("#music-body"), !!(r != null && r.connected) || H), Vt(t), st(t), r != null && r.connected && (Bs(t, Y), Os(t));
  const e = Ie ?? !(r != null && r.builtin);
  q(t.querySelector("#music-setup-fields"), e), q(t.querySelector("#music-save"), e);
  const i = t.querySelector("#music-fields-toggle");
  q(i, !!(r != null && r.builtin)), g(i, n(e ? "music.hide_fields" : "music.use_own_client_id")), g(
    t.querySelector("#music-setup-hint"),
    r != null && r.builtin ? n("music.setup_builtin") : n("music.setup_hint")
  );
  const s = t.querySelector("#music-client-id"), c = t.querySelector("#music-port"), a = t.querySelector("#music-librespot"), f = t.querySelector("#music-librespot-proxy");
  s && document.activeElement !== s && (s.value = (r == null ? void 0 : r.client_id) ?? ""), c && document.activeElement !== c && (c.value = String((r == null ? void 0 : r.port) ?? 8899)), a && document.activeElement !== a && (a.value = (r == null ? void 0 : r.librespot_path) ?? ""), f && document.activeElement !== f && (f.value = (r == null ? void 0 : r.librespot_proxy) ?? "");
  const k = re ?? (r == null ? void 0 : r.librespot_bitrate) ?? 320;
  for (const T of t.querySelectorAll("#music-quality .music-seg-btn"))
    yt(T, "aria-pressed", String(Number(T.dataset.q) === k));
  g(t.querySelector("#music-redirect"), (r == null ? void 0 : r.redirect_uri) ?? "");
}
function Tn(t) {
  const e = n(`music.tuning_p_${t}`);
  return e.startsWith("music.") ? t : e;
}
function as(t) {
  const e = n(`music.tk_${t}`);
  return e.startsWith("music.") ? t : e;
}
function ut(t, e = 3) {
  return t === void 0 || !Number.isFinite(t) ? "" : String(Math.round(t * 10 ** e) / 10 ** e);
}
function Cn(t, e) {
  return e === "freq_hz" ? ut(t.freq_hz, 1) : e === "gain_db" ? ut(t.gain_db ?? 0, 1) : e === "q" ? ut(t.q ?? 0.707, 3) : "";
}
async function Qe(t) {
  let e;
  try {
    e = await p("player_tuning_get");
  } catch (i) {
    x(t, M(i));
    return;
  }
  JSON.stringify(e) !== JSON.stringify(I) && (I = e, ze(), dt = -1), Ye(t);
}
function Ye(t) {
  if (!I) return;
  for (const s of t.querySelectorAll("#music-tuning-on .music-seg-btn"))
    yt(s, "aria-pressed", String(s.dataset.on === "1" === I.enabled));
  const e = t.querySelector("#music-tuning-preset");
  e && E(
    e,
    I.presets.map((s) => {
      const c = I.preset === s;
      return `<button type="button" class="music-seg-btn" data-preset="${l(s)}" aria-pressed="${c}">${l(Tn(s))}</button>`;
    }).join("")
  ), q(t.querySelector("#music-tuning-custom-hint"), I.preset === "custom");
  const i = t.querySelector("#music-tune-preamp");
  i && document.activeElement !== i && i.value !== ut(Ht, 1) && (i.value = ut(Ht, 1)), Ls(t), Rn(t), g(
    t.querySelector("#music-tune-rate"),
    n("music.tuning_rate", { rate: ut(I.response.sample_rate / 1e3, 1) })
  );
}
function In(t, e, i, s) {
  const c = i.find((w) => w.name === t.kind), a = c ? c.gain : t.gain_db !== void 0, f = c ? c.order !== 1 : t.q !== void 0, k = a ? `<input type="text" class="music-tune-num" data-f="gain_db" inputmode="decimal" autocomplete="off" spellcheck="false" value="${l(ut(t.gain_db ?? 0, 1))}" placeholder="${l(n("music.tuning_gain"))}" aria-label="${l(n("music.tuning_gain"))}" />` : "", T = f ? `<input type="text" class="music-tune-num" data-f="q" inputmode="decimal" autocomplete="off" spellcheck="false" value="${l(ut(t.q ?? 0.707, 3))}" placeholder="${l(n("music.tuning_q"))}" aria-label="${l(n("music.tuning_q"))}" />` : "", A = s ? `<div class="music-tune-menu">${i.map(
    (w) => `<button type="button" class="music-seg-btn" data-act="pick" data-kind="${l(w.name)}" aria-pressed="${w.name === t.kind}">${l(as(w.name))}</button>`
  ).join("")}</div>` : "";
  return `<div class="music-tune-row${t.on ? "" : " off"}" data-i="${e}">
      <div class="music-tune-line">
        <button type="button" class="music-tune-sw" data-act="on" aria-pressed="${t.on}" title="${l(t.on ? n("music.tuning_off") : n("music.tuning_on"))}">${m.power}</button>
        <button type="button" class="music-tune-kind" data-act="kind" aria-expanded="${s}"><span>${l(as(t.kind))}</span>${m.chevron}</button>
        <input type="text" class="music-tune-num" data-f="freq_hz" inputmode="decimal" autocomplete="off" spellcheck="false" value="${l(ut(t.freq_hz, 1))}" placeholder="${l(n("music.tuning_freq"))}" aria-label="${l(n("music.tuning_freq"))}" />
        ${k}${T}
        <button type="button" class="music-tune-del" data-act="del" title="${l(n("music.tuning_del"))}">${m.trash}</button>
      </div>
      ${A}
    </div>`;
}
function Ls(t) {
  const e = t.querySelector("#music-tuning-filters");
  if (!e || !I) return;
  const i = I.kinds;
  E(
    e,
    St.length === 0 ? `<div class="music-hint">${l(n("music.tuning_empty"))}</div>` : St.map((s, c) => In(s, c, i, dt === c)).join("")
  );
}
function Rn(t) {
  const e = t.querySelector("#music-tune-canvas");
  if (!e || !I) return;
  const i = e.clientWidth || e.width, s = e.clientHeight || e.height;
  if (i < 2 || s < 2) return;
  const c = window.devicePixelRatio || 1;
  (e.width !== Math.round(i * c) || e.height !== Math.round(s * c)) && (e.width = Math.round(i * c), e.height = Math.round(s * c));
  const a = e.getContext("2d");
  if (!a) return;
  a.setTransform(c, 0, 0, c, 0, 0), a.clearRect(0, 0, i, s);
  const f = getComputedStyle(t), k = f.getPropertyValue("--accent").trim() || "#7aa2f7", T = f.getPropertyValue("--border-glass").trim() || "rgba(255,255,255,0.12)", A = f.getPropertyValue("--text-dim").trim() || "rgba(255,255,255,0.55)", { freqs: w, db: G } = I.response, C = 30, Te = 8, gt = 8, Ze = 16, _t = Math.max(1, i - C - Te), At = Math.max(1, s - gt - Ze);
  let oe = 0;
  for (const S of G) Number.isFinite(S) && (oe = Math.max(oe, Math.abs(S)));
  const X = Math.min(60, Math.max(12, Math.ceil((oe + 1) / 6) * 6)), W = Math.log10(20), Mt = Math.log10(2e4), K = (S) => C + (Math.log10(Math.max(1, S)) - W) / (Mt - W) * _t, Tt = (S) => gt + (X - S) / (2 * X) * At;
  a.lineWidth = 1, a.font = "9px system-ui, -apple-system, sans-serif", a.textBaseline = "middle";
  for (const S of [X, X / 2, 0, -X / 2, -X])
    a.strokeStyle = T, a.globalAlpha = S === 0 ? 0.9 : 0.45, a.setLineDash(S === 0 ? [] : [3, 3]), a.beginPath(), a.moveTo(C, Tt(S)), a.lineTo(C + _t, Tt(S)), a.stroke();
  a.setLineDash([]), a.fillStyle = A;
  for (const S of [20, 100, 1e3, 1e4, 2e4]) {
    const F = K(S);
    a.globalAlpha = 0.45, a.strokeStyle = T, a.beginPath(), a.moveTo(F, gt), a.lineTo(F, gt + At), a.stroke(), a.globalAlpha = 0.9, a.textAlign = S === 20 ? "left" : S === 2e4 ? "right" : "center", a.fillText(S >= 1e3 ? `${S / 1e3}k` : String(S), F, gt + At + 8);
  }
  a.textAlign = "right";
  for (const S of [X, X / 2, 0, -X / 2, -X])
    a.globalAlpha = 0.9, a.fillStyle = A, a.fillText(`${S > 0 ? "+" : ""}${ut(S, 0)}`, C - 3, Tt(S));
  if (a.textAlign = "left", a.globalAlpha = 1, !(w.length < 2 || G.length !== w.length)) {
    a.beginPath();
    for (let S = 0; S < w.length; S++) {
      const F = K(w[S]), wt = Tt(G[S]);
      S === 0 ? a.moveTo(F, wt) : a.lineTo(F, wt);
    }
    a.lineTo(K(w[w.length - 1]), Tt(0)), a.lineTo(K(w[0]), Tt(0)), a.closePath(), a.globalAlpha = 0.12, a.fillStyle = k, a.fill(), a.globalAlpha = 1, a.beginPath();
    for (let S = 0; S < w.length; S++) {
      const F = K(w[S]), wt = Tt(G[S]);
      S === 0 ? a.moveTo(F, wt) : a.lineTo(F, wt);
    }
    a.strokeStyle = k, a.lineWidth = 1.5, a.stroke();
  }
}
function An(t, e, i) {
  t.kind = e;
  const s = i.find((c) => c.name === e);
  s && (s.gain ? t.gain_db === void 0 && (t.gain_db = 0) : delete t.gain_db, s.order === 1 ? delete t.q : t.q === void 0 && (t.q = 0.707));
}
async function zt(t) {
  var k, T;
  const e = ++xt, i = document.activeElement, s = (k = i == null ? void 0 : i.closest) == null ? void 0 : k.call(i, ".music-tune-row"), c = i instanceof HTMLInputElement ? i.dataset.f : void 0, a = s ? Number(s.dataset.i) : -1;
  let f;
  try {
    f = await p("player_tuning_set_chain", {
      preampDb: Ht,
      filters: St
    });
  } catch (A) {
    if (e !== xt) return;
    x(t, M(A)), await Qe(t);
    return;
  }
  e === xt && (I = f, ze(), x(t, n("music.tuning_saved")), Ye(t), c && a >= 0 && a < St.length && ((T = t.querySelector(`.music-tune-row[data-i="${a}"] input[data-f="${c}"]`)) == null || T.focus()));
}
async function Nn(t, e) {
  const i = ++xt;
  let s;
  try {
    s = await p("player_tuning_set_enabled", { enabled: e });
  } catch (c) {
    if (i !== xt) return;
    x(t, M(c)), await Qe(t);
    return;
  }
  i === xt && (I = s, ze(), x(t, n("music.tuning_saved")), Ye(t));
}
async function Dn(t, e) {
  const i = ++xt;
  let s;
  try {
    s = await p("player_tuning_set", { enabled: !0, preset: e });
  } catch (c) {
    if (i !== xt) return;
    x(t, M(c)), await Qe(t);
    return;
  }
  i === xt && (I = s, ze(), dt = -1, x(t, n("music.tuning_saved")), Ye(t));
}
function Bn(t) {
  var e;
  return !!t.uri && ((e = d == null ? void 0 : d.track) == null ? void 0 : e.uri) === t.uri;
}
function x(t, e) {
  g(t.querySelector("#music-msg"), e);
}
function Je(t, e, i, s = "", c = "") {
  return `<button class="music-tr${Bn(t) ? " playing" : ""}" data-act="${i}" data-uri="${l(t.uri)}"${s ? ` data-i="${l(s)}"` : ""}${c ? ` title="${l(c)}"` : ""}>
    <span class="music-tr-i">${e + 1}</span>
    <span class="music-tr-main">
      <span class="music-tr-n">${l(t.name || "?")}</span>
      <span class="music-tr-a">${l(t.artists || t.album)}</span>
    </span>
    <span class="music-tr-d">${$e(t.duration_ms)}</span>
  </button>`;
}
function Xe(t) {
  return { id: t.id, uri: t.uri, name: t.name, cover: t.cover, subtitle: t.owner, total: t.total };
}
function Oe(t, e) {
  const i = !!e.uri && (d == null ? void 0 : d.context_uri) === e.uri, s = (_ == null ? void 0 : _.kind) === t && _.id === e.id, c = e.cover ? `<img src="${l(e.cover)}" alt="">` : "";
  return `<div class="music-pl${i ? " playing" : ""}${s ? " on" : ""}" data-uri="${l(e.uri)}">
    <button class="music-pl-btn" data-act="open" data-kind="${t}" data-id="${l(e.id)}" title="${l(e.name || "?")}">
      <span class="music-pl-cover">${c}</span>
      <span class="music-pl-main">
        <span class="music-pl-name">${l(e.name || "?")}</span>
        <span class="music-pl-sub">${l(e.subtitle)}</span>
      </span>
    </button>
  </div>`;
}
function On() {
  return `<div class="music-pl${(_ == null ? void 0 : _.kind) === "top-tracks" ? " on" : ""}">
    <button class="music-pl-btn" data-act="open" data-kind="top-tracks" data-id="top-tracks" title="${l(n("music.top_tracks"))}">
      <span class="music-pl-cover music-pl-trend-cover">${m.trend}</span>
      <span class="music-pl-main">
        <span class="music-pl-name">${l(n("music.top_tracks"))}</span>
        <span class="music-pl-sub">${l(n("music.top_tracks_sub"))}</span>
      </span>
    </button>
  </div>`;
}
function Pn(t, e) {
  const i = e.cover ? `<img src="${l(e.cover)}" alt="">` : "";
  return `<button class="music-card" data-act="open" data-kind="${t}" data-id="${l(e.id)}" title="${l(e.name)}">
    <span class="music-card-cover${t === "artist" ? " round" : ""}">${i}</span>
    <span class="music-card-n">${l(e.name)}</span>
    <span class="music-card-s">${l(e.subtitle)}</span>
  </button>`;
}
function jn() {
  const t = (_ == null ? void 0 : _.kind) === "liked", e = B ? String(B.total) : "", i = Wt || [(r == null ? void 0 : r.display_name) || "", e].filter(Boolean).join(" · ");
  return `<div class="music-pl music-pl-liked${t ? " on" : ""}${Wt ? " err" : ""}">
    <button class="music-pl-btn" data-act="open" data-kind="liked" data-id="liked" title="${l(n("music.liked_songs"))}">
      <span class="music-pl-cover music-pl-liked-cover">${m.heart}</span>
      <span class="music-pl-main">
        <span class="music-pl-name">${l(n("music.liked_songs"))}</span>
        <span class="music-pl-sub">${l(i)}</span>
      </span>
    </button>
  </div>`;
}
function Vt(t) {
  if (H) {
    Rt(t);
    return;
  }
  q(t.querySelector("#music-side-tabs"), !0), q(t.querySelector("#music-local-head"), !1), t.querySelectorAll("#music-side-tabs .music-tab").forEach((a) => {
    a.classList.toggle("on", a.dataset.tab === Y);
  });
  const e = t.querySelector("#music-side-list");
  if (!e) return;
  if (!(r != null && r.connected)) {
    E(e, `<div class="music-empty">${n("music.playlists_login")}</div>`);
    return;
  }
  const i = se.get(Y), s = Se.get(Y);
  let c = Y === "playlist" ? jn() : Y === "top" ? On() : "";
  ve.has(Y) ? c += `<div class="music-empty">${n("music.loading")}</div>` : s ? c += `<div class="music-empty music-empty-err">${l(s)}</div>` : i && (c += i.length === 0 ? `<div class="music-empty">${n(Y === "playlist" ? "music.playlists_empty" : "music.lib_empty")}</div>` : i.map((a) => Oe(Y, a)).join("")), E(e, c);
}
function ii(t) {
  t.querySelectorAll("#music-side-list .music-pl").forEach((e) => {
    const i = e.querySelector(".music-pl-btn"), s = !!_ && (i == null ? void 0 : i.dataset.kind) === _.kind && (i == null ? void 0 : i.dataset.id) === _.id;
    e.classList.toggle("on", s);
  });
}
function st(t) {
  if (H) {
    Ms(t);
    return;
  }
  const e = t.querySelector("#music-main");
  if (!e) return;
  if (Ct && at) {
    E(e, Hn());
    return;
  }
  if (!_) {
    E(e, `<div class="music-empty">${r != null && r.connected ? n("music.pick_hint") : n("music.playlists_login")}</div>`);
    return;
  }
  const i = _.cover ? `<img src="${l(_.cover)}" alt="">` : "", s = _.kind === "liked" ? n("music.liked_songs") : _.kind === "top-tracks" ? n("music.top_tracks") : _.kind === "playlist" ? n("music.playlists") : _.kind === "album" ? n("music.tab_albums") : _.kind === "artist" ? n("music.tab_artists") : _.kind === "new" ? n("music.tab_new") : _.kind === "top" ? n("music.tab_top") : n("music.tab_shows");
  let c;
  Xt ? c = `<div class="music-empty">${n("music.loading")}</div>` : Et ? c = `<div class="music-empty music-empty-err">${l(Et)}</div>` : !it || it.length === 0 ? c = `<div class="music-empty">${n("music.playlist_empty")}</div>` : c = it.map((a, f) => Je(a, f, "main-track", String(f))).join(""), E(e, `<div class="music-page">
    <div class="music-page-head">
      <span class="music-page-cover${_.kind === "artist" ? " round" : ""}">${i}</span>
      <div class="music-page-info">
        <span class="music-page-kind">${l(s)}</span>
        <span class="music-page-name">${l(_.name || "?")}</span>
        <span class="music-page-sub">${l(_.subtitle)}</span>
        <div class="music-page-actions">
          <button class="music-btn music-primary" data-act="main-play-all">${m.play} ${n("music.play_all")}</button>
        </div>
      </div>
    </div>
    <div class="music-list">${c}</div>
  </div>`);
}
function Hn() {
  const t = N, i = [
    ["tracks", n("music.tracks")],
    ["artists", n("music.tab_artists")],
    ["albums", n("music.tab_albums")],
    ["playlists", n("music.playlists")],
    ["shows", n("music.tab_shows")]
  ].map(([c, a]) => `<button class="music-tab${rt === c ? " on" : ""}" data-act="search-tab" data-tab="${c}">${l(a)}</button>`).join("");
  let s;
  if (ie || !t)
    s = `<div class="music-empty">${n("music.loading")}</div>`;
  else if (rt === "tracks")
    s = t.tracks.length ? t.tracks.map((c, a) => Je(c, a, "main-track", String(a))).join("") : `<div class="music-empty">${n("music.search_empty")}</div>`;
  else {
    const a = (rt === "artists" ? t.artists : rt === "albums" ? t.albums : rt === "shows" ? t.shows : t.playlists.map(Xe)).map((f) => Pn(rt === "playlists" ? "playlist" : rt === "artists" ? "artist" : rt === "albums" ? "album" : "show", f));
    s = a.length ? `<div class="music-grid">${a.join("")}</div>` : `<div class="music-empty">${n("music.search_empty")}</div>`;
  }
  return `<div class="music-page">
    <div class="music-page-info music-page-info-flat">
      <span class="music-page-kind">${n("music.search_result")}</span>
      <span class="music-page-name">${l(at)}</span>
    </div>
    <div class="music-tabs">${i}</div>
    <div class="music-list">${s}</div>
  </div>`;
}
function bt(t) {
  const e = t.querySelector("#music-search-dd");
  if (!e) return;
  const i = !!(r != null && r.connected) && nt && !!at;
  if (q(e, i), !i) return;
  if (!N) {
    E(e, ie ? `<div class="music-empty">${n("music.loading")}</div>` : "");
    return;
  }
  const s = N, c = [];
  s.tracks.slice(0, 3).forEach((a, f) => c.push(Je(a, f, "dd-track"))), s.artists.slice(0, 2).forEach((a) => c.push(Oe("artist", a))), s.albums.slice(0, 2).forEach((a) => c.push(Oe("album", a))), s.playlists.slice(0, 2).forEach((a) => c.push(Oe("playlist", Xe(a)))), c.length || c.push(`<div class="music-empty">${n("music.search_empty")}</div>`), c.push(`<button class="music-dd-all" data-act="search-all">${n("music.search_all")}</button>`), E(e, c.join(""));
}
function le(t) {
  const e = t.querySelector("#music-dev-dd");
  if (!e || (q(e, $t), !$t)) return;
  const i = P;
  let s = `<div class="music-dd-head">${n("music.devices")}</div>`;
  i != null && i.available && !i.has_credentials ? s += `<button class="music-dev-row" data-act="local-login">
      <span class="music-dev-ico">${m.power}</span>
      <span class="music-dev-main">
        <span class="music-dev-n">${n("music.local_login")}</span>
        <span class="music-dev-s">${n("music.local_login_hint")}</span>
      </span>
    </button>` : i != null && i.available ? s += `<button class="music-dev-row${i.running ? " on" : ""}" data-act="local-toggle">
      <span class="music-dev-ico">${m.power}</span>
      <span class="music-dev-main">
        <span class="music-dev-n">${n("music.local_play")}</span>
        <span class="music-dev-s">${l(i.path || "")}</span>
      </span>
    </button>` : s += `<div class="music-dev-row disabled">
      <span class="music-dev-ico">${m.power}</span>
      <span class="music-dev-main">
        <span class="music-dev-n">${n("music.local_play")}</span>
        <span class="music-dev-s">${n("music.local_no_exe")}</span>
      </span>
    </div>`;
  const c = Ut ?? [];
  s += c.length ? c.map((a) => `<button class="music-dev-row${a.active ? " on" : ""}" data-act="dev-pick" data-id="${l(a.id)}">
        <span class="music-dev-ico">${m.speaker}</span>
        <span class="music-dev-main">
          <span class="music-dev-n">${l(a.name || "?")}</span>
          <span class="music-dev-s">${l(a.kind)}</span>
        </span>
      </button>`).join("") : `<div class="music-empty">${n("music.device_none")}</div>`, E(e, s);
}
function Wn(t) {
  var s;
  const e = (d == null ? void 0 : d.context_uri) ?? "", i = ((s = d == null ? void 0 : d.track) == null ? void 0 : s.uri) ?? "";
  t.querySelectorAll(".music-pl").forEach((c) => {
    c.classList.toggle("playing", !!e && c.dataset.uri === e);
  }), t.querySelectorAll(".music-tr").forEach((c) => {
    c.classList.toggle("playing", !!i && c.dataset.uri === i);
  });
}
function Fn(t) {
  if (!t) return "";
  const e = new Date(t), i = (s) => String(s).padStart(2, "0");
  return `${e.getFullYear()}-${i(e.getMonth() + 1)}-${i(e.getDate())} ${i(e.getHours())}:${i(e.getMinutes())}`;
}
function qs(t) {
  ct && (mt = !1);
  const e = (i, s) => q(t.querySelector(i), s);
  e("#music-local-add", !ct), e("#music-local-list", !ct), e("#music-local-scan", !ct), e("#music-local-del", ct), e("#music-local-editdone", ct), me(t);
}
function me(t) {
  const e = t.querySelector("#music-local-add-dd");
  e && (q(e, mt), mt && E(e, `
    <div class="music-dd-head">${l(n("music.local_add_head"))}</div>
    <button class="music-dev-row" data-act="media-add-dir">
      <span class="music-dev-ico">${m.folder}</span>
      <span class="music-dev-main">
        <span class="music-dev-n">${l(n("music.local_add_dir"))}</span>
        <span class="music-dev-s">${l(n("music.local_add_dir_hint"))}</span>
      </span>
    </button>
    <button class="music-dev-row" data-act="media-add-list">
      <span class="music-dev-ico">${m.list}</span>
      <span class="music-dev-main">
        <span class="music-dev-n">${l(n("music.local_open_playlist"))}</span>
        <span class="music-dev-s">${l(n("music.local_add_list_hint"))}</span>
      </span>
    </button>`));
}
function Un(t) {
  const e = t.missing ? n("music.local_missing") : [
    n("music.local_n_tracks", { n: String(t.tracks) }),
    t.last_scan_at ? Fn(t.last_scan_at) : n("music.local_never_scanned")
  ].join(" · "), i = ct && pt.has(t.path);
  return `<div class="music-pl${lt === t.path ? " on" : ""}${t.missing ? " err" : ""}${i ? " sel" : ""}">
    <button class="music-pl-btn" data-act="media-root" data-path="${l(t.path)}" title="${l(t.path)}">
      <span class="music-pl-cover music-pl-dir">${m.folder}</span>
      <span class="music-pl-main">
        <span class="music-pl-name">${l(t.name || t.path)}</span>
        <span class="music-pl-sub">${l(e)}</span>
      </span>
    </button>
  </div>`;
}
function Rt(t) {
  q(t.querySelector("#music-side-tabs"), !1), q(t.querySelector("#music-local-head"), !0), qs(t);
  const e = t.querySelector("#music-side-list");
  if (!e) return;
  const i = (z ?? []).filter((a) => !xe.has(a.path)), s = i.reduce((a, f) => a + f.tracks, 0);
  let c = `<div class="music-pl${lt === "" ? " on" : ""}">
    <button class="music-pl-btn" data-act="media-root" data-path="" title="${l(n("music.local_all"))}">
      <span class="music-pl-cover music-pl-dir">${m.note}</span>
      <span class="music-pl-main">
        <span class="music-pl-name">${l(n("music.local_all"))}</span>
        <span class="music-pl-sub">${l(n("music.local_n_tracks", { n: String(s) }))}</span>
      </span>
    </button>
  </div>`;
  We ? c += `<div class="music-empty">${n("music.loading")}</div>` : ne ? c += `<div class="music-empty music-empty-err">${l(ne)}</div>` : z && i.length === 0 ? c += `<div class="music-empty">${l(n("music.local_no_roots"))}</div>` : z && (c += i.map((a) => Un(a)).join("")), E(e, c);
}
function Vn(t, e) {
  const i = t.cover ? `<img src="${l(Ve(t.cover))}" alt="">` : `<span class="music-mt-ico">${m.note}</span>`, s = [t.artist, t.album].filter(Boolean).join(" · ");
  return `<button class="music-mt${!!(y != null && y.active) && y.path === t.path ? " playing" : ""}" data-act="local-track" data-i="${e}" data-path="${l(t.path)}" title="${l(t.path)}">
    <span class="music-mt-i">${e + 1}</span>
    <span class="music-mt-cover">${i}</span>
    <span class="music-mt-main">
      <span class="music-mt-n">${l(t.title || "?")}</span>
      <span class="music-mt-a">${l(s)}</span>
    </span>
    <span class="music-mt-d">${$e(t.duration_ms)}</span>
  </button>`;
}
function Ms(t) {
  const e = t.querySelector("#music-main");
  if (!e) return;
  e.querySelector("#music-local-page") || (e.innerHTML = `<div class="music-local-page" id="music-local-page">
      <div class="music-local-head-row">
        <input class="music-local-q" id="music-mt-q" type="search" autocomplete="off" spellcheck="false"
               placeholder="${l(n("music.local_filter_ph"))}" value="${l(Ee)}">
        <span class="music-list-chip hidden" id="music-list-chip">
          <span class="music-list-chip-n" id="music-list-chip-n"></span>
          <button class="music-pl-x" data-act="media-list-close" title="${l(n("music.local_close_playlist"))}">${m.x}</button>
        </span>
        <!-- 重扫（2026-10-01 用户口径）：**只留图标**，「重扫」那两个可见字去掉 ——
             它右边紧挨着设置齿轮（见 placeGear），带文字那一行会挤。
             title 仍然留着（鼠标悬浮还能问出这是什么）；去掉的是**可见文字**。
             ⚠️ 本行属于**动态骨架**（#music-main 会被 renderMain 整块重写、回来时重建），
             所以它只能走 data-act 委托，直接 addEventListener 会在下次重建时失效。 -->
        <button class="music-ghost-btn music-icon-btn" data-act="media-scan" title="${l(n("music.local_rescan"))}">${m.refresh}</button>
      </div>
      <div class="music-scan hidden" id="music-scan"></div>
      <!-- 视频的**画面层**（2026-10-01 用户第 8 条）。里面那个 video 元素由
           renderLocalVideo 现造现拆（离开 / 换曲时整块清掉，见那里的注释）。
           注：本段在模板字符串里，注释里一个反引号都不能出现（预检 #15 / #39 ⑩）。 -->
      <div class="music-video hidden" id="music-video"></div>
      <div class="music-list" id="music-mt-list"></div>
    </div>`), q(t.querySelector("#music-mt-q"), !et);
  const i = t.querySelector("#music-list-chip");
  q(i, !!et), et && g(
    t.querySelector("#music-list-chip-n"),
    `${et.name} · ${n("music.local_n_tracks", { n: String((O == null ? void 0 : O.total) ?? 0) })}`
  ), zn(t), Ts(t), Gn(t), Es(t);
}
function zn(t) {
  const e = t.querySelector("#music-scan");
  if (!e) return;
  const i = Kt;
  let s = "";
  if (i != null && i.running) {
    const c = i.total, a = c > 0 ? Math.min(100, Math.round(i.scanned / c * 100)) : 0, f = c > 0 ? n("music.local_scanning", { a: String(i.scanned), b: String(c) }) : n("music.local_scanning_n", { a: String(i.scanned) });
    s = `<div class="music-scan-row">
      <span class="music-scan-bar"><span class="music-scan-fill" style="width:${a}%"></span></span>
      <span class="music-scan-txt">${l(f)}</span>
    </div>`;
  } else i != null && i.error ? s = `<div class="music-scan-row music-scan-err">${l(i.error)}</div>` : i != null && i.done_at && (s = `<div class="music-scan-row music-scan-done">${l(n("music.local_scan_done", {
    added: String(i.added),
    updated: String(i.updated),
    removed: String(i.removed),
    failed: String(i.failed)
  }))}</div>`);
  E(e, s), q(e, !!s);
}
function Gn(t) {
  const e = t.querySelector("#music-mt-list");
  if (!e) return;
  let i;
  ce ? i = `<div class="music-empty">${n("music.loading")}</div>` : It ? i = `<div class="music-empty music-empty-err">${l(It)}</div>` : !et && z && z.length === 0 ? i = `<div class="music-empty">${l(n("music.local_add_hint"))}</div>` : !O || O.items.length === 0 ? i = `<div class="music-empty">${l(n(et ? "music.local_list_empty" : "music.local_empty"))}</div>` : (i = O.items.map((s, c) => Vn(s, c)).join(""), O.total > O.items.length && (i += `<div class="music-empty">${l(n("music.local_more", {
    a: String(O.items.length),
    b: String(O.total)
  }))}</div>`)), E(e, i);
}
function Ts(t) {
  const e = t.querySelector("#music-video");
  if (!e) return;
  const i = y, s = !!i && i.video && i.path !== "";
  if (q(e, s), !s) {
    e.firstChild && (e.innerHTML = "");
    return;
  }
  const c = Ve(i.path);
  let a = e.querySelector(".music-video-el");
  if (!a || a.dataset.src !== c) {
    if (e.innerHTML = '<video class="music-video-el" muted playsinline preload="auto"></video>', a = e.querySelector(".music-video-el"), !a) return;
    a.dataset.src = c, a.src = c, a.addEventListener("loadedmetadata", () => ls(a, i), { once: !0 }), a.addEventListener("error", () => {
      g(t.querySelector("#music-msg"), n("music.video_unsupported"));
    });
  }
  ls(a, i);
}
function ls(t, e) {
  e.playing ? t.paused && t.play().catch(() => {
  }) : t.paused || t.pause();
  const i = e.playing ? Date.now() - Le : 0, s = (e.position_ms + Math.max(0, i)) / 1e3;
  t.readyState >= 1 && !t.seeking && Math.abs(t.currentTime - s) > pn && (t.currentTime = s);
}
function Cs(t) {
  if (L !== "lplayer") return;
  const e = t.querySelector("#music-v-lplayer"), i = y;
  if (!e || !i || !i.path) return;
  const s = Lt[ft], c = (s == null ? void 0 : s.title) || i.path.split(/[\\/]/).pop() || i.path;
  g(e.querySelector("#music-lp-title"), c), g(e.querySelector("#music-lp-sub"), s ? [s.artist, s.album].filter(Boolean).join(" · ") : ""), E(
    e.querySelector("#music-lp-cover"),
    s != null && s.cover ? `<img src="${l(Ve(s.cover))}" alt="">` : m.note
  ), E(e.querySelector("#music-lp-play"), i.active && i.playing ? m.pause : m.play);
  const a = e.querySelector("#music-lp-mode");
  a && (yt(a, "data-mode", j), yt(a, "title", mi()), E(a, j === "repeat_all" || j === "repeat_one" ? m.repeat : m.shuffle));
  const f = i.duration_ms, k = V >= 0 ? V : f > 0 ? Math.min(1, i.position_ms / f) : 0, T = e.querySelector("#music-lp-progress");
  T && V < 0 && T.style.setProperty("--seek-pct", `${k * 100}%`), g(e.querySelector("#music-lp-time"), f > 0 ? `${D(i.position_ms)} / ${D(f)}` : D(i.position_ms));
  const A = e.querySelector("#music-lp-vol");
  A && document.activeElement !== A && (A.value = String(Math.round(i.volume * 100)), Zt(A, i.volume * 100));
}
function qt(t) {
  Ts(t), Cs(t);
  const e = t.querySelector("#music-lnowbar");
  if (!e) return;
  const i = y, s = (H || kt) && !!i && i.path !== "";
  if (q(e, s), !s || !i) return;
  const c = Lt[ft], a = (c == null ? void 0 : c.title) || i.path.split(/[\\/]/).pop() || i.path;
  g(e.querySelector("#music-lnow-n"), a), g(e.querySelector("#music-lnow-a"), c ? [c.artist, c.album].filter(Boolean).join(" · ") : ""), E(
    e.querySelector("#music-lnow-cover"),
    c != null && c.cover ? `<img src="${l(Ve(c.cover))}" alt="">` : m.note
  ), E(e.querySelector("#music-l-play"), i.active && i.playing ? m.pause : m.play);
  const f = e.querySelector("#music-l-mode");
  f && (yt(f, "data-mode", j), yt(f, "title", mi()), E(f, j === "repeat_all" || j === "repeat_one" ? m.repeat : m.shuffle));
  const k = i.duration_ms, T = V >= 0 ? V : k > 0 ? Math.min(1, i.position_ms / k) : 0, A = e.querySelector("#music-lbp");
  A && V < 0 && A.style.setProperty("--seek-pct", `${T * 100}%`), g(e.querySelector("#music-l-time"), k > 0 ? `${D(i.position_ms)} / ${D(k)}` : D(i.position_ms));
  const w = e.querySelector("#music-l-vol");
  w && document.activeElement !== w && (w.value = String(Math.round(i.volume * 100)), Zt(w, i.volume * 100));
}
function fi(t) {
  const e = y != null && y.active ? y.path : "";
  t.querySelectorAll(".music-mt").forEach((i) => {
    i.classList.toggle("playing", !!e && i.dataset.path === e);
  });
}
function ht(t) {
  H && (Rt(t), Ms(t), qt(t));
}
async function Is(t) {
  We = !0, ne = "", ht(t);
  try {
    z = await p("media_roots");
  } catch (e) {
    ne = String(e);
  } finally {
    We = !1, ht(t);
  }
}
async function ue(t) {
  et = null, ce = !0, It = "", ht(t);
  try {
    O = await p("media_tracks", {
      // 空串 ⇒ 传 null（宿主的 `Option<String>` 收 None = 全库 / 不筛选）
      root: lt || null,
      query: Ee || null,
      limit: on
    });
  } catch (e) {
    It = String(e);
  } finally {
    ce = !1, ht(t);
  }
}
function te() {
  he !== void 0 && (window.clearInterval(he), he = void 0);
}
function Rs(t) {
  he === void 0 && (he = window.setInterval(() => {
    (async () => {
      if (!t.isConnected) {
        te();
        return;
      }
      try {
        const e = await p("media_scan_status");
        Kt = e, e.running || (te(), await Is(t), await ue(t));
      } catch {
        te();
      }
      ht(t);
    })();
  }, rn));
}
async function oi(t, e) {
  try {
    Kt = await p("media_scan_start", { root: e || null });
  } catch (i) {
    const s = String(i);
    x(t, s.includes("ERR_SCAN_RUNNING") ? n("music.local_scan_busy") : s);
    return;
  }
  ht(t), Rs(t);
}
async function Qn(t) {
  let e = null;
  try {
    e = await ys({ directory: !0, multiple: !1, title: n("music.local_add_dir") });
  } catch (i) {
    x(t, String(i));
    return;
  }
  if (!(typeof e != "string" || !e)) {
    try {
      z = await p("media_add_root", { path: e });
    } catch (i) {
      x(t, String(i));
      return;
    }
    lt = Yn(e), ht(t), await oi(t, lt || e);
  }
}
function Yn(t) {
  var s;
  const e = (c) => c.replace(/[\\/]+$/, "").toLowerCase(), i = e(t);
  return ((s = z == null ? void 0 : z.find((c) => e(c.path) === i)) == null ? void 0 : s.path) ?? "";
}
function Jn(t) {
  ct = !0, pt.clear(), Rt(t);
}
function Xn(t) {
  if (pt.size) {
    for (const e of pt) xe.add(e);
    pt.clear(), Rt(t);
  }
}
async function Kn(t) {
  const e = Array.from(xe);
  if (ct = !1, pt.clear(), xe.clear(), qs(t), !e.length) {
    Rt(t);
    return;
  }
  let i = "";
  for (const s of e)
    try {
      z = await p("media_remove_root", { path: s });
    } catch (c) {
      const a = String(c);
      i = a.includes("ERR_SCAN_RUNNING") ? n("music.local_remove_busy") : a;
    }
  lt && !(z ?? []).some((s) => s.path === lt) && (lt = ""), Rt(t), await ue(t), i && x(t, i);
}
function Zn(t) {
  const e = t instanceof Error ? t.message : String(t);
  return e.includes("ERR_NOT_PLAYLIST") ? n("music.local_not_playlist") : e;
}
async function tc(t) {
  let e = null;
  try {
    e = await ys({
      multiple: !1,
      title: n("music.local_open_playlist"),
      filters: [{ name: "Playlist", extensions: ["m3u", "m3u8", "pls"] }]
    });
  } catch (i) {
    x(t, String(i));
    return;
  }
  if (!(typeof e != "string" || !e)) {
    ce = !0, It = "", O = null, ht(t);
    try {
      O = await p("media_playlist", { path: e }), et = { path: e, name: e.split(/[\\/]/).pop() || e }, lt = "";
    } catch (i) {
      et = null, It = Zn(i);
    } finally {
      ce = !1, ht(t);
    }
  }
}
function ec(t) {
  et = null, ue(t);
}
function As(t) {
  const e = t instanceof Error ? t.message : String(t);
  return e.includes("ERR_NO_AUDIO_DEVICE") ? n("music.local_no_device") : e.includes("找不到这个文件") ? n("music.local_file_missing") : e.includes("解不开") || e.includes("打不开") ? n("music.local_decode_failed") : e;
}
async function Fe(t, e) {
  if (!Ot) {
    await qe(t, "local"), Ot = !0;
    try {
      y = await p("player_play", { path: e });
    } catch (i) {
      x(t, As(i)), Ot = !1;
      return;
    }
    Ot = !1, Le = Date.now(), qt(t), fi(t), Ns(t);
  }
}
async function ic(t, e) {
  const i = (O == null ? void 0 : O.items) ?? [], s = i[e];
  s && (Lt = i.slice(), ft = e, await Fe(t, s.path));
}
async function pe(t, e, i) {
  var a;
  const s = Lt.length;
  if (s === 0) return;
  if (i && j === "repeat_one") {
    await Fe(t, ((a = Lt[ft]) == null ? void 0 : a.path) ?? "");
    return;
  }
  let c;
  if (j === "shuffle" && s > 1)
    do
      c = Math.floor(Math.random() * s);
    while (c === ft);
  else
    c = ft + e;
  if (j === "repeat_all" || j === "shuffle")
    c = (c % s + s) % s;
  else if (c < 0 || c >= s) {
    i || x(t, n("music.local_queue_end"));
    return;
  }
  ft = c, await Fe(t, Lt[c].path);
}
async function us(t) {
  const e = y;
  if (!(!e || e.path === "") && !Ot) {
    if (!e.active) {
      await Fe(t, e.path);
      return;
    }
    try {
      y = await p(e.playing ? "player_pause" : "player_resume");
    } catch (i) {
      x(t, As(i));
      return;
    }
    Le = Date.now(), qt(t), y != null && y.active && Ns(t);
  }
}
async function fe(t) {
  ee(), Lt = [], ft = -1, V = -1, y = null, Le = 0;
  const e = L === "lplayer";
  e && (L = "default"), qt(t), fi(t), e && Q(t);
  try {
    await p("player_stop");
  } catch {
  }
}
async function qe(t, e) {
  if (!kt) {
    if (e === "local") {
      if (r != null && r.connected && (d != null && d.playing))
        try {
          await p("spotify_control", { action: "pause" });
        } catch {
        }
      return;
    }
    y && await fe(t);
  }
}
async function sc(t, e) {
  try {
    y = await p("player_seek", { positionMs: e });
  } catch {
    return;
  }
  qt(t);
}
async function os(t, e) {
  try {
    y = await p("player_volume", { volume: e });
  } catch {
    return;
  }
  qt(t);
}
function ee() {
  ge !== void 0 && (window.clearInterval(ge), ge = void 0);
}
function Ns(t) {
  ge === void 0 && (ge = window.setInterval(() => {
    (async () => {
      if (!t.isConnected) {
        ee();
        return;
      }
      if (V >= 0 || Ot) return;
      let e;
      try {
        e = await p("player_status");
      } catch {
        return;
      }
      if (!t.isConnected) {
        ee();
        return;
      }
      const i = !e.active && e.path !== "" && e.path === (y == null ? void 0 : y.path);
      y = e, Le = Date.now(), qt(t), fi(t), i && (ee(), await pe(t, 1, !0));
    })();
  }, mn));
}
function nc(t, e) {
  Ee = e, J !== void 0 && window.clearTimeout(J), J = window.setTimeout(() => {
    J = void 0, ue(t);
  }, dn);
}
function rs(t) {
  be = Math.min(gs, Math.max(hs, Math.round(be))), t.style.setProperty("--music-side-w", `${be}px`);
}
function Ds(t, e) {
  var s;
  if (t === "liked")
    return { id: "liked", uri: "", name: n("music.liked_songs"), cover: "", subtitle: "", total: (B == null ? void 0 : B.total) ?? 0 };
  if (t === "top-tracks")
    return {
      id: "top-tracks",
      uri: "",
      name: n("music.top_tracks"),
      cover: "",
      subtitle: n("music.top_tracks_sub"),
      total: 0
    };
  const i = t === "artist" ? N == null ? void 0 : N.artists : t === "album" ? N == null ? void 0 : N.albums : t === "show" ? N == null ? void 0 : N.shows : N == null ? void 0 : N.playlists.map(Xe);
  return ((s = se.get(t)) == null ? void 0 : s.find((c) => c.id === e)) ?? (i == null ? void 0 : i.find((c) => c.id === e)) ?? null;
}
async function Bs(t, e) {
  if (!(!(r != null && r.connected) || ve.has(e) || se.has(e))) {
    ve.add(e), Se.delete(e), Vt(t);
    try {
      const i = e === "playlist" ? (ai = await p("spotify_playlists")).map(Xe) : await p(Ks[e]);
      se.set(e, i);
    } catch (i) {
      Se.set(e, M(i));
    } finally {
      ve.delete(e), Vt(t);
    }
  }
}
async function cc(t, e, i) {
  const s = Ds(e, i);
  if (s) {
    if (Ct = !1, nt = !1, _ = { kind: e, id: s.id, uri: s.uri, name: s.name, cover: s.cover, subtitle: s.subtitle }, it = null, Et = "", e === "liked") {
      it = (B == null ? void 0 : B.items) ?? null, Et = Wt, Xt = !B, bt(t), ii(t), st(t), B || await Os(t);
      return;
    }
    Xt = !0, bt(t), ii(t), st(t);
    try {
      it = e === "top-tracks" ? await p("spotify_top_tracks") : await p("spotify_item_tracks", { kind: Xs(e), id: s.id });
    } catch (c) {
      Et = M(c);
    } finally {
      Xt = !1, ii(t), st(t);
    }
  }
}
async function ds(t, e, i, s = 0) {
  const c = Ds(e, i);
  if (c) {
    await qe(t, "spotify");
    try {
      if (e === "liked" || e === "show" || e === "top-tracks") {
        const a = (e === "liked" ? B == null ? void 0 : B.items : it) ?? [];
        if (!a.length) return;
        await p("spotify_play_uris", { uris: a.slice(Math.max(0, s)).map((f) => f.uri), deviceId: ot || void 0 });
      } else if (c.uri)
        await p("spotify_play_context", { contextUri: c.uri, offsetUri: "", deviceId: ot || void 0 });
      else
        return;
    } catch (a) {
      x(t, M(a));
    }
  }
}
async function ac(t, e) {
  if (!_) return;
  const i = it ?? [], s = i[e];
  if (s) {
    await qe(t, "spotify");
    try {
      _.kind === "liked" || _.kind === "show" ? await p("spotify_play_uris", { uris: i.slice(e).map((c) => c.uri), deviceId: ot || void 0 }) : await p("spotify_play_context", { contextUri: _.uri, offsetUri: s.uri, deviceId: ot || void 0 });
    } catch (c) {
      x(t, M(c));
    }
  }
}
async function ri(t) {
  if (!(r != null && r.connected)) return;
  const e = !!(P != null && P.running), i = window.setTimeout(() => x(t, n("music.auto_starting")), 600);
  try {
    const s = await p("music_autoconfigure", { allowLocal: !He });
    ot = s.device_id || "", s.source === "needs_login" ? x(t, n("music.auto_need_login")) : s.source === "local" && !s.device_id ? x(t, n("music.auto_local_unregistered")) : s.started_local && !e ? x(t, n("music.auto_local_started")) : s.source === "start_failed" ? x(t, n("music.auto_start_failed")) : s.source === "none" && !He && x(t, n("music.auto_none"));
  } catch (s) {
    ot = "", String(s) !== "ERR_NOT_CONNECTED" && x(t, M(s));
  } finally {
    window.clearTimeout(i);
  }
  await Me(t);
}
async function Me(t) {
  try {
    Ut = await p("spotify_devices");
  } catch (e) {
    Ut = [], x(t, M(e));
  }
  try {
    P = await p("librespot_status");
  } catch {
    P = null;
  }
  le(t);
}
async function lc(t) {
  if (!(P != null && P.available)) return;
  const e = P.running;
  try {
    P = await p(e ? "librespot_stop" : "librespot_start");
  } catch (i) {
    x(t, M(i));
    return;
  }
  if (He = e, le(t), e) {
    ot = "", await ri(t);
    return;
  }
  for (let i = 0; i < 6; i++) {
    await new Promise((s) => window.setTimeout(s, 1500));
    try {
      const s = await p("spotify_devices");
      Ut = s;
      const c = s.find((a) => a.name === "Lunac");
      if (c && !c.active && await p("spotify_transfer", { deviceId: c.id, play: !0 }), c) {
        ot = c.id;
        break;
      }
    } catch {
    }
  }
  await Me(t);
}
async function uc(t) {
  try {
    P = await p("librespot_login");
  } catch (e) {
    x(t, M(e));
    return;
  }
  He = !1, le(t), x(t, n("music.local_login_started"));
  for (let e = 0; e < 60; e++) {
    if (await new Promise((s) => window.setTimeout(s, 2e3)), !t.isConnected) return;
    let i;
    try {
      i = await p("librespot_status");
    } catch {
      continue;
    }
    if (P = i, !!i.has_credentials) {
      i.running || (P = await p("librespot_start").catch(() => i));
      for (let s = 0; s < 8; s++) {
        if (await new Promise((f) => window.setTimeout(f, 1500)), !t.isConnected) return;
        const c = await p("spotify_devices").catch(() => []);
        Ut = c;
        const a = c.find((f) => f.name === "Lunac");
        if (a) {
          a.active || await p("spotify_transfer", { deviceId: a.id, play: !1 }), ot = a.id;
          break;
        }
      }
      x(t, n("music.local_login_ok"));
      break;
    }
  }
  await Me(t);
}
async function oc(t, e) {
  if (e) {
    try {
      await p("spotify_transfer", { deviceId: e, play: !1 }), $t = !1;
    } catch (i) {
      x(t, M(i));
    }
    await Me(t);
  }
}
async function Os(t) {
  if (!(!(r != null && r.connected) || ei || B)) {
    ei = !0, Wt = "", Vt(t);
    try {
      B = await p("spotify_liked");
    } catch (e) {
      Wt = M(e);
    } finally {
      ei = !1, (_ == null ? void 0 : _.kind) === "liked" && (it = (B == null ? void 0 : B.items) ?? null, Xt = !1, Et = Wt), Vt(t), st(t);
    }
  }
}
function ms(t, e) {
  if (at = e, nt = !!e, de !== void 0 && (window.clearTimeout(de), de = void 0), !e) {
    N = null, ie = !1, Ct = !1, bt(t), st(t);
    return;
  }
  ie = !0, bt(t), st(t), de = window.setTimeout(() => void rc(t, e), cn);
}
async function rc(t, e) {
  de = void 0;
  try {
    const i = await p("spotify_search", { query: e });
    if (at !== e) return;
    N = i;
  } catch (i) {
    if (at !== e) return;
    N = null, x(t, M(i));
  } finally {
    at === e && (ie = !1, bt(t), st(t));
  }
}
function Pe(t) {
  const e = (Bt == null ? void 0 : Bt.items) ?? [], i = n("music.play_from_here"), s = e.length === 0 ? `<div class="music-empty">${n(Bt ? "music.queue_empty" : "music.loading")}</div>` : e.map((c, a) => Je(c, a, "play-uri", "", i)).join("");
  for (const c of ["#music-q", "#music-q-dd"]) E(t.querySelector(c), s);
}
async function Ps(t) {
  var e;
  try {
    Bt = await p("spotify_queue"), _s = ((e = d == null ? void 0 : d.track) == null ? void 0 : e.id) ?? "";
  } catch (i) {
    Bt = null, g(t.querySelector("#music-msg"), M(i));
  }
  Pe(t);
}
function di(t) {
  const e = (d == null ? void 0 : d.track) ?? null, i = e != null && e.cover ? `<img src="${l(e.cover)}" alt="">` : "", s = [e == null ? void 0 : e.artists, e == null ? void 0 : e.album].filter(Boolean).join(" · ") || (d != null && d.active ? "" : n("music.no_device_hint"));
  E(t.querySelector("#music-pv-cover"), i), E(t.querySelector("#music-bnow-cover"), i), g(t.querySelector("#music-pv-title"), (e == null ? void 0 : e.name) || n("music.no_track")), g(t.querySelector("#music-bnow-n"), (e == null ? void 0 : e.name) || n("music.no_track")), g(t.querySelector("#music-pv-sub"), s), g(t.querySelector("#music-bnow-a"), s);
  const c = (e == null ? void 0 : e.duration_ms) ?? 0, a = Math.min((d == null ? void 0 : d.progress_ms) ?? 0, c || Number.MAX_SAFE_INTEGER), f = c > 0 ? Math.max(0, Math.min(100, a / c * 100)) : 0;
  if (ks = a, Ss = Date.now(), Nt < 0)
    for (const C of jt) C.style.setProperty("--seek-pct", `${f}%`);
  g(t.querySelector("#music-pv-pos"), D(a)), g(t.querySelector("#music-pv-dur"), D(c)), g(t.querySelector("#music-b-time"), `${D(a)} / ${D(c)}`);
  const k = d != null && d.playing ? m.pause : m.play;
  E(t.querySelector("#music-play"), k), E(t.querySelector("#music-b-play"), k);
  const T = js(), A = n(T === "shuffle" ? "music.mode_shuffle" : T === "repeat_one" ? "music.mode_repeat_one" : "music.mode_off");
  for (const C of [t.querySelector("#music-mode"), t.querySelector("#music-b-mode")])
    C && (yt(C, "data-mode", T), yt(C, "title", A), E(C, T === "repeat_one" ? m.repeat : m.shuffle));
  const w = d && d.volume_percent >= 0 ? d.volume_percent : -1;
  for (const C of [t.querySelector("#music-vol"), t.querySelector("#music-b-vol")])
    C && w >= 0 && document.activeElement !== C && (C.value = String(w), Zt(C, w));
  const G = !(d != null && d.active);
  t.querySelectorAll("#music-v-player .music-bar button, #music-nowbar button").forEach((C) => {
    C.id === "music-devices-btn" || C.id === "music-open-player" || C.id === "music-bnow" || (C.disabled = G);
  });
}
function dc(t) {
  var c;
  if (!t.isConnected || !(d != null && d.playing) || Nt >= 0) return;
  const e = ((c = d.track) == null ? void 0 : c.duration_ms) ?? 0;
  if (e <= 0) return;
  const i = Math.min(ks + (Date.now() - Ss), e), s = Math.max(0, Math.min(100, i / e * 100));
  for (const a of jt) a.style.setProperty("--seek-pct", `${s}%`);
  g(t.querySelector("#music-pv-pos"), D(i)), g(t.querySelector("#music-b-time"), `${D(i)} / ${D(e)}`);
}
function js() {
  return (d == null ? void 0 : d.repeat) === "track" ? "repeat_one" : d != null && d.shuffle ? "shuffle" : "off";
}
function si(t) {
  var e, i;
  q(t.querySelector("#music-q-wrap"), tt), q(t.querySelector("#music-q-dd"), tt), (e = t.querySelector("#music-queue-btn")) == null || e.classList.toggle("on", tt), (i = t.querySelector("#music-b-queue")) == null || i.classList.toggle("on", tt);
}
function Ue(t) {
  const e = t.querySelector("#music-lyr");
  if (!e) return;
  if (vi(), Dt = -1, Jt = [], ae && (ae = !1, vt !== void 0 && (window.clearTimeout(vt), vt = void 0)), ci) {
    E(e, `<div class="music-empty">${n("music.lyrics_loading")}</div>`);
    return;
  }
  if (U != null && U.synced) {
    const s = gn(U.synced);
    if (s.length > 0) {
      Jt = s;
      const c = l(n("music.seek_line"));
      E(
        e,
        `<div class="music-lyr-lines">${s.map((a, f) => `<div class="music-lyr-line" data-i="${f}" title="${c}">${l(a.text)}</div>`).join("")}</div>`
      );
      return;
    }
  }
  const i = ((U == null ? void 0 : U.plain) || "").trim();
  if (i) {
    E(e, `<div class="music-lyr-plain">${l(i)}</div>`);
    return;
  }
  if (U != null && U.instrumental) {
    E(e, `<div class="music-empty">${n("music.lyrics_instrumental")}</div>`);
    return;
  }
  E(e, `<div class="music-empty">${n("music.lyrics_none")}</div>`);
}
function vi() {
  we && (cancelAnimationFrame(we), we = 0);
}
function ps(t, e) {
  vi();
  const i = t.scrollTop, s = e - i;
  if (Math.abs(s) < 1) {
    t.scrollTop = e;
    return;
  }
  let c = 0;
  const a = (f) => {
    c || (c = f);
    const k = Math.min(1, (f - c) / an);
    t.scrollTop = i + s * (1 - Math.pow(1 - k, 5)), we = k < 1 ? requestAnimationFrame(a) : 0;
  };
  we = requestAnimationFrame(a);
}
function Ke(t) {
  var T, A;
  if (Jt.length === 0) return;
  const e = t.querySelector("#music-lyr");
  if (!e || !e.isConnected || e.clientHeight === 0) return;
  const i = ((d == null ? void 0 : d.progress_ms) ?? 0) / 1e3;
  let s = -1;
  for (let w = 0; w < Jt.length && Jt[w].at <= i; w++)
    s = w;
  if (s === Dt) return;
  const c = Math.min(Dt, s), a = Math.max(Dt, s);
  for (let w = Math.max(0, c + 1); w <= a; w++)
    (T = e.querySelector(`.music-lyr-line[data-i="${w}"]`)) == null || T.classList.toggle("done", w <= s);
  (A = e.querySelector(".music-lyr-line.on")) == null || A.classList.remove("on"), Dt = s;
  const f = e.querySelector(`.music-lyr-line[data-i="${s}"]`);
  if (!f) {
    ae || ps(e, 0);
    return;
  }
  if (f.classList.add("on"), ae) return;
  const k = f.getBoundingClientRect().top - e.getBoundingClientRect().top + e.scrollTop;
  ps(e, Math.max(0, k));
}
function fs(t) {
  ae = !0, vi(), vt !== void 0 && window.clearTimeout(vt), vt = window.setTimeout(() => {
    vt = void 0, ae = !1, Dt = -1, Ke(t);
  }, nn);
}
async function je(t) {
  try {
    r = await p("music_config_get");
  } catch (e) {
    g(t.querySelector("#music-msg"), M(e));
    return;
  }
  !r.connected && L === "player" && (L = "default", Q(t)), Gt(t), Yt(t);
}
async function mc(t) {
  if (ni === t.id) return;
  ni = t.id, ci = !0, U = null;
  const e = xs;
  e && Ue(e);
  try {
    U = await p("lyrics_get", {
      title: t.name,
      artist: t.artists,
      album: t.album,
      duration: t.duration_ms / 1e3
    });
  } catch (i) {
    U = { found: !1, instrumental: !1, track: "", artist: "", album: "", duration: 0, synced: null, plain: null }, e && g(e.querySelector("#music-msg"), M(i));
  } finally {
    ci = !1, e && (Ue(e), Ke(e));
  }
}
async function Hs(t, e) {
  if (e === Qt) {
    if (!t.isConnected) {
      bi();
      return;
    }
    if (wn(t), r != null && r.connected) {
      if (!document.hidden && !Ae) {
        Ae = !0;
        try {
          if (d = await p("spotify_status"), e !== Qt) return;
          Yt(t), di(t), Ke(t), Wn(t), pi(t), ke(t);
        } catch (i) {
          if (e !== Qt) return;
          String(i).includes("ERR_NOT_CONNECTED") ? await je(t) : g(t.querySelector("#music-msg"), M(i));
        } finally {
          Ae = !1;
        }
      }
      d != null && d.track && mc(d.track), tt && (d != null && d.track) && d.track.id !== _s && Ps(t);
    }
    e === Qt && (_e = window.setTimeout(() => void Hs(t, e), 1e3));
  }
}
function bi() {
  _e !== void 0 && (window.clearTimeout(_e), _e = void 0), Ne !== void 0 && (window.clearInterval(Ne), Ne = void 0), Qt++, Ae = !1;
}
function vs(t) {
  bi();
  const e = Qt;
  _e = window.setTimeout(() => void Hs(t, e), 200), Ne = window.setInterval(() => dc(t), un);
}
function ke(t) {
  document.getElementById("plugin-titlebar") && (Ft !== void 0 && window.clearTimeout(Ft), Ft = window.setTimeout(() => void pc(t), 80));
}
async function pc(t) {
  if (Ft = void 0, !document.getElementById("plugin-titlebar")) return;
  let e = Zs, i = tn;
  if (Ge()) {
    const c = t.closest(".plugin-result"), a = c == null ? void 0 : c.closest("#results-list");
    if (!c || !a) return;
    const f = getComputedStyle(a), k = parseFloat(f.paddingTop || "0") + parseFloat(f.paddingBottom || "0"), T = window.innerHeight - a.clientHeight;
    i = Math.round(T + k + c.getBoundingClientRect().height), e = en;
  }
  const s = `${e}x${i}`;
  if (s !== ui)
    try {
      await p("plugin_window_resize", { width: e, height: i }), ui = s;
    } catch {
    }
}
async function vc(t) {
  var hi, gi, _i, wi, $i, ki, Si, xi, Ei, Li, qi, Mi, Ti, Ci, Ii, Ri, Ai, Ni, Di, Bi, Oi, Pi, ji, Hi, Wi, Fi, Ui, Vi, zi, Gi, Qi, Yi, Ji, Xi, Ki, Zi, ts, es, is, ss;
  const e = t.querySelector(".music-root");
  if (!e) return;
  xs = e, L = "default", Ie = null, Re = !1, re = null, tt = !1, ui = "", li = null, De = "", Be = 0, B = null, Wt = "", ai = null, se.clear(), ve.clear(), Se.clear(), Y = "playlist", _ = null, it = null, Xt = !1, Et = "", Ut = null, $t = !1, P = null, ot = "", at = "", N = null, ie = !1, nt = !1, Ct = !1, rt = "tracks", jt = [], H = !1, z = null, We = !1, ne = "", lt = "", ct = !1, pt.clear(), xe.clear(), mt = !1, O = null, ce = !1, It = "", et = null, Ee = "", Kt = null, te(), J !== void 0 && (window.clearTimeout(J), J = void 0), y = null, Lt = [], ft = -1, Ot = !1, V = -1, ee();
  const i = (u) => g(e.querySelector("#music-msg"), u), s = (u) => e.querySelector(u);
  Pt && (Pt(), Pt = null), Pt = await Qs("spotify-auth", (u) => {
    e.isConnected && (u.payload.ok ? (i(n("music.auth_ok")), je(e).then(() => {
      vs(e), ri(e);
    })) : i(u.payload.message || n("music.auth_failed")));
  });
  const c = () => {
    L = "player", Q(e);
  }, a = () => {
    L = "default", Q(e);
  }, f = () => {
    L = "settings", Q(e);
  };
  (hi = s("#music-setup-toggle")) == null || hi.addEventListener("click", f), (gi = s("#music-set-back")) == null || gi.addEventListener("click", a), (_i = s("#music-tune-back")) == null || _i.addEventListener("click", a), (wi = s("#music-tuning-on")) == null || wi.addEventListener("click", (u) => {
    const o = u.target.closest(".music-seg-btn");
    o && Nn(e, o.dataset.on === "1");
  }), ($i = s("#music-tuning-preset")) == null || $i.addEventListener("click", (u) => {
    const o = u.target.closest(".music-seg-btn"), v = o == null ? void 0 : o.dataset.preset;
    v && Dn(e, v);
  });
  const k = () => s("#music-tuning-filters");
  (ki = k()) == null || ki.addEventListener("click", (u) => {
    const o = u.target.closest("[data-act]"), v = o == null ? void 0 : o.closest(".music-tune-row"), $ = Number(v == null ? void 0 : v.dataset.i), b = St[$];
    if (!o || !v || !b) return;
    const h = o.dataset.act;
    if (h === "on")
      b.on = !b.on, zt(e);
    else if (h === "del")
      St.splice($, 1), dt === $ ? dt = -1 : dt > $ && (dt -= 1), zt(e);
    else if (h === "kind")
      dt = dt === $ ? -1 : $, Ls(e);
    else if (h === "pick") {
      const R = o.dataset.kind;
      if (!R) return;
      An(b, R, (I == null ? void 0 : I.kinds) ?? []), dt = -1, zt(e);
    }
  }), (Si = k()) == null || Si.addEventListener("change", (u) => {
    var R;
    const o = u.target, v = (R = o == null ? void 0 : o.dataset) == null ? void 0 : R.f;
    if (!v) return;
    const $ = o.closest(".music-tune-row"), b = St[Number($ == null ? void 0 : $.dataset.i)];
    if (!b) return;
    const h = Number.parseFloat(o.value.trim());
    if (!Number.isFinite(h)) {
      o.value = Cn(b, v);
      return;
    }
    if (v === "freq_hz") {
      if (h === b.freq_hz) return;
      b.freq_hz = h;
    } else if (v === "gain_db") {
      if (h === b.gain_db) return;
      b.gain_db = h;
    } else if (v === "q") {
      if (h === b.q) return;
      b.q = h;
    } else
      return;
    zt(e);
  }), (xi = s("#music-tune-preamp")) == null || xi.addEventListener("change", (u) => {
    const o = u.target, v = Number.parseFloat(o.value.trim());
    if (!Number.isFinite(v)) {
      o.value = ut(Ht, 1);
      return;
    }
    v !== Ht && (Ht = v, zt(e));
  }), (Ei = s("#music-tune-add")) == null || Ei.addEventListener("click", () => {
    St.push(fn()), zt(e);
  }), (Li = s("#music-avatar")) == null || Li.addEventListener("click", () => {
    L !== "default" && (L = "default", Q(e)), Re = !Re, Gt(e);
  }), (qi = s("#music-open-player")) == null || qi.addEventListener("click", c), (Mi = s("#music-bnow")) == null || Mi.addEventListener("click", c);
  const T = (u) => {
    H !== u && (H = u, u ? (Ct = !1, nt = !1, _ = null, it = null, Et = "", z = null, O = null, ne = "", It = "", Kt = null, et = null) : (te(), Ee = "", J !== void 0 && (window.clearTimeout(J), J = void 0), Y = "playlist", y != null && y.path && !kt && fe(e)), Q(e), Yt(e), u && (Is(e), ue(e), p("media_scan_status").then((o) => {
      !H || !e.isConnected || (Kt = o, o.running && Rs(e), ht(e));
    }).catch(() => {
    })));
  }, A = (u) => {
    if (u === "tuning") {
      L = "tuning", Q(e);
      return;
    }
    L = "default", T(u === "local"), Q(e);
  }, w = En(e);
  w == null || w.addEventListener("click", (u) => {
    const o = u.target.closest(".music-tb-seg"), v = o == null ? void 0 : o.dataset.seg;
    v && A(v);
  }), (Ti = s("#music-local-add")) == null || Ti.addEventListener("click", () => {
    mt = !mt, me(e);
  }), (Ci = s("#music-local-list")) == null || Ci.addEventListener("click", () => Jn(e)), (Ii = s("#music-local-del")) == null || Ii.addEventListener("click", () => Xn(e)), (Ri = s("#music-local-editdone")) == null || Ri.addEventListener("click", () => void Kn(e)), (Ai = s("#music-local-scan")) == null || Ai.addEventListener("click", () => void oi(e)), (Ni = s("#music-main")) == null || Ni.addEventListener("input", (u) => {
    const o = u.target;
    (o == null ? void 0 : o.id) === "music-mt-q" && nc(e, o.value.trim());
  }), (Di = s("#music-l-prev")) == null || Di.addEventListener("click", () => void pe(e, -1, !1)), (Bi = s("#music-l-next")) == null || Bi.addEventListener("click", () => void pe(e, 1, !1)), (Oi = s("#music-l-play")) == null || Oi.addEventListener("click", () => void us(e)), (Pi = s("#music-l-stop")) == null || Pi.addEventListener("click", () => void fe(e));
  const G = s("#music-l-vol");
  G == null || G.addEventListener("input", () => {
    Zt(G, Number(G.value)), os(e, Number(G.value) / 100);
  });
  const C = () => {
    const u = ["off", "shuffle", "repeat_all", "repeat_one"];
    j = u[(u.indexOf(j) + 1) % u.length], hn(j), qt(e), x(e, mi());
  };
  (ji = s("#music-l-mode")) == null || ji.addEventListener("click", C);
  const Te = (u, o) => {
    const v = (h) => {
      const R = u.getBoundingClientRect();
      return Math.max(0, Math.min(1, (h - R.left) / Math.max(1, R.width)));
    }, $ = (h) => {
      V = h, u.style.setProperty("--seek-pct", `${h * 100}%`), o(h);
    };
    u.addEventListener("pointerdown", (h) => {
      if (!(((y == null ? void 0 : y.duration_ms) ?? 0) <= 0)) {
        try {
          u.setPointerCapture(h.pointerId);
        } catch {
        }
        u.classList.add("music-dragging"), $(v(h.clientX));
      }
    }), u.addEventListener("pointermove", (h) => {
      V < 0 || $(v(h.clientX));
    });
    const b = (h) => {
      if (V < 0) return;
      const R = V;
      V = -1, u.classList.remove("music-dragging");
      try {
        u.releasePointerCapture(h.pointerId);
      } catch {
      }
      sc(e, Math.round(((y == null ? void 0 : y.duration_ms) ?? 0) * R));
    };
    u.addEventListener("pointerup", b), u.addEventListener("pointercancel", b);
  }, gt = s("#music-lbp");
  gt && Te(gt, (u) => {
    const o = (y == null ? void 0 : y.duration_ms) ?? 0;
    g(gt.querySelector(".music-progress-tip"), $e(o * u));
    const v = e.querySelector("#music-l-time");
    v && g(v, `${D(o * u)} / ${D(o)}`);
  });
  const Ze = () => {
    !y || !y.path || (L = "lplayer", Q(e));
  };
  (Hi = s("#music-l-open-player")) == null || Hi.addEventListener("click", Ze), (Wi = s("#music-lp-prev")) == null || Wi.addEventListener("click", () => void pe(e, -1, !1)), (Fi = s("#music-lp-next")) == null || Fi.addEventListener("click", () => void pe(e, 1, !1)), (Ui = s("#music-lp-play")) == null || Ui.addEventListener("click", () => void us(e)), (Vi = s("#music-lp-stop")) == null || Vi.addEventListener("click", () => void fe(e)), (zi = s("#music-lp-mode")) == null || zi.addEventListener("click", C);
  const _t = s("#music-lp-vol");
  _t == null || _t.addEventListener("input", () => {
    Zt(_t, Number(_t.value)), os(e, Number(_t.value) / 100);
  });
  const At = s("#music-lp-progress");
  At && Te(At, (u) => {
    const o = (y == null ? void 0 : y.duration_ms) ?? 0;
    g(At.querySelector(".music-progress-tip"), $e(o * u));
    const v = e.querySelector("#music-lp-time");
    v && g(v, `${D(o * u)} / ${D(o)}`);
  });
  const oe = (u) => {
    var o;
    !e.isConnected || !Ge() || (o = u.target) != null && o.closest("#plugin-close") && (u.stopPropagation(), u.preventDefault(), L === "lplayer" ? a() : Mn(e));
  };
  document.addEventListener("click", oe, !0), (Gi = s("#music-fields-toggle")) == null || Gi.addEventListener("click", () => {
    Ie = !(Ie ?? !(r != null && r.builtin)), Gt(e);
  }), (Qi = s("#music-copy-redirect")) == null || Qi.addEventListener("click", () => {
    const u = (r == null ? void 0 : r.redirect_uri) || "";
    u && Js(u).then(() => i(n("music.copied"))).catch(() => {
    });
  });
  for (const u of e.querySelectorAll("#music-quality .music-seg-btn"))
    u.addEventListener("click", () => {
      re = Number(u.dataset.q), Gt(e);
    });
  (Yi = s("#music-set-save")) == null || Yi.addEventListener("click", async () => {
    try {
      r = await p("music_config_set", { librespotBitrate: re }), re = null, i(n("music.saved")), Gt(e), Yt(e);
    } catch (u) {
      i(M(u));
    }
  }), (Ji = s("#music-save")) == null || Ji.addEventListener("click", async () => {
    var $, b, h, R;
    const u = (($ = s("#music-client-id")) == null ? void 0 : $.value.trim()) ?? "", o = ((b = s("#music-port")) == null ? void 0 : b.value.trim()) ?? "", v = Number(o);
    if (!u) {
      i(n("music.err_no_client_id"));
      return;
    }
    if (!Number.isInteger(v) || v < 1024 || v > 65535) {
      i(n("music.err_bad_port"));
      return;
    }
    try {
      r = await p("music_config_set", {
        clientId: u,
        port: v,
        // 本机播放那两项**一起交上去**（留空 = 自动探测 / 直连，都是合法值）
        librespotPath: ((h = s("#music-librespot")) == null ? void 0 : h.value.trim()) ?? "",
        librespotProxy: ((R = s("#music-librespot-proxy")) == null ? void 0 : R.value.trim()) ?? ""
        // 音质**不在这里提交**（2026-10-01 起它归设置页，那个页面有自己的「保存」）：
        // 不传 = `None` = 别动，宿主本来就是这个语义。把两页的保存混在一处，
        // 就会出现「在设置页点了 320、回连接卡片点保存、结果把它一起落盘了」。
      }), i(n("music.saved")), Gt(e), Yt(e), P = null;
    } catch (Ce) {
      i(M(Ce));
    }
  }), (Xi = s("#music-connect")) == null || Xi.addEventListener("click", async () => {
    var v, $;
    const u = ((v = s("#music-client-id")) == null ? void 0 : v.value.trim()) ?? "", o = Number((($ = s("#music-port")) == null ? void 0 : $.value.trim()) ?? "");
    if (u && Number.isInteger(o) && o >= 1024)
      try {
        r = await p("music_config_set", {
          clientId: u,
          port: o,
          librespotPath: null,
          librespotProxy: null,
          // 串流质量同上：这条路径只是「先落盘再连」，别动用户选的档
          librespotBitrate: null
        });
      } catch (b) {
        i(M(b));
        return;
      }
    try {
      const b = await p("spotify_connect");
      i(n("music.browser_hint")), await Ys(b);
    } catch (b) {
      i(M(b));
    }
  }), (Ki = s("#music-disconnect")) == null || Ki.addEventListener("click", async () => {
    try {
      await p("spotify_disconnect"), d = null, U = null, ni = "", ai = null, se.clear(), Se.clear(), Bt = null, tt = !1, _ = null, it = null, Et = "", N = null, at = "", nt = !1, Ct = !1, Ut = null, L = "default", await je(e), Q(e), Pe(e), i(n("music.disconnected"));
    } catch (u) {
      i(M(u));
    }
  });
  const X = (u) => {
    var b;
    const o = (b = u.target) == null ? void 0 : b.closest("[data-act]");
    if (!o) return;
    const v = o.dataset.kind || "", $ = o.dataset.id || "";
    switch (o.dataset.act) {
      case "side-tab":
        Y = o.dataset.tab || "playlist", Vt(e), Bs(e, Y);
        break;
      case "search-tab":
        rt = o.dataset.tab || "tracks", st(e);
        break;
      case "open":
        cc(e, v, $);
        break;
      case "main-track":
        ac(e, Number(o.dataset.i || "0"));
        break;
      case "main-play-all":
        _ && ds(e, _.kind, _.id);
        break;
      case "dd-track":
        o.dataset.uri && bs(e, o.dataset.uri);
        break;
      case "play-uri":
        o.dataset.uri && bs(e, o.dataset.uri);
        break;
      case "search-all":
        nt = !1, Ct = !0, bt(e), st(e);
        break;
      case "dev-pick":
        oc(e, $);
        break;
      case "local-toggle":
        lc(e);
        break;
      case "local-login":
        uc(e);
        break;
      // ── 本地音乐页（2026-10-01）──
      case "media-root": {
        const h = o.dataset.path || "";
        if (ct) {
          h && (pt.has(h) ? pt.delete(h) : pt.add(h)), Rt(e);
          break;
        }
        lt = h, Rt(e), ue(e);
        break;
      }
      case "media-scan":
        oi(e);
        break;
      // `＋` 浮层里的两行（2026-10-01）：目录 vs 播放列表文件。
      // **先关浮层再干活** —— 目录对话框是模态的，浮层留着会在对话框背后一闪一闪。
      case "media-add-dir":
        mt = !1, me(e), Qn(e);
        break;
      case "media-add-list":
        mt = !1, me(e), tc(e);
        break;
      case "media-list-close":
        ec(e);
        break;
      case "local-track":
        ic(e, Number(o.dataset.i || "0"));
        break;
    }
  };
  for (const u of ["#music-side-list", "#music-side-tabs", "#music-main", "#music-search-dd", "#music-dev-dd", "#music-q", "#music-q-dd", "#music-local-add-dd"])
    (Zi = s(u)) == null || Zi.addEventListener("click", X);
  (ts = s("#music-side-list")) == null || ts.addEventListener("dblclick", (u) => {
    var b;
    const o = (b = u.target) == null ? void 0 : b.closest('[data-act="open"]');
    if (!o) return;
    const v = o.dataset.kind || "", $ = o.dataset.id || "";
    $ && ds(e, v, $);
  }), (es = s("#music-devices-btn")) == null || es.addEventListener("click", () => {
    $t = !$t, le(e), $t && Me(e);
  }), rs(e), (is = s("#music-split")) == null || is.addEventListener("pointerdown", (u) => {
    var h;
    u.preventDefault();
    const o = u.clientX, v = ((h = s("#music-side")) == null ? void 0 : h.getBoundingClientRect().width) ?? be, $ = (R) => {
      be = Math.min(gs, Math.max(hs, Math.round(v + R.clientX - o))), rs(e);
    }, b = () => {
      window.removeEventListener("pointermove", $), window.removeEventListener("pointerup", b), document.body.classList.remove("music-resizing");
    };
    document.body.classList.add("music-resizing"), window.addEventListener("pointermove", $), window.addEventListener("pointerup", b);
  }), document.addEventListener("pointerdown", (u) => {
    const o = u.target;
    o && ($t && !o.closest("#music-dev-dd") && !o.closest("#music-devices-btn") && ($t = !1, le(e)), nt && !o.closest(".music-search-wrap") && (nt = !1, bt(e)), mt && !o.closest("#music-local-add-dd") && !o.closest("#music-local-add") && (mt = !1, me(e)), tt && !o.closest("#music-q-dd") && !o.closest("#music-b-queue") && !o.closest("#music-queue-btn") && (tt = !1, si(e)));
  });
  const W = s("#music-search");
  W == null || W.addEventListener("input", () => ms(e, W.value.trim())), W == null || W.addEventListener("focus", () => {
    at && (nt = !0, bt(e));
  }), W == null || W.addEventListener("keydown", (u) => {
    if (u.key === "Enter" && at) {
      nt = !1, Ct = !0, bt(e), st(e);
      return;
    }
    u.key === "Escape" && (W.value = "", ms(e, ""));
  }), document.body.addEventListener("mouseenter", () => ke(e)), document.body.addEventListener("mouseleave", () => ke(e));
  const Mt = async (u, o) => {
    u === "play" && await qe(e, "spotify");
    try {
      await p("spotify_control", { action: u, value: o });
    } catch (v) {
      i(M(v));
    }
  }, K = (u, o) => {
    var v;
    for (const $ of u) (v = s(`#${$}`)) == null || v.addEventListener("click", o);
  };
  K(["music-queue-btn", "music-b-queue"], () => {
    tt = !tt, si(e), Pe(e), tt ? Ps(e) : di(e), ke(e);
  }), K(["music-prev", "music-b-prev"], () => void Mt("previous")), K(["music-next", "music-b-next"], () => void Mt("next")), K(["music-play", "music-b-play"], () => void Mt(d != null && d.playing ? "pause" : "play")), K(["music-dual-btn", "music-l-dual-btn"], () => {
    kt = !kt, bn(kt), !kt && !H && y && fe(e), qt(e), pi(e), x(e, n(kt ? "music.dual_on" : "music.dual_off"));
  });
  let F = null, wt = !1;
  const Ws = async (u) => {
    if (F = u, !wt) {
      wt = !0;
      try {
        for (; F !== null; ) {
          const o = F;
          F = null, await Mt("volume", o);
        }
      } finally {
        wt = !1;
      }
    }
  };
  for (const u of ["music-vol", "music-b-vol"])
    (ss = s(`#${u}`)) == null || ss.addEventListener("input", (o) => {
      const v = o.target, $ = Number(v.value);
      Zt(v, $), Ws($);
    });
  K(["music-mode", "music-b-mode"], () => {
    const u = js();
    p("spotify_set_play_mode", { mode: u === "off" ? "shuffle" : u === "shuffle" ? "repeat_one" : "off" }).catch((v) => i(M(v)));
  }), jt = ["#music-pv-progress", "#music-bp"].map((u) => s(u)).filter((u) => !!u);
  for (const u of jt) {
    const o = (b) => {
      const h = u.getBoundingClientRect();
      return Math.max(0, Math.min(1, (b - h.left) / Math.max(1, h.width)));
    }, v = (b) => {
      var ns;
      Nt = b;
      const h = `${b * 100}%`;
      for (const Fs of jt) Fs.style.setProperty("--seek-pct", h);
      const R = ((ns = d == null ? void 0 : d.track) == null ? void 0 : ns.duration_ms) ?? 0, Ce = D(R * b);
      g(u.querySelector(".music-progress-tip"), $e(R * b)), g(s("#music-pv-pos"), Ce), g(s("#music-b-time"), `${Ce} / ${D(R)}`);
    };
    u.addEventListener("pointerdown", (b) => {
      var h;
      if (!((((h = d == null ? void 0 : d.track) == null ? void 0 : h.duration_ms) ?? 0) <= 0)) {
        try {
          u.setPointerCapture(b.pointerId);
        } catch {
        }
        u.classList.add("music-dragging"), v(o(b.clientX));
      }
    }), u.addEventListener("pointermove", (b) => {
      Nt < 0 || v(o(b.clientX));
    });
    const $ = (b) => {
      var R;
      if (Nt < 0) return;
      const h = Nt;
      Nt = -1, u.classList.remove("music-dragging");
      try {
        u.releasePointerCapture(b.pointerId);
      } catch {
      }
      Mt("seek", Math.round((((R = d == null ? void 0 : d.track) == null ? void 0 : R.duration_ms) ?? 0) * h));
    };
    u.addEventListener("pointerup", $), u.addEventListener("pointercancel", $);
  }
  const Z = s("#music-lyr");
  let ti = !1, yi = 0;
  Z == null || Z.addEventListener("wheel", () => fs(e), { passive: !0 }), Z == null || Z.addEventListener("pointerdown", (u) => {
    ti = !1, yi = u.clientY, fs(e);
  }), Z == null || Z.addEventListener("pointermove", (u) => {
    Math.abs(u.clientY - yi) > 4 && (ti = !0);
  }), Z == null || Z.addEventListener("click", (u) => {
    if (ti) return;
    const o = u.target.closest(".music-lyr-line"), v = o ? Jt[Number(o.dataset.i)] : void 0;
    v && Mt("seek", Math.round(v.at * 1e3));
  }), await je(e), Q(e), di(e), Ue(e), Pe(e), si(e), Yt(e), vs(e), ri(e);
}
async function bs(t, e) {
  await qe(t, "spotify");
  try {
    await p("spotify_play_uri", { uri: e, deviceId: ot || void 0 });
  } catch (i) {
    g(t.querySelector("#music-msg"), M(i));
  }
}
function fc() {
  bi(), vt !== void 0 && (window.clearTimeout(vt), vt = void 0), Ft !== void 0 && (window.clearTimeout(Ft), Ft = void 0), te(), J !== void 0 && (window.clearTimeout(J), J = void 0), ee(), y != null && y.path && (y = null, Lt = [], ft = -1, p("player_stop").catch(() => {
  })), Pt && (Pt(), Pt = null), jt = [], Sn(), qn();
}
window.__lunac_music_stop = fc;
const bc = {
  id: "music",
  name: "音乐歌词",
  keywords: ["音乐", "歌词", "歌曲", "正在播放", "music", "lyrics", "spotify", "播放控制", "暂停", "下一首", "歌单", "播放列表"],
  description: "歌词自动抓取 (LRCLIB + 网易云兜底) + Spotify 播放控制 / 歌单 / 队列",
  icon: "🎵",
  badge: "music",
  // 「本插件一律在**悬浮窗**里打开」（2026-09-29 从 main.ts 的硬编码 `id === "music"` 改成声明）。
  // 为什么要声明而不是让宿主按 id 判：音乐已归入**拓展插件**，要能从市场独立打包分发
  // —— 磁盘插件的代码宿主没法写死，行为只能由插件自己声明（见 ai-spec §3.5「插件契约」）。
  // 这也是「用户 2026-09-28 定的：从 Lunac 进音乐界面时自动展开成独立界面」那条的执行点。
  permissions: ["window.float"],
  async execute() {
    return { type: "html", content: _n() };
  }
};
export {
  vc as attach,
  vc as attachMusicListeners,
  bc as default,
  fc as detach,
  bc as musicPlugin,
  fc as stopMusicPolling
};
