const kl = "__lunac_host";
function Sl() {
  return globalThis[kl] ?? null;
}
function a(t, e) {
  const i = Sl();
  return i && typeof i.t == "function" ? i.t(t, e) : t;
}
function $l(t, e, i, s) {
  if (typeof e == "function" ? t !== e || !s : !e.has(t)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? s : i === "a" ? s.call(t) : s ? s.value : e.get(t);
}
function ql(t, e, i, s, n) {
  if (typeof e == "function" ? t !== e || !0 : !e.has(t)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return e.set(t, i), i;
}
var ms;
const Re = "__TAURI_TO_IPC_KEY__";
function xl(t, e = !1) {
  return window.__TAURI_INTERNALS__.transformCallback(t, e);
}
async function d(t, e = {}, i) {
  return window.__TAURI_INTERNALS__.invoke(t, e, i);
}
function Ns(t, e = "asset") {
  return window.__TAURI_INTERNALS__.convertFileSrc(t, e);
}
class Ll {
  get rid() {
    return $l(this, ms, "f");
  }
  constructor(e) {
    ms.set(this, void 0), ql(this, ms, e);
  }
  /**
   * Destroys and cleans up this resource from memory.
   * **You should not call any method on this object anymore and should drop any reference to it.**
   */
  async close() {
    return d("plugin:resources|close", {
      rid: this.rid
    });
  }
}
ms = /* @__PURE__ */ new WeakMap();
var ge;
(function(t) {
  t.WINDOW_RESIZED = "tauri://resize", t.WINDOW_MOVED = "tauri://move", t.WINDOW_CLOSE_REQUESTED = "tauri://close-requested", t.WINDOW_DESTROYED = "tauri://destroyed", t.WINDOW_FOCUS = "tauri://focus", t.WINDOW_BLUR = "tauri://blur", t.WINDOW_SCALE_FACTOR_CHANGED = "tauri://scale-change", t.WINDOW_THEME_CHANGED = "tauri://theme-changed", t.WINDOW_CREATED = "tauri://window-created", t.WINDOW_SUSPENDED = "tauri://suspended", t.WINDOW_RESUMED = "tauri://resumed", t.WEBVIEW_CREATED = "tauri://webview-created", t.DRAG_ENTER = "tauri://drag-enter", t.DRAG_OVER = "tauri://drag-over", t.DRAG_DROP = "tauri://drag-drop", t.DRAG_LEAVE = "tauri://drag-leave";
})(ge || (ge = {}));
async function Lc(t, e) {
  window.__TAURI_EVENT_PLUGIN_INTERNALS__.unregisterListener(t, e), await d("plugin:event|unlisten", {
    event: t,
    eventId: e
  });
}
async function qs(t, e, i) {
  var s;
  const n = typeof (i == null ? void 0 : i.target) == "string" ? { kind: "AnyLabel", label: i.target } : (s = i == null ? void 0 : i.target) !== null && s !== void 0 ? s : { kind: "Any" };
  return d("plugin:event|listen", {
    event: t,
    target: n,
    handler: xl(e)
  }).then((c) => async () => Lc(t, c));
}
async function El(t, e, i) {
  return qs(t, (s) => {
    Lc(t, s.id), e(s);
  }, i);
}
async function Tl(t, e) {
  await d("plugin:event|emit", {
    event: t,
    payload: e
  });
}
async function Ml(t, e, i) {
  await d("plugin:event|emit_to", {
    target: typeof t == "string" ? { kind: "AnyLabel", label: t } : t,
    event: e,
    payload: i
  });
}
async function Cl(t, e) {
  await d("plugin:shell|open", {
    path: t,
    with: e
  });
}
class Di extends Ll {
  /**
   * Creates an Image from a resource ID. For internal use only.
   *
   * @ignore
   */
  constructor(e) {
    super(e);
  }
  /** Creates a new Image using RGBA data, in row-major order from top to bottom, and with specified width and height. */
  static async new(e, i, s) {
    return d("plugin:image|new", {
      rgba: xs(e),
      width: i,
      height: s
    }).then((n) => new Di(n));
  }
  /**
   * Creates a new image using the provided bytes by inferring the file format.
   * If the format is known, prefer [@link Image.fromPngBytes] or [@link Image.fromIcoBytes].
   *
   * Only `ico` and `png` are supported (based on activated feature flag).
   *
   * Note that you need the `image-ico` or `image-png` Cargo features to use this API.
   * To enable it, change your Cargo.toml file:
   * ```toml
   * [dependencies]
   * tauri = { version = "...", features = ["...", "image-png"] }
   * ```
   */
  static async fromBytes(e) {
    return d("plugin:image|from_bytes", {
      bytes: xs(e)
    }).then((i) => new Di(i));
  }
  /**
   * Creates a new image using the provided path.
   *
   * Only `ico` and `png` are supported (based on activated feature flag).
   *
   * Note that you need the `image-ico` or `image-png` Cargo features to use this API.
   * To enable it, change your Cargo.toml file:
   * ```toml
   * [dependencies]
   * tauri = { version = "...", features = ["...", "image-png"] }
   * ```
   */
  static async fromPath(e) {
    return d("plugin:image|from_path", { path: e }).then((i) => new Di(i));
  }
  /** Returns the RGBA data for this image, in row-major order from top to bottom.  */
  async rgba() {
    return d("plugin:image|rgba", {
      rid: this.rid
    }).then((e) => new Uint8Array(e));
  }
  /** Returns the size of this image.  */
  async size() {
    return d("plugin:image|size", { rid: this.rid });
  }
}
function xs(t) {
  return t == null ? null : typeof t == "string" ? t : t instanceof Di ? t.rid : t;
}
async function Al(t, e) {
  await d("plugin:clipboard-manager|write_text", {
    label: e == null ? void 0 : e.label,
    text: t
  });
}
async function ss(t = {}) {
  return typeof t == "object" && Object.freeze(t), await d("plugin:dialog|open", { options: t });
}
async function Il(t = {}) {
  return typeof t == "object" && Object.freeze(t), await d("plugin:dialog|save", { options: t });
}
class Ec {
  constructor(...e) {
    this.type = "Logical", e.length === 1 ? "Logical" in e[0] ? (this.width = e[0].Logical.width, this.height = e[0].Logical.height) : (this.width = e[0].width, this.height = e[0].height) : (this.width = e[0], this.height = e[1]);
  }
  /**
   * Converts the logical size to a physical one.
   * @example
   * ```typescript
   * import { LogicalSize } from '@tauri-apps/api/dpi';
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   *
   * const appWindow = getCurrentWindow();
   * const factor = await appWindow.scaleFactor();
   * const size = new LogicalSize(400, 500);
   * const physical = size.toPhysical(factor);
   * ```
   *
   * @since 2.0.0
   */
  toPhysical(e) {
    return new Ri(this.width * e, this.height * e);
  }
  [Re]() {
    return {
      width: this.width,
      height: this.height
    };
  }
  toJSON() {
    return this[Re]();
  }
}
class Ri {
  constructor(...e) {
    this.type = "Physical", e.length === 1 ? "Physical" in e[0] ? (this.width = e[0].Physical.width, this.height = e[0].Physical.height) : (this.width = e[0].width, this.height = e[0].height) : (this.width = e[0], this.height = e[1]);
  }
  /**
   * Converts the physical size to a logical one.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const appWindow = getCurrentWindow();
   * const factor = await appWindow.scaleFactor();
   * const size = await appWindow.innerSize(); // PhysicalSize
   * const logical = size.toLogical(factor);
   * ```
   */
  toLogical(e) {
    return new Ec(this.width / e, this.height / e);
  }
  [Re]() {
    return {
      width: this.width,
      height: this.height
    };
  }
  toJSON() {
    return this[Re]();
  }
}
class Zt {
  constructor(e) {
    this.size = e;
  }
  toLogical(e) {
    return this.size instanceof Ec ? this.size : this.size.toLogical(e);
  }
  toPhysical(e) {
    return this.size instanceof Ri ? this.size : this.size.toPhysical(e);
  }
  [Re]() {
    return {
      [`${this.size.type}`]: {
        width: this.size.width,
        height: this.size.height
      }
    };
  }
  toJSON() {
    return this[Re]();
  }
}
class Tc {
  constructor(...e) {
    this.type = "Logical", e.length === 1 ? "Logical" in e[0] ? (this.x = e[0].Logical.x, this.y = e[0].Logical.y) : (this.x = e[0].x, this.y = e[0].y) : (this.x = e[0], this.y = e[1]);
  }
  /**
   * Converts the logical position to a physical one.
   * @example
   * ```typescript
   * import { LogicalPosition } from '@tauri-apps/api/dpi';
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   *
   * const appWindow = getCurrentWindow();
   * const factor = await appWindow.scaleFactor();
   * const position = new LogicalPosition(400, 500);
   * const physical = position.toPhysical(factor);
   * ```
   *
   * @since 2.0.0
   */
  toPhysical(e) {
    return new wt(this.x * e, this.y * e);
  }
  [Re]() {
    return {
      x: this.x,
      y: this.y
    };
  }
  toJSON() {
    return this[Re]();
  }
}
class wt {
  constructor(...e) {
    this.type = "Physical", e.length === 1 ? "Physical" in e[0] ? (this.x = e[0].Physical.x, this.y = e[0].Physical.y) : (this.x = e[0].x, this.y = e[0].y) : (this.x = e[0], this.y = e[1]);
  }
  /**
   * Converts the physical position to a logical one.
   * @example
   * ```typescript
   * import { PhysicalPosition } from '@tauri-apps/api/dpi';
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   *
   * const appWindow = getCurrentWindow();
   * const factor = await appWindow.scaleFactor();
   * const position = new PhysicalPosition(400, 500);
   * const physical = position.toLogical(factor);
   * ```
   *
   * @since 2.0.0
   */
  toLogical(e) {
    return new Tc(this.x / e, this.y / e);
  }
  [Re]() {
    return {
      x: this.x,
      y: this.y
    };
  }
  toJSON() {
    return this[Re]();
  }
}
class ls {
  constructor(e) {
    this.position = e;
  }
  toLogical(e) {
    return this.position instanceof Tc ? this.position : this.position.toLogical(e);
  }
  toPhysical(e) {
    return this.position instanceof wt ? this.position : this.position.toPhysical(e);
  }
  [Re]() {
    return {
      [`${this.position.type}`]: {
        x: this.position.x,
        y: this.position.y
      }
    };
  }
  toJSON() {
    return this[Re]();
  }
}
var ln;
(function(t) {
  t[t.Critical = 1] = "Critical", t[t.Informational = 2] = "Informational";
})(ln || (ln = {}));
class Dl {
  constructor(e) {
    this._preventDefault = !1, this.event = e.event, this.id = e.id;
  }
  preventDefault() {
    this._preventDefault = !0;
  }
  isPreventDefault() {
    return this._preventDefault;
  }
}
var Ya;
(function(t) {
  t.None = "none", t.Normal = "normal", t.Indeterminate = "indeterminate", t.Paused = "paused", t.Error = "error";
})(Ya || (Ya = {}));
function Mc() {
  return new Cc(window.__TAURI_INTERNALS__.metadata.currentWindow.label, {
    // @ts-expect-error `skip` is not defined in the public API but it is handled by the constructor
    skip: !0
  });
}
async function Us() {
  return d("plugin:window|get_all_windows").then((t) => t.map((e) => new Cc(e, {
    // @ts-expect-error `skip` is not defined in the public API but it is handled by the constructor
    skip: !0
  })));
}
const Vs = ["tauri://created", "tauri://error"];
class Cc {
  /**
   * Creates a new Window.
   * @example
   * ```typescript
   * import { Window } from '@tauri-apps/api/window';
   * const appWindow = new Window('my-label');
   * appWindow.once('tauri://created', function () {
   *  // window successfully created
   * });
   * appWindow.once('tauri://error', function (e) {
   *  // an error happened creating the window
   * });
   * ```
   *
   * @param label The unique window label. Must be alphanumeric: `a-zA-Z-/:_`.
   * @returns The {@link Window} instance to communicate with the window.
   */
  constructor(e, i = {}) {
    var s;
    this.label = e, this.listeners = /* @__PURE__ */ Object.create(null), i != null && i.skip || d("plugin:window|create", {
      options: {
        ...i,
        parent: typeof i.parent == "string" ? i.parent : (s = i.parent) === null || s === void 0 ? void 0 : s.label,
        label: e
      }
    }).then(async () => this.emit("tauri://created")).catch(async (n) => this.emit("tauri://error", n));
  }
  /**
   * Gets the Window associated with the given label.
   * @example
   * ```typescript
   * import { Window } from '@tauri-apps/api/window';
   * const mainWindow = Window.getByLabel('main');
   * ```
   *
   * @param label The window label.
   * @returns The Window instance to communicate with the window or null if the window doesn't exist.
   */
  static async getByLabel(e) {
    var i;
    return (i = (await Us()).find((s) => s.label === e)) !== null && i !== void 0 ? i : null;
  }
  /**
   * Get an instance of `Window` for the current window.
   */
  static getCurrent() {
    return Mc();
  }
  /**
   * Gets a list of instances of `Window` for all available windows.
   */
  static async getAll() {
    return Us();
  }
  /**
   *  Gets the focused window.
   * @example
   * ```typescript
   * import { Window } from '@tauri-apps/api/window';
   * const focusedWindow = Window.getFocusedWindow();
   * ```
   *
   * @returns The Window instance or `undefined` if there is not any focused window.
   */
  static async getFocusedWindow() {
    for (const e of await Us())
      if (await e.isFocused())
        return e;
    return null;
  }
  /**
   * Listen to an emitted event on this window.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const unlisten = await getCurrentWindow().listen<string>('state-changed', (event) => {
   *   console.log(`Got error: ${payload}`);
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @param event Event name. Must include only alphanumeric characters, `-`, `/`, `:` and `_`.
   * @param handler Event handler.
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async listen(e, i) {
    return this._handleTauriEvent(e, i) ? () => {
      const s = this.listeners[e];
      s.splice(s.indexOf(i), 1);
    } : qs(e, i, {
      target: { kind: "Window", label: this.label }
    });
  }
  /**
   * Listen to an emitted event on this window only once.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const unlisten = await getCurrentWindow().once<null>('initialized', (event) => {
   *   console.log(`Window initialized!`);
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @param event Event name. Must include only alphanumeric characters, `-`, `/`, `:` and `_`.
   * @param handler Event handler.
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async once(e, i) {
    return this._handleTauriEvent(e, i) ? () => {
      const s = this.listeners[e];
      s.splice(s.indexOf(i), 1);
    } : El(e, i, {
      target: { kind: "Window", label: this.label }
    });
  }
  /**
   * Emits an event to all {@link EventTarget|targets}.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().emit('window-loaded', { loggedIn: true, token: 'authToken' });
   * ```
   *
   * @param event Event name. Must include only alphanumeric characters, `-`, `/`, `:` and `_`.
   * @param payload Event payload.
   */
  async emit(e, i) {
    if (Vs.includes(e)) {
      for (const s of this.listeners[e] || [])
        s({
          event: e,
          id: -1,
          payload: i
        });
      return;
    }
    return Tl(e, i);
  }
  /**
   * Emits an event to all {@link EventTarget|targets} matching the given target.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().emit('main', 'window-loaded', { loggedIn: true, token: 'authToken' });
   * ```
   * @param target Label of the target Window/Webview/WebviewWindow or raw {@link EventTarget} object.
   * @param event Event name. Must include only alphanumeric characters, `-`, `/`, `:` and `_`.
   * @param payload Event payload.
   */
  async emitTo(e, i, s) {
    if (Vs.includes(i)) {
      for (const n of this.listeners[i] || [])
        n({
          event: i,
          id: -1,
          payload: s
        });
      return;
    }
    return Ml(e, i, s);
  }
  /** @ignore */
  _handleTauriEvent(e, i) {
    return Vs.includes(e) ? (e in this.listeners ? this.listeners[e].push(i) : this.listeners[e] = [i], !0) : !1;
  }
  // Getters
  /**
   * The scale factor that can be used to map physical pixels to logical pixels.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const factor = await getCurrentWindow().scaleFactor();
   * ```
   *
   * @returns The window's monitor scale factor.
   */
  async scaleFactor() {
    return d("plugin:window|scale_factor", {
      label: this.label
    });
  }
  /**
   * The position of the top-left hand corner of the window's client area relative to the top-left hand corner of the desktop.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const position = await getCurrentWindow().innerPosition();
   * ```
   *
   * @returns The window's inner position.
   */
  async innerPosition() {
    return d("plugin:window|inner_position", {
      label: this.label
    }).then((e) => new wt(e));
  }
  /**
   * The position of the top-left hand corner of the window relative to the top-left hand corner of the desktop.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const position = await getCurrentWindow().outerPosition();
   * ```
   *
   * @returns The window's outer position.
   */
  async outerPosition() {
    return d("plugin:window|outer_position", {
      label: this.label
    }).then((e) => new wt(e));
  }
  /**
   * The physical size of the window's client area.
   * The client area is the content of the window, excluding the title bar and borders.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const size = await getCurrentWindow().innerSize();
   * ```
   *
   * @returns The window's inner size.
   */
  async innerSize() {
    return d("plugin:window|inner_size", {
      label: this.label
    }).then((e) => new Ri(e));
  }
  /**
   * The physical size of the entire window.
   * These dimensions include the title bar and borders. If you don't want that (and you usually don't), use inner_size instead.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const size = await getCurrentWindow().outerSize();
   * ```
   *
   * @returns The window's outer size.
   */
  async outerSize() {
    return d("plugin:window|outer_size", {
      label: this.label
    }).then((e) => new Ri(e));
  }
  /**
   * Gets the window's current fullscreen state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const fullscreen = await getCurrentWindow().isFullscreen();
   * ```
   *
   * @returns Whether the window is in fullscreen mode or not.
   */
  async isFullscreen() {
    return d("plugin:window|is_fullscreen", {
      label: this.label
    });
  }
  /**
   * Gets the window's current minimized state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const minimized = await getCurrentWindow().isMinimized();
   * ```
   */
  async isMinimized() {
    return d("plugin:window|is_minimized", {
      label: this.label
    });
  }
  /**
   * Gets the window's current maximized state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const maximized = await getCurrentWindow().isMaximized();
   * ```
   *
   * @returns Whether the window is maximized or not.
   */
  async isMaximized() {
    return d("plugin:window|is_maximized", {
      label: this.label
    });
  }
  /**
   * Gets the window's current focus state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const focused = await getCurrentWindow().isFocused();
   * ```
   *
   * @returns Whether the window is focused or not.
   */
  async isFocused() {
    return d("plugin:window|is_focused", {
      label: this.label
    });
  }
  /**
   * Gets the window's current decorated state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const decorated = await getCurrentWindow().isDecorated();
   * ```
   *
   * @returns Whether the window is decorated or not.
   */
  async isDecorated() {
    return d("plugin:window|is_decorated", {
      label: this.label
    });
  }
  /**
   * Gets the window's current resizable state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const resizable = await getCurrentWindow().isResizable();
   * ```
   *
   * @returns Whether the window is resizable or not.
   */
  async isResizable() {
    return d("plugin:window|is_resizable", {
      label: this.label
    });
  }
  /**
   * Gets the window's native maximize button state.
   *
   * #### Platform-specific
   *
   * - **Linux / iOS / Android:** Unsupported.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const maximizable = await getCurrentWindow().isMaximizable();
   * ```
   *
   * @returns Whether the window's native maximize button is enabled or not.
   */
  async isMaximizable() {
    return d("plugin:window|is_maximizable", {
      label: this.label
    });
  }
  /**
   * Gets the window's native minimize button state.
   *
   * #### Platform-specific
   *
   * - **Linux / iOS / Android:** Unsupported.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const minimizable = await getCurrentWindow().isMinimizable();
   * ```
   *
   * @returns Whether the window's native minimize button is enabled or not.
   */
  async isMinimizable() {
    return d("plugin:window|is_minimizable", {
      label: this.label
    });
  }
  /**
   * Gets the window's native close button state.
   *
   * #### Platform-specific
   *
   * - **iOS / Android:** Unsupported.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const closable = await getCurrentWindow().isClosable();
   * ```
   *
   * @returns Whether the window's native close button is enabled or not.
   */
  async isClosable() {
    return d("plugin:window|is_closable", {
      label: this.label
    });
  }
  /**
   * Gets the window's current visible state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const visible = await getCurrentWindow().isVisible();
   * ```
   *
   * @returns Whether the window is visible or not.
   */
  async isVisible() {
    return d("plugin:window|is_visible", {
      label: this.label
    });
  }
  /**
   * Gets the window's current title.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const title = await getCurrentWindow().title();
   * ```
   */
  async title() {
    return d("plugin:window|title", {
      label: this.label
    });
  }
  /**
   * Gets the window's current theme.
   *
   * #### Platform-specific
   *
   * - **macOS:** Theme was introduced on macOS 10.14. Returns `light` on macOS 10.13 and below.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const theme = await getCurrentWindow().theme();
   * ```
   *
   * @returns The window theme.
   */
  async theme() {
    return d("plugin:window|theme", {
      label: this.label
    });
  }
  /**
   * Whether the window is configured to be always on top of other windows or not.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const alwaysOnTop = await getCurrentWindow().isAlwaysOnTop();
   * ```
   *
   * @returns Whether the window is visible or not.
   */
  async isAlwaysOnTop() {
    return d("plugin:window|is_always_on_top", {
      label: this.label
    });
  }
  async activityName() {
    return d("plugin:window|activity_name", {
      label: this.label
    });
  }
  async sceneIdentifier() {
    return d("plugin:window|scene_identifier", {
      label: this.label
    });
  }
  // Setters
  /**
   * Centers the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().center();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async center() {
    return d("plugin:window|center", {
      label: this.label
    });
  }
  /**
   *  Requests user attention to the window, this has no effect if the application
   * is already focused. How requesting for user attention manifests is platform dependent,
   * see `UserAttentionType` for details.
   *
   * Providing `null` will unset the request for user attention. Unsetting the request for
   * user attention might not be done automatically by the WM when the window receives input.
   *
   * #### Platform-specific
   *
   * - **macOS:** `null` has no effect.
   * - **Linux:** Urgency levels have the same effect.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().requestUserAttention();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async requestUserAttention(e) {
    let i = null;
    return e && (e === ln.Critical ? i = { type: "Critical" } : i = { type: "Informational" }), d("plugin:window|request_user_attention", {
      label: this.label,
      value: i
    });
  }
  /**
   * Updates the window resizable flag.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setResizable(false);
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async setResizable(e) {
    return d("plugin:window|set_resizable", {
      label: this.label,
      value: e
    });
  }
  /**
   * Enable or disable the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setEnabled(false);
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   *
   * @since 2.0.0
   */
  async setEnabled(e) {
    return d("plugin:window|set_enabled", {
      label: this.label,
      value: e
    });
  }
  /**
   * Whether the window is enabled or disabled.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setEnabled(false);
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   *
   * @since 2.0.0
   */
  async isEnabled() {
    return d("plugin:window|is_enabled", {
      label: this.label
    });
  }
  /**
   * Sets whether the window's native maximize button is enabled or not.
   * If resizable is set to false, this setting is ignored.
   *
   * #### Platform-specific
   *
   * - **macOS:** Disables the "zoom" button in the window titlebar, which is also used to enter fullscreen mode.
   * - **Linux / iOS / Android:** Unsupported.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setMaximizable(false);
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async setMaximizable(e) {
    return d("plugin:window|set_maximizable", {
      label: this.label,
      value: e
    });
  }
  /**
   * Sets whether the window's native minimize button is enabled or not.
   *
   * #### Platform-specific
   *
   * - **Linux / iOS / Android:** Unsupported.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setMinimizable(false);
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async setMinimizable(e) {
    return d("plugin:window|set_minimizable", {
      label: this.label,
      value: e
    });
  }
  /**
   * Sets whether the window's native close button is enabled or not.
   *
   * #### Platform-specific
   *
   * - **Linux:** GTK+ will do its best to convince the window manager not to show a close button. Depending on the system, this function may not have any effect when called on a window that is already visible
   * - **iOS / Android:** Unsupported.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setClosable(false);
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async setClosable(e) {
    return d("plugin:window|set_closable", {
      label: this.label,
      value: e
    });
  }
  /**
   * Sets the window title.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setTitle('Tauri');
   * ```
   *
   * @param title The new title
   * @returns A promise indicating the success or failure of the operation.
   */
  async setTitle(e) {
    return d("plugin:window|set_title", {
      label: this.label,
      value: e
    });
  }
  /**
   * Maximizes the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().maximize();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async maximize() {
    return d("plugin:window|maximize", {
      label: this.label
    });
  }
  /**
   * Unmaximizes the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().unmaximize();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async unmaximize() {
    return d("plugin:window|unmaximize", {
      label: this.label
    });
  }
  /**
   * Toggles the window maximized state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().toggleMaximize();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async toggleMaximize() {
    return d("plugin:window|toggle_maximize", {
      label: this.label
    });
  }
  /**
   * Minimizes the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().minimize();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async minimize() {
    return d("plugin:window|minimize", {
      label: this.label
    });
  }
  /**
   * Unminimizes the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().unminimize();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async unminimize() {
    return d("plugin:window|unminimize", {
      label: this.label
    });
  }
  /**
   * Sets the window visibility to true.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().show();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async show() {
    return d("plugin:window|show", {
      label: this.label
    });
  }
  /**
   * Sets the window visibility to false.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().hide();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async hide() {
    return d("plugin:window|hide", {
      label: this.label
    });
  }
  /**
   * Closes the window.
   *
   * Note this emits a closeRequested event so you can intercept it. To force window close, use {@link Window.destroy}.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().close();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async close() {
    return d("plugin:window|close", {
      label: this.label
    });
  }
  /**
   * Destroys the window. Behaves like {@link Window.close} but forces the window close instead of emitting a closeRequested event.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().destroy();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async destroy() {
    return d("plugin:window|destroy", {
      label: this.label
    });
  }
  /**
   * Whether the window should have borders and bars.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setDecorations(false);
   * ```
   *
   * @param decorations Whether the window should have borders and bars.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setDecorations(e) {
    return d("plugin:window|set_decorations", {
      label: this.label,
      value: e
    });
  }
  /**
   * Whether or not the window should have shadow.
   *
   * #### Platform-specific
   *
   * - **Windows:**
   *   - `false` has no effect on decorated window, shadows are always ON.
   *   - `true` will make undecorated window have a 1px white border,
   * and on Windows 11, it will have a rounded corners.
   * - **Linux:** Unsupported.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setShadow(false);
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async setShadow(e) {
    return d("plugin:window|set_shadow", {
      label: this.label,
      value: e
    });
  }
  /**
   * Set window effects.
   */
  async setEffects(e) {
    return d("plugin:window|set_effects", {
      label: this.label,
      value: e
    });
  }
  /**
   * Clear any applied effects if possible.
   */
  async clearEffects() {
    return d("plugin:window|set_effects", {
      label: this.label,
      value: null
    });
  }
  /**
   * Whether the window should always be on top of other windows.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setAlwaysOnTop(true);
   * ```
   *
   * @param alwaysOnTop Whether the window should always be on top of other windows or not.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setAlwaysOnTop(e) {
    return d("plugin:window|set_always_on_top", {
      label: this.label,
      value: e
    });
  }
  /**
   * Whether the window should always be below other windows.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setAlwaysOnBottom(true);
   * ```
   *
   * @param alwaysOnBottom Whether the window should always be below other windows or not.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setAlwaysOnBottom(e) {
    return d("plugin:window|set_always_on_bottom", {
      label: this.label,
      value: e
    });
  }
  /**
   * Prevents the window contents from being captured by other apps.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setContentProtected(true);
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async setContentProtected(e) {
    return d("plugin:window|set_content_protected", {
      label: this.label,
      value: e
    });
  }
  /**
   * Resizes the window with a new inner size.
   * @example
   * ```typescript
   * import { getCurrentWindow, LogicalSize } from '@tauri-apps/api/window';
   * await getCurrentWindow().setSize(new LogicalSize(600, 500));
   * ```
   *
   * @param size The logical or physical inner size.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setSize(e) {
    return d("plugin:window|set_size", {
      label: this.label,
      value: e instanceof Zt ? e : new Zt(e)
    });
  }
  /**
   * Sets the window minimum inner size. If the `size` argument is not provided, the constraint is unset.
   * @example
   * ```typescript
   * import { getCurrentWindow, PhysicalSize } from '@tauri-apps/api/window';
   * await getCurrentWindow().setMinSize(new PhysicalSize(600, 500));
   * ```
   *
   * @param size The logical or physical inner size, or `null` to unset the constraint.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setMinSize(e) {
    return d("plugin:window|set_min_size", {
      label: this.label,
      value: e instanceof Zt ? e : e ? new Zt(e) : null
    });
  }
  /**
   * Sets the window maximum inner size. If the `size` argument is undefined, the constraint is unset.
   * @example
   * ```typescript
   * import { getCurrentWindow, LogicalSize } from '@tauri-apps/api/window';
   * await getCurrentWindow().setMaxSize(new LogicalSize(600, 500));
   * ```
   *
   * @param size The logical or physical inner size, or `null` to unset the constraint.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setMaxSize(e) {
    return d("plugin:window|set_max_size", {
      label: this.label,
      value: e instanceof Zt ? e : e ? new Zt(e) : null
    });
  }
  /**
   * Sets the window inner size constraints.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setSizeConstraints({ minWidth: 300 });
   * ```
   *
   * @param constraints The logical or physical inner size, or `null` to unset the constraint.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setSizeConstraints(e) {
    function i(s) {
      return s ? { Logical: s } : null;
    }
    return d("plugin:window|set_size_constraints", {
      label: this.label,
      value: {
        minWidth: i(e == null ? void 0 : e.minWidth),
        minHeight: i(e == null ? void 0 : e.minHeight),
        maxWidth: i(e == null ? void 0 : e.maxWidth),
        maxHeight: i(e == null ? void 0 : e.maxHeight)
      }
    });
  }
  /**
   * Sets the window outer position.
   * @example
   * ```typescript
   * import { getCurrentWindow, LogicalPosition } from '@tauri-apps/api/window';
   * await getCurrentWindow().setPosition(new LogicalPosition(600, 500));
   * ```
   *
   * @param position The new position, in logical or physical pixels.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setPosition(e) {
    return d("plugin:window|set_position", {
      label: this.label,
      value: e instanceof ls ? e : new ls(e)
    });
  }
  /**
   * Sets the window fullscreen state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setFullscreen(true);
   * ```
   *
   * @param fullscreen Whether the window should go to fullscreen or not.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setFullscreen(e) {
    return d("plugin:window|set_fullscreen", {
      label: this.label,
      value: e
    });
  }
  /**
   * On macOS, Toggles a fullscreen mode that doesn’t require a new macOS space. Returns a boolean indicating whether the transition was successful (this won’t work if the window was already in the native fullscreen).
   * This is how fullscreen used to work on macOS in versions before Lion. And allows the user to have a fullscreen window without using another space or taking control over the entire monitor.
   *
   * On other platforms, this is the same as {@link Window.setFullscreen}.
   *
   * @param fullscreen Whether the window should go to simple fullscreen or not.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setSimpleFullscreen(e) {
    return d("plugin:window|set_simple_fullscreen", {
      label: this.label,
      value: e
    });
  }
  /**
   * Bring the window to front and focus.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setFocus();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async setFocus() {
    return d("plugin:window|set_focus", {
      label: this.label
    });
  }
  /**
   * Sets whether the window can be focused.
   *
   * #### Platform-specific
   *
   * - **macOS**: If the window is already focused, it is not possible to unfocus it after calling `set_focusable(false)`.
   *   In this case, you might consider calling {@link Window.setFocus} but it will move the window to the back i.e. at the bottom in terms of z-order.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setFocusable(true);
   * ```
   *
   * @param focusable Whether the window can be focused.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setFocusable(e) {
    return d("plugin:window|set_focusable", {
      label: this.label,
      value: e
    });
  }
  /**
   * Sets the window icon.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setIcon('/tauri/awesome.png');
   * ```
   *
   * Note that you may need the `image-ico` or `image-png` Cargo features to use this API.
   * To enable it, change your Cargo.toml file:
   * ```toml
   * [dependencies]
   * tauri = { version = "...", features = ["...", "image-png"] }
   * ```
   *
   * @param icon Icon bytes or path to the icon file.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setIcon(e) {
    return d("plugin:window|set_icon", {
      label: this.label,
      value: xs(e)
    });
  }
  /**
   * Whether the window icon should be hidden from the taskbar or not.
   *
   * #### Platform-specific
   *
   * - **macOS:** Unsupported.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setSkipTaskbar(true);
   * ```
   *
   * @param skip true to hide window icon, false to show it.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setSkipTaskbar(e) {
    return d("plugin:window|set_skip_taskbar", {
      label: this.label,
      value: e
    });
  }
  /**
   * Grabs the cursor, preventing it from leaving the window.
   *
   * There's no guarantee that the cursor will be hidden. You should
   * hide it by yourself if you want so.
   *
   * #### Platform-specific
   *
   * - **Linux:** Unsupported.
   * - **macOS:** This locks the cursor in a fixed location, which looks visually awkward.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setCursorGrab(true);
   * ```
   *
   * @param grab `true` to grab the cursor icon, `false` to release it.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setCursorGrab(e) {
    return d("plugin:window|set_cursor_grab", {
      label: this.label,
      value: e
    });
  }
  /**
   * Modifies the cursor's visibility.
   *
   * #### Platform-specific
   *
   * - **Windows:** The cursor is only hidden within the confines of the window.
   * - **macOS:** The cursor is hidden as long as the window has input focus, even if the cursor is
   *   outside of the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setCursorVisible(false);
   * ```
   *
   * @param visible If `false`, this will hide the cursor. If `true`, this will show the cursor.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setCursorVisible(e) {
    return d("plugin:window|set_cursor_visible", {
      label: this.label,
      value: e
    });
  }
  /**
   * Modifies the cursor icon of the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setCursorIcon('help');
   * ```
   *
   * @param icon The new cursor icon.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setCursorIcon(e) {
    return d("plugin:window|set_cursor_icon", {
      label: this.label,
      value: e
    });
  }
  /**
   * Sets the window background color.
   *
   * #### Platform-specific:
   *
   * - **Windows:** alpha channel is ignored.
   * - **iOS / Android:** Unsupported.
   *
   * @returns A promise indicating the success or failure of the operation.
   *
   * @since 2.1.0
   */
  async setBackgroundColor(e) {
    return d("plugin:window|set_background_color", { color: e });
  }
  /**
   * Changes the position of the cursor in window coordinates.
   * @example
   * ```typescript
   * import { getCurrentWindow, LogicalPosition } from '@tauri-apps/api/window';
   * await getCurrentWindow().setCursorPosition(new LogicalPosition(600, 300));
   * ```
   *
   * @param position The new cursor position.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setCursorPosition(e) {
    return d("plugin:window|set_cursor_position", {
      label: this.label,
      value: e instanceof ls ? e : new ls(e)
    });
  }
  /**
   * Changes the cursor events behavior.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setIgnoreCursorEvents(true);
   * ```
   *
   * @param ignore `true` to ignore the cursor events; `false` to process them as usual.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setIgnoreCursorEvents(e) {
    return d("plugin:window|set_ignore_cursor_events", {
      label: this.label,
      value: e
    });
  }
  /**
   * Starts dragging the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().startDragging();
   * ```
   *
   * @return A promise indicating the success or failure of the operation.
   */
  async startDragging() {
    return d("plugin:window|start_dragging", {
      label: this.label
    });
  }
  /**
   * Starts resize-dragging the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().startResizeDragging();
   * ```
   *
   * @return A promise indicating the success or failure of the operation.
   */
  async startResizeDragging(e) {
    return d("plugin:window|start_resize_dragging", {
      label: this.label,
      value: e
    });
  }
  /**
   * Sets the badge count. It is app wide and not specific to this window.
   *
   * #### Platform-specific
   *
   * - **Windows**: Unsupported. Use @{linkcode Window.setOverlayIcon} instead.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setBadgeCount(5);
   * ```
   *
   * @param count The badge count. Use `undefined` to remove the badge.
   * @return A promise indicating the success or failure of the operation.
   */
  async setBadgeCount(e) {
    return d("plugin:window|set_badge_count", {
      label: this.label,
      value: e
    });
  }
  /**
   * Sets the badge cont **macOS only**.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setBadgeLabel("Hello");
   * ```
   *
   * @param label The badge label. Use `undefined` to remove the badge.
   * @return A promise indicating the success or failure of the operation.
   */
  async setBadgeLabel(e) {
    return d("plugin:window|set_badge_label", {
      label: this.label,
      value: e
    });
  }
  /**
   * Sets the overlay icon. **Windows only**
   * The overlay icon can be set for every window.
   *
   *
   * Note that you may need the `image-ico` or `image-png` Cargo features to use this API.
   * To enable it, change your Cargo.toml file:
   *
   * ```toml
   * [dependencies]
   * tauri = { version = "...", features = ["...", "image-png"] }
   * ```
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setOverlayIcon("/tauri/awesome.png");
   * ```
   *
   * @param icon Icon bytes or path to the icon file. Use `undefined` to remove the overlay icon.
   * @return A promise indicating the success or failure of the operation.
   */
  async setOverlayIcon(e) {
    return d("plugin:window|set_overlay_icon", {
      label: this.label,
      value: e ? xs(e) : void 0
    });
  }
  /**
   * Sets the taskbar progress state.
   *
   * #### Platform-specific
   *
   * - **Linux / macOS**: Progress bar is app-wide and not specific to this window.
   * - **Linux**: Only supported desktop environments with `libunity` (e.g. GNOME).
   *
   * @example
   * ```typescript
   * import { getCurrentWindow, ProgressBarStatus } from '@tauri-apps/api/window';
   * await getCurrentWindow().setProgressBar({
   *   status: ProgressBarStatus.Normal,
   *   progress: 50,
   * });
   * ```
   *
   * @return A promise indicating the success or failure of the operation.
   */
  async setProgressBar(e) {
    return d("plugin:window|set_progress_bar", {
      label: this.label,
      value: e
    });
  }
  /**
   * Sets whether the window should be visible on all workspaces or virtual desktops.
   *
   * #### Platform-specific
   *
   * - **Windows / iOS / Android:** Unsupported.
   *
   * @since 2.0.0
   */
  async setVisibleOnAllWorkspaces(e) {
    return d("plugin:window|set_visible_on_all_workspaces", {
      label: this.label,
      value: e
    });
  }
  /**
   * Sets the title bar style. **macOS only**.
   *
   * @since 2.0.0
   */
  async setTitleBarStyle(e) {
    return d("plugin:window|set_title_bar_style", {
      label: this.label,
      value: e
    });
  }
  /**
   * Set window theme, pass in `null` or `undefined` to follow system theme
   *
   * #### Platform-specific
   *
   * - **Linux / macOS**: Theme is app-wide and not specific to this window.
   * - **iOS / Android:** Unsupported.
   *
   * @since 2.0.0
   */
  async setTheme(e) {
    return d("plugin:window|set_theme", {
      label: this.label,
      value: e
    });
  }
  // Listeners
  /**
   * Listen to window resize.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from "@tauri-apps/api/window";
   * const unlisten = await getCurrentWindow().onResized(({ payload: size }) => {
   *  console.log('Window resized', size);
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async onResized(e) {
    return this.listen(ge.WINDOW_RESIZED, (i) => {
      i.payload = new Ri(i.payload), e(i);
    });
  }
  /**
   * Listen to window move.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from "@tauri-apps/api/window";
   * const unlisten = await getCurrentWindow().onMoved(({ payload: position }) => {
   *  console.log('Window moved', position);
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async onMoved(e) {
    return this.listen(ge.WINDOW_MOVED, (i) => {
      i.payload = new wt(i.payload), e(i);
    });
  }
  /**
   * Listen to window close requested. Emitted when the user requests to closes the window.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from "@tauri-apps/api/window";
   * import { confirm } from '@tauri-apps/api/dialog';
   * const unlisten = await getCurrentWindow().onCloseRequested(async (event) => {
   *   const confirmed = await confirm('Are you sure?');
   *   if (!confirmed) {
   *     // user did not confirm closing the window; let's prevent it
   *     event.preventDefault();
   *   }
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async onCloseRequested(e) {
    return this.listen(ge.WINDOW_CLOSE_REQUESTED, async (i) => {
      const s = new Dl(i);
      await e(s), s.isPreventDefault() || await this.destroy();
    });
  }
  /**
   * Listen to a file drop event.
   * The listener is triggered when the user hovers the selected files on the webview,
   * drops the files or cancels the operation.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from "@tauri-apps/api/webview";
   * const unlisten = await getCurrentWindow().onDragDropEvent((event) => {
   *  if (event.payload.type === 'over') {
   *    console.log('User hovering', event.payload.position);
   *  } else if (event.payload.type === 'drop') {
   *    console.log('User dropped', event.payload.paths);
   *  } else {
   *    console.log('File drop cancelled');
   *  }
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async onDragDropEvent(e) {
    const i = await this.listen(ge.DRAG_ENTER, (r) => {
      e({
        ...r,
        payload: {
          type: "enter",
          paths: r.payload.paths,
          position: new wt(r.payload.position)
        }
      });
    }), s = await this.listen(ge.DRAG_OVER, (r) => {
      e({
        ...r,
        payload: {
          type: "over",
          position: new wt(r.payload.position)
        }
      });
    }), n = await this.listen(ge.DRAG_DROP, (r) => {
      e({
        ...r,
        payload: {
          type: "drop",
          paths: r.payload.paths,
          position: new wt(r.payload.position)
        }
      });
    }), c = await this.listen(ge.DRAG_LEAVE, (r) => {
      e({ ...r, payload: { type: "leave" } });
    });
    return () => {
      i(), n(), s(), c();
    };
  }
  /**
   * Listen to window focus change.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from "@tauri-apps/api/window";
   * const unlisten = await getCurrentWindow().onFocusChanged(({ payload: focused }) => {
   *  console.log('Focus changed, window is focused? ' + focused);
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async onFocusChanged(e) {
    const i = await this.listen(ge.WINDOW_FOCUS, (n) => {
      e({ ...n, payload: !0 });
    }), s = await this.listen(ge.WINDOW_BLUR, (n) => {
      e({ ...n, payload: !1 });
    });
    return () => {
      i(), s();
    };
  }
  /**
   * Listen to window scale change. Emitted when the window's scale factor has changed.
   * The following user actions can cause DPI changes:
   * - Changing the display's resolution.
   * - Changing the display's scale factor (e.g. in Control Panel on Windows).
   * - Moving the window to a display with a different scale factor.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from "@tauri-apps/api/window";
   * const unlisten = await getCurrentWindow().onScaleChanged(({ payload }) => {
   *  console.log('Scale changed', payload.scaleFactor, payload.size);
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async onScaleChanged(e) {
    return this.listen(ge.WINDOW_SCALE_FACTOR_CHANGED, e);
  }
  /**
   * Listen to the system theme change.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from "@tauri-apps/api/window";
   * const unlisten = await getCurrentWindow().onThemeChanged(({ payload: theme }) => {
   *  console.log('New theme: ' + theme);
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async onThemeChanged(e) {
    return this.listen(ge.WINDOW_THEME_CHANGED, e);
  }
}
var Ka;
(function(t) {
  t.Disabled = "disabled", t.Throttle = "throttle", t.Suspend = "suspend";
})(Ka || (Ka = {}));
var Ja;
(function(t) {
  t.Default = "default", t.FluentOverlay = "fluentOverlay";
})(Ja || (Ja = {}));
var Xa;
(function(t) {
  t.AppearanceBased = "appearanceBased", t.Light = "light", t.Dark = "dark", t.MediumLight = "mediumLight", t.UltraDark = "ultraDark", t.Titlebar = "titlebar", t.Selection = "selection", t.Menu = "menu", t.Popover = "popover", t.Sidebar = "sidebar", t.HeaderView = "headerView", t.Sheet = "sheet", t.WindowBackground = "windowBackground", t.HudWindow = "hudWindow", t.FullScreenUI = "fullScreenUI", t.Tooltip = "tooltip", t.ContentBackground = "contentBackground", t.UnderWindowBackground = "underWindowBackground", t.UnderPageBackground = "underPageBackground", t.Mica = "mica", t.Blur = "blur", t.Acrylic = "acrylic", t.Tabbed = "tabbed", t.TabbedDark = "tabbedDark", t.TabbedLight = "tabbedLight";
})(Xa || (Xa = {}));
var Za;
(function(t) {
  t.FollowsWindowActiveState = "followsWindowActiveState", t.Active = "active", t.Inactive = "inactive";
})(Za || (Za = {}));
const Ac = "curve", Rl = (() => {
  try {
    return Mc().label;
  } catch {
    return "";
  }
})(), Ic = Rl.endsWith(`-${Ac}`);
function Nl(t) {
  return t === "top" ? "artist" : t;
}
const Pl = {
  album: "spotify_albums",
  artist: "spotify_artists",
  show: "spotify_shows",
  top: "spotify_top_artists"
}, Dc = ["L", "R", "C", "LFE", "SL", "SR", "BL", "BR"], Gs = 5e3, Ol = 1280, Bl = 720, zl = 550, Wl = 300, Rc = 180, Nc = 520, Hl = 4e3, Fl = 450, jl = 800, Pc = 5e3, Ql = 200, Ul = 15e3, Oc = 500, Vl = 500, Gl = 250, Yl = 500, Kl = 0.3, v = {
  play: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polygon points="6 4 20 12 6 20 6 4"/></svg>',
  pause: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="9" y1="4" x2="9" y2="20"/><line x1="15" y1="4" x2="15" y2="20"/></svg>',
  prev: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polygon points="19 5 9 12 19 19 19 5"/><line x1="5" y1="5" x2="5" y2="19"/></svg>',
  next: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polygon points="5 5 15 12 5 19 5 5"/><line x1="19" y1="5" x2="19" y2="19"/></svg>',
  /** 随机（关 / 随机共用这一个；「关」靠 `data-mode` 变暗区分）。 */
  shuffle: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="16 3 21 3 21 8"/><line x1="4" y1="20" x2="21" y2="3"/><polyline points="21 16 21 21 16 21"/><line x1="15" y1="15" x2="21" y2="21"/><line x1="4" y1="4" x2="9" y2="9"/></svg>',
  /** 循环（单曲循环；那个「1」由 CSS `::after` 加，SVG 里不写字）。 */
  repeat: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="17 1 21 5 17 9"/><path d="M3 11V9a4 4 0 0 1 4-4h14"/><polyline points="7 23 3 19 7 15"/><path d="M21 13v2a4 4 0 0 1-4 4H3"/></svg>',
  list: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="9" y1="6" x2="21" y2="6"/><line x1="9" y1="12" x2="21" y2="12"/><line x1="9" y1="18" x2="21" y2="18"/><circle cx="4" cy="6" r="1" fill="currentColor" stroke="none"/><circle cx="4" cy="12" r="1" fill="currentColor" stroke="none"/><circle cx="4" cy="18" r="1" fill="currentColor" stroke="none"/></svg>',
  /** 进播放界面。 */
  expand: '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 3 21 3 21 9"/><polyline points="9 21 3 21 3 15"/><line x1="21" y1="3" x2="14" y2="10"/><line x1="3" y1="21" x2="10" y2="14"/></svg>',
  /** 回默认界面。**唯一**的退出播放界面的入口 —— 播放停止不会自动退出。 */
  back: '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/><line x1="3" y1="12" x2="9" y2="12"/></svg>',
  chevron: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg>',
  copy: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15V5a2 2 0 0 1 2-2h10"/></svg>',
  link: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.5 1.5"/><path d="M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7L12 19"/></svg>',
  power: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M18.4 6.6a9 9 0 1 1-12.8 0"/><line x1="12" y1="2" x2="12" y2="12"/></svg>',
  gear: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>',
  volume: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M15.5 8.5a5 5 0 0 1 0 7"/></svg>',
  /** 工具条上的「设备」按钮（2026-09-28）。画成一台小音箱，比「显示器」更贴
   *  Spotify 那种「可选的播放设备」语义。 */
  speaker: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="2" width="14" height="20" rx="2"/><circle cx="12" cy="14" r="3.2"/><circle cx="12" cy="6" r="1" fill="currentColor" stroke="none"/></svg>',
  /** 实心心形（「我喜欢的歌曲」那块封面上的图案）。**这个是 `fill`，不是描边** ——
   *  它是一块封面图（Spotify 的收藏夹封面就是实心心 + 渐变底），不是可点按钮。 */
  heart: '<svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" stroke="none"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>',
  // ── 本地媒体库那一页用到的四个（2026-10-01）──
  /** 「本地音乐」入口 + 目录行（画成文件夹）。 */
  folder: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/></svg>',
  /** 「添加目录」。 */
  plus: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>',
  /** 移除一根目录（行尾那枚）。`music.pl-x` 用。 */
  x: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="6" y1="6" x2="18" y2="18"/><line x1="18" y1="6" x2="6" y2="18"/></svg>',
  /** 没有封面的曲目行左侧占位（一个八分音符）。 */
  note: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18V6l10-2v12"/><circle cx="6.5" cy="18" r="2.5"/><circle cx="16.5" cy="16" r="2.5"/></svg>',
  /** 「重新扫描」/「刷新」—— 画成环形箭头。 */
  refresh: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="21 3 21 9 15 9"/><path d="M20.4 14a8.5 8.5 0 1 1-1.6-7.5L21 9"/></svg>',
  /** 勾选（本地列表「自定义队列编辑态」里那一行被勾中的标记）。**路径逐字抄自
   *  icon-style.md §3 的「保存 ✓」** —— 与 SVG.edit / SVG.trash 同一条纪律：已有的图形不另画。 */
  check: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>',
  /** 「测量」—— 一条起伏的响应曲线（Lucide 的 `activity` 那一族的形状）。 */
  wave: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12h3l2.5-6 3.5 12 3-8 2 2h4"/></svg>',
  /** 编辑（改列表）。**路径逐字抄自 icon-style.md §3 的「编辑 ✎」** —— 规范里已经
   *  给好这条了，不许自己另画一条（§4.2 最后一条：已有的图形不要重复造路径）。 */
  edit: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 3a2.8 2.8 0 0 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/></svg>',
  /** 删除（垃圾桶）。**同样逐字抄自 icon-style.md §3** —— 它是危险操作，
   *  按 §4.2 用同风格线性图标 + 语义色（hover 变 `--red`，见 styles.css）。 */
  trash: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6M14 11v6M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>',
  /** 停止本地播放（本地播放条右端那枚）。**它与暂停不是一回事**：暂停留着这台
   *  音频设备，停止会把设备一起放掉（见 player.rs 的 `player_stop`）。 */
  stop: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="6" y="6" width="12" height="12" rx="1.5"/></svg>',
  /** 「本地与 Spotify 同时出声」那把开关（2026-10-01）。画成**两个相交的圆** ——
   *  「两路并存」最直白的图形（Lucide 里叫 `blend`）。**不画成两个喇叭**：12px 下
   *  两个喇叭会糊成一团，而两个圆在任何尺寸下都认得出来。
   *  开关的「开着」不用第二个图形表达，靠 `.on` 的强调色（与其他开关一致）。 */
  dual: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="9" r="6.5"/><circle cx="15" cy="15" r="6.5"/></svg>',
  /** 「最常听的歌曲」那一行的图标（2026-10-01 用户第 4 条）。画成一条上扬的折线
   *  —— 「最常听 / 热度」最直白的图形（Lucide 的 `trending-up`，与上面这些同源）。
   *  与 `SVG.heart` 一样是 20px 的封面图案，但**保持描边风格**（它不是实心封面，
   *  它是「一行合成出来的入口」，与收藏夹那块渐变实心封面刻意区分开）。 */
  trend: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/></svg>'
  // （工具条上那枚「调音推子」图标 2026-10-01 随入口一起删掉了：调音改成标题栏
  //  三段切换的第三段，那枚图标就没有地方落了。图形本身仍在 icon-style.md §3 里。）
};
let f = null, y = null, fe = null, un = "", on = !1, ci = [], Nt = -1, ps = null, Ci = null, fs = !1, b = null, Ui = 0, Vi = 0, Gi = 0, se = [], Vt = [[]], Xe = 0, Bc = [], Le = 0, Ft = [], vi = null, ee = null, Se = -1, ft = 0, rt = null, $t = !1, ot = null, wn = null, ei = -1, Mi = !1, hi = !1, vs = 0, Ys = null;
const Jl = 300;
let us = null, je = { a: !1, b: !1 }, bi = ["a", "b"], qt = !1, Ni = !1, kn = null;
function Xl() {
  return { kind: "peaking", freq_hz: 1e3, gain_db: 0, q: 0.707, on: !0 };
}
function xi() {
  Ui = (b == null ? void 0 : b.preamp_db) ?? 0, Vi = (b == null ? void 0 : b.bass_db) ?? 0, Gi = (b == null ? void 0 : b.treble_db) ?? 0, Bc = ((b == null ? void 0 : b.graphic_eq) ?? []).map((i) => ({ freq_hz: i.freq_hz, gain_db: i.gain_db })), Le = (b == null ? void 0 : b.delay_ms) ?? 0, Ft = ((b == null ? void 0 : b.channel_copy) ?? []).map((i) => ({ from: i.from, to: i.to })), vi = (b == null ? void 0 : b.convolution) ?? null, ee = null;
  const t = b != null && b.channels && b.channels > 0 ? b.channels : 2, e = [((b == null ? void 0 : b.filters) ?? []).map((i) => ({ ...i }))];
  for (let i = 1; i <= t; i++) {
    const s = ((b == null ? void 0 : b.if_else) ?? []).find((n) => n.channel === i - 1);
    e.push(((s == null ? void 0 : s.then) ?? []).map((n) => ({ ...n })));
  }
  Vt = e, (Xe < 0 || Xe >= e.length) && (Xe = 0), se = e[Xe];
}
function Zl() {
  var i;
  if (!b) return [];
  if (Xe === 0) return b.response.db;
  const t = (b.if_else ?? []).findIndex((s) => s.channel === Xe - 1), e = t >= 0 ? (i = b.cond_db) == null ? void 0 : i[t] : void 0;
  return e && e.length ? e : b.response.db;
}
function eu() {
  var i;
  const t = new Map(((b == null ? void 0 : b.if_else) ?? []).map((s) => [s.channel, s])), e = [];
  for (let s = 1; s < Vt.length; s++) {
    const n = s - 1, c = Vt[s], r = ((i = t.get(n)) == null ? void 0 : i.else) ?? [];
    if (c.length === 0 && r.length === 0) continue;
    const p = { channel: n, then: c };
    r.length > 0 && (p.else = r), e.push(p);
  }
  return e;
}
let D = "default", rn = null, dt = null, ec = "", _e = !1, zc = "", J = null, Ks = !1, jt = "", Qe = "", Q = null, yi = !1, Ai, we = "playlist";
const gi = /* @__PURE__ */ new Map(), Pi = /* @__PURE__ */ new Set(), Yi = /* @__PURE__ */ new Map();
let I = null, Me = null, li = !1, vt = "", ze = !1, kt = !1, Ke = "tracks", Gt = null, ut = !1, le = null, Ce = "", Js = !1, hs = 0;
const tu = 2e4;
let Et = !1, Ls = "", Es = 0, Ts = !1, Oi = Wl, dn = null, Bi = "", ie = !1, ne = null, Ms = !1, _i = "", Ue = "", te = !1, ve = /* @__PURE__ */ new Set(), Ki = /* @__PURE__ */ new Set(), We = !1, O = null, wi = !1, Mt = "", Te = null, Ji = "", $e, ui = null, zi, S = null, ns = 0, B = [], P = -1, Pt = !1, oe = -1, Wi, re = 0, tt = [], Ae = [], G = null, ke = !1, U = !1, Ee = !1, it = [], Xi = null;
const F = {
  library: { ids: /* @__PURE__ */ new Set(), anchor: null },
  queue: { ids: /* @__PURE__ */ new Set(), anchor: null },
  onlineMain: { ids: /* @__PURE__ */ new Set(), anchor: null },
  onlineQueue: { ids: /* @__PURE__ */ new Set(), anchor: null },
  queueList: { ids: /* @__PURE__ */ new Set(), anchor: null }
}, Xt = {
  "local-track": "library",
  "queue-track": "queue",
  "main-track": "onlineMain",
  "play-uri": "onlineQueue",
  "local-queue": "queueList"
}, Ps = {
  library: "#music-mt-list",
  queue: "#music-lq-list",
  onlineMain: "#music-main",
  onlineQueue: "#music-q, #music-q-dd",
  queueList: ".music-lqs"
};
let lt = null, Je = "", Y, Fe = null, Tt = /* @__PURE__ */ new Set(), mt = /* @__PURE__ */ new Set(), oi = "", ii = !1;
function Wc() {
  return ie !== ii;
}
const Sn = "lunac-music-local-last";
function Hc() {
  try {
    const t = localStorage.getItem(Sn);
    if (!t) return null;
    const e = JSON.parse(t);
    if (!e || !Array.isArray(e.queue) || e.queue.length === 0) return null;
    const i = Number(e.index);
    return {
      queue: e.queue,
      index: Number.isInteger(i) && i >= 0 && i < e.queue.length ? i : 0,
      position_ms: Math.max(0, Number(e.position_ms) || 0)
    };
  } catch {
    return null;
  }
}
function Yt() {
  if (!(B.length === 0 || P < 0))
    try {
      localStorage.setItem(Sn, JSON.stringify({
        queue: B,
        index: P,
        position_ms: re
      }));
    } catch {
    }
}
const mn = "lunac-music-local-queues";
function iu() {
  try {
    const i = localStorage.getItem(mn);
    if (i) {
      const s = JSON.parse(i), n = Array.isArray(s.queues) ? s.queues.filter((r) => r && typeof r.id == "string" && Array.isArray(r.items)).map((r) => ({ id: r.id, name: typeof r.name == "string" ? r.name : "", items: r.items })) : [], c = typeof s.activeId == "string" && n.some((r) => r.id === s.activeId) ? s.activeId : null;
      return { queues: n, activeId: c };
    }
  } catch {
  }
  const t = { queues: [], activeId: null }, e = Hc();
  e && e.queue.length > 0 && t.queues.push({ id: Fc(), name: "", items: e.queue });
  try {
    localStorage.setItem(mn, JSON.stringify(t));
  } catch {
  }
  return t;
}
function ki() {
  try {
    localStorage.setItem(mn, JSON.stringify({ queues: Ae, activeId: G }));
  } catch {
  }
}
function Fc() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}
function Li() {
  return Ae.find((t) => t.id === G) ?? null;
}
function su(t) {
  const e = t || a("music.local_queue_edit");
  if (!Ae.some((s) => s.name === e)) return e;
  let i = 2;
  for (; Ae.some((s) => s.name === `${e} (${i})`); ) i++;
  return `${e} (${i})`;
}
{
  const t = iu();
  Ae = t.queues, G = t.activeId;
}
const jc = "lunac-music-dual-play";
let He = nu();
function nu() {
  try {
    return localStorage.getItem(jc) === "1";
  } catch {
    return !1;
  }
}
function au(t) {
  try {
    localStorage.setItem(jc, t ? "1" : "0");
  } catch {
  }
}
const Qc = "lunac-music-local-mode";
let ue = cu();
function cu() {
  try {
    const t = localStorage.getItem(Qc);
    return t === "shuffle" || t === "repeat_all" || t === "repeat_one" ? t : "off";
  } catch {
    return "off";
  }
}
function lu(t) {
  try {
    localStorage.setItem(Qc, t);
  } catch {
  }
}
function $n() {
  return a(ue === "shuffle" ? "music.mode_shuffle" : ue === "repeat_all" ? "music.mode_repeat_all" : ue === "repeat_one" ? "music.mode_repeat_one" : "music.mode_off");
}
let pt, bs = !1, Ot, tc = !1, ys, Uc = 0, Vc = 0, Bt = null, zt = null, Cs = null, Zi = null, Wt = 0, Si = !1, Rt = -1, Ht = [], Hi = 0, Ze, Qt, gs = "", _s = 0, St, pn = "";
function ri() {
  return D === "player" || D === "lplayer";
}
function o(t) {
  return t.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
function Fi(t) {
  if (!isFinite(t) || t < 0) return "0:00";
  const e = Math.floor(t / 1e3), i = Math.floor(e / 60), s = e % 60;
  return `${i}:${String(s).padStart(2, "0")}`;
}
function K(t) {
  if (!isFinite(t) || t < 0) return "00:00";
  const e = Math.floor(t / 1e3);
  return `${String(Math.floor(e / 60)).padStart(2, "0")}:${String(e % 60).padStart(2, "0")}`;
}
function R(t) {
  const e = t instanceof Error ? t.message : String(t);
  if (e.includes("ERR_NO_CLIENT_ID")) return a("music.err_no_client_id");
  if (e.includes("ERR_NOT_CONNECTED")) return a("music.err_not_connected");
  if (e.includes("ERR_NO_QUERY")) return a("music.err_no_query");
  if (e.includes("ERR_PORT_BUSY")) return a("music.err_port_busy", { port: String((f == null ? void 0 : f.port) ?? "") });
  if (e.includes("ERR_BAD_URI") || e.includes("ERR_BAD_ID")) return a("music.err_bad_uri");
  if (e.includes("ERR_SPOTIFY_STOPPED"))
    return Et = !0, a("music.err_spotify_stopped");
  const i = e.match(/ERR_RATE_LIMITED:(\S*)/);
  return i ? a("music.err_rate_limited", { s: i[1] || "?" }) : e.includes("Insufficient client scope") ? a("music.err_scope") : e.includes("No active device") || e.includes("NO_ACTIVE_DEVICE") ? a("music.err_no_device") : e.includes("Premium required") || e.includes("PREMIUM_REQUIRED") ? a("music.err_premium") : e.includes("Restriction violated") ? a("music.err_restricted") : e;
}
function uu(t) {
  const e = [];
  for (const i of t.split(/\r?\n/)) {
    const s = [...i.matchAll(/\[(\d{1,3}):(\d{1,2})(?:[.:](\d{1,3}))?\]/g)];
    if (s.length === 0) continue;
    const n = i.replace(/\[[^\]]*\]/g, "").trim();
    if (n)
      for (const c of s) {
        const r = c[3] ? Number(c[3].padEnd(3, "0")) / 1e3 : 0;
        e.push({ at: Number(c[1]) * 60 + Number(c[2]) + r, text: n });
      }
  }
  return e.sort((i, s) => i.at - s.at), e;
}
function ou() {
  return `
  <div class="music-root music-curve-root">
    <div class="music-setview">
      <div class="music-set-head">
        <span class="music-set-title">${a("music.tuning_curve")}</span>
      </div>
      <div class="music-set-body">
        <div class="music-tune-plot">
          <!-- 曲线缩放（与调音页同一条交互）：画布默认铺满宽度，点 ＋/－ 按百分比变宽，
               外层容器横向滚动 —— 看细节放大、看全局缩回。 -->
          <div class="music-tune-toolbar">
            <button type="button" class="music-tune-zoom" id="music-tune-zoom-out" title="${o(a("music.tuning_zoom_out"))}" aria-label="${o(a("music.tuning_zoom_out"))}">－</button>
            <span class="music-tune-zoom-label" id="music-tune-zoom-label">100%</span>
            <button type="button" class="music-tune-zoom" id="music-tune-zoom-in" title="${o(a("music.tuning_zoom_in"))}" aria-label="${o(a("music.tuning_zoom_in"))}">＋</button>
          </div>
          <div class="music-tune-scroll" id="music-tune-scroll">
            <canvas id="music-tune-canvas" width="640" height="280"></canvas>
          </div>
          <div class="music-hint" id="music-tune-rate"></div>
        </div>
        <div class="music-tune-probe">
          <button type="button" class="music-btn" id="music-tune-measure">${v.wave}${a("music.tuning_measure")}</button>
          <div class="music-hint" id="music-tune-probe-hint">${o(a("music.tuning_probe_hint"))}</div>
        </div>
        <div class="music-field">
          <label>${a("music.tuning_slots")}</label>
          <div class="music-seg music-slot-list" id="music-tune-slots"></div>
        </div>
      </div>
    </div>
    <div class="music-msg" id="music-msg"></div>
  </div>`;
}
function ru() {
  return `
  <div class="music-root">
    <!-- ── 默认界面：顶部工具条 + 状态行 + 连接设置 + 歌单列 / 搜索结果 ──
         工具条与「返回」按钮**分属两态**：默认态用底部栏那个「进播放界面」，
         播放态用**标题栏那个 ←**（syncTitlebarClose 把 × 换成它；歌名模块右端
         原来还有一枚「返回歌单」，2026-10-01 已按用户口径删掉）。
         ⚠️ 本段在模板字符串里，注释里一个反引号都不能出现（预检 #15 / #39 ⑩）。 -->
    <div class="music-view" id="music-v-default">
      <!-- 顶部工具条：头像 / 账号 / 搜索（**带下拉预览**）/ 状态 / 设置。
           2026-09-28 第二次改：设备按钮与「展开播放面板」都**下移到最底下那条控制栏**
           （用户要求「严格对齐 Spotify」，Spotify 的工具条上本来就没有这两样）。 -->
      <div class="music-toolbar">
        <button class="music-avatar" id="music-avatar" title="${o(a("music.account_btn"))}"></button>
        <span class="music-acc" id="music-acc"></span>
        <div class="music-search-wrap">
          <input class="music-search" id="music-search" type="search" autocomplete="off" spellcheck="false" placeholder="${o(a("music.search_ph"))}">
          <!-- 下拉预览：绝对定位挂在工具条下方（**不占布局**，否则窗口高会跟着抖） -->
          <div class="music-dd hidden" id="music-search-dd"></div>
        </div>
        <!-- 「自定义队列」状态按钮 2026-10-10 已**从工具条挪回本地音乐分页**（用户口径：
             放到那页筛选标题行（.music-local-head-row）的最右侧、只在本地页显示）—— 见
             renderLocalMain 里那行骨架与 applyQueueModeUi。它不再随本工具条显隐。
             注：本段在模板字符串里，注释里一个反引号都不能出现（预检 #15 / #39 ⑩）。 -->
        <span class="music-status" id="music-status">${a("music.loading")}</span>
        <!-- 「恢复」按钮（2026-10-02）：**只在 429 硬闸拉着时显示**（见 renderResumeBtn）。
             它是用户唯一的出口 —— 宿主一旦收到 429 就停掉所有 Spotify 请求、且不自动重试。
             放工具条而不是底部提示行：提示行在播放态是绝对定位 + pointer-events:none，点不到。
             ⚠️ 本段是 JS 模板字符串，注释里不能出现反引号（预检 #15 / #39 ⑩）。 -->
        <button class="music-ghost-btn hidden" id="music-resume">${a("music.resume")}</button>
        <!-- 这里原来的「本地音乐」文件夹按钮与「调音」推子按钮**已删除**（2026-10-01
             用户口径）：这两个入口收进了**标题栏那枚三段切换**（在线歌单 / 本地音乐 /
             调音，见 renderTitlebarSwitch）。标题栏是悬浮窗独有的，插件若被嵌在主窗口里
             就没有那一条 —— 那种情况下切换器会退到本工具条里（见 placeSwitcher），
             所以这里不给它们留第二份入口，否则「删掉」就变成了「多一份」。
             ⚠️ 本段是 JS 模板字符串，注释里不能出现反引号（预检 #15 / #39 ⑩）。 -->
        <button class="music-ghost-btn music-icon-btn" id="music-setup-toggle" title="${o(a("music.settings"))}">${v.gear}</button>
      </div>

      <div class="music-setup hidden" id="music-setup">
        <div class="music-hint" id="music-setup-hint">${a("music.setup_hint")}</div>
        <!-- 凭据字段默认只在「没有内置 Client ID」或用户主动展开时显示：
             内置值让「登录」变成一步操作，Redirect URI 那一串对普通用户是噪音。 -->
        <button class="music-ghost-btn music-fields-toggle hidden" id="music-fields-toggle"></button>
        <div id="music-setup-fields">
          <div class="music-field">
            <label for="music-client-id">${a("music.client_id")}</label>
            <input id="music-client-id" type="text" spellcheck="false" autocomplete="off" placeholder="${o(a("music.client_id_ph"))}">
          </div>
          <div class="music-field music-field-port">
            <label for="music-port">${a("music.port")}</label>
            <input id="music-port" type="text" inputmode="numeric" autocomplete="off">
          </div>
          <div class="music-field">
            <label>${a("music.redirect")}</label>
            <div class="music-redirect-row">
              <code id="music-redirect"></code>
              <button class="music-ghost-btn music-icon-btn" id="music-copy-redirect" title="${o(a("music.copy"))}">${v.copy}</button>
            </div>
          </div>
          <!-- 本机播放（librespot）的两项设置：路径留空 = 自动探测；代理留空 = 直连。
               两者都不是「必填」，所以各带一行小字说明（见 renderSetup）。 -->
          <div class="music-field">
            <label for="music-librespot">${a("music.local_play")}</label>
            <input id="music-librespot" type="text" spellcheck="false" autocomplete="off" placeholder="librespot.exe">
          </div>
          <div class="music-field">
            <label for="music-librespot-proxy">proxy</label>
            <input id="music-librespot-proxy" type="text" spellcheck="false" autocomplete="off" placeholder="${o(a("music.librespot_proxy_ph"))}">
          </div>
        </div>
        <div class="music-actions">
          <button class="music-btn" id="music-save">${a("music.save")}</button>
          <button class="music-btn music-primary" id="music-connect">${v.link} ${a("music.connect")}</button>
          <button class="music-btn" id="music-disconnect">${v.power} ${a("music.disconnect")}</button>
        </div>
      </div>

      <!-- 主体：**左栏（宽度可拖）+ 分隔条 + 主区**（用户 2026-09-28 的
           「歌单列作为单独的一列可拉动」「中间大的大部分区域作为歌曲列表」）。
           两栏各自内部滚动 —— 窗口是定尺 1280×720，不是靠内容撑出来的。 -->
      <div class="music-body hidden" id="music-body">
        <aside class="music-side" id="music-side">
          <div class="music-side-tabs" id="music-side-tabs">
            <button class="music-tab on" data-act="side-tab" data-tab="playlist">${a("music.playlists")}</button>
            <button class="music-tab" data-act="side-tab" data-tab="album">${a("music.tab_albums")}</button>
            <button class="music-tab" data-act="side-tab" data-tab="artist">${a("music.tab_artists")}</button>
            <button class="music-tab" data-act="side-tab" data-tab="show">${a("music.tab_shows")}</button>
            <!-- 「最常听」栏（2026-10-01 用户第 4 条）。**放在最后**：那四栏是「我的库」，
                 这一栏是「库外的东西」，顺序上按这个分组走。
                 原先与它并列的「新发行」2026-10-02 删除（端点永久 403）。
                 注：本段在模板字符串里，注释里不能出现反引号（预检 #15 / #39 ⑩）。 -->
            <button class="music-tab" data-act="side-tab" data-tab="top">${a("music.tab_top")}</button>
          </div>
          <!-- 「本地音乐」那一页的左栏头（与上面那排 Spotify 页签**互斥显示**）：
               一个标题 + 一个「添加目录」。它跟着 localPage 切，见 renderLocalSide。 -->
          <div class="music-local-head hidden" id="music-local-head">
            <span class="music-local-title">${a("music.local_library")}</span>
            <div class="music-local-head-btns">
              <!-- 正常态三枚（2026-10-01 用户口径）：
                   ＋ = 添加（**目录或播放列表文件**，两个入口合一）
                   ✎ = 修改列表（进编辑态）—— 取代原来那枚「打开播放列表文件」
                   ⟳ = 重扫。
                   图标一律取自 icon-style.md §3，不自己画（见 SVG.edit / SVG.trash）。 -->
              <button class="music-ghost-btn music-icon-btn" id="music-local-add" title="${o(a("music.local_add"))}">${v.plus}</button>
              <button class="music-ghost-btn music-icon-btn" id="music-local-list" title="${o(a("music.local_edit"))}">${v.edit}</button>
              <!-- 「重扫」那枚**已从本行删掉**（2026-10-10 用户口径：扫描按钮只留一枚）——
                   保留的是主区筛选标题行（.music-local-head-row）里那枚（id=music-scan-btn）；
                   本行不再有扫描入口。自定义队列开关也在那边（最右一枚），不在本行。 -->
              <!-- 编辑态两枚（正常态隐藏，切法见 renderLocalHead）：
                   🗑 = 把勾选的行**摘出列表**（暂存，还能反悔）
                   × = 退出并保存（到这一步才真落盘） -->
              <button class="music-ghost-btn music-icon-btn hidden" id="music-local-del" title="${o(a("music.local_del_sel"))}">${v.trash}</button>
              <button class="music-ghost-btn music-icon-btn hidden" id="music-local-editdone" title="${o(a("music.local_edit_done"))}">${v.x}</button>
              <!-- 那个「＋」的二选一浮层（目录 / 播放列表文件）。画法见 renderLocalAddMenu，
                   定位参照是上面那排按钮（.music-local-head-btns 是 relative）。
                   注：本段在**模板字符串**里，注释里一个反引号都不能出现（预检 #15 / #39 ⑩）。 -->
              <div class="music-dd music-local-add-dd hidden" id="music-local-add-dd"></div>
            </div>
          </div>
          <div class="music-side-list" id="music-side-list"></div>
        </aside>
        <div class="music-split" id="music-split" role="separator" aria-orientation="vertical"></div>
        <main class="music-main" id="music-main"></main>
      </div>

      <!-- ── 底部控制栏（2026-09-28，Spotify 复刻）─────────────────────────
           用户要求「在默认面板下方添加 Spotify 那样的播放控制，并把一些按钮也
           移动到下方控制」。三列 grid：左 = 正在播放（点它 = 打开播放面板）、
           中 = 播放键组、右 = 设备 / 音量 / 队列 / 展开。
           栏顶那条 2px 细进度线**绝对定位**（不占高），拖动即可跳转。
           **两个弹层都挂在右端那一簇里、向上弹**：这条栏贴着窗口下沿，
           向下弹会跑到窗口外面（见 styles.css 里那两条覆盖 top 的规则）。
           注意本段是 JS 模板字符串 —— 注释里不能出现反引号（会把字符串截断）。 -->
      <div class="music-nowbar no-drawer hidden" id="music-nowbar">
        <!-- 「另一侧」的抽屉（2026-10-03 用户口径）：两条控制栏同屏只能有一条，
             另一条收进左端这一枚里 —— 点它把另一条换出来、这一条收进去。
             只在「同时出声」开着**且另一侧确实有东西**时出现（见 syncHead）。
             它是 grid 的第一列（auto 宽），隐藏时整列塌成 0 ⇒ 不开抽屉时外观不变。 -->
        <button type="button" class="music-drawer-btn hidden" id="music-b-drawer"></button>
        <div class="music-bp music-bp-timed" id="music-bp" title="${o(a("music.seek"))}">
          <div class="music-bp-fill" id="music-bp-fill"></div>
          <div class="music-progress-tip" id="music-bp-tip">0:00</div>
          <span class="music-btime" id="music-b-time">00:00 / 00:00</span>
        </div>
        <button class="music-bnow" id="music-bnow" title="${o(a("music.open_player"))}">
          <span class="music-bnow-cover" id="music-bnow-cover"></span>
          <span class="music-bnow-main">
            <span class="music-bnow-n" id="music-bnow-n"></span>
            <span class="music-bnow-a" id="music-bnow-a"></span>
          </span>
          <!-- 「进入小窗播放」的位置**收在左边这一块上**（2026-10-03 用户口径）：
               左块本身就是那个按钮，右端那枚重复的展开按钮已删。这个图标只是为了
               让「它可点」这件事看得见（同一条口径也铺到了本地那条栏，见下面）。 -->
          <span class="music-bnow-go">${v.expand}</span>
        </button>
        <div class="music-bctl">
          <button class="music-round-btn music-mode-btn" id="music-b-mode" data-mode="off"></button>
          <button class="music-round-btn" id="music-b-prev" title="${o(a("music.prev"))}">${v.prev}</button>
          <button class="music-round-btn music-play-btn" id="music-b-play" title="${o(a("music.play_pause"))}">${v.play}</button>
          <button class="music-round-btn" id="music-b-next" title="${o(a("music.next"))}">${v.next}</button>
        </div>
        <div class="music-bend">
          <!-- 与本地播放条上那一枚是**同一个状态**（见 dualPlay 的注释）。
               两枚按钮各自长在自己的控制区里，用户在哪条栏上都够得着。 -->
          <button class="music-ghost-btn music-icon-btn music-dual-btn" id="music-dual-btn" title="${o(a("music.dual_play"))}">${v.dual}</button>
          <button class="music-ghost-btn music-icon-btn" id="music-devices-btn" title="${o(a("music.devices"))}">${v.speaker}</button>
          <span class="music-vol-ico">${v.volume}</span>
          <input class="music-vol" id="music-b-vol" type="range" min="0" max="100" step="1" value="50" style="--vol-pct:50%" title="${o(a("music.volume"))}">
          <button class="music-round-btn" id="music-b-queue" title="${o(a("music.queue"))}">${v.list}</button>
          <!-- 右端那枚「进入小窗播放」**已删**（2026-10-03 用户口径）：它与左边
               「正在播放」那一块是同一个动作（都进小窗播放态），右边这枚是重复入口。
               保留左边那块既有的按钮语义，右端这一簇从此只放设备 / 音量 / 队列。 -->
          <div class="music-dd music-dev-dd hidden" id="music-dev-dd"></div>
          <div class="music-dd hidden" id="music-q-dd"></div>
        </div>
      </div>

      <!-- ── 本地文件播放条（2026-10-01）───────────────────────────────
           与上面那条 Spotify 控制栏**不是一条**：那条的对象是远端播放器
           （Web API 的 spotify_* 命令），这条的对象是宿主里那条本机音频流
           （player.rs 的 player_* 命令）。两者的数据源、可用条件（这条不要求
           登录 Spotify）、能做的事都不一样 —— 合成一条会到处长出
           「如果是本地就…」的分支，那正是两套东西被缝在一起的样子。
           只在「本地页 + 有本地会话」时出现，见 renderLocalNowbar。
           注意本段是 JS 模板字符串 —— 注释里不能出现反引号。 -->
      <div class="music-nowbar music-lnowbar no-drawer hidden" id="music-lnowbar">
        <!-- 「另一侧」的抽屉，与上面那条栏同形同义（点击 = 把在线那条换出来）。 -->
        <button type="button" class="music-drawer-btn hidden" id="music-l-drawer"></button>
        <div class="music-bp" id="music-lbp" title="${o(a("music.seek"))}">
          <div class="music-bp-fill" id="music-lbp-fill"></div>
          <div class="music-progress-tip" id="music-lbp-tip">0:00</div>
        </div>
        <!-- 左边这一块**就是**「进入小窗播放」的入口（2026-10-03 用户口径）：
             原来它是纯展示（本地没有小窗可进），2026-10-01 有了本地小窗之后那句话
             就不成立了 ⇒ 与 Spotify 那条栏同形，做成按钮，点它进 #music-v-lplayer。 -->
        <button class="music-bnow music-lnow" id="music-lnow" title="${o(a("music.open_player"))}">
          <span class="music-bnow-cover" id="music-lnow-cover"></span>
          <span class="music-bnow-main">
            <span class="music-bnow-n" id="music-lnow-n"></span>
            <span class="music-bnow-a" id="music-lnow-a"></span>
          </span>
          <span class="music-bnow-go">${v.expand}</span>
        </button>
        <div class="music-bctl">
          <!-- 播放模式（关 / 随机 / 循环列表 / 单曲循环，2026-10-01 用户第 8 条）。
               与 Spotify 那枚 #music-b-mode **不是一件事**：那枚是远端真相，
               这枚是前端自己算的（见 localMode 的注释），所以两枚各记各的状态。
               注：本段在模板字符串里，注释里不能出现反引号（预检 #15 / #39 ⑩）。 -->
          <button class="music-round-btn music-mode-btn" id="music-l-mode" data-mode="off" title="${o(a("music.mode_off"))}"></button>
          <button class="music-round-btn" id="music-l-prev" title="${o(a("music.prev"))}">${v.prev}</button>
          <button class="music-round-btn music-play-btn" id="music-l-play" title="${o(a("music.play_pause"))}">${v.play}</button>
          <button class="music-round-btn" id="music-l-next" title="${o(a("music.next"))}">${v.next}</button>
          <button class="music-round-btn" id="music-l-stop" title="${o(a("music.local_stop"))}">${v.stop}</button>
        </div>
        <div class="music-bend">
          <button class="music-ghost-btn music-icon-btn music-dual-btn" id="music-l-dual-btn" title="${o(a("music.dual_play"))}">${v.dual}</button>
          <span class="music-ltime" id="music-l-time">0:00 / 0:00</span>
          <span class="music-vol-ico">${v.volume}</span>
          <input class="music-vol" id="music-l-vol" type="range" min="0" max="100" step="1" value="80" style="--vol-pct:80%" title="${o(a("music.volume"))}">
          <!-- 「队列」按钮（2026-10-09 用户口径，2026-10-11 澄清）：在音量右边，点它弹出一个
               **与在线 #music-q-dd 同形同义的下拉浮层**（#music-lq-dd，锚在这条栏同一位置），
               展示**这一轮的播放队列**（localQueue —— 即现在 / 接下来放什么），**不是**左栏那些
               自定义队列（与远端 #music-b-queue 同一个图标）。
               注：本段在模板字符串里，注释里一个反引号都不能出现（预检 #15 / #39 ⑩）。 -->
          <button class="music-round-btn" id="music-l-queue" title="${o(a("music.local_play_queue"))}">${v.list}</button>
          <div class="music-dd hidden" id="music-lq-dd"></div>
          <!-- 右端那枚「进入小窗播放」**已删**（2026-10-03 用户口径）：动作与左边
               「正在播放」那一块重复，两边只留左边一个入口。 -->
        </div>
      </div>
    </div>

    <!-- ── 播放界面：**550×130 的长条**（封面 100 + 右侧列 450）──────────
         右侧列三块的高度加起来正好是长条高：歌名 30 + 歌词 65 + 控制 35 = 130。
         **这几个数都是用户 2026-09-27 给的定尺**：改任何一个都要同步
         styles.css 的 .music-name / .music-lyr / .music-bar，以及宿主
         plugin_window.rs 的 MUSIC_W（见 ai-spec §4.6 与预检 #39 ④）。 -->
    <!-- 注意：本段是 JS 模板字符串，**注释里不能出现反引号**（会把字符串截断）。 -->
    <div class="music-view music-player hidden" id="music-v-player">
      <div class="music-pv-card">
        <div class="music-pv-cover" id="music-pv-cover"></div>
        <div class="music-pv-col">
          <!-- 歌名模块 H30：歌名（亮）+ 歌手·专辑（暗）。 -->
          <div class="music-name">
            <div class="music-name-text">
              <span class="music-title" id="music-pv-title"></span>
              <span class="music-sub" id="music-pv-sub"></span>
            </div>
            <!-- 「返回歌单」那枚**已删除**（2026-10-01 用户口径：小窗播放里那个不是
                 状态栏里的返回按钮要去掉）。退出去仍然走**标题栏那个 ←** ——
                 它在播放态由 syncTitlebarClose 把 × 换成 ←，语义是「停播 + 回默认面板」
                 （见 stopAndBack），也是用户当初指定的出口。所以这里删掉不留缺口。 -->
          </div>

          <!-- 歌词模块 H65：正好两行可见（行高 32）。已过 + 正在 = 亮，未到 = 暗；
               点某一行 = 跳到那一句的进度。 -->
          <div class="music-lyr" id="music-lyr"></div>

          <!-- 控制面板 H35：进度条**叠在本块顶部**（绝对定位 ⇒ 不占高度，总高仍是 130），
               四个播放键在块内居中，右端音量条 80px + 播放列表按钮。 -->
          <div class="music-bar">
            <!-- 时间在控制块**最左端、进度条下方**（用户 2026-09-27 定）。
                 绝对定位 ⇒ 不参与四钮的居中计算。 -->
            <div class="music-time">
              <span id="music-pv-pos">0:00</span><span class="music-time-sep">/</span><span id="music-pv-dur">0:00</span>
            </div>
            <div class="music-progress" id="music-pv-progress" title="${o(a("music.seek"))}">
              <div class="music-progress-fill" id="music-pv-fill"></div>
              <div class="music-progress-dot" id="music-pv-dot"></div>
              <div class="music-progress-tip" id="music-pv-tip">0:00</div>
            </div>
            <div class="music-bar-main">
              <button class="music-round-btn music-mode-btn" id="music-mode" data-mode="off"></button>
              <button class="music-round-btn" id="music-prev" title="${o(a("music.prev"))}">${v.prev}</button>
              <button class="music-round-btn music-play-btn" id="music-play" title="${o(a("music.play_pause"))}">${v.play}</button>
              <button class="music-round-btn" id="music-next" title="${o(a("music.next"))}">${v.next}</button>
            </div>
            <div class="music-bar-end">
              <span class="music-vol-ico">${v.volume}</span>
              <input class="music-vol" id="music-vol" type="range" min="0" max="100" step="1" value="50" style="--vol-pct:50%" title="${o(a("music.volume"))}">
              <button class="music-round-btn" id="music-queue-btn" title="${o(a("music.queue"))}">${v.list}</button>
            </div>
          </div>
        </div>
      </div>

      <!-- 播放列表（队列）挂在长条**下方**、不再与歌词互斥：长条是定尺 130，
           塞不进队列。开着时窗口按内容长高（applyResize 实测贴合）。 -->
      <div class="music-q-wrap hidden" id="music-q-wrap">
        <div class="music-sec-head">
          <span class="music-sec-title">${a("music.queue")}</span>
          <span class="music-sec-note">${a("music.queue_hint")}</span>
        </div>
        <div class="music-q" id="music-q"></div>
      </div>
    </div>

    <!-- ── 本地小窗：**本地文件播放也有的那条长条**（2026-10-01 用户口径
         「在本地文件播放的情况下也添加小窗模式」）────────────────────────
         与上一个视图**共用同一套外壳类**（music-player / music-pv-card / music-pv-cover /
         music-name / music-bar / music-bp…）⇒ 尺寸（550×130）、圆角、配色、
         进度条的细线与命中区，一行业务 CSS 都不用重写。
         唯一的差别在**中间那一块**：远端那条长条放的是歌词（H65，见 .music-lyr），
         本地文件没有歌词 —— 那一格换成**大号进度线 + 时间**（见 .music-lp-mid）。
         三块的高度仍是 30 + 65 + 35 = 130，与 MUSIC_W_BAR / applyResize 对齐。
         数据与动作**都只有一份**：状态来自 localPlayer，按钮走的是本地播放那几条
         既有函数（见 attachMusicListeners 里那几条绑定）。
         注意本段是 JS 模板字符串 —— 注释里不能出现反引号（预检 #15 / #39 ⑩）。 -->
    <div class="music-view music-player hidden" id="music-v-lplayer">
      <div class="music-pv-card">
        <div class="music-pv-cover" id="music-lp-cover"></div>
        <div class="music-pv-col">
          <div class="music-name">
            <div class="music-name-text">
              <span class="music-title" id="music-lp-title"></span>
              <span class="music-sub" id="music-lp-sub"></span>
            </div>
          </div>
          <div class="music-lp-mid">
            <div class="music-bp music-lp-seek" id="music-lp-progress" title="${o(a("music.seek"))}">
              <div class="music-bp-fill" id="music-lp-fill"></div>
              <div class="music-progress-tip" id="music-lp-tip">0:00</div>
            </div>
            <div class="music-lp-time" id="music-lp-time">0:00 / 0:00</div>
          </div>
          <div class="music-bar">
            <div class="music-bar-main">
              <button class="music-round-btn music-mode-btn" id="music-lp-mode" data-mode="off" title="${o(a("music.mode_off"))}"></button>
              <button class="music-round-btn" id="music-lp-prev" title="${o(a("music.prev"))}">${v.prev}</button>
              <button class="music-round-btn music-play-btn" id="music-lp-play" title="${o(a("music.play_pause"))}">${v.play}</button>
              <button class="music-round-btn" id="music-lp-next" title="${o(a("music.next"))}">${v.next}</button>
              <button class="music-round-btn" id="music-lp-stop" title="${o(a("music.local_stop"))}">${v.stop}</button>
            </div>
            <div class="music-bar-end">
              <span class="music-vol-ico">${v.volume}</span>
              <input class="music-vol" id="music-lp-vol" type="range" min="0" max="100" step="1" value="80" style="--vol-pct:80%" title="${o(a("music.volume"))}">
              <!-- 「队列」按钮（2026-10-09 用户口径，2026-10-11 改）：与本地那条控制栏上的同一枚
                   同义，但**小窗里没有内容区、也没有浮层的锚点** ⇒ 点它**切回默认面板再打开
                   同一个 #music-lq-dd 浮层**（本任务选定：② 切到默认面板并打开浮层）。
                   注：本段在模板字符串里，注释里一个反引号都不能出现（预检 #15 / #39 ⑩）。 -->
              <button class="music-round-btn" id="music-lp-queue" title="${o(a("music.local_play_queue"))}">${v.list}</button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- ── 设置页：**整屏**（2026-10-01 用户要求「设置图标进到一个新的设置页面」）──
         与 #music-v-player 同为整屏视图，由 mode = "settings" 切（见 renderMode）。
         职责划分是硬的：**这里只放「偏好」，「连接」仍归头像点开的 #music-setup**
         （Client ID / 端口 / 回调 / librespot 路径与代理），**「调音」也有自己的一页**
         （#music-v-tuning，2026-10-01 用户要求搬出去的）。理由与那张卡片里的
         「保存」按钮直接相关 —— 一个卡片里塞两套保存语义必然出岔子，而现在这几页
         各有各的保存。
         ⚠️ 本段是 JS 模板字符串 —— 注释里**不许出现反引号**，连「引用一个标识符」
         那种写法都不行：它会把模板字符串提前截断（预检 #15 / #39 ⑩，本轮又踩了一次）。 -->
    <div class="music-view music-setview hidden" id="music-v-settings">
      <div class="music-set-head">
        <button class="music-ghost-btn music-icon-btn" id="music-set-back" title="${o(a("music.settings_back"))}">${v.back}</button>
        <span class="music-set-title">${a("music.settings")}</span>
      </div>
      <div class="music-set-body">
        <!-- 串流质量：三档互斥按钮。**不用原生 select 元素** —— WebView2 透明窗口里
             它不渲染弹出层（code-rules §5.2）。三档值只允许 96/160/320（宿主侧
             LIBRESPOT_BITRATES，抄自 librespot --help 的原文）。
             ⚠️ 模板字符串 ⇒ 本段注释里也不许出现反引号（预检 #39 ⑩）。 -->
        <div class="music-field">
          <label>${a("music.quality")}</label>
          <div class="music-seg" id="music-quality">
            ${[96, 160, 320].map((t) => `<button type="button" class="music-seg-btn" data-q="${t}">${t}k</button>`).join("")}
          </div>
          <div class="music-hint">${o(a("music.quality_hint"))}</div>
          <div class="music-hint">${o(a("music.quality_local_note"))}</div>
        </div>
        <!-- 调音页的入口（2026-10-03 用户要求「设置按钮入口」）。**不在这页里编辑调音**：
             调音是**按下即生效、即落盘**的实时功能，而这页那套是「攒着等保存」
             （音质要重启 librespot 才生效）—— 两种保存语义混在一张卡片里必然出岔子。
             所以这里只给一颗**进去的按钮**（切到 #music-v-tuning 那一页）。 -->
        <div class="music-field">
          <label>${a("music.tuning")}</label>
          <div class="music-actions">
            <button type="button" class="music-btn" id="music-set-tuning">${a("music.tuning_open")}</button>
          </div>
        </div>
        <div class="music-actions">
          <button class="music-btn" id="music-set-save">${a("music.save")}</button>
        </div>
      </div>
    </div>

    <!-- ── 调音页：**自己一页**（2026-10-01 用户口径）────────────────────
         用户明确「调音插件的界面不能放置到设置界面里，要新建一个界面专门用来显示调音」
         —— 所以它在 2026-10-01 从设置页那一块**整段搬过来**（上一版是「调音分区」）。
         入口只有一个：标题栏那枚三段切换的第三段（见 renderTitlebarSwitch）——
         **页内那枚返回按钮 2026-10-02 按用户要求取掉了**：切换器本身就是「回得去」的
         那一条路（点回「在线歌单 / 本地音乐」即离页），再摆一个返回是重复入口。
         版面顺序（2026-10-03 用户口径，本轮重排）：三栏骨架 ——
         左 = 工具条（保存 / 导入 / 导出）+ 我的预设；中 = 三条全局水平滑块 +
         **频段柱**（滤波器与均衡器已合并）；右 = 通道槽 + 全局效果器（延迟 / 复制 / 卷积）。
         四条纪律：① 控件**按下就生效、也当场落盘**（与设置页「音质」那两条攒着
         等保存完全不同：音质要重启 librespot 才生效，调音是实时的）；
         ② 滤波器类型的**名单来自宿主**（tuning.kinds，与引擎 Kind::ALL 同源）、
         用户预设名单也来自宿主（tuning.user_presets）—— 前端不维护第二份名单；
         ③ **两条播放链都生效**（2026-10-04 起）：本地文件走宿主 player.rs，在线歌单走
         librespot 的 -B pipe 输出 → 宿主的 live_audio.rs，两条套的是**同一个**
         TuningSource（共享同一份配置与版本号 ⇒ 在哪边调都立刻生效）。唯一例外是
         **首次授权那一次**：那一次不能带 -B pipe（OAuth 会把 URL 打到 stdout、污染
         PCM，见 librespot_args 的三条注释），重启一次 librespot 即接入；
         ④ 频段柱里的控件**全部动态渲染**（见 renderTuningFilters），这里只留容器。
         ⚠️ 本段是 JS 模板字符串 ⇒ 注释里不许出现反引号（预检 #15 / #39 ⑩）。 -->
    <div class="music-view music-setview hidden" id="music-v-tuning">
      <div class="music-set-head">
        <span class="music-set-title">${a("music.tuning")}</span>
        <!-- 频响曲线**不在这页里**（2026-10-03 用户口径「参照 Peace」）：它搬进一扇独立小窗，
             这页只留一颗按钮当入口。理由：曲线是「一边看一边调」的东西，占满这页会把
             推子与数值表挤没；而这一页要按 Peace 的三栏骨架排。 -->
        <button type="button" class="music-btn music-curve-open" id="music-curve-open">${v.wave}${a("music.tuning_curve_open")}</button>
        <button type="button" class="music-switch" id="music-tuning-on" role="switch" aria-checked="false" title="${o(a("music.tuning"))}">
          <span class="music-switch-knob"></span>
        </button>
      </div>
      <!-- 三栏骨架（2026-10-03，参照 Peace 主窗 → 同日按用户第 7/8 条重排）：
             左 = 工具条 + 我的预设、中 = 三条全局滑块 + 频段柱、右 = 扬声器声道 + 全局效果器。
             **接线函数的 id 一律沿用**（music-tuning-user-presets / music-tune-slots /
             music-tuning-filters / music-preamp-range …）：这一页的 render 与委托全按 id 找节点，
             重排只动 HTML 的位置，逻辑一行都不用改。
             ⚠️ 本段是 JS 模板字符串 ⇒ 注释里不许出现反引号（预检 #15 / #39 ⑩）。 -->
      <div class="music-set-body music-tune-cols">
        <!-- ── 左栏：预设（2026-10-03 用户口径：工具条移到最上、内置 5 档整批删掉）── -->
        <div class="music-tune-col music-tune-col-presets">
          <div class="music-actions">
            <button type="button" class="music-btn" id="music-preset-save">${o(a("music.tuning_preset_save"))}</button>
            <button type="button" class="music-btn" id="music-preset-import">${o(a("music.tuning_preset_import"))}</button>
            <button type="button" class="music-btn" id="music-preset-export">${o(a("music.tuning_preset_export"))}</button>
          </div>
          <div class="music-preset-list" id="music-tuning-user-presets"></div>
          <div class="music-preset-edit hidden" id="music-tuning-preset-edit">
            <div class="music-hint" id="music-preset-edit-hint"></div>
            <input type="text" id="music-preset-name" autocomplete="off" spellcheck="false" />
            <button type="button" class="music-btn" id="music-preset-ok"></button>
            <button type="button" class="music-btn" id="music-preset-cancel">${o(a("music.tuning_preset_cancel"))}</button>
          </div>
          <!-- A-B 盲测（2026-10-06）：两个快照槽 + 随机映射 + 揭晓。
               快照 = **整条链**（宿主落 config	uningab-a.json / ab-b.json）；
               切换走 player_tuning_ab_apply（先校验→落盘→改内存→版本号+1 ⇒ 不重播）。
               盲测时两个按钮只显示 1 / 2，映射由 tuneAbSlots 决定，点「揭晓」才告诉用户。 -->
          <div class="music-tune-ab" id="music-tune-ab">
            <div class="music-sub-label">${o(a("music.tuning_ab_title"))}</div>
            <div class="music-actions">
              <button type="button" class="music-btn" id="music-ab-save-a">${o(a("music.tuning_ab_save_a"))}</button>
              <button type="button" class="music-btn" id="music-ab-save-b">${o(a("music.tuning_ab_save_b"))}</button>
            </div>
            <div class="music-actions" id="music-ab-play">
              <button type="button" class="music-btn" id="music-ab-pos1" data-pos="1">A</button>
              <button type="button" class="music-btn" id="music-ab-pos2" data-pos="2">B</button>
              <button type="button" class="music-btn" id="music-ab-blind">${o(a("music.tuning_ab_blind"))}</button>
              <button type="button" class="music-btn hidden" id="music-ab-reveal">${o(a("music.tuning_ab_reveal"))}</button>
            </div>
            <div class="music-hint" id="music-ab-hint"></div>
          </div>
        </div>
        <!-- ── 中栏：三条全局水平滑块 + 频段柱（2026-10-03 用户口径）────────────
             三条滑块 = 总增益 / 低音增益 / 高音增益（Peace 顶部那种「左标签 + 滑块 + 右数值框」）；
             频段柱 = **滤波器与均衡器合并**后的主体：频率可编辑 / 竖拉条 / 大号增益 / Q / 类型按钮。
             延迟属于全局效果器，已挪到右栏（与声道复制 / 卷积同处）。 -->
        <div class="music-tune-col music-tune-col-eq">
          <div class="music-tune-sliderrow">
            <label>${a("music.tuning_preamp")}</label>
            <input type="range" class="music-tune-hslider" id="music-preamp-range" min="-24" max="24" step="0.5" aria-label="${o(a("music.tuning_preamp"))}" />
            <input type="text" class="music-tune-num" id="music-tune-preamp" inputmode="decimal" autocomplete="off" spellcheck="false" aria-label="${o(a("music.tuning_preamp"))}" />
          </div>
          <div class="music-tune-sliderrow">
            <label>${a("music.tuning_bass")}</label>
            <input type="range" class="music-tune-hslider" id="music-bass-range" min="-24" max="24" step="0.5" aria-label="${o(a("music.tuning_bass"))}" />
            <input type="text" class="music-tune-num" id="music-tune-bass" inputmode="decimal" autocomplete="off" spellcheck="false" aria-label="${o(a("music.tuning_bass"))}" />
          </div>
          <div class="music-tune-sliderrow">
            <label>${a("music.tuning_treble")}</label>
            <input type="range" class="music-tune-hslider" id="music-treble-range" min="-24" max="24" step="0.5" aria-label="${o(a("music.tuning_treble"))}" />
            <input type="text" class="music-tune-num" id="music-tune-treble" inputmode="decimal" autocomplete="off" spellcheck="false" aria-label="${o(a("music.tuning_treble"))}" />
          </div>
          <!-- 频段柱：作用域是**右栏选中的那个通道槽**（全局槽 ↔ 引擎的 filters）。
               左侧那列图例（2026-10-06 用户要求）把「频率 / 增益 / 质量」各标一次，并与柱内
               三行**逐行对齐** —— 三个框都只有数字，少了它用户不知道哪个是哪个。行高与柱子
               共用 --tf-* 那四个变量（见 styles.css 的 .music-tune-filterwrap），改一处两边同步。
               第二格是空占位，对齐的是那根竖拉条（增益那一行同时有拉条与大号读数，只标一次）。 -->
          <div class="music-tune-filterwrap">
            <div class="music-tune-legend" aria-hidden="true">
              <span class="l-freq">${o(a("music.tuning_freq"))}</span>
              <span class="l-slider"></span>
              <span class="l-gain">${o(a("music.tuning_gain"))}</span>
              <span class="l-q">${o(a("music.tuning_q"))}</span>
            </div>
            <div class="music-tune-filters" id="music-tuning-filters"></div>
          </div>
          <div class="music-actions">
            <button type="button" class="music-btn" id="music-tune-add">${v.plus}${a("music.tuning_add")}</button>
          </div>
        </div>
        <!-- ── 右栏：通道槽 + 全局效果器（延迟 / 声道复制 / 卷积）──────────────
             三样效果器都是**顶层字段** ⇒ 只在「全局」通道槽里显示（画在通道槽里会看起来像
             只作用于那条声道）。槽本身不落盘 —— 它只是「中栏那排频段柱在编辑哪一份草稿」
             这个视图状态；改动落在草稿里，提交时整排一起发（见 tuneIfElsePayload）。 -->
        <div class="music-tune-col music-tune-col-side">
          <div class="music-sub-label">${a("music.tuning_slots")}</div>
          <div class="music-seg music-slot-list music-slot-col" id="music-tune-slots"></div>
          <div class="music-field hidden" id="music-tune-delay">
            <div class="music-tune-sliderrow">
              <label>${a("music.tuning_delay")}</label>
              <input type="range" class="music-tune-hslider" id="music-delay-range" min="0" max="5000" step="1" aria-label="${o(a("music.tuning_delay"))}" />
              <input type="text" class="music-tune-num" id="music-delay-num" inputmode="decimal" autocomplete="off" spellcheck="false" aria-label="${o(a("music.tuning_delay"))}" />
            </div>
          </div>
          <div class="music-field hidden" id="music-tune-copy">
            <div class="music-copy-list" id="music-copy-list"></div>
            <div class="music-actions">
              <button type="button" class="music-btn" id="music-copy-add">${v.plus}${a("music.tuning_copy_add")}</button>
            </div>
          </div>
          <div class="music-field hidden" id="music-tune-conv">
            <label>${a("music.tuning_conv")}</label>
            <div class="music-hint" id="music-conv-path"></div>
            <div class="music-actions">
              <button type="button" class="music-btn" id="music-conv-pick">${o(a("music.tuning_conv_pick"))}</button>
              <button type="button" class="music-btn hidden" id="music-conv-clear">${o(a("music.tuning_conv_clear"))}</button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- ── 自定义队列的编辑小窗（2026-10-09 用户口径）：插件页面**正中的浮层** —
         一个名字输入框 + 一个「添加文件」按钮 + 已选文件清单 + 确定 / 取消。
         ⚠️ 本段在模板字符串里，注释里一个反引号都不能出现（预检 #15 / #39 ⑩）。 -->
    <div class="music-dlg-mask hidden" id="music-queue-dlg">
      <div class="music-dlg">
        <div class="music-dlg-title">${a("music.local_queue_dlg_title")}</div>
        <div class="music-field">
          <label for="music-queue-name">${a("music.local_queue_dlg_name")}</label>
          <input id="music-queue-name" type="text" spellcheck="false" autocomplete="off" placeholder="${o(a("music.local_queue_dlg_name_ph"))}">
        </div>
        <div class="music-queue-pickrow">
          <button type="button" class="music-btn" id="music-queue-pick">${v.plus} ${a("music.local_queue_pick")}</button>
          <span class="music-hint" id="music-queue-pick-hint">${o(a("music.local_queue_pick_hint"))}</span>
        </div>
        <div class="music-queue-files" id="music-queue-files"></div>
        <div class="music-actions">
          <button type="button" class="music-btn" id="music-queue-cancel">${a("music.local_queue_cancel")}</button>
          <button type="button" class="music-btn music-primary" id="music-queue-ok">${a("music.local_queue_ok")}</button>
        </div>
      </div>
    </div>

    <!-- ── 「删除本地文件」二次确认（2026-10-11 用户口径）：删除是**不可恢复**动作，
         所以走一扇居中确认卡（复用上面 #music-queue-dlg 那套 .music-dlg-mask 观感，
         **不用 window.confirm** —— WebView2 里那套原生框与本仓观感不一致）。
         文案动态填进 #music-del-text（带上曲目名、写明不可恢复）。
         ⚠️ 本段在模板字符串里，注释里一个反引号都不能出现（预检 #15 / #39 ⑩）。 -->
    <div class="music-dlg-mask hidden" id="music-del-dlg">
      <div class="music-dlg">
        <div class="music-dlg-title">${a("music.ctx_delete_title")}</div>
        <div class="music-del-text" id="music-del-text"></div>
        <div class="music-actions">
          <button type="button" class="music-btn" id="music-del-cancel">${a("music.ctx_delete_cancel")}</button>
          <button type="button" class="music-btn music-primary" id="music-del-ok">${a("music.ctx_delete_ok")}</button>
        </div>
      </div>
    </div>

    <!-- ── 歌曲行的**右键上下文菜单**（2026-10-11 用户第 4 条）：单例节点，在鼠标位置弹出
         （非居中模态）；点外部 / Esc 关闭。做法照桌宠窗那枚 pet-menu（静态节点 + open 类 +
         鼠标位置定位），不另造第二套观感。菜单项按上下文现填（见 openCtxMenu）。
         ⚠️ **必须长在「主插件窗」的 shell（这里）**：上一版误放进了 curveShellHtml
         （频响曲线窗）—— 而 curve 窗根本不挂 contextmenu 监听（attachMusicListeners 在
         isCurveWindow 时早退到 attachCurveWindow）⇒ 主窗里 openCtxMenu 永远
         querySelector 到 null、菜单不出（2026-10-11 用户报「右键呼不出来」的根因）。
         ⚠️ 本段在模板字符串里，注释里一个反引号都不能出现（预检 #15 / #39 ⑩）。 -->
    <div class="music-ctx" id="music-ctx"></div>

    <div class="music-msg" id="music-msg"></div>
  </div>`;
}
function M(t, e) {
  t && t.textContent !== e && (t.textContent = e);
}
function C(t, e) {
  if (!t || t.innerHTML === e) return;
  const i = document.createElement("template");
  i.innerHTML = e, t.innerHTML !== i.innerHTML && (t.innerHTML = e);
}
function A(t, e) {
  t == null || t.classList.toggle("hidden", !e);
}
function de(t, e, i) {
  t && t.getAttribute(e) !== i && t.setAttribute(e, i);
}
function di(t, e) {
  if (!t) return;
  const i = Math.max(0, Math.min(100, Math.round(e)));
  t.style.setProperty("--vol-pct", `${i}%`);
}
function du(t) {
  const e = t.querySelector("#music-msg");
  if (!e) return;
  const i = e.textContent ?? "";
  if (i !== gs) {
    gs = i, _s = Date.now();
    return;
  }
  i && Date.now() - _s >= Pc && (e.textContent = "", gs = "", _s = 0);
}
function ae(t) {
  const e = ri();
  A(t.querySelector("#music-v-default"), D === "default"), A(t.querySelector("#music-v-player"), D === "player"), A(t.querySelector("#music-v-lplayer"), D === "lplayer"), A(t.querySelector("#music-v-settings"), D === "settings");
  const i = D === "tuning";
  A(t.querySelector("#music-v-tuning"), i), i ? (Ct(t), Pu(t)) : qn(), t.classList.toggle("music-player-on", e), mu(e), pu(), si(t), bu(), D === "player" ? (Nt = -1, Rs(t), Hs(t)) : D === "lplayer" ? cl(t) : D === "default" && (A(t.querySelector("#music-body"), !!(f != null && f.connected) || ie), Kt(t), Ie(t), et(t), $i(t)), D !== "default" && Ee && (Ee = !1, xt(t)), Qi(t);
}
function mu(t) {
  const e = !t;
  document.getElementById("plugin-titlebar") && dn !== e && (dn = e, d("plugin_window_set_resizable", { resizable: e }).catch(() => {
  }));
}
function pu() {
  const t = document.getElementById("plugin-close");
  if (!t) return;
  Bi || (Bi = t.innerHTML);
  const e = ri() ? "back" : "close";
  if (t.dataset.mode === e) return;
  t.dataset.mode = e, t.innerHTML = e === "back" ? v.back : Bi;
  const i = e === "back" ? a("music.back") : "Close";
  t.title = i, t.setAttribute("aria-label", i);
}
function fu() {
  const t = document.getElementById("plugin-close");
  !t || !Bi || t.dataset.mode !== "back" || (t.innerHTML = Bi, t.title = "Close", t.setAttribute("aria-label", "Close"), t.dataset.mode = "close");
}
function vu() {
  return D === "tuning" ? "tuning" : D !== "default" ? "" : ie ? "local" : "online";
}
function hu(t) {
  const e = document.getElementById("music-tb-switch");
  if (e) return e;
  const i = document.createElement("div");
  i.id = "music-tb-switch", i.className = "music-tb-switch", i.setAttribute("role", "tablist"), i.setAttribute("data-tauri-drag-region", "");
  const s = [
    ["online", a("music.tb_online")],
    ["local", a("music.tb_local")],
    ["tuning", a("music.tb_tuning")]
  ];
  i.innerHTML = s.map(([r, p]) => `<button type="button" class="music-tb-seg" role="tab" data-seg="${r}" title="${o(p)}">${o(p)}</button>`).join("");
  const n = document.getElementById("plugin-titlebar"), c = document.getElementById("plugin-title");
  if (n && c)
    n.insertBefore(i, c.nextSibling);
  else {
    const r = t.querySelector("#music-setup-toggle"), p = t.querySelector(".music-toolbar");
    if (!p) return null;
    p.insertBefore(i, r);
  }
  return i;
}
function bu() {
  const t = document.getElementById("music-tb-switch");
  if (!t) return;
  const e = vu();
  for (const i of t.querySelectorAll(".music-tb-seg"))
    de(i, "aria-pressed", String(i.dataset.seg === e));
}
function yu() {
  var t;
  (t = document.getElementById("music-tb-switch")) == null || t.remove();
}
async function gu(t) {
  try {
    await d("spotify_control", { action: "pause" });
  } catch (e) {
    $(t, R(e));
  }
  D = "default", ae(t);
}
function es(t) {
  const e = t.querySelector("#music-local-qmode");
  e && (e.classList.toggle("on", U), de(e, "aria-pressed", U ? "true" : "false"));
  const i = t.querySelector("#music-scan-btn");
  i && (de(i, "title", a(U ? "music.local_queue_exit" : "music.local_rescan")), C(i, U ? v.x : v.refresh)), Gc(t);
}
function Gc(t) {
  const e = t.querySelector("#music-setup-toggle");
  e && (de(e, "title", a(U ? "music.local_queue_add_picked" : "music.settings")), C(e, U ? v.plus : v.gear));
}
function ic(t) {
  const e = t.querySelector("#music-setup-toggle"), i = t.querySelector(".music-toolbar");
  e && i && e.parentElement !== i && i.appendChild(e);
}
function fn(t) {
  const e = t.querySelector("#music-setup-toggle"), i = t.querySelector(".music-toolbar");
  if (!e || !i) return;
  const s = ie ? t.querySelector(
    G === null ? "#music-local-page .music-local-head-row" : "#music-queue-page .music-local-head-row"
  ) : null;
  if (!s) {
    e.parentElement !== i && i.appendChild(e);
    return;
  }
  if (G === null) {
    const n = s.querySelector("#music-scan-btn");
    n ? e.previousElementSibling !== n && n.insertAdjacentElement("afterend", e) : e.parentElement !== s && s.appendChild(e);
  } else (e.parentElement !== s || e !== s.lastElementChild) && s.appendChild(e);
}
function sc(t, e, i, s) {
  const n = t.querySelector(e);
  n && n.classList.toggle("no-drawer", !s), A(t.querySelector(i), s);
}
function nc(t, e, i) {
  if (!t) return;
  const s = a(e);
  t.dataset.label !== s && (t.dataset.label = s, t.innerHTML = `${v.expand}<span>${o(s)}</span>`), de(t, "title", a(i));
}
function si(t) {
  const e = D === "player", i = !!(f != null && f.connected);
  A(t.querySelector("#music-nowbar"), !e && i && !Wc());
  const s = He && i && P >= 0;
  sc(t, "#music-nowbar", "#music-b-drawer", s), sc(t, "#music-lnowbar", "#music-l-drawer", s), nc(t.querySelector("#music-b-drawer"), "music.drawer_local", "music.tb_local"), nc(t.querySelector("#music-l-drawer"), "music.drawer_online", "music.tb_online");
  for (const n of [".music-search-wrap", "#music-avatar", "#music-acc", "#music-status"])
    A(t.querySelector(n), !ie);
  fn(t), Gc(t), t.querySelectorAll(".music-dual-btn").forEach((n) => n.classList.toggle("on", He));
}
function ni(t, e) {
  const i = t.querySelector("#music-status");
  f != null && f.client_id ? f.connected ? y ? y.active ? y.playing ? M(i, a("music.status_playing")) : M(i, a("music.status_paused")) : M(i, a("music.status_no_device")) : M(i, a("music.status_connecting")) : M(i, a("music.status_disconnected")) : M(i, a("music.status_unconfigured"));
  const s = t.querySelector("#music-avatar");
  if (s) {
    const c = f != null && f.connected && f.avatar || "";
    C(s, c ? `<img src="${o(c)}" alt="">` : "");
  }
  M(t.querySelector("#music-acc"), f != null && f.connected && f.display_name || "");
  const n = t.querySelector("#music-devices-btn");
  n && (de(n, "title", `${a("music.devices")}：${(y == null ? void 0 : y.device) || a("music.device_none")}`), n.classList.toggle("warn", !!(f != null && f.connected) && !(y != null && y.active)));
}
function ti(t) {
  A(t.querySelector("#music-setup"), !(f != null && f.connected) || fs), A(t.querySelector("#music-body"), !!(f != null && f.connected) || ie), Kt(t), Ie(t), f != null && f.connected && (vl(t, we), bl(t));
  const e = ps ?? !(f != null && f.builtin);
  A(t.querySelector("#music-setup-fields"), e), A(t.querySelector("#music-save"), e);
  const i = t.querySelector("#music-fields-toggle");
  A(i, !!(f != null && f.builtin)), M(i, a(e ? "music.hide_fields" : "music.use_own_client_id")), M(
    t.querySelector("#music-setup-hint"),
    f != null && f.builtin ? a("music.setup_builtin") : a("music.setup_hint")
  );
  const s = t.querySelector("#music-client-id"), n = t.querySelector("#music-port"), c = t.querySelector("#music-librespot"), r = t.querySelector("#music-librespot-proxy");
  s && document.activeElement !== s && (s.value = (f == null ? void 0 : f.client_id) ?? ""), n && document.activeElement !== n && (n.value = String((f == null ? void 0 : f.port) ?? 8899)), c && document.activeElement !== c && (c.value = (f == null ? void 0 : f.librespot_path) ?? ""), r && document.activeElement !== r && (r.value = (f == null ? void 0 : f.librespot_proxy) ?? "");
  const p = Ci ?? (f == null ? void 0 : f.librespot_bitrate) ?? 320;
  for (const _ of t.querySelectorAll("#music-quality .music-seg-btn"))
    de(_, "aria-pressed", String(Number(_.dataset.q) === p));
  M(t.querySelector("#music-redirect"), (f == null ? void 0 : f.redirect_uri) ?? "");
}
function ac(t) {
  const e = a(`music.tk_${t}`);
  return e.startsWith("music.") ? t : e;
}
function cc(t) {
  return Number.isFinite(t) ? Math.min(2e4, Math.max(20, t)) : 1e3;
}
function lc(t) {
  return Number.isFinite(t) ? Math.min(24, Math.max(-24, t)) : 0;
}
function X(t, e = 3) {
  return t === void 0 || !Number.isFinite(t) ? "" : String(Math.round(t * 10 ** e) / 10 ** e);
}
function Xs(t, e) {
  return e === "freq_hz" ? X(t.freq_hz, 1) : e === "gain_db" ? X(t.gain_db ?? 0, 1) : e === "q" ? X(t.q ?? 0.707, 3) : "";
}
async function Ct(t) {
  let e;
  try {
    e = await d("player_tuning_get");
  } catch (i) {
    $(t, R(i));
    return;
  }
  JSON.stringify(e) !== JSON.stringify(b) && (b = e, xi(), Se = -1), await qu(), he(t);
}
function Yc(t) {
  const e = t.querySelector("#music-tune-measure");
  e && e.disabled !== $t && (e.disabled = $t), de(e, "aria-busy", String($t));
  const i = t.querySelector("#music-tune-probe-hint");
  if (!i) return;
  if ($t) {
    M(i, a("music.tuning_measuring"));
    return;
  }
  const s = rt;
  if (!s) {
    M(i, a("music.tuning_probe_hint"));
    return;
  }
  const n = (p, _) => {
    let x = 0, w = 0;
    for (let E = 0; E < p.length && E < _.length; E++)
      x += p[E] - _[E], w += 1;
    return w > 0 ? x / w : 0;
  }, c = n(s.chain_db ?? [], s.ref_db), r = n(s.db, s.chain_db ?? []);
  M(
    i,
    a("music.tuning_probe_result", {
      cov: String(Math.round(s.coverage * 100)),
      dev: `${c >= 0 ? "+" : ""}${c.toFixed(1)}`,
      sys: `${r >= 0 ? "+" : ""}${r.toFixed(1)}`,
      ms: String(s.elapsed_ms)
    })
  );
}
function _u(t) {
  if (!b) return;
  const e = b.user_presets ?? [], i = t.querySelector("#music-tuning-user-presets");
  i && C(
    i,
    e.map((r) => {
      const p = b.preset === r;
      return `<div class="music-preset-user" data-preset="${o(r)}" aria-pressed="${p}"><button type="button" class="music-preset-item" data-act="use">${o(r)}</button><button type="button" class="music-preset-icon" data-act="rename" title="${o(a("music.tuning_preset_rename"))}">✎</button><button type="button" class="music-preset-icon" data-act="delete" title="${o(a("music.tuning_preset_delete"))}">✕</button></div>`;
    }).join("")
  );
  const s = ot;
  if (A(t.querySelector("#music-tuning-preset-edit"), s !== null), !s) return;
  const n = s.mode === "delete";
  M(
    t.querySelector("#music-preset-edit-hint"),
    s.mode === "save" ? a("music.tuning_preset_save_prompt") : s.mode === "rename" ? a("music.tuning_preset_rename_prompt", { name: s.from }) : a("music.tuning_preset_delete_confirm", { name: s.name })
  );
  const c = t.querySelector("#music-preset-name");
  A(c, !n), c && c !== document.activeElement && c.value !== s.name && (c.value = s.name), M(
    t.querySelector("#music-preset-ok"),
    s.mode === "save" ? s.overwrite ? a("music.tuning_preset_overwrite") : a("music.tuning_preset_ok") : s.mode === "rename" ? a("music.tuning_preset_rename") : a("music.tuning_preset_delete")
  );
}
function wu(t) {
  return t === 0 ? a("music.tuning_slot_global") : Dc[t - 1] ?? `#${t}`;
}
function ku(t) {
  const e = t.querySelector("#music-tune-slots");
  e && C(
    e,
    Vt.map((i, s) => {
      const n = wu(s), c = i.filter((r) => r.on).length;
      return `<button type="button" class="music-seg-btn music-slot-btn" data-slot="${s}" aria-pressed="${s === Xe}" title="${o(n)}">${o(n)}<em>${c}</em></button>`;
    }).join("")
  );
}
function Su(t, e) {
  e === Xe || e < 0 || e >= Vt.length || (Xe = e, se = Vt[e], Se = -1, he(t));
}
function uc(t) {
  return Dc[t] ?? "#" + (t + 1);
}
function Kc(t) {
  const e = t.querySelector("#music-copy-list");
  if (!e) return;
  const i = Math.max(1, (b == null ? void 0 : b.channels) || 2);
  C(
    e,
    Ft.map((s, n) => {
      const c = (ee == null ? void 0 : ee.row) === n ? ee.side : null, r = (_) => c === _ ? `<div class="music-tune-menu">${Array.from({ length: i }, (x, w) => {
        const E = (_ === "from" ? s.from : s.to) === w;
        return `<button type="button" class="music-seg-btn" data-act="pick" data-i="${n}" data-side="${_}" data-ch="${w}" aria-pressed="${E}">${o(uc(w))}</button>`;
      }).join("")}</div>` : "", p = (_, x) => `<button type="button" class="music-tune-kind" data-act="menu" data-i="${n}" data-side="${_}" aria-expanded="${c === _}"><span>${o(uc(x))}</span>${v.chevron}</button>`;
      return `<div class="music-copy-row" data-i="${n}">
        ${p("from", s.from)}<span class="music-copy-arrow">→</span>${p("to", s.to)}
        <button type="button" class="music-tune-del" data-act="del" data-i="${n}" title="${o(a("music.tuning_del"))}">${v.trash}</button>
        ${r("from")}${r("to")}
      </div>`;
    }).join("")
  ), A(t.querySelector("#music-copy-empty"), Ft.length === 0);
}
function $u(t) {
  const e = Xe === 0;
  if (A(t.querySelector("#music-tune-delay"), e), A(t.querySelector("#music-tune-copy"), e), A(t.querySelector("#music-tune-conv"), e), !e || hi) return;
  const i = t.querySelector("#music-delay-num");
  i && document.activeElement !== i && i.value !== X(Le, 1) && (i.value = X(Le, 1));
  const s = t.querySelector("#music-delay-range");
  s && s.value !== String(Le) && (s.value = String(Le)), Kc(t), M(t.querySelector("#music-conv-path"), vi ?? a("music.tuning_conv_none")), A(t.querySelector("#music-conv-clear"), vi !== null);
}
function Zs(t, e, i, s) {
  const n = t.querySelector(e);
  n && n.value !== X(s, 1) && (n.value = X(s, 1));
  const c = t.querySelector(i);
  c && document.activeElement !== c && c.value !== X(s, 1) && (c.value = X(s, 1));
}
async function qu() {
  try {
    je = await d("player_tuning_ab_state");
  } catch {
    je = { a: !1, b: !1 };
  }
}
function ts(t) {
  var s;
  for (const n of [1, 2]) {
    const c = t.querySelector(`#music-ab-pos${n}`);
    if (!c) continue;
    const r = bi[n - 1], p = r === "a" ? je.a : je.b;
    c.dataset.ab = r, c.textContent = qt ? String(n) : r.toUpperCase(), c.disabled = !p, c.classList.toggle("active", p && kn === r);
  }
  const e = t.querySelector("#music-ab-blind");
  e && (e.classList.toggle("active", qt), e.disabled = !(je.a && je.b)), (s = t.querySelector("#music-ab-reveal")) == null || s.classList.toggle("hidden", !qt || Ni);
  const i = t.querySelector("#music-ab-hint");
  i && (i.textContent = xu());
}
function xu() {
  return !je.a && !je.b ? a("music.tuning_ab_empty") : qt ? Ni ? a("music.tuning_ab_revealed", {
    one: bi[0].toUpperCase(),
    two: bi[1].toUpperCase()
  }) : a("music.tuning_ab_blind_hint") : a("music.tuning_ab_hint", {
    a: je.a ? "A" : "—",
    b: je.b ? "B" : "—"
  });
}
async function oc(t, e) {
  try {
    je = await d("player_tuning_ab_save", { slot: e }), $(t, a(e === "a" ? "music.tuning_ab_saved_a" : "music.tuning_ab_saved_b"));
  } catch (i) {
    $(t, R(i));
  }
  ts(t);
}
async function Lu(t, e) {
  const i = bi[e - 1];
  if (i) {
    try {
      await d("player_tuning_ab_apply", { slot: i }), kn = i, await Ct(t);
    } catch (s) {
      $(t, R(s));
    }
    ts(t);
  }
}
function he(t) {
  b && (de(t.querySelector("#music-tuning-on"), "aria-checked", String(b.enabled)), Yc(t), _u(t), ts(t), Zs(t, "#music-preamp-range", "#music-tune-preamp", Ui), Zs(t, "#music-bass-range", "#music-tune-bass", Vi), Zs(t, "#music-treble-range", "#music-tune-treble", Gi), ku(t), Jc(t), $u(t), Zc(t), M(
    t.querySelector("#music-tune-rate"),
    a("music.tuning_rate", { rate: X(b.response.sample_rate / 1e3, 1) })
  ));
}
function Eu(t, e, i, s) {
  const n = i.find((z) => z.name === t.kind), c = n ? n.gain : t.gain_db !== void 0, r = n ? n.order !== 1 : t.q !== void 0, p = t.gain_db ?? 0, _ = `<input type="text" class="music-tune-num music-band-freq" data-f="freq_hz" inputmode="decimal" autocomplete="off" spellcheck="false" value="${o(X(t.freq_hz, 1))}" aria-label="${o(a("music.tuning_freq"))}" />`, x = c ? `<input type="range" class="music-tune-vslider" data-f="gain_db" min="-24" max="24" step="0.5" value="${o(X(p, 1))}" aria-label="${o(a("music.tuning_gain"))}" />` : '<div class="music-tune-vslider-na"></div>', w = c ? `<input type="text" class="music-tune-num music-band-gain" data-f="gain_db" inputmode="decimal" autocomplete="off" spellcheck="false" value="${o(X(p, 1))}" aria-label="${o(a("music.tuning_gain"))}" />` : '<span class="music-band-gain na">—</span>', E = r ? `<input type="text" class="music-tune-num music-band-q" data-f="q" inputmode="decimal" autocomplete="off" spellcheck="false" value="${o(X(t.q ?? 0.707, 3))}" aria-label="${o(a("music.tuning_q"))}" />` : "", T = s ? `<div class="music-tune-menu">${i.map(
    (z) => `<button type="button" class="music-seg-btn" data-act="pick" data-kind="${o(z.name)}" aria-pressed="${z.name === t.kind}">${o(ac(z.name))}</button>`
  ).join("")}</div>` : "";
  return `<div class="music-tune-band music-tune-row${t.on ? "" : " off"}" data-i="${e}">
      ${_}
      ${x}
      ${w}
      ${E}
      <div class="music-band-foot">
        <button type="button" class="music-tune-kind" data-act="kind" aria-expanded="${s}"><span>${o(ac(t.kind))}</span>${v.chevron}</button>
        <button type="button" class="music-tune-sw" data-act="on" aria-pressed="${t.on}" title="${o(t.on ? a("music.tuning_off") : a("music.tuning_on"))}">${v.power}</button>
        <button type="button" class="music-tune-del" data-act="del" title="${o(a("music.tuning_del"))}">${v.trash}</button>
      </div>
      ${T}
    </div>`;
}
function Jc(t) {
  if (hi) return;
  const e = t.querySelector("#music-tuning-filters");
  if (!e || !b || e.contains(document.activeElement)) return;
  const i = b.kinds;
  C(e, se.map((s, n) => Eu(s, n, i, Se === n)).join(""));
}
function rc(t, e, i) {
  const s = wn;
  if (!s) return null;
  const n = t.getBoundingClientRect(), c = s.w / (n.width || s.w), r = s.h / (n.height || s.h), p = (e - n.left) * c, _ = (i - n.top) * r, x = Math.log10(20), w = Math.log10(2e4), E = (p - s.padL) / s.plotW, T = 10 ** (x + E * (w - x)), z = s.span - (_ - s.padT) / s.plotH * (2 * s.span);
  return { f: T, db: z, x: p, y: _ };
}
function Xc(t, e, i) {
  const s = Math.log10(20), n = Math.log10(2e4), c = t.padL + (Math.log10(Math.max(1, e)) - s) / (n - s) * t.plotW, r = t.padT + (t.span - i) / (2 * t.span) * t.plotH;
  return { x: c, y: r };
}
let ai = 1;
function Zc(t) {
  const e = t.querySelector("#music-tune-canvas");
  e && (e.style.width = `${ai * 100}%`), M(t.querySelector("#music-tune-zoom-label"), `${Math.round(ai * 100)}%`), As(t);
}
function As(t) {
  var Ge;
  const e = t.querySelector("#music-tune-canvas");
  if (!e || !b) return;
  const i = e.clientWidth || e.width, s = e.clientHeight || e.height;
  if (i < 2 || s < 2) return;
  const n = window.devicePixelRatio || 1;
  (e.width !== Math.round(i * n) || e.height !== Math.round(s * n)) && (e.width = Math.round(i * n), e.height = Math.round(s * n));
  const c = e.getContext("2d");
  if (!c) return;
  c.setTransform(n, 0, 0, n, 0, 0), c.clearRect(0, 0, i, s);
  const r = getComputedStyle(t), p = r.getPropertyValue("--accent").trim() || "#7aa2f7", _ = r.getPropertyValue("--border-glass").trim() || "rgba(255,255,255,0.12)", x = r.getPropertyValue("--text-dim").trim() || "rgba(255,255,255,0.55)", { freqs: w } = b.response, E = Zl(), T = 30, z = 8, j = 8, be = 16, Ve = Math.max(1, i - T - z), Ne = Math.max(1, s - j - be);
  let Pe = 0;
  for (const L of E) Number.isFinite(L) && (Pe = Math.max(Pe, Math.abs(L)));
  for (const L of (rt == null ? void 0 : rt.db) ?? [])
    Number.isFinite(L) && (Pe = Math.max(Pe, Math.abs(L)));
  const ye = Math.min(60, Math.max(12, Math.ceil((Pe + 1) / 6) * 6)), nt = Math.log10(20), Ei = Math.log10(2e4), bt = (L) => T + (Math.log10(Math.max(1, L)) - nt) / (Ei - nt) * Ve, Oe = (L) => j + (ye - L) / (2 * ye) * Ne, yt = { w: i, h: s, padL: T, padT: j, plotW: Ve, plotH: Ne, span: ye };
  wn = yt, c.lineWidth = 1, c.font = "9px system-ui, -apple-system, sans-serif", c.textBaseline = "middle";
  for (const L of [ye, ye / 2, 0, -ye / 2, -ye])
    c.strokeStyle = _, c.globalAlpha = L === 0 ? 0.9 : 0.45, c.setLineDash(L === 0 ? [] : [3, 3]), c.beginPath(), c.moveTo(T, Oe(L)), c.lineTo(T + Ve, Oe(L)), c.stroke();
  c.setLineDash([]), c.fillStyle = x;
  for (const L of [20, 100, 1e3, 1e4, 2e4]) {
    const W = bt(L);
    c.globalAlpha = 0.45, c.strokeStyle = _, c.beginPath(), c.moveTo(W, j), c.lineTo(W, j + Ne), c.stroke(), c.globalAlpha = 0.9, c.textAlign = L === 20 ? "left" : L === 2e4 ? "right" : "center", c.fillText(L >= 1e3 ? `${L / 1e3}k` : String(L), W, j + Ne + 8);
  }
  c.textAlign = "right";
  for (const L of [ye, ye / 2, 0, -ye / 2, -ye])
    c.globalAlpha = 0.9, c.fillStyle = x, c.fillText(`${L > 0 ? "+" : ""}${X(L, 0)}`, T - 3, Oe(L));
  if (c.textAlign = "left", c.globalAlpha = 1, w.length >= 2 && E.length === w.length) {
    c.beginPath();
    for (let L = 0; L < w.length; L++) {
      const W = bt(w[L]), pe = Oe(E[L]);
      L === 0 ? c.moveTo(W, pe) : c.lineTo(W, pe);
    }
    c.lineTo(bt(w[w.length - 1]), Oe(0)), c.lineTo(bt(w[0]), Oe(0)), c.closePath(), c.globalAlpha = 0.12, c.fillStyle = p, c.fill(), c.globalAlpha = 1, c.beginPath();
    for (let L = 0; L < w.length; L++) {
      const W = bt(w[L]), pe = Oe(E[L]);
      L === 0 ? c.moveTo(W, pe) : c.lineTo(W, pe);
    }
    c.strokeStyle = p, c.lineWidth = 1.5, c.stroke();
  }
  const me = rt;
  if (me && me.freqs.length >= 2) {
    const L = r.getPropertyValue("--green").trim() || "#8fc99a", W = r.getPropertyValue("--blue").trim() || "#9490b4", pe = (Be, at, It, Ti) => {
      if (!(Be.length < 2)) {
        c.save(), c.beginPath(), c.rect(T, j, Ve, Ne), c.clip(), c.beginPath();
        for (let Z = 0; Z < me.freqs.length && Z < Be.length; Z++) {
          const ct = bt(me.freqs[Z]), gt = Oe(Be[Z]);
          Z === 0 ? c.moveTo(ct, gt) : c.lineTo(ct, gt);
        }
        c.setLineDash(at), c.strokeStyle = It, c.lineWidth = Ti, c.stroke(), c.setLineDash([]), c.restore();
      }
    };
    pe(me.db, [1.5, 3], W, 1.2), pe(me.chain_db ?? [], [5, 3], L, 1.5);
  }
  if (se.length > 0) {
    c.save(), c.font = "9px system-ui, -apple-system, sans-serif", c.textAlign = "center", c.textBaseline = "middle";
    for (let L = 0; L < se.length; L++) {
      const W = se[L], pe = ((Ge = b.kinds.find((Ti) => Ti.name === W.kind)) == null ? void 0 : Ge.gain) ?? W.gain_db !== void 0, { x: Be, y: at } = Xc(yt, W.freq_hz, pe ? W.gain_db ?? 0 : 0), It = L === ei;
      c.globalAlpha = W.on ? 1 : 0.4, c.beginPath(), pe ? c.arc(Be, at, It ? 6 : 4.5, 0, Math.PI * 2) : (c.moveTo(Be, at - 5), c.lineTo(Be + 5, at + 3), c.lineTo(Be - 5, at + 3), c.closePath()), c.fillStyle = It ? p : "rgba(0,0,0,0.65)", c.fill(), c.strokeStyle = p, c.lineWidth = 1.5, c.stroke(), pe && L < 9 && (c.globalAlpha = 1, c.fillStyle = It ? "rgba(0,0,0,0.8)" : p, c.fillText(String(L + 1), Be, at + 0.5));
    }
    c.globalAlpha = 1, c.restore();
  }
}
function Tu(t, e, i) {
  t.kind = e;
  const s = i.find((n) => n.name === e);
  s && (s.gain ? t.gain_db === void 0 && (t.gain_db = 0) : delete t.gain_db, s.order === 1 ? delete t.q : t.q === void 0 && (t.q = 0.707));
}
async function ce(t, e = !1) {
  var x, w, E;
  const i = ++ft, s = document.activeElement, n = (x = s == null ? void 0 : s.closest) == null ? void 0 : x.call(s, ".music-tune-row"), c = s instanceof HTMLInputElement && s.type === "text" ? s.dataset.f : void 0, r = n ? Number(n.dataset.i) : -1, p = s instanceof HTMLInputElement && s.type === "text" && !n ? s.id : "";
  let _;
  try {
    _ = await d("player_tuning_set_chain", {
      preampDb: Ui,
      // 低音 / 高音快捷增益：引擎不认识它们，宿主会追加成 low_shelf / high_shelf 两条。
      bassDb: Vi,
      trebleDb: Gi,
      // ⚠️ **全局槽 = `tuneSlotDrafts[0]`，不是 `tuneFilters`**（P5-2）：后者是「表正在编辑
      // 的那一份」，用户停在某个通道槽时它指的是那条声道 —— 拿它当全局发会把通道的段搬进全局。
      filters: Vt[0],
      // 新效果器全部**走草稿**（它们现在都有界面了：P5-3 图示均衡器 / P5-4 延迟 + 复制 + 卷积）。
      // 宿主那条命令的语义是「**覆盖整条链**」⇒ 少发一样就等于把它清掉。
      graphicEq: Bc,
      delayMs: Le,
      channelCopy: Ft,
      convolution: vi,
      // 通道段由**全部槽的草稿**拼（P5-2）—— 不是把宿主那份原样回传：用户这会儿
      // 可能正在某个通道槽里改，那份改动就在 `tuneSlotDrafts` 里。
      ifElse: eu()
    });
  } catch (T) {
    if (i !== ft) return;
    $(t, R(T)), await Ct(t);
    return;
  }
  i === ft && (b = _, xi(), e || $(t, a("music.tuning_saved")), he(t), c && r >= 0 && r < se.length ? (w = t.querySelector(`.music-tune-row[data-i="${r}"] input[type="text"][data-f="${c}"]`)) == null || w.focus() : p && ((E = t.querySelector(`#${p}`)) == null || E.focus()));
}
async function Mu(t, e) {
  const i = ++ft;
  let s;
  try {
    s = await d("player_tuning_set_enabled", { enabled: e });
  } catch (n) {
    if (i !== ft) return;
    $(t, R(n)), await Ct(t);
    return;
  }
  i === ft && (b = s, xi(), $(t, a("music.tuning_saved")), he(t));
}
async function Cu(t, e) {
  const i = ++ft;
  let s;
  try {
    s = await d("player_tuning_set", { enabled: !0, preset: e });
  } catch (n) {
    if (i !== ft) return;
    $(t, R(n)), await Ct(t);
    return;
  }
  i === ft && (b = s, xi(), Se = -1, rt = null, $(t, a("music.tuning_saved")), he(t));
}
async function dc(t) {
  var s;
  const e = ot;
  if (!e) return;
  const i = e.mode === "delete" ? e.name : (((s = t.querySelector("#music-preset-name")) == null ? void 0 : s.value) ?? "").trim();
  if (e.mode !== "delete" && !i) {
    $(t, a("music.tuning_preset_name_empty"));
    return;
  }
  try {
    e.mode === "save" ? (b = await d("player_tuning_preset_save", { name: i, overwrite: e.overwrite }), $(t, a("music.tuning_preset_saved", { name: i }))) : e.mode === "rename" ? (b = await d("player_tuning_preset_rename", { from: e.from, to: i }), $(t, a("music.tuning_preset_renamed", { name: i }))) : (b = await d("player_tuning_preset_delete", { name: i }), $(t, a("music.tuning_preset_deleted", { name: i }))), ot = null, xi(), he(t);
  } catch (n) {
    const c = R(n);
    if (c.includes("ERR_PRESET_EXISTS")) {
      e.mode === "save" ? (ot = { mode: "save", name: i, overwrite: !0 }, he(t)) : $(t, a("music.tuning_preset_exists", { name: i }));
      return;
    }
    $(t, c);
  }
}
async function Au(t) {
  let e;
  try {
    e = await ss({
      multiple: !1,
      filters: [{ name: "Lunac preset", extensions: ["json"] }]
    });
  } catch (i) {
    $(t, R(i));
    return;
  }
  if (typeof e == "string")
    try {
      b = await d("player_tuning_preset_import", { path: e }), xi(), Se = -1, rt = null, he(t), $(t, a("music.tuning_preset_imported", { name: b.preset }));
    } catch (i) {
      $(t, R(i));
    }
}
async function Iu(t) {
  let e;
  try {
    e = await ss({
      multiple: !1,
      filters: [{ name: "WAV", extensions: ["wav"] }]
    });
  } catch (i) {
    $(t, R(i));
    return;
  }
  typeof e == "string" && (vi = e, await ce(t));
}
async function Du(t) {
  if (!b) return;
  const e = b.preset && b.preset !== "custom" ? b.preset : "lunac-chain";
  let i;
  try {
    i = await Il({
      defaultPath: `${e}.json`,
      filters: [{ name: "Lunac preset", extensions: ["json"] }]
    });
  } catch (s) {
    $(t, R(s));
    return;
  }
  if (typeof i == "string")
    try {
      await d("player_tuning_preset_export", { path: i }), $(t, a("music.tuning_preset_exported", { path: i }));
    } catch (s) {
      $(t, R(s));
    }
}
function ws(t) {
  const e = Date.now();
  if (e - vs >= 120) {
    vs = e, ce(t, !0);
    return;
  }
  Ys == null && (Ys = window.setTimeout(() => {
    Ys = null, vs = Date.now(), ce(t, !0);
  }, 120));
}
function en(t) {
  us != null && window.clearTimeout(us), us = window.setTimeout(() => {
    us = null, ce(t);
  }, Jl);
}
async function Ru(t) {
  if (!$t) {
    $t = !0, Yc(t);
    try {
      rt = await d("player_tuning_measure");
    } catch (e) {
      $(t, R(e));
    } finally {
      $t = !1, he(t);
    }
  }
}
function Nu(t) {
  const e = t.querySelector("#music-tune-canvas");
  if (!e) return;
  const i = (n, c, r) => {
    var T;
    const p = rc(n, c, r), _ = wn;
    if (!p || !_) return null;
    let x = -1, w = 14;
    for (let z = 0; z < se.length; z++) {
      const j = se[z], be = ((T = b == null ? void 0 : b.kinds.find((Pe) => Pe.name === j.kind)) == null ? void 0 : T.gain) ?? j.gain_db !== void 0, Ve = Xc(_, j.freq_hz, be ? j.gain_db ?? 0 : 0), Ne = Math.hypot(Ve.x - p.x, Ve.y - p.y);
      Ne < w && (w = Ne, x = z);
    }
    const E = p.x >= _.padL - 6 && p.x <= _.padL + _.plotW + 6 && p.y >= _.padT - 6 && p.y <= _.padT + _.plotH + 6;
    return { p, idx: x, inside: E };
  };
  e.addEventListener("pointerdown", (n) => {
    const c = n.currentTarget, r = i(c, n.clientX, n.clientY);
    if (!r) return;
    let p = r.idx;
    Mi = !1, !(p < 0 && !r.inside) && (p < 0 && (se.push({
      kind: "peaking",
      freq_hz: cc(r.p.f),
      gain_db: lc(r.p.db),
      q: 0.707,
      on: !0
    }), p = se.length - 1, Se = -1, Mi = !0), ei = p, hi = !0, c.setPointerCapture(n.pointerId), As(t), n.preventDefault());
  }), e.addEventListener("pointermove", (n) => {
    var E;
    if (ei < 0) return;
    const c = n.currentTarget, r = se[ei], p = rc(c, n.clientX, n.clientY);
    if (!r || !p) return;
    const _ = ((E = b == null ? void 0 : b.kinds.find((T) => T.name === r.kind)) == null ? void 0 : E.gain) ?? r.gain_db !== void 0, x = cc(p.f), w = lc(p.db);
    (x !== r.freq_hz || _ && w !== r.gain_db) && (Mi = !0), r.freq_hz = x, _ && (r.gain_db = w), As(t), ws(t), n.preventDefault();
  });
  const s = (n) => {
    var p;
    if (ei < 0) return;
    const c = n.currentTarget, r = Mi;
    ei = -1, Mi = !1, hi = !1, (p = c.hasPointerCapture) != null && p.call(c, n.pointerId) && c.releasePointerCapture(n.pointerId), vs = 0, r && ce(t);
  };
  e.addEventListener("pointerup", s), e.addEventListener("pointercancel", s);
}
function el(t) {
  var s, n, c, r, p;
  (s = t.querySelector("#music-tune-measure")) == null || s.addEventListener("click", () => {
    Ru(t);
  });
  const e = (_, x) => {
    const w = t.querySelector("#music-tune-scroll"), E = t.querySelector("#music-tune-canvas");
    if (!w || !E) return;
    const T = E.getBoundingClientRect(), z = T.width > 0 ? (_ - T.left) / T.width : 0.5, j = Math.min(3, Math.max(1, Math.round(x * 100) / 100));
    if (j === ai) return;
    ai = j, Zc(t);
    const be = E.getBoundingClientRect();
    w.scrollLeft += be.left + z * be.width - _;
  }, i = (_) => {
    const x = t.querySelector("#music-tune-scroll");
    if (!x) return;
    const w = x.getBoundingClientRect();
    e(w.left + w.width / 2, ai + _);
  };
  (n = t.querySelector("#music-tune-zoom-in")) == null || n.addEventListener("click", () => i(0.25)), (c = t.querySelector("#music-tune-zoom-out")) == null || c.addEventListener("click", () => i(-0.25)), (r = t.querySelector("#music-tune-scroll")) == null || r.addEventListener(
    "wheel",
    (_) => {
      _.preventDefault(), e(_.clientX, ai + (_.deltaY < 0 ? 0.2 : -0.2));
    },
    { passive: !1 }
  ), Nu(t), (p = t.querySelector("#music-tune-slots")) == null || p.addEventListener("click", (_) => {
    const x = _.target.closest("[data-slot]");
    x && Su(t, Number(x.dataset.slot));
  });
}
let ji;
const mc = 1200;
function vn() {
  ji !== void 0 && (window.clearTimeout(ji), ji = void 0);
}
let mi;
const pc = 1200;
function qn() {
  mi !== void 0 && (window.clearTimeout(mi), mi = void 0);
}
function Pu(t) {
  if (mi !== void 0) return;
  const e = async () => {
    if (!t.isConnected || D !== "tuning") {
      qn();
      return;
    }
    await Ct(t), t.isConnected && D === "tuning" && (mi = window.setTimeout(() => void e(), pc));
  };
  mi = window.setTimeout(() => void e(), pc);
}
async function Ou(t) {
  vn(), rt = null, $t = !1, el(t), await Ct(t);
  const e = async () => {
    if (!t.isConnected) {
      vn();
      return;
    }
    await Ct(t), t.isConnected && (ji = window.setTimeout(() => void e(), mc));
  };
  ji = window.setTimeout(() => void e(), mc);
}
async function Bu(t) {
  try {
    await d("open_plugin_window", { pluginId: "music", key: Ac, input: "" });
  } catch (e) {
    $(t, R(e));
  }
}
function zu(t) {
  var e;
  return !!t.uri && ((e = y == null ? void 0 : y.track) == null ? void 0 : e.uri) === t.uri;
}
function At(t, e) {
  const i = t == null ? void 0 : t.querySelector("#music-msg");
  !i || i.textContent === e || (i.textContent = e, St !== void 0 && (window.clearTimeout(St), St = void 0), e && (St = window.setTimeout(() => {
    i.textContent = "", St = void 0;
  }, Pc)));
}
function $(t, e) {
  At(t, e);
}
function Os(t, e, i, s = "", n = "") {
  const c = Xt[i], r = !!c && F[c].ids.has(t.uri);
  return `<button class="music-tr${zu(t) ? " playing" : ""}${r ? " sel" : ""}" data-act="${i}" data-uri="${o(t.uri)}"${s ? ` data-i="${o(s)}"` : ""}${n ? ` title="${o(n)}"` : ""}>
    <span class="music-tr-i">${e + 1}</span>
    <span class="music-tr-main">
      <span class="music-tr-n">${o(t.name || "?")}</span>
      <span class="music-tr-a">${o(t.artists || t.album)}</span>
    </span>
    <span class="music-tr-d">${Fi(t.duration_ms)}</span>
  </button>`;
}
function Bs(t) {
  return { id: t.id, uri: t.uri, name: t.name, cover: t.cover, subtitle: t.owner, total: t.total };
}
function ks(t, e) {
  const i = !!e.uri && (y == null ? void 0 : y.context_uri) === e.uri, s = (I == null ? void 0 : I.kind) === t && I.id === e.id, n = e.cover ? `<img src="${o(e.cover)}" alt="">` : "";
  return `<div class="music-pl${i ? " playing" : ""}${s ? " on" : ""}" data-uri="${o(e.uri)}">
    <button class="music-pl-btn" data-act="open" data-kind="${t}" data-id="${o(e.id)}" title="${o(e.name || "?")}">
      <span class="music-pl-cover">${n}</span>
      <span class="music-pl-main">
        <span class="music-pl-name">${o(e.name || "?")}</span>
        <span class="music-pl-sub">${o(e.subtitle)}</span>
      </span>
    </button>
  </div>`;
}
function Wu() {
  return `<div class="music-pl${(I == null ? void 0 : I.kind) === "top-tracks" ? " on" : ""}">
    <button class="music-pl-btn" data-act="open" data-kind="top-tracks" data-id="top-tracks" title="${o(a("music.top_tracks"))}">
      <span class="music-pl-cover music-pl-trend-cover">${v.trend}</span>
      <span class="music-pl-main">
        <span class="music-pl-name">${o(a("music.top_tracks"))}</span>
        <span class="music-pl-sub">${o(a("music.top_tracks_sub"))}</span>
      </span>
    </button>
  </div>`;
}
function Hu(t, e) {
  const i = e.cover ? `<img src="${o(e.cover)}" alt="">` : "";
  return `<button class="music-card" data-act="open" data-kind="${t}" data-id="${o(e.id)}" title="${o(e.name)}">
    <span class="music-card-cover${t === "artist" ? " round" : ""}">${i}</span>
    <span class="music-card-n">${o(e.name)}</span>
    <span class="music-card-s">${o(e.subtitle)}</span>
  </button>`;
}
function Fu() {
  const t = (I == null ? void 0 : I.kind) === "liked", e = J ? String(J.total) : "", i = jt || [(f == null ? void 0 : f.display_name) || "", e].filter(Boolean).join(" · ");
  return `<div class="music-pl music-pl-liked${t ? " on" : ""}${jt ? " err" : ""}">
    <button class="music-pl-btn" data-act="open" data-kind="liked" data-id="liked" title="${o(a("music.liked_songs"))}">
      <span class="music-pl-cover music-pl-liked-cover">${v.heart}</span>
      <span class="music-pl-main">
        <span class="music-pl-name">${o(a("music.liked_songs"))}</span>
        <span class="music-pl-sub">${o(i)}</span>
      </span>
    </button>
  </div>`;
}
function Kt(t) {
  if (ie) {
    De(t);
    return;
  }
  A(t.querySelector("#music-side-tabs"), !0), A(t.querySelector("#music-local-head"), !1), t.querySelectorAll("#music-side-tabs .music-tab").forEach((c) => {
    c.classList.toggle("on", c.dataset.tab === we);
  });
  const e = t.querySelector("#music-side-list");
  if (!e) return;
  if (!(f != null && f.connected)) {
    C(e, `<div class="music-empty">${a("music.playlists_login")}</div>`);
    return;
  }
  const i = gi.get(we), s = Yi.get(we);
  let n = we === "playlist" ? Fu() : we === "top" ? Wu() : "";
  if (Pi.has(we) ? n += `<div class="music-empty">${a("music.loading")}</div>` : s ? n += `<div class="music-empty music-empty-err">${o(s)}</div>` : i && (n += i.length === 0 ? `<div class="music-empty">${a(we === "playlist" ? "music.playlists_empty" : "music.lib_empty")}</div>` : i.map((c) => ks(we, c)).join("")), C(e, n), ke && P >= 0) {
    const c = P;
    requestAnimationFrame(() => {
      const r = e.querySelector(`[data-act="queue-play"][data-i="${c}"]`);
      r == null || r.scrollIntoView({ block: "nearest" });
    });
  }
}
function tn(t) {
  t.querySelectorAll("#music-side-list .music-pl").forEach((e) => {
    const i = e.querySelector(".music-pl-btn"), s = !!I && (i == null ? void 0 : i.dataset.kind) === I.kind && (i == null ? void 0 : i.dataset.id) === I.id;
    e.classList.toggle("on", s);
  });
}
function Ie(t) {
  if (ie) {
    Ut(t);
    return;
  }
  const e = t.querySelector("#music-main");
  if (!e) return;
  if (kt && Qe) {
    C(e, ju());
    return;
  }
  if (!I) {
    C(e, `<div class="music-empty">${f != null && f.connected ? a("music.pick_hint") : a("music.playlists_login")}</div>`);
    return;
  }
  const i = I.cover ? `<img src="${o(I.cover)}" alt="">` : "", s = I.kind === "liked" ? a("music.liked_songs") : I.kind === "top-tracks" ? a("music.top_tracks") : I.kind === "playlist" ? a("music.playlists") : I.kind === "album" ? a("music.tab_albums") : I.kind === "artist" ? a("music.tab_artists") : I.kind === "top" ? a("music.tab_top") : a("music.tab_shows");
  let n;
  li ? n = `<div class="music-empty">${a("music.loading")}</div>` : vt ? n = `<div class="music-empty music-empty-err">${o(vt)}</div>` : !Me || Me.length === 0 ? n = `<div class="music-empty">${a("music.playlist_empty")}</div>` : n = Me.map((c, r) => Os(c, r, "main-track", String(r))).join(""), C(e, `<div class="music-page">
    <div class="music-page-head">
      <span class="music-page-cover${I.kind === "artist" ? " round" : ""}">${i}</span>
      <div class="music-page-info">
        <span class="music-page-kind">${o(s)}</span>
        <span class="music-page-name">${o(I.name || "?")}</span>
        <span class="music-page-sub">${o(I.subtitle)}</span>
        <div class="music-page-actions">
          <button class="music-btn music-primary" data-act="main-play-all">${v.play} ${a("music.play_all")}</button>
        </div>
      </div>
    </div>
    <div class="music-list">${n}</div>
  </div>`);
}
function ju() {
  const t = Q, i = [
    ["tracks", a("music.tracks")],
    ["artists", a("music.tab_artists")],
    ["albums", a("music.tab_albums")],
    ["playlists", a("music.playlists")],
    ["shows", a("music.tab_shows")]
  ].map(([n, c]) => `<button class="music-tab${Ke === n ? " on" : ""}" data-act="search-tab" data-tab="${n}">${o(c)}</button>`).join("");
  let s;
  if (yi || !t)
    s = `<div class="music-empty">${a("music.loading")}</div>`;
  else if (Ke === "tracks")
    s = t.tracks.length ? t.tracks.map((n, c) => Os(n, c, "main-track", String(c))).join("") : `<div class="music-empty">${a("music.search_empty")}</div>`;
  else {
    const c = (Ke === "artists" ? t.artists : Ke === "albums" ? t.albums : Ke === "shows" ? t.shows : t.playlists.map(Bs)).map((r) => Hu(Ke === "playlists" ? "playlist" : Ke === "artists" ? "artist" : Ke === "albums" ? "album" : "show", r));
    s = c.length ? `<div class="music-grid">${c.join("")}</div>` : `<div class="music-empty">${a("music.search_empty")}</div>`;
  }
  return `<div class="music-page">
    <div class="music-page-info music-page-info-flat">
      <span class="music-page-kind">${a("music.search_result")}</span>
      <span class="music-page-name">${o(Qe)}</span>
    </div>
    <div class="music-tabs">${i}</div>
    <div class="music-list">${s}</div>
  </div>`;
}
function et(t) {
  const e = t.querySelector("#music-search-dd");
  if (!e) return;
  const i = !!(f != null && f.connected) && ze && !!Qe;
  if (A(e, i), !i) return;
  if (!Q) {
    C(e, yi ? `<div class="music-empty">${a("music.loading")}</div>` : "");
    return;
  }
  const s = Q, n = [];
  s.tracks.slice(0, 3).forEach((c, r) => n.push(Os(c, r, "dd-track"))), s.artists.slice(0, 2).forEach((c) => n.push(ks("artist", c))), s.albums.slice(0, 2).forEach((c) => n.push(ks("album", c))), s.playlists.slice(0, 2).forEach((c) => n.push(ks("playlist", Bs(c)))), n.length || n.push(`<div class="music-empty">${a("music.search_empty")}</div>`), n.push(`<button class="music-dd-all" data-act="search-all">${a("music.search_all")}</button>`), C(e, n.join(""));
}
function $i(t) {
  const e = t.querySelector("#music-dev-dd");
  if (!e || (A(e, ut), !ut)) return;
  const i = le;
  let s = `<div class="music-dd-head">${a("music.devices")}</div>`;
  i != null && i.available && !i.has_credentials ? s += `<button class="music-dev-row" data-act="local-login">
      <span class="music-dev-ico">${v.power}</span>
      <span class="music-dev-main">
        <span class="music-dev-n">${a("music.local_login")}</span>
        <span class="music-dev-s">${a("music.local_login_hint")}</span>
      </span>
    </button>` : i != null && i.available ? s += `<button class="music-dev-row${i.running ? " on" : ""}" data-act="local-toggle">
      <span class="music-dev-ico">${v.power}</span>
      <span class="music-dev-main">
        <span class="music-dev-n">${a("music.local_play")}</span>
        <span class="music-dev-s">${o(i.path || "")}</span>
      </span>
    </button>` : s += `<div class="music-dev-row disabled">
      <span class="music-dev-ico">${v.power}</span>
      <span class="music-dev-main">
        <span class="music-dev-n">${a("music.local_play")}</span>
        <span class="music-dev-s">${a("music.local_no_exe")}</span>
      </span>
    </div>`;
  const n = Gt ?? [];
  s += n.length ? n.map((c) => `<button class="music-dev-row${c.active ? " on" : ""}" data-act="dev-pick" data-id="${o(c.id)}">
        <span class="music-dev-ico">${v.speaker}</span>
        <span class="music-dev-main">
          <span class="music-dev-n">${o(c.name || "?")}</span>
          <span class="music-dev-s">${o(c.kind)}</span>
        </span>
      </button>`).join("") : `<div class="music-empty">${a("music.device_none")}</div>`, C(e, s);
}
function Qu(t) {
  var s;
  const e = (y == null ? void 0 : y.context_uri) ?? "", i = ((s = y == null ? void 0 : y.track) == null ? void 0 : s.uri) ?? "";
  t.querySelectorAll(".music-pl").forEach((n) => {
    n.classList.toggle("playing", !!e && n.dataset.uri === e);
  }), t.querySelectorAll(".music-tr").forEach((n) => {
    n.classList.toggle("playing", !!i && n.dataset.uri === i);
  });
}
function Uu(t) {
  if (!t) return "";
  const e = new Date(t), i = (s) => String(s).padStart(2, "0");
  return `${e.getFullYear()}-${i(e.getMonth() + 1)}-${i(e.getDate())} ${i(e.getHours())}:${i(e.getMinutes())}`;
}
function hn(t) {
  te && (We = !1);
  const e = (i, s) => A(t.querySelector(i), s);
  e("#music-local-add", !te), e("#music-local-list", !te), e("#music-local-del", te), e("#music-local-editdone", te), es(t), Ii(t);
}
function Ii(t) {
  const e = t.querySelector("#music-local-add-dd");
  e && (A(e, We), We && C(e, `
    <div class="music-dd-head">${o(a("music.local_add_head"))}</div>
    <button class="music-dev-row" data-act="media-add-dir">
      <span class="music-dev-ico">${v.folder}</span>
      <span class="music-dev-main">
        <span class="music-dev-n">${o(a("music.local_add_dir"))}</span>
        <span class="music-dev-s">${o(a("music.local_add_dir_hint"))}</span>
      </span>
    </button>
    <button class="music-dev-row" data-act="media-add-list">
      <span class="music-dev-ico">${v.list}</span>
      <span class="music-dev-main">
        <span class="music-dev-n">${o(a("music.local_open_playlist"))}</span>
        <span class="music-dev-s">${o(a("music.local_add_list_hint"))}</span>
      </span>
    </button>`));
}
function Vu(t) {
  const e = t.missing ? a("music.local_missing") : [
    a("music.local_n_tracks", { n: String(t.tracks) }),
    t.last_scan_at ? Uu(t.last_scan_at) : a("music.local_never_scanned")
  ].join(" · "), i = te && ve.has(t.path);
  return `<div class="music-pl${Ue === t.path ? " on" : ""}${t.missing ? " err" : ""}${i ? " sel" : ""}">
    <button class="music-pl-btn" data-act="media-root" data-path="${o(t.path)}" title="${o(t.path)}">
      <span class="music-pl-cover music-pl-dir">${v.folder}</span>
      <span class="music-pl-main">
        <span class="music-pl-name">${o(t.name || t.path)}</span>
        <span class="music-pl-sub">${o(e)}</span>
      </span>
    </button>
  </div>`;
}
function De(t) {
  A(t.querySelector("#music-side-tabs"), !1), A(t.querySelector("#music-local-head"), !0), hn(t);
  const e = t.querySelector("#music-side-list");
  if (!e) return;
  const i = (ne ?? []).filter((c) => !Ki.has(c.path)), s = i.reduce((c, r) => c + r.tracks, 0);
  let n = `<div class="music-pl${Ue === "" ? " on" : ""}">
    <button class="music-pl-btn" data-act="media-root" data-path="" title="${o(a("music.local_all"))}">
      <span class="music-pl-cover music-pl-dir">${v.note}</span>
      <span class="music-pl-main">
        <span class="music-pl-name">${o(a("music.local_all"))}</span>
        <span class="music-pl-sub">${o(a("music.local_n_tracks", { n: String(s) }))}</span>
      </span>
    </button>
  </div>`;
  Ms ? n += `<div class="music-empty">${a("music.loading")}</div>` : _i ? n += `<div class="music-empty music-empty-err">${o(_i)}</div>` : ne && i.length === 0 ? n += `<div class="music-empty">${o(a("music.local_no_roots"))}</div>` : ne && (n += i.map((c) => Vu(c)).join("")), n += Yu(), C(e, n);
}
function Gu(t) {
  const e = t.id === G, i = te && F.queueList.ids.has(t.id), s = t.name || a("music.local_queue_edit");
  return `<div class="music-pl${e ? " on" : ""}${i ? " sel" : ""}">
    <button class="music-pl-btn" data-act="local-queue" data-qid="${o(t.id)}" title="${o(s)}">
      <span class="music-pl-cover music-pl-dir">${v.list}</span>
      <span class="music-pl-main">
        <span class="music-pl-name">${o(s)}</span>
        <span class="music-pl-sub">${o(a("music.local_n_tracks", { n: String(t.items.length) }))}</span>
      </span>
    </button>
  </div>`;
}
function Yu() {
  const t = Ae.filter((e) => !mt.has(e.id)).map(Gu).join("");
  return `<div class="music-lqs">
    <div class="music-lqs-head">${o(a("music.local_queue_edit"))}</div>
    ${t}
  </div>`;
}
function xn(t, e, i = "local-track") {
  const s = t.cover ? `<img src="${o(Ns(t.cover))}" alt="">` : `<span class="music-mt-ico">${v.note}</span>`, n = [t.artist, t.album].filter(Boolean).join(" · "), c = !!(S != null && S.active) && S.path === t.path, r = Xt[i], p = !!r && F[r].ids.has(t.path), w = (i === "local-track" || i === "queue-track") && (U || te && G !== null) ? `<span class="music-mt-i music-mt-check${p ? " on" : ""}">${p ? v.check : ""}</span>` : `<span class="music-mt-i">${e + 1}</span>`, E = `<button class="music-mt${c ? " playing" : ""}${p ? " sel" : ""}" data-act="${i}" data-i="${e}" data-path="${o(t.path)}" title="${o(t.path)}">
    ${w}
    <span class="music-mt-cover">${s}</span>
    <span class="music-mt-main">
      <span class="music-mt-n">${o(t.title || "?")}</span>
      <span class="music-mt-a">${o(n)}</span>
    </span>
    <span class="music-mt-d">${Fi(t.duration_ms)}</span>
  </button>`;
  if (i !== "queue-play") return E;
  const T = a("music.play_queue_remove");
  return `<div class="music-mt-wrap">${E}<button type="button" class="music-mt-x" data-act="queue-remove" data-i="${e}" title="${o(T)}" aria-label="${o(T)}">${v.x}</button></div>`;
}
function Ut(t) {
  const e = t.querySelector("#music-main");
  if (!e) return;
  if (G !== null) {
    e.querySelector("#music-queue-page") || (ic(t), e.innerHTML = Zu());
    const s = t.querySelector("#music-lq-q");
    s && s.value !== Je && (s.value = Je), zs(t), fn(t), es(t);
    return;
  }
  e.querySelector("#music-local-page") || (ic(t), e.innerHTML = `<div class="music-local-page" id="music-local-page">
      ${tl("library")}
      <div class="music-scan hidden" id="music-scan"></div>
      <!-- 视频的**画面层**（2026-10-01 用户第 8 条）。里面那个 video 元素由
           renderLocalVideo 现造现拆（离开 / 换曲时整块清掉，见那里的注释）。
           注：本段在模板字符串里，注释里一个反引号都不能出现（预检 #15 / #39 ⑩）。 -->
      <div class="music-video hidden" id="music-video"></div>
      <div class="music-list" id="music-mt-list"></div>
    </div>`), A(t.querySelector("#music-mt-q"), !Te);
  const i = t.querySelector("#music-list-chip");
  A(i, !!Te), Te && M(
    t.querySelector("#music-list-chip-n"),
    `${Te.name} · ${a("music.local_n_tracks", { n: String((O == null ? void 0 : O.total) ?? 0) })}`
  ), Ku(t), al(t), bn(t), fn(t), es(t);
}
function Ku(t) {
  const e = t.querySelector("#music-scan");
  if (!e) return;
  const i = ui;
  let s = "";
  if (i != null && i.running) {
    const n = i.total, c = n > 0 ? Math.min(100, Math.round(i.scanned / n * 100)) : 0, r = n > 0 ? a("music.local_scanning", { a: String(i.scanned), b: String(n) }) : a("music.local_scanning_n", { a: String(i.scanned) });
    s = `<div class="music-scan-row">
      <span class="music-scan-bar"><span class="music-scan-fill" style="width:${c}%"></span></span>
      <span class="music-scan-txt">${o(r)}</span>
    </div>`;
  } else i != null && i.error ? s = `<div class="music-scan-row music-scan-err">${o(i.error)}</div>` : i != null && i.done_at && (s = `<div class="music-scan-row music-scan-done">${o(a("music.local_scan_done", {
    added: String(i.added),
    updated: String(i.updated),
    removed: String(i.removed),
    failed: String(i.failed)
  }))}</div>`);
  C(e, s), A(e, !!s);
}
function bn(t) {
  const e = t.querySelector("#music-mt-list");
  if (!e) return;
  let i;
  wi ? i = `<div class="music-empty">${a("music.loading")}</div>` : Mt ? i = `<div class="music-empty music-empty-err">${o(Mt)}</div>` : !Te && ne && ne.length === 0 ? i = `<div class="music-empty">${o(a("music.local_add_hint"))}</div>` : !O || O.items.length === 0 ? i = `<div class="music-empty">${o(a(Te ? "music.local_list_empty" : "music.local_empty"))}</div>` : (i = O.items.map((s, n) => xn(s, n)).join(""), O.total > O.items.length && (i += `<div class="music-empty">${o(a("music.local_more", {
    a: String(O.items.length),
    b: String(O.total)
  }))}</div>`)), C(e, i), Ln(t);
}
const Ju = [
  "mp3",
  "flac",
  "m4a",
  "m4b",
  "mp4",
  "aac",
  "ogg",
  "oga",
  "opus",
  "spx",
  "wav",
  "wave",
  "aif",
  "aiff",
  "aifc",
  "ape",
  "wv",
  "mpc",
  "m4v",
  "mov"
];
function Xu(t) {
  const e = t.split(/[\\/]/).pop() || t, i = e.lastIndexOf(".");
  return {
    path: t,
    title: i > 0 ? e.slice(0, i) : e,
    artist: "",
    album: "",
    duration_ms: 0,
    cover: "",
    ext: i > 0 ? e.slice(i + 1).toLowerCase() : "",
    size: 0
  };
}
function Ln(t) {
  if (!oi) return;
  const e = t.querySelector("#music-main");
  if (!e) return;
  const i = Array.from(e.querySelectorAll(".music-mt")).find((c) => c.dataset.path === oi);
  if (!i) return;
  const n = i.getBoundingClientRect().top - e.getBoundingClientRect().top + e.scrollTop - Math.max(0, (e.clientHeight - i.clientHeight) / 2);
  e.scrollTop = Math.max(0, n), oi = "";
}
function tl(t) {
  const e = t === "queue", i = e ? `<input class="music-local-q" id="music-lq-q" type="search" autocomplete="off" spellcheck="false"
             placeholder="${o(a("music.local_filter_ph"))}" value="${o(Je)}">` : `<input class="music-local-q" id="music-mt-q" type="search" autocomplete="off" spellcheck="false"
             placeholder="${o(a("music.local_filter_ph"))}" value="${o(Ji)}">`, s = e ? "" : `<span class="music-list-chip hidden" id="music-list-chip">
          <span class="music-list-chip-n" id="music-list-chip-n"></span>
          <button class="music-pl-x" data-act="media-list-close" title="${o(a("music.local_close_playlist"))}">${v.x}</button>
        </span>`, n = e ? "" : `<button class="music-ghost-btn music-icon-btn music-local-qmode" id="music-local-qmode" data-act="qmode" aria-pressed="false" title="${o(a("music.local_queue_edit"))}">${v.list}</button>`;
  return `<div class="music-local-head-row">
        ${i}
        ${s}
        <button class="music-ghost-btn music-icon-btn" id="music-scan-btn" data-act="media-scan" title="${o(a("music.local_rescan"))}">${v.refresh}</button>
        ${n}
      </div>`;
}
function Zu() {
  return `<div class="music-local-page" id="music-queue-page">
    ${tl("queue")}
    <div class="music-list" id="music-lq-list"></div>
  </div>`;
}
function zs(t) {
  var c;
  const e = t.querySelector("#music-lq-list");
  if (!e) return;
  const i = Je.trim().toLowerCase(), s = (((c = Li()) == null ? void 0 : c.items) ?? []).filter((r) => !Tt.has(r.path)).filter((r) => !i || [r.title, r.artist, r.album].some((p) => (p || "").toLowerCase().includes(i))), n = s.length === 0 ? `<div class="music-empty">${o(a("music.local_queue_page_empty"))}</div>` : s.map((r, p) => xn(r, p, "queue-track")).join("");
  C(e, n), Ln(t);
}
function xt(t) {
  const e = t.querySelector("#music-queue-dlg");
  if (!e || (A(e, Ee), !Ee)) return;
  const i = t.querySelector("#music-queue-files"), s = it.length === 0 ? `<div class="music-empty">${o(a("music.local_queue_files_empty"))}</div>` : `<div class="music-queue-file">${o(a("music.local_queue_files_n", { n: String(it.length) }))}</div>` + it.map((n) => `<div class="music-queue-file" title="${o(n)}">${o(n.split(/[\\/]/).pop() || n)}</div>`).join("");
  C(i, s);
}
function eo(t, e = []) {
  Ee = !0;
  const i = /* @__PURE__ */ new Set();
  it = [];
  for (const n of e) {
    const c = n.toLowerCase();
    !n || i.has(c) || (i.add(c), it.push(n));
  }
  xt(t);
  const s = t.querySelector("#music-queue-name");
  s && (s.value = "", setTimeout(() => s.focus(), 0));
}
async function to(t) {
  let e = null;
  try {
    e = await ss({
      multiple: !0,
      title: a("music.local_queue_pick"),
      filters: [{ name: "Audio / Video", extensions: Ju }]
    });
  } catch (n) {
    $(t, String(n));
    return;
  }
  if (!e) return;
  const i = Array.isArray(e) ? e : [e], s = new Set(it.map((n) => n.toLowerCase()));
  for (const n of i) {
    const c = n.toLowerCase();
    !n || s.has(c) || (s.add(c), it.push(n));
  }
  xt(t);
}
function fc(t) {
  var s;
  if (it.length === 0) {
    $(t, a("music.local_queue_need_files"));
    return;
  }
  const e = t.querySelector("#music-queue-name"), i = {
    id: Fc(),
    name: su(((e == null ? void 0 : e.value) ?? "").trim()),
    items: it.map(Xu)
  };
  Ae.push(i), G = i.id, ki(), Ee = !1, U = !1, qe("library"), xt(t), ie && (De(t), (s = t.querySelector("#music-queue-page")) == null || s.remove(), Ut(t)), V(t), $(t, a("music.local_queue_created", { name: i.name }));
}
function io(t) {
  const i = ((O == null ? void 0 : O.items) ?? []).filter((s) => F.library.ids.has(s.path));
  eo(t, i.map((s) => s.path));
}
function il(t) {
  const e = t.querySelector("#music-del-dlg");
  if (!e) return;
  const i = Xi !== null;
  if (A(e, i), !i) return;
  const s = Xi;
  M(
    t.querySelector("#music-del-text"),
    a("music.ctx_delete_confirm", { name: s.name })
  );
}
function so(t, e, i) {
  Xi = { path: e, name: i || e.split(/[\\/]/).pop() || e }, il(t);
}
function yn(t) {
  Xi = null, il(t);
}
async function no(t) {
  const e = Xi;
  if (!e) return;
  const i = e.path;
  yn(t);
  try {
    await d("media_delete_file", { path: i });
  } catch (s) {
    $(t, String(s));
    return;
  }
  for (const s of ["library", "queue"]) {
    const n = F[s];
    n.ids.delete(i), n.anchor === i && (n.anchor = null);
  }
  (S == null ? void 0 : S.path) === i && await Lt(t), await Jt(t), $(t, a("music.ctx_deleted"));
}
function ao() {
  const t = Fe;
  if (!t) return "";
  const e = (s, n, c = !1) => `<button class="music-ctx-item${c ? " danger" : ""}" data-ctx="${s}">${o(n)}</button>`, i = [];
  if (t.act === "local-track" && i.push(e("add-play-queue", a("music.add_to_play_queue"))), t.act === "queue-track") {
    const s = sl().length;
    i.push(e("remove-queue", a("music.ctx_remove_selected", { n: String(s) }), !0));
  }
  return (t.act === "local-track" || t.act === "queue-track") && t.path && (i.push(e("reveal", a("music.ctx_reveal"))), i.push(e("delete-file", a("music.ctx_delete_file"), !0))), (t.act === "main-track" || t.act === "play-uri") && i.push(e("play", a("music.ctx_play"))), i.join("");
}
function co(t, e, i) {
  const s = t.querySelector("#music-ctx");
  if (!s) return;
  const n = t.getBoundingClientRect(), c = Math.max(2, Math.min(e - n.left, n.width - 132)), r = Math.max(2, Math.min(i - n.top, n.height - 160));
  s.style.left = `${c}px`, s.style.top = `${r}px`, s.classList.add("open"), requestAnimationFrame(() => {
    if (!s.isConnected) return;
    const p = s.getBoundingClientRect();
    p.width && p.height && (p.right > n.right && (s.style.left = `${Math.max(2, n.width - p.width - 8)}px`), p.bottom > n.bottom && (s.style.top = `${Math.max(2, n.height - p.height - 8)}px`));
  });
}
function lo(t, e, i) {
  const s = t.querySelector("#music-ctx");
  s && (C(s, ao()), s.querySelector("button") && co(t, e, i));
}
function _t(t) {
  var e;
  (e = t.querySelector("#music-ctx")) == null || e.classList.remove("open"), Fe = null;
}
function uo() {
  const t = (O == null ? void 0 : O.items) ?? [], e = t.filter((i) => F.library.ids.has(i.path));
  if (e.length) return e;
  if (Fe != null && Fe.path) {
    const i = t.find((s) => s.path === Fe.path);
    if (i) return [i];
  }
  return [];
}
function sl() {
  const t = Li();
  if (!t) return [];
  const e = F.queue.ids;
  return t.items.filter((i) => e.has(i.path));
}
function oo(t) {
  const e = Li(), i = sl();
  if (!e || !i.length) return;
  const s = new Set(i.map((r) => r.path)), n = e.items.length;
  e.items = e.items.filter((r) => !s.has(r.path));
  const c = n - e.items.length;
  qe("queue"), ki(), zs(t), c > 0 && $(t, a("music.ctx_removed_n_from_queue", { n: String(c) }));
}
function ro(t) {
  const e = uo();
  e.length && (B.push(...e), P < 0 && (P = 0, re = 0), Yt(), V(t), $(t, a("music.added_to_play_queue", { n: String(e.length) })));
}
async function mo(t, e) {
  if (!B[e]) return;
  const s = e === P, n = !!(S && S.path);
  B.splice(e, 1), tt = [], B.length === 0 ? await nl(t, n) : s ? (P = Math.min(e, B.length - 1), re = 0, n ? await ht(t, B[P].path) || await Lt(t) : (Yt(), V(t))) : (e < P && P--, Yt(), V(t));
}
async function nl(t, e) {
  B = [], P = -1, re = 0, tt = [];
  try {
    localStorage.removeItem(Sn);
  } catch {
  }
  e ? await Lt(t) : V(t);
}
async function po(t) {
  if (B.length === 0) return;
  const e = !!(S && S.path);
  await nl(t, e);
}
function al(t) {
  const e = t.querySelector("#music-video");
  if (!e) return;
  const i = S, s = !!i && i.video && i.path !== "";
  if (A(e, s), !s) {
    e.firstChild && (e.innerHTML = "");
    return;
  }
  const n = Ns(i.path);
  let c = e.querySelector(".music-video-el");
  if (!c || c.dataset.src !== n) {
    if (e.innerHTML = '<video class="music-video-el" muted playsinline preload="auto"></video>', c = e.querySelector(".music-video-el"), !c) return;
    c.dataset.src = n, c.src = n, c.addEventListener("loadedmetadata", () => vc(c, i), { once: !0 }), c.addEventListener("error", () => {
      At(t, a("music.video_unsupported"));
    });
  }
  vc(c, i);
}
function vc(t, e) {
  e.playing ? t.paused && t.play().catch(() => {
  }) : t.paused || t.pause();
  const i = e.playing ? Date.now() - ns : 0, s = (e.position_ms + Math.max(0, i)) / 1e3;
  t.readyState >= 1 && !t.seeking && Math.abs(t.currentTime - s) > Kl && (t.currentTime = s);
}
function cl(t) {
  if (D !== "lplayer") return;
  const e = t.querySelector("#music-v-lplayer"), i = S;
  if (!e || !i || !i.path) return;
  const s = B[P], n = (s == null ? void 0 : s.title) || i.path.split(/[\\/]/).pop() || i.path;
  M(e.querySelector("#music-lp-title"), n), M(e.querySelector("#music-lp-sub"), s ? [s.artist, s.album].filter(Boolean).join(" · ") : ""), C(
    e.querySelector("#music-lp-cover"),
    s != null && s.cover ? `<img src="${o(Ns(s.cover))}" alt="">` : v.note
  ), C(e.querySelector("#music-lp-play"), i.active && i.playing ? v.pause : v.play);
  const c = e.querySelector("#music-lp-mode");
  c && (de(c, "data-mode", ue), de(c, "title", $n()), C(c, ue === "repeat_all" || ue === "repeat_one" ? v.repeat : v.shuffle));
  const r = i.duration_ms, p = oe >= 0 ? oe : r > 0 ? Math.min(1, i.position_ms / r) : 0, _ = e.querySelector("#music-lp-progress");
  _ && oe < 0 && _.style.setProperty("--seek-pct", `${p * 100}%`), M(e.querySelector("#music-lp-time"), r > 0 ? `${K(i.position_ms)} / ${K(r)}` : K(i.position_ms));
  const x = e.querySelector("#music-lp-vol");
  x && document.activeElement !== x && (x.value = String(Math.round(i.volume * 100)), di(x, i.volume * 100));
}
function fo(t) {
  var n, c;
  const e = t.querySelector("#music-lq-dd");
  if (!e || (A(e, ke), (n = t.querySelector("#music-l-queue")) == null || n.classList.toggle("on", ke), (c = t.querySelector("#music-lp-queue")) == null || c.classList.toggle("on", ke), !ke)) return;
  const i = o(a("music.play_queue_clear")), s = B.length === 0 ? `<div class="music-empty">${o(a("music.local_play_queue_empty"))}</div>` : `<div class="music-lq-head"><button type="button" class="music-lq-clear" data-act="queue-clear" title="${i}" aria-label="${i}">${v.trash}</button></div>` + B.map((r, p) => xn(r, p, "queue-play")).join("");
  C(e, s);
}
function hc(t, e) {
  const i = (() => {
    const n = a("plugin.music");
    return n === "plugin.music" ? "music" : n;
  })(), s = t ? e ? `${t} - ${e}` : t : i;
  s !== ec && (ec = s, d("plugin_window_set_title", { title: s }).catch(() => {
  }));
}
function ll() {
  const t = B.length > 1, e = {
    hasPrev: t,
    hasNext: t,
    playing: !!(S != null && S.active && S.playing)
  }, i = Cs;
  i && i.hasPrev === e.hasPrev && i.hasNext === e.hasNext && i.playing === e.playing || (Cs = e, d("taskbar_thumb_set", e).catch(() => {
  }));
}
function V(t) {
  ll(), al(t), cl(t), fo(t);
  const e = t.querySelector("#music-lnowbar");
  if (!e) return;
  const i = S, s = !!i && i.path !== "", n = Wc();
  if (A(e, n), !n) return;
  const c = B[P] ?? null, r = (i && s ? i.path : "") || (c == null ? void 0 : c.path) || "";
  if (!c && !s) {
    hc("", ""), M(e.querySelector("#music-lnow-n"), a("music.local_bar_empty")), M(e.querySelector("#music-lnow-a"), ""), C(e.querySelector("#music-lnow-cover"), v.note), C(e.querySelector("#music-l-play"), v.play), M(e.querySelector("#music-l-time"), "0:00");
    const w = e.querySelector("#music-lbp");
    w && oe < 0 && w.style.setProperty("--seek-pct", "0%");
  } else {
    const w = (c == null ? void 0 : c.title) || r.split(/[\\/]/).pop() || r;
    hc(w, (c == null ? void 0 : c.artist) ?? ""), M(e.querySelector("#music-lnow-n"), w), M(e.querySelector("#music-lnow-a"), c ? [c.artist, c.album].filter(Boolean).join(" · ") : ""), C(
      e.querySelector("#music-lnow-cover"),
      c != null && c.cover ? `<img src="${o(Ns(c.cover))}" alt="">` : v.note
    ), C(e.querySelector("#music-l-play"), i != null && i.active && (i != null && i.playing) ? v.pause : v.play);
    const E = (i && s ? i.duration_ms : 0) || (c == null ? void 0 : c.duration_ms) || 0, T = i && s ? i.position_ms : re, z = oe >= 0 ? oe : E > 0 ? Math.min(1, T / E) : 0, j = e.querySelector("#music-lbp");
    j && oe < 0 && j.style.setProperty("--seek-pct", `${z * 100}%`), M(e.querySelector("#music-l-time"), E > 0 ? `${K(T)} / ${K(E)}` : K(T));
  }
  const p = !!c || s;
  for (const w of ["#music-l-prev", "#music-l-next", "#music-l-mode", "#music-l-stop", "#music-l-play"]) {
    const E = e.querySelector(w);
    E && (E.disabled = !p);
  }
  const _ = e.querySelector("#music-l-mode");
  _ && (de(_, "data-mode", ue), de(_, "title", $n()), C(_, ue === "repeat_all" || ue === "repeat_one" ? v.repeat : v.shuffle));
  const x = e.querySelector("#music-l-vol");
  if (x && document.activeElement !== x) {
    const w = i ? i.volume : Number(x.value) / 100;
    x.value = String(Math.round(w * 100)), di(x, w * 100);
  }
}
function En(t) {
  const e = S != null && S.active ? S.path : "";
  t.querySelectorAll(".music-mt").forEach((i) => {
    i.classList.toggle("playing", !!e && i.dataset.path === e);
  });
}
function st(t) {
  ie && (De(t), Ut(t), V(t));
}
async function ul(t) {
  Ms = !0, _i = "", st(t);
  try {
    ne = await d("media_roots");
  } catch (e) {
    _i = String(e);
  } finally {
    Ms = !1, st(t);
  }
}
async function Jt(t) {
  Te = null, wi = !0, Mt = "", st(t);
  try {
    O = await d("media_tracks", {
      // 空串 ⇒ 传 null（宿主的 `Option<String>` 收 None = 全库 / 不筛选）
      root: Ue || null,
      query: Ji || null,
      limit: Oc
    });
  } catch (e) {
    Mt = String(e);
  } finally {
    wi = !1, st(t);
  }
}
function pi() {
  zi !== void 0 && (window.clearInterval(zi), zi = void 0);
}
function ol(t) {
  zi === void 0 && (zi = window.setInterval(() => {
    (async () => {
      if (!t.isConnected) {
        pi();
        return;
      }
      try {
        const e = await d("media_scan_status");
        ui = e, e.running || (pi(), await ul(t), await Jt(t));
      } catch {
        pi();
      }
      st(t);
    })();
  }, Vl));
}
async function rl(t, e) {
  try {
    ui = await d("media_scan_start", { root: e || null });
  } catch (i) {
    const s = String(i);
    $(t, s.includes("ERR_SCAN_RUNNING") ? a("music.local_scan_busy") : s);
    return;
  }
  st(t), ol(t);
}
async function vo(t) {
  let e = null;
  try {
    e = await ss({ directory: !0, multiple: !1, title: a("music.local_add_dir") });
  } catch (i) {
    $(t, String(i));
    return;
  }
  if (!(typeof e != "string" || !e)) {
    try {
      ne = await d("media_add_root", { path: e });
    } catch (i) {
      $(t, String(i));
      return;
    }
    Ue = ho(e), st(t), await rl(t, Ue || e);
  }
}
function ho(t) {
  var s;
  const e = (n) => n.replace(/[\\/]+$/, "").toLowerCase(), i = e(t);
  return ((s = ne == null ? void 0 : ne.find((n) => e(n.path) === i)) == null ? void 0 : s.path) ?? "";
}
function bo(t) {
  te = !0, U = !1, ve.clear(), Tt.clear(), qe("queueList"), mt.clear(), De(t), G !== null && Ut(t);
}
function yo(t) {
  const e = F.queueList.ids, i = e.size > 0;
  for (const s of e) mt.add(s);
  if (qe("queueList"), G !== null) {
    const s = F.queue.ids;
    if (s.size) {
      for (const n of s) Tt.add(n);
      qe("queue"), zs(t);
    }
    i && De(t);
    return;
  }
  if (ve.size) {
    for (const s of ve) Ki.add(s);
    ve.clear();
  }
  De(t);
}
async function go(t) {
  const e = Array.from(mt);
  mt.clear(), qe("queueList");
  let i = !1;
  if (e.length) {
    const c = new Set(e);
    Ae = Ae.filter((r) => !c.has(r.id)), G && c.has(G) && (G = null, i = !0, te = !1, ve.clear(), Tt.clear(), qe("queue"), Je = "", Y !== void 0 && (window.clearTimeout(Y), Y = void 0)), ki();
  }
  if (G !== null) {
    const c = Li(), r = Array.from(Tt);
    if (te = !1, ve.clear(), qe("queue"), qe("library"), Tt.clear(), hn(t), De(t), c && r.length) {
      const p = new Set(r);
      c.items = c.items.filter((_) => !p.has(_.path)), ki();
    }
    Ut(t);
    return;
  }
  const s = Array.from(Ki);
  if (te = !1, ve.clear(), Ki.clear(), hn(t), !s.length) {
    De(t), i && Ut(t);
    return;
  }
  let n = "";
  for (const c of s)
    try {
      ne = await d("media_remove_root", { path: c });
    } catch (r) {
      const p = String(r);
      n = p.includes("ERR_SCAN_RUNNING") ? a("music.local_remove_busy") : p;
    }
  Ue && !(ne ?? []).some((c) => c.path === Ue) && (Ue = ""), De(t), await Jt(t), i && Ut(t), n && $(t, n);
}
function dl(t) {
  const e = t instanceof Error ? t.message : String(t);
  return e.includes("ERR_NOT_PLAYLIST") ? a("music.local_not_playlist") : e;
}
async function _o(t) {
  let e = null;
  try {
    e = await ss({
      multiple: !1,
      title: a("music.local_open_playlist"),
      filters: [{ name: "Playlist", extensions: ["m3u", "m3u8", "pls"] }]
    });
  } catch (i) {
    $(t, String(i));
    return;
  }
  if (!(typeof e != "string" || !e)) {
    wi = !0, Mt = "", O = null, st(t);
    try {
      O = await d("media_playlist", { path: e }), Te = { path: e, name: e.split(/[\\/]/).pop() || e }, Ue = "";
    } catch (i) {
      Te = null, Mt = dl(i);
    } finally {
      wi = !1, st(t);
    }
  }
}
function wo(t) {
  Te = null, Jt(t);
}
function ml(t) {
  const e = t instanceof Error ? t.message : String(t);
  return e.includes("ERR_NO_AUDIO_DEVICE") ? a("music.local_no_device") : e.includes("找不到这个文件") ? a("music.local_file_missing") : e.includes("解不开") || e.includes("打不开") ? a("music.local_decode_failed") : e;
}
async function ht(t, e, i = 0) {
  if (Pt) return !1;
  await as(t, "local"), Pt = !0;
  try {
    S = await d("player_play", { path: e });
  } catch (s) {
    return $(t, ml(s)), Pt = !1, !1;
  }
  if (Pt = !1, re = 0, i > 0)
    try {
      S = await d("player_seek", { positionMs: Math.round(i) }), re = S.position_ms;
    } catch {
    }
  return ns = Date.now(), Yt(), oi = e, V(t), En(t), Ln(t), fl(t), !0;
}
async function ko(t, e) {
  const i = (O == null ? void 0 : O.items) ?? [], s = i[e];
  s && (B = i.slice(), P = e, tt = [], await ht(t, s.path));
}
async function sn(t, e, i = Li()) {
  if (!i || !e) return;
  const s = i.items.findIndex((n) => n.path === e);
  s < 0 || (B = i.items.slice(), P = s, tt = [], await ht(t, e));
}
async function So(t, e) {
  const i = B[e];
  i && (P = e, tt = [], await ht(t, i.path));
}
function bc(t) {
  if (!(t instanceof HTMLElement)) return null;
  const e = t.closest("[data-act]"), i = e ? Xt[e.dataset.act || ""] : void 0;
  return !e || !i ? null : { list: i, container: e.closest(Ps[i]) ?? e };
}
function Ws(t) {
  return (t.dataset.act || "") === "local-queue" ? t.dataset.qid || "" : t.dataset.path || t.dataset.uri || "";
}
function pl(t, e) {
  const i = [];
  return t.querySelectorAll("[data-act]").forEach((s) => {
    if (Xt[s.dataset.act || ""] !== e) return;
    const n = Ws(s);
    n && !i.includes(n) && i.push(n);
  }), i;
}
function is(t, e) {
  const i = F[e];
  t.querySelectorAll(Ps[e]).forEach((s) => {
    s.querySelectorAll("[data-act]").forEach((n) => {
      if (Xt[n.dataset.act || ""] !== e) return;
      const c = Ws(n), r = !!c && i.ids.has(c), p = n.closest(".music-pl, .music-mt, .music-tr") ?? n;
      p.classList.toggle("sel", r);
      const _ = p.querySelector(".music-mt-i");
      _ != null && _.classList.contains("music-mt-check") && (_.classList.toggle("on", r), _.innerHTML = r ? v.check : "");
    });
  });
}
function qe(t) {
  const e = F[t];
  return !e.ids.size && !e.anchor ? !1 : (e.ids.clear(), e.anchor = null, !0);
}
function os() {
  for (const t of Object.keys(F)) qe(t);
  lt = null;
}
function $o(t, e) {
  const i = [];
  t.querySelectorAll(Ps[e]).forEach((n) => {
    for (const c of pl(n, e)) i.includes(c) || i.push(c);
  });
  const s = F[e];
  s.ids.clear();
  for (const n of i) s.ids.add(n);
  s.anchor = i[0] ?? null, is(t, e);
}
function rs(t, e, i) {
  i && (F[e].ids.add(i), F[e].anchor = i, is(t, e));
}
function ds(t, e, i) {
  const s = Xt[e.dataset.act || ""], n = Ws(e);
  if (!s || !n) return;
  const c = F[s], r = e.closest(Ps[s]), p = r ? pl(r, s) : [n], _ = s === "library" && U;
  if (i != null && i.shiftKey && c.anchor) {
    const x = p.indexOf(c.anchor), w = p.indexOf(n);
    if (x >= 0 && w >= 0) {
      c.ids.clear();
      for (let E = Math.min(x, w); E <= Math.max(x, w); E++) c.ids.add(p[E]);
    } else
      c.ids.clear(), c.ids.add(n), c.anchor = n;
  } else i != null && i.ctrlKey || i != null && i.metaKey || _ ? (c.ids.has(n) ? c.ids.delete(n) : c.ids.add(n), c.anchor = n) : (c.ids.clear(), c.ids.add(n), c.anchor = n);
  is(t, s);
}
async function Dt(t, e, i) {
  var c;
  const s = B.length;
  if (s === 0) return;
  if (i && ue === "repeat_one") {
    await ht(t, ((c = B[P]) == null ? void 0 : c.path) ?? "");
    return;
  }
  let n;
  if (ue === "shuffle" && s > 1)
    if (e < 0 && tt.length > 0)
      n = tt.pop();
    else {
      do
        n = Math.floor(Math.random() * s);
      while (n === P);
      P >= 0 && tt.push(P);
    }
  else
    n = P + e;
  if (ue === "repeat_all" || ue === "shuffle")
    n = (n % s + s) % s;
  else if (n < 0 || n >= s) {
    i || $(t, a("music.local_queue_end"));
    return;
  }
  P = n, await ht(t, B[n].path);
}
async function nn(t) {
  var i;
  if (Pt) return;
  const e = S;
  if (!e || e.path === "") {
    const s = ((i = B[P]) == null ? void 0 : i.path) ?? "";
    if (!s) return;
    await ht(t, s, re);
    return;
  }
  if (!e.active) {
    await ht(t, e.path);
    return;
  }
  try {
    S = await d(e.playing ? "player_pause" : "player_resume");
  } catch (s) {
    $(t, ml(s));
    return;
  }
  ns = Date.now(), V(t), S != null && S.active && fl(t);
}
async function Lt(t) {
  fi(), S != null && S.path && (re = S.position_ms), oe = -1, tt = [], S = null, ns = 0, Yt();
  const e = D === "lplayer";
  e && (D = "default"), V(t), En(t), e && ae(t);
  try {
    await d("player_stop");
  } catch {
  }
}
async function as(t, e) {
  if (!He) {
    if (e === "local") {
      if (f != null && f.connected && (y != null && y.playing))
        try {
          await d("spotify_control", { action: "pause" });
        } catch {
        }
      return;
    }
    S && await Lt(t);
  }
}
async function qo(t, e) {
  if (!S || S.path === "") {
    re = Math.max(0, Math.round(e)), Yt(), V(t);
    return;
  }
  try {
    S = await d("player_seek", { positionMs: e });
  } catch {
    return;
  }
  re = S.position_ms, V(t);
}
async function yc(t, e) {
  try {
    S = await d("player_volume", { volume: e });
  } catch {
    return;
  }
  V(t);
}
function fi() {
  Wi !== void 0 && (window.clearInterval(Wi), Wi = void 0);
}
function fl(t) {
  Wi === void 0 && (Wi = window.setInterval(() => {
    (async () => {
      if (!t.isConnected) {
        fi();
        return;
      }
      if (oe >= 0 || Pt) return;
      let e;
      try {
        e = await d("player_status");
      } catch {
        return;
      }
      if (!t.isConnected) {
        fi();
        return;
      }
      const i = !e.active && e.path !== "" && e.path === (S == null ? void 0 : S.path);
      S = e, re = e.position_ms, ns = Date.now(), V(t), En(t), i && (fi(), await Dt(t, 1, !0));
    })();
  }, Yl));
}
function xo(t, e) {
  Ji = e, $e !== void 0 && window.clearTimeout($e), $e = window.setTimeout(() => {
    $e = void 0, Jt(t);
  }, Gl);
}
function gc(t) {
  Oi = Math.min(Nc, Math.max(Rc, Math.round(Oi))), t.style.setProperty("--music-side-w", `${Oi}px`);
}
function Tn(t, e) {
  var s;
  if (t === "liked")
    return { id: "liked", uri: "", name: a("music.liked_songs"), cover: "", subtitle: "", total: (J == null ? void 0 : J.total) ?? 0 };
  if (t === "top-tracks")
    return {
      id: "top-tracks",
      uri: "",
      name: a("music.top_tracks"),
      cover: "",
      subtitle: a("music.top_tracks_sub"),
      total: 0
    };
  const i = t === "artist" ? Q == null ? void 0 : Q.artists : t === "album" ? Q == null ? void 0 : Q.albums : t === "show" ? Q == null ? void 0 : Q.shows : Q == null ? void 0 : Q.playlists.map(Bs);
  return ((s = gi.get(t)) == null ? void 0 : s.find((n) => n.id === e)) ?? (i == null ? void 0 : i.find((n) => n.id === e)) ?? null;
}
async function vl(t, e) {
  if (!(!(f != null && f.connected) || Pi.has(e) || gi.has(e))) {
    Pi.add(e), Yi.delete(e), Kt(t);
    try {
      const i = e === "playlist" ? (rn = await d("spotify_playlists")).map(Bs) : await d(Pl[e]);
      gi.set(e, i);
    } catch (i) {
      Yi.set(e, R(i));
    } finally {
      Pi.delete(e), Kt(t);
    }
  }
}
async function _c(t, e, i) {
  const s = Tn(e, i);
  if (s) {
    if (kt = !1, ze = !1, I = { kind: e, id: s.id, uri: s.uri, name: s.name, cover: s.cover, subtitle: s.subtitle }, Me = null, vt = "", e === "liked") {
      Me = (J == null ? void 0 : J.items) ?? null, vt = jt, li = !J, et(t), tn(t), Ie(t), J || await bl(t);
      return;
    }
    li = !0, et(t), tn(t), Ie(t);
    try {
      Me = e === "top-tracks" ? await d("spotify_top_tracks") : await d("spotify_item_tracks", { kind: Nl(e), id: s.id });
    } catch (n) {
      vt = R(n);
    } finally {
      li = !1, tn(t), Ie(t);
    }
  }
}
async function wc(t, e, i, s = 0) {
  const n = Tn(e, i);
  if (n) {
    await as(t, "spotify");
    try {
      if (e === "liked" || e === "show" || e === "top-tracks") {
        const c = (e === "liked" ? J == null ? void 0 : J.items : Me) ?? [];
        if (!c.length) return;
        await d("spotify_play_uris", { uris: c.slice(Math.max(0, s)).map((r) => r.uri), deviceId: Ce || void 0 });
      } else if (n.uri)
        await d("spotify_play_context", { contextUri: n.uri, offsetUri: "", deviceId: Ce || void 0 });
      else
        return;
    } catch (c) {
      $(t, R(c));
    }
  }
}
async function kc(t, e) {
  if (!I) return;
  const i = Me ?? [], s = i[e];
  if (s) {
    await as(t, "spotify");
    try {
      I.kind === "liked" || I.kind === "show" ? await d("spotify_play_uris", { uris: i.slice(e).map((n) => n.uri), deviceId: Ce || void 0 }) : await d("spotify_play_context", { contextUri: I.uri, offsetUri: s.uri, deviceId: Ce || void 0 });
    } catch (n) {
      $(t, R(n));
    }
  }
}
async function Is(t, e = !1) {
  if (!(f != null && f.connected)) return;
  if (!e && Ce && Date.now() - hs < tu) {
    await qi(t);
    return;
  }
  if (Js) return;
  Js = !0;
  const i = !!(le != null && le.running), s = window.setTimeout(() => $(t, a("music.auto_starting")), 600);
  try {
    const n = await d("music_autoconfigure", { allowLocal: !Ts });
    Ce = n.device_id || "", hs = Date.now(), n.source === "needs_login" ? $(t, a("music.auto_need_login")) : n.source === "local" && !n.device_id ? $(t, a("music.auto_local_unregistered")) : n.started_local && !i ? $(t, a("music.auto_local_started")) : n.source === "start_failed" ? $(t, a("music.auto_start_failed")) : n.source === "none" && !Ts && $(t, a("music.auto_none"));
  } catch (n) {
    Ce = "", hs = 0, String(n) !== "ERR_NOT_CONNECTED" && $(t, R(n));
  } finally {
    window.clearTimeout(s), Js = !1;
  }
  await qi(t);
}
function Lo(t) {
  if (t <= 0) return "";
  if (t >= 3600) {
    const e = Math.floor(t / 3600), i = Math.round(t % 3600 / 60);
    return i > 0 ? a("music.wait_hm", { h: String(e), m: String(i) }) : a("music.wait_h", { h: String(e) });
  }
  return t >= 60 ? a("music.wait_m", { m: String(Math.round(t / 60)) }) : a("music.wait_s", { s: String(Math.ceil(t)) });
}
function Eo() {
  return Es <= 0 ? 0 : Math.max(0, Math.round((Es - Date.now()) / 1e3));
}
async function hl(t) {
  try {
    const e = await d("spotify_api_state");
    Et = e.stopped, Ls = e.reason, Es = e.retry_at_ms;
  } catch {
  }
  Ds(t);
}
function Ds(t) {
  const e = t.querySelector("#music-resume");
  if (A(e, Et), !e) return;
  if (!Et) {
    e.textContent = a("music.resume"), e.title = "";
    return;
  }
  const i = Lo(Eo());
  e.textContent = i ? a("music.resume_in", { wait: i }) : a("music.resume"), e.title = i ? a("music.resume_hint", { wait: i, reason: Ls }) : Ls;
}
async function To(t) {
  try {
    await d("spotify_resume");
  } catch {
  }
  Et = !1, Ls = "", Es = 0, Ds(t), $(t, a("music.resumed")), Is(t, !0);
}
async function qi(t) {
  try {
    Gt = await d("spotify_devices");
  } catch (e) {
    Gt = [], $(t, R(e));
  }
  try {
    le = await d("librespot_status");
  } catch {
    le = null;
  }
  $i(t);
}
async function Mo(t) {
  if (!(le != null && le.available)) return;
  const e = le.running;
  try {
    le = await d(e ? "librespot_stop" : "librespot_start");
  } catch (i) {
    $(t, R(i));
    return;
  }
  if (Ts = e, $i(t), e) {
    Ce = "", hs = 0, await Is(t, !0);
    return;
  }
  for (let i = 0; i < 6; i++) {
    await new Promise((s) => window.setTimeout(s, 1500));
    try {
      const s = await d("spotify_devices");
      Gt = s;
      const n = s.find((c) => c.name === "Lunac");
      if (n && !n.active && await d("spotify_transfer", { deviceId: n.id, play: !0 }), n) {
        Ce = n.id;
        break;
      }
    } catch {
    }
  }
  await qi(t);
}
async function Co(t) {
  try {
    le = await d("librespot_login");
  } catch (e) {
    $(t, R(e));
    return;
  }
  Ts = !1, $i(t), $(t, a("music.local_login_started"));
  for (let e = 0; e < 60; e++) {
    if (await new Promise((s) => window.setTimeout(s, 2e3)), !t.isConnected) return;
    let i;
    try {
      i = await d("librespot_status");
    } catch {
      continue;
    }
    if (le = i, !!i.has_credentials) {
      i.running || (le = await d("librespot_start").catch(() => i));
      for (let s = 0; s < 8; s++) {
        if (await new Promise((r) => window.setTimeout(r, 1500)), !t.isConnected) return;
        const n = await d("spotify_devices").catch(() => []);
        Gt = n;
        const c = n.find((r) => r.name === "Lunac");
        if (c) {
          c.active || await d("spotify_transfer", { deviceId: c.id, play: !1 }), Ce = c.id;
          break;
        }
      }
      $(t, a("music.local_login_ok"));
      break;
    }
  }
  await qi(t);
}
async function Ao(t, e) {
  if (e) {
    try {
      await d("spotify_transfer", { deviceId: e, play: !1 }), ut = !1;
    } catch (i) {
      $(t, R(i));
    }
    await qi(t);
  }
}
async function bl(t) {
  if (!(!(f != null && f.connected) || Ks || J)) {
    Ks = !0, jt = "", Kt(t);
    try {
      J = await d("spotify_liked");
    } catch (e) {
      jt = R(e);
    } finally {
      Ks = !1, (I == null ? void 0 : I.kind) === "liked" && (Me = (J == null ? void 0 : J.items) ?? null, li = !1, vt = jt), Kt(t), Ie(t);
    }
  }
}
function Sc(t, e) {
  if (Qe = e, ze = !!e, Ai !== void 0 && (window.clearTimeout(Ai), Ai = void 0), !e) {
    Q = null, yi = !1, kt = !1, et(t), Ie(t);
    return;
  }
  yi = !0, et(t), Ie(t), Ai = window.setTimeout(() => void Io(t, e), Fl);
}
async function Io(t, e) {
  Ai = void 0;
  try {
    const i = await d("spotify_search", { query: e });
    if (Qe !== e) return;
    Q = i;
  } catch (i) {
    if (Qe !== e) return;
    Q = null, $(t, R(i));
  } finally {
    Qe === e && (yi = !1, et(t), Ie(t));
  }
}
function Ss(t) {
  const e = (dt == null ? void 0 : dt.items) ?? [], i = a("music.play_from_here"), s = e.length === 0 ? `<div class="music-empty">${a(dt ? "music.queue_empty" : "music.loading")}</div>` : e.map((n, c) => Os(n, c, "play-uri", "", i)).join("");
  for (const n of ["#music-q", "#music-q-dd"]) C(t.querySelector(n), s);
}
async function yl(t) {
  var e;
  try {
    dt = await d("spotify_queue"), zc = ((e = y == null ? void 0 : y.track) == null ? void 0 : e.id) ?? "";
  } catch (i) {
    dt = null, At(t, R(i));
  }
  Ss(t);
}
function gn(t) {
  const e = (y == null ? void 0 : y.track) ?? null, i = e != null && e.cover ? `<img src="${o(e.cover)}" alt="">` : "", s = [e == null ? void 0 : e.artists, e == null ? void 0 : e.album].filter(Boolean).join(" · ") || (y != null && y.active ? "" : a("music.no_device_hint"));
  C(t.querySelector("#music-pv-cover"), i), C(t.querySelector("#music-bnow-cover"), i), M(t.querySelector("#music-pv-title"), (e == null ? void 0 : e.name) || a("music.no_track")), M(t.querySelector("#music-bnow-n"), (e == null ? void 0 : e.name) || a("music.no_track")), M(t.querySelector("#music-pv-sub"), s), M(t.querySelector("#music-bnow-a"), s);
  const n = (e == null ? void 0 : e.duration_ms) ?? 0, c = Math.min((y == null ? void 0 : y.progress_ms) ?? 0, n || Number.MAX_SAFE_INTEGER), r = n > 0 ? Math.max(0, Math.min(100, c / n * 100)) : 0;
  if (Uc = c, Vc = Date.now(), Rt < 0)
    for (const T of Ht) T.style.setProperty("--seek-pct", `${r}%`);
  M(t.querySelector("#music-pv-pos"), K(c)), M(t.querySelector("#music-pv-dur"), K(n)), M(t.querySelector("#music-b-time"), `${K(c)} / ${K(n)}`);
  const p = y != null && y.playing ? v.pause : v.play;
  C(t.querySelector("#music-play"), p), C(t.querySelector("#music-b-play"), p);
  const _ = gl(), x = a(_ === "shuffle" ? "music.mode_shuffle" : _ === "repeat_one" ? "music.mode_repeat_one" : "music.mode_off");
  for (const T of [t.querySelector("#music-mode"), t.querySelector("#music-b-mode")])
    T && (de(T, "data-mode", _), de(T, "title", x), C(T, _ === "repeat_one" ? v.repeat : v.shuffle));
  const w = y && y.volume_percent >= 0 ? y.volume_percent : -1;
  for (const T of [t.querySelector("#music-vol"), t.querySelector("#music-b-vol")])
    T && w >= 0 && document.activeElement !== T && (T.value = String(w), di(T, w));
  const E = !(y != null && y.active);
  t.querySelectorAll("#music-v-player .music-bar button, #music-nowbar button").forEach((T) => {
    T.id === "music-devices-btn" || T.id === "music-bnow" || T.id === "music-b-drawer" || (T.disabled = E);
  });
}
function Do(t) {
  var n;
  if (!t.isConnected || !(y != null && y.playing) || Rt >= 0) return;
  const e = ((n = y.track) == null ? void 0 : n.duration_ms) ?? 0;
  if (e <= 0) return;
  const i = Math.min(Uc + (Date.now() - Vc), e), s = Math.max(0, Math.min(100, i / e * 100));
  for (const c of Ht) c.style.setProperty("--seek-pct", `${s}%`);
  M(t.querySelector("#music-pv-pos"), K(i)), M(t.querySelector("#music-b-time"), `${K(i)} / ${K(e)}`);
}
function gl() {
  return (y == null ? void 0 : y.repeat) === "track" ? "repeat_one" : y != null && y.shuffle ? "shuffle" : "off";
}
function an(t) {
  var e, i;
  A(t.querySelector("#music-q-wrap"), _e), A(t.querySelector("#music-q-dd"), _e), (e = t.querySelector("#music-queue-btn")) == null || e.classList.toggle("on", _e), (i = t.querySelector("#music-b-queue")) == null || i.classList.toggle("on", _e);
}
function Rs(t) {
  const e = t.querySelector("#music-lyr");
  if (!e) return;
  if (Mn(), Nt = -1, ci = [], Si && (Si = !1, Ze !== void 0 && (window.clearTimeout(Ze), Ze = void 0)), on) {
    C(e, `<div class="music-empty">${a("music.lyrics_loading")}</div>`);
    return;
  }
  if (fe != null && fe.synced) {
    const s = uu(fe.synced);
    if (s.length > 0) {
      ci = s;
      const n = o(a("music.seek_line"));
      C(
        e,
        `<div class="music-lyr-lines">${s.map((c, r) => `<div class="music-lyr-line" data-i="${r}" title="${n}">${o(c.text)}</div>`).join("")}</div>`
      );
      return;
    }
  }
  const i = ((fe == null ? void 0 : fe.plain) || "").trim();
  if (i) {
    C(e, `<div class="music-lyr-plain">${o(i)}</div>`);
    return;
  }
  if (fe != null && fe.instrumental) {
    C(e, `<div class="music-empty">${a("music.lyrics_instrumental")}</div>`);
    return;
  }
  C(e, `<div class="music-empty">${a("music.lyrics_none")}</div>`);
}
function Mn() {
  Hi && (cancelAnimationFrame(Hi), Hi = 0);
}
function $c(t, e) {
  Mn();
  const i = t.scrollTop, s = e - i;
  if (Math.abs(s) < 1) {
    t.scrollTop = e;
    return;
  }
  let n = 0;
  const c = (r) => {
    n || (n = r);
    const p = Math.min(1, (r - n) / jl);
    t.scrollTop = i + s * (1 - Math.pow(1 - p, 5)), Hi = p < 1 ? requestAnimationFrame(c) : 0;
  };
  Hi = requestAnimationFrame(c);
}
function Hs(t) {
  var _, x;
  if (ci.length === 0) return;
  const e = t.querySelector("#music-lyr");
  if (!e || !e.isConnected || e.clientHeight === 0) return;
  const i = ((y == null ? void 0 : y.progress_ms) ?? 0) / 1e3;
  let s = -1;
  for (let w = 0; w < ci.length && ci[w].at <= i; w++)
    s = w;
  if (s === Nt) return;
  const n = Math.min(Nt, s), c = Math.max(Nt, s);
  for (let w = Math.max(0, n + 1); w <= c; w++)
    (_ = e.querySelector(`.music-lyr-line[data-i="${w}"]`)) == null || _.classList.toggle("done", w <= s);
  (x = e.querySelector(".music-lyr-line.on")) == null || x.classList.remove("on"), Nt = s;
  const r = e.querySelector(`.music-lyr-line[data-i="${s}"]`);
  if (!r) {
    Si || $c(e, 0);
    return;
  }
  if (r.classList.add("on"), Si) return;
  const p = r.getBoundingClientRect().top - e.getBoundingClientRect().top + e.scrollTop;
  $c(e, Math.max(0, p));
}
function qc(t) {
  Si = !0, Mn(), Ze !== void 0 && window.clearTimeout(Ze), Ze = window.setTimeout(() => {
    Ze = void 0, Si = !1, Nt = -1, Hs(t);
  }, Hl);
}
async function $s(t) {
  try {
    f = await d("music_config_get");
  } catch (e) {
    At(t, R(e));
    return;
  }
  !f.connected && D === "player" && (D = "default", ae(t)), ti(t), ni(t);
}
async function Ro(t) {
  if (un === t.id) return;
  un = t.id, on = !0, fe = null;
  const e = Zi;
  e && Rs(e);
  try {
    fe = await d("lyrics_get", {
      title: t.name,
      artist: t.artists,
      album: t.album,
      duration: t.duration_ms / 1e3
    });
  } catch (i) {
    fe = { found: !1, instrumental: !1, track: "", artist: "", album: "", duration: 0, synced: null, plain: null }, e && At(e, R(i));
  } finally {
    on = !1, e && (Rs(e), Hs(e));
  }
}
async function Cn(t, e) {
  if (e === Wt) {
    if (!t.isConnected) {
      Fs();
      return;
    }
    if (du(t), f != null && f.connected) {
      if (!Et) {
        if (!document.hidden && !bs) {
          bs = !0;
          try {
            if (y = await d("spotify_status"), e !== Wt) return;
            ni(t), gn(t), Hs(t), Qu(t), si(t), Qi(t), Et && Ds(t);
          } catch (i) {
            if (e !== Wt) return;
            String(i).includes("ERR_NOT_CONNECTED") ? await $s(t) : (At(t, R(i)), Ds(t), Et && hl(t));
          } finally {
            bs = !1;
          }
        }
        _e && (y != null && y.track) && y.track.id !== zc && yl(t);
      }
      y != null && y.track && Ro(y.track);
    }
    e === Wt && (pt = window.setTimeout(() => void Cn(t, e), Ul));
  }
}
function Fs() {
  pt !== void 0 && (window.clearTimeout(pt), pt = void 0), Ot !== void 0 && (window.clearTimeout(Ot), Ot = void 0), ys !== void 0 && (window.clearInterval(ys), ys = void 0), Wt++, bs = !1;
}
function _n(t) {
  Fs();
  const e = Wt;
  pt = window.setTimeout(() => void Cn(t, e), 200), ys = window.setInterval(() => Do(t), Ql);
}
const No = 2e3;
let xc = 0;
function Po(t) {
  const e = Math.max(400, No - (Date.now() - xc));
  Ot !== void 0 && window.clearTimeout(Ot), Ot = window.setTimeout(() => {
    Ot = void 0, !(!t.isConnected || document.hidden) && (xc = Date.now(), pt !== void 0 && (window.clearTimeout(pt), pt = void 0), pt = window.setTimeout(() => void Cn(t, Wt), 0));
  }, e);
}
function Oo() {
  if (tc) return;
  tc = !0, document.addEventListener("visibilitychange", () => {
    const e = Zi;
    !e || !e.isConnected || (document.hidden ? Fs() : _n(e));
  });
  const t = (e) => {
    const i = Zi;
    if (!i || !i.isConnected || document.hidden) return;
    const s = e.target;
    !s || !i.contains(s) || Po(i);
  };
  document.addEventListener("click", t, !0), document.addEventListener("input", t, !0), document.addEventListener("change", t, !0);
}
function Qi(t) {
  document.getElementById("plugin-titlebar") && (Qt !== void 0 && window.clearTimeout(Qt), Qt = window.setTimeout(() => void Bo(t), 80));
}
async function Bo(t) {
  if (Qt = void 0, !document.getElementById("plugin-titlebar")) return;
  let e = Ol, i = Bl;
  if (ri()) {
    const n = t.closest(".plugin-result"), c = n == null ? void 0 : n.closest("#results-list");
    if (!n || !c) return;
    const r = getComputedStyle(c), p = parseFloat(r.paddingTop || "0") + parseFloat(r.paddingBottom || "0"), _ = window.innerHeight - c.clientHeight;
    i = Math.round(_ + p + n.getBoundingClientRect().height), e = zl;
  }
  const s = `${e}x${i}`;
  if (s !== pn)
    try {
      await d("plugin_window_resize", { width: e, height: i }), pn = s;
    } catch {
    }
}
async function Ho(t) {
  var In, Dn, Rn, Nn, Pn, On, Bn, zn, Wn, Hn, Fn, jn, Qn, Un, Vn, Gn, Yn, Kn, Jn, Xn, Zn, ea, ta, ia, sa, na, aa, ca, la, ua, oa, ra, da, ma, pa, fa, va, ha, ba, ya, ga, _a, wa, ka, Sa, $a, qa, xa, La, Ea, Ta, Ma, Ca, Aa, Ia, Da, Ra, Na, Pa, Oa, Ba, za, Wa, Ha, Fa, ja, Qa, Ua, Va;
  if (Ic) return Ou(t);
  const e = t.querySelector(".music-root");
  if (!e) return;
  Zi = e, Oo(), D = "default", ps = null, fs = !1, Ci = null, _e = !1, pn = "", qt = !1, Ni = !1, bi = ["a", "b"], kn = null, dn = null, gs = "", _s = 0, J = null, jt = "", rn = null, gi.clear(), Pi.clear(), Yi.clear(), we = "playlist", I = null, Me = null, li = !1, vt = "", Gt = null, ut = !1, le = null, Ce = "", Qe = "", Q = null, yi = !1, ze = !1, kt = !1, Ke = "tracks", Ht = [], ie = !1, ne = null, Ms = !1, _i = "", Ue = "", te = !1, ve.clear(), Ki.clear(), We = !1, O = null, wi = !1, Mt = "", Te = null, Ji = "", ui = null, pi(), $e !== void 0 && (window.clearTimeout($e), $e = void 0), S = null, Pt = !1, oe = -1, tt = [], fi();
  const i = Hc();
  B = (i == null ? void 0 : i.queue) ?? [], P = i ? i.index : -1, re = (i == null ? void 0 : i.position_ms) ?? 0, U = !1, Ee = !1, it = [], mt.clear(), os(), Je = "", Y !== void 0 && (window.clearTimeout(Y), Y = void 0), Fe = null, ke = !1, oi = ((In = B[P]) == null ? void 0 : In.path) ?? "";
  const s = (l) => At(e, l), n = (l) => e.querySelector(l);
  Bt && (Bt(), Bt = null), Bt = await qs("spotify-auth", (l) => {
    e.isConnected && (l.payload.ok ? (s(a("music.auth_ok")), $s(e).then(() => {
      _n(e), Is(e, !0);
    })) : s(l.payload.message || a("music.auth_failed")));
  }), zt && (zt(), zt = null), Cs = null, zt = await qs("music-taskbar", (l) => {
    e.isConnected && (l.payload === "prev" ? Dt(e, -1, !1) : l.payload === "next" ? Dt(e, 1, !1) : l.payload === "toggle" && nn(e));
  });
  const c = () => {
    D = "player", ae(e);
  }, r = () => {
    D = "default", ae(e);
  }, p = () => {
    D = "settings", ae(e);
  };
  (Dn = n("#music-setup-toggle")) == null || Dn.addEventListener("click", () => {
    if (U) {
      io(e);
      return;
    }
    p();
  }), (Rn = n("#music-resume")) == null || Rn.addEventListener("click", () => void To(e)), (Nn = n("#music-set-back")) == null || Nn.addEventListener("click", r), (Pn = n("#music-set-tuning")) == null || Pn.addEventListener("click", () => {
    D = "tuning", ae(e);
  }), (On = n("#music-tuning-on")) == null || On.addEventListener("click", () => {
    b && Mu(e, !b.enabled);
  }), el(e), (Bn = n("#music-curve-open")) == null || Bn.addEventListener("click", () => void Bu(e));
  const _ = (l, u, m, h) => {
    var k;
    const g = n(l);
    g == null || g.addEventListener("input", (q) => {
      const N = Number.parseFloat(q.target.value);
      if (!Number.isFinite(N)) return;
      h(N);
      const H = e.querySelector(u);
      H && (H.value = X(N, 1)), ws(e);
    }), g == null || g.addEventListener("change", (q) => {
      const N = Number.parseFloat(q.target.value);
      Number.isFinite(N) && h(N), ce(e);
    }), (k = n(u)) == null || k.addEventListener("change", (q) => {
      const N = q.target, H = Number.parseFloat(N.value.trim());
      if (!Number.isFinite(H)) {
        N.value = X(m(), 1);
        return;
      }
      H !== m() && (h(H), en(e));
    });
  };
  _("#music-preamp-range", "#music-tune-preamp", () => Ui, (l) => Ui = l), _("#music-bass-range", "#music-tune-bass", () => Vi, (l) => Vi = l), _("#music-treble-range", "#music-tune-treble", () => Gi, (l) => Gi = l), (zn = n("#music-tuning-user-presets")) == null || zn.addEventListener("click", (l) => {
    var g;
    const u = l.target.closest(".music-preset-user"), m = u == null ? void 0 : u.dataset.preset;
    if (!m) return;
    const h = ((g = l.target.closest("[data-act]")) == null ? void 0 : g.dataset.act) ?? "use";
    h === "rename" ? (ot = { mode: "rename", from: m, name: m }, he(e), setTimeout(() => {
      var k;
      return (k = e.querySelector("#music-preset-name")) == null ? void 0 : k.select();
    }, 0)) : h === "delete" ? (ot = { mode: "delete", name: m }, he(e)) : Cu(e, m);
  }), (Wn = n("#music-preset-save")) == null || Wn.addEventListener("click", () => {
    var u;
    if (!b) return;
    ot = { mode: "save", name: (u = b.user_presets) != null && u.includes(b.preset) ? b.preset : "", overwrite: !1 }, he(e), setTimeout(() => {
      var m;
      return (m = e.querySelector("#music-preset-name")) == null ? void 0 : m.select();
    }, 0);
  }), (Hn = n("#music-preset-cancel")) == null || Hn.addEventListener("click", () => {
    ot = null, he(e);
  }), (Fn = n("#music-preset-ok")) == null || Fn.addEventListener("click", () => void dc(e)), (jn = n("#music-preset-name")) == null || jn.addEventListener("keydown", (l) => {
    l.key === "Enter" ? (l.preventDefault(), dc(e)) : l.key === "Escape" && (l.preventDefault(), ot = null, he(e));
  }), (Qn = n("#music-preset-import")) == null || Qn.addEventListener("click", () => void Au(e)), (Un = n("#music-preset-export")) == null || Un.addEventListener("click", () => void Du(e));
  const x = () => n("#music-delay-range");
  (Vn = x()) == null || Vn.addEventListener("input", (l) => {
    const u = Number.parseFloat(l.target.value);
    if (!Number.isFinite(u)) return;
    Le = Math.min(Gs, Math.max(0, u));
    const m = e.querySelector("#music-delay-num");
    m && (m.value = X(Le, 1)), ws(e);
  }), (Gn = x()) == null || Gn.addEventListener("change", (l) => {
    const u = Number.parseFloat(l.target.value);
    Number.isFinite(u) && (Le = Math.min(Gs, Math.max(0, u))), ce(e);
  }), (Yn = n("#music-delay-num")) == null || Yn.addEventListener("change", (l) => {
    const u = l.target, m = Number.parseFloat(u.value.trim());
    if (!Number.isFinite(m) || m < 0 || m > Gs) {
      u.value = X(Le, 1);
      return;
    }
    m !== Le && (Le = m, en(e));
  }), (Kn = n("#music-copy-list")) == null || Kn.addEventListener("click", (l) => {
    const u = l.target.closest("[data-act]");
    if (!u) return;
    const m = Number(u.dataset.i), h = u.dataset.act;
    if (h === "menu") {
      const g = u.dataset.side === "to" ? "to" : "from";
      ee = (ee == null ? void 0 : ee.row) === m && ee.side === g ? null : { row: m, side: g }, Kc(e);
    } else if (h === "pick") {
      const g = Ft[m], k = Number(u.dataset.ch);
      if (!g || !Number.isInteger(k)) return;
      u.dataset.side === "to" ? g.to = k : g.from = k, ee = null, ce(e);
    } else h === "del" && (Ft.splice(m, 1), (ee == null ? void 0 : ee.row) === m ? ee = null : ee && ee.row > m && (ee.row -= 1), ce(e));
  }), (Jn = n("#music-copy-add")) == null || Jn.addEventListener("click", () => {
    const l = Math.max(2, (b == null ? void 0 : b.channels) || 2);
    Ft.push({ from: 0, to: Math.min(1, l - 1) }), ce(e);
  }), (Xn = n("#music-conv-pick")) == null || Xn.addEventListener("click", () => void Iu(e)), (Zn = n("#music-conv-clear")) == null || Zn.addEventListener("click", () => {
    vi = null, ce(e);
  }), (ea = n("#music-ab-save-a")) == null || ea.addEventListener("click", () => void oc(e, "a")), (ta = n("#music-ab-save-b")) == null || ta.addEventListener("click", () => void oc(e, "b")), (ia = n("#music-ab-play")) == null || ia.addEventListener("click", (l) => {
    const u = l.target.closest("[data-pos]"), m = Number(u == null ? void 0 : u.dataset.pos);
    (m === 1 || m === 2) && Lu(e, m);
  }), (sa = n("#music-ab-blind")) == null || sa.addEventListener("click", () => {
    qt = !qt, Ni = !1, bi = qt && Math.random() < 0.5 ? ["b", "a"] : ["a", "b"], ts(e);
  }), (na = n("#music-ab-reveal")) == null || na.addEventListener("click", () => {
    Ni = !0, ts(e);
  });
  const w = () => n("#music-tuning-filters");
  (aa = w()) == null || aa.addEventListener("click", (l) => {
    const u = l.target.closest("[data-act]"), m = u == null ? void 0 : u.closest(".music-tune-row"), h = Number(m == null ? void 0 : m.dataset.i), g = se[h];
    if (!u || !m || !g) return;
    const k = u.dataset.act;
    if (k === "on")
      g.on = !g.on, ce(e);
    else if (k === "del")
      se.splice(h, 1), Se === h ? Se = -1 : Se > h && (Se -= 1), ce(e);
    else if (k === "kind")
      Se = Se === h ? -1 : h, Jc(e);
    else if (k === "pick") {
      const q = u.dataset.kind;
      if (!q) return;
      Tu(g, q, (b == null ? void 0 : b.kinds) ?? []), Se = -1, ce(e);
    }
  }), (ca = w()) == null || ca.addEventListener("input", (l) => {
    var H;
    const u = l.target;
    if (!(u instanceof HTMLInputElement) || u.type !== "range") return;
    const m = u.dataset.f, h = u.closest(".music-tune-row"), g = se[Number(h == null ? void 0 : h.dataset.i)];
    if (!m || !g) return;
    const k = Number.parseFloat(u.value);
    if (!Number.isFinite(k)) return;
    if (m === "gain_db") g.gain_db = k;
    else if (m === "q") g.q = k;
    else return;
    const q = h == null ? void 0 : h.querySelector(`input.music-tune-num[data-f="${m}"]`);
    q && (q.value = Xs(g, m));
    const N = (H = u.closest(".music-tune-slider")) == null ? void 0 : H.querySelector("em");
    N && (N.textContent = Xs(g, m)), hi = !0, As(e), ws(e);
  }), (la = w()) == null || la.addEventListener("change", (l) => {
    var N;
    const u = l.target, m = (N = u == null ? void 0 : u.dataset) == null ? void 0 : N.f;
    if (!m) return;
    const h = u.closest(".music-tune-row"), g = se[Number(h == null ? void 0 : h.dataset.i)];
    if (!g) return;
    u.type === "range" && (hi = !1);
    const k = Number.parseFloat(u.value.trim());
    if (!Number.isFinite(k)) {
      u.value = Xs(g, m);
      return;
    }
    let q = !1;
    if (m === "freq_hz")
      q = k !== g.freq_hz, g.freq_hz = k;
    else if (m === "gain_db")
      q = k !== g.gain_db, g.gain_db = k;
    else if (m === "q")
      q = k !== g.q, g.q = k;
    else
      return;
    !q && u.type !== "range" || (u.type === "range" ? ce(e) : en(e));
  }), (ua = n("#music-tune-add")) == null || ua.addEventListener("click", () => {
    se.push(Xl()), ce(e);
  }), (oa = n("#music-avatar")) == null || oa.addEventListener("click", () => {
    D !== "default" && (D = "default", ae(e)), fs = !fs, ti(e);
  }), (ra = n("#music-bnow")) == null || ra.addEventListener("click", c);
  const E = (l) => {
    ie !== l && (ie = l, ii = !1, l ? (!He && (y != null && y.playing) && d("spotify_control", { action: "pause" }).catch(() => {
    }), kt = !1, ze = !1, I = null, Me = null, vt = "", ne = null, O = null, _i = "", Mt = "", ui = null, Te = null) : (pi(), U = !1, mt.clear(), os(), Je = "", Y !== void 0 && (window.clearTimeout(Y), Y = void 0), Fe = null, ke = !1, Ee && (Ee = !1, xt(e)), oi = "", Ji = "", $e !== void 0 && (window.clearTimeout($e), $e = void 0), we = "playlist", S != null && S.path && !He && Lt(e)), ae(e), ni(e), V(e), l && (ul(e), Jt(e), d("media_scan_status").then((u) => {
      !ie || !e.isConnected || (ui = u, u.running && ol(e), st(e));
    }).catch(() => {
    })));
  }, T = (l) => {
    if (l === "tuning") {
      D = "tuning", ae(e);
      return;
    }
    D = "default", E(l === "local"), ae(e);
  }, z = hu(e);
  z == null || z.addEventListener("click", (l) => {
    const u = l.target.closest(".music-tb-seg"), m = u == null ? void 0 : u.dataset.seg;
    m && T(m);
  }), (da = n("#music-local-add")) == null || da.addEventListener("click", () => {
    We = !We, Ii(e);
  }), (ma = n("#music-local-list")) == null || ma.addEventListener("click", () => bo(e)), (pa = n("#music-local-del")) == null || pa.addEventListener("click", () => yo(e)), (fa = n("#music-local-editdone")) == null || fa.addEventListener("click", () => void go(e)), (va = n("#music-main")) == null || va.addEventListener("input", (l) => {
    const u = l.target;
    if ((u == null ? void 0 : u.id) === "music-lq-q") {
      Je = u.value, Y !== void 0 && window.clearTimeout(Y), Y = window.setTimeout(() => {
        Y = void 0, zs(e);
      }, 140);
      return;
    }
    (u == null ? void 0 : u.id) === "music-mt-q" && xo(e, u.value.trim());
  }), (ha = n("#music-l-prev")) == null || ha.addEventListener("click", () => void Dt(e, -1, !1)), (ba = n("#music-l-next")) == null || ba.addEventListener("click", () => void Dt(e, 1, !1)), (ya = n("#music-l-play")) == null || ya.addEventListener("click", () => void nn(e)), (ga = n("#music-l-stop")) == null || ga.addEventListener("click", () => void Lt(e));
  const j = () => {
    !ke && D !== "default" && (D = "default", ae(e)), ke = !ke, V(e), si(e);
  };
  (_a = n("#music-queue-pick")) == null || _a.addEventListener("click", () => void to(e)), (wa = n("#music-queue-cancel")) == null || wa.addEventListener("click", () => {
    Ee = !1, xt(e);
  }), (ka = n("#music-queue-ok")) == null || ka.addEventListener("click", () => fc(e)), (Sa = n("#music-queue-name")) == null || Sa.addEventListener("keydown", (l) => {
    l.key === "Enter" ? (l.preventDefault(), fc(e)) : l.key === "Escape" && (l.preventDefault(), Ee = !1, xt(e));
  }), ($a = n("#music-queue-dlg")) == null || $a.addEventListener("pointerdown", (l) => {
    l.target.classList.contains("music-dlg-mask") && (Ee = !1, xt(e));
  }), (qa = n("#music-del-ok")) == null || qa.addEventListener("click", () => void no(e)), (xa = n("#music-del-cancel")) == null || xa.addEventListener("click", () => yn(e)), (La = n("#music-del-dlg")) == null || La.addEventListener("pointerdown", (l) => {
    l.target.classList.contains("music-dlg-mask") && yn(e);
  }), (Ea = n("#music-b-drawer")) == null || Ea.addEventListener("click", () => {
    ii = !0, si(e), V(e);
  }), (Ta = n("#music-l-drawer")) == null || Ta.addEventListener("click", () => {
    ii = !1, si(e), V(e);
  });
  const be = n("#music-l-vol");
  be == null || be.addEventListener("input", () => {
    di(be, Number(be.value)), yc(e, Number(be.value) / 100);
  });
  const Ve = () => {
    const l = ["off", "shuffle", "repeat_all", "repeat_one"];
    ue = l[(l.indexOf(ue) + 1) % l.length], lu(ue), V(e), $(e, $n());
  };
  (Ma = n("#music-l-mode")) == null || Ma.addEventListener("click", Ve);
  const Ne = (l, u) => {
    const m = (k) => {
      const q = l.getBoundingClientRect();
      return Math.max(0, Math.min(1, (k - q.left) / Math.max(1, q.width)));
    }, h = (k) => {
      oe = k, l.style.setProperty("--seek-pct", `${k * 100}%`), u(k);
    };
    l.addEventListener("pointerdown", (k) => {
      if (!(((S == null ? void 0 : S.duration_ms) ?? 0) <= 0)) {
        try {
          l.setPointerCapture(k.pointerId);
        } catch {
        }
        l.classList.add("music-dragging"), h(m(k.clientX));
      }
    }), l.addEventListener("pointermove", (k) => {
      oe < 0 || h(m(k.clientX));
    });
    const g = (k) => {
      if (oe < 0) return;
      const q = oe;
      oe = -1, l.classList.remove("music-dragging");
      try {
        l.releasePointerCapture(k.pointerId);
      } catch {
      }
      qo(e, Math.round(((S == null ? void 0 : S.duration_ms) ?? 0) * q));
    };
    l.addEventListener("pointerup", g), l.addEventListener("pointercancel", g);
  }, Pe = n("#music-lbp");
  Pe && Ne(Pe, (l) => {
    const u = (S == null ? void 0 : S.duration_ms) ?? 0;
    M(Pe.querySelector(".music-progress-tip"), Fi(u * l));
    const m = e.querySelector("#music-l-time");
    m && M(m, `${K(u * l)} / ${K(u)}`);
  });
  const ye = async () => {
    var l;
    if (!S || !S.path) {
      const u = ((l = B[P]) == null ? void 0 : l.path) ?? "";
      if (!u || !await ht(e, u, re)) return;
    }
    D = "lplayer", ae(e);
  };
  (Ca = n("#music-lnow")) == null || Ca.addEventListener("click", () => void ye()), (Aa = n("#music-lp-prev")) == null || Aa.addEventListener("click", () => void Dt(e, -1, !1)), (Ia = n("#music-lp-next")) == null || Ia.addEventListener("click", () => void Dt(e, 1, !1)), (Da = n("#music-lp-play")) == null || Da.addEventListener("click", () => void nn(e)), (Ra = n("#music-lp-stop")) == null || Ra.addEventListener("click", () => void Lt(e)), (Na = n("#music-lp-mode")) == null || Na.addEventListener("click", Ve);
  const nt = n("#music-lp-vol");
  nt == null || nt.addEventListener("input", () => {
    di(nt, Number(nt.value)), yc(e, Number(nt.value) / 100);
  });
  const Ei = n("#music-lp-progress");
  Ei && Ne(Ei, (l) => {
    const u = (S == null ? void 0 : S.duration_ms) ?? 0;
    M(Ei.querySelector(".music-progress-tip"), Fi(u * l));
    const m = e.querySelector("#music-lp-time");
    m && M(m, `${K(u * l)} / ${K(u)}`);
  });
  const bt = (l) => {
    var u;
    !e.isConnected || !ri() || (u = l.target) != null && u.closest("#plugin-close") && (l.stopPropagation(), l.preventDefault(), D === "lplayer" ? r() : gu(e));
  };
  document.addEventListener("click", bt, !0), (Pa = n("#music-fields-toggle")) == null || Pa.addEventListener("click", () => {
    ps = !(ps ?? !(f != null && f.builtin)), ti(e);
  }), (Oa = n("#music-copy-redirect")) == null || Oa.addEventListener("click", () => {
    const l = (f == null ? void 0 : f.redirect_uri) || "";
    l && Al(l).then(() => s(a("music.copied"))).catch(() => {
    });
  });
  for (const l of e.querySelectorAll("#music-quality .music-seg-btn"))
    l.addEventListener("click", () => {
      Ci = Number(l.dataset.q), ti(e);
    });
  (Ba = n("#music-set-save")) == null || Ba.addEventListener("click", async () => {
    try {
      f = await d("music_config_set", { librespotBitrate: Ci }), Ci = null, s(a("music.saved")), ti(e), ni(e);
    } catch (l) {
      s(R(l));
    }
  }), (za = n("#music-save")) == null || za.addEventListener("click", async () => {
    var h, g, k, q;
    const l = ((h = n("#music-client-id")) == null ? void 0 : h.value.trim()) ?? "", u = ((g = n("#music-port")) == null ? void 0 : g.value.trim()) ?? "", m = Number(u);
    if (!l) {
      s(a("music.err_no_client_id"));
      return;
    }
    if (!Number.isInteger(m) || m < 1024 || m > 65535) {
      s(a("music.err_bad_port"));
      return;
    }
    try {
      f = await d("music_config_set", {
        clientId: l,
        port: m,
        // 本机播放那两项**一起交上去**（留空 = 自动探测 / 直连，都是合法值）
        librespotPath: ((k = n("#music-librespot")) == null ? void 0 : k.value.trim()) ?? "",
        librespotProxy: ((q = n("#music-librespot-proxy")) == null ? void 0 : q.value.trim()) ?? ""
        // 音质**不在这里提交**（2026-10-01 起它归设置页，那个页面有自己的「保存」）：
        // 不传 = `None` = 别动，宿主本来就是这个语义。把两页的保存混在一处，
        // 就会出现「在设置页点了 320、回连接卡片点保存、结果把它一起落盘了」。
      }), s(a("music.saved")), ti(e), ni(e), le = null;
    } catch (N) {
      s(R(N));
    }
  }), (Wa = n("#music-connect")) == null || Wa.addEventListener("click", async () => {
    var m, h;
    const l = ((m = n("#music-client-id")) == null ? void 0 : m.value.trim()) ?? "", u = Number(((h = n("#music-port")) == null ? void 0 : h.value.trim()) ?? "");
    if (l && Number.isInteger(u) && u >= 1024)
      try {
        f = await d("music_config_set", {
          clientId: l,
          port: u,
          librespotPath: null,
          librespotProxy: null,
          // 串流质量同上：这条路径只是「先落盘再连」，别动用户选的档
          librespotBitrate: null
        });
      } catch (g) {
        s(R(g));
        return;
      }
    try {
      const g = await d("spotify_connect");
      s(a("music.browser_hint")), await Cl(g);
    } catch (g) {
      s(R(g));
    }
  }), (Ha = n("#music-disconnect")) == null || Ha.addEventListener("click", async () => {
    try {
      await d("spotify_disconnect"), y = null, fe = null, un = "", rn = null, gi.clear(), Yi.clear(), dt = null, _e = !1, I = null, Me = null, vt = "", Q = null, Qe = "", ze = !1, kt = !1, Gt = null, D = "default", await $s(e), ae(e), Ss(e), s(a("music.disconnected"));
    } catch (l) {
      s(R(l));
    }
  });
  const Oe = 500;
  let yt, me;
  const Ge = () => {
    yt !== void 0 && (window.clearTimeout(yt), yt = void 0);
  }, L = (l) => {
    Ge(), yt = window.setTimeout(() => {
      yt = void 0, l();
    }, Oe);
  }, W = (l) => {
    const u = Date.now(), m = !!me && me.key === l && u - me.at <= Oe;
    return me = m ? void 0 : { key: l, at: u }, m;
  }, pe = (l) => {
    Ae.some((u) => u.id === l) && (G = l, ki(), U = !1, te = !1, ve.clear(), Tt.clear(), mt.clear(), os(), Je = "", Y !== void 0 && (window.clearTimeout(Y), Y = void 0), ie || E(!0), D = "default", ae(e));
  }, Be = (l, u) => {
    var m;
    if (u) {
      if (l === "playlist" && ((m = Tn(l, u)) == null ? void 0 : m.total) === 0) {
        $(e, a("music.playlist_empty"));
        return;
      }
      wc(e, l, u);
    }
  }, at = (l) => {
    const u = Ae.find((m) => m.id === l);
    if (u) {
      if (u.items.length === 0) {
        $(e, a("music.local_queue_page_empty"));
        return;
      }
      sn(e, u.items[0].path, u);
    }
  }, It = async (l) => {
    const u = l ? ne == null ? void 0 : ne.find((h) => h.path === l) : void 0;
    if (u != null && u.missing) {
      $(e, a("music.local_missing"));
      return;
    }
    let m;
    try {
      m = await d("media_tracks", {
        root: l || null,
        // 空串 ⇒ 全部曲目（宿主 `Option<String>` 收 None）
        query: null,
        // 双击播的是整个目录，不是当前筛选后的子集
        limit: Oc
        // 与主区列表同一个上限，双击播到的就是会显示的那批
      });
    } catch (h) {
      $(e, dl(h));
      return;
    }
    if (m.items.length === 0) {
      $(e, a("music.local_empty"));
      return;
    }
    sn(e, m.items[0].path, m);
  }, Ti = (l) => {
    var k;
    const u = (k = l.target) == null ? void 0 : k.closest("[data-act]");
    if (!u) return;
    const m = u.dataset.kind || "", h = u.dataset.id || "", g = u.dataset.act === "open" || u.dataset.act === "local-queue" || u.dataset.act === "media-root";
    switch ((!u.closest("#music-side-list") || !g) && (Ge(), me = void 0), u.dataset.act) {
      case "side-tab":
        we = u.dataset.tab || "playlist", Kt(e), vl(e, we);
        break;
      case "search-tab":
        Ke = u.dataset.tab || "tracks", Ie(e);
        break;
      case "open": {
        if (!u.closest("#music-side-list")) {
          _c(e, m, h);
          break;
        }
        if (W(`open:${m}:${h}`)) {
          Ge(), Be(m, h);
          break;
        }
        L(() => void _c(e, m, h));
        break;
      }
      case "main-track": {
        ds(e, u, l);
        break;
      }
      case "main-play-all":
        I && wc(e, I.kind, I.id);
        break;
      case "dd-track":
        u.dataset.uri && cn(e, u.dataset.uri);
        break;
      case "play-uri": {
        ds(e, u, l);
        break;
      }
      case "search-all":
        ze = !1, kt = !0, et(e), Ie(e);
        break;
      case "dev-pick":
        Ao(e, h);
        break;
      case "local-toggle":
        Mo(e);
        break;
      case "local-login":
        Co(e);
        break;
      // ── 本地音乐页（2026-10-01）──
      case "media-root": {
        const q = u.dataset.path || "";
        if (te) {
          Ge(), me = void 0, q && (ve.has(q) ? ve.delete(q) : ve.add(q)), De(e);
          break;
        }
        const N = q ? `media-root:${q}` : "media-root:*";
        if (U)
          me = void 0;
        else if (W(N)) {
          Ge(), It(q);
          break;
        }
        L(() => {
          Ge(), Ue = q, G !== null && (G = null, te = !1, ve.clear(), Tt.clear(), mt.clear(), os(), Je = "", Y !== void 0 && (window.clearTimeout(Y), Y = void 0), ki()), De(e), Jt(e);
        });
        break;
      }
      case "media-scan":
        if (U) {
          U = !1, qe("library"), es(e), bn(e);
          break;
        }
        rl(e);
        break;
      // 「自定义队列」开关（2026-10-10 用户口径：入口从齿轮挪到本地页筛选行最右侧；
      // 2026-10-11 改：开启 = 进**列表勾选编辑态**，不再弹小窗）。
      case "qmode":
        U = !U, qe("library"), U && (We = !1), es(e), bn(e);
        break;
      // `＋` 浮层里的两行（2026-10-01）：目录 vs 播放列表文件。
      // **先关浮层再干活** —— 目录对话框是模态的，浮层留着会在对话框背后一闪一闪。
      case "media-add-dir":
        We = !1, Ii(e), vo(e);
        break;
      case "media-add-list":
        We = !1, Ii(e), _o(e);
        break;
      case "media-list-close":
        wo(e);
        break;
      case "local-track": {
        ds(e, u, l);
        break;
      }
      // ── 本地「自定义队列」（2026-10-11 用户口径：多条，列在左栏）──
      case "local-queue": {
        const q = u.dataset.qid || "";
        if (!Ae.some((N) => N.id === q)) break;
        if (te) {
          F.queueList.ids.has(q) ? F.queueList.ids.delete(q) : F.queueList.ids.add(q), F.queueList.anchor = q, De(e);
          break;
        }
        if (W(`local-queue:${q}`)) {
          Ge(), at(q);
          break;
        }
        L(() => pe(q));
        break;
      }
      // ── 队列详情页（2026-10-09 用户口径；2026-10-11 由左栏选中驱动）──
      case "queue-track": {
        ds(e, u, l);
        break;
      }
      // 本地队列**下拉浮层**（`#music-lq-dd`）里的行 = 播放队列（`localQueue`）的一首：
      // **单击 = 从这一首起播**（不参与多选；鼠标移上去只是 hover 预选 + 右侧显形 ×）。
      case "queue-play":
        So(e, Number(u.dataset.i || "0"));
        break;
      // 播放队列行右侧的 ×：只从播放队列移除（不删磁盘、不动任何自定义队列）。
      case "queue-remove":
        l.stopPropagation(), mo(e, Number(u.dataset.i || "0"));
        break;
      // 浮层右上角的「一键清除队列」：只清播放队列（不删磁盘、不动任何自定义队列）。
      // 按钮不是曲目行的一部分 ⇒ 不冒泡、不触发 queue-play；清除后浮层保持打开（显示空态）。
      case "queue-clear":
        l.stopPropagation(), po(e);
        break;
    }
  };
  for (const l of ["#music-side-list", "#music-side-tabs", "#music-main", "#music-search-dd", "#music-dev-dd", "#music-q", "#music-q-dd", "#music-lq-dd", "#music-local-add-dd"])
    (Fa = n(l)) == null || Fa.addEventListener("click", Ti);
  e.addEventListener("dblclick", (l) => {
    var m;
    const u = (m = l.target) == null ? void 0 : m.closest("[data-act]");
    if (u)
      switch (u.dataset.act) {
        case "local-track": {
          rs(e, "library", u.dataset.path || ""), ko(e, Number(u.dataset.i || "0"));
          break;
        }
        case "queue-track": {
          const h = u.dataset.path || "";
          rs(e, "queue", h), sn(e, h);
          break;
        }
        case "main-track": {
          rs(e, "onlineMain", u.dataset.uri || ""), kc(e, Number(u.dataset.i || "0"));
          break;
        }
        case "play-uri": {
          const h = u.dataset.uri || "";
          rs(e, "onlineQueue", h), h && cn(e, h);
          break;
        }
      }
  }), e.addEventListener("contextmenu", (l) => {
    var Ga;
    const u = (Ga = l.target) == null ? void 0 : Ga.closest("[data-act]");
    if (!u) return;
    const m = u.dataset.act || "";
    if (m === "local-queue") return;
    const h = Xt[m];
    if (!h) return;
    l.preventDefault(), l.stopPropagation();
    const g = Number(u.dataset.i || "0"), k = u.dataset.path || "", q = u.dataset.uri || "", N = m === "local-queue" ? u.dataset.qid || "" : m === "queue-track" ? G ?? "" : "", H = F[h], Ye = Ws(u);
    Ye && !H.ids.has(Ye) && (H.ids.clear(), H.ids.add(Ye), H.anchor = Ye, is(e, h)), Fe = { act: m, i: g, path: k, uri: q, qid: N }, lo(e, l.clientX, l.clientY);
  }), (ja = n("#music-ctx")) == null || ja.addEventListener("click", (l) => {
    var g, k, q, N;
    const u = (g = l.target) == null ? void 0 : g.closest("[data-ctx]");
    if (!u) return;
    const m = u.dataset.ctx || "", h = Fe;
    if (h) {
      if (m === "add-play-queue") {
        ro(e), _t(e);
        return;
      }
      if (m === "reveal") {
        h.path && d("reveal_in_explorer", { path: h.path }).catch((H) => $(e, String(H))), _t(e);
        return;
      }
      if (m === "delete-file") {
        const H = h.path && ((k = O == null ? void 0 : O.items.find((Ye) => Ye.path === h.path)) == null ? void 0 : k.title) || h.path && ((N = (q = Li()) == null ? void 0 : q.items.find((Ye) => Ye.path === h.path)) == null ? void 0 : N.title) || "";
        _t(e), so(e, h.path, H);
        return;
      }
      if (m === "remove-queue") {
        oo(e), _t(e);
        return;
      }
      if (m === "play") {
        _t(e), h.act === "main-track" ? kc(e, h.i) : h.act === "play-uri" && h.uri && cn(e, h.uri);
        return;
      }
    }
  }), document.addEventListener("keydown", (l) => {
    var u;
    l.key === "Escape" && ((u = n("#music-ctx")) != null && u.classList.contains("open")) && _t(e);
  }), e.addEventListener("pointerdown", (l) => {
    var u;
    lt = ((u = bc(l.target)) == null ? void 0 : u.list) ?? null;
  }, !0), e.addEventListener("focusin", (l) => {
    var u;
    lt = ((u = bc(l.target)) == null ? void 0 : u.list) ?? null;
  }), e.addEventListener("keydown", (l) => {
    var m;
    const u = l.target;
    if (!(u && (u.closest("input, textarea, select") || u.isContentEditable))) {
      if (l.key === "Escape") {
        if ((m = n("#music-ctx")) != null && m.classList.contains("open")) {
          _t(e);
          return;
        }
        lt && qe(lt) && (is(e, lt), l.preventDefault());
        return;
      }
      if ((l.ctrlKey || l.metaKey) && !l.altKey && !l.shiftKey && l.key.toLowerCase() === "a") {
        if (!lt || lt === "queueList" && !te) return;
        l.preventDefault(), $o(e, lt);
      }
    }
  }), (Qa = n("#music-devices-btn")) == null || Qa.addEventListener("click", () => {
    ut = !ut, $i(e), ut && qi(e);
  }), gc(e), (Ua = n("#music-split")) == null || Ua.addEventListener("pointerdown", (l) => {
    var k;
    l.preventDefault();
    const u = l.clientX, m = ((k = n("#music-side")) == null ? void 0 : k.getBoundingClientRect().width) ?? Oi, h = (q) => {
      Oi = Math.min(Nc, Math.max(Rc, Math.round(m + q.clientX - u))), gc(e);
    }, g = () => {
      window.removeEventListener("pointermove", h), window.removeEventListener("pointerup", g), document.body.classList.remove("music-resizing");
    };
    document.body.classList.add("music-resizing"), window.addEventListener("pointermove", h), window.addEventListener("pointerup", g);
  }), document.addEventListener("pointerdown", (l) => {
    const u = l.target;
    u && (ut && !u.closest("#music-dev-dd") && !u.closest("#music-devices-btn") && (ut = !1, $i(e)), ze && !u.closest(".music-search-wrap") && (ze = !1, et(e)), We && !u.closest("#music-local-add-dd") && !u.closest("#music-local-add") && (We = !1, Ii(e)), _e && !u.closest("#music-q-dd") && !u.closest("#music-b-queue") && !u.closest("#music-queue-btn") && (_e = !1, an(e)), ke && !u.closest("#music-lq-dd") && !u.closest("#music-l-queue") && !u.closest("#music-lp-queue") && (ke = !1, V(e)), Fe && !u.closest("#music-ctx") && _t(e));
  });
  const Z = n("#music-search");
  Z == null || Z.addEventListener("input", () => Sc(e, Z.value.trim())), Z == null || Z.addEventListener("focus", () => {
    Qe && (ze = !0, et(e));
  }), Z == null || Z.addEventListener("keydown", (l) => {
    if (l.key === "Enter" && Qe) {
      ze = !1, kt = !0, et(e), Ie(e);
      return;
    }
    l.key === "Escape" && (Z.value = "", Sc(e, ""));
  }), document.body.addEventListener("mouseenter", () => Qi(e)), document.body.addEventListener("mouseleave", () => Qi(e));
  const ct = async (l, u) => {
    l === "play" && await as(e, "spotify");
    try {
      await d("spotify_control", { action: l, value: u });
    } catch (m) {
      s(R(m));
    }
  }, gt = (l, u) => {
    var m;
    for (const h of l) (m = n(`#${h}`)) == null || m.addEventListener("click", u);
  }, _l = () => {
    _e = !_e, an(e), Ss(e), _e ? yl(e) : gn(e), Qi(e);
  };
  e.addEventListener("click", (l) => {
    var h;
    const u = l.target;
    if (!u) return;
    const m = u.closest("#music-l-queue, #music-lp-queue, #music-queue-btn, #music-b-queue");
    if (m && d("log_frontend", { level: "warn", message: `[music] queue-btn hit id=${m.id}` }).catch(() => {
    }), u.closest("#music-l-queue, #music-lp-queue")) {
      j();
      const g = e.querySelector("#music-lq-dd"), k = e.querySelector("#music-body"), q = e.querySelector("#music-v-default");
      d("log_frontend", {
        level: "warn",
        message: `[music] queue AFTER toggleLocalQueue: mode=${D} localPage=${ie} activeQueueId=${G} localQueueOpen=${ke} localQueueLen=${B.length} barMode=${ri()} ddExists=${!!g} ddHidden=${g ? g.classList.contains("hidden") : "n/a"} bodyHidden=${k ? k.classList.contains("hidden") : "n/a"} defaultHidden=${q ? q.classList.contains("hidden") : "n/a"}`
      }).catch(() => {
      });
      return;
    }
    if (u.closest("#music-queue-btn, #music-b-queue")) {
      _l();
      const g = e.querySelector("#music-q-dd"), k = e.querySelector("#music-q-wrap");
      d("log_frontend", {
        level: "warn",
        message: `[music] queue AFTER toggleQueue: queueOpen=${_e} barMode=${ri()} ddExists=${!!g} ddHidden=${g ? g.classList.contains("hidden") : "n/a"} wrapHidden=${k ? k.classList.contains("hidden") : "n/a"} items=${dt ? ((h = dt.items) == null ? void 0 : h.length) ?? 0 : "no-queue"}`
      }).catch(() => {
      });
      return;
    }
  }), gt(["music-prev", "music-b-prev"], () => void ct("previous")), gt(["music-next", "music-b-next"], () => void ct("next")), gt(["music-play", "music-b-play"], () => void ct(y != null && y.playing ? "pause" : "play")), gt(["music-dual-btn", "music-l-dual-btn"], () => {
    He = !He, au(He), He || (ii = !1), !He && !ie && S && Lt(e), V(e), si(e), $(e, a(He ? "music.dual_on" : "music.dual_off"));
  });
  let cs = null, js = !1;
  const wl = async (l) => {
    if (cs = l, !js) {
      js = !0;
      try {
        for (; cs !== null; ) {
          const u = cs;
          cs = null, await ct("volume", u);
        }
      } finally {
        js = !1;
      }
    }
  };
  for (const l of ["music-vol", "music-b-vol"])
    (Va = n(`#${l}`)) == null || Va.addEventListener("input", (u) => {
      const m = u.target, h = Number(m.value);
      di(m, h), wl(h);
    });
  gt(["music-mode", "music-b-mode"], () => {
    const l = gl();
    d("spotify_set_play_mode", { mode: l === "off" ? "shuffle" : l === "shuffle" ? "repeat_one" : "off" }).catch((m) => s(R(m)));
  }), Ht = ["#music-pv-progress", "#music-bp"].map((l) => n(l)).filter((l) => !!l);
  for (const l of Ht) {
    const u = (g) => {
      const k = l.getBoundingClientRect();
      return Math.max(0, Math.min(1, (g - k.left) / Math.max(1, k.width)));
    }, m = (g) => {
      var H;
      Rt = g;
      const k = `${g * 100}%`;
      for (const Ye of Ht) Ye.style.setProperty("--seek-pct", k);
      const q = ((H = y == null ? void 0 : y.track) == null ? void 0 : H.duration_ms) ?? 0, N = K(q * g);
      M(l.querySelector(".music-progress-tip"), Fi(q * g)), M(n("#music-pv-pos"), N), M(n("#music-b-time"), `${N} / ${K(q)}`);
    };
    l.addEventListener("pointerdown", (g) => {
      var k;
      if (!((((k = y == null ? void 0 : y.track) == null ? void 0 : k.duration_ms) ?? 0) <= 0)) {
        try {
          l.setPointerCapture(g.pointerId);
        } catch {
        }
        l.classList.add("music-dragging"), m(u(g.clientX));
      }
    }), l.addEventListener("pointermove", (g) => {
      Rt < 0 || m(u(g.clientX));
    });
    const h = (g) => {
      var q;
      if (Rt < 0) return;
      const k = Rt;
      Rt = -1, l.classList.remove("music-dragging");
      try {
        l.releasePointerCapture(g.pointerId);
      } catch {
      }
      ct("seek", Math.round((((q = y == null ? void 0 : y.track) == null ? void 0 : q.duration_ms) ?? 0) * k));
    };
    l.addEventListener("pointerup", h), l.addEventListener("pointercancel", h);
  }
  const xe = n("#music-lyr");
  let Qs = !1, An = 0;
  xe == null || xe.addEventListener("wheel", () => qc(e), { passive: !0 }), xe == null || xe.addEventListener("pointerdown", (l) => {
    Qs = !1, An = l.clientY, qc(e);
  }), xe == null || xe.addEventListener("pointermove", (l) => {
    Math.abs(l.clientY - An) > 4 && (Qs = !0);
  }), xe == null || xe.addEventListener("click", (l) => {
    if (Qs) return;
    const u = l.target.closest(".music-lyr-line"), m = u ? ci[Number(u.dataset.i)] : void 0;
    m && ct("seek", Math.round(m.at * 1e3));
  }), await $s(e), ae(e), gn(e), Rs(e), Ss(e), an(e), ni(e), ll(), await hl(e), _n(e), Is(e);
}
async function cn(t, e) {
  await as(t, "spotify");
  try {
    await d("spotify_play_uri", { uri: e, deviceId: Ce || void 0 });
  } catch (i) {
    At(t, R(i));
  }
}
function zo() {
  vn(), qn(), Fs(), Zi = null, Ze !== void 0 && (window.clearTimeout(Ze), Ze = void 0), Qt !== void 0 && (window.clearTimeout(Qt), Qt = void 0), St !== void 0 && (window.clearTimeout(St), St = void 0), pi(), $e !== void 0 && (window.clearTimeout($e), $e = void 0), fi(), S != null && S.path && (re = S.position_ms, Yt(), S = null, B = [], P = -1, d("player_stop").catch(() => {
  })), Bt && (Bt(), Bt = null), zt && (zt(), zt = null), Cs = null, Ht = [], ii = !1, fu(), yu();
}
window.__lunac_music_stop = zo;
const Fo = {
  id: "music",
  name: "音乐歌词",
  keywords: ["音乐", "歌词", "歌曲", "正在播放", "music", "lyrics", "spotify", "播放控制", "暂停", "下一首", "歌单", "播放列表"],
  description: "歌词自动抓取 (LRCLIB + 网易云兜底) + Spotify 播放控制 / 歌单 / 队列",
  icon: "🎵",
  badge: "music",
  // 「本插件一律在**悬浮窗**里打开」（2026-09-29 从 main.ts 的硬编码 `id === "music"` 改成声明）。
  // 为什么要声明而不是让宿主按 id 判：音乐已归入**拓展插件**，要能从市场独立打包分发
  // —— 磁盘插件的代码宿主没法写死，行为只能由插件自己声明（见 ai-spec §3.5「插件契约」）。
  // 这也是「用户 2026-09-28 定的：从 Lunac 进音乐界面时自动展开成独立界面」那条的执行点。
  permissions: ["window.float"],
  async execute() {
    return { type: "html", content: Ic ? ou() : ru() };
  }
};
export {
  Ho as attach,
  Ho as attachMusicListeners,
  Fo as default,
  zo as detach,
  Fo as musicPlugin,
  zo as stopMusicPolling
};
