const bl = "__lunac_host";
function yl() {
  return globalThis[bl] ?? null;
}
function a(t, e) {
  const i = yl();
  return i && typeof i.t == "function" ? i.t(t, e) : t;
}
function gl(t, e, i, s) {
  if (typeof e == "function" ? t !== e || !s : !e.has(t)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? s : i === "a" ? s.call(t) : s ? s.value : e.get(t);
}
function _l(t, e, i, s, n) {
  if (typeof e == "function" ? t !== e || !0 : !e.has(t)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return e.set(t, i), i;
}
var ds;
const Re = "__TAURI_TO_IPC_KEY__";
function wl(t, e = !1) {
  return window.__TAURI_INTERNALS__.transformCallback(t, e);
}
async function d(t, e = {}, i) {
  return window.__TAURI_INTERNALS__.invoke(t, e, i);
}
function Is(t, e = "asset") {
  return window.__TAURI_INTERNALS__.convertFileSrc(t, e);
}
class kl {
  get rid() {
    return gl(this, ds, "f");
  }
  constructor(e) {
    ds.set(this, void 0), _l(this, ds, e);
  }
  /**
   * Destroys and cleans up this resource from memory.
   * **You should not call any method on this object anymore and should drop any reference to it.**
   */
  async close() {
    return d("plugin:resources|close", {
      rid: this.rid
    });
  }
}
ds = /* @__PURE__ */ new WeakMap();
var ge;
(function(t) {
  t.WINDOW_RESIZED = "tauri://resize", t.WINDOW_MOVED = "tauri://move", t.WINDOW_CLOSE_REQUESTED = "tauri://close-requested", t.WINDOW_DESTROYED = "tauri://destroyed", t.WINDOW_FOCUS = "tauri://focus", t.WINDOW_BLUR = "tauri://blur", t.WINDOW_SCALE_FACTOR_CHANGED = "tauri://scale-change", t.WINDOW_THEME_CHANGED = "tauri://theme-changed", t.WINDOW_CREATED = "tauri://window-created", t.WINDOW_SUSPENDED = "tauri://suspended", t.WINDOW_RESUMED = "tauri://resumed", t.WEBVIEW_CREATED = "tauri://webview-created", t.DRAG_ENTER = "tauri://drag-enter", t.DRAG_OVER = "tauri://drag-over", t.DRAG_DROP = "tauri://drag-drop", t.DRAG_LEAVE = "tauri://drag-leave";
})(ge || (ge = {}));
async function Sc(t, e) {
  window.__TAURI_EVENT_PLUGIN_INTERNALS__.unregisterListener(t, e), await d("plugin:event|unlisten", {
    event: t,
    eventId: e
  });
}
async function bn(t, e, i) {
  var s;
  const n = typeof (i == null ? void 0 : i.target) == "string" ? { kind: "AnyLabel", label: i.target } : (s = i == null ? void 0 : i.target) !== null && s !== void 0 ? s : { kind: "Any" };
  return d("plugin:event|listen", {
    event: t,
    target: n,
    handler: wl(e)
  }).then((c) => async () => Sc(t, c));
}
async function Sl(t, e, i) {
  return bn(t, (s) => {
    Sc(t, s.id), e(s);
  }, i);
}
async function $l(t, e) {
  await d("plugin:event|emit", {
    event: t,
    payload: e
  });
}
async function ql(t, e, i) {
  await d("plugin:event|emit_to", {
    target: typeof t == "string" ? { kind: "AnyLabel", label: t } : t,
    event: e,
    payload: i
  });
}
async function Ll(t, e) {
  await d("plugin:shell|open", {
    path: t,
    with: e
  });
}
class Ii extends kl {
  /**
   * Creates an Image from a resource ID. For internal use only.
   *
   * @ignore
   */
  constructor(e) {
    super(e);
  }
  /** Creates a new Image using RGBA data, in row-major order from top to bottom, and with specified width and height. */
  static async new(e, i, s) {
    return d("plugin:image|new", {
      rgba: $s(e),
      width: i,
      height: s
    }).then((n) => new Ii(n));
  }
  /**
   * Creates a new image using the provided bytes by inferring the file format.
   * If the format is known, prefer [@link Image.fromPngBytes] or [@link Image.fromIcoBytes].
   *
   * Only `ico` and `png` are supported (based on activated feature flag).
   *
   * Note that you need the `image-ico` or `image-png` Cargo features to use this API.
   * To enable it, change your Cargo.toml file:
   * ```toml
   * [dependencies]
   * tauri = { version = "...", features = ["...", "image-png"] }
   * ```
   */
  static async fromBytes(e) {
    return d("plugin:image|from_bytes", {
      bytes: $s(e)
    }).then((i) => new Ii(i));
  }
  /**
   * Creates a new image using the provided path.
   *
   * Only `ico` and `png` are supported (based on activated feature flag).
   *
   * Note that you need the `image-ico` or `image-png` Cargo features to use this API.
   * To enable it, change your Cargo.toml file:
   * ```toml
   * [dependencies]
   * tauri = { version = "...", features = ["...", "image-png"] }
   * ```
   */
  static async fromPath(e) {
    return d("plugin:image|from_path", { path: e }).then((i) => new Ii(i));
  }
  /** Returns the RGBA data for this image, in row-major order from top to bottom.  */
  async rgba() {
    return d("plugin:image|rgba", {
      rid: this.rid
    }).then((e) => new Uint8Array(e));
  }
  /** Returns the size of this image.  */
  async size() {
    return d("plugin:image|size", { rid: this.rid });
  }
}
function $s(t) {
  return t == null ? null : typeof t == "string" ? t : t instanceof Ii ? t.rid : t;
}
async function xl(t, e) {
  await d("plugin:clipboard-manager|write_text", {
    label: e == null ? void 0 : e.label,
    text: t
  });
}
async function is(t = {}) {
  return typeof t == "object" && Object.freeze(t), await d("plugin:dialog|open", { options: t });
}
async function El(t = {}) {
  return typeof t == "object" && Object.freeze(t), await d("plugin:dialog|save", { options: t });
}
class $c {
  constructor(...e) {
    this.type = "Logical", e.length === 1 ? "Logical" in e[0] ? (this.width = e[0].Logical.width, this.height = e[0].Logical.height) : (this.width = e[0].width, this.height = e[0].height) : (this.width = e[0], this.height = e[1]);
  }
  /**
   * Converts the logical size to a physical one.
   * @example
   * ```typescript
   * import { LogicalSize } from '@tauri-apps/api/dpi';
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   *
   * const appWindow = getCurrentWindow();
   * const factor = await appWindow.scaleFactor();
   * const size = new LogicalSize(400, 500);
   * const physical = size.toPhysical(factor);
   * ```
   *
   * @since 2.0.0
   */
  toPhysical(e) {
    return new Di(this.width * e, this.height * e);
  }
  [Re]() {
    return {
      width: this.width,
      height: this.height
    };
  }
  toJSON() {
    return this[Re]();
  }
}
class Di {
  constructor(...e) {
    this.type = "Physical", e.length === 1 ? "Physical" in e[0] ? (this.width = e[0].Physical.width, this.height = e[0].Physical.height) : (this.width = e[0].width, this.height = e[0].height) : (this.width = e[0], this.height = e[1]);
  }
  /**
   * Converts the physical size to a logical one.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const appWindow = getCurrentWindow();
   * const factor = await appWindow.scaleFactor();
   * const size = await appWindow.innerSize(); // PhysicalSize
   * const logical = size.toLogical(factor);
   * ```
   */
  toLogical(e) {
    return new $c(this.width / e, this.height / e);
  }
  [Re]() {
    return {
      width: this.width,
      height: this.height
    };
  }
  toJSON() {
    return this[Re]();
  }
}
class Jt {
  constructor(e) {
    this.size = e;
  }
  toLogical(e) {
    return this.size instanceof $c ? this.size : this.size.toLogical(e);
  }
  toPhysical(e) {
    return this.size instanceof Di ? this.size : this.size.toPhysical(e);
  }
  [Re]() {
    return {
      [`${this.size.type}`]: {
        width: this.size.width,
        height: this.size.height
      }
    };
  }
  toJSON() {
    return this[Re]();
  }
}
class qc {
  constructor(...e) {
    this.type = "Logical", e.length === 1 ? "Logical" in e[0] ? (this.x = e[0].Logical.x, this.y = e[0].Logical.y) : (this.x = e[0].x, this.y = e[0].y) : (this.x = e[0], this.y = e[1]);
  }
  /**
   * Converts the logical position to a physical one.
   * @example
   * ```typescript
   * import { LogicalPosition } from '@tauri-apps/api/dpi';
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   *
   * const appWindow = getCurrentWindow();
   * const factor = await appWindow.scaleFactor();
   * const position = new LogicalPosition(400, 500);
   * const physical = position.toPhysical(factor);
   * ```
   *
   * @since 2.0.0
   */
  toPhysical(e) {
    return new wt(this.x * e, this.y * e);
  }
  [Re]() {
    return {
      x: this.x,
      y: this.y
    };
  }
  toJSON() {
    return this[Re]();
  }
}
class wt {
  constructor(...e) {
    this.type = "Physical", e.length === 1 ? "Physical" in e[0] ? (this.x = e[0].Physical.x, this.y = e[0].Physical.y) : (this.x = e[0].x, this.y = e[0].y) : (this.x = e[0], this.y = e[1]);
  }
  /**
   * Converts the physical position to a logical one.
   * @example
   * ```typescript
   * import { PhysicalPosition } from '@tauri-apps/api/dpi';
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   *
   * const appWindow = getCurrentWindow();
   * const factor = await appWindow.scaleFactor();
   * const position = new PhysicalPosition(400, 500);
   * const physical = position.toLogical(factor);
   * ```
   *
   * @since 2.0.0
   */
  toLogical(e) {
    return new qc(this.x / e, this.y / e);
  }
  [Re]() {
    return {
      x: this.x,
      y: this.y
    };
  }
  toJSON() {
    return this[Re]();
  }
}
class cs {
  constructor(e) {
    this.position = e;
  }
  toLogical(e) {
    return this.position instanceof qc ? this.position : this.position.toLogical(e);
  }
  toPhysical(e) {
    return this.position instanceof wt ? this.position : this.position.toPhysical(e);
  }
  [Re]() {
    return {
      [`${this.position.type}`]: {
        x: this.position.x,
        y: this.position.y
      }
    };
  }
  toJSON() {
    return this[Re]();
  }
}
var sn;
(function(t) {
  t[t.Critical = 1] = "Critical", t[t.Informational = 2] = "Informational";
})(sn || (sn = {}));
class Tl {
  constructor(e) {
    this._preventDefault = !1, this.event = e.event, this.id = e.id;
  }
  preventDefault() {
    this._preventDefault = !0;
  }
  isPreventDefault() {
    return this._preventDefault;
  }
}
var Ua;
(function(t) {
  t.None = "none", t.Normal = "normal", t.Indeterminate = "indeterminate", t.Paused = "paused", t.Error = "error";
})(Ua || (Ua = {}));
function Lc() {
  return new xc(window.__TAURI_INTERNALS__.metadata.currentWindow.label, {
    // @ts-expect-error `skip` is not defined in the public API but it is handled by the constructor
    skip: !0
  });
}
async function Fs() {
  return d("plugin:window|get_all_windows").then((t) => t.map((e) => new xc(e, {
    // @ts-expect-error `skip` is not defined in the public API but it is handled by the constructor
    skip: !0
  })));
}
const js = ["tauri://created", "tauri://error"];
class xc {
  /**
   * Creates a new Window.
   * @example
   * ```typescript
   * import { Window } from '@tauri-apps/api/window';
   * const appWindow = new Window('my-label');
   * appWindow.once('tauri://created', function () {
   *  // window successfully created
   * });
   * appWindow.once('tauri://error', function (e) {
   *  // an error happened creating the window
   * });
   * ```
   *
   * @param label The unique window label. Must be alphanumeric: `a-zA-Z-/:_`.
   * @returns The {@link Window} instance to communicate with the window.
   */
  constructor(e, i = {}) {
    var s;
    this.label = e, this.listeners = /* @__PURE__ */ Object.create(null), i != null && i.skip || d("plugin:window|create", {
      options: {
        ...i,
        parent: typeof i.parent == "string" ? i.parent : (s = i.parent) === null || s === void 0 ? void 0 : s.label,
        label: e
      }
    }).then(async () => this.emit("tauri://created")).catch(async (n) => this.emit("tauri://error", n));
  }
  /**
   * Gets the Window associated with the given label.
   * @example
   * ```typescript
   * import { Window } from '@tauri-apps/api/window';
   * const mainWindow = Window.getByLabel('main');
   * ```
   *
   * @param label The window label.
   * @returns The Window instance to communicate with the window or null if the window doesn't exist.
   */
  static async getByLabel(e) {
    var i;
    return (i = (await Fs()).find((s) => s.label === e)) !== null && i !== void 0 ? i : null;
  }
  /**
   * Get an instance of `Window` for the current window.
   */
  static getCurrent() {
    return Lc();
  }
  /**
   * Gets a list of instances of `Window` for all available windows.
   */
  static async getAll() {
    return Fs();
  }
  /**
   *  Gets the focused window.
   * @example
   * ```typescript
   * import { Window } from '@tauri-apps/api/window';
   * const focusedWindow = Window.getFocusedWindow();
   * ```
   *
   * @returns The Window instance or `undefined` if there is not any focused window.
   */
  static async getFocusedWindow() {
    for (const e of await Fs())
      if (await e.isFocused())
        return e;
    return null;
  }
  /**
   * Listen to an emitted event on this window.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const unlisten = await getCurrentWindow().listen<string>('state-changed', (event) => {
   *   console.log(`Got error: ${payload}`);
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @param event Event name. Must include only alphanumeric characters, `-`, `/`, `:` and `_`.
   * @param handler Event handler.
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async listen(e, i) {
    return this._handleTauriEvent(e, i) ? () => {
      const s = this.listeners[e];
      s.splice(s.indexOf(i), 1);
    } : bn(e, i, {
      target: { kind: "Window", label: this.label }
    });
  }
  /**
   * Listen to an emitted event on this window only once.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const unlisten = await getCurrentWindow().once<null>('initialized', (event) => {
   *   console.log(`Window initialized!`);
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @param event Event name. Must include only alphanumeric characters, `-`, `/`, `:` and `_`.
   * @param handler Event handler.
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async once(e, i) {
    return this._handleTauriEvent(e, i) ? () => {
      const s = this.listeners[e];
      s.splice(s.indexOf(i), 1);
    } : Sl(e, i, {
      target: { kind: "Window", label: this.label }
    });
  }
  /**
   * Emits an event to all {@link EventTarget|targets}.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().emit('window-loaded', { loggedIn: true, token: 'authToken' });
   * ```
   *
   * @param event Event name. Must include only alphanumeric characters, `-`, `/`, `:` and `_`.
   * @param payload Event payload.
   */
  async emit(e, i) {
    if (js.includes(e)) {
      for (const s of this.listeners[e] || [])
        s({
          event: e,
          id: -1,
          payload: i
        });
      return;
    }
    return $l(e, i);
  }
  /**
   * Emits an event to all {@link EventTarget|targets} matching the given target.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().emit('main', 'window-loaded', { loggedIn: true, token: 'authToken' });
   * ```
   * @param target Label of the target Window/Webview/WebviewWindow or raw {@link EventTarget} object.
   * @param event Event name. Must include only alphanumeric characters, `-`, `/`, `:` and `_`.
   * @param payload Event payload.
   */
  async emitTo(e, i, s) {
    if (js.includes(i)) {
      for (const n of this.listeners[i] || [])
        n({
          event: i,
          id: -1,
          payload: s
        });
      return;
    }
    return ql(e, i, s);
  }
  /** @ignore */
  _handleTauriEvent(e, i) {
    return js.includes(e) ? (e in this.listeners ? this.listeners[e].push(i) : this.listeners[e] = [i], !0) : !1;
  }
  // Getters
  /**
   * The scale factor that can be used to map physical pixels to logical pixels.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const factor = await getCurrentWindow().scaleFactor();
   * ```
   *
   * @returns The window's monitor scale factor.
   */
  async scaleFactor() {
    return d("plugin:window|scale_factor", {
      label: this.label
    });
  }
  /**
   * The position of the top-left hand corner of the window's client area relative to the top-left hand corner of the desktop.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const position = await getCurrentWindow().innerPosition();
   * ```
   *
   * @returns The window's inner position.
   */
  async innerPosition() {
    return d("plugin:window|inner_position", {
      label: this.label
    }).then((e) => new wt(e));
  }
  /**
   * The position of the top-left hand corner of the window relative to the top-left hand corner of the desktop.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const position = await getCurrentWindow().outerPosition();
   * ```
   *
   * @returns The window's outer position.
   */
  async outerPosition() {
    return d("plugin:window|outer_position", {
      label: this.label
    }).then((e) => new wt(e));
  }
  /**
   * The physical size of the window's client area.
   * The client area is the content of the window, excluding the title bar and borders.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const size = await getCurrentWindow().innerSize();
   * ```
   *
   * @returns The window's inner size.
   */
  async innerSize() {
    return d("plugin:window|inner_size", {
      label: this.label
    }).then((e) => new Di(e));
  }
  /**
   * The physical size of the entire window.
   * These dimensions include the title bar and borders. If you don't want that (and you usually don't), use inner_size instead.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const size = await getCurrentWindow().outerSize();
   * ```
   *
   * @returns The window's outer size.
   */
  async outerSize() {
    return d("plugin:window|outer_size", {
      label: this.label
    }).then((e) => new Di(e));
  }
  /**
   * Gets the window's current fullscreen state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const fullscreen = await getCurrentWindow().isFullscreen();
   * ```
   *
   * @returns Whether the window is in fullscreen mode or not.
   */
  async isFullscreen() {
    return d("plugin:window|is_fullscreen", {
      label: this.label
    });
  }
  /**
   * Gets the window's current minimized state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const minimized = await getCurrentWindow().isMinimized();
   * ```
   */
  async isMinimized() {
    return d("plugin:window|is_minimized", {
      label: this.label
    });
  }
  /**
   * Gets the window's current maximized state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const maximized = await getCurrentWindow().isMaximized();
   * ```
   *
   * @returns Whether the window is maximized or not.
   */
  async isMaximized() {
    return d("plugin:window|is_maximized", {
      label: this.label
    });
  }
  /**
   * Gets the window's current focus state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const focused = await getCurrentWindow().isFocused();
   * ```
   *
   * @returns Whether the window is focused or not.
   */
  async isFocused() {
    return d("plugin:window|is_focused", {
      label: this.label
    });
  }
  /**
   * Gets the window's current decorated state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const decorated = await getCurrentWindow().isDecorated();
   * ```
   *
   * @returns Whether the window is decorated or not.
   */
  async isDecorated() {
    return d("plugin:window|is_decorated", {
      label: this.label
    });
  }
  /**
   * Gets the window's current resizable state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const resizable = await getCurrentWindow().isResizable();
   * ```
   *
   * @returns Whether the window is resizable or not.
   */
  async isResizable() {
    return d("plugin:window|is_resizable", {
      label: this.label
    });
  }
  /**
   * Gets the window's native maximize button state.
   *
   * #### Platform-specific
   *
   * - **Linux / iOS / Android:** Unsupported.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const maximizable = await getCurrentWindow().isMaximizable();
   * ```
   *
   * @returns Whether the window's native maximize button is enabled or not.
   */
  async isMaximizable() {
    return d("plugin:window|is_maximizable", {
      label: this.label
    });
  }
  /**
   * Gets the window's native minimize button state.
   *
   * #### Platform-specific
   *
   * - **Linux / iOS / Android:** Unsupported.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const minimizable = await getCurrentWindow().isMinimizable();
   * ```
   *
   * @returns Whether the window's native minimize button is enabled or not.
   */
  async isMinimizable() {
    return d("plugin:window|is_minimizable", {
      label: this.label
    });
  }
  /**
   * Gets the window's native close button state.
   *
   * #### Platform-specific
   *
   * - **iOS / Android:** Unsupported.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const closable = await getCurrentWindow().isClosable();
   * ```
   *
   * @returns Whether the window's native close button is enabled or not.
   */
  async isClosable() {
    return d("plugin:window|is_closable", {
      label: this.label
    });
  }
  /**
   * Gets the window's current visible state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const visible = await getCurrentWindow().isVisible();
   * ```
   *
   * @returns Whether the window is visible or not.
   */
  async isVisible() {
    return d("plugin:window|is_visible", {
      label: this.label
    });
  }
  /**
   * Gets the window's current title.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const title = await getCurrentWindow().title();
   * ```
   */
  async title() {
    return d("plugin:window|title", {
      label: this.label
    });
  }
  /**
   * Gets the window's current theme.
   *
   * #### Platform-specific
   *
   * - **macOS:** Theme was introduced on macOS 10.14. Returns `light` on macOS 10.13 and below.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const theme = await getCurrentWindow().theme();
   * ```
   *
   * @returns The window theme.
   */
  async theme() {
    return d("plugin:window|theme", {
      label: this.label
    });
  }
  /**
   * Whether the window is configured to be always on top of other windows or not.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const alwaysOnTop = await getCurrentWindow().isAlwaysOnTop();
   * ```
   *
   * @returns Whether the window is visible or not.
   */
  async isAlwaysOnTop() {
    return d("plugin:window|is_always_on_top", {
      label: this.label
    });
  }
  async activityName() {
    return d("plugin:window|activity_name", {
      label: this.label
    });
  }
  async sceneIdentifier() {
    return d("plugin:window|scene_identifier", {
      label: this.label
    });
  }
  // Setters
  /**
   * Centers the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().center();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async center() {
    return d("plugin:window|center", {
      label: this.label
    });
  }
  /**
   *  Requests user attention to the window, this has no effect if the application
   * is already focused. How requesting for user attention manifests is platform dependent,
   * see `UserAttentionType` for details.
   *
   * Providing `null` will unset the request for user attention. Unsetting the request for
   * user attention might not be done automatically by the WM when the window receives input.
   *
   * #### Platform-specific
   *
   * - **macOS:** `null` has no effect.
   * - **Linux:** Urgency levels have the same effect.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().requestUserAttention();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async requestUserAttention(e) {
    let i = null;
    return e && (e === sn.Critical ? i = { type: "Critical" } : i = { type: "Informational" }), d("plugin:window|request_user_attention", {
      label: this.label,
      value: i
    });
  }
  /**
   * Updates the window resizable flag.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setResizable(false);
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async setResizable(e) {
    return d("plugin:window|set_resizable", {
      label: this.label,
      value: e
    });
  }
  /**
   * Enable or disable the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setEnabled(false);
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   *
   * @since 2.0.0
   */
  async setEnabled(e) {
    return d("plugin:window|set_enabled", {
      label: this.label,
      value: e
    });
  }
  /**
   * Whether the window is enabled or disabled.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setEnabled(false);
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   *
   * @since 2.0.0
   */
  async isEnabled() {
    return d("plugin:window|is_enabled", {
      label: this.label
    });
  }
  /**
   * Sets whether the window's native maximize button is enabled or not.
   * If resizable is set to false, this setting is ignored.
   *
   * #### Platform-specific
   *
   * - **macOS:** Disables the "zoom" button in the window titlebar, which is also used to enter fullscreen mode.
   * - **Linux / iOS / Android:** Unsupported.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setMaximizable(false);
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async setMaximizable(e) {
    return d("plugin:window|set_maximizable", {
      label: this.label,
      value: e
    });
  }
  /**
   * Sets whether the window's native minimize button is enabled or not.
   *
   * #### Platform-specific
   *
   * - **Linux / iOS / Android:** Unsupported.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setMinimizable(false);
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async setMinimizable(e) {
    return d("plugin:window|set_minimizable", {
      label: this.label,
      value: e
    });
  }
  /**
   * Sets whether the window's native close button is enabled or not.
   *
   * #### Platform-specific
   *
   * - **Linux:** GTK+ will do its best to convince the window manager not to show a close button. Depending on the system, this function may not have any effect when called on a window that is already visible
   * - **iOS / Android:** Unsupported.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setClosable(false);
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async setClosable(e) {
    return d("plugin:window|set_closable", {
      label: this.label,
      value: e
    });
  }
  /**
   * Sets the window title.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setTitle('Tauri');
   * ```
   *
   * @param title The new title
   * @returns A promise indicating the success or failure of the operation.
   */
  async setTitle(e) {
    return d("plugin:window|set_title", {
      label: this.label,
      value: e
    });
  }
  /**
   * Maximizes the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().maximize();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async maximize() {
    return d("plugin:window|maximize", {
      label: this.label
    });
  }
  /**
   * Unmaximizes the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().unmaximize();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async unmaximize() {
    return d("plugin:window|unmaximize", {
      label: this.label
    });
  }
  /**
   * Toggles the window maximized state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().toggleMaximize();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async toggleMaximize() {
    return d("plugin:window|toggle_maximize", {
      label: this.label
    });
  }
  /**
   * Minimizes the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().minimize();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async minimize() {
    return d("plugin:window|minimize", {
      label: this.label
    });
  }
  /**
   * Unminimizes the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().unminimize();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async unminimize() {
    return d("plugin:window|unminimize", {
      label: this.label
    });
  }
  /**
   * Sets the window visibility to true.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().show();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async show() {
    return d("plugin:window|show", {
      label: this.label
    });
  }
  /**
   * Sets the window visibility to false.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().hide();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async hide() {
    return d("plugin:window|hide", {
      label: this.label
    });
  }
  /**
   * Closes the window.
   *
   * Note this emits a closeRequested event so you can intercept it. To force window close, use {@link Window.destroy}.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().close();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async close() {
    return d("plugin:window|close", {
      label: this.label
    });
  }
  /**
   * Destroys the window. Behaves like {@link Window.close} but forces the window close instead of emitting a closeRequested event.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().destroy();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async destroy() {
    return d("plugin:window|destroy", {
      label: this.label
    });
  }
  /**
   * Whether the window should have borders and bars.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setDecorations(false);
   * ```
   *
   * @param decorations Whether the window should have borders and bars.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setDecorations(e) {
    return d("plugin:window|set_decorations", {
      label: this.label,
      value: e
    });
  }
  /**
   * Whether or not the window should have shadow.
   *
   * #### Platform-specific
   *
   * - **Windows:**
   *   - `false` has no effect on decorated window, shadows are always ON.
   *   - `true` will make undecorated window have a 1px white border,
   * and on Windows 11, it will have a rounded corners.
   * - **Linux:** Unsupported.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setShadow(false);
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async setShadow(e) {
    return d("plugin:window|set_shadow", {
      label: this.label,
      value: e
    });
  }
  /**
   * Set window effects.
   */
  async setEffects(e) {
    return d("plugin:window|set_effects", {
      label: this.label,
      value: e
    });
  }
  /**
   * Clear any applied effects if possible.
   */
  async clearEffects() {
    return d("plugin:window|set_effects", {
      label: this.label,
      value: null
    });
  }
  /**
   * Whether the window should always be on top of other windows.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setAlwaysOnTop(true);
   * ```
   *
   * @param alwaysOnTop Whether the window should always be on top of other windows or not.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setAlwaysOnTop(e) {
    return d("plugin:window|set_always_on_top", {
      label: this.label,
      value: e
    });
  }
  /**
   * Whether the window should always be below other windows.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setAlwaysOnBottom(true);
   * ```
   *
   * @param alwaysOnBottom Whether the window should always be below other windows or not.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setAlwaysOnBottom(e) {
    return d("plugin:window|set_always_on_bottom", {
      label: this.label,
      value: e
    });
  }
  /**
   * Prevents the window contents from being captured by other apps.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setContentProtected(true);
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async setContentProtected(e) {
    return d("plugin:window|set_content_protected", {
      label: this.label,
      value: e
    });
  }
  /**
   * Resizes the window with a new inner size.
   * @example
   * ```typescript
   * import { getCurrentWindow, LogicalSize } from '@tauri-apps/api/window';
   * await getCurrentWindow().setSize(new LogicalSize(600, 500));
   * ```
   *
   * @param size The logical or physical inner size.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setSize(e) {
    return d("plugin:window|set_size", {
      label: this.label,
      value: e instanceof Jt ? e : new Jt(e)
    });
  }
  /**
   * Sets the window minimum inner size. If the `size` argument is not provided, the constraint is unset.
   * @example
   * ```typescript
   * import { getCurrentWindow, PhysicalSize } from '@tauri-apps/api/window';
   * await getCurrentWindow().setMinSize(new PhysicalSize(600, 500));
   * ```
   *
   * @param size The logical or physical inner size, or `null` to unset the constraint.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setMinSize(e) {
    return d("plugin:window|set_min_size", {
      label: this.label,
      value: e instanceof Jt ? e : e ? new Jt(e) : null
    });
  }
  /**
   * Sets the window maximum inner size. If the `size` argument is undefined, the constraint is unset.
   * @example
   * ```typescript
   * import { getCurrentWindow, LogicalSize } from '@tauri-apps/api/window';
   * await getCurrentWindow().setMaxSize(new LogicalSize(600, 500));
   * ```
   *
   * @param size The logical or physical inner size, or `null` to unset the constraint.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setMaxSize(e) {
    return d("plugin:window|set_max_size", {
      label: this.label,
      value: e instanceof Jt ? e : e ? new Jt(e) : null
    });
  }
  /**
   * Sets the window inner size constraints.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setSizeConstraints({ minWidth: 300 });
   * ```
   *
   * @param constraints The logical or physical inner size, or `null` to unset the constraint.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setSizeConstraints(e) {
    function i(s) {
      return s ? { Logical: s } : null;
    }
    return d("plugin:window|set_size_constraints", {
      label: this.label,
      value: {
        minWidth: i(e == null ? void 0 : e.minWidth),
        minHeight: i(e == null ? void 0 : e.minHeight),
        maxWidth: i(e == null ? void 0 : e.maxWidth),
        maxHeight: i(e == null ? void 0 : e.maxHeight)
      }
    });
  }
  /**
   * Sets the window outer position.
   * @example
   * ```typescript
   * import { getCurrentWindow, LogicalPosition } from '@tauri-apps/api/window';
   * await getCurrentWindow().setPosition(new LogicalPosition(600, 500));
   * ```
   *
   * @param position The new position, in logical or physical pixels.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setPosition(e) {
    return d("plugin:window|set_position", {
      label: this.label,
      value: e instanceof cs ? e : new cs(e)
    });
  }
  /**
   * Sets the window fullscreen state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setFullscreen(true);
   * ```
   *
   * @param fullscreen Whether the window should go to fullscreen or not.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setFullscreen(e) {
    return d("plugin:window|set_fullscreen", {
      label: this.label,
      value: e
    });
  }
  /**
   * On macOS, Toggles a fullscreen mode that doesn’t require a new macOS space. Returns a boolean indicating whether the transition was successful (this won’t work if the window was already in the native fullscreen).
   * This is how fullscreen used to work on macOS in versions before Lion. And allows the user to have a fullscreen window without using another space or taking control over the entire monitor.
   *
   * On other platforms, this is the same as {@link Window.setFullscreen}.
   *
   * @param fullscreen Whether the window should go to simple fullscreen or not.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setSimpleFullscreen(e) {
    return d("plugin:window|set_simple_fullscreen", {
      label: this.label,
      value: e
    });
  }
  /**
   * Bring the window to front and focus.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setFocus();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async setFocus() {
    return d("plugin:window|set_focus", {
      label: this.label
    });
  }
  /**
   * Sets whether the window can be focused.
   *
   * #### Platform-specific
   *
   * - **macOS**: If the window is already focused, it is not possible to unfocus it after calling `set_focusable(false)`.
   *   In this case, you might consider calling {@link Window.setFocus} but it will move the window to the back i.e. at the bottom in terms of z-order.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setFocusable(true);
   * ```
   *
   * @param focusable Whether the window can be focused.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setFocusable(e) {
    return d("plugin:window|set_focusable", {
      label: this.label,
      value: e
    });
  }
  /**
   * Sets the window icon.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setIcon('/tauri/awesome.png');
   * ```
   *
   * Note that you may need the `image-ico` or `image-png` Cargo features to use this API.
   * To enable it, change your Cargo.toml file:
   * ```toml
   * [dependencies]
   * tauri = { version = "...", features = ["...", "image-png"] }
   * ```
   *
   * @param icon Icon bytes or path to the icon file.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setIcon(e) {
    return d("plugin:window|set_icon", {
      label: this.label,
      value: $s(e)
    });
  }
  /**
   * Whether the window icon should be hidden from the taskbar or not.
   *
   * #### Platform-specific
   *
   * - **macOS:** Unsupported.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setSkipTaskbar(true);
   * ```
   *
   * @param skip true to hide window icon, false to show it.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setSkipTaskbar(e) {
    return d("plugin:window|set_skip_taskbar", {
      label: this.label,
      value: e
    });
  }
  /**
   * Grabs the cursor, preventing it from leaving the window.
   *
   * There's no guarantee that the cursor will be hidden. You should
   * hide it by yourself if you want so.
   *
   * #### Platform-specific
   *
   * - **Linux:** Unsupported.
   * - **macOS:** This locks the cursor in a fixed location, which looks visually awkward.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setCursorGrab(true);
   * ```
   *
   * @param grab `true` to grab the cursor icon, `false` to release it.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setCursorGrab(e) {
    return d("plugin:window|set_cursor_grab", {
      label: this.label,
      value: e
    });
  }
  /**
   * Modifies the cursor's visibility.
   *
   * #### Platform-specific
   *
   * - **Windows:** The cursor is only hidden within the confines of the window.
   * - **macOS:** The cursor is hidden as long as the window has input focus, even if the cursor is
   *   outside of the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setCursorVisible(false);
   * ```
   *
   * @param visible If `false`, this will hide the cursor. If `true`, this will show the cursor.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setCursorVisible(e) {
    return d("plugin:window|set_cursor_visible", {
      label: this.label,
      value: e
    });
  }
  /**
   * Modifies the cursor icon of the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setCursorIcon('help');
   * ```
   *
   * @param icon The new cursor icon.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setCursorIcon(e) {
    return d("plugin:window|set_cursor_icon", {
      label: this.label,
      value: e
    });
  }
  /**
   * Sets the window background color.
   *
   * #### Platform-specific:
   *
   * - **Windows:** alpha channel is ignored.
   * - **iOS / Android:** Unsupported.
   *
   * @returns A promise indicating the success or failure of the operation.
   *
   * @since 2.1.0
   */
  async setBackgroundColor(e) {
    return d("plugin:window|set_background_color", { color: e });
  }
  /**
   * Changes the position of the cursor in window coordinates.
   * @example
   * ```typescript
   * import { getCurrentWindow, LogicalPosition } from '@tauri-apps/api/window';
   * await getCurrentWindow().setCursorPosition(new LogicalPosition(600, 300));
   * ```
   *
   * @param position The new cursor position.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setCursorPosition(e) {
    return d("plugin:window|set_cursor_position", {
      label: this.label,
      value: e instanceof cs ? e : new cs(e)
    });
  }
  /**
   * Changes the cursor events behavior.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setIgnoreCursorEvents(true);
   * ```
   *
   * @param ignore `true` to ignore the cursor events; `false` to process them as usual.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setIgnoreCursorEvents(e) {
    return d("plugin:window|set_ignore_cursor_events", {
      label: this.label,
      value: e
    });
  }
  /**
   * Starts dragging the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().startDragging();
   * ```
   *
   * @return A promise indicating the success or failure of the operation.
   */
  async startDragging() {
    return d("plugin:window|start_dragging", {
      label: this.label
    });
  }
  /**
   * Starts resize-dragging the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().startResizeDragging();
   * ```
   *
   * @return A promise indicating the success or failure of the operation.
   */
  async startResizeDragging(e) {
    return d("plugin:window|start_resize_dragging", {
      label: this.label,
      value: e
    });
  }
  /**
   * Sets the badge count. It is app wide and not specific to this window.
   *
   * #### Platform-specific
   *
   * - **Windows**: Unsupported. Use @{linkcode Window.setOverlayIcon} instead.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setBadgeCount(5);
   * ```
   *
   * @param count The badge count. Use `undefined` to remove the badge.
   * @return A promise indicating the success or failure of the operation.
   */
  async setBadgeCount(e) {
    return d("plugin:window|set_badge_count", {
      label: this.label,
      value: e
    });
  }
  /**
   * Sets the badge cont **macOS only**.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setBadgeLabel("Hello");
   * ```
   *
   * @param label The badge label. Use `undefined` to remove the badge.
   * @return A promise indicating the success or failure of the operation.
   */
  async setBadgeLabel(e) {
    return d("plugin:window|set_badge_label", {
      label: this.label,
      value: e
    });
  }
  /**
   * Sets the overlay icon. **Windows only**
   * The overlay icon can be set for every window.
   *
   *
   * Note that you may need the `image-ico` or `image-png` Cargo features to use this API.
   * To enable it, change your Cargo.toml file:
   *
   * ```toml
   * [dependencies]
   * tauri = { version = "...", features = ["...", "image-png"] }
   * ```
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setOverlayIcon("/tauri/awesome.png");
   * ```
   *
   * @param icon Icon bytes or path to the icon file. Use `undefined` to remove the overlay icon.
   * @return A promise indicating the success or failure of the operation.
   */
  async setOverlayIcon(e) {
    return d("plugin:window|set_overlay_icon", {
      label: this.label,
      value: e ? $s(e) : void 0
    });
  }
  /**
   * Sets the taskbar progress state.
   *
   * #### Platform-specific
   *
   * - **Linux / macOS**: Progress bar is app-wide and not specific to this window.
   * - **Linux**: Only supported desktop environments with `libunity` (e.g. GNOME).
   *
   * @example
   * ```typescript
   * import { getCurrentWindow, ProgressBarStatus } from '@tauri-apps/api/window';
   * await getCurrentWindow().setProgressBar({
   *   status: ProgressBarStatus.Normal,
   *   progress: 50,
   * });
   * ```
   *
   * @return A promise indicating the success or failure of the operation.
   */
  async setProgressBar(e) {
    return d("plugin:window|set_progress_bar", {
      label: this.label,
      value: e
    });
  }
  /**
   * Sets whether the window should be visible on all workspaces or virtual desktops.
   *
   * #### Platform-specific
   *
   * - **Windows / iOS / Android:** Unsupported.
   *
   * @since 2.0.0
   */
  async setVisibleOnAllWorkspaces(e) {
    return d("plugin:window|set_visible_on_all_workspaces", {
      label: this.label,
      value: e
    });
  }
  /**
   * Sets the title bar style. **macOS only**.
   *
   * @since 2.0.0
   */
  async setTitleBarStyle(e) {
    return d("plugin:window|set_title_bar_style", {
      label: this.label,
      value: e
    });
  }
  /**
   * Set window theme, pass in `null` or `undefined` to follow system theme
   *
   * #### Platform-specific
   *
   * - **Linux / macOS**: Theme is app-wide and not specific to this window.
   * - **iOS / Android:** Unsupported.
   *
   * @since 2.0.0
   */
  async setTheme(e) {
    return d("plugin:window|set_theme", {
      label: this.label,
      value: e
    });
  }
  // Listeners
  /**
   * Listen to window resize.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from "@tauri-apps/api/window";
   * const unlisten = await getCurrentWindow().onResized(({ payload: size }) => {
   *  console.log('Window resized', size);
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async onResized(e) {
    return this.listen(ge.WINDOW_RESIZED, (i) => {
      i.payload = new Di(i.payload), e(i);
    });
  }
  /**
   * Listen to window move.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from "@tauri-apps/api/window";
   * const unlisten = await getCurrentWindow().onMoved(({ payload: position }) => {
   *  console.log('Window moved', position);
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async onMoved(e) {
    return this.listen(ge.WINDOW_MOVED, (i) => {
      i.payload = new wt(i.payload), e(i);
    });
  }
  /**
   * Listen to window close requested. Emitted when the user requests to closes the window.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from "@tauri-apps/api/window";
   * import { confirm } from '@tauri-apps/api/dialog';
   * const unlisten = await getCurrentWindow().onCloseRequested(async (event) => {
   *   const confirmed = await confirm('Are you sure?');
   *   if (!confirmed) {
   *     // user did not confirm closing the window; let's prevent it
   *     event.preventDefault();
   *   }
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async onCloseRequested(e) {
    return this.listen(ge.WINDOW_CLOSE_REQUESTED, async (i) => {
      const s = new Tl(i);
      await e(s), s.isPreventDefault() || await this.destroy();
    });
  }
  /**
   * Listen to a file drop event.
   * The listener is triggered when the user hovers the selected files on the webview,
   * drops the files or cancels the operation.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from "@tauri-apps/api/webview";
   * const unlisten = await getCurrentWindow().onDragDropEvent((event) => {
   *  if (event.payload.type === 'over') {
   *    console.log('User hovering', event.payload.position);
   *  } else if (event.payload.type === 'drop') {
   *    console.log('User dropped', event.payload.paths);
   *  } else {
   *    console.log('File drop cancelled');
   *  }
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async onDragDropEvent(e) {
    const i = await this.listen(ge.DRAG_ENTER, (r) => {
      e({
        ...r,
        payload: {
          type: "enter",
          paths: r.payload.paths,
          position: new wt(r.payload.position)
        }
      });
    }), s = await this.listen(ge.DRAG_OVER, (r) => {
      e({
        ...r,
        payload: {
          type: "over",
          position: new wt(r.payload.position)
        }
      });
    }), n = await this.listen(ge.DRAG_DROP, (r) => {
      e({
        ...r,
        payload: {
          type: "drop",
          paths: r.payload.paths,
          position: new wt(r.payload.position)
        }
      });
    }), c = await this.listen(ge.DRAG_LEAVE, (r) => {
      e({ ...r, payload: { type: "leave" } });
    });
    return () => {
      i(), n(), s(), c();
    };
  }
  /**
   * Listen to window focus change.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from "@tauri-apps/api/window";
   * const unlisten = await getCurrentWindow().onFocusChanged(({ payload: focused }) => {
   *  console.log('Focus changed, window is focused? ' + focused);
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async onFocusChanged(e) {
    const i = await this.listen(ge.WINDOW_FOCUS, (n) => {
      e({ ...n, payload: !0 });
    }), s = await this.listen(ge.WINDOW_BLUR, (n) => {
      e({ ...n, payload: !1 });
    });
    return () => {
      i(), s();
    };
  }
  /**
   * Listen to window scale change. Emitted when the window's scale factor has changed.
   * The following user actions can cause DPI changes:
   * - Changing the display's resolution.
   * - Changing the display's scale factor (e.g. in Control Panel on Windows).
   * - Moving the window to a display with a different scale factor.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from "@tauri-apps/api/window";
   * const unlisten = await getCurrentWindow().onScaleChanged(({ payload }) => {
   *  console.log('Scale changed', payload.scaleFactor, payload.size);
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async onScaleChanged(e) {
    return this.listen(ge.WINDOW_SCALE_FACTOR_CHANGED, e);
  }
  /**
   * Listen to the system theme change.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from "@tauri-apps/api/window";
   * const unlisten = await getCurrentWindow().onThemeChanged(({ payload: theme }) => {
   *  console.log('New theme: ' + theme);
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async onThemeChanged(e) {
    return this.listen(ge.WINDOW_THEME_CHANGED, e);
  }
}
var Va;
(function(t) {
  t.Disabled = "disabled", t.Throttle = "throttle", t.Suspend = "suspend";
})(Va || (Va = {}));
var Ga;
(function(t) {
  t.Default = "default", t.FluentOverlay = "fluentOverlay";
})(Ga || (Ga = {}));
var Ya;
(function(t) {
  t.AppearanceBased = "appearanceBased", t.Light = "light", t.Dark = "dark", t.MediumLight = "mediumLight", t.UltraDark = "ultraDark", t.Titlebar = "titlebar", t.Selection = "selection", t.Menu = "menu", t.Popover = "popover", t.Sidebar = "sidebar", t.HeaderView = "headerView", t.Sheet = "sheet", t.WindowBackground = "windowBackground", t.HudWindow = "hudWindow", t.FullScreenUI = "fullScreenUI", t.Tooltip = "tooltip", t.ContentBackground = "contentBackground", t.UnderWindowBackground = "underWindowBackground", t.UnderPageBackground = "underPageBackground", t.Mica = "mica", t.Blur = "blur", t.Acrylic = "acrylic", t.Tabbed = "tabbed", t.TabbedDark = "tabbedDark", t.TabbedLight = "tabbedLight";
})(Ya || (Ya = {}));
var Ka;
(function(t) {
  t.FollowsWindowActiveState = "followsWindowActiveState", t.Active = "active", t.Inactive = "inactive";
})(Ka || (Ka = {}));
const Ec = "curve", Ml = (() => {
  try {
    return Lc().label;
  } catch {
    return "";
  }
})(), Tc = Ml.endsWith(`-${Ec}`);
function Cl(t) {
  return t === "top" ? "artist" : t;
}
const Al = {
  album: "spotify_albums",
  artist: "spotify_artists",
  show: "spotify_shows",
  top: "spotify_top_artists"
}, Mc = ["L", "R", "C", "LFE", "SL", "SR", "BL", "BR"], Qs = 5e3, Il = 1280, Dl = 720, Rl = 550, Nl = 300, Cc = 180, Ac = 520, Pl = 4e3, Ol = 450, Bl = 800, Ic = 5e3, zl = 200, Hl = 15e3, Dc = 500, Wl = 500, Fl = 250, jl = 500, Ql = 0.3, v = {
  play: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polygon points="6 4 20 12 6 20 6 4"/></svg>',
  pause: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="9" y1="4" x2="9" y2="20"/><line x1="15" y1="4" x2="15" y2="20"/></svg>',
  prev: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polygon points="19 5 9 12 19 19 19 5"/><line x1="5" y1="5" x2="5" y2="19"/></svg>',
  next: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polygon points="5 5 15 12 5 19 5 5"/><line x1="19" y1="5" x2="19" y2="19"/></svg>',
  /** 随机（关 / 随机共用这一个；「关」靠 `data-mode` 变暗区分）。 */
  shuffle: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="16 3 21 3 21 8"/><line x1="4" y1="20" x2="21" y2="3"/><polyline points="21 16 21 21 16 21"/><line x1="15" y1="15" x2="21" y2="21"/><line x1="4" y1="4" x2="9" y2="9"/></svg>',
  /** 循环（单曲循环；那个「1」由 CSS `::after` 加，SVG 里不写字）。 */
  repeat: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="17 1 21 5 17 9"/><path d="M3 11V9a4 4 0 0 1 4-4h14"/><polyline points="7 23 3 19 7 15"/><path d="M21 13v2a4 4 0 0 1-4 4H3"/></svg>',
  list: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="9" y1="6" x2="21" y2="6"/><line x1="9" y1="12" x2="21" y2="12"/><line x1="9" y1="18" x2="21" y2="18"/><circle cx="4" cy="6" r="1" fill="currentColor" stroke="none"/><circle cx="4" cy="12" r="1" fill="currentColor" stroke="none"/><circle cx="4" cy="18" r="1" fill="currentColor" stroke="none"/></svg>',
  /** 进播放界面。 */
  expand: '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 3 21 3 21 9"/><polyline points="9 21 3 21 3 15"/><line x1="21" y1="3" x2="14" y2="10"/><line x1="3" y1="21" x2="10" y2="14"/></svg>',
  /** 回默认界面。**唯一**的退出播放界面的入口 —— 播放停止不会自动退出。 */
  back: '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/><line x1="3" y1="12" x2="9" y2="12"/></svg>',
  chevron: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg>',
  copy: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15V5a2 2 0 0 1 2-2h10"/></svg>',
  link: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.5 1.5"/><path d="M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7L12 19"/></svg>',
  power: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M18.4 6.6a9 9 0 1 1-12.8 0"/><line x1="12" y1="2" x2="12" y2="12"/></svg>',
  gear: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>',
  volume: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M15.5 8.5a5 5 0 0 1 0 7"/></svg>',
  /** 工具条上的「设备」按钮（2026-09-28）。画成一台小音箱，比「显示器」更贴
   *  Spotify 那种「可选的播放设备」语义。 */
  speaker: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="2" width="14" height="20" rx="2"/><circle cx="12" cy="14" r="3.2"/><circle cx="12" cy="6" r="1" fill="currentColor" stroke="none"/></svg>',
  /** 实心心形（「我喜欢的歌曲」那块封面上的图案）。**这个是 `fill`，不是描边** ——
   *  它是一块封面图（Spotify 的收藏夹封面就是实心心 + 渐变底），不是可点按钮。 */
  heart: '<svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" stroke="none"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>',
  // ── 本地媒体库那一页用到的四个（2026-10-01）──
  /** 「本地音乐」入口 + 目录行（画成文件夹）。 */
  folder: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/></svg>',
  /** 「添加目录」。 */
  plus: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>',
  /** 移除一根目录（行尾那枚）。`music.pl-x` 用。 */
  x: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="6" y1="6" x2="18" y2="18"/><line x1="18" y1="6" x2="6" y2="18"/></svg>',
  /** 没有封面的曲目行左侧占位（一个八分音符）。 */
  note: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18V6l10-2v12"/><circle cx="6.5" cy="18" r="2.5"/><circle cx="16.5" cy="16" r="2.5"/></svg>',
  /** 「重新扫描」/「刷新」—— 画成环形箭头。 */
  refresh: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="21 3 21 9 15 9"/><path d="M20.4 14a8.5 8.5 0 1 1-1.6-7.5L21 9"/></svg>',
  /** 勾选（本地列表「自定义队列编辑态」里那一行被勾中的标记）。**路径逐字抄自
   *  icon-style.md §3 的「保存 ✓」** —— 与 SVG.edit / SVG.trash 同一条纪律：已有的图形不另画。 */
  check: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>',
  /** 「测量」—— 一条起伏的响应曲线（Lucide 的 `activity` 那一族的形状）。 */
  wave: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12h3l2.5-6 3.5 12 3-8 2 2h4"/></svg>',
  /** 编辑（改列表）。**路径逐字抄自 icon-style.md §3 的「编辑 ✎」** —— 规范里已经
   *  给好这条了，不许自己另画一条（§4.2 最后一条：已有的图形不要重复造路径）。 */
  edit: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 3a2.8 2.8 0 0 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/></svg>',
  /** 删除（垃圾桶）。**同样逐字抄自 icon-style.md §3** —— 它是危险操作，
   *  按 §4.2 用同风格线性图标 + 语义色（hover 变 `--red`，见 styles.css）。 */
  trash: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6M14 11v6M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>',
  /** 停止本地播放（本地播放条右端那枚）。**它与暂停不是一回事**：暂停留着这台
   *  音频设备，停止会把设备一起放掉（见 player.rs 的 `player_stop`）。 */
  stop: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="6" y="6" width="12" height="12" rx="1.5"/></svg>',
  /** 「本地与 Spotify 同时出声」那把开关（2026-10-01）。画成**两个相交的圆** ——
   *  「两路并存」最直白的图形（Lucide 里叫 `blend`）。**不画成两个喇叭**：12px 下
   *  两个喇叭会糊成一团，而两个圆在任何尺寸下都认得出来。
   *  开关的「开着」不用第二个图形表达，靠 `.on` 的强调色（与其他开关一致）。 */
  dual: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="9" r="6.5"/><circle cx="15" cy="15" r="6.5"/></svg>',
  /** 「最常听的歌曲」那一行的图标（2026-10-01 用户第 4 条）。画成一条上扬的折线
   *  —— 「最常听 / 热度」最直白的图形（Lucide 的 `trending-up`，与上面这些同源）。
   *  与 `SVG.heart` 一样是 20px 的封面图案，但**保持描边风格**（它不是实心封面，
   *  它是「一行合成出来的入口」，与收藏夹那块渐变实心封面刻意区分开）。 */
  trend: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/></svg>'
  // （工具条上那枚「调音推子」图标 2026-10-01 随入口一起删掉了：调音改成标题栏
  //  三段切换的第三段，那枚图标就没有地方落了。图形本身仍在 icon-style.md §3 里。）
};
let f = null, y = null, fe = null, nn = "", an = !1, ni = [], Rt = -1, ms = null, Ti = null, ps = !1, b = null, Qi = 0, Ui = 0, Vi = 0, se = [], Qt = [[]], Xe = 0, Rc = [], xe = 0, Ht = [], pi = null, ee = null, ke = -1, ft = 0, rt = null, $t = !1, ot = null, yn = null, Xt = -1, Ei = !1, fi = !1, fs = 0, Us = null;
const Ul = 300;
let ls = null, je = { a: !1, b: !1 }, vi = ["a", "b"], qt = !1, Ri = !1, gn = null;
function Vl() {
  return { kind: "peaking", freq_hz: 1e3, gain_db: 0, q: 0.707, on: !0 };
}
function $i() {
  Qi = (b == null ? void 0 : b.preamp_db) ?? 0, Ui = (b == null ? void 0 : b.bass_db) ?? 0, Vi = (b == null ? void 0 : b.treble_db) ?? 0, Rc = ((b == null ? void 0 : b.graphic_eq) ?? []).map((i) => ({ freq_hz: i.freq_hz, gain_db: i.gain_db })), xe = (b == null ? void 0 : b.delay_ms) ?? 0, Ht = ((b == null ? void 0 : b.channel_copy) ?? []).map((i) => ({ from: i.from, to: i.to })), pi = (b == null ? void 0 : b.convolution) ?? null, ee = null;
  const t = b != null && b.channels && b.channels > 0 ? b.channels : 2, e = [((b == null ? void 0 : b.filters) ?? []).map((i) => ({ ...i }))];
  for (let i = 1; i <= t; i++) {
    const s = ((b == null ? void 0 : b.if_else) ?? []).find((n) => n.channel === i - 1);
    e.push(((s == null ? void 0 : s.then) ?? []).map((n) => ({ ...n })));
  }
  Qt = e, (Xe < 0 || Xe >= e.length) && (Xe = 0), se = e[Xe];
}
function Gl() {
  var i;
  if (!b) return [];
  if (Xe === 0) return b.response.db;
  const t = (b.if_else ?? []).findIndex((s) => s.channel === Xe - 1), e = t >= 0 ? (i = b.cond_db) == null ? void 0 : i[t] : void 0;
  return e && e.length ? e : b.response.db;
}
function Yl() {
  var i;
  const t = new Map(((b == null ? void 0 : b.if_else) ?? []).map((s) => [s.channel, s])), e = [];
  for (let s = 1; s < Qt.length; s++) {
    const n = s - 1, c = Qt[s], r = ((i = t.get(n)) == null ? void 0 : i.else) ?? [];
    if (c.length === 0 && r.length === 0) continue;
    const p = { channel: n, then: c };
    r.length > 0 && (p.else = r), e.push(p);
  }
  return e;
}
let D = "default", cn = null, dt = null, _e = !1, Nc = "", J = null, Vs = !1, Wt = "", Qe = "", Q = null, hi = !1, Mi, we = "playlist";
const bi = /* @__PURE__ */ new Map(), Ni = /* @__PURE__ */ new Set(), Gi = /* @__PURE__ */ new Map();
let I = null, Me = null, ai = !1, vt = "", ze = !1, kt = !1, Ke = "tracks", Ut = null, ut = !1, le = null, Ce = "", Gs = !1, vs = 0;
const Kl = 2e4;
let Et = !1, qs = "", Ls = 0, xs = !1, Pi = Nl, ln = null, Oi = "", ie = !1, ne = null, Es = !1, yi = "", Ue = "", te = !1, ve = /* @__PURE__ */ new Set(), Yi = /* @__PURE__ */ new Set(), He = !1, P = null, gi = !1, Mt = "", Te = null, Ki = "", Se, ci = null, Bi, $ = null, ss = 0, B = [], O = -1, Nt = !1, oe = -1, zi, re = 0, tt = [], Ae = [], G = null, Le = !1, U = !1, Ee = !1, it = [], Ji = null;
const F = {
  library: { ids: /* @__PURE__ */ new Set(), anchor: null },
  queue: { ids: /* @__PURE__ */ new Set(), anchor: null },
  onlineMain: { ids: /* @__PURE__ */ new Set(), anchor: null },
  onlineQueue: { ids: /* @__PURE__ */ new Set(), anchor: null },
  queueList: { ids: /* @__PURE__ */ new Set(), anchor: null }
}, Kt = {
  "local-track": "library",
  "queue-track": "queue",
  "main-track": "onlineMain",
  "play-uri": "onlineQueue",
  "local-queue": "queueList"
}, Ds = {
  library: "#music-mt-list",
  queue: "#music-lq-list",
  onlineMain: "#music-main",
  onlineQueue: "#music-q, #music-q-dd",
  queueList: ".music-lqs"
};
let lt = null, Je = "", Y, Fe = null, Tt = /* @__PURE__ */ new Set(), mt = /* @__PURE__ */ new Set(), li = "", ei = !1;
function Pc() {
  return ie !== ei;
}
const _n = "lunac-music-local-last";
function Oc() {
  try {
    const t = localStorage.getItem(_n);
    if (!t) return null;
    const e = JSON.parse(t);
    if (!e || !Array.isArray(e.queue) || e.queue.length === 0) return null;
    const i = Number(e.index);
    return {
      queue: e.queue,
      index: Number.isInteger(i) && i >= 0 && i < e.queue.length ? i : 0,
      position_ms: Math.max(0, Number(e.position_ms) || 0)
    };
  } catch {
    return null;
  }
}
function Vt() {
  if (!(B.length === 0 || O < 0))
    try {
      localStorage.setItem(_n, JSON.stringify({
        queue: B,
        index: O,
        position_ms: re
      }));
    } catch {
    }
}
const un = "lunac-music-local-queues";
function Jl() {
  try {
    const i = localStorage.getItem(un);
    if (i) {
      const s = JSON.parse(i), n = Array.isArray(s.queues) ? s.queues.filter((r) => r && typeof r.id == "string" && Array.isArray(r.items)).map((r) => ({ id: r.id, name: typeof r.name == "string" ? r.name : "", items: r.items })) : [], c = typeof s.activeId == "string" && n.some((r) => r.id === s.activeId) ? s.activeId : null;
      return { queues: n, activeId: c };
    }
  } catch {
  }
  const t = { queues: [], activeId: null }, e = Oc();
  e && e.queue.length > 0 && t.queues.push({ id: Bc(), name: "", items: e.queue });
  try {
    localStorage.setItem(un, JSON.stringify(t));
  } catch {
  }
  return t;
}
function _i() {
  try {
    localStorage.setItem(un, JSON.stringify({ queues: Ae, activeId: G }));
  } catch {
  }
}
function Bc() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}
function qi() {
  return Ae.find((t) => t.id === G) ?? null;
}
function Xl(t) {
  const e = t || a("music.local_queue_edit");
  if (!Ae.some((s) => s.name === e)) return e;
  let i = 2;
  for (; Ae.some((s) => s.name === `${e} (${i})`); ) i++;
  return `${e} (${i})`;
}
{
  const t = Jl();
  Ae = t.queues, G = t.activeId;
}
const zc = "lunac-music-dual-play";
let We = Zl();
function Zl() {
  try {
    return localStorage.getItem(zc) === "1";
  } catch {
    return !1;
  }
}
function eu(t) {
  try {
    localStorage.setItem(zc, t ? "1" : "0");
  } catch {
  }
}
const Hc = "lunac-music-local-mode";
let ue = tu();
function tu() {
  try {
    const t = localStorage.getItem(Hc);
    return t === "shuffle" || t === "repeat_all" || t === "repeat_one" ? t : "off";
  } catch {
    return "off";
  }
}
function iu(t) {
  try {
    localStorage.setItem(Hc, t);
  } catch {
  }
}
function wn() {
  return a(ue === "shuffle" ? "music.mode_shuffle" : ue === "repeat_all" ? "music.mode_repeat_all" : ue === "repeat_one" ? "music.mode_repeat_one" : "music.mode_off");
}
let pt, hs = !1, Pt, Ja = !1, bs, Wc = 0, Fc = 0, Ot = null, Xi = null, Bt = 0, wi = !1, Dt = -1, zt = [], Hi = 0, Ze, Ft, ys = "", gs = 0, St, on = "";
function ui() {
  return D === "player" || D === "lplayer";
}
function o(t) {
  return t.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
function Wi(t) {
  if (!isFinite(t) || t < 0) return "0:00";
  const e = Math.floor(t / 1e3), i = Math.floor(e / 60), s = e % 60;
  return `${i}:${String(s).padStart(2, "0")}`;
}
function K(t) {
  if (!isFinite(t) || t < 0) return "00:00";
  const e = Math.floor(t / 1e3);
  return `${String(Math.floor(e / 60)).padStart(2, "0")}:${String(e % 60).padStart(2, "0")}`;
}
function R(t) {
  const e = t instanceof Error ? t.message : String(t);
  if (e.includes("ERR_NO_CLIENT_ID")) return a("music.err_no_client_id");
  if (e.includes("ERR_NOT_CONNECTED")) return a("music.err_not_connected");
  if (e.includes("ERR_NO_QUERY")) return a("music.err_no_query");
  if (e.includes("ERR_PORT_BUSY")) return a("music.err_port_busy", { port: String((f == null ? void 0 : f.port) ?? "") });
  if (e.includes("ERR_BAD_URI") || e.includes("ERR_BAD_ID")) return a("music.err_bad_uri");
  if (e.includes("ERR_SPOTIFY_STOPPED"))
    return Et = !0, a("music.err_spotify_stopped");
  const i = e.match(/ERR_RATE_LIMITED:(\S*)/);
  return i ? a("music.err_rate_limited", { s: i[1] || "?" }) : e.includes("Insufficient client scope") ? a("music.err_scope") : e.includes("No active device") || e.includes("NO_ACTIVE_DEVICE") ? a("music.err_no_device") : e.includes("Premium required") || e.includes("PREMIUM_REQUIRED") ? a("music.err_premium") : e.includes("Restriction violated") ? a("music.err_restricted") : e;
}
function su(t) {
  const e = [];
  for (const i of t.split(/\r?\n/)) {
    const s = [...i.matchAll(/\[(\d{1,3}):(\d{1,2})(?:[.:](\d{1,3}))?\]/g)];
    if (s.length === 0) continue;
    const n = i.replace(/\[[^\]]*\]/g, "").trim();
    if (n)
      for (const c of s) {
        const r = c[3] ? Number(c[3].padEnd(3, "0")) / 1e3 : 0;
        e.push({ at: Number(c[1]) * 60 + Number(c[2]) + r, text: n });
      }
  }
  return e.sort((i, s) => i.at - s.at), e;
}
function nu() {
  return `
  <div class="music-root music-curve-root">
    <div class="music-setview">
      <div class="music-set-head">
        <span class="music-set-title">${a("music.tuning_curve")}</span>
      </div>
      <div class="music-set-body">
        <div class="music-tune-plot">
          <!-- 曲线缩放（与调音页同一条交互）：画布默认铺满宽度，点 ＋/－ 按百分比变宽，
               外层容器横向滚动 —— 看细节放大、看全局缩回。 -->
          <div class="music-tune-toolbar">
            <button type="button" class="music-tune-zoom" id="music-tune-zoom-out" title="${o(a("music.tuning_zoom_out"))}" aria-label="${o(a("music.tuning_zoom_out"))}">－</button>
            <span class="music-tune-zoom-label" id="music-tune-zoom-label">100%</span>
            <button type="button" class="music-tune-zoom" id="music-tune-zoom-in" title="${o(a("music.tuning_zoom_in"))}" aria-label="${o(a("music.tuning_zoom_in"))}">＋</button>
          </div>
          <div class="music-tune-scroll" id="music-tune-scroll">
            <canvas id="music-tune-canvas" width="640" height="280"></canvas>
          </div>
          <div class="music-hint" id="music-tune-rate"></div>
        </div>
        <div class="music-tune-probe">
          <button type="button" class="music-btn" id="music-tune-measure">${v.wave}${a("music.tuning_measure")}</button>
          <div class="music-hint" id="music-tune-probe-hint">${o(a("music.tuning_probe_hint"))}</div>
        </div>
        <div class="music-field">
          <label>${a("music.tuning_slots")}</label>
          <div class="music-seg music-slot-list" id="music-tune-slots"></div>
        </div>
      </div>
    </div>
    <div class="music-msg" id="music-msg"></div>
  </div>`;
}
function au() {
  return `
  <div class="music-root">
    <!-- ── 默认界面：顶部工具条 + 状态行 + 连接设置 + 歌单列 / 搜索结果 ──
         工具条与「返回」按钮**分属两态**：默认态用底部栏那个「进播放界面」，
         播放态用**标题栏那个 ←**（syncTitlebarClose 把 × 换成它；歌名模块右端
         原来还有一枚「返回歌单」，2026-10-01 已按用户口径删掉）。
         ⚠️ 本段在模板字符串里，注释里一个反引号都不能出现（预检 #15 / #39 ⑩）。 -->
    <div class="music-view" id="music-v-default">
      <!-- 顶部工具条：头像 / 账号 / 搜索（**带下拉预览**）/ 状态 / 设置。
           2026-09-28 第二次改：设备按钮与「展开播放面板」都**下移到最底下那条控制栏**
           （用户要求「严格对齐 Spotify」，Spotify 的工具条上本来就没有这两样）。 -->
      <div class="music-toolbar">
        <button class="music-avatar" id="music-avatar" title="${o(a("music.account_btn"))}"></button>
        <span class="music-acc" id="music-acc"></span>
        <div class="music-search-wrap">
          <input class="music-search" id="music-search" type="search" autocomplete="off" spellcheck="false" placeholder="${o(a("music.search_ph"))}">
          <!-- 下拉预览：绝对定位挂在工具条下方（**不占布局**，否则窗口高会跟着抖） -->
          <div class="music-dd hidden" id="music-search-dd"></div>
        </div>
        <!-- 「自定义队列」状态按钮 2026-10-10 已**从工具条挪回本地音乐分页**（用户口径：
             放到那页筛选标题行（.music-local-head-row）的最右侧、只在本地页显示）—— 见
             renderLocalMain 里那行骨架与 applyQueueModeUi。它不再随本工具条显隐。
             注：本段在模板字符串里，注释里一个反引号都不能出现（预检 #15 / #39 ⑩）。 -->
        <span class="music-status" id="music-status">${a("music.loading")}</span>
        <!-- 「恢复」按钮（2026-10-02）：**只在 429 硬闸拉着时显示**（见 renderResumeBtn）。
             它是用户唯一的出口 —— 宿主一旦收到 429 就停掉所有 Spotify 请求、且不自动重试。
             放工具条而不是底部提示行：提示行在播放态是绝对定位 + pointer-events:none，点不到。
             ⚠️ 本段是 JS 模板字符串，注释里不能出现反引号（预检 #15 / #39 ⑩）。 -->
        <button class="music-ghost-btn hidden" id="music-resume">${a("music.resume")}</button>
        <!-- 这里原来的「本地音乐」文件夹按钮与「调音」推子按钮**已删除**（2026-10-01
             用户口径）：这两个入口收进了**标题栏那枚三段切换**（在线歌单 / 本地音乐 /
             调音，见 renderTitlebarSwitch）。标题栏是悬浮窗独有的，插件若被嵌在主窗口里
             就没有那一条 —— 那种情况下切换器会退到本工具条里（见 placeSwitcher），
             所以这里不给它们留第二份入口，否则「删掉」就变成了「多一份」。
             ⚠️ 本段是 JS 模板字符串，注释里不能出现反引号（预检 #15 / #39 ⑩）。 -->
        <button class="music-ghost-btn music-icon-btn" id="music-setup-toggle" title="${o(a("music.settings"))}">${v.gear}</button>
      </div>

      <div class="music-setup hidden" id="music-setup">
        <div class="music-hint" id="music-setup-hint">${a("music.setup_hint")}</div>
        <!-- 凭据字段默认只在「没有内置 Client ID」或用户主动展开时显示：
             内置值让「登录」变成一步操作，Redirect URI 那一串对普通用户是噪音。 -->
        <button class="music-ghost-btn music-fields-toggle hidden" id="music-fields-toggle"></button>
        <div id="music-setup-fields">
          <div class="music-field">
            <label for="music-client-id">${a("music.client_id")}</label>
            <input id="music-client-id" type="text" spellcheck="false" autocomplete="off" placeholder="${o(a("music.client_id_ph"))}">
          </div>
          <div class="music-field music-field-port">
            <label for="music-port">${a("music.port")}</label>
            <input id="music-port" type="text" inputmode="numeric" autocomplete="off">
          </div>
          <div class="music-field">
            <label>${a("music.redirect")}</label>
            <div class="music-redirect-row">
              <code id="music-redirect"></code>
              <button class="music-ghost-btn music-icon-btn" id="music-copy-redirect" title="${o(a("music.copy"))}">${v.copy}</button>
            </div>
          </div>
          <!-- 本机播放（librespot）的两项设置：路径留空 = 自动探测；代理留空 = 直连。
               两者都不是「必填」，所以各带一行小字说明（见 renderSetup）。 -->
          <div class="music-field">
            <label for="music-librespot">${a("music.local_play")}</label>
            <input id="music-librespot" type="text" spellcheck="false" autocomplete="off" placeholder="librespot.exe">
          </div>
          <div class="music-field">
            <label for="music-librespot-proxy">proxy</label>
            <input id="music-librespot-proxy" type="text" spellcheck="false" autocomplete="off" placeholder="${o(a("music.librespot_proxy_ph"))}">
          </div>
        </div>
        <div class="music-actions">
          <button class="music-btn" id="music-save">${a("music.save")}</button>
          <button class="music-btn music-primary" id="music-connect">${v.link} ${a("music.connect")}</button>
          <button class="music-btn" id="music-disconnect">${v.power} ${a("music.disconnect")}</button>
        </div>
      </div>

      <!-- 主体：**左栏（宽度可拖）+ 分隔条 + 主区**（用户 2026-09-28 的
           「歌单列作为单独的一列可拉动」「中间大的大部分区域作为歌曲列表」）。
           两栏各自内部滚动 —— 窗口是定尺 1280×720，不是靠内容撑出来的。 -->
      <div class="music-body hidden" id="music-body">
        <aside class="music-side" id="music-side">
          <div class="music-side-tabs" id="music-side-tabs">
            <button class="music-tab on" data-act="side-tab" data-tab="playlist">${a("music.playlists")}</button>
            <button class="music-tab" data-act="side-tab" data-tab="album">${a("music.tab_albums")}</button>
            <button class="music-tab" data-act="side-tab" data-tab="artist">${a("music.tab_artists")}</button>
            <button class="music-tab" data-act="side-tab" data-tab="show">${a("music.tab_shows")}</button>
            <!-- 「最常听」栏（2026-10-01 用户第 4 条）。**放在最后**：那四栏是「我的库」，
                 这一栏是「库外的东西」，顺序上按这个分组走。
                 原先与它并列的「新发行」2026-10-02 删除（端点永久 403）。
                 注：本段在模板字符串里，注释里不能出现反引号（预检 #15 / #39 ⑩）。 -->
            <button class="music-tab" data-act="side-tab" data-tab="top">${a("music.tab_top")}</button>
          </div>
          <!-- 「本地音乐」那一页的左栏头（与上面那排 Spotify 页签**互斥显示**）：
               一个标题 + 一个「添加目录」。它跟着 localPage 切，见 renderLocalSide。 -->
          <div class="music-local-head hidden" id="music-local-head">
            <span class="music-local-title">${a("music.local_library")}</span>
            <div class="music-local-head-btns">
              <!-- 正常态三枚（2026-10-01 用户口径）：
                   ＋ = 添加（**目录或播放列表文件**，两个入口合一）
                   ✎ = 修改列表（进编辑态）—— 取代原来那枚「打开播放列表文件」
                   ⟳ = 重扫。
                   图标一律取自 icon-style.md §3，不自己画（见 SVG.edit / SVG.trash）。 -->
              <button class="music-ghost-btn music-icon-btn" id="music-local-add" title="${o(a("music.local_add"))}">${v.plus}</button>
              <button class="music-ghost-btn music-icon-btn" id="music-local-list" title="${o(a("music.local_edit"))}">${v.edit}</button>
              <!-- 「重扫」那枚**已从本行删掉**（2026-10-10 用户口径：扫描按钮只留一枚）——
                   保留的是主区筛选标题行（.music-local-head-row）里那枚（id=music-scan-btn）；
                   本行不再有扫描入口。自定义队列开关也在那边（最右一枚），不在本行。 -->
              <!-- 编辑态两枚（正常态隐藏，切法见 renderLocalHead）：
                   🗑 = 把勾选的行**摘出列表**（暂存，还能反悔）
                   × = 退出并保存（到这一步才真落盘） -->
              <button class="music-ghost-btn music-icon-btn hidden" id="music-local-del" title="${o(a("music.local_del_sel"))}">${v.trash}</button>
              <button class="music-ghost-btn music-icon-btn hidden" id="music-local-editdone" title="${o(a("music.local_edit_done"))}">${v.x}</button>
              <!-- 那个「＋」的二选一浮层（目录 / 播放列表文件）。画法见 renderLocalAddMenu，
                   定位参照是上面那排按钮（.music-local-head-btns 是 relative）。
                   注：本段在**模板字符串**里，注释里一个反引号都不能出现（预检 #15 / #39 ⑩）。 -->
              <div class="music-dd music-local-add-dd hidden" id="music-local-add-dd"></div>
            </div>
          </div>
          <div class="music-side-list" id="music-side-list"></div>
        </aside>
        <div class="music-split" id="music-split" role="separator" aria-orientation="vertical"></div>
        <main class="music-main" id="music-main"></main>
      </div>

      <!-- ── 底部控制栏（2026-09-28，Spotify 复刻）─────────────────────────
           用户要求「在默认面板下方添加 Spotify 那样的播放控制，并把一些按钮也
           移动到下方控制」。三列 grid：左 = 正在播放（点它 = 打开播放面板）、
           中 = 播放键组、右 = 设备 / 音量 / 队列 / 展开。
           栏顶那条 2px 细进度线**绝对定位**（不占高），拖动即可跳转。
           **两个弹层都挂在右端那一簇里、向上弹**：这条栏贴着窗口下沿，
           向下弹会跑到窗口外面（见 styles.css 里那两条覆盖 top 的规则）。
           注意本段是 JS 模板字符串 —— 注释里不能出现反引号（会把字符串截断）。 -->
      <div class="music-nowbar no-drawer hidden" id="music-nowbar">
        <!-- 「另一侧」的抽屉（2026-10-03 用户口径）：两条控制栏同屏只能有一条，
             另一条收进左端这一枚里 —— 点它把另一条换出来、这一条收进去。
             只在「同时出声」开着**且另一侧确实有东西**时出现（见 syncHead）。
             它是 grid 的第一列（auto 宽），隐藏时整列塌成 0 ⇒ 不开抽屉时外观不变。 -->
        <button type="button" class="music-drawer-btn hidden" id="music-b-drawer"></button>
        <div class="music-bp music-bp-timed" id="music-bp" title="${o(a("music.seek"))}">
          <div class="music-bp-fill" id="music-bp-fill"></div>
          <div class="music-progress-tip" id="music-bp-tip">0:00</div>
          <span class="music-btime" id="music-b-time">00:00 / 00:00</span>
        </div>
        <button class="music-bnow" id="music-bnow" title="${o(a("music.open_player"))}">
          <span class="music-bnow-cover" id="music-bnow-cover"></span>
          <span class="music-bnow-main">
            <span class="music-bnow-n" id="music-bnow-n"></span>
            <span class="music-bnow-a" id="music-bnow-a"></span>
          </span>
          <!-- 「进入小窗播放」的位置**收在左边这一块上**（2026-10-03 用户口径）：
               左块本身就是那个按钮，右端那枚重复的展开按钮已删。这个图标只是为了
               让「它可点」这件事看得见（同一条口径也铺到了本地那条栏，见下面）。 -->
          <span class="music-bnow-go">${v.expand}</span>
        </button>
        <div class="music-bctl">
          <button class="music-round-btn music-mode-btn" id="music-b-mode" data-mode="off"></button>
          <button class="music-round-btn" id="music-b-prev" title="${o(a("music.prev"))}">${v.prev}</button>
          <button class="music-round-btn music-play-btn" id="music-b-play" title="${o(a("music.play_pause"))}">${v.play}</button>
          <button class="music-round-btn" id="music-b-next" title="${o(a("music.next"))}">${v.next}</button>
        </div>
        <div class="music-bend">
          <!-- 与本地播放条上那一枚是**同一个状态**（见 dualPlay 的注释）。
               两枚按钮各自长在自己的控制区里，用户在哪条栏上都够得着。 -->
          <button class="music-ghost-btn music-icon-btn music-dual-btn" id="music-dual-btn" title="${o(a("music.dual_play"))}">${v.dual}</button>
          <button class="music-ghost-btn music-icon-btn" id="music-devices-btn" title="${o(a("music.devices"))}">${v.speaker}</button>
          <span class="music-vol-ico">${v.volume}</span>
          <input class="music-vol" id="music-b-vol" type="range" min="0" max="100" step="1" value="50" style="--vol-pct:50%" title="${o(a("music.volume"))}">
          <button class="music-round-btn" id="music-b-queue" title="${o(a("music.queue"))}">${v.list}</button>
          <!-- 右端那枚「进入小窗播放」**已删**（2026-10-03 用户口径）：它与左边
               「正在播放」那一块是同一个动作（都进小窗播放态），右边这枚是重复入口。
               保留左边那块既有的按钮语义，右端这一簇从此只放设备 / 音量 / 队列。 -->
          <div class="music-dd music-dev-dd hidden" id="music-dev-dd"></div>
          <div class="music-dd hidden" id="music-q-dd"></div>
        </div>
      </div>

      <!-- ── 本地文件播放条（2026-10-01）───────────────────────────────
           与上面那条 Spotify 控制栏**不是一条**：那条的对象是远端播放器
           （Web API 的 spotify_* 命令），这条的对象是宿主里那条本机音频流
           （player.rs 的 player_* 命令）。两者的数据源、可用条件（这条不要求
           登录 Spotify）、能做的事都不一样 —— 合成一条会到处长出
           「如果是本地就…」的分支，那正是两套东西被缝在一起的样子。
           只在「本地页 + 有本地会话」时出现，见 renderLocalNowbar。
           注意本段是 JS 模板字符串 —— 注释里不能出现反引号。 -->
      <div class="music-nowbar music-lnowbar no-drawer hidden" id="music-lnowbar">
        <!-- 「另一侧」的抽屉，与上面那条栏同形同义（点击 = 把在线那条换出来）。 -->
        <button type="button" class="music-drawer-btn hidden" id="music-l-drawer"></button>
        <div class="music-bp" id="music-lbp" title="${o(a("music.seek"))}">
          <div class="music-bp-fill" id="music-lbp-fill"></div>
          <div class="music-progress-tip" id="music-lbp-tip">0:00</div>
        </div>
        <!-- 左边这一块**就是**「进入小窗播放」的入口（2026-10-03 用户口径）：
             原来它是纯展示（本地没有小窗可进），2026-10-01 有了本地小窗之后那句话
             就不成立了 ⇒ 与 Spotify 那条栏同形，做成按钮，点它进 #music-v-lplayer。 -->
        <button class="music-bnow music-lnow" id="music-lnow" title="${o(a("music.open_player"))}">
          <span class="music-bnow-cover" id="music-lnow-cover"></span>
          <span class="music-bnow-main">
            <span class="music-bnow-n" id="music-lnow-n"></span>
            <span class="music-bnow-a" id="music-lnow-a"></span>
          </span>
          <span class="music-bnow-go">${v.expand}</span>
        </button>
        <div class="music-bctl">
          <!-- 播放模式（关 / 随机 / 循环列表 / 单曲循环，2026-10-01 用户第 8 条）。
               与 Spotify 那枚 #music-b-mode **不是一件事**：那枚是远端真相，
               这枚是前端自己算的（见 localMode 的注释），所以两枚各记各的状态。
               注：本段在模板字符串里，注释里不能出现反引号（预检 #15 / #39 ⑩）。 -->
          <button class="music-round-btn music-mode-btn" id="music-l-mode" data-mode="off" title="${o(a("music.mode_off"))}"></button>
          <button class="music-round-btn" id="music-l-prev" title="${o(a("music.prev"))}">${v.prev}</button>
          <button class="music-round-btn music-play-btn" id="music-l-play" title="${o(a("music.play_pause"))}">${v.play}</button>
          <button class="music-round-btn" id="music-l-next" title="${o(a("music.next"))}">${v.next}</button>
          <button class="music-round-btn" id="music-l-stop" title="${o(a("music.local_stop"))}">${v.stop}</button>
        </div>
        <div class="music-bend">
          <button class="music-ghost-btn music-icon-btn music-dual-btn" id="music-l-dual-btn" title="${o(a("music.dual_play"))}">${v.dual}</button>
          <span class="music-ltime" id="music-l-time">0:00 / 0:00</span>
          <span class="music-vol-ico">${v.volume}</span>
          <input class="music-vol" id="music-l-vol" type="range" min="0" max="100" step="1" value="80" style="--vol-pct:80%" title="${o(a("music.volume"))}">
          <!-- 「队列」按钮（2026-10-09 用户口径，2026-10-11 澄清）：在音量右边，点它弹出一个
               **与在线 #music-q-dd 同形同义的下拉浮层**（#music-lq-dd，锚在这条栏同一位置），
               展示**这一轮的播放队列**（localQueue —— 即现在 / 接下来放什么），**不是**左栏那些
               自定义队列（与远端 #music-b-queue 同一个图标）。
               注：本段在模板字符串里，注释里一个反引号都不能出现（预检 #15 / #39 ⑩）。 -->
          <button class="music-round-btn" id="music-l-queue" title="${o(a("music.local_play_queue"))}">${v.list}</button>
          <div class="music-dd hidden" id="music-lq-dd"></div>
          <!-- 右端那枚「进入小窗播放」**已删**（2026-10-03 用户口径）：动作与左边
               「正在播放」那一块重复，两边只留左边一个入口。 -->
        </div>
      </div>
    </div>

    <!-- ── 播放界面：**550×130 的长条**（封面 100 + 右侧列 450）──────────
         右侧列三块的高度加起来正好是长条高：歌名 30 + 歌词 65 + 控制 35 = 130。
         **这几个数都是用户 2026-09-27 给的定尺**：改任何一个都要同步
         styles.css 的 .music-name / .music-lyr / .music-bar，以及宿主
         plugin_window.rs 的 MUSIC_W（见 ai-spec §4.6 与预检 #39 ④）。 -->
    <!-- 注意：本段是 JS 模板字符串，**注释里不能出现反引号**（会把字符串截断）。 -->
    <div class="music-view music-player hidden" id="music-v-player">
      <div class="music-pv-card">
        <div class="music-pv-cover" id="music-pv-cover"></div>
        <div class="music-pv-col">
          <!-- 歌名模块 H30：歌名（亮）+ 歌手·专辑（暗）。 -->
          <div class="music-name">
            <div class="music-name-text">
              <span class="music-title" id="music-pv-title"></span>
              <span class="music-sub" id="music-pv-sub"></span>
            </div>
            <!-- 「返回歌单」那枚**已删除**（2026-10-01 用户口径：小窗播放里那个不是
                 状态栏里的返回按钮要去掉）。退出去仍然走**标题栏那个 ←** ——
                 它在播放态由 syncTitlebarClose 把 × 换成 ←，语义是「停播 + 回默认面板」
                 （见 stopAndBack），也是用户当初指定的出口。所以这里删掉不留缺口。 -->
          </div>

          <!-- 歌词模块 H65：正好两行可见（行高 32）。已过 + 正在 = 亮，未到 = 暗；
               点某一行 = 跳到那一句的进度。 -->
          <div class="music-lyr" id="music-lyr"></div>

          <!-- 控制面板 H35：进度条**叠在本块顶部**（绝对定位 ⇒ 不占高度，总高仍是 130），
               四个播放键在块内居中，右端音量条 80px + 播放列表按钮。 -->
          <div class="music-bar">
            <!-- 时间在控制块**最左端、进度条下方**（用户 2026-09-27 定）。
                 绝对定位 ⇒ 不参与四钮的居中计算。 -->
            <div class="music-time">
              <span id="music-pv-pos">0:00</span><span class="music-time-sep">/</span><span id="music-pv-dur">0:00</span>
            </div>
            <div class="music-progress" id="music-pv-progress" title="${o(a("music.seek"))}">
              <div class="music-progress-fill" id="music-pv-fill"></div>
              <div class="music-progress-dot" id="music-pv-dot"></div>
              <div class="music-progress-tip" id="music-pv-tip">0:00</div>
            </div>
            <div class="music-bar-main">
              <button class="music-round-btn music-mode-btn" id="music-mode" data-mode="off"></button>
              <button class="music-round-btn" id="music-prev" title="${o(a("music.prev"))}">${v.prev}</button>
              <button class="music-round-btn music-play-btn" id="music-play" title="${o(a("music.play_pause"))}">${v.play}</button>
              <button class="music-round-btn" id="music-next" title="${o(a("music.next"))}">${v.next}</button>
            </div>
            <div class="music-bar-end">
              <span class="music-vol-ico">${v.volume}</span>
              <input class="music-vol" id="music-vol" type="range" min="0" max="100" step="1" value="50" style="--vol-pct:50%" title="${o(a("music.volume"))}">
              <button class="music-round-btn" id="music-queue-btn" title="${o(a("music.queue"))}">${v.list}</button>
            </div>
          </div>
        </div>
      </div>

      <!-- 播放列表（队列）挂在长条**下方**、不再与歌词互斥：长条是定尺 130，
           塞不进队列。开着时窗口按内容长高（applyResize 实测贴合）。 -->
      <div class="music-q-wrap hidden" id="music-q-wrap">
        <div class="music-sec-head">
          <span class="music-sec-title">${a("music.queue")}</span>
          <span class="music-sec-note">${a("music.queue_hint")}</span>
        </div>
        <div class="music-q" id="music-q"></div>
      </div>
    </div>

    <!-- ── 本地小窗：**本地文件播放也有的那条长条**（2026-10-01 用户口径
         「在本地文件播放的情况下也添加小窗模式」）────────────────────────
         与上一个视图**共用同一套外壳类**（music-player / music-pv-card / music-pv-cover /
         music-name / music-bar / music-bp…）⇒ 尺寸（550×130）、圆角、配色、
         进度条的细线与命中区，一行业务 CSS 都不用重写。
         唯一的差别在**中间那一块**：远端那条长条放的是歌词（H65，见 .music-lyr），
         本地文件没有歌词 —— 那一格换成**大号进度线 + 时间**（见 .music-lp-mid）。
         三块的高度仍是 30 + 65 + 35 = 130，与 MUSIC_W_BAR / applyResize 对齐。
         数据与动作**都只有一份**：状态来自 localPlayer，按钮走的是本地播放那几条
         既有函数（见 attachMusicListeners 里那几条绑定）。
         注意本段是 JS 模板字符串 —— 注释里不能出现反引号（预检 #15 / #39 ⑩）。 -->
    <div class="music-view music-player hidden" id="music-v-lplayer">
      <div class="music-pv-card">
        <div class="music-pv-cover" id="music-lp-cover"></div>
        <div class="music-pv-col">
          <div class="music-name">
            <div class="music-name-text">
              <span class="music-title" id="music-lp-title"></span>
              <span class="music-sub" id="music-lp-sub"></span>
            </div>
          </div>
          <div class="music-lp-mid">
            <div class="music-bp music-lp-seek" id="music-lp-progress" title="${o(a("music.seek"))}">
              <div class="music-bp-fill" id="music-lp-fill"></div>
              <div class="music-progress-tip" id="music-lp-tip">0:00</div>
            </div>
            <div class="music-lp-time" id="music-lp-time">0:00 / 0:00</div>
          </div>
          <div class="music-bar">
            <div class="music-bar-main">
              <button class="music-round-btn music-mode-btn" id="music-lp-mode" data-mode="off" title="${o(a("music.mode_off"))}"></button>
              <button class="music-round-btn" id="music-lp-prev" title="${o(a("music.prev"))}">${v.prev}</button>
              <button class="music-round-btn music-play-btn" id="music-lp-play" title="${o(a("music.play_pause"))}">${v.play}</button>
              <button class="music-round-btn" id="music-lp-next" title="${o(a("music.next"))}">${v.next}</button>
              <button class="music-round-btn" id="music-lp-stop" title="${o(a("music.local_stop"))}">${v.stop}</button>
            </div>
            <div class="music-bar-end">
              <span class="music-vol-ico">${v.volume}</span>
              <input class="music-vol" id="music-lp-vol" type="range" min="0" max="100" step="1" value="80" style="--vol-pct:80%" title="${o(a("music.volume"))}">
              <!-- 「队列」按钮（2026-10-09 用户口径，2026-10-11 改）：与本地那条控制栏上的同一枚
                   同义，但**小窗里没有内容区、也没有浮层的锚点** ⇒ 点它**切回默认面板再打开
                   同一个 #music-lq-dd 浮层**（本任务选定：② 切到默认面板并打开浮层）。
                   注：本段在模板字符串里，注释里一个反引号都不能出现（预检 #15 / #39 ⑩）。 -->
              <button class="music-round-btn" id="music-lp-queue" title="${o(a("music.local_play_queue"))}">${v.list}</button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- ── 设置页：**整屏**（2026-10-01 用户要求「设置图标进到一个新的设置页面」）──
         与 #music-v-player 同为整屏视图，由 mode = "settings" 切（见 renderMode）。
         职责划分是硬的：**这里只放「偏好」，「连接」仍归头像点开的 #music-setup**
         （Client ID / 端口 / 回调 / librespot 路径与代理），**「调音」也有自己的一页**
         （#music-v-tuning，2026-10-01 用户要求搬出去的）。理由与那张卡片里的
         「保存」按钮直接相关 —— 一个卡片里塞两套保存语义必然出岔子，而现在这几页
         各有各的保存。
         ⚠️ 本段是 JS 模板字符串 —— 注释里**不许出现反引号**，连「引用一个标识符」
         那种写法都不行：它会把模板字符串提前截断（预检 #15 / #39 ⑩，本轮又踩了一次）。 -->
    <div class="music-view music-setview hidden" id="music-v-settings">
      <div class="music-set-head">
        <button class="music-ghost-btn music-icon-btn" id="music-set-back" title="${o(a("music.settings_back"))}">${v.back}</button>
        <span class="music-set-title">${a("music.settings")}</span>
      </div>
      <div class="music-set-body">
        <!-- 串流质量：三档互斥按钮。**不用原生 select 元素** —— WebView2 透明窗口里
             它不渲染弹出层（code-rules §5.2）。三档值只允许 96/160/320（宿主侧
             LIBRESPOT_BITRATES，抄自 librespot --help 的原文）。
             ⚠️ 模板字符串 ⇒ 本段注释里也不许出现反引号（预检 #39 ⑩）。 -->
        <div class="music-field">
          <label>${a("music.quality")}</label>
          <div class="music-seg" id="music-quality">
            ${[96, 160, 320].map((t) => `<button type="button" class="music-seg-btn" data-q="${t}">${t}k</button>`).join("")}
          </div>
          <div class="music-hint">${o(a("music.quality_hint"))}</div>
          <div class="music-hint">${o(a("music.quality_local_note"))}</div>
        </div>
        <!-- 调音页的入口（2026-10-03 用户要求「设置按钮入口」）。**不在这页里编辑调音**：
             调音是**按下即生效、即落盘**的实时功能，而这页那套是「攒着等保存」
             （音质要重启 librespot 才生效）—— 两种保存语义混在一张卡片里必然出岔子。
             所以这里只给一颗**进去的按钮**（切到 #music-v-tuning 那一页）。 -->
        <div class="music-field">
          <label>${a("music.tuning")}</label>
          <div class="music-actions">
            <button type="button" class="music-btn" id="music-set-tuning">${a("music.tuning_open")}</button>
          </div>
        </div>
        <div class="music-actions">
          <button class="music-btn" id="music-set-save">${a("music.save")}</button>
        </div>
      </div>
    </div>

    <!-- ── 调音页：**自己一页**（2026-10-01 用户口径）────────────────────
         用户明确「调音插件的界面不能放置到设置界面里，要新建一个界面专门用来显示调音」
         —— 所以它在 2026-10-01 从设置页那一块**整段搬过来**（上一版是「调音分区」）。
         入口只有一个：标题栏那枚三段切换的第三段（见 renderTitlebarSwitch）——
         **页内那枚返回按钮 2026-10-02 按用户要求取掉了**：切换器本身就是「回得去」的
         那一条路（点回「在线歌单 / 本地音乐」即离页），再摆一个返回是重复入口。
         版面顺序（2026-10-03 用户口径，本轮重排）：三栏骨架 ——
         左 = 工具条（保存 / 导入 / 导出）+ 我的预设；中 = 三条全局水平滑块 +
         **频段柱**（滤波器与均衡器已合并）；右 = 通道槽 + 全局效果器（延迟 / 复制 / 卷积）。
         四条纪律：① 控件**按下就生效、也当场落盘**（与设置页「音质」那两条攒着
         等保存完全不同：音质要重启 librespot 才生效，调音是实时的）；
         ② 滤波器类型的**名单来自宿主**（tuning.kinds，与引擎 Kind::ALL 同源）、
         用户预设名单也来自宿主（tuning.user_presets）—— 前端不维护第二份名单；
         ③ **两条播放链都生效**（2026-10-04 起）：本地文件走宿主 player.rs，在线歌单走
         librespot 的 -B pipe 输出 → 宿主的 live_audio.rs，两条套的是**同一个**
         TuningSource（共享同一份配置与版本号 ⇒ 在哪边调都立刻生效）。唯一例外是
         **首次授权那一次**：那一次不能带 -B pipe（OAuth 会把 URL 打到 stdout、污染
         PCM，见 librespot_args 的三条注释），重启一次 librespot 即接入；
         ④ 频段柱里的控件**全部动态渲染**（见 renderTuningFilters），这里只留容器。
         ⚠️ 本段是 JS 模板字符串 ⇒ 注释里不许出现反引号（预检 #15 / #39 ⑩）。 -->
    <div class="music-view music-setview hidden" id="music-v-tuning">
      <div class="music-set-head">
        <span class="music-set-title">${a("music.tuning")}</span>
        <!-- 频响曲线**不在这页里**（2026-10-03 用户口径「参照 Peace」）：它搬进一扇独立小窗，
             这页只留一颗按钮当入口。理由：曲线是「一边看一边调」的东西，占满这页会把
             推子与数值表挤没；而这一页要按 Peace 的三栏骨架排。 -->
        <button type="button" class="music-btn music-curve-open" id="music-curve-open">${v.wave}${a("music.tuning_curve_open")}</button>
        <button type="button" class="music-switch" id="music-tuning-on" role="switch" aria-checked="false" title="${o(a("music.tuning"))}">
          <span class="music-switch-knob"></span>
        </button>
      </div>
      <!-- 三栏骨架（2026-10-03，参照 Peace 主窗 → 同日按用户第 7/8 条重排）：
             左 = 工具条 + 我的预设、中 = 三条全局滑块 + 频段柱、右 = 扬声器声道 + 全局效果器。
             **接线函数的 id 一律沿用**（music-tuning-user-presets / music-tune-slots /
             music-tuning-filters / music-preamp-range …）：这一页的 render 与委托全按 id 找节点，
             重排只动 HTML 的位置，逻辑一行都不用改。
             ⚠️ 本段是 JS 模板字符串 ⇒ 注释里不许出现反引号（预检 #15 / #39 ⑩）。 -->
      <div class="music-set-body music-tune-cols">
        <!-- ── 左栏：预设（2026-10-03 用户口径：工具条移到最上、内置 5 档整批删掉）── -->
        <div class="music-tune-col music-tune-col-presets">
          <div class="music-actions">
            <button type="button" class="music-btn" id="music-preset-save">${o(a("music.tuning_preset_save"))}</button>
            <button type="button" class="music-btn" id="music-preset-import">${o(a("music.tuning_preset_import"))}</button>
            <button type="button" class="music-btn" id="music-preset-export">${o(a("music.tuning_preset_export"))}</button>
          </div>
          <div class="music-preset-list" id="music-tuning-user-presets"></div>
          <div class="music-preset-edit hidden" id="music-tuning-preset-edit">
            <div class="music-hint" id="music-preset-edit-hint"></div>
            <input type="text" id="music-preset-name" autocomplete="off" spellcheck="false" />
            <button type="button" class="music-btn" id="music-preset-ok"></button>
            <button type="button" class="music-btn" id="music-preset-cancel">${o(a("music.tuning_preset_cancel"))}</button>
          </div>
          <!-- A-B 盲测（2026-10-06）：两个快照槽 + 随机映射 + 揭晓。
               快照 = **整条链**（宿主落 config	uningab-a.json / ab-b.json）；
               切换走 player_tuning_ab_apply（先校验→落盘→改内存→版本号+1 ⇒ 不重播）。
               盲测时两个按钮只显示 1 / 2，映射由 tuneAbSlots 决定，点「揭晓」才告诉用户。 -->
          <div class="music-tune-ab" id="music-tune-ab">
            <div class="music-sub-label">${o(a("music.tuning_ab_title"))}</div>
            <div class="music-actions">
              <button type="button" class="music-btn" id="music-ab-save-a">${o(a("music.tuning_ab_save_a"))}</button>
              <button type="button" class="music-btn" id="music-ab-save-b">${o(a("music.tuning_ab_save_b"))}</button>
            </div>
            <div class="music-actions" id="music-ab-play">
              <button type="button" class="music-btn" id="music-ab-pos1" data-pos="1">A</button>
              <button type="button" class="music-btn" id="music-ab-pos2" data-pos="2">B</button>
              <button type="button" class="music-btn" id="music-ab-blind">${o(a("music.tuning_ab_blind"))}</button>
              <button type="button" class="music-btn hidden" id="music-ab-reveal">${o(a("music.tuning_ab_reveal"))}</button>
            </div>
            <div class="music-hint" id="music-ab-hint"></div>
          </div>
        </div>
        <!-- ── 中栏：三条全局水平滑块 + 频段柱（2026-10-03 用户口径）────────────
             三条滑块 = 总增益 / 低音增益 / 高音增益（Peace 顶部那种「左标签 + 滑块 + 右数值框」）；
             频段柱 = **滤波器与均衡器合并**后的主体：频率可编辑 / 竖拉条 / 大号增益 / Q / 类型按钮。
             延迟属于全局效果器，已挪到右栏（与声道复制 / 卷积同处）。 -->
        <div class="music-tune-col music-tune-col-eq">
          <div class="music-tune-sliderrow">
            <label>${a("music.tuning_preamp")}</label>
            <input type="range" class="music-tune-hslider" id="music-preamp-range" min="-24" max="24" step="0.5" aria-label="${o(a("music.tuning_preamp"))}" />
            <input type="text" class="music-tune-num" id="music-tune-preamp" inputmode="decimal" autocomplete="off" spellcheck="false" aria-label="${o(a("music.tuning_preamp"))}" />
          </div>
          <div class="music-tune-sliderrow">
            <label>${a("music.tuning_bass")}</label>
            <input type="range" class="music-tune-hslider" id="music-bass-range" min="-24" max="24" step="0.5" aria-label="${o(a("music.tuning_bass"))}" />
            <input type="text" class="music-tune-num" id="music-tune-bass" inputmode="decimal" autocomplete="off" spellcheck="false" aria-label="${o(a("music.tuning_bass"))}" />
          </div>
          <div class="music-tune-sliderrow">
            <label>${a("music.tuning_treble")}</label>
            <input type="range" class="music-tune-hslider" id="music-treble-range" min="-24" max="24" step="0.5" aria-label="${o(a("music.tuning_treble"))}" />
            <input type="text" class="music-tune-num" id="music-tune-treble" inputmode="decimal" autocomplete="off" spellcheck="false" aria-label="${o(a("music.tuning_treble"))}" />
          </div>
          <!-- 频段柱：作用域是**右栏选中的那个通道槽**（全局槽 ↔ 引擎的 filters）。
               左侧那列图例（2026-10-06 用户要求）把「频率 / 增益 / 质量」各标一次，并与柱内
               三行**逐行对齐** —— 三个框都只有数字，少了它用户不知道哪个是哪个。行高与柱子
               共用 --tf-* 那四个变量（见 styles.css 的 .music-tune-filterwrap），改一处两边同步。
               第二格是空占位，对齐的是那根竖拉条（增益那一行同时有拉条与大号读数，只标一次）。 -->
          <div class="music-tune-filterwrap">
            <div class="music-tune-legend" aria-hidden="true">
              <span class="l-freq">${o(a("music.tuning_freq"))}</span>
              <span class="l-slider"></span>
              <span class="l-gain">${o(a("music.tuning_gain"))}</span>
              <span class="l-q">${o(a("music.tuning_q"))}</span>
            </div>
            <div class="music-tune-filters" id="music-tuning-filters"></div>
          </div>
          <div class="music-actions">
            <button type="button" class="music-btn" id="music-tune-add">${v.plus}${a("music.tuning_add")}</button>
          </div>
        </div>
        <!-- ── 右栏：通道槽 + 全局效果器（延迟 / 声道复制 / 卷积）──────────────
             三样效果器都是**顶层字段** ⇒ 只在「全局」通道槽里显示（画在通道槽里会看起来像
             只作用于那条声道）。槽本身不落盘 —— 它只是「中栏那排频段柱在编辑哪一份草稿」
             这个视图状态；改动落在草稿里，提交时整排一起发（见 tuneIfElsePayload）。 -->
        <div class="music-tune-col music-tune-col-side">
          <div class="music-sub-label">${a("music.tuning_slots")}</div>
          <div class="music-seg music-slot-list music-slot-col" id="music-tune-slots"></div>
          <div class="music-field hidden" id="music-tune-delay">
            <div class="music-tune-sliderrow">
              <label>${a("music.tuning_delay")}</label>
              <input type="range" class="music-tune-hslider" id="music-delay-range" min="0" max="5000" step="1" aria-label="${o(a("music.tuning_delay"))}" />
              <input type="text" class="music-tune-num" id="music-delay-num" inputmode="decimal" autocomplete="off" spellcheck="false" aria-label="${o(a("music.tuning_delay"))}" />
            </div>
          </div>
          <div class="music-field hidden" id="music-tune-copy">
            <div class="music-copy-list" id="music-copy-list"></div>
            <div class="music-actions">
              <button type="button" class="music-btn" id="music-copy-add">${v.plus}${a("music.tuning_copy_add")}</button>
            </div>
          </div>
          <div class="music-field hidden" id="music-tune-conv">
            <label>${a("music.tuning_conv")}</label>
            <div class="music-hint" id="music-conv-path"></div>
            <div class="music-actions">
              <button type="button" class="music-btn" id="music-conv-pick">${o(a("music.tuning_conv_pick"))}</button>
              <button type="button" class="music-btn hidden" id="music-conv-clear">${o(a("music.tuning_conv_clear"))}</button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- ── 自定义队列的编辑小窗（2026-10-09 用户口径）：插件页面**正中的浮层** —
         一个名字输入框 + 一个「添加文件」按钮 + 已选文件清单 + 确定 / 取消。
         ⚠️ 本段在模板字符串里，注释里一个反引号都不能出现（预检 #15 / #39 ⑩）。 -->
    <div class="music-dlg-mask hidden" id="music-queue-dlg">
      <div class="music-dlg">
        <div class="music-dlg-title">${a("music.local_queue_dlg_title")}</div>
        <div class="music-field">
          <label for="music-queue-name">${a("music.local_queue_dlg_name")}</label>
          <input id="music-queue-name" type="text" spellcheck="false" autocomplete="off" placeholder="${o(a("music.local_queue_dlg_name_ph"))}">
        </div>
        <div class="music-queue-pickrow">
          <button type="button" class="music-btn" id="music-queue-pick">${v.plus} ${a("music.local_queue_pick")}</button>
          <span class="music-hint" id="music-queue-pick-hint">${o(a("music.local_queue_pick_hint"))}</span>
        </div>
        <div class="music-queue-files" id="music-queue-files"></div>
        <div class="music-actions">
          <button type="button" class="music-btn" id="music-queue-cancel">${a("music.local_queue_cancel")}</button>
          <button type="button" class="music-btn music-primary" id="music-queue-ok">${a("music.local_queue_ok")}</button>
        </div>
      </div>
    </div>

    <!-- ── 「删除本地文件」二次确认（2026-10-11 用户口径）：删除是**不可恢复**动作，
         所以走一扇居中确认卡（复用上面 #music-queue-dlg 那套 .music-dlg-mask 观感，
         **不用 window.confirm** —— WebView2 里那套原生框与本仓观感不一致）。
         文案动态填进 #music-del-text（带上曲目名、写明不可恢复）。
         ⚠️ 本段在模板字符串里，注释里一个反引号都不能出现（预检 #15 / #39 ⑩）。 -->
    <div class="music-dlg-mask hidden" id="music-del-dlg">
      <div class="music-dlg">
        <div class="music-dlg-title">${a("music.ctx_delete_title")}</div>
        <div class="music-del-text" id="music-del-text"></div>
        <div class="music-actions">
          <button type="button" class="music-btn" id="music-del-cancel">${a("music.ctx_delete_cancel")}</button>
          <button type="button" class="music-btn music-primary" id="music-del-ok">${a("music.ctx_delete_ok")}</button>
        </div>
      </div>
    </div>

    <!-- ── 歌曲行的**右键上下文菜单**（2026-10-11 用户第 4 条）：单例节点，在鼠标位置弹出
         （非居中模态）；点外部 / Esc 关闭。做法照桌宠窗那枚 pet-menu（静态节点 + open 类 +
         鼠标位置定位），不另造第二套观感。菜单项按上下文现填（见 openCtxMenu）。
         ⚠️ **必须长在「主插件窗」的 shell（这里）**：上一版误放进了 curveShellHtml
         （频响曲线窗）—— 而 curve 窗根本不挂 contextmenu 监听（attachMusicListeners 在
         isCurveWindow 时早退到 attachCurveWindow）⇒ 主窗里 openCtxMenu 永远
         querySelector 到 null、菜单不出（2026-10-11 用户报「右键呼不出来」的根因）。
         ⚠️ 本段在模板字符串里，注释里一个反引号都不能出现（预检 #15 / #39 ⑩）。 -->
    <div class="music-ctx" id="music-ctx"></div>

    <div class="music-msg" id="music-msg"></div>
  </div>`;
}
function M(t, e) {
  t && t.textContent !== e && (t.textContent = e);
}
function C(t, e) {
  if (!t || t.innerHTML === e) return;
  const i = document.createElement("template");
  i.innerHTML = e, t.innerHTML !== i.innerHTML && (t.innerHTML = e);
}
function A(t, e) {
  t == null || t.classList.toggle("hidden", !e);
}
function de(t, e, i) {
  t && t.getAttribute(e) !== i && t.setAttribute(e, i);
}
function oi(t, e) {
  if (!t) return;
  const i = Math.max(0, Math.min(100, Math.round(e)));
  t.style.setProperty("--vol-pct", `${i}%`);
}
function cu(t) {
  const e = t.querySelector("#music-msg");
  if (!e) return;
  const i = e.textContent ?? "";
  if (i !== ys) {
    ys = i, gs = Date.now();
    return;
  }
  i && Date.now() - gs >= Ic && (e.textContent = "", ys = "", gs = 0);
}
function ae(t) {
  const e = ui();
  A(t.querySelector("#music-v-default"), D === "default"), A(t.querySelector("#music-v-player"), D === "player"), A(t.querySelector("#music-v-lplayer"), D === "lplayer"), A(t.querySelector("#music-v-settings"), D === "settings");
  const i = D === "tuning";
  A(t.querySelector("#music-v-tuning"), i), i ? (Ct(t), Au(t)) : kn(), t.classList.toggle("music-player-on", e), lu(e), uu(), ti(t), mu(), D === "player" ? (Rt = -1, As(t), Bs(t)) : D === "lplayer" ? il(t) : D === "default" && (A(t.querySelector("#music-body"), !!(f != null && f.connected) || ie), Gt(t), Ie(t), et(t), ki(t)), D !== "default" && Ee && (Ee = !1, Lt(t)), ji(t);
}
function lu(t) {
  const e = !t;
  document.getElementById("plugin-titlebar") && ln !== e && (ln = e, d("plugin_window_set_resizable", { resizable: e }).catch(() => {
  }));
}
function uu() {
  const t = document.getElementById("plugin-close");
  if (!t) return;
  Oi || (Oi = t.innerHTML);
  const e = ui() ? "back" : "close";
  if (t.dataset.mode === e) return;
  t.dataset.mode = e, t.innerHTML = e === "back" ? v.back : Oi;
  const i = e === "back" ? a("music.back") : "Close";
  t.title = i, t.setAttribute("aria-label", i);
}
function ou() {
  const t = document.getElementById("plugin-close");
  !t || !Oi || t.dataset.mode !== "back" || (t.innerHTML = Oi, t.title = "Close", t.setAttribute("aria-label", "Close"), t.dataset.mode = "close");
}
function ru() {
  return D === "tuning" ? "tuning" : D !== "default" ? "" : ie ? "local" : "online";
}
function du(t) {
  const e = document.getElementById("music-tb-switch");
  if (e) return e;
  const i = document.createElement("div");
  i.id = "music-tb-switch", i.className = "music-tb-switch", i.setAttribute("role", "tablist"), i.setAttribute("data-tauri-drag-region", "");
  const s = [
    ["online", a("music.tb_online")],
    ["local", a("music.tb_local")],
    ["tuning", a("music.tb_tuning")]
  ];
  i.innerHTML = s.map(([r, p]) => `<button type="button" class="music-tb-seg" role="tab" data-seg="${r}" title="${o(p)}">${o(p)}</button>`).join("");
  const n = document.getElementById("plugin-titlebar"), c = document.getElementById("plugin-title");
  if (n && c)
    n.insertBefore(i, c.nextSibling);
  else {
    const r = t.querySelector("#music-setup-toggle"), p = t.querySelector(".music-toolbar");
    if (!p) return null;
    p.insertBefore(i, r);
  }
  return i;
}
function mu() {
  const t = document.getElementById("music-tb-switch");
  if (!t) return;
  const e = ru();
  for (const i of t.querySelectorAll(".music-tb-seg"))
    de(i, "aria-pressed", String(i.dataset.seg === e));
}
function pu() {
  var t;
  (t = document.getElementById("music-tb-switch")) == null || t.remove();
}
async function fu(t) {
  try {
    await d("spotify_control", { action: "pause" });
  } catch (e) {
    S(t, R(e));
  }
  D = "default", ae(t);
}
function Zi(t) {
  const e = t.querySelector("#music-local-qmode");
  e && (e.classList.toggle("on", U), de(e, "aria-pressed", U ? "true" : "false"));
  const i = t.querySelector("#music-scan-btn");
  i && (de(i, "title", a(U ? "music.local_queue_exit" : "music.local_rescan")), C(i, U ? v.x : v.refresh)), jc(t);
}
function jc(t) {
  const e = t.querySelector("#music-setup-toggle");
  e && (de(e, "title", a(U ? "music.local_queue_add_picked" : "music.settings")), C(e, U ? v.plus : v.gear));
}
function Xa(t) {
  const e = t.querySelector("#music-setup-toggle"), i = t.querySelector(".music-toolbar");
  e && i && e.parentElement !== i && i.appendChild(e);
}
function rn(t) {
  const e = t.querySelector("#music-setup-toggle"), i = t.querySelector(".music-toolbar");
  if (!e || !i) return;
  const s = ie ? t.querySelector(
    G === null ? "#music-local-page .music-local-head-row" : "#music-queue-page .music-local-head-row"
  ) : null;
  if (!s) {
    e.parentElement !== i && i.appendChild(e);
    return;
  }
  if (G === null) {
    const n = s.querySelector("#music-scan-btn");
    n ? e.previousElementSibling !== n && n.insertAdjacentElement("afterend", e) : e.parentElement !== s && s.appendChild(e);
  } else (e.parentElement !== s || e !== s.lastElementChild) && s.appendChild(e);
}
function Za(t, e, i, s) {
  const n = t.querySelector(e);
  n && n.classList.toggle("no-drawer", !s), A(t.querySelector(i), s);
}
function ec(t, e, i) {
  if (!t) return;
  const s = a(e);
  t.dataset.label !== s && (t.dataset.label = s, t.innerHTML = `${v.expand}<span>${o(s)}</span>`), de(t, "title", a(i));
}
function ti(t) {
  const e = D === "player", i = !!(f != null && f.connected);
  A(t.querySelector("#music-nowbar"), !e && i && !Pc());
  const s = We && i && O >= 0;
  Za(t, "#music-nowbar", "#music-b-drawer", s), Za(t, "#music-lnowbar", "#music-l-drawer", s), ec(t.querySelector("#music-b-drawer"), "music.drawer_local", "music.tb_local"), ec(t.querySelector("#music-l-drawer"), "music.drawer_online", "music.tb_online");
  for (const n of [".music-search-wrap", "#music-avatar", "#music-acc", "#music-status"])
    A(t.querySelector(n), !ie);
  rn(t), jc(t), t.querySelectorAll(".music-dual-btn").forEach((n) => n.classList.toggle("on", We));
}
function ii(t, e) {
  const i = t.querySelector("#music-status");
  f != null && f.client_id ? f.connected ? y ? y.active ? y.playing ? M(i, a("music.status_playing")) : M(i, a("music.status_paused")) : M(i, a("music.status_no_device")) : M(i, a("music.status_connecting")) : M(i, a("music.status_disconnected")) : M(i, a("music.status_unconfigured"));
  const s = t.querySelector("#music-avatar");
  if (s) {
    const c = f != null && f.connected && f.avatar || "";
    C(s, c ? `<img src="${o(c)}" alt="">` : "");
  }
  M(t.querySelector("#music-acc"), f != null && f.connected && f.display_name || "");
  const n = t.querySelector("#music-devices-btn");
  n && (de(n, "title", `${a("music.devices")}：${(y == null ? void 0 : y.device) || a("music.device_none")}`), n.classList.toggle("warn", !!(f != null && f.connected) && !(y != null && y.active)));
}
function Zt(t) {
  A(t.querySelector("#music-setup"), !(f != null && f.connected) || ps), A(t.querySelector("#music-body"), !!(f != null && f.connected) || ie), Gt(t), Ie(t), f != null && f.connected && (rl(t, we), ml(t));
  const e = ms ?? !(f != null && f.builtin);
  A(t.querySelector("#music-setup-fields"), e), A(t.querySelector("#music-save"), e);
  const i = t.querySelector("#music-fields-toggle");
  A(i, !!(f != null && f.builtin)), M(i, a(e ? "music.hide_fields" : "music.use_own_client_id")), M(
    t.querySelector("#music-setup-hint"),
    f != null && f.builtin ? a("music.setup_builtin") : a("music.setup_hint")
  );
  const s = t.querySelector("#music-client-id"), n = t.querySelector("#music-port"), c = t.querySelector("#music-librespot"), r = t.querySelector("#music-librespot-proxy");
  s && document.activeElement !== s && (s.value = (f == null ? void 0 : f.client_id) ?? ""), n && document.activeElement !== n && (n.value = String((f == null ? void 0 : f.port) ?? 8899)), c && document.activeElement !== c && (c.value = (f == null ? void 0 : f.librespot_path) ?? ""), r && document.activeElement !== r && (r.value = (f == null ? void 0 : f.librespot_proxy) ?? "");
  const p = Ti ?? (f == null ? void 0 : f.librespot_bitrate) ?? 320;
  for (const _ of t.querySelectorAll("#music-quality .music-seg-btn"))
    de(_, "aria-pressed", String(Number(_.dataset.q) === p));
  M(t.querySelector("#music-redirect"), (f == null ? void 0 : f.redirect_uri) ?? "");
}
function tc(t) {
  const e = a(`music.tk_${t}`);
  return e.startsWith("music.") ? t : e;
}
function ic(t) {
  return Number.isFinite(t) ? Math.min(2e4, Math.max(20, t)) : 1e3;
}
function sc(t) {
  return Number.isFinite(t) ? Math.min(24, Math.max(-24, t)) : 0;
}
function X(t, e = 3) {
  return t === void 0 || !Number.isFinite(t) ? "" : String(Math.round(t * 10 ** e) / 10 ** e);
}
function Ys(t, e) {
  return e === "freq_hz" ? X(t.freq_hz, 1) : e === "gain_db" ? X(t.gain_db ?? 0, 1) : e === "q" ? X(t.q ?? 0.707, 3) : "";
}
async function Ct(t) {
  let e;
  try {
    e = await d("player_tuning_get");
  } catch (i) {
    S(t, R(i));
    return;
  }
  JSON.stringify(e) !== JSON.stringify(b) && (b = e, $i(), ke = -1), await _u(), he(t);
}
function Qc(t) {
  const e = t.querySelector("#music-tune-measure");
  e && e.disabled !== $t && (e.disabled = $t), de(e, "aria-busy", String($t));
  const i = t.querySelector("#music-tune-probe-hint");
  if (!i) return;
  if ($t) {
    M(i, a("music.tuning_measuring"));
    return;
  }
  const s = rt;
  if (!s) {
    M(i, a("music.tuning_probe_hint"));
    return;
  }
  const n = (p, _) => {
    let L = 0, w = 0;
    for (let E = 0; E < p.length && E < _.length; E++)
      L += p[E] - _[E], w += 1;
    return w > 0 ? L / w : 0;
  }, c = n(s.chain_db ?? [], s.ref_db), r = n(s.db, s.chain_db ?? []);
  M(
    i,
    a("music.tuning_probe_result", {
      cov: String(Math.round(s.coverage * 100)),
      dev: `${c >= 0 ? "+" : ""}${c.toFixed(1)}`,
      sys: `${r >= 0 ? "+" : ""}${r.toFixed(1)}`,
      ms: String(s.elapsed_ms)
    })
  );
}
function vu(t) {
  if (!b) return;
  const e = b.user_presets ?? [], i = t.querySelector("#music-tuning-user-presets");
  i && C(
    i,
    e.map((r) => {
      const p = b.preset === r;
      return `<div class="music-preset-user" data-preset="${o(r)}" aria-pressed="${p}"><button type="button" class="music-preset-item" data-act="use">${o(r)}</button><button type="button" class="music-preset-icon" data-act="rename" title="${o(a("music.tuning_preset_rename"))}">✎</button><button type="button" class="music-preset-icon" data-act="delete" title="${o(a("music.tuning_preset_delete"))}">✕</button></div>`;
    }).join("")
  );
  const s = ot;
  if (A(t.querySelector("#music-tuning-preset-edit"), s !== null), !s) return;
  const n = s.mode === "delete";
  M(
    t.querySelector("#music-preset-edit-hint"),
    s.mode === "save" ? a("music.tuning_preset_save_prompt") : s.mode === "rename" ? a("music.tuning_preset_rename_prompt", { name: s.from }) : a("music.tuning_preset_delete_confirm", { name: s.name })
  );
  const c = t.querySelector("#music-preset-name");
  A(c, !n), c && c !== document.activeElement && c.value !== s.name && (c.value = s.name), M(
    t.querySelector("#music-preset-ok"),
    s.mode === "save" ? s.overwrite ? a("music.tuning_preset_overwrite") : a("music.tuning_preset_ok") : s.mode === "rename" ? a("music.tuning_preset_rename") : a("music.tuning_preset_delete")
  );
}
function hu(t) {
  return t === 0 ? a("music.tuning_slot_global") : Mc[t - 1] ?? `#${t}`;
}
function bu(t) {
  const e = t.querySelector("#music-tune-slots");
  e && C(
    e,
    Qt.map((i, s) => {
      const n = hu(s), c = i.filter((r) => r.on).length;
      return `<button type="button" class="music-seg-btn music-slot-btn" data-slot="${s}" aria-pressed="${s === Xe}" title="${o(n)}">${o(n)}<em>${c}</em></button>`;
    }).join("")
  );
}
function yu(t, e) {
  e === Xe || e < 0 || e >= Qt.length || (Xe = e, se = Qt[e], ke = -1, he(t));
}
function nc(t) {
  return Mc[t] ?? "#" + (t + 1);
}
function Uc(t) {
  const e = t.querySelector("#music-copy-list");
  if (!e) return;
  const i = Math.max(1, (b == null ? void 0 : b.channels) || 2);
  C(
    e,
    Ht.map((s, n) => {
      const c = (ee == null ? void 0 : ee.row) === n ? ee.side : null, r = (_) => c === _ ? `<div class="music-tune-menu">${Array.from({ length: i }, (L, w) => {
        const E = (_ === "from" ? s.from : s.to) === w;
        return `<button type="button" class="music-seg-btn" data-act="pick" data-i="${n}" data-side="${_}" data-ch="${w}" aria-pressed="${E}">${o(nc(w))}</button>`;
      }).join("")}</div>` : "", p = (_, L) => `<button type="button" class="music-tune-kind" data-act="menu" data-i="${n}" data-side="${_}" aria-expanded="${c === _}"><span>${o(nc(L))}</span>${v.chevron}</button>`;
      return `<div class="music-copy-row" data-i="${n}">
        ${p("from", s.from)}<span class="music-copy-arrow">→</span>${p("to", s.to)}
        <button type="button" class="music-tune-del" data-act="del" data-i="${n}" title="${o(a("music.tuning_del"))}">${v.trash}</button>
        ${r("from")}${r("to")}
      </div>`;
    }).join("")
  ), A(t.querySelector("#music-copy-empty"), Ht.length === 0);
}
function gu(t) {
  const e = Xe === 0;
  if (A(t.querySelector("#music-tune-delay"), e), A(t.querySelector("#music-tune-copy"), e), A(t.querySelector("#music-tune-conv"), e), !e || fi) return;
  const i = t.querySelector("#music-delay-num");
  i && document.activeElement !== i && i.value !== X(xe, 1) && (i.value = X(xe, 1));
  const s = t.querySelector("#music-delay-range");
  s && s.value !== String(xe) && (s.value = String(xe)), Uc(t), M(t.querySelector("#music-conv-path"), pi ?? a("music.tuning_conv_none")), A(t.querySelector("#music-conv-clear"), pi !== null);
}
function Ks(t, e, i, s) {
  const n = t.querySelector(e);
  n && n.value !== X(s, 1) && (n.value = X(s, 1));
  const c = t.querySelector(i);
  c && document.activeElement !== c && c.value !== X(s, 1) && (c.value = X(s, 1));
}
async function _u() {
  try {
    je = await d("player_tuning_ab_state");
  } catch {
    je = { a: !1, b: !1 };
  }
}
function es(t) {
  var s;
  for (const n of [1, 2]) {
    const c = t.querySelector(`#music-ab-pos${n}`);
    if (!c) continue;
    const r = vi[n - 1], p = r === "a" ? je.a : je.b;
    c.dataset.ab = r, c.textContent = qt ? String(n) : r.toUpperCase(), c.disabled = !p, c.classList.toggle("active", p && gn === r);
  }
  const e = t.querySelector("#music-ab-blind");
  e && (e.classList.toggle("active", qt), e.disabled = !(je.a && je.b)), (s = t.querySelector("#music-ab-reveal")) == null || s.classList.toggle("hidden", !qt || Ri);
  const i = t.querySelector("#music-ab-hint");
  i && (i.textContent = wu());
}
function wu() {
  return !je.a && !je.b ? a("music.tuning_ab_empty") : qt ? Ri ? a("music.tuning_ab_revealed", {
    one: vi[0].toUpperCase(),
    two: vi[1].toUpperCase()
  }) : a("music.tuning_ab_blind_hint") : a("music.tuning_ab_hint", {
    a: je.a ? "A" : "—",
    b: je.b ? "B" : "—"
  });
}
async function ac(t, e) {
  try {
    je = await d("player_tuning_ab_save", { slot: e }), S(t, a(e === "a" ? "music.tuning_ab_saved_a" : "music.tuning_ab_saved_b"));
  } catch (i) {
    S(t, R(i));
  }
  es(t);
}
async function ku(t, e) {
  const i = vi[e - 1];
  if (i) {
    try {
      await d("player_tuning_ab_apply", { slot: i }), gn = i, await Ct(t);
    } catch (s) {
      S(t, R(s));
    }
    es(t);
  }
}
function he(t) {
  b && (de(t.querySelector("#music-tuning-on"), "aria-checked", String(b.enabled)), Qc(t), vu(t), es(t), Ks(t, "#music-preamp-range", "#music-tune-preamp", Qi), Ks(t, "#music-bass-range", "#music-tune-bass", Ui), Ks(t, "#music-treble-range", "#music-tune-treble", Vi), bu(t), Vc(t), gu(t), Yc(t), M(
    t.querySelector("#music-tune-rate"),
    a("music.tuning_rate", { rate: X(b.response.sample_rate / 1e3, 1) })
  ));
}
function Su(t, e, i, s) {
  const n = i.find((z) => z.name === t.kind), c = n ? n.gain : t.gain_db !== void 0, r = n ? n.order !== 1 : t.q !== void 0, p = t.gain_db ?? 0, _ = `<input type="text" class="music-tune-num music-band-freq" data-f="freq_hz" inputmode="decimal" autocomplete="off" spellcheck="false" value="${o(X(t.freq_hz, 1))}" aria-label="${o(a("music.tuning_freq"))}" />`, L = c ? `<input type="range" class="music-tune-vslider" data-f="gain_db" min="-24" max="24" step="0.5" value="${o(X(p, 1))}" aria-label="${o(a("music.tuning_gain"))}" />` : '<div class="music-tune-vslider-na"></div>', w = c ? `<input type="text" class="music-tune-num music-band-gain" data-f="gain_db" inputmode="decimal" autocomplete="off" spellcheck="false" value="${o(X(p, 1))}" aria-label="${o(a("music.tuning_gain"))}" />` : '<span class="music-band-gain na">—</span>', E = r ? `<input type="text" class="music-tune-num music-band-q" data-f="q" inputmode="decimal" autocomplete="off" spellcheck="false" value="${o(X(t.q ?? 0.707, 3))}" aria-label="${o(a("music.tuning_q"))}" />` : "", T = s ? `<div class="music-tune-menu">${i.map(
    (z) => `<button type="button" class="music-seg-btn" data-act="pick" data-kind="${o(z.name)}" aria-pressed="${z.name === t.kind}">${o(tc(z.name))}</button>`
  ).join("")}</div>` : "";
  return `<div class="music-tune-band music-tune-row${t.on ? "" : " off"}" data-i="${e}">
      ${_}
      ${L}
      ${w}
      ${E}
      <div class="music-band-foot">
        <button type="button" class="music-tune-kind" data-act="kind" aria-expanded="${s}"><span>${o(tc(t.kind))}</span>${v.chevron}</button>
        <button type="button" class="music-tune-sw" data-act="on" aria-pressed="${t.on}" title="${o(t.on ? a("music.tuning_off") : a("music.tuning_on"))}">${v.power}</button>
        <button type="button" class="music-tune-del" data-act="del" title="${o(a("music.tuning_del"))}">${v.trash}</button>
      </div>
      ${T}
    </div>`;
}
function Vc(t) {
  if (fi) return;
  const e = t.querySelector("#music-tuning-filters");
  if (!e || !b || e.contains(document.activeElement)) return;
  const i = b.kinds;
  C(e, se.map((s, n) => Su(s, n, i, ke === n)).join(""));
}
function cc(t, e, i) {
  const s = yn;
  if (!s) return null;
  const n = t.getBoundingClientRect(), c = s.w / (n.width || s.w), r = s.h / (n.height || s.h), p = (e - n.left) * c, _ = (i - n.top) * r, L = Math.log10(20), w = Math.log10(2e4), E = (p - s.padL) / s.plotW, T = 10 ** (L + E * (w - L)), z = s.span - (_ - s.padT) / s.plotH * (2 * s.span);
  return { f: T, db: z, x: p, y: _ };
}
function Gc(t, e, i) {
  const s = Math.log10(20), n = Math.log10(2e4), c = t.padL + (Math.log10(Math.max(1, e)) - s) / (n - s) * t.plotW, r = t.padT + (t.span - i) / (2 * t.span) * t.plotH;
  return { x: c, y: r };
}
let si = 1;
function Yc(t) {
  const e = t.querySelector("#music-tune-canvas");
  e && (e.style.width = `${si * 100}%`), M(t.querySelector("#music-tune-zoom-label"), `${Math.round(si * 100)}%`), Ts(t);
}
function Ts(t) {
  var Ge;
  const e = t.querySelector("#music-tune-canvas");
  if (!e || !b) return;
  const i = e.clientWidth || e.width, s = e.clientHeight || e.height;
  if (i < 2 || s < 2) return;
  const n = window.devicePixelRatio || 1;
  (e.width !== Math.round(i * n) || e.height !== Math.round(s * n)) && (e.width = Math.round(i * n), e.height = Math.round(s * n));
  const c = e.getContext("2d");
  if (!c) return;
  c.setTransform(n, 0, 0, n, 0, 0), c.clearRect(0, 0, i, s);
  const r = getComputedStyle(t), p = r.getPropertyValue("--accent").trim() || "#7aa2f7", _ = r.getPropertyValue("--border-glass").trim() || "rgba(255,255,255,0.12)", L = r.getPropertyValue("--text-dim").trim() || "rgba(255,255,255,0.55)", { freqs: w } = b.response, E = Gl(), T = 30, z = 8, j = 8, be = 16, Ve = Math.max(1, i - T - z), Ne = Math.max(1, s - j - be);
  let Pe = 0;
  for (const x of E) Number.isFinite(x) && (Pe = Math.max(Pe, Math.abs(x)));
  for (const x of (rt == null ? void 0 : rt.db) ?? [])
    Number.isFinite(x) && (Pe = Math.max(Pe, Math.abs(x)));
  const ye = Math.min(60, Math.max(12, Math.ceil((Pe + 1) / 6) * 6)), nt = Math.log10(20), Li = Math.log10(2e4), bt = (x) => T + (Math.log10(Math.max(1, x)) - nt) / (Li - nt) * Ve, Oe = (x) => j + (ye - x) / (2 * ye) * Ne, yt = { w: i, h: s, padL: T, padT: j, plotW: Ve, plotH: Ne, span: ye };
  yn = yt, c.lineWidth = 1, c.font = "9px system-ui, -apple-system, sans-serif", c.textBaseline = "middle";
  for (const x of [ye, ye / 2, 0, -ye / 2, -ye])
    c.strokeStyle = _, c.globalAlpha = x === 0 ? 0.9 : 0.45, c.setLineDash(x === 0 ? [] : [3, 3]), c.beginPath(), c.moveTo(T, Oe(x)), c.lineTo(T + Ve, Oe(x)), c.stroke();
  c.setLineDash([]), c.fillStyle = L;
  for (const x of [20, 100, 1e3, 1e4, 2e4]) {
    const H = bt(x);
    c.globalAlpha = 0.45, c.strokeStyle = _, c.beginPath(), c.moveTo(H, j), c.lineTo(H, j + Ne), c.stroke(), c.globalAlpha = 0.9, c.textAlign = x === 20 ? "left" : x === 2e4 ? "right" : "center", c.fillText(x >= 1e3 ? `${x / 1e3}k` : String(x), H, j + Ne + 8);
  }
  c.textAlign = "right";
  for (const x of [ye, ye / 2, 0, -ye / 2, -ye])
    c.globalAlpha = 0.9, c.fillStyle = L, c.fillText(`${x > 0 ? "+" : ""}${X(x, 0)}`, T - 3, Oe(x));
  if (c.textAlign = "left", c.globalAlpha = 1, w.length >= 2 && E.length === w.length) {
    c.beginPath();
    for (let x = 0; x < w.length; x++) {
      const H = bt(w[x]), pe = Oe(E[x]);
      x === 0 ? c.moveTo(H, pe) : c.lineTo(H, pe);
    }
    c.lineTo(bt(w[w.length - 1]), Oe(0)), c.lineTo(bt(w[0]), Oe(0)), c.closePath(), c.globalAlpha = 0.12, c.fillStyle = p, c.fill(), c.globalAlpha = 1, c.beginPath();
    for (let x = 0; x < w.length; x++) {
      const H = bt(w[x]), pe = Oe(E[x]);
      x === 0 ? c.moveTo(H, pe) : c.lineTo(H, pe);
    }
    c.strokeStyle = p, c.lineWidth = 1.5, c.stroke();
  }
  const me = rt;
  if (me && me.freqs.length >= 2) {
    const x = r.getPropertyValue("--green").trim() || "#8fc99a", H = r.getPropertyValue("--blue").trim() || "#9490b4", pe = (Be, at, It, xi) => {
      if (!(Be.length < 2)) {
        c.save(), c.beginPath(), c.rect(T, j, Ve, Ne), c.clip(), c.beginPath();
        for (let Z = 0; Z < me.freqs.length && Z < Be.length; Z++) {
          const ct = bt(me.freqs[Z]), gt = Oe(Be[Z]);
          Z === 0 ? c.moveTo(ct, gt) : c.lineTo(ct, gt);
        }
        c.setLineDash(at), c.strokeStyle = It, c.lineWidth = xi, c.stroke(), c.setLineDash([]), c.restore();
      }
    };
    pe(me.db, [1.5, 3], H, 1.2), pe(me.chain_db ?? [], [5, 3], x, 1.5);
  }
  if (se.length > 0) {
    c.save(), c.font = "9px system-ui, -apple-system, sans-serif", c.textAlign = "center", c.textBaseline = "middle";
    for (let x = 0; x < se.length; x++) {
      const H = se[x], pe = ((Ge = b.kinds.find((xi) => xi.name === H.kind)) == null ? void 0 : Ge.gain) ?? H.gain_db !== void 0, { x: Be, y: at } = Gc(yt, H.freq_hz, pe ? H.gain_db ?? 0 : 0), It = x === Xt;
      c.globalAlpha = H.on ? 1 : 0.4, c.beginPath(), pe ? c.arc(Be, at, It ? 6 : 4.5, 0, Math.PI * 2) : (c.moveTo(Be, at - 5), c.lineTo(Be + 5, at + 3), c.lineTo(Be - 5, at + 3), c.closePath()), c.fillStyle = It ? p : "rgba(0,0,0,0.65)", c.fill(), c.strokeStyle = p, c.lineWidth = 1.5, c.stroke(), pe && x < 9 && (c.globalAlpha = 1, c.fillStyle = It ? "rgba(0,0,0,0.8)" : p, c.fillText(String(x + 1), Be, at + 0.5));
    }
    c.globalAlpha = 1, c.restore();
  }
}
function $u(t, e, i) {
  t.kind = e;
  const s = i.find((n) => n.name === e);
  s && (s.gain ? t.gain_db === void 0 && (t.gain_db = 0) : delete t.gain_db, s.order === 1 ? delete t.q : t.q === void 0 && (t.q = 0.707));
}
async function ce(t, e = !1) {
  var L, w, E;
  const i = ++ft, s = document.activeElement, n = (L = s == null ? void 0 : s.closest) == null ? void 0 : L.call(s, ".music-tune-row"), c = s instanceof HTMLInputElement && s.type === "text" ? s.dataset.f : void 0, r = n ? Number(n.dataset.i) : -1, p = s instanceof HTMLInputElement && s.type === "text" && !n ? s.id : "";
  let _;
  try {
    _ = await d("player_tuning_set_chain", {
      preampDb: Qi,
      // 低音 / 高音快捷增益：引擎不认识它们，宿主会追加成 low_shelf / high_shelf 两条。
      bassDb: Ui,
      trebleDb: Vi,
      // ⚠️ **全局槽 = `tuneSlotDrafts[0]`，不是 `tuneFilters`**（P5-2）：后者是「表正在编辑
      // 的那一份」，用户停在某个通道槽时它指的是那条声道 —— 拿它当全局发会把通道的段搬进全局。
      filters: Qt[0],
      // 新效果器全部**走草稿**（它们现在都有界面了：P5-3 图示均衡器 / P5-4 延迟 + 复制 + 卷积）。
      // 宿主那条命令的语义是「**覆盖整条链**」⇒ 少发一样就等于把它清掉。
      graphicEq: Rc,
      delayMs: xe,
      channelCopy: Ht,
      convolution: pi,
      // 通道段由**全部槽的草稿**拼（P5-2）—— 不是把宿主那份原样回传：用户这会儿
      // 可能正在某个通道槽里改，那份改动就在 `tuneSlotDrafts` 里。
      ifElse: Yl()
    });
  } catch (T) {
    if (i !== ft) return;
    S(t, R(T)), await Ct(t);
    return;
  }
  i === ft && (b = _, $i(), e || S(t, a("music.tuning_saved")), he(t), c && r >= 0 && r < se.length ? (w = t.querySelector(`.music-tune-row[data-i="${r}"] input[type="text"][data-f="${c}"]`)) == null || w.focus() : p && ((E = t.querySelector(`#${p}`)) == null || E.focus()));
}
async function qu(t, e) {
  const i = ++ft;
  let s;
  try {
    s = await d("player_tuning_set_enabled", { enabled: e });
  } catch (n) {
    if (i !== ft) return;
    S(t, R(n)), await Ct(t);
    return;
  }
  i === ft && (b = s, $i(), S(t, a("music.tuning_saved")), he(t));
}
async function Lu(t, e) {
  const i = ++ft;
  let s;
  try {
    s = await d("player_tuning_set", { enabled: !0, preset: e });
  } catch (n) {
    if (i !== ft) return;
    S(t, R(n)), await Ct(t);
    return;
  }
  i === ft && (b = s, $i(), ke = -1, rt = null, S(t, a("music.tuning_saved")), he(t));
}
async function lc(t) {
  var s;
  const e = ot;
  if (!e) return;
  const i = e.mode === "delete" ? e.name : (((s = t.querySelector("#music-preset-name")) == null ? void 0 : s.value) ?? "").trim();
  if (e.mode !== "delete" && !i) {
    S(t, a("music.tuning_preset_name_empty"));
    return;
  }
  try {
    e.mode === "save" ? (b = await d("player_tuning_preset_save", { name: i, overwrite: e.overwrite }), S(t, a("music.tuning_preset_saved", { name: i }))) : e.mode === "rename" ? (b = await d("player_tuning_preset_rename", { from: e.from, to: i }), S(t, a("music.tuning_preset_renamed", { name: i }))) : (b = await d("player_tuning_preset_delete", { name: i }), S(t, a("music.tuning_preset_deleted", { name: i }))), ot = null, $i(), he(t);
  } catch (n) {
    const c = R(n);
    if (c.includes("ERR_PRESET_EXISTS")) {
      e.mode === "save" ? (ot = { mode: "save", name: i, overwrite: !0 }, he(t)) : S(t, a("music.tuning_preset_exists", { name: i }));
      return;
    }
    S(t, c);
  }
}
async function xu(t) {
  let e;
  try {
    e = await is({
      multiple: !1,
      filters: [{ name: "Lunac preset", extensions: ["json"] }]
    });
  } catch (i) {
    S(t, R(i));
    return;
  }
  if (typeof e == "string")
    try {
      b = await d("player_tuning_preset_import", { path: e }), $i(), ke = -1, rt = null, he(t), S(t, a("music.tuning_preset_imported", { name: b.preset }));
    } catch (i) {
      S(t, R(i));
    }
}
async function Eu(t) {
  let e;
  try {
    e = await is({
      multiple: !1,
      filters: [{ name: "WAV", extensions: ["wav"] }]
    });
  } catch (i) {
    S(t, R(i));
    return;
  }
  typeof e == "string" && (pi = e, await ce(t));
}
async function Tu(t) {
  if (!b) return;
  const e = b.preset && b.preset !== "custom" ? b.preset : "lunac-chain";
  let i;
  try {
    i = await El({
      defaultPath: `${e}.json`,
      filters: [{ name: "Lunac preset", extensions: ["json"] }]
    });
  } catch (s) {
    S(t, R(s));
    return;
  }
  if (typeof i == "string")
    try {
      await d("player_tuning_preset_export", { path: i }), S(t, a("music.tuning_preset_exported", { path: i }));
    } catch (s) {
      S(t, R(s));
    }
}
function _s(t) {
  const e = Date.now();
  if (e - fs >= 120) {
    fs = e, ce(t, !0);
    return;
  }
  Us == null && (Us = window.setTimeout(() => {
    Us = null, fs = Date.now(), ce(t, !0);
  }, 120));
}
function Js(t) {
  ls != null && window.clearTimeout(ls), ls = window.setTimeout(() => {
    ls = null, ce(t);
  }, Ul);
}
async function Mu(t) {
  if (!$t) {
    $t = !0, Qc(t);
    try {
      rt = await d("player_tuning_measure");
    } catch (e) {
      S(t, R(e));
    } finally {
      $t = !1, he(t);
    }
  }
}
function Cu(t) {
  const e = t.querySelector("#music-tune-canvas");
  if (!e) return;
  const i = (n, c, r) => {
    var T;
    const p = cc(n, c, r), _ = yn;
    if (!p || !_) return null;
    let L = -1, w = 14;
    for (let z = 0; z < se.length; z++) {
      const j = se[z], be = ((T = b == null ? void 0 : b.kinds.find((Pe) => Pe.name === j.kind)) == null ? void 0 : T.gain) ?? j.gain_db !== void 0, Ve = Gc(_, j.freq_hz, be ? j.gain_db ?? 0 : 0), Ne = Math.hypot(Ve.x - p.x, Ve.y - p.y);
      Ne < w && (w = Ne, L = z);
    }
    const E = p.x >= _.padL - 6 && p.x <= _.padL + _.plotW + 6 && p.y >= _.padT - 6 && p.y <= _.padT + _.plotH + 6;
    return { p, idx: L, inside: E };
  };
  e.addEventListener("pointerdown", (n) => {
    const c = n.currentTarget, r = i(c, n.clientX, n.clientY);
    if (!r) return;
    let p = r.idx;
    Ei = !1, !(p < 0 && !r.inside) && (p < 0 && (se.push({
      kind: "peaking",
      freq_hz: ic(r.p.f),
      gain_db: sc(r.p.db),
      q: 0.707,
      on: !0
    }), p = se.length - 1, ke = -1, Ei = !0), Xt = p, fi = !0, c.setPointerCapture(n.pointerId), Ts(t), n.preventDefault());
  }), e.addEventListener("pointermove", (n) => {
    var E;
    if (Xt < 0) return;
    const c = n.currentTarget, r = se[Xt], p = cc(c, n.clientX, n.clientY);
    if (!r || !p) return;
    const _ = ((E = b == null ? void 0 : b.kinds.find((T) => T.name === r.kind)) == null ? void 0 : E.gain) ?? r.gain_db !== void 0, L = ic(p.f), w = sc(p.db);
    (L !== r.freq_hz || _ && w !== r.gain_db) && (Ei = !0), r.freq_hz = L, _ && (r.gain_db = w), Ts(t), _s(t), n.preventDefault();
  });
  const s = (n) => {
    var p;
    if (Xt < 0) return;
    const c = n.currentTarget, r = Ei;
    Xt = -1, Ei = !1, fi = !1, (p = c.hasPointerCapture) != null && p.call(c, n.pointerId) && c.releasePointerCapture(n.pointerId), fs = 0, r && ce(t);
  };
  e.addEventListener("pointerup", s), e.addEventListener("pointercancel", s);
}
function Kc(t) {
  var s, n, c, r, p;
  (s = t.querySelector("#music-tune-measure")) == null || s.addEventListener("click", () => {
    Mu(t);
  });
  const e = (_, L) => {
    const w = t.querySelector("#music-tune-scroll"), E = t.querySelector("#music-tune-canvas");
    if (!w || !E) return;
    const T = E.getBoundingClientRect(), z = T.width > 0 ? (_ - T.left) / T.width : 0.5, j = Math.min(3, Math.max(1, Math.round(L * 100) / 100));
    if (j === si) return;
    si = j, Yc(t);
    const be = E.getBoundingClientRect();
    w.scrollLeft += be.left + z * be.width - _;
  }, i = (_) => {
    const L = t.querySelector("#music-tune-scroll");
    if (!L) return;
    const w = L.getBoundingClientRect();
    e(w.left + w.width / 2, si + _);
  };
  (n = t.querySelector("#music-tune-zoom-in")) == null || n.addEventListener("click", () => i(0.25)), (c = t.querySelector("#music-tune-zoom-out")) == null || c.addEventListener("click", () => i(-0.25)), (r = t.querySelector("#music-tune-scroll")) == null || r.addEventListener(
    "wheel",
    (_) => {
      _.preventDefault(), e(_.clientX, si + (_.deltaY < 0 ? 0.2 : -0.2));
    },
    { passive: !1 }
  ), Cu(t), (p = t.querySelector("#music-tune-slots")) == null || p.addEventListener("click", (_) => {
    const L = _.target.closest("[data-slot]");
    L && yu(t, Number(L.dataset.slot));
  });
}
let Fi;
const uc = 1200;
function dn() {
  Fi !== void 0 && (window.clearTimeout(Fi), Fi = void 0);
}
let ri;
const oc = 1200;
function kn() {
  ri !== void 0 && (window.clearTimeout(ri), ri = void 0);
}
function Au(t) {
  if (ri !== void 0) return;
  const e = async () => {
    if (!t.isConnected || D !== "tuning") {
      kn();
      return;
    }
    await Ct(t), t.isConnected && D === "tuning" && (ri = window.setTimeout(() => void e(), oc));
  };
  ri = window.setTimeout(() => void e(), oc);
}
async function Iu(t) {
  dn(), rt = null, $t = !1, Kc(t), await Ct(t);
  const e = async () => {
    if (!t.isConnected) {
      dn();
      return;
    }
    await Ct(t), t.isConnected && (Fi = window.setTimeout(() => void e(), uc));
  };
  Fi = window.setTimeout(() => void e(), uc);
}
async function Du(t) {
  try {
    await d("open_plugin_window", { pluginId: "music", key: Ec, input: "" });
  } catch (e) {
    S(t, R(e));
  }
}
function Ru(t) {
  var e;
  return !!t.uri && ((e = y == null ? void 0 : y.track) == null ? void 0 : e.uri) === t.uri;
}
function At(t, e) {
  const i = t == null ? void 0 : t.querySelector("#music-msg");
  !i || i.textContent === e || (i.textContent = e, St !== void 0 && (window.clearTimeout(St), St = void 0), e && (St = window.setTimeout(() => {
    i.textContent = "", St = void 0;
  }, Ic)));
}
function S(t, e) {
  At(t, e);
}
function Rs(t, e, i, s = "", n = "") {
  const c = Kt[i], r = !!c && F[c].ids.has(t.uri);
  return `<button class="music-tr${Ru(t) ? " playing" : ""}${r ? " sel" : ""}" data-act="${i}" data-uri="${o(t.uri)}"${s ? ` data-i="${o(s)}"` : ""}${n ? ` title="${o(n)}"` : ""}>
    <span class="music-tr-i">${e + 1}</span>
    <span class="music-tr-main">
      <span class="music-tr-n">${o(t.name || "?")}</span>
      <span class="music-tr-a">${o(t.artists || t.album)}</span>
    </span>
    <span class="music-tr-d">${Wi(t.duration_ms)}</span>
  </button>`;
}
function Ns(t) {
  return { id: t.id, uri: t.uri, name: t.name, cover: t.cover, subtitle: t.owner, total: t.total };
}
function ws(t, e) {
  const i = !!e.uri && (y == null ? void 0 : y.context_uri) === e.uri, s = (I == null ? void 0 : I.kind) === t && I.id === e.id, n = e.cover ? `<img src="${o(e.cover)}" alt="">` : "";
  return `<div class="music-pl${i ? " playing" : ""}${s ? " on" : ""}" data-uri="${o(e.uri)}">
    <button class="music-pl-btn" data-act="open" data-kind="${t}" data-id="${o(e.id)}" title="${o(e.name || "?")}">
      <span class="music-pl-cover">${n}</span>
      <span class="music-pl-main">
        <span class="music-pl-name">${o(e.name || "?")}</span>
        <span class="music-pl-sub">${o(e.subtitle)}</span>
      </span>
    </button>
  </div>`;
}
function Nu() {
  return `<div class="music-pl${(I == null ? void 0 : I.kind) === "top-tracks" ? " on" : ""}">
    <button class="music-pl-btn" data-act="open" data-kind="top-tracks" data-id="top-tracks" title="${o(a("music.top_tracks"))}">
      <span class="music-pl-cover music-pl-trend-cover">${v.trend}</span>
      <span class="music-pl-main">
        <span class="music-pl-name">${o(a("music.top_tracks"))}</span>
        <span class="music-pl-sub">${o(a("music.top_tracks_sub"))}</span>
      </span>
    </button>
  </div>`;
}
function Pu(t, e) {
  const i = e.cover ? `<img src="${o(e.cover)}" alt="">` : "";
  return `<button class="music-card" data-act="open" data-kind="${t}" data-id="${o(e.id)}" title="${o(e.name)}">
    <span class="music-card-cover${t === "artist" ? " round" : ""}">${i}</span>
    <span class="music-card-n">${o(e.name)}</span>
    <span class="music-card-s">${o(e.subtitle)}</span>
  </button>`;
}
function Ou() {
  const t = (I == null ? void 0 : I.kind) === "liked", e = J ? String(J.total) : "", i = Wt || [(f == null ? void 0 : f.display_name) || "", e].filter(Boolean).join(" · ");
  return `<div class="music-pl music-pl-liked${t ? " on" : ""}${Wt ? " err" : ""}">
    <button class="music-pl-btn" data-act="open" data-kind="liked" data-id="liked" title="${o(a("music.liked_songs"))}">
      <span class="music-pl-cover music-pl-liked-cover">${v.heart}</span>
      <span class="music-pl-main">
        <span class="music-pl-name">${o(a("music.liked_songs"))}</span>
        <span class="music-pl-sub">${o(i)}</span>
      </span>
    </button>
  </div>`;
}
function Gt(t) {
  if (ie) {
    De(t);
    return;
  }
  A(t.querySelector("#music-side-tabs"), !0), A(t.querySelector("#music-local-head"), !1), t.querySelectorAll("#music-side-tabs .music-tab").forEach((c) => {
    c.classList.toggle("on", c.dataset.tab === we);
  });
  const e = t.querySelector("#music-side-list");
  if (!e) return;
  if (!(f != null && f.connected)) {
    C(e, `<div class="music-empty">${a("music.playlists_login")}</div>`);
    return;
  }
  const i = bi.get(we), s = Gi.get(we);
  let n = we === "playlist" ? Ou() : we === "top" ? Nu() : "";
  Ni.has(we) ? n += `<div class="music-empty">${a("music.loading")}</div>` : s ? n += `<div class="music-empty music-empty-err">${o(s)}</div>` : i && (n += i.length === 0 ? `<div class="music-empty">${a(we === "playlist" ? "music.playlists_empty" : "music.lib_empty")}</div>` : i.map((c) => ws(we, c)).join("")), C(e, n);
}
function Xs(t) {
  t.querySelectorAll("#music-side-list .music-pl").forEach((e) => {
    const i = e.querySelector(".music-pl-btn"), s = !!I && (i == null ? void 0 : i.dataset.kind) === I.kind && (i == null ? void 0 : i.dataset.id) === I.id;
    e.classList.toggle("on", s);
  });
}
function Ie(t) {
  if (ie) {
    jt(t);
    return;
  }
  const e = t.querySelector("#music-main");
  if (!e) return;
  if (kt && Qe) {
    C(e, Bu());
    return;
  }
  if (!I) {
    C(e, `<div class="music-empty">${f != null && f.connected ? a("music.pick_hint") : a("music.playlists_login")}</div>`);
    return;
  }
  const i = I.cover ? `<img src="${o(I.cover)}" alt="">` : "", s = I.kind === "liked" ? a("music.liked_songs") : I.kind === "top-tracks" ? a("music.top_tracks") : I.kind === "playlist" ? a("music.playlists") : I.kind === "album" ? a("music.tab_albums") : I.kind === "artist" ? a("music.tab_artists") : I.kind === "top" ? a("music.tab_top") : a("music.tab_shows");
  let n;
  ai ? n = `<div class="music-empty">${a("music.loading")}</div>` : vt ? n = `<div class="music-empty music-empty-err">${o(vt)}</div>` : !Me || Me.length === 0 ? n = `<div class="music-empty">${a("music.playlist_empty")}</div>` : n = Me.map((c, r) => Rs(c, r, "main-track", String(r))).join(""), C(e, `<div class="music-page">
    <div class="music-page-head">
      <span class="music-page-cover${I.kind === "artist" ? " round" : ""}">${i}</span>
      <div class="music-page-info">
        <span class="music-page-kind">${o(s)}</span>
        <span class="music-page-name">${o(I.name || "?")}</span>
        <span class="music-page-sub">${o(I.subtitle)}</span>
        <div class="music-page-actions">
          <button class="music-btn music-primary" data-act="main-play-all">${v.play} ${a("music.play_all")}</button>
        </div>
      </div>
    </div>
    <div class="music-list">${n}</div>
  </div>`);
}
function Bu() {
  const t = Q, i = [
    ["tracks", a("music.tracks")],
    ["artists", a("music.tab_artists")],
    ["albums", a("music.tab_albums")],
    ["playlists", a("music.playlists")],
    ["shows", a("music.tab_shows")]
  ].map(([n, c]) => `<button class="music-tab${Ke === n ? " on" : ""}" data-act="search-tab" data-tab="${n}">${o(c)}</button>`).join("");
  let s;
  if (hi || !t)
    s = `<div class="music-empty">${a("music.loading")}</div>`;
  else if (Ke === "tracks")
    s = t.tracks.length ? t.tracks.map((n, c) => Rs(n, c, "main-track", String(c))).join("") : `<div class="music-empty">${a("music.search_empty")}</div>`;
  else {
    const c = (Ke === "artists" ? t.artists : Ke === "albums" ? t.albums : Ke === "shows" ? t.shows : t.playlists.map(Ns)).map((r) => Pu(Ke === "playlists" ? "playlist" : Ke === "artists" ? "artist" : Ke === "albums" ? "album" : "show", r));
    s = c.length ? `<div class="music-grid">${c.join("")}</div>` : `<div class="music-empty">${a("music.search_empty")}</div>`;
  }
  return `<div class="music-page">
    <div class="music-page-info music-page-info-flat">
      <span class="music-page-kind">${a("music.search_result")}</span>
      <span class="music-page-name">${o(Qe)}</span>
    </div>
    <div class="music-tabs">${i}</div>
    <div class="music-list">${s}</div>
  </div>`;
}
function et(t) {
  const e = t.querySelector("#music-search-dd");
  if (!e) return;
  const i = !!(f != null && f.connected) && ze && !!Qe;
  if (A(e, i), !i) return;
  if (!Q) {
    C(e, hi ? `<div class="music-empty">${a("music.loading")}</div>` : "");
    return;
  }
  const s = Q, n = [];
  s.tracks.slice(0, 3).forEach((c, r) => n.push(Rs(c, r, "dd-track"))), s.artists.slice(0, 2).forEach((c) => n.push(ws("artist", c))), s.albums.slice(0, 2).forEach((c) => n.push(ws("album", c))), s.playlists.slice(0, 2).forEach((c) => n.push(ws("playlist", Ns(c)))), n.length || n.push(`<div class="music-empty">${a("music.search_empty")}</div>`), n.push(`<button class="music-dd-all" data-act="search-all">${a("music.search_all")}</button>`), C(e, n.join(""));
}
function ki(t) {
  const e = t.querySelector("#music-dev-dd");
  if (!e || (A(e, ut), !ut)) return;
  const i = le;
  let s = `<div class="music-dd-head">${a("music.devices")}</div>`;
  i != null && i.available && !i.has_credentials ? s += `<button class="music-dev-row" data-act="local-login">
      <span class="music-dev-ico">${v.power}</span>
      <span class="music-dev-main">
        <span class="music-dev-n">${a("music.local_login")}</span>
        <span class="music-dev-s">${a("music.local_login_hint")}</span>
      </span>
    </button>` : i != null && i.available ? s += `<button class="music-dev-row${i.running ? " on" : ""}" data-act="local-toggle">
      <span class="music-dev-ico">${v.power}</span>
      <span class="music-dev-main">
        <span class="music-dev-n">${a("music.local_play")}</span>
        <span class="music-dev-s">${o(i.path || "")}</span>
      </span>
    </button>` : s += `<div class="music-dev-row disabled">
      <span class="music-dev-ico">${v.power}</span>
      <span class="music-dev-main">
        <span class="music-dev-n">${a("music.local_play")}</span>
        <span class="music-dev-s">${a("music.local_no_exe")}</span>
      </span>
    </div>`;
  const n = Ut ?? [];
  s += n.length ? n.map((c) => `<button class="music-dev-row${c.active ? " on" : ""}" data-act="dev-pick" data-id="${o(c.id)}">
        <span class="music-dev-ico">${v.speaker}</span>
        <span class="music-dev-main">
          <span class="music-dev-n">${o(c.name || "?")}</span>
          <span class="music-dev-s">${o(c.kind)}</span>
        </span>
      </button>`).join("") : `<div class="music-empty">${a("music.device_none")}</div>`, C(e, s);
}
function zu(t) {
  var s;
  const e = (y == null ? void 0 : y.context_uri) ?? "", i = ((s = y == null ? void 0 : y.track) == null ? void 0 : s.uri) ?? "";
  t.querySelectorAll(".music-pl").forEach((n) => {
    n.classList.toggle("playing", !!e && n.dataset.uri === e);
  }), t.querySelectorAll(".music-tr").forEach((n) => {
    n.classList.toggle("playing", !!i && n.dataset.uri === i);
  });
}
function Hu(t) {
  if (!t) return "";
  const e = new Date(t), i = (s) => String(s).padStart(2, "0");
  return `${e.getFullYear()}-${i(e.getMonth() + 1)}-${i(e.getDate())} ${i(e.getHours())}:${i(e.getMinutes())}`;
}
function mn(t) {
  te && (He = !1);
  const e = (i, s) => A(t.querySelector(i), s);
  e("#music-local-add", !te), e("#music-local-list", !te), e("#music-local-del", te), e("#music-local-editdone", te), Zi(t), Ci(t);
}
function Ci(t) {
  const e = t.querySelector("#music-local-add-dd");
  e && (A(e, He), He && C(e, `
    <div class="music-dd-head">${o(a("music.local_add_head"))}</div>
    <button class="music-dev-row" data-act="media-add-dir">
      <span class="music-dev-ico">${v.folder}</span>
      <span class="music-dev-main">
        <span class="music-dev-n">${o(a("music.local_add_dir"))}</span>
        <span class="music-dev-s">${o(a("music.local_add_dir_hint"))}</span>
      </span>
    </button>
    <button class="music-dev-row" data-act="media-add-list">
      <span class="music-dev-ico">${v.list}</span>
      <span class="music-dev-main">
        <span class="music-dev-n">${o(a("music.local_open_playlist"))}</span>
        <span class="music-dev-s">${o(a("music.local_add_list_hint"))}</span>
      </span>
    </button>`));
}
function Wu(t) {
  const e = t.missing ? a("music.local_missing") : [
    a("music.local_n_tracks", { n: String(t.tracks) }),
    t.last_scan_at ? Hu(t.last_scan_at) : a("music.local_never_scanned")
  ].join(" · "), i = te && ve.has(t.path);
  return `<div class="music-pl${Ue === t.path ? " on" : ""}${t.missing ? " err" : ""}${i ? " sel" : ""}">
    <button class="music-pl-btn" data-act="media-root" data-path="${o(t.path)}" title="${o(t.path)}">
      <span class="music-pl-cover music-pl-dir">${v.folder}</span>
      <span class="music-pl-main">
        <span class="music-pl-name">${o(t.name || t.path)}</span>
        <span class="music-pl-sub">${o(e)}</span>
      </span>
    </button>
  </div>`;
}
function De(t) {
  A(t.querySelector("#music-side-tabs"), !1), A(t.querySelector("#music-local-head"), !0), mn(t);
  const e = t.querySelector("#music-side-list");
  if (!e) return;
  const i = (ne ?? []).filter((c) => !Yi.has(c.path)), s = i.reduce((c, r) => c + r.tracks, 0);
  let n = `<div class="music-pl${Ue === "" ? " on" : ""}">
    <button class="music-pl-btn" data-act="media-root" data-path="" title="${o(a("music.local_all"))}">
      <span class="music-pl-cover music-pl-dir">${v.note}</span>
      <span class="music-pl-main">
        <span class="music-pl-name">${o(a("music.local_all"))}</span>
        <span class="music-pl-sub">${o(a("music.local_n_tracks", { n: String(s) }))}</span>
      </span>
    </button>
  </div>`;
  Es ? n += `<div class="music-empty">${a("music.loading")}</div>` : yi ? n += `<div class="music-empty music-empty-err">${o(yi)}</div>` : ne && i.length === 0 ? n += `<div class="music-empty">${o(a("music.local_no_roots"))}</div>` : ne && (n += i.map((c) => Wu(c)).join("")), n += ju(), C(e, n);
}
function Fu(t) {
  const e = t.id === G, i = te && F.queueList.ids.has(t.id), s = t.name || a("music.local_queue_edit");
  return `<div class="music-pl${e ? " on" : ""}${i ? " sel" : ""}">
    <button class="music-pl-btn" data-act="local-queue" data-qid="${o(t.id)}" title="${o(s)}">
      <span class="music-pl-cover music-pl-dir">${v.list}</span>
      <span class="music-pl-main">
        <span class="music-pl-name">${o(s)}</span>
        <span class="music-pl-sub">${o(a("music.local_n_tracks", { n: String(t.items.length) }))}</span>
      </span>
    </button>
  </div>`;
}
function ju() {
  const t = Ae.filter((e) => !mt.has(e.id)).map(Fu).join("");
  return `<div class="music-lqs">
    <div class="music-lqs-head">${o(a("music.local_queue_edit"))}</div>
    ${t}
  </div>`;
}
function Sn(t, e, i = "local-track") {
  const s = t.cover ? `<img src="${o(Is(t.cover))}" alt="">` : `<span class="music-mt-ico">${v.note}</span>`, n = [t.artist, t.album].filter(Boolean).join(" · "), c = !!($ != null && $.active) && $.path === t.path, r = Kt[i], p = !!r && F[r].ids.has(t.path), w = (i === "local-track" || i === "queue-track") && (U || te && G !== null) ? `<span class="music-mt-i music-mt-check${p ? " on" : ""}">${p ? v.check : ""}</span>` : `<span class="music-mt-i">${e + 1}</span>`, E = `<button class="music-mt${c ? " playing" : ""}${p ? " sel" : ""}" data-act="${i}" data-i="${e}" data-path="${o(t.path)}" title="${o(t.path)}">
    ${w}
    <span class="music-mt-cover">${s}</span>
    <span class="music-mt-main">
      <span class="music-mt-n">${o(t.title || "?")}</span>
      <span class="music-mt-a">${o(n)}</span>
    </span>
    <span class="music-mt-d">${Wi(t.duration_ms)}</span>
  </button>`;
  if (i !== "queue-play") return E;
  const T = a("music.play_queue_remove");
  return `<div class="music-mt-wrap">${E}<button type="button" class="music-mt-x" data-act="queue-remove" data-i="${e}" title="${o(T)}" aria-label="${o(T)}">${v.x}</button></div>`;
}
function jt(t) {
  const e = t.querySelector("#music-main");
  if (!e) return;
  if (G !== null) {
    e.querySelector("#music-queue-page") || (Xa(t), e.innerHTML = Gu());
    const s = t.querySelector("#music-lq-q");
    s && s.value !== Je && (s.value = Je), Ps(t), rn(t), Zi(t);
    return;
  }
  e.querySelector("#music-local-page") || (Xa(t), e.innerHTML = `<div class="music-local-page" id="music-local-page">
      ${Jc("library")}
      <div class="music-scan hidden" id="music-scan"></div>
      <!-- 视频的**画面层**（2026-10-01 用户第 8 条）。里面那个 video 元素由
           renderLocalVideo 现造现拆（离开 / 换曲时整块清掉，见那里的注释）。
           注：本段在模板字符串里，注释里一个反引号都不能出现（预检 #15 / #39 ⑩）。 -->
      <div class="music-video hidden" id="music-video"></div>
      <div class="music-list" id="music-mt-list"></div>
    </div>`), A(t.querySelector("#music-mt-q"), !Te);
  const i = t.querySelector("#music-list-chip");
  A(i, !!Te), Te && M(
    t.querySelector("#music-list-chip-n"),
    `${Te.name} · ${a("music.local_n_tracks", { n: String((P == null ? void 0 : P.total) ?? 0) })}`
  ), Qu(t), tl(t), pn(t), rn(t), Zi(t);
}
function Qu(t) {
  const e = t.querySelector("#music-scan");
  if (!e) return;
  const i = ci;
  let s = "";
  if (i != null && i.running) {
    const n = i.total, c = n > 0 ? Math.min(100, Math.round(i.scanned / n * 100)) : 0, r = n > 0 ? a("music.local_scanning", { a: String(i.scanned), b: String(n) }) : a("music.local_scanning_n", { a: String(i.scanned) });
    s = `<div class="music-scan-row">
      <span class="music-scan-bar"><span class="music-scan-fill" style="width:${c}%"></span></span>
      <span class="music-scan-txt">${o(r)}</span>
    </div>`;
  } else i != null && i.error ? s = `<div class="music-scan-row music-scan-err">${o(i.error)}</div>` : i != null && i.done_at && (s = `<div class="music-scan-row music-scan-done">${o(a("music.local_scan_done", {
    added: String(i.added),
    updated: String(i.updated),
    removed: String(i.removed),
    failed: String(i.failed)
  }))}</div>`);
  C(e, s), A(e, !!s);
}
function pn(t) {
  const e = t.querySelector("#music-mt-list");
  if (!e) return;
  let i;
  gi ? i = `<div class="music-empty">${a("music.loading")}</div>` : Mt ? i = `<div class="music-empty music-empty-err">${o(Mt)}</div>` : !Te && ne && ne.length === 0 ? i = `<div class="music-empty">${o(a("music.local_add_hint"))}</div>` : !P || P.items.length === 0 ? i = `<div class="music-empty">${o(a(Te ? "music.local_list_empty" : "music.local_empty"))}</div>` : (i = P.items.map((s, n) => Sn(s, n)).join(""), P.total > P.items.length && (i += `<div class="music-empty">${o(a("music.local_more", {
    a: String(P.items.length),
    b: String(P.total)
  }))}</div>`)), C(e, i), $n(t);
}
const Uu = [
  "mp3",
  "flac",
  "m4a",
  "m4b",
  "mp4",
  "aac",
  "ogg",
  "oga",
  "opus",
  "spx",
  "wav",
  "wave",
  "aif",
  "aiff",
  "aifc",
  "ape",
  "wv",
  "mpc",
  "m4v",
  "mov"
];
function Vu(t) {
  const e = t.split(/[\\/]/).pop() || t, i = e.lastIndexOf(".");
  return {
    path: t,
    title: i > 0 ? e.slice(0, i) : e,
    artist: "",
    album: "",
    duration_ms: 0,
    cover: "",
    ext: i > 0 ? e.slice(i + 1).toLowerCase() : "",
    size: 0
  };
}
function $n(t) {
  if (!li) return;
  const e = t.querySelector("#music-main");
  if (!e) return;
  const i = Array.from(e.querySelectorAll(".music-mt")).find((c) => c.dataset.path === li);
  if (!i) return;
  const n = i.getBoundingClientRect().top - e.getBoundingClientRect().top + e.scrollTop - Math.max(0, (e.clientHeight - i.clientHeight) / 2);
  e.scrollTop = Math.max(0, n), li = "";
}
function Jc(t) {
  const e = t === "queue", i = e ? `<input class="music-local-q" id="music-lq-q" type="search" autocomplete="off" spellcheck="false"
             placeholder="${o(a("music.local_filter_ph"))}" value="${o(Je)}">` : `<input class="music-local-q" id="music-mt-q" type="search" autocomplete="off" spellcheck="false"
             placeholder="${o(a("music.local_filter_ph"))}" value="${o(Ki)}">`, s = e ? "" : `<span class="music-list-chip hidden" id="music-list-chip">
          <span class="music-list-chip-n" id="music-list-chip-n"></span>
          <button class="music-pl-x" data-act="media-list-close" title="${o(a("music.local_close_playlist"))}">${v.x}</button>
        </span>`, n = e ? "" : `<button class="music-ghost-btn music-icon-btn music-local-qmode" id="music-local-qmode" data-act="qmode" aria-pressed="false" title="${o(a("music.local_queue_edit"))}">${v.list}</button>`;
  return `<div class="music-local-head-row">
        ${i}
        ${s}
        <button class="music-ghost-btn music-icon-btn" id="music-scan-btn" data-act="media-scan" title="${o(a("music.local_rescan"))}">${v.refresh}</button>
        ${n}
      </div>`;
}
function Gu() {
  return `<div class="music-local-page" id="music-queue-page">
    ${Jc("queue")}
    <div class="music-list" id="music-lq-list"></div>
  </div>`;
}
function Ps(t) {
  var c;
  const e = t.querySelector("#music-lq-list");
  if (!e) return;
  const i = Je.trim().toLowerCase(), s = (((c = qi()) == null ? void 0 : c.items) ?? []).filter((r) => !Tt.has(r.path)).filter((r) => !i || [r.title, r.artist, r.album].some((p) => (p || "").toLowerCase().includes(i))), n = s.length === 0 ? `<div class="music-empty">${o(a("music.local_queue_page_empty"))}</div>` : s.map((r, p) => Sn(r, p, "queue-track")).join("");
  C(e, n), $n(t);
}
function Lt(t) {
  const e = t.querySelector("#music-queue-dlg");
  if (!e || (A(e, Ee), !Ee)) return;
  const i = t.querySelector("#music-queue-files"), s = it.length === 0 ? `<div class="music-empty">${o(a("music.local_queue_files_empty"))}</div>` : `<div class="music-queue-file">${o(a("music.local_queue_files_n", { n: String(it.length) }))}</div>` + it.map((n) => `<div class="music-queue-file" title="${o(n)}">${o(n.split(/[\\/]/).pop() || n)}</div>`).join("");
  C(i, s);
}
function Yu(t, e = []) {
  Ee = !0;
  const i = /* @__PURE__ */ new Set();
  it = [];
  for (const n of e) {
    const c = n.toLowerCase();
    !n || i.has(c) || (i.add(c), it.push(n));
  }
  Lt(t);
  const s = t.querySelector("#music-queue-name");
  s && (s.value = "", setTimeout(() => s.focus(), 0));
}
async function Ku(t) {
  let e = null;
  try {
    e = await is({
      multiple: !0,
      title: a("music.local_queue_pick"),
      filters: [{ name: "Audio / Video", extensions: Uu }]
    });
  } catch (n) {
    S(t, String(n));
    return;
  }
  if (!e) return;
  const i = Array.isArray(e) ? e : [e], s = new Set(it.map((n) => n.toLowerCase()));
  for (const n of i) {
    const c = n.toLowerCase();
    !n || s.has(c) || (s.add(c), it.push(n));
  }
  Lt(t);
}
function rc(t) {
  var s;
  if (it.length === 0) {
    S(t, a("music.local_queue_need_files"));
    return;
  }
  const e = t.querySelector("#music-queue-name"), i = {
    id: Bc(),
    name: Xl(((e == null ? void 0 : e.value) ?? "").trim()),
    items: it.map(Vu)
  };
  Ae.push(i), G = i.id, _i(), Ee = !1, U = !1, $e("library"), Lt(t), ie && (De(t), (s = t.querySelector("#music-queue-page")) == null || s.remove(), jt(t)), V(t), S(t, a("music.local_queue_created", { name: i.name }));
}
function Ju(t) {
  const i = ((P == null ? void 0 : P.items) ?? []).filter((s) => F.library.ids.has(s.path));
  Yu(t, i.map((s) => s.path));
}
function Xc(t) {
  const e = t.querySelector("#music-del-dlg");
  if (!e) return;
  const i = Ji !== null;
  if (A(e, i), !i) return;
  const s = Ji;
  M(
    t.querySelector("#music-del-text"),
    a("music.ctx_delete_confirm", { name: s.name })
  );
}
function Xu(t, e, i) {
  Ji = { path: e, name: i || e.split(/[\\/]/).pop() || e }, Xc(t);
}
function fn(t) {
  Ji = null, Xc(t);
}
async function Zu(t) {
  const e = Ji;
  if (!e) return;
  const i = e.path;
  fn(t);
  try {
    await d("media_delete_file", { path: i });
  } catch (s) {
    S(t, String(s));
    return;
  }
  for (const s of ["library", "queue"]) {
    const n = F[s];
    n.ids.delete(i), n.anchor === i && (n.anchor = null);
  }
  ($ == null ? void 0 : $.path) === i && await xt(t), await Yt(t), S(t, a("music.ctx_deleted"));
}
function eo() {
  const t = Fe;
  if (!t) return "";
  const e = (s, n, c = !1) => `<button class="music-ctx-item${c ? " danger" : ""}" data-ctx="${s}">${o(n)}</button>`, i = [];
  if (t.act === "local-track" && i.push(e("add-play-queue", a("music.add_to_play_queue"))), t.act === "queue-track") {
    const s = Zc().length;
    i.push(e("remove-queue", a("music.ctx_remove_selected", { n: String(s) }), !0));
  }
  return (t.act === "local-track" || t.act === "queue-track") && t.path && (i.push(e("reveal", a("music.ctx_reveal"))), i.push(e("delete-file", a("music.ctx_delete_file"), !0))), (t.act === "main-track" || t.act === "play-uri") && i.push(e("play", a("music.ctx_play"))), i.join("");
}
function to(t, e, i) {
  const s = t.querySelector("#music-ctx");
  if (!s) return;
  const n = t.getBoundingClientRect(), c = Math.max(2, Math.min(e - n.left, n.width - 132)), r = Math.max(2, Math.min(i - n.top, n.height - 160));
  s.style.left = `${c}px`, s.style.top = `${r}px`, s.classList.add("open"), requestAnimationFrame(() => {
    if (!s.isConnected) return;
    const p = s.getBoundingClientRect();
    p.width && p.height && (p.right > n.right && (s.style.left = `${Math.max(2, n.width - p.width - 8)}px`), p.bottom > n.bottom && (s.style.top = `${Math.max(2, n.height - p.height - 8)}px`));
  });
}
function io(t, e, i) {
  const s = t.querySelector("#music-ctx");
  s && (C(s, eo()), s.querySelector("button") && to(t, e, i));
}
function _t(t) {
  var e;
  (e = t.querySelector("#music-ctx")) == null || e.classList.remove("open"), Fe = null;
}
function so() {
  const t = (P == null ? void 0 : P.items) ?? [], e = t.filter((i) => F.library.ids.has(i.path));
  if (e.length) return e;
  if (Fe != null && Fe.path) {
    const i = t.find((s) => s.path === Fe.path);
    if (i) return [i];
  }
  return [];
}
function Zc() {
  const t = qi();
  if (!t) return [];
  const e = F.queue.ids;
  return t.items.filter((i) => e.has(i.path));
}
function no(t) {
  const e = qi(), i = Zc();
  if (!e || !i.length) return;
  const s = new Set(i.map((r) => r.path)), n = e.items.length;
  e.items = e.items.filter((r) => !s.has(r.path));
  const c = n - e.items.length;
  $e("queue"), _i(), Ps(t), c > 0 && S(t, a("music.ctx_removed_n_from_queue", { n: String(c) }));
}
function ao(t) {
  const e = so();
  e.length && (B.push(...e), O < 0 && (O = 0, re = 0), Vt(), V(t), S(t, a("music.added_to_play_queue", { n: String(e.length) })));
}
async function co(t, e) {
  if (!B[e]) return;
  const s = e === O, n = !!($ && $.path);
  B.splice(e, 1), tt = [], B.length === 0 ? await el(t, n) : s ? (O = Math.min(e, B.length - 1), re = 0, n ? await ht(t, B[O].path) || await xt(t) : (Vt(), V(t))) : (e < O && O--, Vt(), V(t));
}
async function el(t, e) {
  B = [], O = -1, re = 0, tt = [];
  try {
    localStorage.removeItem(_n);
  } catch {
  }
  e ? await xt(t) : V(t);
}
async function lo(t) {
  if (B.length === 0) return;
  const e = !!($ && $.path);
  await el(t, e);
}
function tl(t) {
  const e = t.querySelector("#music-video");
  if (!e) return;
  const i = $, s = !!i && i.video && i.path !== "";
  if (A(e, s), !s) {
    e.firstChild && (e.innerHTML = "");
    return;
  }
  const n = Is(i.path);
  let c = e.querySelector(".music-video-el");
  if (!c || c.dataset.src !== n) {
    if (e.innerHTML = '<video class="music-video-el" muted playsinline preload="auto"></video>', c = e.querySelector(".music-video-el"), !c) return;
    c.dataset.src = n, c.src = n, c.addEventListener("loadedmetadata", () => dc(c, i), { once: !0 }), c.addEventListener("error", () => {
      At(t, a("music.video_unsupported"));
    });
  }
  dc(c, i);
}
function dc(t, e) {
  e.playing ? t.paused && t.play().catch(() => {
  }) : t.paused || t.pause();
  const i = e.playing ? Date.now() - ss : 0, s = (e.position_ms + Math.max(0, i)) / 1e3;
  t.readyState >= 1 && !t.seeking && Math.abs(t.currentTime - s) > Ql && (t.currentTime = s);
}
function il(t) {
  if (D !== "lplayer") return;
  const e = t.querySelector("#music-v-lplayer"), i = $;
  if (!e || !i || !i.path) return;
  const s = B[O], n = (s == null ? void 0 : s.title) || i.path.split(/[\\/]/).pop() || i.path;
  M(e.querySelector("#music-lp-title"), n), M(e.querySelector("#music-lp-sub"), s ? [s.artist, s.album].filter(Boolean).join(" · ") : ""), C(
    e.querySelector("#music-lp-cover"),
    s != null && s.cover ? `<img src="${o(Is(s.cover))}" alt="">` : v.note
  ), C(e.querySelector("#music-lp-play"), i.active && i.playing ? v.pause : v.play);
  const c = e.querySelector("#music-lp-mode");
  c && (de(c, "data-mode", ue), de(c, "title", wn()), C(c, ue === "repeat_all" || ue === "repeat_one" ? v.repeat : v.shuffle));
  const r = i.duration_ms, p = oe >= 0 ? oe : r > 0 ? Math.min(1, i.position_ms / r) : 0, _ = e.querySelector("#music-lp-progress");
  _ && oe < 0 && _.style.setProperty("--seek-pct", `${p * 100}%`), M(e.querySelector("#music-lp-time"), r > 0 ? `${K(i.position_ms)} / ${K(r)}` : K(i.position_ms));
  const L = e.querySelector("#music-lp-vol");
  L && document.activeElement !== L && (L.value = String(Math.round(i.volume * 100)), oi(L, i.volume * 100));
}
function uo(t) {
  var n, c;
  const e = t.querySelector("#music-lq-dd");
  if (!e || (A(e, Le), (n = t.querySelector("#music-l-queue")) == null || n.classList.toggle("on", Le), (c = t.querySelector("#music-lp-queue")) == null || c.classList.toggle("on", Le), !Le)) return;
  const i = o(a("music.play_queue_clear")), s = B.length === 0 ? `<div class="music-empty">${o(a("music.local_play_queue_empty"))}</div>` : `<div class="music-lq-head"><button type="button" class="music-lq-clear" data-act="queue-clear" title="${i}" aria-label="${i}">${v.trash}</button></div>` + B.map((r, p) => Sn(r, p, "queue-play")).join("");
  C(e, s);
}
function V(t) {
  tl(t), il(t), uo(t);
  const e = t.querySelector("#music-lnowbar");
  if (!e) return;
  const i = $, s = !!i && i.path !== "", n = Pc();
  if (A(e, n), !n) return;
  const c = B[O] ?? null, r = (i && s ? i.path : "") || (c == null ? void 0 : c.path) || "";
  if (!c && !s) {
    M(e.querySelector("#music-lnow-n"), a("music.local_bar_empty")), M(e.querySelector("#music-lnow-a"), ""), C(e.querySelector("#music-lnow-cover"), v.note), C(e.querySelector("#music-l-play"), v.play), M(e.querySelector("#music-l-time"), "0:00");
    const w = e.querySelector("#music-lbp");
    w && oe < 0 && w.style.setProperty("--seek-pct", "0%");
  } else {
    const w = (c == null ? void 0 : c.title) || r.split(/[\\/]/).pop() || r;
    M(e.querySelector("#music-lnow-n"), w), M(e.querySelector("#music-lnow-a"), c ? [c.artist, c.album].filter(Boolean).join(" · ") : ""), C(
      e.querySelector("#music-lnow-cover"),
      c != null && c.cover ? `<img src="${o(Is(c.cover))}" alt="">` : v.note
    ), C(e.querySelector("#music-l-play"), i != null && i.active && (i != null && i.playing) ? v.pause : v.play);
    const E = (i && s ? i.duration_ms : 0) || (c == null ? void 0 : c.duration_ms) || 0, T = i && s ? i.position_ms : re, z = oe >= 0 ? oe : E > 0 ? Math.min(1, T / E) : 0, j = e.querySelector("#music-lbp");
    j && oe < 0 && j.style.setProperty("--seek-pct", `${z * 100}%`), M(e.querySelector("#music-l-time"), E > 0 ? `${K(T)} / ${K(E)}` : K(T));
  }
  const p = !!c || s;
  for (const w of ["#music-l-prev", "#music-l-next", "#music-l-mode", "#music-l-stop", "#music-l-play"]) {
    const E = e.querySelector(w);
    E && (E.disabled = !p);
  }
  const _ = e.querySelector("#music-l-mode");
  _ && (de(_, "data-mode", ue), de(_, "title", wn()), C(_, ue === "repeat_all" || ue === "repeat_one" ? v.repeat : v.shuffle));
  const L = e.querySelector("#music-l-vol");
  if (L && document.activeElement !== L) {
    const w = i ? i.volume : Number(L.value) / 100;
    L.value = String(Math.round(w * 100)), oi(L, w * 100);
  }
}
function qn(t) {
  const e = $ != null && $.active ? $.path : "";
  t.querySelectorAll(".music-mt").forEach((i) => {
    i.classList.toggle("playing", !!e && i.dataset.path === e);
  });
}
function st(t) {
  ie && (De(t), jt(t), V(t));
}
async function sl(t) {
  Es = !0, yi = "", st(t);
  try {
    ne = await d("media_roots");
  } catch (e) {
    yi = String(e);
  } finally {
    Es = !1, st(t);
  }
}
async function Yt(t) {
  Te = null, gi = !0, Mt = "", st(t);
  try {
    P = await d("media_tracks", {
      // 空串 ⇒ 传 null（宿主的 `Option<String>` 收 None = 全库 / 不筛选）
      root: Ue || null,
      query: Ki || null,
      limit: Dc
    });
  } catch (e) {
    Mt = String(e);
  } finally {
    gi = !1, st(t);
  }
}
function di() {
  Bi !== void 0 && (window.clearInterval(Bi), Bi = void 0);
}
function nl(t) {
  Bi === void 0 && (Bi = window.setInterval(() => {
    (async () => {
      if (!t.isConnected) {
        di();
        return;
      }
      try {
        const e = await d("media_scan_status");
        ci = e, e.running || (di(), await sl(t), await Yt(t));
      } catch {
        di();
      }
      st(t);
    })();
  }, Wl));
}
async function al(t, e) {
  try {
    ci = await d("media_scan_start", { root: e || null });
  } catch (i) {
    const s = String(i);
    S(t, s.includes("ERR_SCAN_RUNNING") ? a("music.local_scan_busy") : s);
    return;
  }
  st(t), nl(t);
}
async function oo(t) {
  let e = null;
  try {
    e = await is({ directory: !0, multiple: !1, title: a("music.local_add_dir") });
  } catch (i) {
    S(t, String(i));
    return;
  }
  if (!(typeof e != "string" || !e)) {
    try {
      ne = await d("media_add_root", { path: e });
    } catch (i) {
      S(t, String(i));
      return;
    }
    Ue = ro(e), st(t), await al(t, Ue || e);
  }
}
function ro(t) {
  var s;
  const e = (n) => n.replace(/[\\/]+$/, "").toLowerCase(), i = e(t);
  return ((s = ne == null ? void 0 : ne.find((n) => e(n.path) === i)) == null ? void 0 : s.path) ?? "";
}
function mo(t) {
  te = !0, U = !1, ve.clear(), Tt.clear(), $e("queueList"), mt.clear(), De(t), G !== null && jt(t);
}
function po(t) {
  const e = F.queueList.ids, i = e.size > 0;
  for (const s of e) mt.add(s);
  if ($e("queueList"), G !== null) {
    const s = F.queue.ids;
    if (s.size) {
      for (const n of s) Tt.add(n);
      $e("queue"), Ps(t);
    }
    i && De(t);
    return;
  }
  if (ve.size) {
    for (const s of ve) Yi.add(s);
    ve.clear();
  }
  De(t);
}
async function fo(t) {
  const e = Array.from(mt);
  mt.clear(), $e("queueList");
  let i = !1;
  if (e.length) {
    const c = new Set(e);
    Ae = Ae.filter((r) => !c.has(r.id)), G && c.has(G) && (G = null, i = !0, te = !1, ve.clear(), Tt.clear(), $e("queue"), Je = "", Y !== void 0 && (window.clearTimeout(Y), Y = void 0)), _i();
  }
  if (G !== null) {
    const c = qi(), r = Array.from(Tt);
    if (te = !1, ve.clear(), $e("queue"), $e("library"), Tt.clear(), mn(t), De(t), c && r.length) {
      const p = new Set(r);
      c.items = c.items.filter((_) => !p.has(_.path)), _i();
    }
    jt(t);
    return;
  }
  const s = Array.from(Yi);
  if (te = !1, ve.clear(), Yi.clear(), mn(t), !s.length) {
    De(t), i && jt(t);
    return;
  }
  let n = "";
  for (const c of s)
    try {
      ne = await d("media_remove_root", { path: c });
    } catch (r) {
      const p = String(r);
      n = p.includes("ERR_SCAN_RUNNING") ? a("music.local_remove_busy") : p;
    }
  Ue && !(ne ?? []).some((c) => c.path === Ue) && (Ue = ""), De(t), await Yt(t), i && jt(t), n && S(t, n);
}
function cl(t) {
  const e = t instanceof Error ? t.message : String(t);
  return e.includes("ERR_NOT_PLAYLIST") ? a("music.local_not_playlist") : e;
}
async function vo(t) {
  let e = null;
  try {
    e = await is({
      multiple: !1,
      title: a("music.local_open_playlist"),
      filters: [{ name: "Playlist", extensions: ["m3u", "m3u8", "pls"] }]
    });
  } catch (i) {
    S(t, String(i));
    return;
  }
  if (!(typeof e != "string" || !e)) {
    gi = !0, Mt = "", P = null, st(t);
    try {
      P = await d("media_playlist", { path: e }), Te = { path: e, name: e.split(/[\\/]/).pop() || e }, Ue = "";
    } catch (i) {
      Te = null, Mt = cl(i);
    } finally {
      gi = !1, st(t);
    }
  }
}
function ho(t) {
  Te = null, Yt(t);
}
function ll(t) {
  const e = t instanceof Error ? t.message : String(t);
  return e.includes("ERR_NO_AUDIO_DEVICE") ? a("music.local_no_device") : e.includes("找不到这个文件") ? a("music.local_file_missing") : e.includes("解不开") || e.includes("打不开") ? a("music.local_decode_failed") : e;
}
async function ht(t, e, i = 0) {
  if (Nt) return !1;
  await ns(t, "local"), Nt = !0;
  try {
    $ = await d("player_play", { path: e });
  } catch (s) {
    return S(t, ll(s)), Nt = !1, !1;
  }
  if (Nt = !1, re = 0, i > 0)
    try {
      $ = await d("player_seek", { positionMs: Math.round(i) }), re = $.position_ms;
    } catch {
    }
  return ss = Date.now(), Vt(), li = e, V(t), qn(t), $n(t), ol(t), !0;
}
async function bo(t, e) {
  const i = (P == null ? void 0 : P.items) ?? [], s = i[e];
  s && (B = i.slice(), O = e, tt = [], await ht(t, s.path));
}
async function Zs(t, e, i = qi()) {
  if (!i || !e) return;
  const s = i.items.findIndex((n) => n.path === e);
  s < 0 || (B = i.items.slice(), O = s, tt = [], await ht(t, e));
}
async function yo(t, e) {
  const i = B[e];
  i && (O = e, tt = [], await ht(t, i.path));
}
function mc(t) {
  if (!(t instanceof HTMLElement)) return null;
  const e = t.closest("[data-act]"), i = e ? Kt[e.dataset.act || ""] : void 0;
  return !e || !i ? null : { list: i, container: e.closest(Ds[i]) ?? e };
}
function Os(t) {
  return (t.dataset.act || "") === "local-queue" ? t.dataset.qid || "" : t.dataset.path || t.dataset.uri || "";
}
function ul(t, e) {
  const i = [];
  return t.querySelectorAll("[data-act]").forEach((s) => {
    if (Kt[s.dataset.act || ""] !== e) return;
    const n = Os(s);
    n && !i.includes(n) && i.push(n);
  }), i;
}
function ts(t, e) {
  const i = F[e];
  t.querySelectorAll(Ds[e]).forEach((s) => {
    s.querySelectorAll("[data-act]").forEach((n) => {
      if (Kt[n.dataset.act || ""] !== e) return;
      const c = Os(n), r = !!c && i.ids.has(c), p = n.closest(".music-pl, .music-mt, .music-tr") ?? n;
      p.classList.toggle("sel", r);
      const _ = p.querySelector(".music-mt-i");
      _ != null && _.classList.contains("music-mt-check") && (_.classList.toggle("on", r), _.innerHTML = r ? v.check : "");
    });
  });
}
function $e(t) {
  const e = F[t];
  return !e.ids.size && !e.anchor ? !1 : (e.ids.clear(), e.anchor = null, !0);
}
function us() {
  for (const t of Object.keys(F)) $e(t);
  lt = null;
}
function go(t, e) {
  const i = [];
  t.querySelectorAll(Ds[e]).forEach((n) => {
    for (const c of ul(n, e)) i.includes(c) || i.push(c);
  });
  const s = F[e];
  s.ids.clear();
  for (const n of i) s.ids.add(n);
  s.anchor = i[0] ?? null, ts(t, e);
}
function os(t, e, i) {
  i && (F[e].ids.add(i), F[e].anchor = i, ts(t, e));
}
function rs(t, e, i) {
  const s = Kt[e.dataset.act || ""], n = Os(e);
  if (!s || !n) return;
  const c = F[s], r = e.closest(Ds[s]), p = r ? ul(r, s) : [n], _ = s === "library" && U;
  if (i != null && i.shiftKey && c.anchor) {
    const L = p.indexOf(c.anchor), w = p.indexOf(n);
    if (L >= 0 && w >= 0) {
      c.ids.clear();
      for (let E = Math.min(L, w); E <= Math.max(L, w); E++) c.ids.add(p[E]);
    } else
      c.ids.clear(), c.ids.add(n), c.anchor = n;
  } else i != null && i.ctrlKey || i != null && i.metaKey || _ ? (c.ids.has(n) ? c.ids.delete(n) : c.ids.add(n), c.anchor = n) : (c.ids.clear(), c.ids.add(n), c.anchor = n);
  ts(t, s);
}
async function Ai(t, e, i) {
  var c;
  const s = B.length;
  if (s === 0) return;
  if (i && ue === "repeat_one") {
    await ht(t, ((c = B[O]) == null ? void 0 : c.path) ?? "");
    return;
  }
  let n;
  if (ue === "shuffle" && s > 1)
    if (e < 0 && tt.length > 0)
      n = tt.pop();
    else {
      do
        n = Math.floor(Math.random() * s);
      while (n === O);
      O >= 0 && tt.push(O);
    }
  else
    n = O + e;
  if (ue === "repeat_all" || ue === "shuffle")
    n = (n % s + s) % s;
  else if (n < 0 || n >= s) {
    i || S(t, a("music.local_queue_end"));
    return;
  }
  O = n, await ht(t, B[n].path);
}
async function pc(t) {
  var i;
  if (Nt) return;
  const e = $;
  if (!e || e.path === "") {
    const s = ((i = B[O]) == null ? void 0 : i.path) ?? "";
    if (!s) return;
    await ht(t, s, re);
    return;
  }
  if (!e.active) {
    await ht(t, e.path);
    return;
  }
  try {
    $ = await d(e.playing ? "player_pause" : "player_resume");
  } catch (s) {
    S(t, ll(s));
    return;
  }
  ss = Date.now(), V(t), $ != null && $.active && ol(t);
}
async function xt(t) {
  mi(), $ != null && $.path && (re = $.position_ms), oe = -1, tt = [], $ = null, ss = 0, Vt();
  const e = D === "lplayer";
  e && (D = "default"), V(t), qn(t), e && ae(t);
  try {
    await d("player_stop");
  } catch {
  }
}
async function ns(t, e) {
  if (!We) {
    if (e === "local") {
      if (f != null && f.connected && (y != null && y.playing))
        try {
          await d("spotify_control", { action: "pause" });
        } catch {
        }
      return;
    }
    $ && await xt(t);
  }
}
async function _o(t, e) {
  if (!$ || $.path === "") {
    re = Math.max(0, Math.round(e)), Vt(), V(t);
    return;
  }
  try {
    $ = await d("player_seek", { positionMs: e });
  } catch {
    return;
  }
  re = $.position_ms, V(t);
}
async function fc(t, e) {
  try {
    $ = await d("player_volume", { volume: e });
  } catch {
    return;
  }
  V(t);
}
function mi() {
  zi !== void 0 && (window.clearInterval(zi), zi = void 0);
}
function ol(t) {
  zi === void 0 && (zi = window.setInterval(() => {
    (async () => {
      if (!t.isConnected) {
        mi();
        return;
      }
      if (oe >= 0 || Nt) return;
      let e;
      try {
        e = await d("player_status");
      } catch {
        return;
      }
      if (!t.isConnected) {
        mi();
        return;
      }
      const i = !e.active && e.path !== "" && e.path === ($ == null ? void 0 : $.path);
      $ = e, re = e.position_ms, ss = Date.now(), V(t), qn(t), i && (mi(), await Ai(t, 1, !0));
    })();
  }, jl));
}
function wo(t, e) {
  Ki = e, Se !== void 0 && window.clearTimeout(Se), Se = window.setTimeout(() => {
    Se = void 0, Yt(t);
  }, Fl);
}
function vc(t) {
  Pi = Math.min(Ac, Math.max(Cc, Math.round(Pi))), t.style.setProperty("--music-side-w", `${Pi}px`);
}
function Ln(t, e) {
  var s;
  if (t === "liked")
    return { id: "liked", uri: "", name: a("music.liked_songs"), cover: "", subtitle: "", total: (J == null ? void 0 : J.total) ?? 0 };
  if (t === "top-tracks")
    return {
      id: "top-tracks",
      uri: "",
      name: a("music.top_tracks"),
      cover: "",
      subtitle: a("music.top_tracks_sub"),
      total: 0
    };
  const i = t === "artist" ? Q == null ? void 0 : Q.artists : t === "album" ? Q == null ? void 0 : Q.albums : t === "show" ? Q == null ? void 0 : Q.shows : Q == null ? void 0 : Q.playlists.map(Ns);
  return ((s = bi.get(t)) == null ? void 0 : s.find((n) => n.id === e)) ?? (i == null ? void 0 : i.find((n) => n.id === e)) ?? null;
}
async function rl(t, e) {
  if (!(!(f != null && f.connected) || Ni.has(e) || bi.has(e))) {
    Ni.add(e), Gi.delete(e), Gt(t);
    try {
      const i = e === "playlist" ? (cn = await d("spotify_playlists")).map(Ns) : await d(Al[e]);
      bi.set(e, i);
    } catch (i) {
      Gi.set(e, R(i));
    } finally {
      Ni.delete(e), Gt(t);
    }
  }
}
async function hc(t, e, i) {
  const s = Ln(e, i);
  if (s) {
    if (kt = !1, ze = !1, I = { kind: e, id: s.id, uri: s.uri, name: s.name, cover: s.cover, subtitle: s.subtitle }, Me = null, vt = "", e === "liked") {
      Me = (J == null ? void 0 : J.items) ?? null, vt = Wt, ai = !J, et(t), Xs(t), Ie(t), J || await ml(t);
      return;
    }
    ai = !0, et(t), Xs(t), Ie(t);
    try {
      Me = e === "top-tracks" ? await d("spotify_top_tracks") : await d("spotify_item_tracks", { kind: Cl(e), id: s.id });
    } catch (n) {
      vt = R(n);
    } finally {
      ai = !1, Xs(t), Ie(t);
    }
  }
}
async function bc(t, e, i, s = 0) {
  const n = Ln(e, i);
  if (n) {
    await ns(t, "spotify");
    try {
      if (e === "liked" || e === "show" || e === "top-tracks") {
        const c = (e === "liked" ? J == null ? void 0 : J.items : Me) ?? [];
        if (!c.length) return;
        await d("spotify_play_uris", { uris: c.slice(Math.max(0, s)).map((r) => r.uri), deviceId: Ce || void 0 });
      } else if (n.uri)
        await d("spotify_play_context", { contextUri: n.uri, offsetUri: "", deviceId: Ce || void 0 });
      else
        return;
    } catch (c) {
      S(t, R(c));
    }
  }
}
async function yc(t, e) {
  if (!I) return;
  const i = Me ?? [], s = i[e];
  if (s) {
    await ns(t, "spotify");
    try {
      I.kind === "liked" || I.kind === "show" ? await d("spotify_play_uris", { uris: i.slice(e).map((n) => n.uri), deviceId: Ce || void 0 }) : await d("spotify_play_context", { contextUri: I.uri, offsetUri: s.uri, deviceId: Ce || void 0 });
    } catch (n) {
      S(t, R(n));
    }
  }
}
async function Ms(t, e = !1) {
  if (!(f != null && f.connected)) return;
  if (!e && Ce && Date.now() - vs < Kl) {
    await Si(t);
    return;
  }
  if (Gs) return;
  Gs = !0;
  const i = !!(le != null && le.running), s = window.setTimeout(() => S(t, a("music.auto_starting")), 600);
  try {
    const n = await d("music_autoconfigure", { allowLocal: !xs });
    Ce = n.device_id || "", vs = Date.now(), n.source === "needs_login" ? S(t, a("music.auto_need_login")) : n.source === "local" && !n.device_id ? S(t, a("music.auto_local_unregistered")) : n.started_local && !i ? S(t, a("music.auto_local_started")) : n.source === "start_failed" ? S(t, a("music.auto_start_failed")) : n.source === "none" && !xs && S(t, a("music.auto_none"));
  } catch (n) {
    Ce = "", vs = 0, String(n) !== "ERR_NOT_CONNECTED" && S(t, R(n));
  } finally {
    window.clearTimeout(s), Gs = !1;
  }
  await Si(t);
}
function ko(t) {
  if (t <= 0) return "";
  if (t >= 3600) {
    const e = Math.floor(t / 3600), i = Math.round(t % 3600 / 60);
    return i > 0 ? a("music.wait_hm", { h: String(e), m: String(i) }) : a("music.wait_h", { h: String(e) });
  }
  return t >= 60 ? a("music.wait_m", { m: String(Math.round(t / 60)) }) : a("music.wait_s", { s: String(Math.ceil(t)) });
}
function So() {
  return Ls <= 0 ? 0 : Math.max(0, Math.round((Ls - Date.now()) / 1e3));
}
async function dl(t) {
  try {
    const e = await d("spotify_api_state");
    Et = e.stopped, qs = e.reason, Ls = e.retry_at_ms;
  } catch {
  }
  Cs(t);
}
function Cs(t) {
  const e = t.querySelector("#music-resume");
  if (A(e, Et), !e) return;
  if (!Et) {
    e.textContent = a("music.resume"), e.title = "";
    return;
  }
  const i = ko(So());
  e.textContent = i ? a("music.resume_in", { wait: i }) : a("music.resume"), e.title = i ? a("music.resume_hint", { wait: i, reason: qs }) : qs;
}
async function $o(t) {
  try {
    await d("spotify_resume");
  } catch {
  }
  Et = !1, qs = "", Ls = 0, Cs(t), S(t, a("music.resumed")), Ms(t, !0);
}
async function Si(t) {
  try {
    Ut = await d("spotify_devices");
  } catch (e) {
    Ut = [], S(t, R(e));
  }
  try {
    le = await d("librespot_status");
  } catch {
    le = null;
  }
  ki(t);
}
async function qo(t) {
  if (!(le != null && le.available)) return;
  const e = le.running;
  try {
    le = await d(e ? "librespot_stop" : "librespot_start");
  } catch (i) {
    S(t, R(i));
    return;
  }
  if (xs = e, ki(t), e) {
    Ce = "", vs = 0, await Ms(t, !0);
    return;
  }
  for (let i = 0; i < 6; i++) {
    await new Promise((s) => window.setTimeout(s, 1500));
    try {
      const s = await d("spotify_devices");
      Ut = s;
      const n = s.find((c) => c.name === "Lunac");
      if (n && !n.active && await d("spotify_transfer", { deviceId: n.id, play: !0 }), n) {
        Ce = n.id;
        break;
      }
    } catch {
    }
  }
  await Si(t);
}
async function Lo(t) {
  try {
    le = await d("librespot_login");
  } catch (e) {
    S(t, R(e));
    return;
  }
  xs = !1, ki(t), S(t, a("music.local_login_started"));
  for (let e = 0; e < 60; e++) {
    if (await new Promise((s) => window.setTimeout(s, 2e3)), !t.isConnected) return;
    let i;
    try {
      i = await d("librespot_status");
    } catch {
      continue;
    }
    if (le = i, !!i.has_credentials) {
      i.running || (le = await d("librespot_start").catch(() => i));
      for (let s = 0; s < 8; s++) {
        if (await new Promise((r) => window.setTimeout(r, 1500)), !t.isConnected) return;
        const n = await d("spotify_devices").catch(() => []);
        Ut = n;
        const c = n.find((r) => r.name === "Lunac");
        if (c) {
          c.active || await d("spotify_transfer", { deviceId: c.id, play: !1 }), Ce = c.id;
          break;
        }
      }
      S(t, a("music.local_login_ok"));
      break;
    }
  }
  await Si(t);
}
async function xo(t, e) {
  if (e) {
    try {
      await d("spotify_transfer", { deviceId: e, play: !1 }), ut = !1;
    } catch (i) {
      S(t, R(i));
    }
    await Si(t);
  }
}
async function ml(t) {
  if (!(!(f != null && f.connected) || Vs || J)) {
    Vs = !0, Wt = "", Gt(t);
    try {
      J = await d("spotify_liked");
    } catch (e) {
      Wt = R(e);
    } finally {
      Vs = !1, (I == null ? void 0 : I.kind) === "liked" && (Me = (J == null ? void 0 : J.items) ?? null, ai = !1, vt = Wt), Gt(t), Ie(t);
    }
  }
}
function gc(t, e) {
  if (Qe = e, ze = !!e, Mi !== void 0 && (window.clearTimeout(Mi), Mi = void 0), !e) {
    Q = null, hi = !1, kt = !1, et(t), Ie(t);
    return;
  }
  hi = !0, et(t), Ie(t), Mi = window.setTimeout(() => void Eo(t, e), Ol);
}
async function Eo(t, e) {
  Mi = void 0;
  try {
    const i = await d("spotify_search", { query: e });
    if (Qe !== e) return;
    Q = i;
  } catch (i) {
    if (Qe !== e) return;
    Q = null, S(t, R(i));
  } finally {
    Qe === e && (hi = !1, et(t), Ie(t));
  }
}
function ks(t) {
  const e = (dt == null ? void 0 : dt.items) ?? [], i = a("music.play_from_here"), s = e.length === 0 ? `<div class="music-empty">${a(dt ? "music.queue_empty" : "music.loading")}</div>` : e.map((n, c) => Rs(n, c, "play-uri", "", i)).join("");
  for (const n of ["#music-q", "#music-q-dd"]) C(t.querySelector(n), s);
}
async function pl(t) {
  var e;
  try {
    dt = await d("spotify_queue"), Nc = ((e = y == null ? void 0 : y.track) == null ? void 0 : e.id) ?? "";
  } catch (i) {
    dt = null, At(t, R(i));
  }
  ks(t);
}
function vn(t) {
  const e = (y == null ? void 0 : y.track) ?? null, i = e != null && e.cover ? `<img src="${o(e.cover)}" alt="">` : "", s = [e == null ? void 0 : e.artists, e == null ? void 0 : e.album].filter(Boolean).join(" · ") || (y != null && y.active ? "" : a("music.no_device_hint"));
  C(t.querySelector("#music-pv-cover"), i), C(t.querySelector("#music-bnow-cover"), i), M(t.querySelector("#music-pv-title"), (e == null ? void 0 : e.name) || a("music.no_track")), M(t.querySelector("#music-bnow-n"), (e == null ? void 0 : e.name) || a("music.no_track")), M(t.querySelector("#music-pv-sub"), s), M(t.querySelector("#music-bnow-a"), s);
  const n = (e == null ? void 0 : e.duration_ms) ?? 0, c = Math.min((y == null ? void 0 : y.progress_ms) ?? 0, n || Number.MAX_SAFE_INTEGER), r = n > 0 ? Math.max(0, Math.min(100, c / n * 100)) : 0;
  if (Wc = c, Fc = Date.now(), Dt < 0)
    for (const T of zt) T.style.setProperty("--seek-pct", `${r}%`);
  M(t.querySelector("#music-pv-pos"), K(c)), M(t.querySelector("#music-pv-dur"), K(n)), M(t.querySelector("#music-b-time"), `${K(c)} / ${K(n)}`);
  const p = y != null && y.playing ? v.pause : v.play;
  C(t.querySelector("#music-play"), p), C(t.querySelector("#music-b-play"), p);
  const _ = fl(), L = a(_ === "shuffle" ? "music.mode_shuffle" : _ === "repeat_one" ? "music.mode_repeat_one" : "music.mode_off");
  for (const T of [t.querySelector("#music-mode"), t.querySelector("#music-b-mode")])
    T && (de(T, "data-mode", _), de(T, "title", L), C(T, _ === "repeat_one" ? v.repeat : v.shuffle));
  const w = y && y.volume_percent >= 0 ? y.volume_percent : -1;
  for (const T of [t.querySelector("#music-vol"), t.querySelector("#music-b-vol")])
    T && w >= 0 && document.activeElement !== T && (T.value = String(w), oi(T, w));
  const E = !(y != null && y.active);
  t.querySelectorAll("#music-v-player .music-bar button, #music-nowbar button").forEach((T) => {
    T.id === "music-devices-btn" || T.id === "music-bnow" || T.id === "music-b-drawer" || (T.disabled = E);
  });
}
function To(t) {
  var n;
  if (!t.isConnected || !(y != null && y.playing) || Dt >= 0) return;
  const e = ((n = y.track) == null ? void 0 : n.duration_ms) ?? 0;
  if (e <= 0) return;
  const i = Math.min(Wc + (Date.now() - Fc), e), s = Math.max(0, Math.min(100, i / e * 100));
  for (const c of zt) c.style.setProperty("--seek-pct", `${s}%`);
  M(t.querySelector("#music-pv-pos"), K(i)), M(t.querySelector("#music-b-time"), `${K(i)} / ${K(e)}`);
}
function fl() {
  return (y == null ? void 0 : y.repeat) === "track" ? "repeat_one" : y != null && y.shuffle ? "shuffle" : "off";
}
function en(t) {
  var e, i;
  A(t.querySelector("#music-q-wrap"), _e), A(t.querySelector("#music-q-dd"), _e), (e = t.querySelector("#music-queue-btn")) == null || e.classList.toggle("on", _e), (i = t.querySelector("#music-b-queue")) == null || i.classList.toggle("on", _e);
}
function As(t) {
  const e = t.querySelector("#music-lyr");
  if (!e) return;
  if (xn(), Rt = -1, ni = [], wi && (wi = !1, Ze !== void 0 && (window.clearTimeout(Ze), Ze = void 0)), an) {
    C(e, `<div class="music-empty">${a("music.lyrics_loading")}</div>`);
    return;
  }
  if (fe != null && fe.synced) {
    const s = su(fe.synced);
    if (s.length > 0) {
      ni = s;
      const n = o(a("music.seek_line"));
      C(
        e,
        `<div class="music-lyr-lines">${s.map((c, r) => `<div class="music-lyr-line" data-i="${r}" title="${n}">${o(c.text)}</div>`).join("")}</div>`
      );
      return;
    }
  }
  const i = ((fe == null ? void 0 : fe.plain) || "").trim();
  if (i) {
    C(e, `<div class="music-lyr-plain">${o(i)}</div>`);
    return;
  }
  if (fe != null && fe.instrumental) {
    C(e, `<div class="music-empty">${a("music.lyrics_instrumental")}</div>`);
    return;
  }
  C(e, `<div class="music-empty">${a("music.lyrics_none")}</div>`);
}
function xn() {
  Hi && (cancelAnimationFrame(Hi), Hi = 0);
}
function _c(t, e) {
  xn();
  const i = t.scrollTop, s = e - i;
  if (Math.abs(s) < 1) {
    t.scrollTop = e;
    return;
  }
  let n = 0;
  const c = (r) => {
    n || (n = r);
    const p = Math.min(1, (r - n) / Bl);
    t.scrollTop = i + s * (1 - Math.pow(1 - p, 5)), Hi = p < 1 ? requestAnimationFrame(c) : 0;
  };
  Hi = requestAnimationFrame(c);
}
function Bs(t) {
  var _, L;
  if (ni.length === 0) return;
  const e = t.querySelector("#music-lyr");
  if (!e || !e.isConnected || e.clientHeight === 0) return;
  const i = ((y == null ? void 0 : y.progress_ms) ?? 0) / 1e3;
  let s = -1;
  for (let w = 0; w < ni.length && ni[w].at <= i; w++)
    s = w;
  if (s === Rt) return;
  const n = Math.min(Rt, s), c = Math.max(Rt, s);
  for (let w = Math.max(0, n + 1); w <= c; w++)
    (_ = e.querySelector(`.music-lyr-line[data-i="${w}"]`)) == null || _.classList.toggle("done", w <= s);
  (L = e.querySelector(".music-lyr-line.on")) == null || L.classList.remove("on"), Rt = s;
  const r = e.querySelector(`.music-lyr-line[data-i="${s}"]`);
  if (!r) {
    wi || _c(e, 0);
    return;
  }
  if (r.classList.add("on"), wi) return;
  const p = r.getBoundingClientRect().top - e.getBoundingClientRect().top + e.scrollTop;
  _c(e, Math.max(0, p));
}
function wc(t) {
  wi = !0, xn(), Ze !== void 0 && window.clearTimeout(Ze), Ze = window.setTimeout(() => {
    Ze = void 0, wi = !1, Rt = -1, Bs(t);
  }, Pl);
}
async function Ss(t) {
  try {
    f = await d("music_config_get");
  } catch (e) {
    At(t, R(e));
    return;
  }
  !f.connected && D === "player" && (D = "default", ae(t)), Zt(t), ii(t);
}
async function Mo(t) {
  if (nn === t.id) return;
  nn = t.id, an = !0, fe = null;
  const e = Xi;
  e && As(e);
  try {
    fe = await d("lyrics_get", {
      title: t.name,
      artist: t.artists,
      album: t.album,
      duration: t.duration_ms / 1e3
    });
  } catch (i) {
    fe = { found: !1, instrumental: !1, track: "", artist: "", album: "", duration: 0, synced: null, plain: null }, e && At(e, R(i));
  } finally {
    an = !1, e && (As(e), Bs(e));
  }
}
async function En(t, e) {
  if (e === Bt) {
    if (!t.isConnected) {
      zs();
      return;
    }
    if (cu(t), f != null && f.connected) {
      if (!Et) {
        if (!document.hidden && !hs) {
          hs = !0;
          try {
            if (y = await d("spotify_status"), e !== Bt) return;
            ii(t), vn(t), Bs(t), zu(t), ti(t), ji(t), Et && Cs(t);
          } catch (i) {
            if (e !== Bt) return;
            String(i).includes("ERR_NOT_CONNECTED") ? await Ss(t) : (At(t, R(i)), Cs(t), Et && dl(t));
          } finally {
            hs = !1;
          }
        }
        _e && (y != null && y.track) && y.track.id !== Nc && pl(t);
      }
      y != null && y.track && Mo(y.track);
    }
    e === Bt && (pt = window.setTimeout(() => void En(t, e), Hl));
  }
}
function zs() {
  pt !== void 0 && (window.clearTimeout(pt), pt = void 0), Pt !== void 0 && (window.clearTimeout(Pt), Pt = void 0), bs !== void 0 && (window.clearInterval(bs), bs = void 0), Bt++, hs = !1;
}
function hn(t) {
  zs();
  const e = Bt;
  pt = window.setTimeout(() => void En(t, e), 200), bs = window.setInterval(() => To(t), zl);
}
const Co = 2e3;
let kc = 0;
function Ao(t) {
  const e = Math.max(400, Co - (Date.now() - kc));
  Pt !== void 0 && window.clearTimeout(Pt), Pt = window.setTimeout(() => {
    Pt = void 0, !(!t.isConnected || document.hidden) && (kc = Date.now(), pt !== void 0 && (window.clearTimeout(pt), pt = void 0), pt = window.setTimeout(() => void En(t, Bt), 0));
  }, e);
}
function Io() {
  if (Ja) return;
  Ja = !0, document.addEventListener("visibilitychange", () => {
    const e = Xi;
    !e || !e.isConnected || (document.hidden ? zs() : hn(e));
  });
  const t = (e) => {
    const i = Xi;
    if (!i || !i.isConnected || document.hidden) return;
    const s = e.target;
    !s || !i.contains(s) || Ao(i);
  };
  document.addEventListener("click", t, !0), document.addEventListener("input", t, !0), document.addEventListener("change", t, !0);
}
function ji(t) {
  document.getElementById("plugin-titlebar") && (Ft !== void 0 && window.clearTimeout(Ft), Ft = window.setTimeout(() => void Do(t), 80));
}
async function Do(t) {
  if (Ft = void 0, !document.getElementById("plugin-titlebar")) return;
  let e = Il, i = Dl;
  if (ui()) {
    const n = t.closest(".plugin-result"), c = n == null ? void 0 : n.closest("#results-list");
    if (!n || !c) return;
    const r = getComputedStyle(c), p = parseFloat(r.paddingTop || "0") + parseFloat(r.paddingBottom || "0"), _ = window.innerHeight - c.clientHeight;
    i = Math.round(_ + p + n.getBoundingClientRect().height), e = Rl;
  }
  const s = `${e}x${i}`;
  if (s !== on)
    try {
      await d("plugin_window_resize", { width: e, height: i }), on = s;
    } catch {
    }
}
async function Po(t) {
  var Mn, Cn, An, In, Dn, Rn, Nn, Pn, On, Bn, zn, Hn, Wn, Fn, jn, Qn, Un, Vn, Gn, Yn, Kn, Jn, Xn, Zn, ea, ta, ia, sa, na, aa, ca, la, ua, oa, ra, da, ma, pa, fa, va, ha, ba, ya, ga, _a, wa, ka, Sa, $a, qa, La, xa, Ea, Ta, Ma, Ca, Aa, Ia, Da, Ra, Na, Pa, Oa, Ba, za, Ha, Wa, Fa, ja;
  if (Tc) return Iu(t);
  const e = t.querySelector(".music-root");
  if (!e) return;
  Xi = e, Io(), D = "default", ms = null, ps = !1, Ti = null, _e = !1, on = "", qt = !1, Ri = !1, vi = ["a", "b"], gn = null, ln = null, ys = "", gs = 0, J = null, Wt = "", cn = null, bi.clear(), Ni.clear(), Gi.clear(), we = "playlist", I = null, Me = null, ai = !1, vt = "", Ut = null, ut = !1, le = null, Ce = "", Qe = "", Q = null, hi = !1, ze = !1, kt = !1, Ke = "tracks", zt = [], ie = !1, ne = null, Es = !1, yi = "", Ue = "", te = !1, ve.clear(), Yi.clear(), He = !1, P = null, gi = !1, Mt = "", Te = null, Ki = "", ci = null, di(), Se !== void 0 && (window.clearTimeout(Se), Se = void 0), $ = null, Nt = !1, oe = -1, tt = [], mi();
  const i = Oc();
  B = (i == null ? void 0 : i.queue) ?? [], O = i ? i.index : -1, re = (i == null ? void 0 : i.position_ms) ?? 0, U = !1, Ee = !1, it = [], mt.clear(), us(), Je = "", Y !== void 0 && (window.clearTimeout(Y), Y = void 0), Fe = null, Le = !1, li = ((Mn = B[O]) == null ? void 0 : Mn.path) ?? "";
  const s = (l) => At(e, l), n = (l) => e.querySelector(l);
  Ot && (Ot(), Ot = null), Ot = await bn("spotify-auth", (l) => {
    e.isConnected && (l.payload.ok ? (s(a("music.auth_ok")), Ss(e).then(() => {
      hn(e), Ms(e, !0);
    })) : s(l.payload.message || a("music.auth_failed")));
  });
  const c = () => {
    D = "player", ae(e);
  }, r = () => {
    D = "default", ae(e);
  }, p = () => {
    D = "settings", ae(e);
  };
  (Cn = n("#music-setup-toggle")) == null || Cn.addEventListener("click", () => {
    if (U) {
      Ju(e);
      return;
    }
    p();
  }), (An = n("#music-resume")) == null || An.addEventListener("click", () => void $o(e)), (In = n("#music-set-back")) == null || In.addEventListener("click", r), (Dn = n("#music-set-tuning")) == null || Dn.addEventListener("click", () => {
    D = "tuning", ae(e);
  }), (Rn = n("#music-tuning-on")) == null || Rn.addEventListener("click", () => {
    b && qu(e, !b.enabled);
  }), Kc(e), (Nn = n("#music-curve-open")) == null || Nn.addEventListener("click", () => void Du(e));
  const _ = (l, u, m, h) => {
    var k;
    const g = n(l);
    g == null || g.addEventListener("input", (q) => {
      const N = Number.parseFloat(q.target.value);
      if (!Number.isFinite(N)) return;
      h(N);
      const W = e.querySelector(u);
      W && (W.value = X(N, 1)), _s(e);
    }), g == null || g.addEventListener("change", (q) => {
      const N = Number.parseFloat(q.target.value);
      Number.isFinite(N) && h(N), ce(e);
    }), (k = n(u)) == null || k.addEventListener("change", (q) => {
      const N = q.target, W = Number.parseFloat(N.value.trim());
      if (!Number.isFinite(W)) {
        N.value = X(m(), 1);
        return;
      }
      W !== m() && (h(W), Js(e));
    });
  };
  _("#music-preamp-range", "#music-tune-preamp", () => Qi, (l) => Qi = l), _("#music-bass-range", "#music-tune-bass", () => Ui, (l) => Ui = l), _("#music-treble-range", "#music-tune-treble", () => Vi, (l) => Vi = l), (Pn = n("#music-tuning-user-presets")) == null || Pn.addEventListener("click", (l) => {
    var g;
    const u = l.target.closest(".music-preset-user"), m = u == null ? void 0 : u.dataset.preset;
    if (!m) return;
    const h = ((g = l.target.closest("[data-act]")) == null ? void 0 : g.dataset.act) ?? "use";
    h === "rename" ? (ot = { mode: "rename", from: m, name: m }, he(e), setTimeout(() => {
      var k;
      return (k = e.querySelector("#music-preset-name")) == null ? void 0 : k.select();
    }, 0)) : h === "delete" ? (ot = { mode: "delete", name: m }, he(e)) : Lu(e, m);
  }), (On = n("#music-preset-save")) == null || On.addEventListener("click", () => {
    var u;
    if (!b) return;
    ot = { mode: "save", name: (u = b.user_presets) != null && u.includes(b.preset) ? b.preset : "", overwrite: !1 }, he(e), setTimeout(() => {
      var m;
      return (m = e.querySelector("#music-preset-name")) == null ? void 0 : m.select();
    }, 0);
  }), (Bn = n("#music-preset-cancel")) == null || Bn.addEventListener("click", () => {
    ot = null, he(e);
  }), (zn = n("#music-preset-ok")) == null || zn.addEventListener("click", () => void lc(e)), (Hn = n("#music-preset-name")) == null || Hn.addEventListener("keydown", (l) => {
    l.key === "Enter" ? (l.preventDefault(), lc(e)) : l.key === "Escape" && (l.preventDefault(), ot = null, he(e));
  }), (Wn = n("#music-preset-import")) == null || Wn.addEventListener("click", () => void xu(e)), (Fn = n("#music-preset-export")) == null || Fn.addEventListener("click", () => void Tu(e));
  const L = () => n("#music-delay-range");
  (jn = L()) == null || jn.addEventListener("input", (l) => {
    const u = Number.parseFloat(l.target.value);
    if (!Number.isFinite(u)) return;
    xe = Math.min(Qs, Math.max(0, u));
    const m = e.querySelector("#music-delay-num");
    m && (m.value = X(xe, 1)), _s(e);
  }), (Qn = L()) == null || Qn.addEventListener("change", (l) => {
    const u = Number.parseFloat(l.target.value);
    Number.isFinite(u) && (xe = Math.min(Qs, Math.max(0, u))), ce(e);
  }), (Un = n("#music-delay-num")) == null || Un.addEventListener("change", (l) => {
    const u = l.target, m = Number.parseFloat(u.value.trim());
    if (!Number.isFinite(m) || m < 0 || m > Qs) {
      u.value = X(xe, 1);
      return;
    }
    m !== xe && (xe = m, Js(e));
  }), (Vn = n("#music-copy-list")) == null || Vn.addEventListener("click", (l) => {
    const u = l.target.closest("[data-act]");
    if (!u) return;
    const m = Number(u.dataset.i), h = u.dataset.act;
    if (h === "menu") {
      const g = u.dataset.side === "to" ? "to" : "from";
      ee = (ee == null ? void 0 : ee.row) === m && ee.side === g ? null : { row: m, side: g }, Uc(e);
    } else if (h === "pick") {
      const g = Ht[m], k = Number(u.dataset.ch);
      if (!g || !Number.isInteger(k)) return;
      u.dataset.side === "to" ? g.to = k : g.from = k, ee = null, ce(e);
    } else h === "del" && (Ht.splice(m, 1), (ee == null ? void 0 : ee.row) === m ? ee = null : ee && ee.row > m && (ee.row -= 1), ce(e));
  }), (Gn = n("#music-copy-add")) == null || Gn.addEventListener("click", () => {
    const l = Math.max(2, (b == null ? void 0 : b.channels) || 2);
    Ht.push({ from: 0, to: Math.min(1, l - 1) }), ce(e);
  }), (Yn = n("#music-conv-pick")) == null || Yn.addEventListener("click", () => void Eu(e)), (Kn = n("#music-conv-clear")) == null || Kn.addEventListener("click", () => {
    pi = null, ce(e);
  }), (Jn = n("#music-ab-save-a")) == null || Jn.addEventListener("click", () => void ac(e, "a")), (Xn = n("#music-ab-save-b")) == null || Xn.addEventListener("click", () => void ac(e, "b")), (Zn = n("#music-ab-play")) == null || Zn.addEventListener("click", (l) => {
    const u = l.target.closest("[data-pos]"), m = Number(u == null ? void 0 : u.dataset.pos);
    (m === 1 || m === 2) && ku(e, m);
  }), (ea = n("#music-ab-blind")) == null || ea.addEventListener("click", () => {
    qt = !qt, Ri = !1, vi = qt && Math.random() < 0.5 ? ["b", "a"] : ["a", "b"], es(e);
  }), (ta = n("#music-ab-reveal")) == null || ta.addEventListener("click", () => {
    Ri = !0, es(e);
  });
  const w = () => n("#music-tuning-filters");
  (ia = w()) == null || ia.addEventListener("click", (l) => {
    const u = l.target.closest("[data-act]"), m = u == null ? void 0 : u.closest(".music-tune-row"), h = Number(m == null ? void 0 : m.dataset.i), g = se[h];
    if (!u || !m || !g) return;
    const k = u.dataset.act;
    if (k === "on")
      g.on = !g.on, ce(e);
    else if (k === "del")
      se.splice(h, 1), ke === h ? ke = -1 : ke > h && (ke -= 1), ce(e);
    else if (k === "kind")
      ke = ke === h ? -1 : h, Vc(e);
    else if (k === "pick") {
      const q = u.dataset.kind;
      if (!q) return;
      $u(g, q, (b == null ? void 0 : b.kinds) ?? []), ke = -1, ce(e);
    }
  }), (sa = w()) == null || sa.addEventListener("input", (l) => {
    var W;
    const u = l.target;
    if (!(u instanceof HTMLInputElement) || u.type !== "range") return;
    const m = u.dataset.f, h = u.closest(".music-tune-row"), g = se[Number(h == null ? void 0 : h.dataset.i)];
    if (!m || !g) return;
    const k = Number.parseFloat(u.value);
    if (!Number.isFinite(k)) return;
    if (m === "gain_db") g.gain_db = k;
    else if (m === "q") g.q = k;
    else return;
    const q = h == null ? void 0 : h.querySelector(`input.music-tune-num[data-f="${m}"]`);
    q && (q.value = Ys(g, m));
    const N = (W = u.closest(".music-tune-slider")) == null ? void 0 : W.querySelector("em");
    N && (N.textContent = Ys(g, m)), fi = !0, Ts(e), _s(e);
  }), (na = w()) == null || na.addEventListener("change", (l) => {
    var N;
    const u = l.target, m = (N = u == null ? void 0 : u.dataset) == null ? void 0 : N.f;
    if (!m) return;
    const h = u.closest(".music-tune-row"), g = se[Number(h == null ? void 0 : h.dataset.i)];
    if (!g) return;
    u.type === "range" && (fi = !1);
    const k = Number.parseFloat(u.value.trim());
    if (!Number.isFinite(k)) {
      u.value = Ys(g, m);
      return;
    }
    let q = !1;
    if (m === "freq_hz")
      q = k !== g.freq_hz, g.freq_hz = k;
    else if (m === "gain_db")
      q = k !== g.gain_db, g.gain_db = k;
    else if (m === "q")
      q = k !== g.q, g.q = k;
    else
      return;
    !q && u.type !== "range" || (u.type === "range" ? ce(e) : Js(e));
  }), (aa = n("#music-tune-add")) == null || aa.addEventListener("click", () => {
    se.push(Vl()), ce(e);
  }), (ca = n("#music-avatar")) == null || ca.addEventListener("click", () => {
    D !== "default" && (D = "default", ae(e)), ps = !ps, Zt(e);
  }), (la = n("#music-bnow")) == null || la.addEventListener("click", c);
  const E = (l) => {
    ie !== l && (ie = l, ei = !1, l ? (!We && (y != null && y.playing) && d("spotify_control", { action: "pause" }).catch(() => {
    }), kt = !1, ze = !1, I = null, Me = null, vt = "", ne = null, P = null, yi = "", Mt = "", ci = null, Te = null) : (di(), U = !1, mt.clear(), us(), Je = "", Y !== void 0 && (window.clearTimeout(Y), Y = void 0), Fe = null, Le = !1, Ee && (Ee = !1, Lt(e)), li = "", Ki = "", Se !== void 0 && (window.clearTimeout(Se), Se = void 0), we = "playlist", $ != null && $.path && !We && xt(e)), ae(e), ii(e), V(e), l && (sl(e), Yt(e), d("media_scan_status").then((u) => {
      !ie || !e.isConnected || (ci = u, u.running && nl(e), st(e));
    }).catch(() => {
    })));
  }, T = (l) => {
    if (l === "tuning") {
      D = "tuning", ae(e);
      return;
    }
    D = "default", E(l === "local"), ae(e);
  }, z = du(e);
  z == null || z.addEventListener("click", (l) => {
    const u = l.target.closest(".music-tb-seg"), m = u == null ? void 0 : u.dataset.seg;
    m && T(m);
  }), (ua = n("#music-local-add")) == null || ua.addEventListener("click", () => {
    He = !He, Ci(e);
  }), (oa = n("#music-local-list")) == null || oa.addEventListener("click", () => mo(e)), (ra = n("#music-local-del")) == null || ra.addEventListener("click", () => po(e)), (da = n("#music-local-editdone")) == null || da.addEventListener("click", () => void fo(e)), (ma = n("#music-main")) == null || ma.addEventListener("input", (l) => {
    const u = l.target;
    if ((u == null ? void 0 : u.id) === "music-lq-q") {
      Je = u.value, Y !== void 0 && window.clearTimeout(Y), Y = window.setTimeout(() => {
        Y = void 0, Ps(e);
      }, 140);
      return;
    }
    (u == null ? void 0 : u.id) === "music-mt-q" && wo(e, u.value.trim());
  }), (pa = n("#music-l-prev")) == null || pa.addEventListener("click", () => void Ai(e, -1, !1)), (fa = n("#music-l-next")) == null || fa.addEventListener("click", () => void Ai(e, 1, !1)), (va = n("#music-l-play")) == null || va.addEventListener("click", () => void pc(e)), (ha = n("#music-l-stop")) == null || ha.addEventListener("click", () => void xt(e));
  const j = () => {
    !Le && D !== "default" && (D = "default", ae(e)), Le = !Le, V(e), ti(e);
  };
  (ba = n("#music-queue-pick")) == null || ba.addEventListener("click", () => void Ku(e)), (ya = n("#music-queue-cancel")) == null || ya.addEventListener("click", () => {
    Ee = !1, Lt(e);
  }), (ga = n("#music-queue-ok")) == null || ga.addEventListener("click", () => rc(e)), (_a = n("#music-queue-name")) == null || _a.addEventListener("keydown", (l) => {
    l.key === "Enter" ? (l.preventDefault(), rc(e)) : l.key === "Escape" && (l.preventDefault(), Ee = !1, Lt(e));
  }), (wa = n("#music-queue-dlg")) == null || wa.addEventListener("pointerdown", (l) => {
    l.target.classList.contains("music-dlg-mask") && (Ee = !1, Lt(e));
  }), (ka = n("#music-del-ok")) == null || ka.addEventListener("click", () => void Zu(e)), (Sa = n("#music-del-cancel")) == null || Sa.addEventListener("click", () => fn(e)), ($a = n("#music-del-dlg")) == null || $a.addEventListener("pointerdown", (l) => {
    l.target.classList.contains("music-dlg-mask") && fn(e);
  }), (qa = n("#music-b-drawer")) == null || qa.addEventListener("click", () => {
    ei = !0, ti(e), V(e);
  }), (La = n("#music-l-drawer")) == null || La.addEventListener("click", () => {
    ei = !1, ti(e), V(e);
  });
  const be = n("#music-l-vol");
  be == null || be.addEventListener("input", () => {
    oi(be, Number(be.value)), fc(e, Number(be.value) / 100);
  });
  const Ve = () => {
    const l = ["off", "shuffle", "repeat_all", "repeat_one"];
    ue = l[(l.indexOf(ue) + 1) % l.length], iu(ue), V(e), S(e, wn());
  };
  (xa = n("#music-l-mode")) == null || xa.addEventListener("click", Ve);
  const Ne = (l, u) => {
    const m = (k) => {
      const q = l.getBoundingClientRect();
      return Math.max(0, Math.min(1, (k - q.left) / Math.max(1, q.width)));
    }, h = (k) => {
      oe = k, l.style.setProperty("--seek-pct", `${k * 100}%`), u(k);
    };
    l.addEventListener("pointerdown", (k) => {
      if (!((($ == null ? void 0 : $.duration_ms) ?? 0) <= 0)) {
        try {
          l.setPointerCapture(k.pointerId);
        } catch {
        }
        l.classList.add("music-dragging"), h(m(k.clientX));
      }
    }), l.addEventListener("pointermove", (k) => {
      oe < 0 || h(m(k.clientX));
    });
    const g = (k) => {
      if (oe < 0) return;
      const q = oe;
      oe = -1, l.classList.remove("music-dragging");
      try {
        l.releasePointerCapture(k.pointerId);
      } catch {
      }
      _o(e, Math.round((($ == null ? void 0 : $.duration_ms) ?? 0) * q));
    };
    l.addEventListener("pointerup", g), l.addEventListener("pointercancel", g);
  }, Pe = n("#music-lbp");
  Pe && Ne(Pe, (l) => {
    const u = ($ == null ? void 0 : $.duration_ms) ?? 0;
    M(Pe.querySelector(".music-progress-tip"), Wi(u * l));
    const m = e.querySelector("#music-l-time");
    m && M(m, `${K(u * l)} / ${K(u)}`);
  });
  const ye = async () => {
    var l;
    if (!$ || !$.path) {
      const u = ((l = B[O]) == null ? void 0 : l.path) ?? "";
      if (!u || !await ht(e, u, re)) return;
    }
    D = "lplayer", ae(e);
  };
  (Ea = n("#music-lnow")) == null || Ea.addEventListener("click", () => void ye()), (Ta = n("#music-lp-prev")) == null || Ta.addEventListener("click", () => void Ai(e, -1, !1)), (Ma = n("#music-lp-next")) == null || Ma.addEventListener("click", () => void Ai(e, 1, !1)), (Ca = n("#music-lp-play")) == null || Ca.addEventListener("click", () => void pc(e)), (Aa = n("#music-lp-stop")) == null || Aa.addEventListener("click", () => void xt(e)), (Ia = n("#music-lp-mode")) == null || Ia.addEventListener("click", Ve);
  const nt = n("#music-lp-vol");
  nt == null || nt.addEventListener("input", () => {
    oi(nt, Number(nt.value)), fc(e, Number(nt.value) / 100);
  });
  const Li = n("#music-lp-progress");
  Li && Ne(Li, (l) => {
    const u = ($ == null ? void 0 : $.duration_ms) ?? 0;
    M(Li.querySelector(".music-progress-tip"), Wi(u * l));
    const m = e.querySelector("#music-lp-time");
    m && M(m, `${K(u * l)} / ${K(u)}`);
  });
  const bt = (l) => {
    var u;
    !e.isConnected || !ui() || (u = l.target) != null && u.closest("#plugin-close") && (l.stopPropagation(), l.preventDefault(), D === "lplayer" ? r() : fu(e));
  };
  document.addEventListener("click", bt, !0), (Da = n("#music-fields-toggle")) == null || Da.addEventListener("click", () => {
    ms = !(ms ?? !(f != null && f.builtin)), Zt(e);
  }), (Ra = n("#music-copy-redirect")) == null || Ra.addEventListener("click", () => {
    const l = (f == null ? void 0 : f.redirect_uri) || "";
    l && xl(l).then(() => s(a("music.copied"))).catch(() => {
    });
  });
  for (const l of e.querySelectorAll("#music-quality .music-seg-btn"))
    l.addEventListener("click", () => {
      Ti = Number(l.dataset.q), Zt(e);
    });
  (Na = n("#music-set-save")) == null || Na.addEventListener("click", async () => {
    try {
      f = await d("music_config_set", { librespotBitrate: Ti }), Ti = null, s(a("music.saved")), Zt(e), ii(e);
    } catch (l) {
      s(R(l));
    }
  }), (Pa = n("#music-save")) == null || Pa.addEventListener("click", async () => {
    var h, g, k, q;
    const l = ((h = n("#music-client-id")) == null ? void 0 : h.value.trim()) ?? "", u = ((g = n("#music-port")) == null ? void 0 : g.value.trim()) ?? "", m = Number(u);
    if (!l) {
      s(a("music.err_no_client_id"));
      return;
    }
    if (!Number.isInteger(m) || m < 1024 || m > 65535) {
      s(a("music.err_bad_port"));
      return;
    }
    try {
      f = await d("music_config_set", {
        clientId: l,
        port: m,
        // 本机播放那两项**一起交上去**（留空 = 自动探测 / 直连，都是合法值）
        librespotPath: ((k = n("#music-librespot")) == null ? void 0 : k.value.trim()) ?? "",
        librespotProxy: ((q = n("#music-librespot-proxy")) == null ? void 0 : q.value.trim()) ?? ""
        // 音质**不在这里提交**（2026-10-01 起它归设置页，那个页面有自己的「保存」）：
        // 不传 = `None` = 别动，宿主本来就是这个语义。把两页的保存混在一处，
        // 就会出现「在设置页点了 320、回连接卡片点保存、结果把它一起落盘了」。
      }), s(a("music.saved")), Zt(e), ii(e), le = null;
    } catch (N) {
      s(R(N));
    }
  }), (Oa = n("#music-connect")) == null || Oa.addEventListener("click", async () => {
    var m, h;
    const l = ((m = n("#music-client-id")) == null ? void 0 : m.value.trim()) ?? "", u = Number(((h = n("#music-port")) == null ? void 0 : h.value.trim()) ?? "");
    if (l && Number.isInteger(u) && u >= 1024)
      try {
        f = await d("music_config_set", {
          clientId: l,
          port: u,
          librespotPath: null,
          librespotProxy: null,
          // 串流质量同上：这条路径只是「先落盘再连」，别动用户选的档
          librespotBitrate: null
        });
      } catch (g) {
        s(R(g));
        return;
      }
    try {
      const g = await d("spotify_connect");
      s(a("music.browser_hint")), await Ll(g);
    } catch (g) {
      s(R(g));
    }
  }), (Ba = n("#music-disconnect")) == null || Ba.addEventListener("click", async () => {
    try {
      await d("spotify_disconnect"), y = null, fe = null, nn = "", cn = null, bi.clear(), Gi.clear(), dt = null, _e = !1, I = null, Me = null, vt = "", Q = null, Qe = "", ze = !1, kt = !1, Ut = null, D = "default", await Ss(e), ae(e), ks(e), s(a("music.disconnected"));
    } catch (l) {
      s(R(l));
    }
  });
  const Oe = 500;
  let yt, me;
  const Ge = () => {
    yt !== void 0 && (window.clearTimeout(yt), yt = void 0);
  }, x = (l) => {
    Ge(), yt = window.setTimeout(() => {
      yt = void 0, l();
    }, Oe);
  }, H = (l) => {
    const u = Date.now(), m = !!me && me.key === l && u - me.at <= Oe;
    return me = m ? void 0 : { key: l, at: u }, m;
  }, pe = (l) => {
    Ae.some((u) => u.id === l) && (G = l, _i(), U = !1, te = !1, ve.clear(), Tt.clear(), mt.clear(), us(), Je = "", Y !== void 0 && (window.clearTimeout(Y), Y = void 0), ie || E(!0), D = "default", ae(e));
  }, Be = (l, u) => {
    var m;
    if (u) {
      if (l === "playlist" && ((m = Ln(l, u)) == null ? void 0 : m.total) === 0) {
        S(e, a("music.playlist_empty"));
        return;
      }
      bc(e, l, u);
    }
  }, at = (l) => {
    const u = Ae.find((m) => m.id === l);
    if (u) {
      if (u.items.length === 0) {
        S(e, a("music.local_queue_page_empty"));
        return;
      }
      Zs(e, u.items[0].path, u);
    }
  }, It = async (l) => {
    const u = l ? ne == null ? void 0 : ne.find((h) => h.path === l) : void 0;
    if (u != null && u.missing) {
      S(e, a("music.local_missing"));
      return;
    }
    let m;
    try {
      m = await d("media_tracks", {
        root: l || null,
        // 空串 ⇒ 全部曲目（宿主 `Option<String>` 收 None）
        query: null,
        // 双击播的是整个目录，不是当前筛选后的子集
        limit: Dc
        // 与主区列表同一个上限，双击播到的就是会显示的那批
      });
    } catch (h) {
      S(e, cl(h));
      return;
    }
    if (m.items.length === 0) {
      S(e, a("music.local_empty"));
      return;
    }
    Zs(e, m.items[0].path, m);
  }, xi = (l) => {
    var k;
    const u = (k = l.target) == null ? void 0 : k.closest("[data-act]");
    if (!u) return;
    const m = u.dataset.kind || "", h = u.dataset.id || "", g = u.dataset.act === "open" || u.dataset.act === "local-queue" || u.dataset.act === "media-root";
    switch ((!u.closest("#music-side-list") || !g) && (Ge(), me = void 0), u.dataset.act) {
      case "side-tab":
        we = u.dataset.tab || "playlist", Gt(e), rl(e, we);
        break;
      case "search-tab":
        Ke = u.dataset.tab || "tracks", Ie(e);
        break;
      case "open": {
        if (!u.closest("#music-side-list")) {
          hc(e, m, h);
          break;
        }
        if (H(`open:${m}:${h}`)) {
          Ge(), Be(m, h);
          break;
        }
        x(() => void hc(e, m, h));
        break;
      }
      case "main-track": {
        rs(e, u, l);
        break;
      }
      case "main-play-all":
        I && bc(e, I.kind, I.id);
        break;
      case "dd-track":
        u.dataset.uri && tn(e, u.dataset.uri);
        break;
      case "play-uri": {
        rs(e, u, l);
        break;
      }
      case "search-all":
        ze = !1, kt = !0, et(e), Ie(e);
        break;
      case "dev-pick":
        xo(e, h);
        break;
      case "local-toggle":
        qo(e);
        break;
      case "local-login":
        Lo(e);
        break;
      // ── 本地音乐页（2026-10-01）──
      case "media-root": {
        const q = u.dataset.path || "";
        if (te) {
          Ge(), me = void 0, q && (ve.has(q) ? ve.delete(q) : ve.add(q)), De(e);
          break;
        }
        const N = q ? `media-root:${q}` : "media-root:*";
        if (U)
          me = void 0;
        else if (H(N)) {
          Ge(), It(q);
          break;
        }
        x(() => {
          Ge(), Ue = q, G !== null && (G = null, te = !1, ve.clear(), Tt.clear(), mt.clear(), us(), Je = "", Y !== void 0 && (window.clearTimeout(Y), Y = void 0), _i()), De(e), Yt(e);
        });
        break;
      }
      case "media-scan":
        if (U) {
          U = !1, $e("library"), Zi(e), pn(e);
          break;
        }
        al(e);
        break;
      // 「自定义队列」开关（2026-10-10 用户口径：入口从齿轮挪到本地页筛选行最右侧；
      // 2026-10-11 改：开启 = 进**列表勾选编辑态**，不再弹小窗）。
      case "qmode":
        U = !U, $e("library"), U && (He = !1), Zi(e), pn(e);
        break;
      // `＋` 浮层里的两行（2026-10-01）：目录 vs 播放列表文件。
      // **先关浮层再干活** —— 目录对话框是模态的，浮层留着会在对话框背后一闪一闪。
      case "media-add-dir":
        He = !1, Ci(e), oo(e);
        break;
      case "media-add-list":
        He = !1, Ci(e), vo(e);
        break;
      case "media-list-close":
        ho(e);
        break;
      case "local-track": {
        rs(e, u, l);
        break;
      }
      // ── 本地「自定义队列」（2026-10-11 用户口径：多条，列在左栏）──
      case "local-queue": {
        const q = u.dataset.qid || "";
        if (!Ae.some((N) => N.id === q)) break;
        if (te) {
          F.queueList.ids.has(q) ? F.queueList.ids.delete(q) : F.queueList.ids.add(q), F.queueList.anchor = q, De(e);
          break;
        }
        if (H(`local-queue:${q}`)) {
          Ge(), at(q);
          break;
        }
        x(() => pe(q));
        break;
      }
      // ── 队列详情页（2026-10-09 用户口径；2026-10-11 由左栏选中驱动）──
      case "queue-track": {
        rs(e, u, l);
        break;
      }
      // 本地队列**下拉浮层**（`#music-lq-dd`）里的行 = 播放队列（`localQueue`）的一首：
      // **单击 = 从这一首起播**（不参与多选；鼠标移上去只是 hover 预选 + 右侧显形 ×）。
      case "queue-play":
        yo(e, Number(u.dataset.i || "0"));
        break;
      // 播放队列行右侧的 ×：只从播放队列移除（不删磁盘、不动任何自定义队列）。
      case "queue-remove":
        l.stopPropagation(), co(e, Number(u.dataset.i || "0"));
        break;
      // 浮层右上角的「一键清除队列」：只清播放队列（不删磁盘、不动任何自定义队列）。
      // 按钮不是曲目行的一部分 ⇒ 不冒泡、不触发 queue-play；清除后浮层保持打开（显示空态）。
      case "queue-clear":
        l.stopPropagation(), lo(e);
        break;
    }
  };
  for (const l of ["#music-side-list", "#music-side-tabs", "#music-main", "#music-search-dd", "#music-dev-dd", "#music-q", "#music-q-dd", "#music-lq-dd", "#music-local-add-dd"])
    (za = n(l)) == null || za.addEventListener("click", xi);
  e.addEventListener("dblclick", (l) => {
    var m;
    const u = (m = l.target) == null ? void 0 : m.closest("[data-act]");
    if (u)
      switch (u.dataset.act) {
        case "local-track": {
          os(e, "library", u.dataset.path || ""), bo(e, Number(u.dataset.i || "0"));
          break;
        }
        case "queue-track": {
          const h = u.dataset.path || "";
          os(e, "queue", h), Zs(e, h);
          break;
        }
        case "main-track": {
          os(e, "onlineMain", u.dataset.uri || ""), yc(e, Number(u.dataset.i || "0"));
          break;
        }
        case "play-uri": {
          const h = u.dataset.uri || "";
          os(e, "onlineQueue", h), h && tn(e, h);
          break;
        }
      }
  }), e.addEventListener("contextmenu", (l) => {
    var Qa;
    const u = (Qa = l.target) == null ? void 0 : Qa.closest("[data-act]");
    if (!u) return;
    const m = u.dataset.act || "";
    if (m === "local-queue") return;
    const h = Kt[m];
    if (!h) return;
    l.preventDefault(), l.stopPropagation();
    const g = Number(u.dataset.i || "0"), k = u.dataset.path || "", q = u.dataset.uri || "", N = m === "local-queue" ? u.dataset.qid || "" : m === "queue-track" ? G ?? "" : "", W = F[h], Ye = Os(u);
    Ye && !W.ids.has(Ye) && (W.ids.clear(), W.ids.add(Ye), W.anchor = Ye, ts(e, h)), Fe = { act: m, i: g, path: k, uri: q, qid: N }, io(e, l.clientX, l.clientY);
  }), (Ha = n("#music-ctx")) == null || Ha.addEventListener("click", (l) => {
    var g, k, q, N;
    const u = (g = l.target) == null ? void 0 : g.closest("[data-ctx]");
    if (!u) return;
    const m = u.dataset.ctx || "", h = Fe;
    if (h) {
      if (m === "add-play-queue") {
        ao(e), _t(e);
        return;
      }
      if (m === "reveal") {
        h.path && d("reveal_in_explorer", { path: h.path }).catch((W) => S(e, String(W))), _t(e);
        return;
      }
      if (m === "delete-file") {
        const W = h.path && ((k = P == null ? void 0 : P.items.find((Ye) => Ye.path === h.path)) == null ? void 0 : k.title) || h.path && ((N = (q = qi()) == null ? void 0 : q.items.find((Ye) => Ye.path === h.path)) == null ? void 0 : N.title) || "";
        _t(e), Xu(e, h.path, W);
        return;
      }
      if (m === "remove-queue") {
        no(e), _t(e);
        return;
      }
      if (m === "play") {
        _t(e), h.act === "main-track" ? yc(e, h.i) : h.act === "play-uri" && h.uri && tn(e, h.uri);
        return;
      }
    }
  }), document.addEventListener("keydown", (l) => {
    var u;
    l.key === "Escape" && ((u = n("#music-ctx")) != null && u.classList.contains("open")) && _t(e);
  }), e.addEventListener("pointerdown", (l) => {
    var u;
    lt = ((u = mc(l.target)) == null ? void 0 : u.list) ?? null;
  }, !0), e.addEventListener("focusin", (l) => {
    var u;
    lt = ((u = mc(l.target)) == null ? void 0 : u.list) ?? null;
  }), e.addEventListener("keydown", (l) => {
    var m;
    const u = l.target;
    if (!(u && (u.closest("input, textarea, select") || u.isContentEditable))) {
      if (l.key === "Escape") {
        if ((m = n("#music-ctx")) != null && m.classList.contains("open")) {
          _t(e);
          return;
        }
        lt && $e(lt) && (ts(e, lt), l.preventDefault());
        return;
      }
      if ((l.ctrlKey || l.metaKey) && !l.altKey && !l.shiftKey && l.key.toLowerCase() === "a") {
        if (!lt || lt === "queueList" && !te) return;
        l.preventDefault(), go(e, lt);
      }
    }
  }), (Wa = n("#music-devices-btn")) == null || Wa.addEventListener("click", () => {
    ut = !ut, ki(e), ut && Si(e);
  }), vc(e), (Fa = n("#music-split")) == null || Fa.addEventListener("pointerdown", (l) => {
    var k;
    l.preventDefault();
    const u = l.clientX, m = ((k = n("#music-side")) == null ? void 0 : k.getBoundingClientRect().width) ?? Pi, h = (q) => {
      Pi = Math.min(Ac, Math.max(Cc, Math.round(m + q.clientX - u))), vc(e);
    }, g = () => {
      window.removeEventListener("pointermove", h), window.removeEventListener("pointerup", g), document.body.classList.remove("music-resizing");
    };
    document.body.classList.add("music-resizing"), window.addEventListener("pointermove", h), window.addEventListener("pointerup", g);
  }), document.addEventListener("pointerdown", (l) => {
    const u = l.target;
    u && (ut && !u.closest("#music-dev-dd") && !u.closest("#music-devices-btn") && (ut = !1, ki(e)), ze && !u.closest(".music-search-wrap") && (ze = !1, et(e)), He && !u.closest("#music-local-add-dd") && !u.closest("#music-local-add") && (He = !1, Ci(e)), _e && !u.closest("#music-q-dd") && !u.closest("#music-b-queue") && !u.closest("#music-queue-btn") && (_e = !1, en(e)), Le && !u.closest("#music-lq-dd") && !u.closest("#music-l-queue") && !u.closest("#music-lp-queue") && (Le = !1, V(e)), Fe && !u.closest("#music-ctx") && _t(e));
  });
  const Z = n("#music-search");
  Z == null || Z.addEventListener("input", () => gc(e, Z.value.trim())), Z == null || Z.addEventListener("focus", () => {
    Qe && (ze = !0, et(e));
  }), Z == null || Z.addEventListener("keydown", (l) => {
    if (l.key === "Enter" && Qe) {
      ze = !1, kt = !0, et(e), Ie(e);
      return;
    }
    l.key === "Escape" && (Z.value = "", gc(e, ""));
  }), document.body.addEventListener("mouseenter", () => ji(e)), document.body.addEventListener("mouseleave", () => ji(e));
  const ct = async (l, u) => {
    l === "play" && await ns(e, "spotify");
    try {
      await d("spotify_control", { action: l, value: u });
    } catch (m) {
      s(R(m));
    }
  }, gt = (l, u) => {
    var m;
    for (const h of l) (m = n(`#${h}`)) == null || m.addEventListener("click", u);
  }, vl = () => {
    _e = !_e, en(e), ks(e), _e ? pl(e) : vn(e), ji(e);
  };
  e.addEventListener("click", (l) => {
    var h;
    const u = l.target;
    if (!u) return;
    const m = u.closest("#music-l-queue, #music-lp-queue, #music-queue-btn, #music-b-queue");
    if (m && d("log_frontend", { level: "warn", message: `[music] queue-btn hit id=${m.id}` }).catch(() => {
    }), u.closest("#music-l-queue, #music-lp-queue")) {
      j();
      const g = e.querySelector("#music-lq-dd"), k = e.querySelector("#music-body"), q = e.querySelector("#music-v-default");
      d("log_frontend", {
        level: "warn",
        message: `[music] queue AFTER toggleLocalQueue: mode=${D} localPage=${ie} activeQueueId=${G} localQueueOpen=${Le} localQueueLen=${B.length} barMode=${ui()} ddExists=${!!g} ddHidden=${g ? g.classList.contains("hidden") : "n/a"} bodyHidden=${k ? k.classList.contains("hidden") : "n/a"} defaultHidden=${q ? q.classList.contains("hidden") : "n/a"}`
      }).catch(() => {
      });
      return;
    }
    if (u.closest("#music-queue-btn, #music-b-queue")) {
      vl();
      const g = e.querySelector("#music-q-dd"), k = e.querySelector("#music-q-wrap");
      d("log_frontend", {
        level: "warn",
        message: `[music] queue AFTER toggleQueue: queueOpen=${_e} barMode=${ui()} ddExists=${!!g} ddHidden=${g ? g.classList.contains("hidden") : "n/a"} wrapHidden=${k ? k.classList.contains("hidden") : "n/a"} items=${dt ? ((h = dt.items) == null ? void 0 : h.length) ?? 0 : "no-queue"}`
      }).catch(() => {
      });
      return;
    }
  }), gt(["music-prev", "music-b-prev"], () => void ct("previous")), gt(["music-next", "music-b-next"], () => void ct("next")), gt(["music-play", "music-b-play"], () => void ct(y != null && y.playing ? "pause" : "play")), gt(["music-dual-btn", "music-l-dual-btn"], () => {
    We = !We, eu(We), We || (ei = !1), !We && !ie && $ && xt(e), V(e), ti(e), S(e, a(We ? "music.dual_on" : "music.dual_off"));
  });
  let as = null, Hs = !1;
  const hl = async (l) => {
    if (as = l, !Hs) {
      Hs = !0;
      try {
        for (; as !== null; ) {
          const u = as;
          as = null, await ct("volume", u);
        }
      } finally {
        Hs = !1;
      }
    }
  };
  for (const l of ["music-vol", "music-b-vol"])
    (ja = n(`#${l}`)) == null || ja.addEventListener("input", (u) => {
      const m = u.target, h = Number(m.value);
      oi(m, h), hl(h);
    });
  gt(["music-mode", "music-b-mode"], () => {
    const l = fl();
    d("spotify_set_play_mode", { mode: l === "off" ? "shuffle" : l === "shuffle" ? "repeat_one" : "off" }).catch((m) => s(R(m)));
  }), zt = ["#music-pv-progress", "#music-bp"].map((l) => n(l)).filter((l) => !!l);
  for (const l of zt) {
    const u = (g) => {
      const k = l.getBoundingClientRect();
      return Math.max(0, Math.min(1, (g - k.left) / Math.max(1, k.width)));
    }, m = (g) => {
      var W;
      Dt = g;
      const k = `${g * 100}%`;
      for (const Ye of zt) Ye.style.setProperty("--seek-pct", k);
      const q = ((W = y == null ? void 0 : y.track) == null ? void 0 : W.duration_ms) ?? 0, N = K(q * g);
      M(l.querySelector(".music-progress-tip"), Wi(q * g)), M(n("#music-pv-pos"), N), M(n("#music-b-time"), `${N} / ${K(q)}`);
    };
    l.addEventListener("pointerdown", (g) => {
      var k;
      if (!((((k = y == null ? void 0 : y.track) == null ? void 0 : k.duration_ms) ?? 0) <= 0)) {
        try {
          l.setPointerCapture(g.pointerId);
        } catch {
        }
        l.classList.add("music-dragging"), m(u(g.clientX));
      }
    }), l.addEventListener("pointermove", (g) => {
      Dt < 0 || m(u(g.clientX));
    });
    const h = (g) => {
      var q;
      if (Dt < 0) return;
      const k = Dt;
      Dt = -1, l.classList.remove("music-dragging");
      try {
        l.releasePointerCapture(g.pointerId);
      } catch {
      }
      ct("seek", Math.round((((q = y == null ? void 0 : y.track) == null ? void 0 : q.duration_ms) ?? 0) * k));
    };
    l.addEventListener("pointerup", h), l.addEventListener("pointercancel", h);
  }
  const qe = n("#music-lyr");
  let Ws = !1, Tn = 0;
  qe == null || qe.addEventListener("wheel", () => wc(e), { passive: !0 }), qe == null || qe.addEventListener("pointerdown", (l) => {
    Ws = !1, Tn = l.clientY, wc(e);
  }), qe == null || qe.addEventListener("pointermove", (l) => {
    Math.abs(l.clientY - Tn) > 4 && (Ws = !0);
  }), qe == null || qe.addEventListener("click", (l) => {
    if (Ws) return;
    const u = l.target.closest(".music-lyr-line"), m = u ? ni[Number(u.dataset.i)] : void 0;
    m && ct("seek", Math.round(m.at * 1e3));
  }), await Ss(e), ae(e), vn(e), As(e), ks(e), en(e), ii(e), await dl(e), hn(e), Ms(e);
}
async function tn(t, e) {
  await ns(t, "spotify");
  try {
    await d("spotify_play_uri", { uri: e, deviceId: Ce || void 0 });
  } catch (i) {
    At(t, R(i));
  }
}
function Ro() {
  dn(), kn(), zs(), Xi = null, Ze !== void 0 && (window.clearTimeout(Ze), Ze = void 0), Ft !== void 0 && (window.clearTimeout(Ft), Ft = void 0), St !== void 0 && (window.clearTimeout(St), St = void 0), di(), Se !== void 0 && (window.clearTimeout(Se), Se = void 0), mi(), $ != null && $.path && (re = $.position_ms, Vt(), $ = null, B = [], O = -1, d("player_stop").catch(() => {
  })), Ot && (Ot(), Ot = null), zt = [], ei = !1, ou(), pu();
}
window.__lunac_music_stop = Ro;
const Oo = {
  id: "music",
  name: "音乐歌词",
  keywords: ["音乐", "歌词", "歌曲", "正在播放", "music", "lyrics", "spotify", "播放控制", "暂停", "下一首", "歌单", "播放列表"],
  description: "歌词自动抓取 (LRCLIB + 网易云兜底) + Spotify 播放控制 / 歌单 / 队列",
  icon: "🎵",
  badge: "music",
  // 「本插件一律在**悬浮窗**里打开」（2026-09-29 从 main.ts 的硬编码 `id === "music"` 改成声明）。
  // 为什么要声明而不是让宿主按 id 判：音乐已归入**拓展插件**，要能从市场独立打包分发
  // —— 磁盘插件的代码宿主没法写死，行为只能由插件自己声明（见 ai-spec §3.5「插件契约」）。
  // 这也是「用户 2026-09-28 定的：从 Lunac 进音乐界面时自动展开成独立界面」那条的执行点。
  permissions: ["window.float"],
  async execute() {
    return { type: "html", content: Tc ? nu() : au() };
  }
};
export {
  Po as attach,
  Po as attachMusicListeners,
  Oo as default,
  Ro as detach,
  Oo as musicPlugin,
  Ro as stopMusicPolling
};
