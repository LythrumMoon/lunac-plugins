const Jc = "__lunac_host";
function Xc() {
  return globalThis[Jc] ?? null;
}
function a(t, e) {
  const i = Xc();
  return i && typeof i.t == "function" ? i.t(t, e) : t;
}
function Kc(t, e, i, s) {
  if (typeof e == "function" ? t !== e || !s : !e.has(t)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? s : i === "a" ? s.call(t) : s ? s.value : e.get(t);
}
function Zc(t, e, i, s, n) {
  if (typeof e == "function" ? t !== e || !0 : !e.has(t)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return e.set(t, i), i;
}
var cs;
const Ie = "__TAURI_TO_IPC_KEY__";
function el(t, e = !1) {
  return window.__TAURI_INTERNALS__.transformCallback(t, e);
}
async function r(t, e = {}, i) {
  return window.__TAURI_INTERNALS__.invoke(t, e, i);
}
function Es(t, e = "asset") {
  return window.__TAURI_INTERNALS__.convertFileSrc(t, e);
}
class tl {
  get rid() {
    return Kc(this, cs, "f");
  }
  constructor(e) {
    cs.set(this, void 0), Zc(this, cs, e);
  }
  /**
   * Destroys and cleans up this resource from memory.
   * **You should not call any method on this object anymore and should drop any reference to it.**
   */
  async close() {
    return r("plugin:resources|close", {
      rid: this.rid
    });
  }
}
cs = /* @__PURE__ */ new WeakMap();
var _e;
(function(t) {
  t.WINDOW_RESIZED = "tauri://resize", t.WINDOW_MOVED = "tauri://move", t.WINDOW_CLOSE_REQUESTED = "tauri://close-requested", t.WINDOW_DESTROYED = "tauri://destroyed", t.WINDOW_FOCUS = "tauri://focus", t.WINDOW_BLUR = "tauri://blur", t.WINDOW_SCALE_FACTOR_CHANGED = "tauri://scale-change", t.WINDOW_THEME_CHANGED = "tauri://theme-changed", t.WINDOW_CREATED = "tauri://window-created", t.WINDOW_SUSPENDED = "tauri://suspended", t.WINDOW_RESUMED = "tauri://resumed", t.WEBVIEW_CREATED = "tauri://webview-created", t.DRAG_ENTER = "tauri://drag-enter", t.DRAG_OVER = "tauri://drag-over", t.DRAG_DROP = "tauri://drag-drop", t.DRAG_LEAVE = "tauri://drag-leave";
})(_e || (_e = {}));
async function ac(t, e) {
  window.__TAURI_EVENT_PLUGIN_INTERNALS__.unregisterListener(t, e), await r("plugin:event|unlisten", {
    event: t,
    eventId: e
  });
}
async function ln(t, e, i) {
  var s;
  const n = typeof (i == null ? void 0 : i.target) == "string" ? { kind: "AnyLabel", label: i.target } : (s = i == null ? void 0 : i.target) !== null && s !== void 0 ? s : { kind: "Any" };
  return r("plugin:event|listen", {
    event: t,
    target: n,
    handler: el(e)
  }).then((c) => async () => ac(t, c));
}
async function il(t, e, i) {
  return ln(t, (s) => {
    ac(t, s.id), e(s);
  }, i);
}
async function sl(t, e) {
  await r("plugin:event|emit", {
    event: t,
    payload: e
  });
}
async function nl(t, e, i) {
  await r("plugin:event|emit_to", {
    target: typeof t == "string" ? { kind: "AnyLabel", label: t } : t,
    event: e,
    payload: i
  });
}
async function al(t, e) {
  await r("plugin:shell|open", {
    path: t,
    with: e
  });
}
class Li extends tl {
  /**
   * Creates an Image from a resource ID. For internal use only.
   *
   * @ignore
   */
  constructor(e) {
    super(e);
  }
  /** Creates a new Image using RGBA data, in row-major order from top to bottom, and with specified width and height. */
  static async new(e, i, s) {
    return r("plugin:image|new", {
      rgba: gs(e),
      width: i,
      height: s
    }).then((n) => new Li(n));
  }
  /**
   * Creates a new image using the provided bytes by inferring the file format.
   * If the format is known, prefer [@link Image.fromPngBytes] or [@link Image.fromIcoBytes].
   *
   * Only `ico` and `png` are supported (based on activated feature flag).
   *
   * Note that you need the `image-ico` or `image-png` Cargo features to use this API.
   * To enable it, change your Cargo.toml file:
   * ```toml
   * [dependencies]
   * tauri = { version = "...", features = ["...", "image-png"] }
   * ```
   */
  static async fromBytes(e) {
    return r("plugin:image|from_bytes", {
      bytes: gs(e)
    }).then((i) => new Li(i));
  }
  /**
   * Creates a new image using the provided path.
   *
   * Only `ico` and `png` are supported (based on activated feature flag).
   *
   * Note that you need the `image-ico` or `image-png` Cargo features to use this API.
   * To enable it, change your Cargo.toml file:
   * ```toml
   * [dependencies]
   * tauri = { version = "...", features = ["...", "image-png"] }
   * ```
   */
  static async fromPath(e) {
    return r("plugin:image|from_path", { path: e }).then((i) => new Li(i));
  }
  /** Returns the RGBA data for this image, in row-major order from top to bottom.  */
  async rgba() {
    return r("plugin:image|rgba", {
      rid: this.rid
    }).then((e) => new Uint8Array(e));
  }
  /** Returns the size of this image.  */
  async size() {
    return r("plugin:image|size", { rid: this.rid });
  }
}
function gs(t) {
  return t == null ? null : typeof t == "string" ? t : t instanceof Li ? t.rid : t;
}
async function cl(t, e) {
  await r("plugin:clipboard-manager|write_text", {
    label: e == null ? void 0 : e.label,
    text: t
  });
}
async function Xi(t = {}) {
  return typeof t == "object" && Object.freeze(t), await r("plugin:dialog|open", { options: t });
}
async function ll(t = {}) {
  return typeof t == "object" && Object.freeze(t), await r("plugin:dialog|save", { options: t });
}
class cc {
  constructor(...e) {
    this.type = "Logical", e.length === 1 ? "Logical" in e[0] ? (this.width = e[0].Logical.width, this.height = e[0].Logical.height) : (this.width = e[0].width, this.height = e[0].height) : (this.width = e[0], this.height = e[1]);
  }
  /**
   * Converts the logical size to a physical one.
   * @example
   * ```typescript
   * import { LogicalSize } from '@tauri-apps/api/dpi';
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   *
   * const appWindow = getCurrentWindow();
   * const factor = await appWindow.scaleFactor();
   * const size = new LogicalSize(400, 500);
   * const physical = size.toPhysical(factor);
   * ```
   *
   * @since 2.0.0
   */
  toPhysical(e) {
    return new Ei(this.width * e, this.height * e);
  }
  [Ie]() {
    return {
      width: this.width,
      height: this.height
    };
  }
  toJSON() {
    return this[Ie]();
  }
}
class Ei {
  constructor(...e) {
    this.type = "Physical", e.length === 1 ? "Physical" in e[0] ? (this.width = e[0].Physical.width, this.height = e[0].Physical.height) : (this.width = e[0].width, this.height = e[0].height) : (this.width = e[0], this.height = e[1]);
  }
  /**
   * Converts the physical size to a logical one.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const appWindow = getCurrentWindow();
   * const factor = await appWindow.scaleFactor();
   * const size = await appWindow.innerSize(); // PhysicalSize
   * const logical = size.toLogical(factor);
   * ```
   */
  toLogical(e) {
    return new cc(this.width / e, this.height / e);
  }
  [Ie]() {
    return {
      width: this.width,
      height: this.height
    };
  }
  toJSON() {
    return this[Ie]();
  }
}
class Ft {
  constructor(e) {
    this.size = e;
  }
  toLogical(e) {
    return this.size instanceof cc ? this.size : this.size.toLogical(e);
  }
  toPhysical(e) {
    return this.size instanceof Ei ? this.size : this.size.toPhysical(e);
  }
  [Ie]() {
    return {
      [`${this.size.type}`]: {
        width: this.size.width,
        height: this.size.height
      }
    };
  }
  toJSON() {
    return this[Ie]();
  }
}
class lc {
  constructor(...e) {
    this.type = "Logical", e.length === 1 ? "Logical" in e[0] ? (this.x = e[0].Logical.x, this.y = e[0].Logical.y) : (this.x = e[0].x, this.y = e[0].y) : (this.x = e[0], this.y = e[1]);
  }
  /**
   * Converts the logical position to a physical one.
   * @example
   * ```typescript
   * import { LogicalPosition } from '@tauri-apps/api/dpi';
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   *
   * const appWindow = getCurrentWindow();
   * const factor = await appWindow.scaleFactor();
   * const position = new LogicalPosition(400, 500);
   * const physical = position.toPhysical(factor);
   * ```
   *
   * @since 2.0.0
   */
  toPhysical(e) {
    return new vt(this.x * e, this.y * e);
  }
  [Ie]() {
    return {
      x: this.x,
      y: this.y
    };
  }
  toJSON() {
    return this[Ie]();
  }
}
class vt {
  constructor(...e) {
    this.type = "Physical", e.length === 1 ? "Physical" in e[0] ? (this.x = e[0].Physical.x, this.y = e[0].Physical.y) : (this.x = e[0].x, this.y = e[0].y) : (this.x = e[0], this.y = e[1]);
  }
  /**
   * Converts the physical position to a logical one.
   * @example
   * ```typescript
   * import { PhysicalPosition } from '@tauri-apps/api/dpi';
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   *
   * const appWindow = getCurrentWindow();
   * const factor = await appWindow.scaleFactor();
   * const position = new PhysicalPosition(400, 500);
   * const physical = position.toLogical(factor);
   * ```
   *
   * @since 2.0.0
   */
  toLogical(e) {
    return new lc(this.x / e, this.y / e);
  }
  [Ie]() {
    return {
      x: this.x,
      y: this.y
    };
  }
  toJSON() {
    return this[Ie]();
  }
}
class ts {
  constructor(e) {
    this.position = e;
  }
  toLogical(e) {
    return this.position instanceof lc ? this.position : this.position.toLogical(e);
  }
  toPhysical(e) {
    return this.position instanceof vt ? this.position : this.position.toPhysical(e);
  }
  [Ie]() {
    return {
      [`${this.position.type}`]: {
        x: this.position.x,
        y: this.position.y
      }
    };
  }
  toJSON() {
    return this[Ie]();
  }
}
var Vs;
(function(t) {
  t[t.Critical = 1] = "Critical", t[t.Informational = 2] = "Informational";
})(Vs || (Vs = {}));
class ul {
  constructor(e) {
    this._preventDefault = !1, this.event = e.event, this.id = e.id;
  }
  preventDefault() {
    this._preventDefault = !0;
  }
  isPreventDefault() {
    return this._preventDefault;
  }
}
var Ca;
(function(t) {
  t.None = "none", t.Normal = "normal", t.Indeterminate = "indeterminate", t.Paused = "paused", t.Error = "error";
})(Ca || (Ca = {}));
function uc() {
  return new oc(window.__TAURI_INTERNALS__.metadata.currentWindow.label, {
    // @ts-expect-error `skip` is not defined in the public API but it is handled by the constructor
    skip: !0
  });
}
async function Ds() {
  return r("plugin:window|get_all_windows").then((t) => t.map((e) => new oc(e, {
    // @ts-expect-error `skip` is not defined in the public API but it is handled by the constructor
    skip: !0
  })));
}
const Rs = ["tauri://created", "tauri://error"];
class oc {
  /**
   * Creates a new Window.
   * @example
   * ```typescript
   * import { Window } from '@tauri-apps/api/window';
   * const appWindow = new Window('my-label');
   * appWindow.once('tauri://created', function () {
   *  // window successfully created
   * });
   * appWindow.once('tauri://error', function (e) {
   *  // an error happened creating the window
   * });
   * ```
   *
   * @param label The unique window label. Must be alphanumeric: `a-zA-Z-/:_`.
   * @returns The {@link Window} instance to communicate with the window.
   */
  constructor(e, i = {}) {
    var s;
    this.label = e, this.listeners = /* @__PURE__ */ Object.create(null), i != null && i.skip || r("plugin:window|create", {
      options: {
        ...i,
        parent: typeof i.parent == "string" ? i.parent : (s = i.parent) === null || s === void 0 ? void 0 : s.label,
        label: e
      }
    }).then(async () => this.emit("tauri://created")).catch(async (n) => this.emit("tauri://error", n));
  }
  /**
   * Gets the Window associated with the given label.
   * @example
   * ```typescript
   * import { Window } from '@tauri-apps/api/window';
   * const mainWindow = Window.getByLabel('main');
   * ```
   *
   * @param label The window label.
   * @returns The Window instance to communicate with the window or null if the window doesn't exist.
   */
  static async getByLabel(e) {
    var i;
    return (i = (await Ds()).find((s) => s.label === e)) !== null && i !== void 0 ? i : null;
  }
  /**
   * Get an instance of `Window` for the current window.
   */
  static getCurrent() {
    return uc();
  }
  /**
   * Gets a list of instances of `Window` for all available windows.
   */
  static async getAll() {
    return Ds();
  }
  /**
   *  Gets the focused window.
   * @example
   * ```typescript
   * import { Window } from '@tauri-apps/api/window';
   * const focusedWindow = Window.getFocusedWindow();
   * ```
   *
   * @returns The Window instance or `undefined` if there is not any focused window.
   */
  static async getFocusedWindow() {
    for (const e of await Ds())
      if (await e.isFocused())
        return e;
    return null;
  }
  /**
   * Listen to an emitted event on this window.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const unlisten = await getCurrentWindow().listen<string>('state-changed', (event) => {
   *   console.log(`Got error: ${payload}`);
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @param event Event name. Must include only alphanumeric characters, `-`, `/`, `:` and `_`.
   * @param handler Event handler.
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async listen(e, i) {
    return this._handleTauriEvent(e, i) ? () => {
      const s = this.listeners[e];
      s.splice(s.indexOf(i), 1);
    } : ln(e, i, {
      target: { kind: "Window", label: this.label }
    });
  }
  /**
   * Listen to an emitted event on this window only once.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const unlisten = await getCurrentWindow().once<null>('initialized', (event) => {
   *   console.log(`Window initialized!`);
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @param event Event name. Must include only alphanumeric characters, `-`, `/`, `:` and `_`.
   * @param handler Event handler.
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async once(e, i) {
    return this._handleTauriEvent(e, i) ? () => {
      const s = this.listeners[e];
      s.splice(s.indexOf(i), 1);
    } : il(e, i, {
      target: { kind: "Window", label: this.label }
    });
  }
  /**
   * Emits an event to all {@link EventTarget|targets}.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().emit('window-loaded', { loggedIn: true, token: 'authToken' });
   * ```
   *
   * @param event Event name. Must include only alphanumeric characters, `-`, `/`, `:` and `_`.
   * @param payload Event payload.
   */
  async emit(e, i) {
    if (Rs.includes(e)) {
      for (const s of this.listeners[e] || [])
        s({
          event: e,
          id: -1,
          payload: i
        });
      return;
    }
    return sl(e, i);
  }
  /**
   * Emits an event to all {@link EventTarget|targets} matching the given target.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().emit('main', 'window-loaded', { loggedIn: true, token: 'authToken' });
   * ```
   * @param target Label of the target Window/Webview/WebviewWindow or raw {@link EventTarget} object.
   * @param event Event name. Must include only alphanumeric characters, `-`, `/`, `:` and `_`.
   * @param payload Event payload.
   */
  async emitTo(e, i, s) {
    if (Rs.includes(i)) {
      for (const n of this.listeners[i] || [])
        n({
          event: i,
          id: -1,
          payload: s
        });
      return;
    }
    return nl(e, i, s);
  }
  /** @ignore */
  _handleTauriEvent(e, i) {
    return Rs.includes(e) ? (e in this.listeners ? this.listeners[e].push(i) : this.listeners[e] = [i], !0) : !1;
  }
  // Getters
  /**
   * The scale factor that can be used to map physical pixels to logical pixels.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const factor = await getCurrentWindow().scaleFactor();
   * ```
   *
   * @returns The window's monitor scale factor.
   */
  async scaleFactor() {
    return r("plugin:window|scale_factor", {
      label: this.label
    });
  }
  /**
   * The position of the top-left hand corner of the window's client area relative to the top-left hand corner of the desktop.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const position = await getCurrentWindow().innerPosition();
   * ```
   *
   * @returns The window's inner position.
   */
  async innerPosition() {
    return r("plugin:window|inner_position", {
      label: this.label
    }).then((e) => new vt(e));
  }
  /**
   * The position of the top-left hand corner of the window relative to the top-left hand corner of the desktop.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const position = await getCurrentWindow().outerPosition();
   * ```
   *
   * @returns The window's outer position.
   */
  async outerPosition() {
    return r("plugin:window|outer_position", {
      label: this.label
    }).then((e) => new vt(e));
  }
  /**
   * The physical size of the window's client area.
   * The client area is the content of the window, excluding the title bar and borders.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const size = await getCurrentWindow().innerSize();
   * ```
   *
   * @returns The window's inner size.
   */
  async innerSize() {
    return r("plugin:window|inner_size", {
      label: this.label
    }).then((e) => new Ei(e));
  }
  /**
   * The physical size of the entire window.
   * These dimensions include the title bar and borders. If you don't want that (and you usually don't), use inner_size instead.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const size = await getCurrentWindow().outerSize();
   * ```
   *
   * @returns The window's outer size.
   */
  async outerSize() {
    return r("plugin:window|outer_size", {
      label: this.label
    }).then((e) => new Ei(e));
  }
  /**
   * Gets the window's current fullscreen state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const fullscreen = await getCurrentWindow().isFullscreen();
   * ```
   *
   * @returns Whether the window is in fullscreen mode or not.
   */
  async isFullscreen() {
    return r("plugin:window|is_fullscreen", {
      label: this.label
    });
  }
  /**
   * Gets the window's current minimized state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const minimized = await getCurrentWindow().isMinimized();
   * ```
   */
  async isMinimized() {
    return r("plugin:window|is_minimized", {
      label: this.label
    });
  }
  /**
   * Gets the window's current maximized state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const maximized = await getCurrentWindow().isMaximized();
   * ```
   *
   * @returns Whether the window is maximized or not.
   */
  async isMaximized() {
    return r("plugin:window|is_maximized", {
      label: this.label
    });
  }
  /**
   * Gets the window's current focus state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const focused = await getCurrentWindow().isFocused();
   * ```
   *
   * @returns Whether the window is focused or not.
   */
  async isFocused() {
    return r("plugin:window|is_focused", {
      label: this.label
    });
  }
  /**
   * Gets the window's current decorated state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const decorated = await getCurrentWindow().isDecorated();
   * ```
   *
   * @returns Whether the window is decorated or not.
   */
  async isDecorated() {
    return r("plugin:window|is_decorated", {
      label: this.label
    });
  }
  /**
   * Gets the window's current resizable state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const resizable = await getCurrentWindow().isResizable();
   * ```
   *
   * @returns Whether the window is resizable or not.
   */
  async isResizable() {
    return r("plugin:window|is_resizable", {
      label: this.label
    });
  }
  /**
   * Gets the window's native maximize button state.
   *
   * #### Platform-specific
   *
   * - **Linux / iOS / Android:** Unsupported.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const maximizable = await getCurrentWindow().isMaximizable();
   * ```
   *
   * @returns Whether the window's native maximize button is enabled or not.
   */
  async isMaximizable() {
    return r("plugin:window|is_maximizable", {
      label: this.label
    });
  }
  /**
   * Gets the window's native minimize button state.
   *
   * #### Platform-specific
   *
   * - **Linux / iOS / Android:** Unsupported.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const minimizable = await getCurrentWindow().isMinimizable();
   * ```
   *
   * @returns Whether the window's native minimize button is enabled or not.
   */
  async isMinimizable() {
    return r("plugin:window|is_minimizable", {
      label: this.label
    });
  }
  /**
   * Gets the window's native close button state.
   *
   * #### Platform-specific
   *
   * - **iOS / Android:** Unsupported.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const closable = await getCurrentWindow().isClosable();
   * ```
   *
   * @returns Whether the window's native close button is enabled or not.
   */
  async isClosable() {
    return r("plugin:window|is_closable", {
      label: this.label
    });
  }
  /**
   * Gets the window's current visible state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const visible = await getCurrentWindow().isVisible();
   * ```
   *
   * @returns Whether the window is visible or not.
   */
  async isVisible() {
    return r("plugin:window|is_visible", {
      label: this.label
    });
  }
  /**
   * Gets the window's current title.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const title = await getCurrentWindow().title();
   * ```
   */
  async title() {
    return r("plugin:window|title", {
      label: this.label
    });
  }
  /**
   * Gets the window's current theme.
   *
   * #### Platform-specific
   *
   * - **macOS:** Theme was introduced on macOS 10.14. Returns `light` on macOS 10.13 and below.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const theme = await getCurrentWindow().theme();
   * ```
   *
   * @returns The window theme.
   */
  async theme() {
    return r("plugin:window|theme", {
      label: this.label
    });
  }
  /**
   * Whether the window is configured to be always on top of other windows or not.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const alwaysOnTop = await getCurrentWindow().isAlwaysOnTop();
   * ```
   *
   * @returns Whether the window is visible or not.
   */
  async isAlwaysOnTop() {
    return r("plugin:window|is_always_on_top", {
      label: this.label
    });
  }
  async activityName() {
    return r("plugin:window|activity_name", {
      label: this.label
    });
  }
  async sceneIdentifier() {
    return r("plugin:window|scene_identifier", {
      label: this.label
    });
  }
  // Setters
  /**
   * Centers the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().center();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async center() {
    return r("plugin:window|center", {
      label: this.label
    });
  }
  /**
   *  Requests user attention to the window, this has no effect if the application
   * is already focused. How requesting for user attention manifests is platform dependent,
   * see `UserAttentionType` for details.
   *
   * Providing `null` will unset the request for user attention. Unsetting the request for
   * user attention might not be done automatically by the WM when the window receives input.
   *
   * #### Platform-specific
   *
   * - **macOS:** `null` has no effect.
   * - **Linux:** Urgency levels have the same effect.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().requestUserAttention();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async requestUserAttention(e) {
    let i = null;
    return e && (e === Vs.Critical ? i = { type: "Critical" } : i = { type: "Informational" }), r("plugin:window|request_user_attention", {
      label: this.label,
      value: i
    });
  }
  /**
   * Updates the window resizable flag.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setResizable(false);
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async setResizable(e) {
    return r("plugin:window|set_resizable", {
      label: this.label,
      value: e
    });
  }
  /**
   * Enable or disable the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setEnabled(false);
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   *
   * @since 2.0.0
   */
  async setEnabled(e) {
    return r("plugin:window|set_enabled", {
      label: this.label,
      value: e
    });
  }
  /**
   * Whether the window is enabled or disabled.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setEnabled(false);
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   *
   * @since 2.0.0
   */
  async isEnabled() {
    return r("plugin:window|is_enabled", {
      label: this.label
    });
  }
  /**
   * Sets whether the window's native maximize button is enabled or not.
   * If resizable is set to false, this setting is ignored.
   *
   * #### Platform-specific
   *
   * - **macOS:** Disables the "zoom" button in the window titlebar, which is also used to enter fullscreen mode.
   * - **Linux / iOS / Android:** Unsupported.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setMaximizable(false);
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async setMaximizable(e) {
    return r("plugin:window|set_maximizable", {
      label: this.label,
      value: e
    });
  }
  /**
   * Sets whether the window's native minimize button is enabled or not.
   *
   * #### Platform-specific
   *
   * - **Linux / iOS / Android:** Unsupported.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setMinimizable(false);
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async setMinimizable(e) {
    return r("plugin:window|set_minimizable", {
      label: this.label,
      value: e
    });
  }
  /**
   * Sets whether the window's native close button is enabled or not.
   *
   * #### Platform-specific
   *
   * - **Linux:** GTK+ will do its best to convince the window manager not to show a close button. Depending on the system, this function may not have any effect when called on a window that is already visible
   * - **iOS / Android:** Unsupported.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setClosable(false);
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async setClosable(e) {
    return r("plugin:window|set_closable", {
      label: this.label,
      value: e
    });
  }
  /**
   * Sets the window title.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setTitle('Tauri');
   * ```
   *
   * @param title The new title
   * @returns A promise indicating the success or failure of the operation.
   */
  async setTitle(e) {
    return r("plugin:window|set_title", {
      label: this.label,
      value: e
    });
  }
  /**
   * Maximizes the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().maximize();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async maximize() {
    return r("plugin:window|maximize", {
      label: this.label
    });
  }
  /**
   * Unmaximizes the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().unmaximize();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async unmaximize() {
    return r("plugin:window|unmaximize", {
      label: this.label
    });
  }
  /**
   * Toggles the window maximized state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().toggleMaximize();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async toggleMaximize() {
    return r("plugin:window|toggle_maximize", {
      label: this.label
    });
  }
  /**
   * Minimizes the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().minimize();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async minimize() {
    return r("plugin:window|minimize", {
      label: this.label
    });
  }
  /**
   * Unminimizes the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().unminimize();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async unminimize() {
    return r("plugin:window|unminimize", {
      label: this.label
    });
  }
  /**
   * Sets the window visibility to true.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().show();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async show() {
    return r("plugin:window|show", {
      label: this.label
    });
  }
  /**
   * Sets the window visibility to false.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().hide();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async hide() {
    return r("plugin:window|hide", {
      label: this.label
    });
  }
  /**
   * Closes the window.
   *
   * Note this emits a closeRequested event so you can intercept it. To force window close, use {@link Window.destroy}.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().close();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async close() {
    return r("plugin:window|close", {
      label: this.label
    });
  }
  /**
   * Destroys the window. Behaves like {@link Window.close} but forces the window close instead of emitting a closeRequested event.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().destroy();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async destroy() {
    return r("plugin:window|destroy", {
      label: this.label
    });
  }
  /**
   * Whether the window should have borders and bars.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setDecorations(false);
   * ```
   *
   * @param decorations Whether the window should have borders and bars.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setDecorations(e) {
    return r("plugin:window|set_decorations", {
      label: this.label,
      value: e
    });
  }
  /**
   * Whether or not the window should have shadow.
   *
   * #### Platform-specific
   *
   * - **Windows:**
   *   - `false` has no effect on decorated window, shadows are always ON.
   *   - `true` will make undecorated window have a 1px white border,
   * and on Windows 11, it will have a rounded corners.
   * - **Linux:** Unsupported.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setShadow(false);
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async setShadow(e) {
    return r("plugin:window|set_shadow", {
      label: this.label,
      value: e
    });
  }
  /**
   * Set window effects.
   */
  async setEffects(e) {
    return r("plugin:window|set_effects", {
      label: this.label,
      value: e
    });
  }
  /**
   * Clear any applied effects if possible.
   */
  async clearEffects() {
    return r("plugin:window|set_effects", {
      label: this.label,
      value: null
    });
  }
  /**
   * Whether the window should always be on top of other windows.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setAlwaysOnTop(true);
   * ```
   *
   * @param alwaysOnTop Whether the window should always be on top of other windows or not.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setAlwaysOnTop(e) {
    return r("plugin:window|set_always_on_top", {
      label: this.label,
      value: e
    });
  }
  /**
   * Whether the window should always be below other windows.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setAlwaysOnBottom(true);
   * ```
   *
   * @param alwaysOnBottom Whether the window should always be below other windows or not.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setAlwaysOnBottom(e) {
    return r("plugin:window|set_always_on_bottom", {
      label: this.label,
      value: e
    });
  }
  /**
   * Prevents the window contents from being captured by other apps.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setContentProtected(true);
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async setContentProtected(e) {
    return r("plugin:window|set_content_protected", {
      label: this.label,
      value: e
    });
  }
  /**
   * Resizes the window with a new inner size.
   * @example
   * ```typescript
   * import { getCurrentWindow, LogicalSize } from '@tauri-apps/api/window';
   * await getCurrentWindow().setSize(new LogicalSize(600, 500));
   * ```
   *
   * @param size The logical or physical inner size.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setSize(e) {
    return r("plugin:window|set_size", {
      label: this.label,
      value: e instanceof Ft ? e : new Ft(e)
    });
  }
  /**
   * Sets the window minimum inner size. If the `size` argument is not provided, the constraint is unset.
   * @example
   * ```typescript
   * import { getCurrentWindow, PhysicalSize } from '@tauri-apps/api/window';
   * await getCurrentWindow().setMinSize(new PhysicalSize(600, 500));
   * ```
   *
   * @param size The logical or physical inner size, or `null` to unset the constraint.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setMinSize(e) {
    return r("plugin:window|set_min_size", {
      label: this.label,
      value: e instanceof Ft ? e : e ? new Ft(e) : null
    });
  }
  /**
   * Sets the window maximum inner size. If the `size` argument is undefined, the constraint is unset.
   * @example
   * ```typescript
   * import { getCurrentWindow, LogicalSize } from '@tauri-apps/api/window';
   * await getCurrentWindow().setMaxSize(new LogicalSize(600, 500));
   * ```
   *
   * @param size The logical or physical inner size, or `null` to unset the constraint.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setMaxSize(e) {
    return r("plugin:window|set_max_size", {
      label: this.label,
      value: e instanceof Ft ? e : e ? new Ft(e) : null
    });
  }
  /**
   * Sets the window inner size constraints.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setSizeConstraints({ minWidth: 300 });
   * ```
   *
   * @param constraints The logical or physical inner size, or `null` to unset the constraint.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setSizeConstraints(e) {
    function i(s) {
      return s ? { Logical: s } : null;
    }
    return r("plugin:window|set_size_constraints", {
      label: this.label,
      value: {
        minWidth: i(e == null ? void 0 : e.minWidth),
        minHeight: i(e == null ? void 0 : e.minHeight),
        maxWidth: i(e == null ? void 0 : e.maxWidth),
        maxHeight: i(e == null ? void 0 : e.maxHeight)
      }
    });
  }
  /**
   * Sets the window outer position.
   * @example
   * ```typescript
   * import { getCurrentWindow, LogicalPosition } from '@tauri-apps/api/window';
   * await getCurrentWindow().setPosition(new LogicalPosition(600, 500));
   * ```
   *
   * @param position The new position, in logical or physical pixels.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setPosition(e) {
    return r("plugin:window|set_position", {
      label: this.label,
      value: e instanceof ts ? e : new ts(e)
    });
  }
  /**
   * Sets the window fullscreen state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setFullscreen(true);
   * ```
   *
   * @param fullscreen Whether the window should go to fullscreen or not.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setFullscreen(e) {
    return r("plugin:window|set_fullscreen", {
      label: this.label,
      value: e
    });
  }
  /**
   * On macOS, Toggles a fullscreen mode that doesn’t require a new macOS space. Returns a boolean indicating whether the transition was successful (this won’t work if the window was already in the native fullscreen).
   * This is how fullscreen used to work on macOS in versions before Lion. And allows the user to have a fullscreen window without using another space or taking control over the entire monitor.
   *
   * On other platforms, this is the same as {@link Window.setFullscreen}.
   *
   * @param fullscreen Whether the window should go to simple fullscreen or not.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setSimpleFullscreen(e) {
    return r("plugin:window|set_simple_fullscreen", {
      label: this.label,
      value: e
    });
  }
  /**
   * Bring the window to front and focus.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setFocus();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async setFocus() {
    return r("plugin:window|set_focus", {
      label: this.label
    });
  }
  /**
   * Sets whether the window can be focused.
   *
   * #### Platform-specific
   *
   * - **macOS**: If the window is already focused, it is not possible to unfocus it after calling `set_focusable(false)`.
   *   In this case, you might consider calling {@link Window.setFocus} but it will move the window to the back i.e. at the bottom in terms of z-order.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setFocusable(true);
   * ```
   *
   * @param focusable Whether the window can be focused.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setFocusable(e) {
    return r("plugin:window|set_focusable", {
      label: this.label,
      value: e
    });
  }
  /**
   * Sets the window icon.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setIcon('/tauri/awesome.png');
   * ```
   *
   * Note that you may need the `image-ico` or `image-png` Cargo features to use this API.
   * To enable it, change your Cargo.toml file:
   * ```toml
   * [dependencies]
   * tauri = { version = "...", features = ["...", "image-png"] }
   * ```
   *
   * @param icon Icon bytes or path to the icon file.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setIcon(e) {
    return r("plugin:window|set_icon", {
      label: this.label,
      value: gs(e)
    });
  }
  /**
   * Whether the window icon should be hidden from the taskbar or not.
   *
   * #### Platform-specific
   *
   * - **macOS:** Unsupported.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setSkipTaskbar(true);
   * ```
   *
   * @param skip true to hide window icon, false to show it.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setSkipTaskbar(e) {
    return r("plugin:window|set_skip_taskbar", {
      label: this.label,
      value: e
    });
  }
  /**
   * Grabs the cursor, preventing it from leaving the window.
   *
   * There's no guarantee that the cursor will be hidden. You should
   * hide it by yourself if you want so.
   *
   * #### Platform-specific
   *
   * - **Linux:** Unsupported.
   * - **macOS:** This locks the cursor in a fixed location, which looks visually awkward.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setCursorGrab(true);
   * ```
   *
   * @param grab `true` to grab the cursor icon, `false` to release it.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setCursorGrab(e) {
    return r("plugin:window|set_cursor_grab", {
      label: this.label,
      value: e
    });
  }
  /**
   * Modifies the cursor's visibility.
   *
   * #### Platform-specific
   *
   * - **Windows:** The cursor is only hidden within the confines of the window.
   * - **macOS:** The cursor is hidden as long as the window has input focus, even if the cursor is
   *   outside of the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setCursorVisible(false);
   * ```
   *
   * @param visible If `false`, this will hide the cursor. If `true`, this will show the cursor.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setCursorVisible(e) {
    return r("plugin:window|set_cursor_visible", {
      label: this.label,
      value: e
    });
  }
  /**
   * Modifies the cursor icon of the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setCursorIcon('help');
   * ```
   *
   * @param icon The new cursor icon.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setCursorIcon(e) {
    return r("plugin:window|set_cursor_icon", {
      label: this.label,
      value: e
    });
  }
  /**
   * Sets the window background color.
   *
   * #### Platform-specific:
   *
   * - **Windows:** alpha channel is ignored.
   * - **iOS / Android:** Unsupported.
   *
   * @returns A promise indicating the success or failure of the operation.
   *
   * @since 2.1.0
   */
  async setBackgroundColor(e) {
    return r("plugin:window|set_background_color", { color: e });
  }
  /**
   * Changes the position of the cursor in window coordinates.
   * @example
   * ```typescript
   * import { getCurrentWindow, LogicalPosition } from '@tauri-apps/api/window';
   * await getCurrentWindow().setCursorPosition(new LogicalPosition(600, 300));
   * ```
   *
   * @param position The new cursor position.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setCursorPosition(e) {
    return r("plugin:window|set_cursor_position", {
      label: this.label,
      value: e instanceof ts ? e : new ts(e)
    });
  }
  /**
   * Changes the cursor events behavior.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setIgnoreCursorEvents(true);
   * ```
   *
   * @param ignore `true` to ignore the cursor events; `false` to process them as usual.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setIgnoreCursorEvents(e) {
    return r("plugin:window|set_ignore_cursor_events", {
      label: this.label,
      value: e
    });
  }
  /**
   * Starts dragging the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().startDragging();
   * ```
   *
   * @return A promise indicating the success or failure of the operation.
   */
  async startDragging() {
    return r("plugin:window|start_dragging", {
      label: this.label
    });
  }
  /**
   * Starts resize-dragging the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().startResizeDragging();
   * ```
   *
   * @return A promise indicating the success or failure of the operation.
   */
  async startResizeDragging(e) {
    return r("plugin:window|start_resize_dragging", {
      label: this.label,
      value: e
    });
  }
  /**
   * Sets the badge count. It is app wide and not specific to this window.
   *
   * #### Platform-specific
   *
   * - **Windows**: Unsupported. Use @{linkcode Window.setOverlayIcon} instead.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setBadgeCount(5);
   * ```
   *
   * @param count The badge count. Use `undefined` to remove the badge.
   * @return A promise indicating the success or failure of the operation.
   */
  async setBadgeCount(e) {
    return r("plugin:window|set_badge_count", {
      label: this.label,
      value: e
    });
  }
  /**
   * Sets the badge cont **macOS only**.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setBadgeLabel("Hello");
   * ```
   *
   * @param label The badge label. Use `undefined` to remove the badge.
   * @return A promise indicating the success or failure of the operation.
   */
  async setBadgeLabel(e) {
    return r("plugin:window|set_badge_label", {
      label: this.label,
      value: e
    });
  }
  /**
   * Sets the overlay icon. **Windows only**
   * The overlay icon can be set for every window.
   *
   *
   * Note that you may need the `image-ico` or `image-png` Cargo features to use this API.
   * To enable it, change your Cargo.toml file:
   *
   * ```toml
   * [dependencies]
   * tauri = { version = "...", features = ["...", "image-png"] }
   * ```
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setOverlayIcon("/tauri/awesome.png");
   * ```
   *
   * @param icon Icon bytes or path to the icon file. Use `undefined` to remove the overlay icon.
   * @return A promise indicating the success or failure of the operation.
   */
  async setOverlayIcon(e) {
    return r("plugin:window|set_overlay_icon", {
      label: this.label,
      value: e ? gs(e) : void 0
    });
  }
  /**
   * Sets the taskbar progress state.
   *
   * #### Platform-specific
   *
   * - **Linux / macOS**: Progress bar is app-wide and not specific to this window.
   * - **Linux**: Only supported desktop environments with `libunity` (e.g. GNOME).
   *
   * @example
   * ```typescript
   * import { getCurrentWindow, ProgressBarStatus } from '@tauri-apps/api/window';
   * await getCurrentWindow().setProgressBar({
   *   status: ProgressBarStatus.Normal,
   *   progress: 50,
   * });
   * ```
   *
   * @return A promise indicating the success or failure of the operation.
   */
  async setProgressBar(e) {
    return r("plugin:window|set_progress_bar", {
      label: this.label,
      value: e
    });
  }
  /**
   * Sets whether the window should be visible on all workspaces or virtual desktops.
   *
   * #### Platform-specific
   *
   * - **Windows / iOS / Android:** Unsupported.
   *
   * @since 2.0.0
   */
  async setVisibleOnAllWorkspaces(e) {
    return r("plugin:window|set_visible_on_all_workspaces", {
      label: this.label,
      value: e
    });
  }
  /**
   * Sets the title bar style. **macOS only**.
   *
   * @since 2.0.0
   */
  async setTitleBarStyle(e) {
    return r("plugin:window|set_title_bar_style", {
      label: this.label,
      value: e
    });
  }
  /**
   * Set window theme, pass in `null` or `undefined` to follow system theme
   *
   * #### Platform-specific
   *
   * - **Linux / macOS**: Theme is app-wide and not specific to this window.
   * - **iOS / Android:** Unsupported.
   *
   * @since 2.0.0
   */
  async setTheme(e) {
    return r("plugin:window|set_theme", {
      label: this.label,
      value: e
    });
  }
  // Listeners
  /**
   * Listen to window resize.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from "@tauri-apps/api/window";
   * const unlisten = await getCurrentWindow().onResized(({ payload: size }) => {
   *  console.log('Window resized', size);
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async onResized(e) {
    return this.listen(_e.WINDOW_RESIZED, (i) => {
      i.payload = new Ei(i.payload), e(i);
    });
  }
  /**
   * Listen to window move.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from "@tauri-apps/api/window";
   * const unlisten = await getCurrentWindow().onMoved(({ payload: position }) => {
   *  console.log('Window moved', position);
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async onMoved(e) {
    return this.listen(_e.WINDOW_MOVED, (i) => {
      i.payload = new vt(i.payload), e(i);
    });
  }
  /**
   * Listen to window close requested. Emitted when the user requests to closes the window.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from "@tauri-apps/api/window";
   * import { confirm } from '@tauri-apps/api/dialog';
   * const unlisten = await getCurrentWindow().onCloseRequested(async (event) => {
   *   const confirmed = await confirm('Are you sure?');
   *   if (!confirmed) {
   *     // user did not confirm closing the window; let's prevent it
   *     event.preventDefault();
   *   }
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async onCloseRequested(e) {
    return this.listen(_e.WINDOW_CLOSE_REQUESTED, async (i) => {
      const s = new ul(i);
      await e(s), s.isPreventDefault() || await this.destroy();
    });
  }
  /**
   * Listen to a file drop event.
   * The listener is triggered when the user hovers the selected files on the webview,
   * drops the files or cancels the operation.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from "@tauri-apps/api/webview";
   * const unlisten = await getCurrentWindow().onDragDropEvent((event) => {
   *  if (event.payload.type === 'over') {
   *    console.log('User hovering', event.payload.position);
   *  } else if (event.payload.type === 'drop') {
   *    console.log('User dropped', event.payload.paths);
   *  } else {
   *    console.log('File drop cancelled');
   *  }
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async onDragDropEvent(e) {
    const i = await this.listen(_e.DRAG_ENTER, (d) => {
      e({
        ...d,
        payload: {
          type: "enter",
          paths: d.payload.paths,
          position: new vt(d.payload.position)
        }
      });
    }), s = await this.listen(_e.DRAG_OVER, (d) => {
      e({
        ...d,
        payload: {
          type: "over",
          position: new vt(d.payload.position)
        }
      });
    }), n = await this.listen(_e.DRAG_DROP, (d) => {
      e({
        ...d,
        payload: {
          type: "drop",
          paths: d.payload.paths,
          position: new vt(d.payload.position)
        }
      });
    }), c = await this.listen(_e.DRAG_LEAVE, (d) => {
      e({ ...d, payload: { type: "leave" } });
    });
    return () => {
      i(), n(), s(), c();
    };
  }
  /**
   * Listen to window focus change.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from "@tauri-apps/api/window";
   * const unlisten = await getCurrentWindow().onFocusChanged(({ payload: focused }) => {
   *  console.log('Focus changed, window is focused? ' + focused);
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async onFocusChanged(e) {
    const i = await this.listen(_e.WINDOW_FOCUS, (n) => {
      e({ ...n, payload: !0 });
    }), s = await this.listen(_e.WINDOW_BLUR, (n) => {
      e({ ...n, payload: !1 });
    });
    return () => {
      i(), s();
    };
  }
  /**
   * Listen to window scale change. Emitted when the window's scale factor has changed.
   * The following user actions can cause DPI changes:
   * - Changing the display's resolution.
   * - Changing the display's scale factor (e.g. in Control Panel on Windows).
   * - Moving the window to a display with a different scale factor.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from "@tauri-apps/api/window";
   * const unlisten = await getCurrentWindow().onScaleChanged(({ payload }) => {
   *  console.log('Scale changed', payload.scaleFactor, payload.size);
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async onScaleChanged(e) {
    return this.listen(_e.WINDOW_SCALE_FACTOR_CHANGED, e);
  }
  /**
   * Listen to the system theme change.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from "@tauri-apps/api/window";
   * const unlisten = await getCurrentWindow().onThemeChanged(({ payload: theme }) => {
   *  console.log('New theme: ' + theme);
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async onThemeChanged(e) {
    return this.listen(_e.WINDOW_THEME_CHANGED, e);
  }
}
var Aa;
(function(t) {
  t.Disabled = "disabled", t.Throttle = "throttle", t.Suspend = "suspend";
})(Aa || (Aa = {}));
var Ia;
(function(t) {
  t.Default = "default", t.FluentOverlay = "fluentOverlay";
})(Ia || (Ia = {}));
var Da;
(function(t) {
  t.AppearanceBased = "appearanceBased", t.Light = "light", t.Dark = "dark", t.MediumLight = "mediumLight", t.UltraDark = "ultraDark", t.Titlebar = "titlebar", t.Selection = "selection", t.Menu = "menu", t.Popover = "popover", t.Sidebar = "sidebar", t.HeaderView = "headerView", t.Sheet = "sheet", t.WindowBackground = "windowBackground", t.HudWindow = "hudWindow", t.FullScreenUI = "fullScreenUI", t.Tooltip = "tooltip", t.ContentBackground = "contentBackground", t.UnderWindowBackground = "underWindowBackground", t.UnderPageBackground = "underPageBackground", t.Mica = "mica", t.Blur = "blur", t.Acrylic = "acrylic", t.Tabbed = "tabbed", t.TabbedDark = "tabbedDark", t.TabbedLight = "tabbedLight";
})(Da || (Da = {}));
var Ra;
(function(t) {
  t.FollowsWindowActiveState = "followsWindowActiveState", t.Active = "active", t.Inactive = "inactive";
})(Ra || (Ra = {}));
const rc = "curve", ol = (() => {
  try {
    return uc().label;
  } catch {
    return "";
  }
})(), dc = ol.endsWith(`-${rc}`);
function rl(t) {
  return t === "top" ? "artist" : t;
}
const dl = {
  album: "spotify_albums",
  artist: "spotify_artists",
  show: "spotify_shows",
  top: "spotify_top_artists"
}, mc = ["L", "R", "C", "LFE", "SL", "SR", "BL", "BR"], Ns = 5e3, ml = 1280, pl = 720, fl = 550, vl = 300, pc = 180, fc = 520, bl = 4e3, hl = 450, yl = 800, vc = 5e3, gl = 200, _l = 15e3, wl = 500, kl = 500, Sl = 250, $l = 500, ql = 0.3, h = {
  play: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polygon points="6 4 20 12 6 20 6 4"/></svg>',
  pause: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="9" y1="4" x2="9" y2="20"/><line x1="15" y1="4" x2="15" y2="20"/></svg>',
  prev: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polygon points="19 5 9 12 19 19 19 5"/><line x1="5" y1="5" x2="5" y2="19"/></svg>',
  next: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polygon points="5 5 15 12 5 19 5 5"/><line x1="19" y1="5" x2="19" y2="19"/></svg>',
  /** 随机（关 / 随机共用这一个；「关」靠 `data-mode` 变暗区分）。 */
  shuffle: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="16 3 21 3 21 8"/><line x1="4" y1="20" x2="21" y2="3"/><polyline points="21 16 21 21 16 21"/><line x1="15" y1="15" x2="21" y2="21"/><line x1="4" y1="4" x2="9" y2="9"/></svg>',
  /** 循环（单曲循环；那个「1」由 CSS `::after` 加，SVG 里不写字）。 */
  repeat: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="17 1 21 5 17 9"/><path d="M3 11V9a4 4 0 0 1 4-4h14"/><polyline points="7 23 3 19 7 15"/><path d="M21 13v2a4 4 0 0 1-4 4H3"/></svg>',
  list: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="9" y1="6" x2="21" y2="6"/><line x1="9" y1="12" x2="21" y2="12"/><line x1="9" y1="18" x2="21" y2="18"/><circle cx="4" cy="6" r="1" fill="currentColor" stroke="none"/><circle cx="4" cy="12" r="1" fill="currentColor" stroke="none"/><circle cx="4" cy="18" r="1" fill="currentColor" stroke="none"/></svg>',
  /** 进播放界面。 */
  expand: '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 3 21 3 21 9"/><polyline points="9 21 3 21 3 15"/><line x1="21" y1="3" x2="14" y2="10"/><line x1="3" y1="21" x2="10" y2="14"/></svg>',
  /** 回默认界面。**唯一**的退出播放界面的入口 —— 播放停止不会自动退出。 */
  back: '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/><line x1="3" y1="12" x2="9" y2="12"/></svg>',
  chevron: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg>',
  copy: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15V5a2 2 0 0 1 2-2h10"/></svg>',
  link: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.5 1.5"/><path d="M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7L12 19"/></svg>',
  power: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M18.4 6.6a9 9 0 1 1-12.8 0"/><line x1="12" y1="2" x2="12" y2="12"/></svg>',
  gear: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>',
  volume: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M15.5 8.5a5 5 0 0 1 0 7"/></svg>',
  /** 工具条上的「设备」按钮（2026-09-28）。画成一台小音箱，比「显示器」更贴
   *  Spotify 那种「可选的播放设备」语义。 */
  speaker: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="2" width="14" height="20" rx="2"/><circle cx="12" cy="14" r="3.2"/><circle cx="12" cy="6" r="1" fill="currentColor" stroke="none"/></svg>',
  /** 实心心形（「我喜欢的歌曲」那块封面上的图案）。**这个是 `fill`，不是描边** ——
   *  它是一块封面图（Spotify 的收藏夹封面就是实心心 + 渐变底），不是可点按钮。 */
  heart: '<svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" stroke="none"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>',
  // ── 本地媒体库那一页用到的四个（2026-10-01）──
  /** 「本地音乐」入口 + 目录行（画成文件夹）。 */
  folder: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/></svg>',
  /** 「添加目录」。 */
  plus: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>',
  /** 移除一根目录（行尾那枚）。`music.pl-x` 用。 */
  x: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="6" y1="6" x2="18" y2="18"/><line x1="18" y1="6" x2="6" y2="18"/></svg>',
  /** 没有封面的曲目行左侧占位（一个八分音符）。 */
  note: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18V6l10-2v12"/><circle cx="6.5" cy="18" r="2.5"/><circle cx="16.5" cy="16" r="2.5"/></svg>',
  /** 「重新扫描」/「刷新」—— 画成环形箭头。 */
  refresh: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="21 3 21 9 15 9"/><path d="M20.4 14a8.5 8.5 0 1 1-1.6-7.5L21 9"/></svg>',
  /** 勾选（本地列表「自定义队列编辑态」里那一行被勾中的标记）。**路径逐字抄自
   *  icon-style.md §3 的「保存 ✓」** —— 与 SVG.edit / SVG.trash 同一条纪律：已有的图形不另画。 */
  check: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>',
  /** 「测量」—— 一条起伏的响应曲线（Lucide 的 `activity` 那一族的形状）。 */
  wave: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12h3l2.5-6 3.5 12 3-8 2 2h4"/></svg>',
  /** 编辑（改列表）。**路径逐字抄自 icon-style.md §3 的「编辑 ✎」** —— 规范里已经
   *  给好这条了，不许自己另画一条（§4.2 最后一条：已有的图形不要重复造路径）。 */
  edit: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 3a2.8 2.8 0 0 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/></svg>',
  /** 删除（垃圾桶）。**同样逐字抄自 icon-style.md §3** —— 它是危险操作，
   *  按 §4.2 用同风格线性图标 + 语义色（hover 变 `--red`，见 styles.css）。 */
  trash: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6M14 11v6M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>',
  /** 停止本地播放（本地播放条右端那枚）。**它与暂停不是一回事**：暂停留着这台
   *  音频设备，停止会把设备一起放掉（见 player.rs 的 `player_stop`）。 */
  stop: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="6" y="6" width="12" height="12" rx="1.5"/></svg>',
  /** 「本地与 Spotify 同时出声」那把开关（2026-10-01）。画成**两个相交的圆** ——
   *  「两路并存」最直白的图形（Lucide 里叫 `blend`）。**不画成两个喇叭**：12px 下
   *  两个喇叭会糊成一团，而两个圆在任何尺寸下都认得出来。
   *  开关的「开着」不用第二个图形表达，靠 `.on` 的强调色（与其他开关一致）。 */
  dual: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="9" r="6.5"/><circle cx="15" cy="15" r="6.5"/></svg>',
  /** 「最常听的歌曲」那一行的图标（2026-10-01 用户第 4 条）。画成一条上扬的折线
   *  —— 「最常听 / 热度」最直白的图形（Lucide 的 `trending-up`，与上面这些同源）。
   *  与 `SVG.heart` 一样是 20px 的封面图案，但**保持描边风格**（它不是实心封面，
   *  它是「一行合成出来的入口」，与收藏夹那块渐变实心封面刻意区分开）。 */
  trend: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/></svg>'
  // （工具条上那枚「调音推子」图标 2026-10-01 随入口一起删掉了：调音改成标题栏
  //  三段切换的第三段，那枚图标就没有地方落了。图形本身仍在 icon-style.md §3 里。）
};
let p = null, _ = null, de = null, Gs = "", Ys = !1, Xt = [], Mt = -1, ls = null, ki = null, us = !1, y = null, zi = 0, Wi = 0, Hi = 0, ie = [], Ot = [[]], Ge = 0, bc = [], Ee = 0, Rt = [], li = null, J = null, Se = -1, ot = 0, ct = null, yt = !1, nt = null, un = null, jt = -1, wi = !1, ui = !1, os = 0, Ps = null;
const xl = 300;
let is = null, We = { a: !1, b: !1 }, oi = ["a", "b"], gt = !1, Mi = !1, on = null;
function Ll() {
  return { kind: "peaking", freq_hz: 1e3, gain_db: 0, q: 0.707, on: !0 };
}
function hi() {
  zi = (y == null ? void 0 : y.preamp_db) ?? 0, Wi = (y == null ? void 0 : y.bass_db) ?? 0, Hi = (y == null ? void 0 : y.treble_db) ?? 0, bc = ((y == null ? void 0 : y.graphic_eq) ?? []).map((i) => ({ freq_hz: i.freq_hz, gain_db: i.gain_db })), Ee = (y == null ? void 0 : y.delay_ms) ?? 0, Rt = ((y == null ? void 0 : y.channel_copy) ?? []).map((i) => ({ from: i.from, to: i.to })), li = (y == null ? void 0 : y.convolution) ?? null, J = null;
  const t = y != null && y.channels && y.channels > 0 ? y.channels : 2, e = [((y == null ? void 0 : y.filters) ?? []).map((i) => ({ ...i }))];
  for (let i = 1; i <= t; i++) {
    const s = ((y == null ? void 0 : y.if_else) ?? []).find((n) => n.channel === i - 1);
    e.push(((s == null ? void 0 : s.then) ?? []).map((n) => ({ ...n })));
  }
  Ot = e, (Ge < 0 || Ge >= e.length) && (Ge = 0), ie = e[Ge];
}
function El() {
  var i;
  if (!y) return [];
  if (Ge === 0) return y.response.db;
  const t = (y.if_else ?? []).findIndex((s) => s.channel === Ge - 1), e = t >= 0 ? (i = y.cond_db) == null ? void 0 : i[t] : void 0;
  return e && e.length ? e : y.response.db;
}
function Ml() {
  var i;
  const t = new Map(((y == null ? void 0 : y.if_else) ?? []).map((s) => [s.channel, s])), e = [];
  for (let s = 1; s < Ot.length; s++) {
    const n = s - 1, c = Ot[s], d = ((i = t.get(n)) == null ? void 0 : i.else) ?? [];
    if (c.length === 0 && d.length === 0) continue;
    const v = { channel: n, then: c };
    d.length > 0 && (v.else = d), e.push(v);
  }
  return e;
}
let D = "default", Js = null, lt = null, we = !1, hc = "", U = null, Os = !1, Nt = "", He = "", H = null, ri = !1, Si, ke = "playlist";
const di = /* @__PURE__ */ new Map(), Ti = /* @__PURE__ */ new Set(), Fi = /* @__PURE__ */ new Map();
let I = null, Ce = null, Kt = !1, rt = "", Pe = !1, bt = !1, Ve = "tracks", Bt = null, st = !1, ae = null, Ae = "", Bs = !1, rs = 0;
const Tl = 2e4;
let wt = !1, _s = "", ws = 0, ks = !1, Ci = vl, Xs = null, Ai = "", te = !1, fe = null, Ss = !1, mi = "", Fe = "", me = !1, $e = /* @__PURE__ */ new Set(), ji = /* @__PURE__ */ new Set(), Oe = !1, P = null, pi = !1, St = "", Te = null, Ui = "", qe, Zt = null, Ii, S = null, Ki = 0, K = [], F = -1, Tt = !1, ue = -1, Di, De = 0, kt = [], Ke = [], ce = null, Le = !1, X = !1, Me = !1, Xe = [], Qi = null, N = /* @__PURE__ */ new Set(), at = "", ge, ze = null, zt = /* @__PURE__ */ new Set(), ei = "", Qt = !1;
function yc() {
  return te !== Qt;
}
const gc = "lunac-music-local-last";
function _c() {
  try {
    const t = localStorage.getItem(gc);
    if (!t) return null;
    const e = JSON.parse(t);
    if (!e || !Array.isArray(e.queue) || e.queue.length === 0) return null;
    const i = Number(e.index);
    return {
      queue: e.queue,
      index: Number.isInteger(i) && i >= 0 && i < e.queue.length ? i : 0,
      position_ms: Math.max(0, Number(e.position_ms) || 0)
    };
  } catch {
    return null;
  }
}
function Ms() {
  if (!(K.length === 0 || F < 0))
    try {
      localStorage.setItem(gc, JSON.stringify({
        queue: K,
        index: F,
        position_ms: De
      }));
    } catch {
    }
}
const Ks = "lunac-music-local-queues";
function Cl() {
  try {
    const i = localStorage.getItem(Ks);
    if (i) {
      const s = JSON.parse(i), n = Array.isArray(s.queues) ? s.queues.filter((d) => d && typeof d.id == "string" && Array.isArray(d.items)).map((d) => ({ id: d.id, name: typeof d.name == "string" ? d.name : "", items: d.items })) : [], c = typeof s.activeId == "string" && n.some((d) => d.id === s.activeId) ? s.activeId : null;
      return { queues: n, activeId: c };
    }
  } catch {
  }
  const t = { queues: [], activeId: null }, e = _c();
  e && e.queue.length > 0 && t.queues.push({ id: wc(), name: "", items: e.queue });
  try {
    localStorage.setItem(Ks, JSON.stringify(t));
  } catch {
  }
  return t;
}
function ti() {
  try {
    localStorage.setItem(Ks, JSON.stringify({ queues: Ke, activeId: ce }));
  } catch {
  }
}
function wc() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}
function Vi() {
  return Ke.find((t) => t.id === ce) ?? null;
}
function Al(t) {
  const e = t || a("music.local_queue_edit");
  if (!Ke.some((s) => s.name === e)) return e;
  let i = 2;
  for (; Ke.some((s) => s.name === `${e} (${i})`); ) i++;
  return `${e} (${i})`;
}
{
  const t = Cl();
  Ke = t.queues, ce = t.activeId;
}
const kc = "lunac-music-dual-play";
let Be = Il();
function Il() {
  try {
    return localStorage.getItem(kc) === "1";
  } catch {
    return !1;
  }
}
function Dl(t) {
  try {
    localStorage.setItem(kc, t ? "1" : "0");
  } catch {
  }
}
const Sc = "lunac-music-local-mode";
let le = Rl();
function Rl() {
  try {
    const t = localStorage.getItem(Sc);
    return t === "shuffle" || t === "repeat_all" || t === "repeat_one" ? t : "off";
  } catch {
    return "off";
  }
}
function Nl(t) {
  try {
    localStorage.setItem(Sc, t);
  } catch {
  }
}
function rn() {
  return a(le === "shuffle" ? "music.mode_shuffle" : le === "repeat_all" ? "music.mode_repeat_all" : le === "repeat_one" ? "music.mode_repeat_one" : "music.mode_off");
}
let ut, ds = !1, Ct, Na = !1, ms, $c = 0, qc = 0, At = null, Gi = null, It = 0, fi = !1, Et = -1, Dt = [], Ri = 0, Ye, Pt, ps = "", fs = 0, ht, Zs = "";
function ii() {
  return D === "player" || D === "lplayer";
}
function l(t) {
  return t.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
function Ni(t) {
  if (!isFinite(t) || t < 0) return "0:00";
  const e = Math.floor(t / 1e3), i = Math.floor(e / 60), s = e % 60;
  return `${i}:${String(s).padStart(2, "0")}`;
}
function j(t) {
  if (!isFinite(t) || t < 0) return "00:00";
  const e = Math.floor(t / 1e3);
  return `${String(Math.floor(e / 60)).padStart(2, "0")}:${String(e % 60).padStart(2, "0")}`;
}
function R(t) {
  const e = t instanceof Error ? t.message : String(t);
  if (e.includes("ERR_NO_CLIENT_ID")) return a("music.err_no_client_id");
  if (e.includes("ERR_NOT_CONNECTED")) return a("music.err_not_connected");
  if (e.includes("ERR_NO_QUERY")) return a("music.err_no_query");
  if (e.includes("ERR_PORT_BUSY")) return a("music.err_port_busy", { port: String((p == null ? void 0 : p.port) ?? "") });
  if (e.includes("ERR_BAD_URI") || e.includes("ERR_BAD_ID")) return a("music.err_bad_uri");
  if (e.includes("ERR_SPOTIFY_STOPPED"))
    return wt = !0, a("music.err_spotify_stopped");
  const i = e.match(/ERR_RATE_LIMITED:(\S*)/);
  return i ? a("music.err_rate_limited", { s: i[1] || "?" }) : e.includes("Insufficient client scope") ? a("music.err_scope") : e.includes("No active device") || e.includes("NO_ACTIVE_DEVICE") ? a("music.err_no_device") : e.includes("Premium required") || e.includes("PREMIUM_REQUIRED") ? a("music.err_premium") : e.includes("Restriction violated") ? a("music.err_restricted") : e;
}
function Pl(t) {
  const e = [];
  for (const i of t.split(/\r?\n/)) {
    const s = [...i.matchAll(/\[(\d{1,3}):(\d{1,2})(?:[.:](\d{1,3}))?\]/g)];
    if (s.length === 0) continue;
    const n = i.replace(/\[[^\]]*\]/g, "").trim();
    if (n)
      for (const c of s) {
        const d = c[3] ? Number(c[3].padEnd(3, "0")) / 1e3 : 0;
        e.push({ at: Number(c[1]) * 60 + Number(c[2]) + d, text: n });
      }
  }
  return e.sort((i, s) => i.at - s.at), e;
}
function Ol() {
  return `
  <div class="music-root music-curve-root">
    <div class="music-setview">
      <div class="music-set-head">
        <span class="music-set-title">${a("music.tuning_curve")}</span>
      </div>
      <div class="music-set-body">
        <div class="music-tune-plot">
          <!-- 曲线缩放（与调音页同一条交互）：画布默认铺满宽度，点 ＋/－ 按百分比变宽，
               外层容器横向滚动 —— 看细节放大、看全局缩回。 -->
          <div class="music-tune-toolbar">
            <button type="button" class="music-tune-zoom" id="music-tune-zoom-out" title="${l(a("music.tuning_zoom_out"))}" aria-label="${l(a("music.tuning_zoom_out"))}">－</button>
            <span class="music-tune-zoom-label" id="music-tune-zoom-label">100%</span>
            <button type="button" class="music-tune-zoom" id="music-tune-zoom-in" title="${l(a("music.tuning_zoom_in"))}" aria-label="${l(a("music.tuning_zoom_in"))}">＋</button>
          </div>
          <div class="music-tune-scroll" id="music-tune-scroll">
            <canvas id="music-tune-canvas" width="640" height="280"></canvas>
          </div>
          <div class="music-hint" id="music-tune-rate"></div>
        </div>
        <div class="music-tune-probe">
          <button type="button" class="music-btn" id="music-tune-measure">${h.wave}${a("music.tuning_measure")}</button>
          <div class="music-hint" id="music-tune-probe-hint">${l(a("music.tuning_probe_hint"))}</div>
        </div>
        <div class="music-field">
          <label>${a("music.tuning_slots")}</label>
          <div class="music-seg music-slot-list" id="music-tune-slots"></div>
        </div>
      </div>
    </div>
    <div class="music-msg" id="music-msg"></div>
  </div>`;
}
function Bl() {
  return `
  <div class="music-root">
    <!-- ── 默认界面：顶部工具条 + 状态行 + 连接设置 + 歌单列 / 搜索结果 ──
         工具条与「返回」按钮**分属两态**：默认态用底部栏那个「进播放界面」，
         播放态用**标题栏那个 ←**（syncTitlebarClose 把 × 换成它；歌名模块右端
         原来还有一枚「返回歌单」，2026-10-01 已按用户口径删掉）。
         ⚠️ 本段在模板字符串里，注释里一个反引号都不能出现（预检 #15 / #39 ⑩）。 -->
    <div class="music-view" id="music-v-default">
      <!-- 顶部工具条：头像 / 账号 / 搜索（**带下拉预览**）/ 状态 / 设置。
           2026-09-28 第二次改：设备按钮与「展开播放面板」都**下移到最底下那条控制栏**
           （用户要求「严格对齐 Spotify」，Spotify 的工具条上本来就没有这两样）。 -->
      <div class="music-toolbar">
        <button class="music-avatar" id="music-avatar" title="${l(a("music.account_btn"))}"></button>
        <span class="music-acc" id="music-acc"></span>
        <div class="music-search-wrap">
          <input class="music-search" id="music-search" type="search" autocomplete="off" spellcheck="false" placeholder="${l(a("music.search_ph"))}">
          <!-- 下拉预览：绝对定位挂在工具条下方（**不占布局**，否则窗口高会跟着抖） -->
          <div class="music-dd hidden" id="music-search-dd"></div>
        </div>
        <!-- 「自定义队列」状态按钮 2026-10-10 已**从工具条挪回本地音乐分页**（用户口径：
             放到那页筛选标题行（.music-local-head-row）的最右侧、只在本地页显示）—— 见
             renderLocalMain 里那行骨架与 applyQueueModeUi。它不再随本工具条显隐。
             注：本段在模板字符串里，注释里一个反引号都不能出现（预检 #15 / #39 ⑩）。 -->
        <span class="music-status" id="music-status">${a("music.loading")}</span>
        <!-- 「恢复」按钮（2026-10-02）：**只在 429 硬闸拉着时显示**（见 renderResumeBtn）。
             它是用户唯一的出口 —— 宿主一旦收到 429 就停掉所有 Spotify 请求、且不自动重试。
             放工具条而不是底部提示行：提示行在播放态是绝对定位 + pointer-events:none，点不到。
             ⚠️ 本段是 JS 模板字符串，注释里不能出现反引号（预检 #15 / #39 ⑩）。 -->
        <button class="music-ghost-btn hidden" id="music-resume">${a("music.resume")}</button>
        <!-- 这里原来的「本地音乐」文件夹按钮与「调音」推子按钮**已删除**（2026-10-01
             用户口径）：这两个入口收进了**标题栏那枚三段切换**（在线歌单 / 本地音乐 /
             调音，见 renderTitlebarSwitch）。标题栏是悬浮窗独有的，插件若被嵌在主窗口里
             就没有那一条 —— 那种情况下切换器会退到本工具条里（见 placeSwitcher），
             所以这里不给它们留第二份入口，否则「删掉」就变成了「多一份」。
             ⚠️ 本段是 JS 模板字符串，注释里不能出现反引号（预检 #15 / #39 ⑩）。 -->
        <button class="music-ghost-btn music-icon-btn" id="music-setup-toggle" title="${l(a("music.settings"))}">${h.gear}</button>
      </div>

      <div class="music-setup hidden" id="music-setup">
        <div class="music-hint" id="music-setup-hint">${a("music.setup_hint")}</div>
        <!-- 凭据字段默认只在「没有内置 Client ID」或用户主动展开时显示：
             内置值让「登录」变成一步操作，Redirect URI 那一串对普通用户是噪音。 -->
        <button class="music-ghost-btn music-fields-toggle hidden" id="music-fields-toggle"></button>
        <div id="music-setup-fields">
          <div class="music-field">
            <label for="music-client-id">${a("music.client_id")}</label>
            <input id="music-client-id" type="text" spellcheck="false" autocomplete="off" placeholder="${l(a("music.client_id_ph"))}">
          </div>
          <div class="music-field music-field-port">
            <label for="music-port">${a("music.port")}</label>
            <input id="music-port" type="text" inputmode="numeric" autocomplete="off">
          </div>
          <div class="music-field">
            <label>${a("music.redirect")}</label>
            <div class="music-redirect-row">
              <code id="music-redirect"></code>
              <button class="music-ghost-btn music-icon-btn" id="music-copy-redirect" title="${l(a("music.copy"))}">${h.copy}</button>
            </div>
          </div>
          <!-- 本机播放（librespot）的两项设置：路径留空 = 自动探测；代理留空 = 直连。
               两者都不是「必填」，所以各带一行小字说明（见 renderSetup）。 -->
          <div class="music-field">
            <label for="music-librespot">${a("music.local_play")}</label>
            <input id="music-librespot" type="text" spellcheck="false" autocomplete="off" placeholder="librespot.exe">
          </div>
          <div class="music-field">
            <label for="music-librespot-proxy">proxy</label>
            <input id="music-librespot-proxy" type="text" spellcheck="false" autocomplete="off" placeholder="${l(a("music.librespot_proxy_ph"))}">
          </div>
        </div>
        <div class="music-actions">
          <button class="music-btn" id="music-save">${a("music.save")}</button>
          <button class="music-btn music-primary" id="music-connect">${h.link} ${a("music.connect")}</button>
          <button class="music-btn" id="music-disconnect">${h.power} ${a("music.disconnect")}</button>
        </div>
      </div>

      <!-- 主体：**左栏（宽度可拖）+ 分隔条 + 主区**（用户 2026-09-28 的
           「歌单列作为单独的一列可拉动」「中间大的大部分区域作为歌曲列表」）。
           两栏各自内部滚动 —— 窗口是定尺 1280×720，不是靠内容撑出来的。 -->
      <div class="music-body hidden" id="music-body">
        <aside class="music-side" id="music-side">
          <div class="music-side-tabs" id="music-side-tabs">
            <button class="music-tab on" data-act="side-tab" data-tab="playlist">${a("music.playlists")}</button>
            <button class="music-tab" data-act="side-tab" data-tab="album">${a("music.tab_albums")}</button>
            <button class="music-tab" data-act="side-tab" data-tab="artist">${a("music.tab_artists")}</button>
            <button class="music-tab" data-act="side-tab" data-tab="show">${a("music.tab_shows")}</button>
            <!-- 「最常听」栏（2026-10-01 用户第 4 条）。**放在最后**：那四栏是「我的库」，
                 这一栏是「库外的东西」，顺序上按这个分组走。
                 原先与它并列的「新发行」2026-10-02 删除（端点永久 403）。
                 注：本段在模板字符串里，注释里不能出现反引号（预检 #15 / #39 ⑩）。 -->
            <button class="music-tab" data-act="side-tab" data-tab="top">${a("music.tab_top")}</button>
          </div>
          <!-- 「本地音乐」那一页的左栏头（与上面那排 Spotify 页签**互斥显示**）：
               一个标题 + 一个「添加目录」。它跟着 localPage 切，见 renderLocalSide。 -->
          <div class="music-local-head hidden" id="music-local-head">
            <span class="music-local-title">${a("music.local_library")}</span>
            <div class="music-local-head-btns">
              <!-- 正常态三枚（2026-10-01 用户口径）：
                   ＋ = 添加（**目录或播放列表文件**，两个入口合一）
                   ✎ = 修改列表（进编辑态）—— 取代原来那枚「打开播放列表文件」
                   ⟳ = 重扫。
                   图标一律取自 icon-style.md §3，不自己画（见 SVG.edit / SVG.trash）。 -->
              <button class="music-ghost-btn music-icon-btn" id="music-local-add" title="${l(a("music.local_add"))}">${h.plus}</button>
              <button class="music-ghost-btn music-icon-btn" id="music-local-list" title="${l(a("music.local_edit"))}">${h.edit}</button>
              <!-- 「重扫」那枚**已从本行删掉**（2026-10-10 用户口径：扫描按钮只留一枚）——
                   保留的是主区筛选标题行（.music-local-head-row）里那枚（id=music-scan-btn）；
                   本行不再有扫描入口。自定义队列开关也在那边（最右一枚），不在本行。 -->
              <!-- 编辑态两枚（正常态隐藏，切法见 renderLocalHead）：
                   🗑 = 把勾选的行**摘出列表**（暂存，还能反悔）
                   × = 退出并保存（到这一步才真落盘） -->
              <button class="music-ghost-btn music-icon-btn hidden" id="music-local-del" title="${l(a("music.local_del_sel"))}">${h.trash}</button>
              <button class="music-ghost-btn music-icon-btn hidden" id="music-local-editdone" title="${l(a("music.local_edit_done"))}">${h.x}</button>
              <!-- 那个「＋」的二选一浮层（目录 / 播放列表文件）。画法见 renderLocalAddMenu，
                   定位参照是上面那排按钮（.music-local-head-btns 是 relative）。
                   注：本段在**模板字符串**里，注释里一个反引号都不能出现（预检 #15 / #39 ⑩）。 -->
              <div class="music-dd music-local-add-dd hidden" id="music-local-add-dd"></div>
            </div>
          </div>
          <div class="music-side-list" id="music-side-list"></div>
        </aside>
        <div class="music-split" id="music-split" role="separator" aria-orientation="vertical"></div>
        <main class="music-main" id="music-main"></main>
      </div>

      <!-- ── 底部控制栏（2026-09-28，Spotify 复刻）─────────────────────────
           用户要求「在默认面板下方添加 Spotify 那样的播放控制，并把一些按钮也
           移动到下方控制」。三列 grid：左 = 正在播放（点它 = 打开播放面板）、
           中 = 播放键组、右 = 设备 / 音量 / 队列 / 展开。
           栏顶那条 2px 细进度线**绝对定位**（不占高），拖动即可跳转。
           **两个弹层都挂在右端那一簇里、向上弹**：这条栏贴着窗口下沿，
           向下弹会跑到窗口外面（见 styles.css 里那两条覆盖 top 的规则）。
           注意本段是 JS 模板字符串 —— 注释里不能出现反引号（会把字符串截断）。 -->
      <div class="music-nowbar no-drawer hidden" id="music-nowbar">
        <!-- 「另一侧」的抽屉（2026-10-03 用户口径）：两条控制栏同屏只能有一条，
             另一条收进左端这一枚里 —— 点它把另一条换出来、这一条收进去。
             只在「同时出声」开着**且另一侧确实有东西**时出现（见 syncHead）。
             它是 grid 的第一列（auto 宽），隐藏时整列塌成 0 ⇒ 不开抽屉时外观不变。 -->
        <button type="button" class="music-drawer-btn hidden" id="music-b-drawer"></button>
        <div class="music-bp music-bp-timed" id="music-bp" title="${l(a("music.seek"))}">
          <div class="music-bp-fill" id="music-bp-fill"></div>
          <div class="music-progress-tip" id="music-bp-tip">0:00</div>
          <span class="music-btime" id="music-b-time">00:00 / 00:00</span>
        </div>
        <button class="music-bnow" id="music-bnow" title="${l(a("music.open_player"))}">
          <span class="music-bnow-cover" id="music-bnow-cover"></span>
          <span class="music-bnow-main">
            <span class="music-bnow-n" id="music-bnow-n"></span>
            <span class="music-bnow-a" id="music-bnow-a"></span>
          </span>
          <!-- 「进入小窗播放」的位置**收在左边这一块上**（2026-10-03 用户口径）：
               左块本身就是那个按钮，右端那枚重复的展开按钮已删。这个图标只是为了
               让「它可点」这件事看得见（同一条口径也铺到了本地那条栏，见下面）。 -->
          <span class="music-bnow-go">${h.expand}</span>
        </button>
        <div class="music-bctl">
          <button class="music-round-btn music-mode-btn" id="music-b-mode" data-mode="off"></button>
          <button class="music-round-btn" id="music-b-prev" title="${l(a("music.prev"))}">${h.prev}</button>
          <button class="music-round-btn music-play-btn" id="music-b-play" title="${l(a("music.play_pause"))}">${h.play}</button>
          <button class="music-round-btn" id="music-b-next" title="${l(a("music.next"))}">${h.next}</button>
        </div>
        <div class="music-bend">
          <!-- 与本地播放条上那一枚是**同一个状态**（见 dualPlay 的注释）。
               两枚按钮各自长在自己的控制区里，用户在哪条栏上都够得着。 -->
          <button class="music-ghost-btn music-icon-btn music-dual-btn" id="music-dual-btn" title="${l(a("music.dual_play"))}">${h.dual}</button>
          <button class="music-ghost-btn music-icon-btn" id="music-devices-btn" title="${l(a("music.devices"))}">${h.speaker}</button>
          <span class="music-vol-ico">${h.volume}</span>
          <input class="music-vol" id="music-b-vol" type="range" min="0" max="100" step="1" value="50" style="--vol-pct:50%" title="${l(a("music.volume"))}">
          <button class="music-round-btn" id="music-b-queue" title="${l(a("music.queue"))}">${h.list}</button>
          <!-- 右端那枚「进入小窗播放」**已删**（2026-10-03 用户口径）：它与左边
               「正在播放」那一块是同一个动作（都进小窗播放态），右边这枚是重复入口。
               保留左边那块既有的按钮语义，右端这一簇从此只放设备 / 音量 / 队列。 -->
          <div class="music-dd music-dev-dd hidden" id="music-dev-dd"></div>
          <div class="music-dd hidden" id="music-q-dd"></div>
        </div>
      </div>

      <!-- ── 本地文件播放条（2026-10-01）───────────────────────────────
           与上面那条 Spotify 控制栏**不是一条**：那条的对象是远端播放器
           （Web API 的 spotify_* 命令），这条的对象是宿主里那条本机音频流
           （player.rs 的 player_* 命令）。两者的数据源、可用条件（这条不要求
           登录 Spotify）、能做的事都不一样 —— 合成一条会到处长出
           「如果是本地就…」的分支，那正是两套东西被缝在一起的样子。
           只在「本地页 + 有本地会话」时出现，见 renderLocalNowbar。
           注意本段是 JS 模板字符串 —— 注释里不能出现反引号。 -->
      <div class="music-nowbar music-lnowbar no-drawer hidden" id="music-lnowbar">
        <!-- 「另一侧」的抽屉，与上面那条栏同形同义（点击 = 把在线那条换出来）。 -->
        <button type="button" class="music-drawer-btn hidden" id="music-l-drawer"></button>
        <div class="music-bp" id="music-lbp" title="${l(a("music.seek"))}">
          <div class="music-bp-fill" id="music-lbp-fill"></div>
          <div class="music-progress-tip" id="music-lbp-tip">0:00</div>
        </div>
        <!-- 左边这一块**就是**「进入小窗播放」的入口（2026-10-03 用户口径）：
             原来它是纯展示（本地没有小窗可进），2026-10-01 有了本地小窗之后那句话
             就不成立了 ⇒ 与 Spotify 那条栏同形，做成按钮，点它进 #music-v-lplayer。 -->
        <button class="music-bnow music-lnow" id="music-lnow" title="${l(a("music.open_player"))}">
          <span class="music-bnow-cover" id="music-lnow-cover"></span>
          <span class="music-bnow-main">
            <span class="music-bnow-n" id="music-lnow-n"></span>
            <span class="music-bnow-a" id="music-lnow-a"></span>
          </span>
          <span class="music-bnow-go">${h.expand}</span>
        </button>
        <div class="music-bctl">
          <!-- 播放模式（关 / 随机 / 循环列表 / 单曲循环，2026-10-01 用户第 8 条）。
               与 Spotify 那枚 #music-b-mode **不是一件事**：那枚是远端真相，
               这枚是前端自己算的（见 localMode 的注释），所以两枚各记各的状态。
               注：本段在模板字符串里，注释里不能出现反引号（预检 #15 / #39 ⑩）。 -->
          <button class="music-round-btn music-mode-btn" id="music-l-mode" data-mode="off" title="${l(a("music.mode_off"))}"></button>
          <button class="music-round-btn" id="music-l-prev" title="${l(a("music.prev"))}">${h.prev}</button>
          <button class="music-round-btn music-play-btn" id="music-l-play" title="${l(a("music.play_pause"))}">${h.play}</button>
          <button class="music-round-btn" id="music-l-next" title="${l(a("music.next"))}">${h.next}</button>
          <button class="music-round-btn" id="music-l-stop" title="${l(a("music.local_stop"))}">${h.stop}</button>
        </div>
        <div class="music-bend">
          <button class="music-ghost-btn music-icon-btn music-dual-btn" id="music-l-dual-btn" title="${l(a("music.dual_play"))}">${h.dual}</button>
          <span class="music-ltime" id="music-l-time">0:00 / 0:00</span>
          <span class="music-vol-ico">${h.volume}</span>
          <input class="music-vol" id="music-l-vol" type="range" min="0" max="100" step="1" value="80" style="--vol-pct:80%" title="${l(a("music.volume"))}">
          <!-- 「队列」按钮（2026-10-09 用户口径，2026-10-11 澄清）：在音量右边，点它弹出一个
               **与在线 #music-q-dd 同形同义的下拉浮层**（#music-lq-dd，锚在这条栏同一位置），
               展示**这一轮的播放队列**（localQueue —— 即现在 / 接下来放什么），**不是**左栏那些
               自定义队列（与远端 #music-b-queue 同一个图标）。
               注：本段在模板字符串里，注释里一个反引号都不能出现（预检 #15 / #39 ⑩）。 -->
          <button class="music-round-btn" id="music-l-queue" title="${l(a("music.local_play_queue"))}">${h.list}</button>
          <div class="music-dd hidden" id="music-lq-dd"></div>
          <!-- 右端那枚「进入小窗播放」**已删**（2026-10-03 用户口径）：动作与左边
               「正在播放」那一块重复，两边只留左边一个入口。 -->
        </div>
      </div>
    </div>

    <!-- ── 播放界面：**550×130 的长条**（封面 100 + 右侧列 450）──────────
         右侧列三块的高度加起来正好是长条高：歌名 30 + 歌词 65 + 控制 35 = 130。
         **这几个数都是用户 2026-09-27 给的定尺**：改任何一个都要同步
         styles.css 的 .music-name / .music-lyr / .music-bar，以及宿主
         plugin_window.rs 的 MUSIC_W（见 ai-spec §4.6 与预检 #39 ④）。 -->
    <!-- 注意：本段是 JS 模板字符串，**注释里不能出现反引号**（会把字符串截断）。 -->
    <div class="music-view music-player hidden" id="music-v-player">
      <div class="music-pv-card">
        <div class="music-pv-cover" id="music-pv-cover"></div>
        <div class="music-pv-col">
          <!-- 歌名模块 H30：歌名（亮）+ 歌手·专辑（暗）。 -->
          <div class="music-name">
            <div class="music-name-text">
              <span class="music-title" id="music-pv-title"></span>
              <span class="music-sub" id="music-pv-sub"></span>
            </div>
            <!-- 「返回歌单」那枚**已删除**（2026-10-01 用户口径：小窗播放里那个不是
                 状态栏里的返回按钮要去掉）。退出去仍然走**标题栏那个 ←** ——
                 它在播放态由 syncTitlebarClose 把 × 换成 ←，语义是「停播 + 回默认面板」
                 （见 stopAndBack），也是用户当初指定的出口。所以这里删掉不留缺口。 -->
          </div>

          <!-- 歌词模块 H65：正好两行可见（行高 32）。已过 + 正在 = 亮，未到 = 暗；
               点某一行 = 跳到那一句的进度。 -->
          <div class="music-lyr" id="music-lyr"></div>

          <!-- 控制面板 H35：进度条**叠在本块顶部**（绝对定位 ⇒ 不占高度，总高仍是 130），
               四个播放键在块内居中，右端音量条 80px + 播放列表按钮。 -->
          <div class="music-bar">
            <!-- 时间在控制块**最左端、进度条下方**（用户 2026-09-27 定）。
                 绝对定位 ⇒ 不参与四钮的居中计算。 -->
            <div class="music-time">
              <span id="music-pv-pos">0:00</span><span class="music-time-sep">/</span><span id="music-pv-dur">0:00</span>
            </div>
            <div class="music-progress" id="music-pv-progress" title="${l(a("music.seek"))}">
              <div class="music-progress-fill" id="music-pv-fill"></div>
              <div class="music-progress-dot" id="music-pv-dot"></div>
              <div class="music-progress-tip" id="music-pv-tip">0:00</div>
            </div>
            <div class="music-bar-main">
              <button class="music-round-btn music-mode-btn" id="music-mode" data-mode="off"></button>
              <button class="music-round-btn" id="music-prev" title="${l(a("music.prev"))}">${h.prev}</button>
              <button class="music-round-btn music-play-btn" id="music-play" title="${l(a("music.play_pause"))}">${h.play}</button>
              <button class="music-round-btn" id="music-next" title="${l(a("music.next"))}">${h.next}</button>
            </div>
            <div class="music-bar-end">
              <span class="music-vol-ico">${h.volume}</span>
              <input class="music-vol" id="music-vol" type="range" min="0" max="100" step="1" value="50" style="--vol-pct:50%" title="${l(a("music.volume"))}">
              <button class="music-round-btn" id="music-queue-btn" title="${l(a("music.queue"))}">${h.list}</button>
            </div>
          </div>
        </div>
      </div>

      <!-- 播放列表（队列）挂在长条**下方**、不再与歌词互斥：长条是定尺 130，
           塞不进队列。开着时窗口按内容长高（applyResize 实测贴合）。 -->
      <div class="music-q-wrap hidden" id="music-q-wrap">
        <div class="music-sec-head">
          <span class="music-sec-title">${a("music.queue")}</span>
          <span class="music-sec-note">${a("music.queue_hint")}</span>
        </div>
        <div class="music-q" id="music-q"></div>
      </div>
    </div>

    <!-- ── 本地小窗：**本地文件播放也有的那条长条**（2026-10-01 用户口径
         「在本地文件播放的情况下也添加小窗模式」）────────────────────────
         与上一个视图**共用同一套外壳类**（music-player / music-pv-card / music-pv-cover /
         music-name / music-bar / music-bp…）⇒ 尺寸（550×130）、圆角、配色、
         进度条的细线与命中区，一行业务 CSS 都不用重写。
         唯一的差别在**中间那一块**：远端那条长条放的是歌词（H65，见 .music-lyr），
         本地文件没有歌词 —— 那一格换成**大号进度线 + 时间**（见 .music-lp-mid）。
         三块的高度仍是 30 + 65 + 35 = 130，与 MUSIC_W_BAR / applyResize 对齐。
         数据与动作**都只有一份**：状态来自 localPlayer，按钮走的是本地播放那几条
         既有函数（见 attachMusicListeners 里那几条绑定）。
         注意本段是 JS 模板字符串 —— 注释里不能出现反引号（预检 #15 / #39 ⑩）。 -->
    <div class="music-view music-player hidden" id="music-v-lplayer">
      <div class="music-pv-card">
        <div class="music-pv-cover" id="music-lp-cover"></div>
        <div class="music-pv-col">
          <div class="music-name">
            <div class="music-name-text">
              <span class="music-title" id="music-lp-title"></span>
              <span class="music-sub" id="music-lp-sub"></span>
            </div>
          </div>
          <div class="music-lp-mid">
            <div class="music-bp music-lp-seek" id="music-lp-progress" title="${l(a("music.seek"))}">
              <div class="music-bp-fill" id="music-lp-fill"></div>
              <div class="music-progress-tip" id="music-lp-tip">0:00</div>
            </div>
            <div class="music-lp-time" id="music-lp-time">0:00 / 0:00</div>
          </div>
          <div class="music-bar">
            <div class="music-bar-main">
              <button class="music-round-btn music-mode-btn" id="music-lp-mode" data-mode="off" title="${l(a("music.mode_off"))}"></button>
              <button class="music-round-btn" id="music-lp-prev" title="${l(a("music.prev"))}">${h.prev}</button>
              <button class="music-round-btn music-play-btn" id="music-lp-play" title="${l(a("music.play_pause"))}">${h.play}</button>
              <button class="music-round-btn" id="music-lp-next" title="${l(a("music.next"))}">${h.next}</button>
              <button class="music-round-btn" id="music-lp-stop" title="${l(a("music.local_stop"))}">${h.stop}</button>
            </div>
            <div class="music-bar-end">
              <span class="music-vol-ico">${h.volume}</span>
              <input class="music-vol" id="music-lp-vol" type="range" min="0" max="100" step="1" value="80" style="--vol-pct:80%" title="${l(a("music.volume"))}">
              <!-- 「队列」按钮（2026-10-09 用户口径，2026-10-11 改）：与本地那条控制栏上的同一枚
                   同义，但**小窗里没有内容区、也没有浮层的锚点** ⇒ 点它**切回默认面板再打开
                   同一个 #music-lq-dd 浮层**（本任务选定：② 切到默认面板并打开浮层）。
                   注：本段在模板字符串里，注释里一个反引号都不能出现（预检 #15 / #39 ⑩）。 -->
              <button class="music-round-btn" id="music-lp-queue" title="${l(a("music.local_play_queue"))}">${h.list}</button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- ── 设置页：**整屏**（2026-10-01 用户要求「设置图标进到一个新的设置页面」）──
         与 #music-v-player 同为整屏视图，由 mode = "settings" 切（见 renderMode）。
         职责划分是硬的：**这里只放「偏好」，「连接」仍归头像点开的 #music-setup**
         （Client ID / 端口 / 回调 / librespot 路径与代理），**「调音」也有自己的一页**
         （#music-v-tuning，2026-10-01 用户要求搬出去的）。理由与那张卡片里的
         「保存」按钮直接相关 —— 一个卡片里塞两套保存语义必然出岔子，而现在这几页
         各有各的保存。
         ⚠️ 本段是 JS 模板字符串 —— 注释里**不许出现反引号**，连「引用一个标识符」
         那种写法都不行：它会把模板字符串提前截断（预检 #15 / #39 ⑩，本轮又踩了一次）。 -->
    <div class="music-view music-setview hidden" id="music-v-settings">
      <div class="music-set-head">
        <button class="music-ghost-btn music-icon-btn" id="music-set-back" title="${l(a("music.settings_back"))}">${h.back}</button>
        <span class="music-set-title">${a("music.settings")}</span>
      </div>
      <div class="music-set-body">
        <!-- 串流质量：三档互斥按钮。**不用原生 select 元素** —— WebView2 透明窗口里
             它不渲染弹出层（code-rules §5.2）。三档值只允许 96/160/320（宿主侧
             LIBRESPOT_BITRATES，抄自 librespot --help 的原文）。
             ⚠️ 模板字符串 ⇒ 本段注释里也不许出现反引号（预检 #39 ⑩）。 -->
        <div class="music-field">
          <label>${a("music.quality")}</label>
          <div class="music-seg" id="music-quality">
            ${[96, 160, 320].map((t) => `<button type="button" class="music-seg-btn" data-q="${t}">${t}k</button>`).join("")}
          </div>
          <div class="music-hint">${l(a("music.quality_hint"))}</div>
          <div class="music-hint">${l(a("music.quality_local_note"))}</div>
        </div>
        <!-- 调音页的入口（2026-10-03 用户要求「设置按钮入口」）。**不在这页里编辑调音**：
             调音是**按下即生效、即落盘**的实时功能，而这页那套是「攒着等保存」
             （音质要重启 librespot 才生效）—— 两种保存语义混在一张卡片里必然出岔子。
             所以这里只给一颗**进去的按钮**（切到 #music-v-tuning 那一页）。 -->
        <div class="music-field">
          <label>${a("music.tuning")}</label>
          <div class="music-actions">
            <button type="button" class="music-btn" id="music-set-tuning">${a("music.tuning_open")}</button>
          </div>
        </div>
        <div class="music-actions">
          <button class="music-btn" id="music-set-save">${a("music.save")}</button>
        </div>
      </div>
    </div>

    <!-- ── 调音页：**自己一页**（2026-10-01 用户口径）────────────────────
         用户明确「调音插件的界面不能放置到设置界面里，要新建一个界面专门用来显示调音」
         —— 所以它在 2026-10-01 从设置页那一块**整段搬过来**（上一版是「调音分区」）。
         入口只有一个：标题栏那枚三段切换的第三段（见 renderTitlebarSwitch）——
         **页内那枚返回按钮 2026-10-02 按用户要求取掉了**：切换器本身就是「回得去」的
         那一条路（点回「在线歌单 / 本地音乐」即离页），再摆一个返回是重复入口。
         版面顺序（2026-10-03 用户口径，本轮重排）：三栏骨架 ——
         左 = 工具条（保存 / 导入 / 导出）+ 我的预设；中 = 三条全局水平滑块 +
         **频段柱**（滤波器与均衡器已合并）；右 = 通道槽 + 全局效果器（延迟 / 复制 / 卷积）。
         四条纪律：① 控件**按下就生效、也当场落盘**（与设置页「音质」那两条攒着
         等保存完全不同：音质要重启 librespot 才生效，调音是实时的）；
         ② 滤波器类型的**名单来自宿主**（tuning.kinds，与引擎 Kind::ALL 同源）、
         用户预设名单也来自宿主（tuning.user_presets）—— 前端不维护第二份名单；
         ③ **两条播放链都生效**（2026-10-04 起）：本地文件走宿主 player.rs，在线歌单走
         librespot 的 -B pipe 输出 → 宿主的 live_audio.rs，两条套的是**同一个**
         TuningSource（共享同一份配置与版本号 ⇒ 在哪边调都立刻生效）。唯一例外是
         **首次授权那一次**：那一次不能带 -B pipe（OAuth 会把 URL 打到 stdout、污染
         PCM，见 librespot_args 的三条注释），重启一次 librespot 即接入；
         ④ 频段柱里的控件**全部动态渲染**（见 renderTuningFilters），这里只留容器。
         ⚠️ 本段是 JS 模板字符串 ⇒ 注释里不许出现反引号（预检 #15 / #39 ⑩）。 -->
    <div class="music-view music-setview hidden" id="music-v-tuning">
      <div class="music-set-head">
        <span class="music-set-title">${a("music.tuning")}</span>
        <!-- 频响曲线**不在这页里**（2026-10-03 用户口径「参照 Peace」）：它搬进一扇独立小窗，
             这页只留一颗按钮当入口。理由：曲线是「一边看一边调」的东西，占满这页会把
             推子与数值表挤没；而这一页要按 Peace 的三栏骨架排。 -->
        <button type="button" class="music-btn music-curve-open" id="music-curve-open">${h.wave}${a("music.tuning_curve_open")}</button>
        <button type="button" class="music-switch" id="music-tuning-on" role="switch" aria-checked="false" title="${l(a("music.tuning"))}">
          <span class="music-switch-knob"></span>
        </button>
      </div>
      <!-- 三栏骨架（2026-10-03，参照 Peace 主窗 → 同日按用户第 7/8 条重排）：
             左 = 工具条 + 我的预设、中 = 三条全局滑块 + 频段柱、右 = 扬声器声道 + 全局效果器。
             **接线函数的 id 一律沿用**（music-tuning-user-presets / music-tune-slots /
             music-tuning-filters / music-preamp-range …）：这一页的 render 与委托全按 id 找节点，
             重排只动 HTML 的位置，逻辑一行都不用改。
             ⚠️ 本段是 JS 模板字符串 ⇒ 注释里不许出现反引号（预检 #15 / #39 ⑩）。 -->
      <div class="music-set-body music-tune-cols">
        <!-- ── 左栏：预设（2026-10-03 用户口径：工具条移到最上、内置 5 档整批删掉）── -->
        <div class="music-tune-col music-tune-col-presets">
          <div class="music-actions">
            <button type="button" class="music-btn" id="music-preset-save">${l(a("music.tuning_preset_save"))}</button>
            <button type="button" class="music-btn" id="music-preset-import">${l(a("music.tuning_preset_import"))}</button>
            <button type="button" class="music-btn" id="music-preset-export">${l(a("music.tuning_preset_export"))}</button>
          </div>
          <div class="music-preset-list" id="music-tuning-user-presets"></div>
          <div class="music-preset-edit hidden" id="music-tuning-preset-edit">
            <div class="music-hint" id="music-preset-edit-hint"></div>
            <input type="text" id="music-preset-name" autocomplete="off" spellcheck="false" />
            <button type="button" class="music-btn" id="music-preset-ok"></button>
            <button type="button" class="music-btn" id="music-preset-cancel">${l(a("music.tuning_preset_cancel"))}</button>
          </div>
          <!-- A-B 盲测（2026-10-06）：两个快照槽 + 随机映射 + 揭晓。
               快照 = **整条链**（宿主落 config	uningab-a.json / ab-b.json）；
               切换走 player_tuning_ab_apply（先校验→落盘→改内存→版本号+1 ⇒ 不重播）。
               盲测时两个按钮只显示 1 / 2，映射由 tuneAbSlots 决定，点「揭晓」才告诉用户。 -->
          <div class="music-tune-ab" id="music-tune-ab">
            <div class="music-sub-label">${l(a("music.tuning_ab_title"))}</div>
            <div class="music-actions">
              <button type="button" class="music-btn" id="music-ab-save-a">${l(a("music.tuning_ab_save_a"))}</button>
              <button type="button" class="music-btn" id="music-ab-save-b">${l(a("music.tuning_ab_save_b"))}</button>
            </div>
            <div class="music-actions" id="music-ab-play">
              <button type="button" class="music-btn" id="music-ab-pos1" data-pos="1">A</button>
              <button type="button" class="music-btn" id="music-ab-pos2" data-pos="2">B</button>
              <button type="button" class="music-btn" id="music-ab-blind">${l(a("music.tuning_ab_blind"))}</button>
              <button type="button" class="music-btn hidden" id="music-ab-reveal">${l(a("music.tuning_ab_reveal"))}</button>
            </div>
            <div class="music-hint" id="music-ab-hint"></div>
          </div>
        </div>
        <!-- ── 中栏：三条全局水平滑块 + 频段柱（2026-10-03 用户口径）────────────
             三条滑块 = 总增益 / 低音增益 / 高音增益（Peace 顶部那种「左标签 + 滑块 + 右数值框」）；
             频段柱 = **滤波器与均衡器合并**后的主体：频率可编辑 / 竖拉条 / 大号增益 / Q / 类型按钮。
             延迟属于全局效果器，已挪到右栏（与声道复制 / 卷积同处）。 -->
        <div class="music-tune-col music-tune-col-eq">
          <div class="music-tune-sliderrow">
            <label>${a("music.tuning_preamp")}</label>
            <input type="range" class="music-tune-hslider" id="music-preamp-range" min="-24" max="24" step="0.5" aria-label="${l(a("music.tuning_preamp"))}" />
            <input type="text" class="music-tune-num" id="music-tune-preamp" inputmode="decimal" autocomplete="off" spellcheck="false" aria-label="${l(a("music.tuning_preamp"))}" />
          </div>
          <div class="music-tune-sliderrow">
            <label>${a("music.tuning_bass")}</label>
            <input type="range" class="music-tune-hslider" id="music-bass-range" min="-24" max="24" step="0.5" aria-label="${l(a("music.tuning_bass"))}" />
            <input type="text" class="music-tune-num" id="music-tune-bass" inputmode="decimal" autocomplete="off" spellcheck="false" aria-label="${l(a("music.tuning_bass"))}" />
          </div>
          <div class="music-tune-sliderrow">
            <label>${a("music.tuning_treble")}</label>
            <input type="range" class="music-tune-hslider" id="music-treble-range" min="-24" max="24" step="0.5" aria-label="${l(a("music.tuning_treble"))}" />
            <input type="text" class="music-tune-num" id="music-tune-treble" inputmode="decimal" autocomplete="off" spellcheck="false" aria-label="${l(a("music.tuning_treble"))}" />
          </div>
          <!-- 频段柱：作用域是**右栏选中的那个通道槽**（全局槽 ↔ 引擎的 filters）。
               左侧那列图例（2026-10-06 用户要求）把「频率 / 增益 / 质量」各标一次，并与柱内
               三行**逐行对齐** —— 三个框都只有数字，少了它用户不知道哪个是哪个。行高与柱子
               共用 --tf-* 那四个变量（见 styles.css 的 .music-tune-filterwrap），改一处两边同步。
               第二格是空占位，对齐的是那根竖拉条（增益那一行同时有拉条与大号读数，只标一次）。 -->
          <div class="music-tune-filterwrap">
            <div class="music-tune-legend" aria-hidden="true">
              <span class="l-freq">${l(a("music.tuning_freq"))}</span>
              <span class="l-slider"></span>
              <span class="l-gain">${l(a("music.tuning_gain"))}</span>
              <span class="l-q">${l(a("music.tuning_q"))}</span>
            </div>
            <div class="music-tune-filters" id="music-tuning-filters"></div>
          </div>
          <div class="music-actions">
            <button type="button" class="music-btn" id="music-tune-add">${h.plus}${a("music.tuning_add")}</button>
          </div>
        </div>
        <!-- ── 右栏：通道槽 + 全局效果器（延迟 / 声道复制 / 卷积）──────────────
             三样效果器都是**顶层字段** ⇒ 只在「全局」通道槽里显示（画在通道槽里会看起来像
             只作用于那条声道）。槽本身不落盘 —— 它只是「中栏那排频段柱在编辑哪一份草稿」
             这个视图状态；改动落在草稿里，提交时整排一起发（见 tuneIfElsePayload）。 -->
        <div class="music-tune-col music-tune-col-side">
          <div class="music-sub-label">${a("music.tuning_slots")}</div>
          <div class="music-seg music-slot-list music-slot-col" id="music-tune-slots"></div>
          <div class="music-field hidden" id="music-tune-delay">
            <div class="music-tune-sliderrow">
              <label>${a("music.tuning_delay")}</label>
              <input type="range" class="music-tune-hslider" id="music-delay-range" min="0" max="5000" step="1" aria-label="${l(a("music.tuning_delay"))}" />
              <input type="text" class="music-tune-num" id="music-delay-num" inputmode="decimal" autocomplete="off" spellcheck="false" aria-label="${l(a("music.tuning_delay"))}" />
            </div>
          </div>
          <div class="music-field hidden" id="music-tune-copy">
            <div class="music-copy-list" id="music-copy-list"></div>
            <div class="music-actions">
              <button type="button" class="music-btn" id="music-copy-add">${h.plus}${a("music.tuning_copy_add")}</button>
            </div>
          </div>
          <div class="music-field hidden" id="music-tune-conv">
            <label>${a("music.tuning_conv")}</label>
            <div class="music-hint" id="music-conv-path"></div>
            <div class="music-actions">
              <button type="button" class="music-btn" id="music-conv-pick">${l(a("music.tuning_conv_pick"))}</button>
              <button type="button" class="music-btn hidden" id="music-conv-clear">${l(a("music.tuning_conv_clear"))}</button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- ── 自定义队列的编辑小窗（2026-10-09 用户口径）：插件页面**正中的浮层** —
         一个名字输入框 + 一个「添加文件」按钮 + 已选文件清单 + 确定 / 取消。
         ⚠️ 本段在模板字符串里，注释里一个反引号都不能出现（预检 #15 / #39 ⑩）。 -->
    <div class="music-dlg-mask hidden" id="music-queue-dlg">
      <div class="music-dlg">
        <div class="music-dlg-title">${a("music.local_queue_dlg_title")}</div>
        <div class="music-field">
          <label for="music-queue-name">${a("music.local_queue_dlg_name")}</label>
          <input id="music-queue-name" type="text" spellcheck="false" autocomplete="off" placeholder="${l(a("music.local_queue_dlg_name_ph"))}">
        </div>
        <div class="music-queue-pickrow">
          <button type="button" class="music-btn" id="music-queue-pick">${h.plus} ${a("music.local_queue_pick")}</button>
          <span class="music-hint" id="music-queue-pick-hint">${l(a("music.local_queue_pick_hint"))}</span>
        </div>
        <div class="music-queue-files" id="music-queue-files"></div>
        <div class="music-actions">
          <button type="button" class="music-btn" id="music-queue-cancel">${a("music.local_queue_cancel")}</button>
          <button type="button" class="music-btn music-primary" id="music-queue-ok">${a("music.local_queue_ok")}</button>
        </div>
      </div>
    </div>

    <!-- ── 「删除本地文件」二次确认（2026-10-11 用户口径）：删除是**不可恢复**动作，
         所以走一扇居中确认卡（复用上面 #music-queue-dlg 那套 .music-dlg-mask 观感，
         **不用 window.confirm** —— WebView2 里那套原生框与本仓观感不一致）。
         文案动态填进 #music-del-text（带上曲目名、写明不可恢复）。
         ⚠️ 本段在模板字符串里，注释里一个反引号都不能出现（预检 #15 / #39 ⑩）。 -->
    <div class="music-dlg-mask hidden" id="music-del-dlg">
      <div class="music-dlg">
        <div class="music-dlg-title">${a("music.ctx_delete_title")}</div>
        <div class="music-del-text" id="music-del-text"></div>
        <div class="music-actions">
          <button type="button" class="music-btn" id="music-del-cancel">${a("music.ctx_delete_cancel")}</button>
          <button type="button" class="music-btn music-primary" id="music-del-ok">${a("music.ctx_delete_ok")}</button>
        </div>
      </div>
    </div>

    <!-- ── 歌曲行的**右键上下文菜单**（2026-10-11 用户第 4 条）：单例节点，在鼠标位置弹出
         （非居中模态）；点外部 / Esc 关闭。做法照桌宠窗那枚 pet-menu（静态节点 + open 类 +
         鼠标位置定位），不另造第二套观感。菜单项按上下文现填（见 openCtxMenu）。
         ⚠️ **必须长在「主插件窗」的 shell（这里）**：上一版误放进了 curveShellHtml
         （频响曲线窗）—— 而 curve 窗根本不挂 contextmenu 监听（attachMusicListeners 在
         isCurveWindow 时早退到 attachCurveWindow）⇒ 主窗里 openCtxMenu 永远
         querySelector 到 null、菜单不出（2026-10-11 用户报「右键呼不出来」的根因）。
         ⚠️ 本段在模板字符串里，注释里一个反引号都不能出现（预检 #15 / #39 ⑩）。 -->
    <div class="music-ctx" id="music-ctx"></div>

    <div class="music-msg" id="music-msg"></div>
  </div>`;
}
function E(t, e) {
  t && t.textContent !== e && (t.textContent = e);
}
function T(t, e) {
  if (!t || t.innerHTML === e) return;
  const i = document.createElement("template");
  i.innerHTML = e, t.innerHTML !== i.innerHTML && (t.innerHTML = e);
}
function A(t, e) {
  t == null || t.classList.toggle("hidden", !e);
}
function oe(t, e, i) {
  t && t.getAttribute(e) !== i && t.setAttribute(e, i);
}
function si(t, e) {
  if (!t) return;
  const i = Math.max(0, Math.min(100, Math.round(e)));
  t.style.setProperty("--vol-pct", `${i}%`);
}
function zl(t) {
  const e = t.querySelector("#music-msg");
  if (!e) return;
  const i = e.textContent ?? "";
  if (i !== ps) {
    ps = i, fs = Date.now();
    return;
  }
  i && Date.now() - fs >= vc && (e.textContent = "", ps = "", fs = 0);
}
function ee(t) {
  const e = ii();
  A(t.querySelector("#music-v-default"), D === "default"), A(t.querySelector("#music-v-player"), D === "player"), A(t.querySelector("#music-v-lplayer"), D === "lplayer"), A(t.querySelector("#music-v-settings"), D === "settings");
  const i = D === "tuning";
  A(t.querySelector("#music-v-tuning"), i), i ? ($t(t), mu(t)) : dn(), t.classList.toggle("music-player-on", e), Wl(e), Hl(), Vt(t), Ql(), D === "player" ? (Mt = -1, Ls(t), As(t)) : D === "lplayer" ? Oc(t) : D === "default" && (A(t.querySelector("#music-body"), !!(p != null && p.connected) || te), Wt(t), xe(t), Je(t), vi(t)), D !== "default" && Me && (Me = !1, _t(t)), Bi(t);
}
function Wl(t) {
  const e = !t;
  document.getElementById("plugin-titlebar") && Xs !== e && (Xs = e, r("plugin_window_set_resizable", { resizable: e }).catch(() => {
  }));
}
function Hl() {
  const t = document.getElementById("plugin-close");
  if (!t) return;
  Ai || (Ai = t.innerHTML);
  const e = ii() ? "back" : "close";
  if (t.dataset.mode === e) return;
  t.dataset.mode = e, t.innerHTML = e === "back" ? h.back : Ai;
  const i = e === "back" ? a("music.back") : "Close";
  t.title = i, t.setAttribute("aria-label", i);
}
function Fl() {
  const t = document.getElementById("plugin-close");
  !t || !Ai || t.dataset.mode !== "back" || (t.innerHTML = Ai, t.title = "Close", t.setAttribute("aria-label", "Close"), t.dataset.mode = "close");
}
function jl() {
  return D === "tuning" ? "tuning" : D !== "default" ? "" : te ? "local" : "online";
}
function Ul(t) {
  const e = document.getElementById("music-tb-switch");
  if (e) return e;
  const i = document.createElement("div");
  i.id = "music-tb-switch", i.className = "music-tb-switch", i.setAttribute("role", "tablist"), i.setAttribute("data-tauri-drag-region", "");
  const s = [
    ["online", a("music.tb_online")],
    ["local", a("music.tb_local")],
    ["tuning", a("music.tb_tuning")]
  ];
  i.innerHTML = s.map(([d, v]) => `<button type="button" class="music-tb-seg" role="tab" data-seg="${d}" title="${l(v)}">${l(v)}</button>`).join("");
  const n = document.getElementById("plugin-titlebar"), c = document.getElementById("plugin-title");
  if (n && c)
    n.insertBefore(i, c.nextSibling);
  else {
    const d = t.querySelector("#music-setup-toggle"), v = t.querySelector(".music-toolbar");
    if (!v) return null;
    v.insertBefore(i, d);
  }
  return i;
}
function Ql() {
  const t = document.getElementById("music-tb-switch");
  if (!t) return;
  const e = jl();
  for (const i of t.querySelectorAll(".music-tb-seg"))
    oe(i, "aria-pressed", String(i.dataset.seg === e));
}
function Vl() {
  var t;
  (t = document.getElementById("music-tb-switch")) == null || t.remove();
}
async function Gl(t) {
  try {
    await r("spotify_control", { action: "pause" });
  } catch (e) {
    $(t, R(e));
  }
  D = "default", ee(t);
}
function Yi(t) {
  const e = t.querySelector("#music-local-qmode");
  e && (e.classList.toggle("on", X), oe(e, "aria-pressed", X ? "true" : "false"));
  const i = t.querySelector("#music-scan-btn");
  i && (oe(i, "title", a(X ? "music.local_queue_exit" : "music.local_rescan")), T(i, X ? h.x : h.refresh)), xc(t);
}
function xc(t) {
  const e = t.querySelector("#music-setup-toggle");
  e && (oe(e, "title", a(X ? "music.local_queue_add_picked" : "music.settings")), T(e, X ? h.plus : h.gear));
}
function en(t) {
  const e = t.querySelector("#music-setup-toggle"), i = t.querySelector(".music-toolbar");
  if (!e || !i) return;
  const s = te ? t.querySelector(
    ce === null ? "#music-local-page .music-local-head-row" : "#music-queue-page .music-local-head-row"
  ) : null;
  if (!s) {
    e.parentElement !== i && i.appendChild(e);
    return;
  }
  if (ce === null) {
    const n = s.querySelector("#music-scan-btn");
    n ? e.previousElementSibling !== n && n.insertAdjacentElement("afterend", e) : e.parentElement !== s && s.appendChild(e);
  } else (e.parentElement !== s || e !== s.lastElementChild) && s.appendChild(e);
}
function Pa(t, e, i, s) {
  const n = t.querySelector(e);
  n && n.classList.toggle("no-drawer", !s), A(t.querySelector(i), s);
}
function Oa(t, e, i) {
  if (!t) return;
  const s = a(e);
  t.dataset.label !== s && (t.dataset.label = s, t.innerHTML = `${h.expand}<span>${l(s)}</span>`), oe(t, "title", a(i));
}
function Vt(t) {
  const e = D === "player", i = !!(p != null && p.connected);
  A(t.querySelector("#music-nowbar"), !e && i && !yc());
  const s = Be && i && F >= 0;
  Pa(t, "#music-nowbar", "#music-b-drawer", s), Pa(t, "#music-lnowbar", "#music-l-drawer", s), Oa(t.querySelector("#music-b-drawer"), "music.drawer_local", "music.tb_local"), Oa(t.querySelector("#music-l-drawer"), "music.drawer_online", "music.tb_online");
  for (const n of [".music-search-wrap", "#music-avatar", "#music-acc", "#music-status"])
    A(t.querySelector(n), !te);
  en(t), xc(t), t.querySelectorAll(".music-dual-btn").forEach((n) => n.classList.toggle("on", Be));
}
function Gt(t, e) {
  const i = t.querySelector("#music-status");
  p != null && p.client_id ? p.connected ? _ ? _.active ? _.playing ? E(i, a("music.status_playing")) : E(i, a("music.status_paused")) : E(i, a("music.status_no_device")) : E(i, a("music.status_connecting")) : E(i, a("music.status_disconnected")) : E(i, a("music.status_unconfigured"));
  const s = t.querySelector("#music-avatar");
  if (s) {
    const c = p != null && p.connected && p.avatar || "";
    T(s, c ? `<img src="${l(c)}" alt="">` : "");
  }
  E(t.querySelector("#music-acc"), p != null && p.connected && p.display_name || "");
  const n = t.querySelector("#music-devices-btn");
  n && (oe(n, "title", `${a("music.devices")}：${(_ == null ? void 0 : _.device) || a("music.device_none")}`), n.classList.toggle("warn", !!(p != null && p.connected) && !(_ != null && _.active)));
}
function Ut(t) {
  A(t.querySelector("#music-setup"), !(p != null && p.connected) || us), A(t.querySelector("#music-body"), !!(p != null && p.connected) || te), Wt(t), xe(t), p != null && p.connected && (Uc(t, ke), Vc(t));
  const e = ls ?? !(p != null && p.builtin);
  A(t.querySelector("#music-setup-fields"), e), A(t.querySelector("#music-save"), e);
  const i = t.querySelector("#music-fields-toggle");
  A(i, !!(p != null && p.builtin)), E(i, a(e ? "music.hide_fields" : "music.use_own_client_id")), E(
    t.querySelector("#music-setup-hint"),
    p != null && p.builtin ? a("music.setup_builtin") : a("music.setup_hint")
  );
  const s = t.querySelector("#music-client-id"), n = t.querySelector("#music-port"), c = t.querySelector("#music-librespot"), d = t.querySelector("#music-librespot-proxy");
  s && document.activeElement !== s && (s.value = (p == null ? void 0 : p.client_id) ?? ""), n && document.activeElement !== n && (n.value = String((p == null ? void 0 : p.port) ?? 8899)), c && document.activeElement !== c && (c.value = (p == null ? void 0 : p.librespot_path) ?? ""), d && document.activeElement !== d && (d.value = (p == null ? void 0 : p.librespot_proxy) ?? "");
  const v = ki ?? (p == null ? void 0 : p.librespot_bitrate) ?? 320;
  for (const w of t.querySelectorAll("#music-quality .music-seg-btn"))
    oe(w, "aria-pressed", String(Number(w.dataset.q) === v));
  E(t.querySelector("#music-redirect"), (p == null ? void 0 : p.redirect_uri) ?? "");
}
function Ba(t) {
  const e = a(`music.tk_${t}`);
  return e.startsWith("music.") ? t : e;
}
function za(t) {
  return Number.isFinite(t) ? Math.min(2e4, Math.max(20, t)) : 1e3;
}
function Wa(t) {
  return Number.isFinite(t) ? Math.min(24, Math.max(-24, t)) : 0;
}
function Q(t, e = 3) {
  return t === void 0 || !Number.isFinite(t) ? "" : String(Math.round(t * 10 ** e) / 10 ** e);
}
function zs(t, e) {
  return e === "freq_hz" ? Q(t.freq_hz, 1) : e === "gain_db" ? Q(t.gain_db ?? 0, 1) : e === "q" ? Q(t.q ?? 0.707, 3) : "";
}
async function $t(t) {
  let e;
  try {
    e = await r("player_tuning_get");
  } catch (i) {
    $(t, R(i));
    return;
  }
  JSON.stringify(e) !== JSON.stringify(y) && (y = e, hi(), Se = -1), await eu(), pe(t);
}
function Lc(t) {
  const e = t.querySelector("#music-tune-measure");
  e && e.disabled !== yt && (e.disabled = yt), oe(e, "aria-busy", String(yt));
  const i = t.querySelector("#music-tune-probe-hint");
  if (!i) return;
  if (yt) {
    E(i, a("music.tuning_measuring"));
    return;
  }
  const s = ct;
  if (!s) {
    E(i, a("music.tuning_probe_hint"));
    return;
  }
  const n = (v, w) => {
    let q = 0, k = 0;
    for (let C = 0; C < v.length && C < w.length; C++)
      q += v[C] - w[C], k += 1;
    return k > 0 ? q / k : 0;
  }, c = n(s.chain_db ?? [], s.ref_db), d = n(s.db, s.chain_db ?? []);
  E(
    i,
    a("music.tuning_probe_result", {
      cov: String(Math.round(s.coverage * 100)),
      dev: `${c >= 0 ? "+" : ""}${c.toFixed(1)}`,
      sys: `${d >= 0 ? "+" : ""}${d.toFixed(1)}`,
      ms: String(s.elapsed_ms)
    })
  );
}
function Yl(t) {
  if (!y) return;
  const e = y.user_presets ?? [], i = t.querySelector("#music-tuning-user-presets");
  i && T(
    i,
    e.map((d) => {
      const v = y.preset === d;
      return `<div class="music-preset-user" data-preset="${l(d)}" aria-pressed="${v}"><button type="button" class="music-preset-item" data-act="use">${l(d)}</button><button type="button" class="music-preset-icon" data-act="rename" title="${l(a("music.tuning_preset_rename"))}">✎</button><button type="button" class="music-preset-icon" data-act="delete" title="${l(a("music.tuning_preset_delete"))}">✕</button></div>`;
    }).join("")
  );
  const s = nt;
  if (A(t.querySelector("#music-tuning-preset-edit"), s !== null), !s) return;
  const n = s.mode === "delete";
  E(
    t.querySelector("#music-preset-edit-hint"),
    s.mode === "save" ? a("music.tuning_preset_save_prompt") : s.mode === "rename" ? a("music.tuning_preset_rename_prompt", { name: s.from }) : a("music.tuning_preset_delete_confirm", { name: s.name })
  );
  const c = t.querySelector("#music-preset-name");
  A(c, !n), c && c !== document.activeElement && c.value !== s.name && (c.value = s.name), E(
    t.querySelector("#music-preset-ok"),
    s.mode === "save" ? s.overwrite ? a("music.tuning_preset_overwrite") : a("music.tuning_preset_ok") : s.mode === "rename" ? a("music.tuning_preset_rename") : a("music.tuning_preset_delete")
  );
}
function Jl(t) {
  return t === 0 ? a("music.tuning_slot_global") : mc[t - 1] ?? `#${t}`;
}
function Xl(t) {
  const e = t.querySelector("#music-tune-slots");
  e && T(
    e,
    Ot.map((i, s) => {
      const n = Jl(s), c = i.filter((d) => d.on).length;
      return `<button type="button" class="music-seg-btn music-slot-btn" data-slot="${s}" aria-pressed="${s === Ge}" title="${l(n)}">${l(n)}<em>${c}</em></button>`;
    }).join("")
  );
}
function Kl(t, e) {
  e === Ge || e < 0 || e >= Ot.length || (Ge = e, ie = Ot[e], Se = -1, pe(t));
}
function Ha(t) {
  return mc[t] ?? "#" + (t + 1);
}
function Ec(t) {
  const e = t.querySelector("#music-copy-list");
  if (!e) return;
  const i = Math.max(1, (y == null ? void 0 : y.channels) || 2);
  T(
    e,
    Rt.map((s, n) => {
      const c = (J == null ? void 0 : J.row) === n ? J.side : null, d = (w) => c === w ? `<div class="music-tune-menu">${Array.from({ length: i }, (q, k) => {
        const C = (w === "from" ? s.from : s.to) === k;
        return `<button type="button" class="music-seg-btn" data-act="pick" data-i="${n}" data-side="${w}" data-ch="${k}" aria-pressed="${C}">${l(Ha(k))}</button>`;
      }).join("")}</div>` : "", v = (w, q) => `<button type="button" class="music-tune-kind" data-act="menu" data-i="${n}" data-side="${w}" aria-expanded="${c === w}"><span>${l(Ha(q))}</span>${h.chevron}</button>`;
      return `<div class="music-copy-row" data-i="${n}">
        ${v("from", s.from)}<span class="music-copy-arrow">→</span>${v("to", s.to)}
        <button type="button" class="music-tune-del" data-act="del" data-i="${n}" title="${l(a("music.tuning_del"))}">${h.trash}</button>
        ${d("from")}${d("to")}
      </div>`;
    }).join("")
  ), A(t.querySelector("#music-copy-empty"), Rt.length === 0);
}
function Zl(t) {
  const e = Ge === 0;
  if (A(t.querySelector("#music-tune-delay"), e), A(t.querySelector("#music-tune-copy"), e), A(t.querySelector("#music-tune-conv"), e), !e || ui) return;
  const i = t.querySelector("#music-delay-num");
  i && document.activeElement !== i && i.value !== Q(Ee, 1) && (i.value = Q(Ee, 1));
  const s = t.querySelector("#music-delay-range");
  s && s.value !== String(Ee) && (s.value = String(Ee)), Ec(t), E(t.querySelector("#music-conv-path"), li ?? a("music.tuning_conv_none")), A(t.querySelector("#music-conv-clear"), li !== null);
}
function Ws(t, e, i, s) {
  const n = t.querySelector(e);
  n && n.value !== Q(s, 1) && (n.value = Q(s, 1));
  const c = t.querySelector(i);
  c && document.activeElement !== c && c.value !== Q(s, 1) && (c.value = Q(s, 1));
}
async function eu() {
  try {
    We = await r("player_tuning_ab_state");
  } catch {
    We = { a: !1, b: !1 };
  }
}
function Ji(t) {
  var s;
  for (const n of [1, 2]) {
    const c = t.querySelector(`#music-ab-pos${n}`);
    if (!c) continue;
    const d = oi[n - 1], v = d === "a" ? We.a : We.b;
    c.dataset.ab = d, c.textContent = gt ? String(n) : d.toUpperCase(), c.disabled = !v, c.classList.toggle("active", v && on === d);
  }
  const e = t.querySelector("#music-ab-blind");
  e && (e.classList.toggle("active", gt), e.disabled = !(We.a && We.b)), (s = t.querySelector("#music-ab-reveal")) == null || s.classList.toggle("hidden", !gt || Mi);
  const i = t.querySelector("#music-ab-hint");
  i && (i.textContent = tu());
}
function tu() {
  return !We.a && !We.b ? a("music.tuning_ab_empty") : gt ? Mi ? a("music.tuning_ab_revealed", {
    one: oi[0].toUpperCase(),
    two: oi[1].toUpperCase()
  }) : a("music.tuning_ab_blind_hint") : a("music.tuning_ab_hint", {
    a: We.a ? "A" : "—",
    b: We.b ? "B" : "—"
  });
}
async function Fa(t, e) {
  try {
    We = await r("player_tuning_ab_save", { slot: e }), $(t, a(e === "a" ? "music.tuning_ab_saved_a" : "music.tuning_ab_saved_b"));
  } catch (i) {
    $(t, R(i));
  }
  Ji(t);
}
async function iu(t, e) {
  const i = oi[e - 1];
  if (i) {
    try {
      await r("player_tuning_ab_apply", { slot: i }), on = i, await $t(t);
    } catch (s) {
      $(t, R(s));
    }
    Ji(t);
  }
}
function pe(t) {
  y && (oe(t.querySelector("#music-tuning-on"), "aria-checked", String(y.enabled)), Lc(t), Yl(t), Ji(t), Ws(t, "#music-preamp-range", "#music-tune-preamp", zi), Ws(t, "#music-bass-range", "#music-tune-bass", Wi), Ws(t, "#music-treble-range", "#music-tune-treble", Hi), Xl(t), Mc(t), Zl(t), Cc(t), E(
    t.querySelector("#music-tune-rate"),
    a("music.tuning_rate", { rate: Q(y.response.sample_rate / 1e3, 1) })
  ));
}
function su(t, e, i, s) {
  const n = i.find((B) => B.name === t.kind), c = n ? n.gain : t.gain_db !== void 0, d = n ? n.order !== 1 : t.q !== void 0, v = t.gain_db ?? 0, w = `<input type="text" class="music-tune-num music-band-freq" data-f="freq_hz" inputmode="decimal" autocomplete="off" spellcheck="false" value="${l(Q(t.freq_hz, 1))}" aria-label="${l(a("music.tuning_freq"))}" />`, q = c ? `<input type="range" class="music-tune-vslider" data-f="gain_db" min="-24" max="24" step="0.5" value="${l(Q(v, 1))}" aria-label="${l(a("music.tuning_gain"))}" />` : '<div class="music-tune-vslider-na"></div>', k = c ? `<input type="text" class="music-tune-num music-band-gain" data-f="gain_db" inputmode="decimal" autocomplete="off" spellcheck="false" value="${l(Q(v, 1))}" aria-label="${l(a("music.tuning_gain"))}" />` : '<span class="music-band-gain na">—</span>', C = d ? `<input type="text" class="music-tune-num music-band-q" data-f="q" inputmode="decimal" autocomplete="off" spellcheck="false" value="${l(Q(t.q ?? 0.707, 3))}" aria-label="${l(a("music.tuning_q"))}" />` : "", L = s ? `<div class="music-tune-menu">${i.map(
    (B) => `<button type="button" class="music-seg-btn" data-act="pick" data-kind="${l(B.name)}" aria-pressed="${B.name === t.kind}">${l(Ba(B.name))}</button>`
  ).join("")}</div>` : "";
  return `<div class="music-tune-band music-tune-row${t.on ? "" : " off"}" data-i="${e}">
      ${w}
      ${q}
      ${k}
      ${C}
      <div class="music-band-foot">
        <button type="button" class="music-tune-kind" data-act="kind" aria-expanded="${s}"><span>${l(Ba(t.kind))}</span>${h.chevron}</button>
        <button type="button" class="music-tune-sw" data-act="on" aria-pressed="${t.on}" title="${l(t.on ? a("music.tuning_off") : a("music.tuning_on"))}">${h.power}</button>
        <button type="button" class="music-tune-del" data-act="del" title="${l(a("music.tuning_del"))}">${h.trash}</button>
      </div>
      ${L}
    </div>`;
}
function Mc(t) {
  if (ui) return;
  const e = t.querySelector("#music-tuning-filters");
  if (!e || !y || e.contains(document.activeElement)) return;
  const i = y.kinds;
  T(e, ie.map((s, n) => su(s, n, i, Se === n)).join(""));
}
function ja(t, e, i) {
  const s = un;
  if (!s) return null;
  const n = t.getBoundingClientRect(), c = s.w / (n.width || s.w), d = s.h / (n.height || s.h), v = (e - n.left) * c, w = (i - n.top) * d, q = Math.log10(20), k = Math.log10(2e4), C = (v - s.padL) / s.plotW, L = 10 ** (q + C * (k - q)), B = s.span - (w - s.padT) / s.plotH * (2 * s.span);
  return { f: L, db: B, x: v, y: w };
}
function Tc(t, e, i) {
  const s = Math.log10(20), n = Math.log10(2e4), c = t.padL + (Math.log10(Math.max(1, e)) - s) / (n - s) * t.plotW, d = t.padT + (t.span - i) / (2 * t.span) * t.plotH;
  return { x: c, y: d };
}
let Yt = 1;
function Cc(t) {
  const e = t.querySelector("#music-tune-canvas");
  e && (e.style.width = `${Yt * 100}%`), E(t.querySelector("#music-tune-zoom-label"), `${Math.round(Yt * 100)}%`), $s(t);
}
function $s(t) {
  var mt;
  const e = t.querySelector("#music-tune-canvas");
  if (!e || !y) return;
  const i = e.clientWidth || e.width, s = e.clientHeight || e.height;
  if (i < 2 || s < 2) return;
  const n = window.devicePixelRatio || 1;
  (e.width !== Math.round(i * n) || e.height !== Math.round(s * n)) && (e.width = Math.round(i * n), e.height = Math.round(s * n));
  const c = e.getContext("2d");
  if (!c) return;
  c.setTransform(n, 0, 0, n, 0, 0), c.clearRect(0, 0, i, s);
  const d = getComputedStyle(t), v = d.getPropertyValue("--accent").trim() || "#7aa2f7", w = d.getPropertyValue("--border-glass").trim() || "rgba(255,255,255,0.12)", q = d.getPropertyValue("--text-dim").trim() || "rgba(255,255,255,0.55)", { freqs: k } = y.response, C = El(), L = 30, B = 8, z = 8, ve = 16, Ue = Math.max(1, i - L - B), Re = Math.max(1, s - z - ve);
  let Ne = 0;
  for (const x of C) Number.isFinite(x) && (Ne = Math.max(Ne, Math.abs(x)));
  for (const x of (ct == null ? void 0 : ct.db) ?? [])
    Number.isFinite(x) && (Ne = Math.max(Ne, Math.abs(x)));
  const be = Math.min(60, Math.max(12, Math.ceil((Ne + 1) / 6) * 6)), et = Math.log10(20), yi = Math.log10(2e4), dt = (x) => L + (Math.log10(Math.max(1, x)) - et) / (yi - et) * Ue, Qe = (x) => z + (be - x) / (2 * be) * Re, re = { w: i, h: s, padL: L, padT: z, plotW: Ue, plotH: Re, span: be };
  un = re, c.lineWidth = 1, c.font = "9px system-ui, -apple-system, sans-serif", c.textBaseline = "middle";
  for (const x of [be, be / 2, 0, -be / 2, -be])
    c.strokeStyle = w, c.globalAlpha = x === 0 ? 0.9 : 0.45, c.setLineDash(x === 0 ? [] : [3, 3]), c.beginPath(), c.moveTo(L, Qe(x)), c.lineTo(L + Ue, Qe(x)), c.stroke();
  c.setLineDash([]), c.fillStyle = q;
  for (const x of [20, 100, 1e3, 1e4, 2e4]) {
    const V = dt(x);
    c.globalAlpha = 0.45, c.strokeStyle = w, c.beginPath(), c.moveTo(V, z), c.lineTo(V, z + Re), c.stroke(), c.globalAlpha = 0.9, c.textAlign = x === 20 ? "left" : x === 2e4 ? "right" : "center", c.fillText(x >= 1e3 ? `${x / 1e3}k` : String(x), V, z + Re + 8);
  }
  c.textAlign = "right";
  for (const x of [be, be / 2, 0, -be / 2, -be])
    c.globalAlpha = 0.9, c.fillStyle = q, c.fillText(`${x > 0 ? "+" : ""}${Q(x, 0)}`, L - 3, Qe(x));
  if (c.textAlign = "left", c.globalAlpha = 1, k.length >= 2 && C.length === k.length) {
    c.beginPath();
    for (let x = 0; x < k.length; x++) {
      const V = dt(k[x]), Z = Qe(C[x]);
      x === 0 ? c.moveTo(V, Z) : c.lineTo(V, Z);
    }
    c.lineTo(dt(k[k.length - 1]), Qe(0)), c.lineTo(dt(k[0]), Qe(0)), c.closePath(), c.globalAlpha = 0.12, c.fillStyle = v, c.fill(), c.globalAlpha = 1, c.beginPath();
    for (let x = 0; x < k.length; x++) {
      const V = dt(k[x]), Z = Qe(C[x]);
      x === 0 ? c.moveTo(V, Z) : c.lineTo(V, Z);
    }
    c.strokeStyle = v, c.lineWidth = 1.5, c.stroke();
  }
  const he = ct;
  if (he && he.freqs.length >= 2) {
    const x = d.getPropertyValue("--green").trim() || "#8fc99a", V = d.getPropertyValue("--blue").trim() || "#9490b4", Z = (ye, tt, G, Lt) => {
      if (!(ye.length < 2)) {
        c.save(), c.beginPath(), c.rect(L, z, Ue, Re), c.clip(), c.beginPath();
        for (let it = 0; it < he.freqs.length && it < ye.length; it++) {
          const gi = dt(he.freqs[it]), _i = Qe(ye[it]);
          it === 0 ? c.moveTo(gi, _i) : c.lineTo(gi, _i);
        }
        c.setLineDash(tt), c.strokeStyle = G, c.lineWidth = Lt, c.stroke(), c.setLineDash([]), c.restore();
      }
    };
    Z(he.db, [1.5, 3], V, 1.2), Z(he.chain_db ?? [], [5, 3], x, 1.5);
  }
  if (ie.length > 0) {
    c.save(), c.font = "9px system-ui, -apple-system, sans-serif", c.textAlign = "center", c.textBaseline = "middle";
    for (let x = 0; x < ie.length; x++) {
      const V = ie[x], Z = ((mt = y.kinds.find((Lt) => Lt.name === V.kind)) == null ? void 0 : mt.gain) ?? V.gain_db !== void 0, { x: ye, y: tt } = Tc(re, V.freq_hz, Z ? V.gain_db ?? 0 : 0), G = x === jt;
      c.globalAlpha = V.on ? 1 : 0.4, c.beginPath(), Z ? c.arc(ye, tt, G ? 6 : 4.5, 0, Math.PI * 2) : (c.moveTo(ye, tt - 5), c.lineTo(ye + 5, tt + 3), c.lineTo(ye - 5, tt + 3), c.closePath()), c.fillStyle = G ? v : "rgba(0,0,0,0.65)", c.fill(), c.strokeStyle = v, c.lineWidth = 1.5, c.stroke(), Z && x < 9 && (c.globalAlpha = 1, c.fillStyle = G ? "rgba(0,0,0,0.8)" : v, c.fillText(String(x + 1), ye, tt + 0.5));
    }
    c.globalAlpha = 1, c.restore();
  }
}
function nu(t, e, i) {
  t.kind = e;
  const s = i.find((n) => n.name === e);
  s && (s.gain ? t.gain_db === void 0 && (t.gain_db = 0) : delete t.gain_db, s.order === 1 ? delete t.q : t.q === void 0 && (t.q = 0.707));
}
async function se(t, e = !1) {
  var q, k, C;
  const i = ++ot, s = document.activeElement, n = (q = s == null ? void 0 : s.closest) == null ? void 0 : q.call(s, ".music-tune-row"), c = s instanceof HTMLInputElement && s.type === "text" ? s.dataset.f : void 0, d = n ? Number(n.dataset.i) : -1, v = s instanceof HTMLInputElement && s.type === "text" && !n ? s.id : "";
  let w;
  try {
    w = await r("player_tuning_set_chain", {
      preampDb: zi,
      // 低音 / 高音快捷增益：引擎不认识它们，宿主会追加成 low_shelf / high_shelf 两条。
      bassDb: Wi,
      trebleDb: Hi,
      // ⚠️ **全局槽 = `tuneSlotDrafts[0]`，不是 `tuneFilters`**（P5-2）：后者是「表正在编辑
      // 的那一份」，用户停在某个通道槽时它指的是那条声道 —— 拿它当全局发会把通道的段搬进全局。
      filters: Ot[0],
      // 新效果器全部**走草稿**（它们现在都有界面了：P5-3 图示均衡器 / P5-4 延迟 + 复制 + 卷积）。
      // 宿主那条命令的语义是「**覆盖整条链**」⇒ 少发一样就等于把它清掉。
      graphicEq: bc,
      delayMs: Ee,
      channelCopy: Rt,
      convolution: li,
      // 通道段由**全部槽的草稿**拼（P5-2）—— 不是把宿主那份原样回传：用户这会儿
      // 可能正在某个通道槽里改，那份改动就在 `tuneSlotDrafts` 里。
      ifElse: Ml()
    });
  } catch (L) {
    if (i !== ot) return;
    $(t, R(L)), await $t(t);
    return;
  }
  i === ot && (y = w, hi(), e || $(t, a("music.tuning_saved")), pe(t), c && d >= 0 && d < ie.length ? (k = t.querySelector(`.music-tune-row[data-i="${d}"] input[type="text"][data-f="${c}"]`)) == null || k.focus() : v && ((C = t.querySelector(`#${v}`)) == null || C.focus()));
}
async function au(t, e) {
  const i = ++ot;
  let s;
  try {
    s = await r("player_tuning_set_enabled", { enabled: e });
  } catch (n) {
    if (i !== ot) return;
    $(t, R(n)), await $t(t);
    return;
  }
  i === ot && (y = s, hi(), $(t, a("music.tuning_saved")), pe(t));
}
async function cu(t, e) {
  const i = ++ot;
  let s;
  try {
    s = await r("player_tuning_set", { enabled: !0, preset: e });
  } catch (n) {
    if (i !== ot) return;
    $(t, R(n)), await $t(t);
    return;
  }
  i === ot && (y = s, hi(), Se = -1, ct = null, $(t, a("music.tuning_saved")), pe(t));
}
async function Ua(t) {
  var s;
  const e = nt;
  if (!e) return;
  const i = e.mode === "delete" ? e.name : (((s = t.querySelector("#music-preset-name")) == null ? void 0 : s.value) ?? "").trim();
  if (e.mode !== "delete" && !i) {
    $(t, a("music.tuning_preset_name_empty"));
    return;
  }
  try {
    e.mode === "save" ? (y = await r("player_tuning_preset_save", { name: i, overwrite: e.overwrite }), $(t, a("music.tuning_preset_saved", { name: i }))) : e.mode === "rename" ? (y = await r("player_tuning_preset_rename", { from: e.from, to: i }), $(t, a("music.tuning_preset_renamed", { name: i }))) : (y = await r("player_tuning_preset_delete", { name: i }), $(t, a("music.tuning_preset_deleted", { name: i }))), nt = null, hi(), pe(t);
  } catch (n) {
    const c = R(n);
    if (c.includes("ERR_PRESET_EXISTS")) {
      e.mode === "save" ? (nt = { mode: "save", name: i, overwrite: !0 }, pe(t)) : $(t, a("music.tuning_preset_exists", { name: i }));
      return;
    }
    $(t, c);
  }
}
async function lu(t) {
  let e;
  try {
    e = await Xi({
      multiple: !1,
      filters: [{ name: "Lunac preset", extensions: ["json"] }]
    });
  } catch (i) {
    $(t, R(i));
    return;
  }
  if (typeof e == "string")
    try {
      y = await r("player_tuning_preset_import", { path: e }), hi(), Se = -1, ct = null, pe(t), $(t, a("music.tuning_preset_imported", { name: y.preset }));
    } catch (i) {
      $(t, R(i));
    }
}
async function uu(t) {
  let e;
  try {
    e = await Xi({
      multiple: !1,
      filters: [{ name: "WAV", extensions: ["wav"] }]
    });
  } catch (i) {
    $(t, R(i));
    return;
  }
  typeof e == "string" && (li = e, await se(t));
}
async function ou(t) {
  if (!y) return;
  const e = y.preset && y.preset !== "custom" ? y.preset : "lunac-chain";
  let i;
  try {
    i = await ll({
      defaultPath: `${e}.json`,
      filters: [{ name: "Lunac preset", extensions: ["json"] }]
    });
  } catch (s) {
    $(t, R(s));
    return;
  }
  if (typeof i == "string")
    try {
      await r("player_tuning_preset_export", { path: i }), $(t, a("music.tuning_preset_exported", { path: i }));
    } catch (s) {
      $(t, R(s));
    }
}
function vs(t) {
  const e = Date.now();
  if (e - os >= 120) {
    os = e, se(t, !0);
    return;
  }
  Ps == null && (Ps = window.setTimeout(() => {
    Ps = null, os = Date.now(), se(t, !0);
  }, 120));
}
function Hs(t) {
  is != null && window.clearTimeout(is), is = window.setTimeout(() => {
    is = null, se(t);
  }, xl);
}
async function ru(t) {
  if (!yt) {
    yt = !0, Lc(t);
    try {
      ct = await r("player_tuning_measure");
    } catch (e) {
      $(t, R(e));
    } finally {
      yt = !1, pe(t);
    }
  }
}
function du(t) {
  const e = t.querySelector("#music-tune-canvas");
  if (!e) return;
  const i = (n, c, d) => {
    var L;
    const v = ja(n, c, d), w = un;
    if (!v || !w) return null;
    let q = -1, k = 14;
    for (let B = 0; B < ie.length; B++) {
      const z = ie[B], ve = ((L = y == null ? void 0 : y.kinds.find((Ne) => Ne.name === z.kind)) == null ? void 0 : L.gain) ?? z.gain_db !== void 0, Ue = Tc(w, z.freq_hz, ve ? z.gain_db ?? 0 : 0), Re = Math.hypot(Ue.x - v.x, Ue.y - v.y);
      Re < k && (k = Re, q = B);
    }
    const C = v.x >= w.padL - 6 && v.x <= w.padL + w.plotW + 6 && v.y >= w.padT - 6 && v.y <= w.padT + w.plotH + 6;
    return { p: v, idx: q, inside: C };
  };
  e.addEventListener("pointerdown", (n) => {
    const c = n.currentTarget, d = i(c, n.clientX, n.clientY);
    if (!d) return;
    let v = d.idx;
    wi = !1, !(v < 0 && !d.inside) && (v < 0 && (ie.push({
      kind: "peaking",
      freq_hz: za(d.p.f),
      gain_db: Wa(d.p.db),
      q: 0.707,
      on: !0
    }), v = ie.length - 1, Se = -1, wi = !0), jt = v, ui = !0, c.setPointerCapture(n.pointerId), $s(t), n.preventDefault());
  }), e.addEventListener("pointermove", (n) => {
    var C;
    if (jt < 0) return;
    const c = n.currentTarget, d = ie[jt], v = ja(c, n.clientX, n.clientY);
    if (!d || !v) return;
    const w = ((C = y == null ? void 0 : y.kinds.find((L) => L.name === d.kind)) == null ? void 0 : C.gain) ?? d.gain_db !== void 0, q = za(v.f), k = Wa(v.db);
    (q !== d.freq_hz || w && k !== d.gain_db) && (wi = !0), d.freq_hz = q, w && (d.gain_db = k), $s(t), vs(t), n.preventDefault();
  });
  const s = (n) => {
    var v;
    if (jt < 0) return;
    const c = n.currentTarget, d = wi;
    jt = -1, wi = !1, ui = !1, (v = c.hasPointerCapture) != null && v.call(c, n.pointerId) && c.releasePointerCapture(n.pointerId), os = 0, d && se(t);
  };
  e.addEventListener("pointerup", s), e.addEventListener("pointercancel", s);
}
function Ac(t) {
  var s, n, c, d, v;
  (s = t.querySelector("#music-tune-measure")) == null || s.addEventListener("click", () => {
    ru(t);
  });
  const e = (w, q) => {
    const k = t.querySelector("#music-tune-scroll"), C = t.querySelector("#music-tune-canvas");
    if (!k || !C) return;
    const L = C.getBoundingClientRect(), B = L.width > 0 ? (w - L.left) / L.width : 0.5, z = Math.min(3, Math.max(1, Math.round(q * 100) / 100));
    if (z === Yt) return;
    Yt = z, Cc(t);
    const ve = C.getBoundingClientRect();
    k.scrollLeft += ve.left + B * ve.width - w;
  }, i = (w) => {
    const q = t.querySelector("#music-tune-scroll");
    if (!q) return;
    const k = q.getBoundingClientRect();
    e(k.left + k.width / 2, Yt + w);
  };
  (n = t.querySelector("#music-tune-zoom-in")) == null || n.addEventListener("click", () => i(0.25)), (c = t.querySelector("#music-tune-zoom-out")) == null || c.addEventListener("click", () => i(-0.25)), (d = t.querySelector("#music-tune-scroll")) == null || d.addEventListener(
    "wheel",
    (w) => {
      w.preventDefault(), e(w.clientX, Yt + (w.deltaY < 0 ? 0.2 : -0.2));
    },
    { passive: !1 }
  ), du(t), (v = t.querySelector("#music-tune-slots")) == null || v.addEventListener("click", (w) => {
    const q = w.target.closest("[data-slot]");
    q && Kl(t, Number(q.dataset.slot));
  });
}
let Pi;
const Qa = 1200;
function tn() {
  Pi !== void 0 && (window.clearTimeout(Pi), Pi = void 0);
}
let ni;
const Va = 1200;
function dn() {
  ni !== void 0 && (window.clearTimeout(ni), ni = void 0);
}
function mu(t) {
  if (ni !== void 0) return;
  const e = async () => {
    if (!t.isConnected || D !== "tuning") {
      dn();
      return;
    }
    await $t(t), t.isConnected && D === "tuning" && (ni = window.setTimeout(() => void e(), Va));
  };
  ni = window.setTimeout(() => void e(), Va);
}
async function pu(t) {
  tn(), ct = null, yt = !1, Ac(t), await $t(t);
  const e = async () => {
    if (!t.isConnected) {
      tn();
      return;
    }
    await $t(t), t.isConnected && (Pi = window.setTimeout(() => void e(), Qa));
  };
  Pi = window.setTimeout(() => void e(), Qa);
}
async function fu(t) {
  try {
    await r("open_plugin_window", { pluginId: "music", key: rc, input: "" });
  } catch (e) {
    $(t, R(e));
  }
}
function vu(t) {
  var e;
  return !!t.uri && ((e = _ == null ? void 0 : _.track) == null ? void 0 : e.uri) === t.uri;
}
function xt(t, e) {
  const i = t == null ? void 0 : t.querySelector("#music-msg");
  !i || i.textContent === e || (i.textContent = e, ht !== void 0 && (window.clearTimeout(ht), ht = void 0), e && (ht = window.setTimeout(() => {
    i.textContent = "", ht = void 0;
  }, vc)));
}
function $(t, e) {
  xt(t, e);
}
function Ts(t, e, i, s = "", n = "") {
  const d = (i === "main-track" || i === "play-uri") && N.has(t.uri);
  return `<button class="music-tr${vu(t) ? " playing" : ""}${d ? " sel" : ""}" data-act="${i}" data-uri="${l(t.uri)}"${s ? ` data-i="${l(s)}"` : ""}${n ? ` title="${l(n)}"` : ""}>
    <span class="music-tr-i">${e + 1}</span>
    <span class="music-tr-main">
      <span class="music-tr-n">${l(t.name || "?")}</span>
      <span class="music-tr-a">${l(t.artists || t.album)}</span>
    </span>
    <span class="music-tr-d">${Ni(t.duration_ms)}</span>
  </button>`;
}
function Cs(t) {
  return { id: t.id, uri: t.uri, name: t.name, cover: t.cover, subtitle: t.owner, total: t.total };
}
function bs(t, e) {
  const i = !!e.uri && (_ == null ? void 0 : _.context_uri) === e.uri, s = (I == null ? void 0 : I.kind) === t && I.id === e.id, n = e.cover ? `<img src="${l(e.cover)}" alt="">` : "";
  return `<div class="music-pl${i ? " playing" : ""}${s ? " on" : ""}" data-uri="${l(e.uri)}">
    <button class="music-pl-btn" data-act="open" data-kind="${t}" data-id="${l(e.id)}" title="${l(e.name || "?")}">
      <span class="music-pl-cover">${n}</span>
      <span class="music-pl-main">
        <span class="music-pl-name">${l(e.name || "?")}</span>
        <span class="music-pl-sub">${l(e.subtitle)}</span>
      </span>
    </button>
  </div>`;
}
function bu() {
  return `<div class="music-pl${(I == null ? void 0 : I.kind) === "top-tracks" ? " on" : ""}">
    <button class="music-pl-btn" data-act="open" data-kind="top-tracks" data-id="top-tracks" title="${l(a("music.top_tracks"))}">
      <span class="music-pl-cover music-pl-trend-cover">${h.trend}</span>
      <span class="music-pl-main">
        <span class="music-pl-name">${l(a("music.top_tracks"))}</span>
        <span class="music-pl-sub">${l(a("music.top_tracks_sub"))}</span>
      </span>
    </button>
  </div>`;
}
function hu(t, e) {
  const i = e.cover ? `<img src="${l(e.cover)}" alt="">` : "";
  return `<button class="music-card" data-act="open" data-kind="${t}" data-id="${l(e.id)}" title="${l(e.name)}">
    <span class="music-card-cover${t === "artist" ? " round" : ""}">${i}</span>
    <span class="music-card-n">${l(e.name)}</span>
    <span class="music-card-s">${l(e.subtitle)}</span>
  </button>`;
}
function yu() {
  const t = (I == null ? void 0 : I.kind) === "liked", e = U ? String(U.total) : "", i = Nt || [(p == null ? void 0 : p.display_name) || "", e].filter(Boolean).join(" · ");
  return `<div class="music-pl music-pl-liked${t ? " on" : ""}${Nt ? " err" : ""}">
    <button class="music-pl-btn" data-act="open" data-kind="liked" data-id="liked" title="${l(a("music.liked_songs"))}">
      <span class="music-pl-cover music-pl-liked-cover">${h.heart}</span>
      <span class="music-pl-main">
        <span class="music-pl-name">${l(a("music.liked_songs"))}</span>
        <span class="music-pl-sub">${l(i)}</span>
      </span>
    </button>
  </div>`;
}
function Wt(t) {
  if (te) {
    je(t);
    return;
  }
  A(t.querySelector("#music-side-tabs"), !0), A(t.querySelector("#music-local-head"), !1), t.querySelectorAll("#music-side-tabs .music-tab").forEach((c) => {
    c.classList.toggle("on", c.dataset.tab === ke);
  });
  const e = t.querySelector("#music-side-list");
  if (!e) return;
  if (!(p != null && p.connected)) {
    T(e, `<div class="music-empty">${a("music.playlists_login")}</div>`);
    return;
  }
  const i = di.get(ke), s = Fi.get(ke);
  let n = ke === "playlist" ? yu() : ke === "top" ? bu() : "";
  Ti.has(ke) ? n += `<div class="music-empty">${a("music.loading")}</div>` : s ? n += `<div class="music-empty music-empty-err">${l(s)}</div>` : i && (n += i.length === 0 ? `<div class="music-empty">${a(ke === "playlist" ? "music.playlists_empty" : "music.lib_empty")}</div>` : i.map((c) => bs(ke, c)).join("")), T(e, n);
}
function Fs(t) {
  t.querySelectorAll("#music-side-list .music-pl").forEach((e) => {
    const i = e.querySelector(".music-pl-btn"), s = !!I && (i == null ? void 0 : i.dataset.kind) === I.kind && (i == null ? void 0 : i.dataset.id) === I.id;
    e.classList.toggle("on", s);
  });
}
function xe(t) {
  if (te) {
    Zi(t);
    return;
  }
  const e = t.querySelector("#music-main");
  if (!e) return;
  if (bt && He) {
    T(e, gu());
    return;
  }
  if (!I) {
    T(e, `<div class="music-empty">${p != null && p.connected ? a("music.pick_hint") : a("music.playlists_login")}</div>`);
    return;
  }
  const i = I.cover ? `<img src="${l(I.cover)}" alt="">` : "", s = I.kind === "liked" ? a("music.liked_songs") : I.kind === "top-tracks" ? a("music.top_tracks") : I.kind === "playlist" ? a("music.playlists") : I.kind === "album" ? a("music.tab_albums") : I.kind === "artist" ? a("music.tab_artists") : I.kind === "top" ? a("music.tab_top") : a("music.tab_shows");
  let n;
  Kt ? n = `<div class="music-empty">${a("music.loading")}</div>` : rt ? n = `<div class="music-empty music-empty-err">${l(rt)}</div>` : !Ce || Ce.length === 0 ? n = `<div class="music-empty">${a("music.playlist_empty")}</div>` : n = Ce.map((c, d) => Ts(c, d, "main-track", String(d))).join(""), T(e, `<div class="music-page">
    <div class="music-page-head">
      <span class="music-page-cover${I.kind === "artist" ? " round" : ""}">${i}</span>
      <div class="music-page-info">
        <span class="music-page-kind">${l(s)}</span>
        <span class="music-page-name">${l(I.name || "?")}</span>
        <span class="music-page-sub">${l(I.subtitle)}</span>
        <div class="music-page-actions">
          <button class="music-btn music-primary" data-act="main-play-all">${h.play} ${a("music.play_all")}</button>
        </div>
      </div>
    </div>
    <div class="music-list">${n}</div>
  </div>`);
}
function gu() {
  const t = H, i = [
    ["tracks", a("music.tracks")],
    ["artists", a("music.tab_artists")],
    ["albums", a("music.tab_albums")],
    ["playlists", a("music.playlists")],
    ["shows", a("music.tab_shows")]
  ].map(([n, c]) => `<button class="music-tab${Ve === n ? " on" : ""}" data-act="search-tab" data-tab="${n}">${l(c)}</button>`).join("");
  let s;
  if (ri || !t)
    s = `<div class="music-empty">${a("music.loading")}</div>`;
  else if (Ve === "tracks")
    s = t.tracks.length ? t.tracks.map((n, c) => Ts(n, c, "main-track", String(c))).join("") : `<div class="music-empty">${a("music.search_empty")}</div>`;
  else {
    const c = (Ve === "artists" ? t.artists : Ve === "albums" ? t.albums : Ve === "shows" ? t.shows : t.playlists.map(Cs)).map((d) => hu(Ve === "playlists" ? "playlist" : Ve === "artists" ? "artist" : Ve === "albums" ? "album" : "show", d));
    s = c.length ? `<div class="music-grid">${c.join("")}</div>` : `<div class="music-empty">${a("music.search_empty")}</div>`;
  }
  return `<div class="music-page">
    <div class="music-page-info music-page-info-flat">
      <span class="music-page-kind">${a("music.search_result")}</span>
      <span class="music-page-name">${l(He)}</span>
    </div>
    <div class="music-tabs">${i}</div>
    <div class="music-list">${s}</div>
  </div>`;
}
function Je(t) {
  const e = t.querySelector("#music-search-dd");
  if (!e) return;
  const i = !!(p != null && p.connected) && Pe && !!He;
  if (A(e, i), !i) return;
  if (!H) {
    T(e, ri ? `<div class="music-empty">${a("music.loading")}</div>` : "");
    return;
  }
  const s = H, n = [];
  s.tracks.slice(0, 3).forEach((c, d) => n.push(Ts(c, d, "dd-track"))), s.artists.slice(0, 2).forEach((c) => n.push(bs("artist", c))), s.albums.slice(0, 2).forEach((c) => n.push(bs("album", c))), s.playlists.slice(0, 2).forEach((c) => n.push(bs("playlist", Cs(c)))), n.length || n.push(`<div class="music-empty">${a("music.search_empty")}</div>`), n.push(`<button class="music-dd-all" data-act="search-all">${a("music.search_all")}</button>`), T(e, n.join(""));
}
function vi(t) {
  const e = t.querySelector("#music-dev-dd");
  if (!e || (A(e, st), !st)) return;
  const i = ae;
  let s = `<div class="music-dd-head">${a("music.devices")}</div>`;
  i != null && i.available && !i.has_credentials ? s += `<button class="music-dev-row" data-act="local-login">
      <span class="music-dev-ico">${h.power}</span>
      <span class="music-dev-main">
        <span class="music-dev-n">${a("music.local_login")}</span>
        <span class="music-dev-s">${a("music.local_login_hint")}</span>
      </span>
    </button>` : i != null && i.available ? s += `<button class="music-dev-row${i.running ? " on" : ""}" data-act="local-toggle">
      <span class="music-dev-ico">${h.power}</span>
      <span class="music-dev-main">
        <span class="music-dev-n">${a("music.local_play")}</span>
        <span class="music-dev-s">${l(i.path || "")}</span>
      </span>
    </button>` : s += `<div class="music-dev-row disabled">
      <span class="music-dev-ico">${h.power}</span>
      <span class="music-dev-main">
        <span class="music-dev-n">${a("music.local_play")}</span>
        <span class="music-dev-s">${a("music.local_no_exe")}</span>
      </span>
    </div>`;
  const n = Bt ?? [];
  s += n.length ? n.map((c) => `<button class="music-dev-row${c.active ? " on" : ""}" data-act="dev-pick" data-id="${l(c.id)}">
        <span class="music-dev-ico">${h.speaker}</span>
        <span class="music-dev-main">
          <span class="music-dev-n">${l(c.name || "?")}</span>
          <span class="music-dev-s">${l(c.kind)}</span>
        </span>
      </button>`).join("") : `<div class="music-empty">${a("music.device_none")}</div>`, T(e, s);
}
function _u(t) {
  var s;
  const e = (_ == null ? void 0 : _.context_uri) ?? "", i = ((s = _ == null ? void 0 : _.track) == null ? void 0 : s.uri) ?? "";
  t.querySelectorAll(".music-pl").forEach((n) => {
    n.classList.toggle("playing", !!e && n.dataset.uri === e);
  }), t.querySelectorAll(".music-tr").forEach((n) => {
    n.classList.toggle("playing", !!i && n.dataset.uri === i);
  });
}
function wu(t) {
  if (!t) return "";
  const e = new Date(t), i = (s) => String(s).padStart(2, "0");
  return `${e.getFullYear()}-${i(e.getMonth() + 1)}-${i(e.getDate())} ${i(e.getHours())}:${i(e.getMinutes())}`;
}
function sn(t) {
  me && (Oe = !1);
  const e = (i, s) => A(t.querySelector(i), s);
  e("#music-local-add", !me), e("#music-local-list", !me), e("#music-local-del", me), e("#music-local-editdone", me), Yi(t), $i(t);
}
function $i(t) {
  const e = t.querySelector("#music-local-add-dd");
  e && (A(e, Oe), Oe && T(e, `
    <div class="music-dd-head">${l(a("music.local_add_head"))}</div>
    <button class="music-dev-row" data-act="media-add-dir">
      <span class="music-dev-ico">${h.folder}</span>
      <span class="music-dev-main">
        <span class="music-dev-n">${l(a("music.local_add_dir"))}</span>
        <span class="music-dev-s">${l(a("music.local_add_dir_hint"))}</span>
      </span>
    </button>
    <button class="music-dev-row" data-act="media-add-list">
      <span class="music-dev-ico">${h.list}</span>
      <span class="music-dev-main">
        <span class="music-dev-n">${l(a("music.local_open_playlist"))}</span>
        <span class="music-dev-s">${l(a("music.local_add_list_hint"))}</span>
      </span>
    </button>`));
}
function ku(t) {
  const e = t.missing ? a("music.local_missing") : [
    a("music.local_n_tracks", { n: String(t.tracks) }),
    t.last_scan_at ? wu(t.last_scan_at) : a("music.local_never_scanned")
  ].join(" · "), i = me && $e.has(t.path);
  return `<div class="music-pl${Fe === t.path ? " on" : ""}${t.missing ? " err" : ""}${i ? " sel" : ""}">
    <button class="music-pl-btn" data-act="media-root" data-path="${l(t.path)}" title="${l(t.path)}">
      <span class="music-pl-cover music-pl-dir">${h.folder}</span>
      <span class="music-pl-main">
        <span class="music-pl-name">${l(t.name || t.path)}</span>
        <span class="music-pl-sub">${l(e)}</span>
      </span>
    </button>
  </div>`;
}
function je(t) {
  A(t.querySelector("#music-side-tabs"), !1), A(t.querySelector("#music-local-head"), !0), sn(t);
  const e = t.querySelector("#music-side-list");
  if (!e) return;
  const i = (fe ?? []).filter((c) => !ji.has(c.path)), s = i.reduce((c, d) => c + d.tracks, 0);
  let n = `<div class="music-pl${Fe === "" ? " on" : ""}">
    <button class="music-pl-btn" data-act="media-root" data-path="" title="${l(a("music.local_all"))}">
      <span class="music-pl-cover music-pl-dir">${h.note}</span>
      <span class="music-pl-main">
        <span class="music-pl-name">${l(a("music.local_all"))}</span>
        <span class="music-pl-sub">${l(a("music.local_n_tracks", { n: String(s) }))}</span>
      </span>
    </button>
  </div>`;
  Ss ? n += `<div class="music-empty">${a("music.loading")}</div>` : mi ? n += `<div class="music-empty music-empty-err">${l(mi)}</div>` : fe && i.length === 0 ? n += `<div class="music-empty">${l(a("music.local_no_roots"))}</div>` : fe && (n += i.map((c) => ku(c)).join("")), n += $u(), T(e, n);
}
function Su(t) {
  const e = t.id === ce, i = t.name || a("music.local_queue_edit");
  return `<div class="music-pl${e ? " on" : ""}">
    <button class="music-pl-btn" data-act="local-queue" data-qid="${l(t.id)}" title="${l(i)}">
      <span class="music-pl-cover music-pl-dir">${h.list}</span>
      <span class="music-pl-main">
        <span class="music-pl-name">${l(i)}</span>
        <span class="music-pl-sub">${l(a("music.local_n_tracks", { n: String(t.items.length) }))}</span>
      </span>
    </button>
  </div>`;
}
function $u() {
  const t = Ke.map(Su).join("");
  return `<div class="music-lqs">
    <div class="music-lqs-head">${l(a("music.local_queue_edit"))}</div>
    ${t}
  </div>`;
}
function mn(t, e, i = "local-track") {
  const s = t.cover ? `<img src="${l(Es(t.cover))}" alt="">` : `<span class="music-mt-ico">${h.note}</span>`, n = [t.artist, t.album].filter(Boolean).join(" · "), c = !!(S != null && S.active) && S.path === t.path, d = i === "local-track" || i === "queue-track", v = d && N.has(t.path), k = d && (X || me && ce !== null) ? `<span class="music-mt-i music-mt-check${v ? " on" : ""}">${v ? h.check : ""}</span>` : `<span class="music-mt-i">${e + 1}</span>`;
  return `<button class="music-mt${c ? " playing" : ""}${v ? " sel" : ""}" data-act="${i}" data-i="${e}" data-path="${l(t.path)}" title="${l(t.path)}">
    ${k}
    <span class="music-mt-cover">${s}</span>
    <span class="music-mt-main">
      <span class="music-mt-n">${l(t.title || "?")}</span>
      <span class="music-mt-a">${l(n)}</span>
    </span>
    <span class="music-mt-d">${Ni(t.duration_ms)}</span>
  </button>`;
}
function Zi(t) {
  const e = t.querySelector("#music-main");
  if (!e) return;
  if (ce !== null) {
    e.querySelector("#music-queue-page") || (e.innerHTML = Eu());
    const s = t.querySelector("#music-lq-q");
    s && s.value !== at && (s.value = at), Oi(t), en(t), Yi(t);
    return;
  }
  e.querySelector("#music-local-page") || (e.innerHTML = `<div class="music-local-page" id="music-local-page">
      <div class="music-local-head-row">
        <input class="music-local-q" id="music-mt-q" type="search" autocomplete="off" spellcheck="false"
               placeholder="${l(a("music.local_filter_ph"))}" value="${l(Ui)}">
        <span class="music-list-chip hidden" id="music-list-chip">
          <span class="music-list-chip-n" id="music-list-chip-n"></span>
          <button class="music-pl-x" data-act="media-list-close" title="${l(a("music.local_close_playlist"))}">${h.x}</button>
        </span>
        <!-- 重扫（2026-10-01 用户口径）：**只留图标**，「重扫」那两个可见字去掉 ——
             它右边紧挨着设置齿轮（见 placeGear），带文字那一行会挤。
             title 仍然留着（鼠标悬浮还能问出这是什么）；去掉的是**可见文字**。
             **这是全页唯一一枚扫描按钮**（2026-10-10 用户口径：扫描只留一枚，左栏那枚已删）；
             「自定义队列」模式开启时它会变成「退出」（图标 ×，见 applyQueueModeUi）。
             ⚠️ 本行属于**动态骨架**（#music-main 会被 renderMain 整块重写、回来时重建），
             所以它（与右边那枚 qmode）只能走 data-act 委托，直接 addEventListener 会在下次重建时失效。 -->
        <button class="music-ghost-btn music-icon-btn" id="music-scan-btn" data-act="media-scan" title="${l(a("music.local_rescan"))}">${h.refresh}</button>
        <!-- 「自定义队列」开关（2026-10-10 用户口径）：放在筛选标题行**最右侧**、只在本地页显示
             （它长在本骨架里，离开本地页整页被换掉 ⇒ 天然隐藏）。开启时高亮，并把上面那枚扫描
             变成「退出」；开启 = 进「自定义队列编辑态」（列表每行可勾选，见 mediaTrackRowHtml /
             onListClick），把这批勾中的歌用**齿轮「添加到队列」**追加进 localQueue（2026-10-11
             用户口径，齿轮语义见 applyGearQueueState）。同样走 data-act 委托。
             注：本段在模板字符串里，注释里一个反引号都不能出现（预检 #15 / #39 ⑩）。 -->
        <button class="music-ghost-btn music-icon-btn music-local-qmode" id="music-local-qmode" data-act="qmode" aria-pressed="false" title="${l(a("music.local_queue_edit"))}">${h.list}</button>
      </div>
      <div class="music-scan hidden" id="music-scan"></div>
      <!-- 视频的**画面层**（2026-10-01 用户第 8 条）。里面那个 video 元素由
           renderLocalVideo 现造现拆（离开 / 换曲时整块清掉，见那里的注释）。
           注：本段在模板字符串里，注释里一个反引号都不能出现（预检 #15 / #39 ⑩）。 -->
      <div class="music-video hidden" id="music-video"></div>
      <div class="music-list" id="music-mt-list"></div>
    </div>`), A(t.querySelector("#music-mt-q"), !Te);
  const i = t.querySelector("#music-list-chip");
  A(i, !!Te), Te && E(
    t.querySelector("#music-list-chip-n"),
    `${Te.name} · ${a("music.local_n_tracks", { n: String((P == null ? void 0 : P.total) ?? 0) })}`
  ), qu(t), Pc(t), hs(t), en(t), Yi(t);
}
function qu(t) {
  const e = t.querySelector("#music-scan");
  if (!e) return;
  const i = Zt;
  let s = "";
  if (i != null && i.running) {
    const n = i.total, c = n > 0 ? Math.min(100, Math.round(i.scanned / n * 100)) : 0, d = n > 0 ? a("music.local_scanning", { a: String(i.scanned), b: String(n) }) : a("music.local_scanning_n", { a: String(i.scanned) });
    s = `<div class="music-scan-row">
      <span class="music-scan-bar"><span class="music-scan-fill" style="width:${c}%"></span></span>
      <span class="music-scan-txt">${l(d)}</span>
    </div>`;
  } else i != null && i.error ? s = `<div class="music-scan-row music-scan-err">${l(i.error)}</div>` : i != null && i.done_at && (s = `<div class="music-scan-row music-scan-done">${l(a("music.local_scan_done", {
    added: String(i.added),
    updated: String(i.updated),
    removed: String(i.removed),
    failed: String(i.failed)
  }))}</div>`);
  T(e, s), A(e, !!s);
}
function hs(t) {
  const e = t.querySelector("#music-mt-list");
  if (!e) return;
  let i;
  pi ? i = `<div class="music-empty">${a("music.loading")}</div>` : St ? i = `<div class="music-empty music-empty-err">${l(St)}</div>` : !Te && fe && fe.length === 0 ? i = `<div class="music-empty">${l(a("music.local_add_hint"))}</div>` : !P || P.items.length === 0 ? i = `<div class="music-empty">${l(a(Te ? "music.local_list_empty" : "music.local_empty"))}</div>` : (i = P.items.map((s, n) => mn(s, n)).join(""), P.total > P.items.length && (i += `<div class="music-empty">${l(a("music.local_more", {
    a: String(P.items.length),
    b: String(P.total)
  }))}</div>`)), T(e, i), pn(t);
}
const xu = [
  "mp3",
  "flac",
  "m4a",
  "m4b",
  "mp4",
  "aac",
  "ogg",
  "oga",
  "opus",
  "spx",
  "wav",
  "wave",
  "aif",
  "aiff",
  "aifc",
  "ape",
  "wv",
  "mpc",
  "m4v",
  "mov"
];
function Lu(t) {
  const e = t.split(/[\\/]/).pop() || t, i = e.lastIndexOf(".");
  return {
    path: t,
    title: i > 0 ? e.slice(0, i) : e,
    artist: "",
    album: "",
    duration_ms: 0,
    cover: "",
    ext: i > 0 ? e.slice(i + 1).toLowerCase() : "",
    size: 0
  };
}
function pn(t) {
  if (!ei) return;
  const e = t.querySelector("#music-main");
  if (!e) return;
  const i = Array.from(e.querySelectorAll(".music-mt")).find((c) => c.dataset.path === ei);
  if (!i) return;
  const n = i.getBoundingClientRect().top - e.getBoundingClientRect().top + e.scrollTop - Math.max(0, (e.clientHeight - i.clientHeight) / 2);
  e.scrollTop = Math.max(0, n), ei = "";
}
function Eu() {
  return `<div class="music-local-page" id="music-queue-page">
    <div class="music-local-head-row">
      <button class="music-ghost-btn music-icon-btn" data-act="queue-back" title="${l(a("music.settings_back"))}">${h.back}</button>
      <input class="music-local-q" id="music-lq-q" type="search" autocomplete="off" spellcheck="false"
             placeholder="${l(a("music.local_filter_ph"))}" value="${l(at)}">
    </div>
    <div class="music-list" id="music-lq-list"></div>
  </div>`;
}
function Oi(t) {
  var c;
  const e = t.querySelector("#music-lq-list");
  if (!e) return;
  const i = at.trim().toLowerCase(), s = (((c = Vi()) == null ? void 0 : c.items) ?? []).filter((d) => !zt.has(d.path)).filter((d) => !i || [d.title, d.artist, d.album].some((v) => (v || "").toLowerCase().includes(i))), n = s.length === 0 ? `<div class="music-empty">${l(a("music.local_queue_page_empty"))}</div>` : s.map((d, v) => mn(d, v, "queue-track")).join("");
  T(e, n), pn(t);
}
function _t(t) {
  const e = t.querySelector("#music-queue-dlg");
  if (!e || (A(e, Me), !Me)) return;
  const i = t.querySelector("#music-queue-files"), s = Xe.length === 0 ? `<div class="music-empty">${l(a("music.local_queue_files_empty"))}</div>` : `<div class="music-queue-file">${l(a("music.local_queue_files_n", { n: String(Xe.length) }))}</div>` + Xe.map((n) => `<div class="music-queue-file" title="${l(n)}">${l(n.split(/[\\/]/).pop() || n)}</div>`).join("");
  T(i, s);
}
function Ic(t, e = []) {
  Me = !0;
  const i = /* @__PURE__ */ new Set();
  Xe = [];
  for (const n of e) {
    const c = n.toLowerCase();
    !n || i.has(c) || (i.add(c), Xe.push(n));
  }
  _t(t);
  const s = t.querySelector("#music-queue-name");
  s && (s.value = "", setTimeout(() => s.focus(), 0));
}
async function Mu(t) {
  let e = null;
  try {
    e = await Xi({
      multiple: !0,
      title: a("music.local_queue_pick"),
      filters: [{ name: "Audio / Video", extensions: xu }]
    });
  } catch (n) {
    $(t, String(n));
    return;
  }
  if (!e) return;
  const i = Array.isArray(e) ? e : [e], s = new Set(Xe.map((n) => n.toLowerCase()));
  for (const n of i) {
    const c = n.toLowerCase();
    !n || s.has(c) || (s.add(c), Xe.push(n));
  }
  _t(t);
}
function Ga(t) {
  var s;
  if (Xe.length === 0) {
    $(t, a("music.local_queue_need_files"));
    return;
  }
  const e = t.querySelector("#music-queue-name"), i = {
    id: wc(),
    name: Al(((e == null ? void 0 : e.value) ?? "").trim()),
    items: Xe.map(Lu)
  };
  Ke.push(i), ce = i.id, ti(), Me = !1, X = !1, N.clear(), _t(t), te && (je(t), (s = t.querySelector("#music-queue-page")) == null || s.remove(), Zi(t)), ne(t), $(t, a("music.local_queue_created", { name: i.name }));
}
function Tu(t) {
  const i = ((P == null ? void 0 : P.items) ?? []).filter((s) => N.has(s.path));
  Ic(t, i.map((s) => s.path));
}
function Dc(t) {
  const e = t.querySelector("#music-del-dlg");
  if (!e) return;
  const i = Qi !== null;
  if (A(e, i), !i) return;
  const s = Qi;
  E(
    t.querySelector("#music-del-text"),
    a("music.ctx_delete_confirm", { name: s.name })
  );
}
function Cu(t, e, i) {
  Qi = { path: e, name: i || e.split(/[\\/]/).pop() || e }, Dc(t);
}
function nn(t) {
  Qi = null, Dc(t);
}
async function Au(t) {
  const e = Qi;
  if (!e) return;
  const i = e.path;
  nn(t);
  try {
    await r("media_delete_file", { path: i });
  } catch (s) {
    $(t, String(s));
    return;
  }
  N.delete(i), (S == null ? void 0 : S.path) === i && await Jt(t), await Ht(t), $(t, a("music.ctx_deleted"));
}
function Iu() {
  const t = ze;
  if (!t) return "";
  const e = (s, n, c = !1) => `<button class="music-ctx-item${c ? " danger" : ""}" data-ctx="${s}">${l(n)}</button>`, i = [];
  return t.act === "local-track" && i.push(e("add-queue", a("music.ctx_add_queue"))), t.act === "queue-track" && i.push(e("remove-queue", a("music.ctx_remove_queue"), !0)), (t.act === "local-track" || t.act === "queue-track") && t.path && (i.push(e("reveal", a("music.ctx_reveal"))), i.push(e("delete-file", a("music.ctx_delete_file"), !0))), (t.act === "main-track" || t.act === "play-uri" || t.act === "queue-play") && i.push(e("play", a("music.ctx_play"))), i.join("");
}
function Rc(t, e, i) {
  const s = t.querySelector("#music-ctx");
  if (!s) return;
  const n = t.getBoundingClientRect(), c = Math.max(2, Math.min(e - n.left, n.width - 132)), d = Math.max(2, Math.min(i - n.top, n.height - 160));
  s.style.left = `${c}px`, s.style.top = `${d}px`, s.classList.add("open"), requestAnimationFrame(() => {
    if (!s.isConnected) return;
    const v = s.getBoundingClientRect();
    v.width && v.height && (v.right > n.right && (s.style.left = `${Math.max(2, n.width - v.width - 8)}px`), v.bottom > n.bottom && (s.style.top = `${Math.max(2, n.height - v.height - 8)}px`));
  });
}
function Du(t, e, i) {
  const s = t.querySelector("#music-ctx");
  s && (T(s, Iu()), s.querySelector("button") && Rc(t, e, i));
}
function Ru(t, e, i) {
  const s = t.querySelector("#music-ctx");
  if (!s) return;
  const n = Ke.map((c) => `<button class="music-ctx-item" data-ctx="pick:${l(c.id)}">${l(c.name || a("music.local_queue_edit"))}</button>`);
  n.push(`<button class="music-ctx-item" data-ctx="pick-new">${l(a("music.ctx_new_queue"))}</button>`), T(s, n.join("")), Rc(t, e, i);
}
function ft(t) {
  var e;
  (e = t.querySelector("#music-ctx")) == null || e.classList.remove("open"), ze = null;
}
function Nc() {
  const t = (P == null ? void 0 : P.items) ?? [], e = t.filter((i) => N.has(i.path));
  if (e.length) return e;
  if (ze != null && ze.path) {
    const i = t.find((s) => s.path === ze.path);
    if (i) return [i];
  }
  return [];
}
function Nu(t, e) {
  const i = Ke.find((d) => d.id === e);
  if (!i) return;
  const s = Nc();
  if (!s.length) return;
  const n = new Set(i.items.map((d) => d.path.toLowerCase()));
  let c = 0;
  for (const d of s) {
    const v = d.path.toLowerCase();
    n.has(v) || (n.add(v), i.items.push(d), c++);
  }
  c && (ti(), $(t, a("music.ctx_added_to_queue", { name: i.name || a("music.local_queue_edit") })), je(t));
}
function Pc(t) {
  const e = t.querySelector("#music-video");
  if (!e) return;
  const i = S, s = !!i && i.video && i.path !== "";
  if (A(e, s), !s) {
    e.firstChild && (e.innerHTML = "");
    return;
  }
  const n = Es(i.path);
  let c = e.querySelector(".music-video-el");
  if (!c || c.dataset.src !== n) {
    if (e.innerHTML = '<video class="music-video-el" muted playsinline preload="auto"></video>', c = e.querySelector(".music-video-el"), !c) return;
    c.dataset.src = n, c.src = n, c.addEventListener("loadedmetadata", () => Ya(c, i), { once: !0 }), c.addEventListener("error", () => {
      xt(t, a("music.video_unsupported"));
    });
  }
  Ya(c, i);
}
function Ya(t, e) {
  e.playing ? t.paused && t.play().catch(() => {
  }) : t.paused || t.pause();
  const i = e.playing ? Date.now() - Ki : 0, s = (e.position_ms + Math.max(0, i)) / 1e3;
  t.readyState >= 1 && !t.seeking && Math.abs(t.currentTime - s) > ql && (t.currentTime = s);
}
function Oc(t) {
  if (D !== "lplayer") return;
  const e = t.querySelector("#music-v-lplayer"), i = S;
  if (!e || !i || !i.path) return;
  const s = K[F], n = (s == null ? void 0 : s.title) || i.path.split(/[\\/]/).pop() || i.path;
  E(e.querySelector("#music-lp-title"), n), E(e.querySelector("#music-lp-sub"), s ? [s.artist, s.album].filter(Boolean).join(" · ") : ""), T(
    e.querySelector("#music-lp-cover"),
    s != null && s.cover ? `<img src="${l(Es(s.cover))}" alt="">` : h.note
  ), T(e.querySelector("#music-lp-play"), i.active && i.playing ? h.pause : h.play);
  const c = e.querySelector("#music-lp-mode");
  c && (oe(c, "data-mode", le), oe(c, "title", rn()), T(c, le === "repeat_all" || le === "repeat_one" ? h.repeat : h.shuffle));
  const d = i.duration_ms, v = ue >= 0 ? ue : d > 0 ? Math.min(1, i.position_ms / d) : 0, w = e.querySelector("#music-lp-progress");
  w && ue < 0 && w.style.setProperty("--seek-pct", `${v * 100}%`), E(e.querySelector("#music-lp-time"), d > 0 ? `${j(i.position_ms)} / ${j(d)}` : j(i.position_ms));
  const q = e.querySelector("#music-lp-vol");
  q && document.activeElement !== q && (q.value = String(Math.round(i.volume * 100)), si(q, i.volume * 100));
}
function Pu(t) {
  var s, n;
  const e = t.querySelector("#music-lq-dd");
  if (!e || (A(e, Le), (s = t.querySelector("#music-l-queue")) == null || s.classList.toggle("on", Le), (n = t.querySelector("#music-lp-queue")) == null || n.classList.toggle("on", Le), !Le)) return;
  const i = K.length === 0 ? `<div class="music-empty">${l(a("music.local_play_queue_empty"))}</div>` : K.map((c, d) => mn(c, d, "queue-play")).join("");
  T(e, i);
}
function ne(t) {
  Pc(t), Oc(t), Pu(t);
  const e = t.querySelector("#music-lnowbar");
  if (!e) return;
  const i = S, s = !!i && i.path !== "", n = yc();
  if (A(e, n), !n) return;
  const c = K[F] ?? null, d = (i && s ? i.path : "") || (c == null ? void 0 : c.path) || "";
  if (!c && !s) {
    E(e.querySelector("#music-lnow-n"), a("music.local_bar_empty")), E(e.querySelector("#music-lnow-a"), ""), T(e.querySelector("#music-lnow-cover"), h.note), T(e.querySelector("#music-l-play"), h.play), E(e.querySelector("#music-l-time"), "0:00");
    const k = e.querySelector("#music-lbp");
    k && ue < 0 && k.style.setProperty("--seek-pct", "0%");
  } else {
    const k = (c == null ? void 0 : c.title) || d.split(/[\\/]/).pop() || d;
    E(e.querySelector("#music-lnow-n"), k), E(e.querySelector("#music-lnow-a"), c ? [c.artist, c.album].filter(Boolean).join(" · ") : ""), T(
      e.querySelector("#music-lnow-cover"),
      c != null && c.cover ? `<img src="${l(Es(c.cover))}" alt="">` : h.note
    ), T(e.querySelector("#music-l-play"), i != null && i.active && (i != null && i.playing) ? h.pause : h.play);
    const C = (i && s ? i.duration_ms : 0) || (c == null ? void 0 : c.duration_ms) || 0, L = i && s ? i.position_ms : De, B = ue >= 0 ? ue : C > 0 ? Math.min(1, L / C) : 0, z = e.querySelector("#music-lbp");
    z && ue < 0 && z.style.setProperty("--seek-pct", `${B * 100}%`), E(e.querySelector("#music-l-time"), C > 0 ? `${j(L)} / ${j(C)}` : j(L));
  }
  const v = !!c || s;
  for (const k of ["#music-l-prev", "#music-l-next", "#music-l-mode", "#music-l-stop", "#music-l-play"]) {
    const C = e.querySelector(k);
    C && (C.disabled = !v);
  }
  const w = e.querySelector("#music-l-mode");
  w && (oe(w, "data-mode", le), oe(w, "title", rn()), T(w, le === "repeat_all" || le === "repeat_one" ? h.repeat : h.shuffle));
  const q = e.querySelector("#music-l-vol");
  if (q && document.activeElement !== q) {
    const k = i ? i.volume : Number(q.value) / 100;
    q.value = String(Math.round(k * 100)), si(q, k * 100);
  }
}
function fn(t) {
  const e = S != null && S.active ? S.path : "";
  t.querySelectorAll(".music-mt").forEach((i) => {
    i.classList.toggle("playing", !!e && i.dataset.path === e);
  });
}
function Ze(t) {
  te && (je(t), Zi(t), ne(t));
}
async function Bc(t) {
  Ss = !0, mi = "", Ze(t);
  try {
    fe = await r("media_roots");
  } catch (e) {
    mi = String(e);
  } finally {
    Ss = !1, Ze(t);
  }
}
async function Ht(t) {
  Te = null, pi = !0, St = "", Ze(t);
  try {
    P = await r("media_tracks", {
      // 空串 ⇒ 传 null（宿主的 `Option<String>` 收 None = 全库 / 不筛选）
      root: Fe || null,
      query: Ui || null,
      limit: wl
    });
  } catch (e) {
    St = String(e);
  } finally {
    pi = !1, Ze(t);
  }
}
function ai() {
  Ii !== void 0 && (window.clearInterval(Ii), Ii = void 0);
}
function zc(t) {
  Ii === void 0 && (Ii = window.setInterval(() => {
    (async () => {
      if (!t.isConnected) {
        ai();
        return;
      }
      try {
        const e = await r("media_scan_status");
        Zt = e, e.running || (ai(), await Bc(t), await Ht(t));
      } catch {
        ai();
      }
      Ze(t);
    })();
  }, kl));
}
async function Wc(t, e) {
  try {
    Zt = await r("media_scan_start", { root: e || null });
  } catch (i) {
    const s = String(i);
    $(t, s.includes("ERR_SCAN_RUNNING") ? a("music.local_scan_busy") : s);
    return;
  }
  Ze(t), zc(t);
}
async function Ou(t) {
  let e = null;
  try {
    e = await Xi({ directory: !0, multiple: !1, title: a("music.local_add_dir") });
  } catch (i) {
    $(t, String(i));
    return;
  }
  if (!(typeof e != "string" || !e)) {
    try {
      fe = await r("media_add_root", { path: e });
    } catch (i) {
      $(t, String(i));
      return;
    }
    Fe = Bu(e), Ze(t), await Wc(t, Fe || e);
  }
}
function Bu(t) {
  var s;
  const e = (n) => n.replace(/[\\/]+$/, "").toLowerCase(), i = e(t);
  return ((s = fe == null ? void 0 : fe.find((n) => e(n.path) === i)) == null ? void 0 : s.path) ?? "";
}
function zu(t) {
  me = !0, X = !1, $e.clear(), zt.clear(), je(t), ce !== null && Zi(t);
}
function Wu(t) {
  if (ce !== null) {
    if (!N.size) return;
    for (const e of N) zt.add(e);
    N.clear(), Oi(t);
    return;
  }
  if ($e.size) {
    for (const e of $e) ji.add(e);
    $e.clear(), je(t);
  }
}
async function Hu(t) {
  if (ce !== null) {
    const s = Vi(), n = Array.from(zt);
    if (me = !1, $e.clear(), N.clear(), zt.clear(), sn(t), je(t), s && n.length) {
      const c = new Set(n);
      s.items = s.items.filter((d) => !c.has(d.path)), ti();
    }
    Zi(t);
    return;
  }
  const e = Array.from(ji);
  if (me = !1, $e.clear(), ji.clear(), sn(t), !e.length) {
    je(t);
    return;
  }
  let i = "";
  for (const s of e)
    try {
      fe = await r("media_remove_root", { path: s });
    } catch (n) {
      const c = String(n);
      i = c.includes("ERR_SCAN_RUNNING") ? a("music.local_remove_busy") : c;
    }
  Fe && !(fe ?? []).some((s) => s.path === Fe) && (Fe = ""), je(t), await Ht(t), i && $(t, i);
}
function Fu(t) {
  const e = t instanceof Error ? t.message : String(t);
  return e.includes("ERR_NOT_PLAYLIST") ? a("music.local_not_playlist") : e;
}
async function ju(t) {
  let e = null;
  try {
    e = await Xi({
      multiple: !1,
      title: a("music.local_open_playlist"),
      filters: [{ name: "Playlist", extensions: ["m3u", "m3u8", "pls"] }]
    });
  } catch (i) {
    $(t, String(i));
    return;
  }
  if (!(typeof e != "string" || !e)) {
    pi = !0, St = "", P = null, Ze(t);
    try {
      P = await r("media_playlist", { path: e }), Te = { path: e, name: e.split(/[\\/]/).pop() || e }, Fe = "";
    } catch (i) {
      Te = null, St = Fu(i);
    } finally {
      pi = !1, Ze(t);
    }
  }
}
function Uu(t) {
  Te = null, Ht(t);
}
function Hc(t) {
  const e = t instanceof Error ? t.message : String(t);
  return e.includes("ERR_NO_AUDIO_DEVICE") ? a("music.local_no_device") : e.includes("找不到这个文件") ? a("music.local_file_missing") : e.includes("解不开") || e.includes("打不开") ? a("music.local_decode_failed") : e;
}
async function qt(t, e, i = 0) {
  if (Tt) return !1;
  await es(t, "local"), Tt = !0;
  try {
    S = await r("player_play", { path: e });
  } catch (s) {
    return $(t, Hc(s)), Tt = !1, !1;
  }
  if (Tt = !1, De = 0, i > 0)
    try {
      S = await r("player_seek", { positionMs: Math.round(i) }), De = S.position_ms;
    } catch {
    }
  return Ki = Date.now(), Ms(), ei = e, ne(t), fn(t), pn(t), Fc(t), !0;
}
async function Qu(t, e) {
  const i = (P == null ? void 0 : P.items) ?? [], s = i[e];
  s && (K = i.slice(), F = e, kt = [], await qt(t, s.path));
}
async function Vu(t, e) {
  const i = Vi();
  if (!i || !e) return;
  const s = i.items.findIndex((n) => n.path === e);
  s < 0 || (K = i.items.slice(), F = s, kt = [], await qt(t, e));
}
async function js(t, e) {
  const i = K[e];
  i && (F = e, kt = [], await qt(t, i.path));
}
function ss(t) {
  if (!t) return !1;
  const e = !N.has(t);
  return e ? N.add(t) : N.delete(t), e;
}
function ns(t, e) {
  t.classList.toggle("sel", e);
  const i = t.querySelector(".music-mt-i");
  i && i.classList.contains("music-mt-check") && (i.classList.toggle("on", e), i.innerHTML = e ? h.check : "");
}
function as(t, e) {
  t.classList.toggle("sel", e);
}
async function qi(t, e, i) {
  var c;
  const s = K.length;
  if (s === 0) return;
  if (i && le === "repeat_one") {
    await qt(t, ((c = K[F]) == null ? void 0 : c.path) ?? "");
    return;
  }
  let n;
  if (le === "shuffle" && s > 1)
    if (e < 0 && kt.length > 0)
      n = kt.pop();
    else {
      do
        n = Math.floor(Math.random() * s);
      while (n === F);
      F >= 0 && kt.push(F);
    }
  else
    n = F + e;
  if (le === "repeat_all" || le === "shuffle")
    n = (n % s + s) % s;
  else if (n < 0 || n >= s) {
    i || $(t, a("music.local_queue_end"));
    return;
  }
  F = n, await qt(t, K[n].path);
}
async function Ja(t) {
  var i;
  if (Tt) return;
  const e = S;
  if (!e || e.path === "") {
    const s = ((i = K[F]) == null ? void 0 : i.path) ?? "";
    if (!s) return;
    await qt(t, s, De);
    return;
  }
  if (!e.active) {
    await qt(t, e.path);
    return;
  }
  try {
    S = await r(e.playing ? "player_pause" : "player_resume");
  } catch (s) {
    $(t, Hc(s));
    return;
  }
  Ki = Date.now(), ne(t), S != null && S.active && Fc(t);
}
async function Jt(t) {
  ci(), S != null && S.path && (De = S.position_ms), ue = -1, kt = [], S = null, Ki = 0, Ms();
  const e = D === "lplayer";
  e && (D = "default"), ne(t), fn(t), e && ee(t);
  try {
    await r("player_stop");
  } catch {
  }
}
async function es(t, e) {
  if (!Be) {
    if (e === "local") {
      if (p != null && p.connected && (_ != null && _.playing))
        try {
          await r("spotify_control", { action: "pause" });
        } catch {
        }
      return;
    }
    S && await Jt(t);
  }
}
async function Gu(t, e) {
  if (!S || S.path === "") {
    De = Math.max(0, Math.round(e)), Ms(), ne(t);
    return;
  }
  try {
    S = await r("player_seek", { positionMs: e });
  } catch {
    return;
  }
  De = S.position_ms, ne(t);
}
async function Xa(t, e) {
  try {
    S = await r("player_volume", { volume: e });
  } catch {
    return;
  }
  ne(t);
}
function ci() {
  Di !== void 0 && (window.clearInterval(Di), Di = void 0);
}
function Fc(t) {
  Di === void 0 && (Di = window.setInterval(() => {
    (async () => {
      if (!t.isConnected) {
        ci();
        return;
      }
      if (ue >= 0 || Tt) return;
      let e;
      try {
        e = await r("player_status");
      } catch {
        return;
      }
      if (!t.isConnected) {
        ci();
        return;
      }
      const i = !e.active && e.path !== "" && e.path === (S == null ? void 0 : S.path);
      S = e, De = e.position_ms, Ki = Date.now(), ne(t), fn(t), i && (ci(), await qi(t, 1, !0));
    })();
  }, $l));
}
function Yu(t, e) {
  Ui = e, qe !== void 0 && window.clearTimeout(qe), qe = window.setTimeout(() => {
    qe = void 0, Ht(t);
  }, Sl);
}
function Ka(t) {
  Ci = Math.min(fc, Math.max(pc, Math.round(Ci))), t.style.setProperty("--music-side-w", `${Ci}px`);
}
function jc(t, e) {
  var s;
  if (t === "liked")
    return { id: "liked", uri: "", name: a("music.liked_songs"), cover: "", subtitle: "", total: (U == null ? void 0 : U.total) ?? 0 };
  if (t === "top-tracks")
    return {
      id: "top-tracks",
      uri: "",
      name: a("music.top_tracks"),
      cover: "",
      subtitle: a("music.top_tracks_sub"),
      total: 0
    };
  const i = t === "artist" ? H == null ? void 0 : H.artists : t === "album" ? H == null ? void 0 : H.albums : t === "show" ? H == null ? void 0 : H.shows : H == null ? void 0 : H.playlists.map(Cs);
  return ((s = di.get(t)) == null ? void 0 : s.find((n) => n.id === e)) ?? (i == null ? void 0 : i.find((n) => n.id === e)) ?? null;
}
async function Uc(t, e) {
  if (!(!(p != null && p.connected) || Ti.has(e) || di.has(e))) {
    Ti.add(e), Fi.delete(e), Wt(t);
    try {
      const i = e === "playlist" ? (Js = await r("spotify_playlists")).map(Cs) : await r(dl[e]);
      di.set(e, i);
    } catch (i) {
      Fi.set(e, R(i));
    } finally {
      Ti.delete(e), Wt(t);
    }
  }
}
async function Ju(t, e, i) {
  const s = jc(e, i);
  if (s) {
    if (bt = !1, Pe = !1, I = { kind: e, id: s.id, uri: s.uri, name: s.name, cover: s.cover, subtitle: s.subtitle }, Ce = null, rt = "", e === "liked") {
      Ce = (U == null ? void 0 : U.items) ?? null, rt = Nt, Kt = !U, Je(t), Fs(t), xe(t), U || await Vc(t);
      return;
    }
    Kt = !0, Je(t), Fs(t), xe(t);
    try {
      Ce = e === "top-tracks" ? await r("spotify_top_tracks") : await r("spotify_item_tracks", { kind: rl(e), id: s.id });
    } catch (n) {
      rt = R(n);
    } finally {
      Kt = !1, Fs(t), xe(t);
    }
  }
}
async function Za(t, e, i, s = 0) {
  const n = jc(e, i);
  if (n) {
    await es(t, "spotify");
    try {
      if (e === "liked" || e === "show" || e === "top-tracks") {
        const c = (e === "liked" ? U == null ? void 0 : U.items : Ce) ?? [];
        if (!c.length) return;
        await r("spotify_play_uris", { uris: c.slice(Math.max(0, s)).map((d) => d.uri), deviceId: Ae || void 0 });
      } else if (n.uri)
        await r("spotify_play_context", { contextUri: n.uri, offsetUri: "", deviceId: Ae || void 0 });
      else
        return;
    } catch (c) {
      $(t, R(c));
    }
  }
}
async function ec(t, e) {
  if (!I) return;
  const i = Ce ?? [], s = i[e];
  if (s) {
    await es(t, "spotify");
    try {
      I.kind === "liked" || I.kind === "show" ? await r("spotify_play_uris", { uris: i.slice(e).map((n) => n.uri), deviceId: Ae || void 0 }) : await r("spotify_play_context", { contextUri: I.uri, offsetUri: s.uri, deviceId: Ae || void 0 });
    } catch (n) {
      $(t, R(n));
    }
  }
}
async function qs(t, e = !1) {
  if (!(p != null && p.connected)) return;
  if (!e && Ae && Date.now() - rs < Tl) {
    await bi(t);
    return;
  }
  if (Bs) return;
  Bs = !0;
  const i = !!(ae != null && ae.running), s = window.setTimeout(() => $(t, a("music.auto_starting")), 600);
  try {
    const n = await r("music_autoconfigure", { allowLocal: !ks });
    Ae = n.device_id || "", rs = Date.now(), n.source === "needs_login" ? $(t, a("music.auto_need_login")) : n.source === "local" && !n.device_id ? $(t, a("music.auto_local_unregistered")) : n.started_local && !i ? $(t, a("music.auto_local_started")) : n.source === "start_failed" ? $(t, a("music.auto_start_failed")) : n.source === "none" && !ks && $(t, a("music.auto_none"));
  } catch (n) {
    Ae = "", rs = 0, String(n) !== "ERR_NOT_CONNECTED" && $(t, R(n));
  } finally {
    window.clearTimeout(s), Bs = !1;
  }
  await bi(t);
}
function Xu(t) {
  if (t <= 0) return "";
  if (t >= 3600) {
    const e = Math.floor(t / 3600), i = Math.round(t % 3600 / 60);
    return i > 0 ? a("music.wait_hm", { h: String(e), m: String(i) }) : a("music.wait_h", { h: String(e) });
  }
  return t >= 60 ? a("music.wait_m", { m: String(Math.round(t / 60)) }) : a("music.wait_s", { s: String(Math.ceil(t)) });
}
function Ku() {
  return ws <= 0 ? 0 : Math.max(0, Math.round((ws - Date.now()) / 1e3));
}
async function Qc(t) {
  try {
    const e = await r("spotify_api_state");
    wt = e.stopped, _s = e.reason, ws = e.retry_at_ms;
  } catch {
  }
  xs(t);
}
function xs(t) {
  const e = t.querySelector("#music-resume");
  if (A(e, wt), !e) return;
  if (!wt) {
    e.textContent = a("music.resume"), e.title = "";
    return;
  }
  const i = Xu(Ku());
  e.textContent = i ? a("music.resume_in", { wait: i }) : a("music.resume"), e.title = i ? a("music.resume_hint", { wait: i, reason: _s }) : _s;
}
async function Zu(t) {
  try {
    await r("spotify_resume");
  } catch {
  }
  wt = !1, _s = "", ws = 0, xs(t), $(t, a("music.resumed")), qs(t, !0);
}
async function bi(t) {
  try {
    Bt = await r("spotify_devices");
  } catch (e) {
    Bt = [], $(t, R(e));
  }
  try {
    ae = await r("librespot_status");
  } catch {
    ae = null;
  }
  vi(t);
}
async function eo(t) {
  if (!(ae != null && ae.available)) return;
  const e = ae.running;
  try {
    ae = await r(e ? "librespot_stop" : "librespot_start");
  } catch (i) {
    $(t, R(i));
    return;
  }
  if (ks = e, vi(t), e) {
    Ae = "", rs = 0, await qs(t, !0);
    return;
  }
  for (let i = 0; i < 6; i++) {
    await new Promise((s) => window.setTimeout(s, 1500));
    try {
      const s = await r("spotify_devices");
      Bt = s;
      const n = s.find((c) => c.name === "Lunac");
      if (n && !n.active && await r("spotify_transfer", { deviceId: n.id, play: !0 }), n) {
        Ae = n.id;
        break;
      }
    } catch {
    }
  }
  await bi(t);
}
async function to(t) {
  try {
    ae = await r("librespot_login");
  } catch (e) {
    $(t, R(e));
    return;
  }
  ks = !1, vi(t), $(t, a("music.local_login_started"));
  for (let e = 0; e < 60; e++) {
    if (await new Promise((s) => window.setTimeout(s, 2e3)), !t.isConnected) return;
    let i;
    try {
      i = await r("librespot_status");
    } catch {
      continue;
    }
    if (ae = i, !!i.has_credentials) {
      i.running || (ae = await r("librespot_start").catch(() => i));
      for (let s = 0; s < 8; s++) {
        if (await new Promise((d) => window.setTimeout(d, 1500)), !t.isConnected) return;
        const n = await r("spotify_devices").catch(() => []);
        Bt = n;
        const c = n.find((d) => d.name === "Lunac");
        if (c) {
          c.active || await r("spotify_transfer", { deviceId: c.id, play: !1 }), Ae = c.id;
          break;
        }
      }
      $(t, a("music.local_login_ok"));
      break;
    }
  }
  await bi(t);
}
async function io(t, e) {
  if (e) {
    try {
      await r("spotify_transfer", { deviceId: e, play: !1 }), st = !1;
    } catch (i) {
      $(t, R(i));
    }
    await bi(t);
  }
}
async function Vc(t) {
  if (!(!(p != null && p.connected) || Os || U)) {
    Os = !0, Nt = "", Wt(t);
    try {
      U = await r("spotify_liked");
    } catch (e) {
      Nt = R(e);
    } finally {
      Os = !1, (I == null ? void 0 : I.kind) === "liked" && (Ce = (U == null ? void 0 : U.items) ?? null, Kt = !1, rt = Nt), Wt(t), xe(t);
    }
  }
}
function tc(t, e) {
  if (He = e, Pe = !!e, Si !== void 0 && (window.clearTimeout(Si), Si = void 0), !e) {
    H = null, ri = !1, bt = !1, Je(t), xe(t);
    return;
  }
  ri = !0, Je(t), xe(t), Si = window.setTimeout(() => void so(t, e), hl);
}
async function so(t, e) {
  Si = void 0;
  try {
    const i = await r("spotify_search", { query: e });
    if (He !== e) return;
    H = i;
  } catch (i) {
    if (He !== e) return;
    H = null, $(t, R(i));
  } finally {
    He === e && (ri = !1, Je(t), xe(t));
  }
}
function xi(t) {
  const e = (lt == null ? void 0 : lt.items) ?? [], i = a("music.play_from_here"), s = e.length === 0 ? `<div class="music-empty">${a(lt ? "music.queue_empty" : "music.loading")}</div>` : e.map((n, c) => Ts(n, c, "play-uri", "", i)).join("");
  for (const n of ["#music-q", "#music-q-dd"]) T(t.querySelector(n), s);
}
async function Gc(t) {
  var e;
  try {
    lt = await r("spotify_queue"), hc = ((e = _ == null ? void 0 : _.track) == null ? void 0 : e.id) ?? "";
  } catch (i) {
    lt = null, xt(t, R(i));
  }
  xi(t);
}
function an(t) {
  const e = (_ == null ? void 0 : _.track) ?? null, i = e != null && e.cover ? `<img src="${l(e.cover)}" alt="">` : "", s = [e == null ? void 0 : e.artists, e == null ? void 0 : e.album].filter(Boolean).join(" · ") || (_ != null && _.active ? "" : a("music.no_device_hint"));
  T(t.querySelector("#music-pv-cover"), i), T(t.querySelector("#music-bnow-cover"), i), E(t.querySelector("#music-pv-title"), (e == null ? void 0 : e.name) || a("music.no_track")), E(t.querySelector("#music-bnow-n"), (e == null ? void 0 : e.name) || a("music.no_track")), E(t.querySelector("#music-pv-sub"), s), E(t.querySelector("#music-bnow-a"), s);
  const n = (e == null ? void 0 : e.duration_ms) ?? 0, c = Math.min((_ == null ? void 0 : _.progress_ms) ?? 0, n || Number.MAX_SAFE_INTEGER), d = n > 0 ? Math.max(0, Math.min(100, c / n * 100)) : 0;
  if ($c = c, qc = Date.now(), Et < 0)
    for (const L of Dt) L.style.setProperty("--seek-pct", `${d}%`);
  E(t.querySelector("#music-pv-pos"), j(c)), E(t.querySelector("#music-pv-dur"), j(n)), E(t.querySelector("#music-b-time"), `${j(c)} / ${j(n)}`);
  const v = _ != null && _.playing ? h.pause : h.play;
  T(t.querySelector("#music-play"), v), T(t.querySelector("#music-b-play"), v);
  const w = Yc(), q = a(w === "shuffle" ? "music.mode_shuffle" : w === "repeat_one" ? "music.mode_repeat_one" : "music.mode_off");
  for (const L of [t.querySelector("#music-mode"), t.querySelector("#music-b-mode")])
    L && (oe(L, "data-mode", w), oe(L, "title", q), T(L, w === "repeat_one" ? h.repeat : h.shuffle));
  const k = _ && _.volume_percent >= 0 ? _.volume_percent : -1;
  for (const L of [t.querySelector("#music-vol"), t.querySelector("#music-b-vol")])
    L && k >= 0 && document.activeElement !== L && (L.value = String(k), si(L, k));
  const C = !(_ != null && _.active);
  t.querySelectorAll("#music-v-player .music-bar button, #music-nowbar button").forEach((L) => {
    L.id === "music-devices-btn" || L.id === "music-bnow" || L.id === "music-b-drawer" || (L.disabled = C);
  });
}
function no(t) {
  var n;
  if (!t.isConnected || !(_ != null && _.playing) || Et >= 0) return;
  const e = ((n = _.track) == null ? void 0 : n.duration_ms) ?? 0;
  if (e <= 0) return;
  const i = Math.min($c + (Date.now() - qc), e), s = Math.max(0, Math.min(100, i / e * 100));
  for (const c of Dt) c.style.setProperty("--seek-pct", `${s}%`);
  E(t.querySelector("#music-pv-pos"), j(i)), E(t.querySelector("#music-b-time"), `${j(i)} / ${j(e)}`);
}
function Yc() {
  return (_ == null ? void 0 : _.repeat) === "track" ? "repeat_one" : _ != null && _.shuffle ? "shuffle" : "off";
}
function Us(t) {
  var e, i;
  A(t.querySelector("#music-q-wrap"), we), A(t.querySelector("#music-q-dd"), we), (e = t.querySelector("#music-queue-btn")) == null || e.classList.toggle("on", we), (i = t.querySelector("#music-b-queue")) == null || i.classList.toggle("on", we);
}
function Ls(t) {
  const e = t.querySelector("#music-lyr");
  if (!e) return;
  if (vn(), Mt = -1, Xt = [], fi && (fi = !1, Ye !== void 0 && (window.clearTimeout(Ye), Ye = void 0)), Ys) {
    T(e, `<div class="music-empty">${a("music.lyrics_loading")}</div>`);
    return;
  }
  if (de != null && de.synced) {
    const s = Pl(de.synced);
    if (s.length > 0) {
      Xt = s;
      const n = l(a("music.seek_line"));
      T(
        e,
        `<div class="music-lyr-lines">${s.map((c, d) => `<div class="music-lyr-line" data-i="${d}" title="${n}">${l(c.text)}</div>`).join("")}</div>`
      );
      return;
    }
  }
  const i = ((de == null ? void 0 : de.plain) || "").trim();
  if (i) {
    T(e, `<div class="music-lyr-plain">${l(i)}</div>`);
    return;
  }
  if (de != null && de.instrumental) {
    T(e, `<div class="music-empty">${a("music.lyrics_instrumental")}</div>`);
    return;
  }
  T(e, `<div class="music-empty">${a("music.lyrics_none")}</div>`);
}
function vn() {
  Ri && (cancelAnimationFrame(Ri), Ri = 0);
}
function ic(t, e) {
  vn();
  const i = t.scrollTop, s = e - i;
  if (Math.abs(s) < 1) {
    t.scrollTop = e;
    return;
  }
  let n = 0;
  const c = (d) => {
    n || (n = d);
    const v = Math.min(1, (d - n) / yl);
    t.scrollTop = i + s * (1 - Math.pow(1 - v, 5)), Ri = v < 1 ? requestAnimationFrame(c) : 0;
  };
  Ri = requestAnimationFrame(c);
}
function As(t) {
  var w, q;
  if (Xt.length === 0) return;
  const e = t.querySelector("#music-lyr");
  if (!e || !e.isConnected || e.clientHeight === 0) return;
  const i = ((_ == null ? void 0 : _.progress_ms) ?? 0) / 1e3;
  let s = -1;
  for (let k = 0; k < Xt.length && Xt[k].at <= i; k++)
    s = k;
  if (s === Mt) return;
  const n = Math.min(Mt, s), c = Math.max(Mt, s);
  for (let k = Math.max(0, n + 1); k <= c; k++)
    (w = e.querySelector(`.music-lyr-line[data-i="${k}"]`)) == null || w.classList.toggle("done", k <= s);
  (q = e.querySelector(".music-lyr-line.on")) == null || q.classList.remove("on"), Mt = s;
  const d = e.querySelector(`.music-lyr-line[data-i="${s}"]`);
  if (!d) {
    fi || ic(e, 0);
    return;
  }
  if (d.classList.add("on"), fi) return;
  const v = d.getBoundingClientRect().top - e.getBoundingClientRect().top + e.scrollTop;
  ic(e, Math.max(0, v));
}
function sc(t) {
  fi = !0, vn(), Ye !== void 0 && window.clearTimeout(Ye), Ye = window.setTimeout(() => {
    Ye = void 0, fi = !1, Mt = -1, As(t);
  }, bl);
}
async function ys(t) {
  try {
    p = await r("music_config_get");
  } catch (e) {
    xt(t, R(e));
    return;
  }
  !p.connected && D === "player" && (D = "default", ee(t)), Ut(t), Gt(t);
}
async function ao(t) {
  if (Gs === t.id) return;
  Gs = t.id, Ys = !0, de = null;
  const e = Gi;
  e && Ls(e);
  try {
    de = await r("lyrics_get", {
      title: t.name,
      artist: t.artists,
      album: t.album,
      duration: t.duration_ms / 1e3
    });
  } catch (i) {
    de = { found: !1, instrumental: !1, track: "", artist: "", album: "", duration: 0, synced: null, plain: null }, e && xt(e, R(i));
  } finally {
    Ys = !1, e && (Ls(e), As(e));
  }
}
async function bn(t, e) {
  if (e === It) {
    if (!t.isConnected) {
      Is();
      return;
    }
    if (zl(t), p != null && p.connected) {
      if (!wt) {
        if (!document.hidden && !ds) {
          ds = !0;
          try {
            if (_ = await r("spotify_status"), e !== It) return;
            Gt(t), an(t), As(t), _u(t), Vt(t), Bi(t), wt && xs(t);
          } catch (i) {
            if (e !== It) return;
            String(i).includes("ERR_NOT_CONNECTED") ? await ys(t) : (xt(t, R(i)), xs(t), wt && Qc(t));
          } finally {
            ds = !1;
          }
        }
        we && (_ != null && _.track) && _.track.id !== hc && Gc(t);
      }
      _ != null && _.track && ao(_.track);
    }
    e === It && (ut = window.setTimeout(() => void bn(t, e), _l));
  }
}
function Is() {
  ut !== void 0 && (window.clearTimeout(ut), ut = void 0), Ct !== void 0 && (window.clearTimeout(Ct), Ct = void 0), ms !== void 0 && (window.clearInterval(ms), ms = void 0), It++, ds = !1;
}
function cn(t) {
  Is();
  const e = It;
  ut = window.setTimeout(() => void bn(t, e), 200), ms = window.setInterval(() => no(t), gl);
}
const co = 2e3;
let nc = 0;
function lo(t) {
  const e = Math.max(400, co - (Date.now() - nc));
  Ct !== void 0 && window.clearTimeout(Ct), Ct = window.setTimeout(() => {
    Ct = void 0, !(!t.isConnected || document.hidden) && (nc = Date.now(), ut !== void 0 && (window.clearTimeout(ut), ut = void 0), ut = window.setTimeout(() => void bn(t, It), 0));
  }, e);
}
function uo() {
  if (Na) return;
  Na = !0, document.addEventListener("visibilitychange", () => {
    const e = Gi;
    !e || !e.isConnected || (document.hidden ? Is() : cn(e));
  });
  const t = (e) => {
    const i = Gi;
    if (!i || !i.isConnected || document.hidden) return;
    const s = e.target;
    !s || !i.contains(s) || lo(i);
  };
  document.addEventListener("click", t, !0), document.addEventListener("input", t, !0), document.addEventListener("change", t, !0);
}
function Bi(t) {
  document.getElementById("plugin-titlebar") && (Pt !== void 0 && window.clearTimeout(Pt), Pt = window.setTimeout(() => void oo(t), 80));
}
async function oo(t) {
  if (Pt = void 0, !document.getElementById("plugin-titlebar")) return;
  let e = ml, i = pl;
  if (ii()) {
    const n = t.closest(".plugin-result"), c = n == null ? void 0 : n.closest("#results-list");
    if (!n || !c) return;
    const d = getComputedStyle(c), v = parseFloat(d.paddingTop || "0") + parseFloat(d.paddingBottom || "0"), w = window.innerHeight - c.clientHeight;
    i = Math.round(w + v + n.getBoundingClientRect().height), e = fl;
  }
  const s = `${e}x${i}`;
  if (s !== Zs)
    try {
      await r("plugin_window_resize", { width: e, height: i }), Zs = s;
    } catch {
    }
}
async function mo(t) {
  var gi, _i, hn, yn, gn, _n, wn, kn, Sn, $n, qn, xn, Ln, En, Mn, Tn, Cn, An, In, Dn, Rn, Nn, Pn, On, Bn, zn, Wn, Hn, Fn, jn, Un, Qn, Vn, Gn, Yn, Jn, Xn, Kn, Zn, ea, ta, ia, sa, na, aa, ca, la, ua, oa, ra, da, ma, pa, fa, va, ba, ha, ya, ga, _a, wa, ka, Sa, $a, qa, xa, La, Ea, Ma, Ta;
  if (dc) return pu(t);
  const e = t.querySelector(".music-root");
  if (!e) return;
  Gi = e, uo(), D = "default", ls = null, us = !1, ki = null, we = !1, Zs = "", gt = !1, Mi = !1, oi = ["a", "b"], on = null, Xs = null, ps = "", fs = 0, U = null, Nt = "", Js = null, di.clear(), Ti.clear(), Fi.clear(), ke = "playlist", I = null, Ce = null, Kt = !1, rt = "", Bt = null, st = !1, ae = null, Ae = "", He = "", H = null, ri = !1, Pe = !1, bt = !1, Ve = "tracks", Dt = [], te = !1, fe = null, Ss = !1, mi = "", Fe = "", me = !1, $e.clear(), ji.clear(), Oe = !1, P = null, pi = !1, St = "", Te = null, Ui = "", Zt = null, ai(), qe !== void 0 && (window.clearTimeout(qe), qe = void 0), S = null, Tt = !1, ue = -1, kt = [], ci();
  const i = _c();
  K = (i == null ? void 0 : i.queue) ?? [], F = i ? i.index : -1, De = (i == null ? void 0 : i.position_ms) ?? 0, X = !1, Me = !1, Xe = [], N = /* @__PURE__ */ new Set(), at = "", ge !== void 0 && (window.clearTimeout(ge), ge = void 0), ze = null, Le = !1, ei = ((gi = K[F]) == null ? void 0 : gi.path) ?? "";
  const s = (o) => xt(e, o), n = (o) => e.querySelector(o);
  At && (At(), At = null), At = await ln("spotify-auth", (o) => {
    e.isConnected && (o.payload.ok ? (s(a("music.auth_ok")), ys(e).then(() => {
      cn(e), qs(e, !0);
    })) : s(o.payload.message || a("music.auth_failed")));
  });
  const c = () => {
    D = "player", ee(e);
  }, d = () => {
    D = "default", ee(e);
  }, v = () => {
    D = "settings", ee(e);
  };
  (_i = n("#music-setup-toggle")) == null || _i.addEventListener("click", () => {
    if (X) {
      Tu(e);
      return;
    }
    v();
  }), (hn = n("#music-resume")) == null || hn.addEventListener("click", () => void Zu(e)), (yn = n("#music-set-back")) == null || yn.addEventListener("click", d), (gn = n("#music-set-tuning")) == null || gn.addEventListener("click", () => {
    D = "tuning", ee(e);
  }), (_n = n("#music-tuning-on")) == null || _n.addEventListener("click", () => {
    y && au(e, !y.enabled);
  }), Ac(e), (wn = n("#music-curve-open")) == null || wn.addEventListener("click", () => void fu(e));
  const w = (o, u, m, f) => {
    var b;
    const g = n(o);
    g == null || g.addEventListener("input", (M) => {
      const O = Number.parseFloat(M.target.value);
      if (!Number.isFinite(O)) return;
      f(O);
      const Y = e.querySelector(u);
      Y && (Y.value = Q(O, 1)), vs(e);
    }), g == null || g.addEventListener("change", (M) => {
      const O = Number.parseFloat(M.target.value);
      Number.isFinite(O) && f(O), se(e);
    }), (b = n(u)) == null || b.addEventListener("change", (M) => {
      const O = M.target, Y = Number.parseFloat(O.value.trim());
      if (!Number.isFinite(Y)) {
        O.value = Q(m(), 1);
        return;
      }
      Y !== m() && (f(Y), Hs(e));
    });
  };
  w("#music-preamp-range", "#music-tune-preamp", () => zi, (o) => zi = o), w("#music-bass-range", "#music-tune-bass", () => Wi, (o) => Wi = o), w("#music-treble-range", "#music-tune-treble", () => Hi, (o) => Hi = o), (kn = n("#music-tuning-user-presets")) == null || kn.addEventListener("click", (o) => {
    var g;
    const u = o.target.closest(".music-preset-user"), m = u == null ? void 0 : u.dataset.preset;
    if (!m) return;
    const f = ((g = o.target.closest("[data-act]")) == null ? void 0 : g.dataset.act) ?? "use";
    f === "rename" ? (nt = { mode: "rename", from: m, name: m }, pe(e), setTimeout(() => {
      var b;
      return (b = e.querySelector("#music-preset-name")) == null ? void 0 : b.select();
    }, 0)) : f === "delete" ? (nt = { mode: "delete", name: m }, pe(e)) : cu(e, m);
  }), (Sn = n("#music-preset-save")) == null || Sn.addEventListener("click", () => {
    var u;
    if (!y) return;
    nt = { mode: "save", name: (u = y.user_presets) != null && u.includes(y.preset) ? y.preset : "", overwrite: !1 }, pe(e), setTimeout(() => {
      var m;
      return (m = e.querySelector("#music-preset-name")) == null ? void 0 : m.select();
    }, 0);
  }), ($n = n("#music-preset-cancel")) == null || $n.addEventListener("click", () => {
    nt = null, pe(e);
  }), (qn = n("#music-preset-ok")) == null || qn.addEventListener("click", () => void Ua(e)), (xn = n("#music-preset-name")) == null || xn.addEventListener("keydown", (o) => {
    o.key === "Enter" ? (o.preventDefault(), Ua(e)) : o.key === "Escape" && (o.preventDefault(), nt = null, pe(e));
  }), (Ln = n("#music-preset-import")) == null || Ln.addEventListener("click", () => void lu(e)), (En = n("#music-preset-export")) == null || En.addEventListener("click", () => void ou(e));
  const q = () => n("#music-delay-range");
  (Mn = q()) == null || Mn.addEventListener("input", (o) => {
    const u = Number.parseFloat(o.target.value);
    if (!Number.isFinite(u)) return;
    Ee = Math.min(Ns, Math.max(0, u));
    const m = e.querySelector("#music-delay-num");
    m && (m.value = Q(Ee, 1)), vs(e);
  }), (Tn = q()) == null || Tn.addEventListener("change", (o) => {
    const u = Number.parseFloat(o.target.value);
    Number.isFinite(u) && (Ee = Math.min(Ns, Math.max(0, u))), se(e);
  }), (Cn = n("#music-delay-num")) == null || Cn.addEventListener("change", (o) => {
    const u = o.target, m = Number.parseFloat(u.value.trim());
    if (!Number.isFinite(m) || m < 0 || m > Ns) {
      u.value = Q(Ee, 1);
      return;
    }
    m !== Ee && (Ee = m, Hs(e));
  }), (An = n("#music-copy-list")) == null || An.addEventListener("click", (o) => {
    const u = o.target.closest("[data-act]");
    if (!u) return;
    const m = Number(u.dataset.i), f = u.dataset.act;
    if (f === "menu") {
      const g = u.dataset.side === "to" ? "to" : "from";
      J = (J == null ? void 0 : J.row) === m && J.side === g ? null : { row: m, side: g }, Ec(e);
    } else if (f === "pick") {
      const g = Rt[m], b = Number(u.dataset.ch);
      if (!g || !Number.isInteger(b)) return;
      u.dataset.side === "to" ? g.to = b : g.from = b, J = null, se(e);
    } else f === "del" && (Rt.splice(m, 1), (J == null ? void 0 : J.row) === m ? J = null : J && J.row > m && (J.row -= 1), se(e));
  }), (In = n("#music-copy-add")) == null || In.addEventListener("click", () => {
    const o = Math.max(2, (y == null ? void 0 : y.channels) || 2);
    Rt.push({ from: 0, to: Math.min(1, o - 1) }), se(e);
  }), (Dn = n("#music-conv-pick")) == null || Dn.addEventListener("click", () => void uu(e)), (Rn = n("#music-conv-clear")) == null || Rn.addEventListener("click", () => {
    li = null, se(e);
  }), (Nn = n("#music-ab-save-a")) == null || Nn.addEventListener("click", () => void Fa(e, "a")), (Pn = n("#music-ab-save-b")) == null || Pn.addEventListener("click", () => void Fa(e, "b")), (On = n("#music-ab-play")) == null || On.addEventListener("click", (o) => {
    const u = o.target.closest("[data-pos]"), m = Number(u == null ? void 0 : u.dataset.pos);
    (m === 1 || m === 2) && iu(e, m);
  }), (Bn = n("#music-ab-blind")) == null || Bn.addEventListener("click", () => {
    gt = !gt, Mi = !1, oi = gt && Math.random() < 0.5 ? ["b", "a"] : ["a", "b"], Ji(e);
  }), (zn = n("#music-ab-reveal")) == null || zn.addEventListener("click", () => {
    Mi = !0, Ji(e);
  });
  const k = () => n("#music-tuning-filters");
  (Wn = k()) == null || Wn.addEventListener("click", (o) => {
    const u = o.target.closest("[data-act]"), m = u == null ? void 0 : u.closest(".music-tune-row"), f = Number(m == null ? void 0 : m.dataset.i), g = ie[f];
    if (!u || !m || !g) return;
    const b = u.dataset.act;
    if (b === "on")
      g.on = !g.on, se(e);
    else if (b === "del")
      ie.splice(f, 1), Se === f ? Se = -1 : Se > f && (Se -= 1), se(e);
    else if (b === "kind")
      Se = Se === f ? -1 : f, Mc(e);
    else if (b === "pick") {
      const M = u.dataset.kind;
      if (!M) return;
      nu(g, M, (y == null ? void 0 : y.kinds) ?? []), Se = -1, se(e);
    }
  }), (Hn = k()) == null || Hn.addEventListener("input", (o) => {
    var Y;
    const u = o.target;
    if (!(u instanceof HTMLInputElement) || u.type !== "range") return;
    const m = u.dataset.f, f = u.closest(".music-tune-row"), g = ie[Number(f == null ? void 0 : f.dataset.i)];
    if (!m || !g) return;
    const b = Number.parseFloat(u.value);
    if (!Number.isFinite(b)) return;
    if (m === "gain_db") g.gain_db = b;
    else if (m === "q") g.q = b;
    else return;
    const M = f == null ? void 0 : f.querySelector(`input.music-tune-num[data-f="${m}"]`);
    M && (M.value = zs(g, m));
    const O = (Y = u.closest(".music-tune-slider")) == null ? void 0 : Y.querySelector("em");
    O && (O.textContent = zs(g, m)), ui = !0, $s(e), vs(e);
  }), (Fn = k()) == null || Fn.addEventListener("change", (o) => {
    var O;
    const u = o.target, m = (O = u == null ? void 0 : u.dataset) == null ? void 0 : O.f;
    if (!m) return;
    const f = u.closest(".music-tune-row"), g = ie[Number(f == null ? void 0 : f.dataset.i)];
    if (!g) return;
    u.type === "range" && (ui = !1);
    const b = Number.parseFloat(u.value.trim());
    if (!Number.isFinite(b)) {
      u.value = zs(g, m);
      return;
    }
    let M = !1;
    if (m === "freq_hz")
      M = b !== g.freq_hz, g.freq_hz = b;
    else if (m === "gain_db")
      M = b !== g.gain_db, g.gain_db = b;
    else if (m === "q")
      M = b !== g.q, g.q = b;
    else
      return;
    !M && u.type !== "range" || (u.type === "range" ? se(e) : Hs(e));
  }), (jn = n("#music-tune-add")) == null || jn.addEventListener("click", () => {
    ie.push(Ll()), se(e);
  }), (Un = n("#music-avatar")) == null || Un.addEventListener("click", () => {
    D !== "default" && (D = "default", ee(e)), us = !us, Ut(e);
  }), (Qn = n("#music-bnow")) == null || Qn.addEventListener("click", c);
  const C = (o) => {
    te !== o && (te = o, Qt = !1, o ? (!Be && (_ != null && _.playing) && r("spotify_control", { action: "pause" }).catch(() => {
    }), bt = !1, Pe = !1, I = null, Ce = null, rt = "", fe = null, P = null, mi = "", St = "", Zt = null, Te = null) : (ai(), X = !1, N.clear(), at = "", ge !== void 0 && (window.clearTimeout(ge), ge = void 0), ze = null, Le = !1, Me && (Me = !1, _t(e)), ei = "", Ui = "", qe !== void 0 && (window.clearTimeout(qe), qe = void 0), ke = "playlist", S != null && S.path && !Be && Jt(e)), ee(e), Gt(e), ne(e), o && (Bc(e), Ht(e), r("media_scan_status").then((u) => {
      !te || !e.isConnected || (Zt = u, u.running && zc(e), Ze(e));
    }).catch(() => {
    })));
  }, L = (o) => {
    if (o === "tuning") {
      D = "tuning", ee(e);
      return;
    }
    D = "default", C(o === "local"), ee(e);
  }, B = Ul(e);
  B == null || B.addEventListener("click", (o) => {
    const u = o.target.closest(".music-tb-seg"), m = u == null ? void 0 : u.dataset.seg;
    m && L(m);
  }), (Vn = n("#music-local-add")) == null || Vn.addEventListener("click", () => {
    Oe = !Oe, $i(e);
  }), (Gn = n("#music-local-list")) == null || Gn.addEventListener("click", () => zu(e)), (Yn = n("#music-local-del")) == null || Yn.addEventListener("click", () => Wu(e)), (Jn = n("#music-local-editdone")) == null || Jn.addEventListener("click", () => void Hu(e)), (Xn = n("#music-main")) == null || Xn.addEventListener("input", (o) => {
    const u = o.target;
    if ((u == null ? void 0 : u.id) === "music-lq-q") {
      at = u.value, ge !== void 0 && window.clearTimeout(ge), ge = window.setTimeout(() => {
        ge = void 0, Oi(e);
      }, 140);
      return;
    }
    (u == null ? void 0 : u.id) === "music-mt-q" && Yu(e, u.value.trim());
  }), (Kn = n("#music-l-prev")) == null || Kn.addEventListener("click", () => void qi(e, -1, !1)), (Zn = n("#music-l-next")) == null || Zn.addEventListener("click", () => void qi(e, 1, !1)), (ea = n("#music-l-play")) == null || ea.addEventListener("click", () => void Ja(e)), (ta = n("#music-l-stop")) == null || ta.addEventListener("click", () => void Jt(e));
  const z = () => {
    !Le && D !== "default" && (D = "default", ee(e)), Le = !Le, ne(e), Vt(e);
  };
  (ia = n("#music-queue-pick")) == null || ia.addEventListener("click", () => void Mu(e)), (sa = n("#music-queue-cancel")) == null || sa.addEventListener("click", () => {
    Me = !1, _t(e);
  }), (na = n("#music-queue-ok")) == null || na.addEventListener("click", () => Ga(e)), (aa = n("#music-queue-name")) == null || aa.addEventListener("keydown", (o) => {
    o.key === "Enter" ? (o.preventDefault(), Ga(e)) : o.key === "Escape" && (o.preventDefault(), Me = !1, _t(e));
  }), (ca = n("#music-queue-dlg")) == null || ca.addEventListener("pointerdown", (o) => {
    o.target.classList.contains("music-dlg-mask") && (Me = !1, _t(e));
  }), (la = n("#music-del-ok")) == null || la.addEventListener("click", () => void Au(e)), (ua = n("#music-del-cancel")) == null || ua.addEventListener("click", () => nn(e)), (oa = n("#music-del-dlg")) == null || oa.addEventListener("pointerdown", (o) => {
    o.target.classList.contains("music-dlg-mask") && nn(e);
  }), (ra = n("#music-b-drawer")) == null || ra.addEventListener("click", () => {
    Qt = !0, Vt(e), ne(e);
  }), (da = n("#music-l-drawer")) == null || da.addEventListener("click", () => {
    Qt = !1, Vt(e), ne(e);
  });
  const ve = n("#music-l-vol");
  ve == null || ve.addEventListener("input", () => {
    si(ve, Number(ve.value)), Xa(e, Number(ve.value) / 100);
  });
  const Ue = () => {
    const o = ["off", "shuffle", "repeat_all", "repeat_one"];
    le = o[(o.indexOf(le) + 1) % o.length], Nl(le), ne(e), $(e, rn());
  };
  (ma = n("#music-l-mode")) == null || ma.addEventListener("click", Ue);
  const Re = (o, u) => {
    const m = (b) => {
      const M = o.getBoundingClientRect();
      return Math.max(0, Math.min(1, (b - M.left) / Math.max(1, M.width)));
    }, f = (b) => {
      ue = b, o.style.setProperty("--seek-pct", `${b * 100}%`), u(b);
    };
    o.addEventListener("pointerdown", (b) => {
      if (!(((S == null ? void 0 : S.duration_ms) ?? 0) <= 0)) {
        try {
          o.setPointerCapture(b.pointerId);
        } catch {
        }
        o.classList.add("music-dragging"), f(m(b.clientX));
      }
    }), o.addEventListener("pointermove", (b) => {
      ue < 0 || f(m(b.clientX));
    });
    const g = (b) => {
      if (ue < 0) return;
      const M = ue;
      ue = -1, o.classList.remove("music-dragging");
      try {
        o.releasePointerCapture(b.pointerId);
      } catch {
      }
      Gu(e, Math.round(((S == null ? void 0 : S.duration_ms) ?? 0) * M));
    };
    o.addEventListener("pointerup", g), o.addEventListener("pointercancel", g);
  }, Ne = n("#music-lbp");
  Ne && Re(Ne, (o) => {
    const u = (S == null ? void 0 : S.duration_ms) ?? 0;
    E(Ne.querySelector(".music-progress-tip"), Ni(u * o));
    const m = e.querySelector("#music-l-time");
    m && E(m, `${j(u * o)} / ${j(u)}`);
  });
  const be = async () => {
    var o;
    if (!S || !S.path) {
      const u = ((o = K[F]) == null ? void 0 : o.path) ?? "";
      if (!u || !await qt(e, u, De)) return;
    }
    D = "lplayer", ee(e);
  };
  (pa = n("#music-lnow")) == null || pa.addEventListener("click", () => void be()), (fa = n("#music-lp-prev")) == null || fa.addEventListener("click", () => void qi(e, -1, !1)), (va = n("#music-lp-next")) == null || va.addEventListener("click", () => void qi(e, 1, !1)), (ba = n("#music-lp-play")) == null || ba.addEventListener("click", () => void Ja(e)), (ha = n("#music-lp-stop")) == null || ha.addEventListener("click", () => void Jt(e)), (ya = n("#music-lp-mode")) == null || ya.addEventListener("click", Ue);
  const et = n("#music-lp-vol");
  et == null || et.addEventListener("input", () => {
    si(et, Number(et.value)), Xa(e, Number(et.value) / 100);
  });
  const yi = n("#music-lp-progress");
  yi && Re(yi, (o) => {
    const u = (S == null ? void 0 : S.duration_ms) ?? 0;
    E(yi.querySelector(".music-progress-tip"), Ni(u * o));
    const m = e.querySelector("#music-lp-time");
    m && E(m, `${j(u * o)} / ${j(u)}`);
  });
  const dt = (o) => {
    var u;
    !e.isConnected || !ii() || (u = o.target) != null && u.closest("#plugin-close") && (o.stopPropagation(), o.preventDefault(), D === "lplayer" ? d() : Gl(e));
  };
  document.addEventListener("click", dt, !0), (ga = n("#music-fields-toggle")) == null || ga.addEventListener("click", () => {
    ls = !(ls ?? !(p != null && p.builtin)), Ut(e);
  }), (_a = n("#music-copy-redirect")) == null || _a.addEventListener("click", () => {
    const o = (p == null ? void 0 : p.redirect_uri) || "";
    o && cl(o).then(() => s(a("music.copied"))).catch(() => {
    });
  });
  for (const o of e.querySelectorAll("#music-quality .music-seg-btn"))
    o.addEventListener("click", () => {
      ki = Number(o.dataset.q), Ut(e);
    });
  (wa = n("#music-set-save")) == null || wa.addEventListener("click", async () => {
    try {
      p = await r("music_config_set", { librespotBitrate: ki }), ki = null, s(a("music.saved")), Ut(e), Gt(e);
    } catch (o) {
      s(R(o));
    }
  }), (ka = n("#music-save")) == null || ka.addEventListener("click", async () => {
    var f, g, b, M;
    const o = ((f = n("#music-client-id")) == null ? void 0 : f.value.trim()) ?? "", u = ((g = n("#music-port")) == null ? void 0 : g.value.trim()) ?? "", m = Number(u);
    if (!o) {
      s(a("music.err_no_client_id"));
      return;
    }
    if (!Number.isInteger(m) || m < 1024 || m > 65535) {
      s(a("music.err_bad_port"));
      return;
    }
    try {
      p = await r("music_config_set", {
        clientId: o,
        port: m,
        // 本机播放那两项**一起交上去**（留空 = 自动探测 / 直连，都是合法值）
        librespotPath: ((b = n("#music-librespot")) == null ? void 0 : b.value.trim()) ?? "",
        librespotProxy: ((M = n("#music-librespot-proxy")) == null ? void 0 : M.value.trim()) ?? ""
        // 音质**不在这里提交**（2026-10-01 起它归设置页，那个页面有自己的「保存」）：
        // 不传 = `None` = 别动，宿主本来就是这个语义。把两页的保存混在一处，
        // 就会出现「在设置页点了 320、回连接卡片点保存、结果把它一起落盘了」。
      }), s(a("music.saved")), Ut(e), Gt(e), ae = null;
    } catch (O) {
      s(R(O));
    }
  }), (Sa = n("#music-connect")) == null || Sa.addEventListener("click", async () => {
    var m, f;
    const o = ((m = n("#music-client-id")) == null ? void 0 : m.value.trim()) ?? "", u = Number(((f = n("#music-port")) == null ? void 0 : f.value.trim()) ?? "");
    if (o && Number.isInteger(u) && u >= 1024)
      try {
        p = await r("music_config_set", {
          clientId: o,
          port: u,
          librespotPath: null,
          librespotProxy: null,
          // 串流质量同上：这条路径只是「先落盘再连」，别动用户选的档
          librespotBitrate: null
        });
      } catch (g) {
        s(R(g));
        return;
      }
    try {
      const g = await r("spotify_connect");
      s(a("music.browser_hint")), await al(g);
    } catch (g) {
      s(R(g));
    }
  }), ($a = n("#music-disconnect")) == null || $a.addEventListener("click", async () => {
    try {
      await r("spotify_disconnect"), _ = null, de = null, Gs = "", Js = null, di.clear(), Fi.clear(), lt = null, we = !1, I = null, Ce = null, rt = "", H = null, He = "", Pe = !1, bt = !1, Bt = null, D = "default", await ys(e), ee(e), xi(e), s(a("music.disconnected"));
    } catch (o) {
      s(R(o));
    }
  });
  const Qe = (o) => {
    var g;
    const u = (g = o.target) == null ? void 0 : g.closest("[data-act]");
    if (!u) return;
    const m = u.dataset.kind || "", f = u.dataset.id || "";
    switch (u.dataset.act) {
      case "side-tab":
        ke = u.dataset.tab || "playlist", Wt(e), Uc(e, ke);
        break;
      case "search-tab":
        Ve = u.dataset.tab || "tracks", xe(e);
        break;
      case "open":
        Ju(e, m, f);
        break;
      case "main-track": {
        const b = u.dataset.uri || "";
        b && as(u, ss(b));
        break;
      }
      case "main-play-all":
        I && Za(e, I.kind, I.id);
        break;
      case "dd-track":
        u.dataset.uri && Qs(e, u.dataset.uri);
        break;
      case "play-uri": {
        const b = u.dataset.uri || "";
        b && as(u, ss(b));
        break;
      }
      case "search-all":
        Pe = !1, bt = !0, Je(e), xe(e);
        break;
      case "dev-pick":
        io(e, f);
        break;
      case "local-toggle":
        eo(e);
        break;
      case "local-login":
        to(e);
        break;
      // ── 本地音乐页（2026-10-01）──
      case "media-root": {
        const b = u.dataset.path || "";
        if (me) {
          b && ($e.has(b) ? $e.delete(b) : $e.add(b)), je(e);
          break;
        }
        Fe = b, je(e), Ht(e);
        break;
      }
      case "media-scan":
        if (X) {
          X = !1, N.clear(), Yi(e), hs(e);
          break;
        }
        Wc(e);
        break;
      // 「自定义队列」开关（2026-10-10 用户口径：入口从齿轮挪到本地页筛选行最右侧；
      // 2026-10-11 改：开启 = 进**列表勾选编辑态**，不再弹小窗）。
      case "qmode":
        X = !X, N.clear(), X && (Oe = !1), Yi(e), hs(e);
        break;
      // `＋` 浮层里的两行（2026-10-01）：目录 vs 播放列表文件。
      // **先关浮层再干活** —— 目录对话框是模态的，浮层留着会在对话框背后一闪一闪。
      case "media-add-dir":
        Oe = !1, $i(e), Ou(e);
        break;
      case "media-add-list":
        Oe = !1, $i(e), ju(e);
        break;
      case "media-list-close":
        Uu(e);
        break;
      case "local-track": {
        const b = u.dataset.path || "";
        b && ns(u, ss(b));
        break;
      }
      // ── 本地「自定义队列」（2026-10-11 用户口径：多条，列在左栏）──
      case "local-queue": {
        const b = u.dataset.qid || "";
        if (!Ke.some((M) => M.id === b)) break;
        ce = b, ti(), X = !1, N.clear(), at = "", me = !1, $e.clear(), zt.clear(), te || C(!0), D = "default", ee(e);
        break;
      }
      // ── 队列详情页（2026-10-09 用户口径；2026-10-11 由左栏选中驱动）──
      case "queue-track": {
        const b = u.dataset.path || "";
        b && ns(u, ss(b));
        break;
      }
      // 本地队列**下拉浮层**（`#music-lq-dd`）里的行 = 播放队列（`localQueue`）的一首：
      // **双击** = 把游标挪到这一首再起播（**不动** `localQueue` 的内容 —— 它本来就是播放队列本身）；
      // 单击不选中（这个浮层是速览，不参与 `trackSel`）。
      case "queue-play": {
        js(e, Number(u.dataset.i || "0"));
        break;
      }
      case "queue-back":
        ce = null, me = !1, $e.clear(), N.clear(), zt.clear(), at = "", ge !== void 0 && (window.clearTimeout(ge), ge = void 0), ti(), ee(e);
        break;
    }
  };
  for (const o of ["#music-side-list", "#music-side-tabs", "#music-main", "#music-search-dd", "#music-dev-dd", "#music-q", "#music-q-dd", "#music-lq-dd", "#music-local-add-dd"])
    (qa = n(o)) == null || qa.addEventListener("click", Qe);
  (xa = n("#music-side-list")) == null || xa.addEventListener("dblclick", (o) => {
    var g;
    const u = (g = o.target) == null ? void 0 : g.closest('[data-act="open"]');
    if (!u) return;
    const m = u.dataset.kind || "", f = u.dataset.id || "";
    f && Za(e, m, f);
  }), e.addEventListener("dblclick", (o) => {
    var m;
    const u = (m = o.target) == null ? void 0 : m.closest("[data-act]");
    if (u)
      switch (u.dataset.act) {
        case "local-track": {
          const f = u.dataset.path || "";
          f && !N.has(f) && (N.add(f), ns(u, !0)), Qu(e, Number(u.dataset.i || "0"));
          break;
        }
        case "queue-track": {
          const f = u.dataset.path || "";
          f && !N.has(f) && (N.add(f), ns(u, !0)), Vu(e, f);
          break;
        }
        case "queue-play":
          js(e, Number(u.dataset.i || "0"));
          break;
        case "main-track": {
          const f = u.dataset.uri || "";
          f && !N.has(f) && (N.add(f), as(u, !0)), ec(e, Number(u.dataset.i || "0"));
          break;
        }
        case "play-uri": {
          const f = u.dataset.uri || "";
          f && !N.has(f) && (N.add(f), as(u, !0)), f && Qs(e, f);
          break;
        }
      }
  }), e.addEventListener("contextmenu", (o) => {
    var pt;
    const u = (pt = o.target) == null ? void 0 : pt.closest("[data-act]");
    if (!u) return;
    const m = u.dataset.act || "";
    if (m !== "local-track" && m !== "queue-track" && m !== "main-track" && m !== "play-uri" && m !== "queue-play") return;
    o.preventDefault(), o.stopPropagation();
    const f = Number(u.dataset.i || "0"), g = u.dataset.path || "", b = u.dataset.uri || "", M = m === "queue-track" ? ce ?? "" : "", O = m === "local-track" || m === "queue-track", Y = m === "main-track" || m === "play-uri", W = Y ? b : g;
    (O || Y) && W && !N.has(W) && (N.clear(), N.add(W), m === "local-track" ? hs(e) : m === "queue-track" ? Oi(e) : m === "main-track" ? xe(e) : m === "play-uri" && xi(e)), ze = { act: m, i: f, path: g, uri: b, qid: M }, Du(e, o.clientX, o.clientY);
  }), (La = n("#music-ctx")) == null || La.addEventListener("click", (o) => {
    var g, b, M, O, Y;
    const u = (g = o.target) == null ? void 0 : g.closest("[data-ctx]");
    if (!u) return;
    const m = u.dataset.ctx || "", f = ze;
    if (f) {
      if (m === "add-queue") {
        const W = (b = n("#music-ctx")) == null ? void 0 : b.getBoundingClientRect();
        Ru(e, W ? W.left : o.clientX, W ? W.top : o.clientY);
        return;
      }
      if (m.startsWith("pick:")) {
        Nu(e, m.slice(5)), ft(e);
        return;
      }
      if (m === "pick-new") {
        Ic(e, Nc().map((W) => W.path)), ft(e);
        return;
      }
      if (m === "reveal") {
        f.path && r("reveal_in_explorer", { path: f.path }).catch((W) => $(e, String(W))), ft(e);
        return;
      }
      if (m === "delete-file") {
        const W = f.path && ((M = P == null ? void 0 : P.items.find((pt) => pt.path === f.path)) == null ? void 0 : M.title) || f.path && ((Y = (O = Vi()) == null ? void 0 : O.items.find((pt) => pt.path === f.path)) == null ? void 0 : Y.title) || "";
        ft(e), Cu(e, f.path, W);
        return;
      }
      if (m === "remove-queue") {
        const W = Vi();
        W && f.path && (W.items = W.items.filter((pt) => pt.path !== f.path), N.delete(f.path), ti(), Oi(e), $(e, a("music.ctx_removed_from_queue"))), ft(e);
        return;
      }
      if (m === "play") {
        ft(e), f.act === "main-track" ? ec(e, f.i) : f.act === "play-uri" && f.uri ? Qs(e, f.uri) : f.act === "queue-play" && js(e, f.i);
        return;
      }
    }
  }), document.addEventListener("keydown", (o) => {
    var u;
    o.key === "Escape" && ((u = n("#music-ctx")) != null && u.classList.contains("open")) && ft(e);
  }), (Ea = n("#music-devices-btn")) == null || Ea.addEventListener("click", () => {
    st = !st, vi(e), st && bi(e);
  }), Ka(e), (Ma = n("#music-split")) == null || Ma.addEventListener("pointerdown", (o) => {
    var b;
    o.preventDefault();
    const u = o.clientX, m = ((b = n("#music-side")) == null ? void 0 : b.getBoundingClientRect().width) ?? Ci, f = (M) => {
      Ci = Math.min(fc, Math.max(pc, Math.round(m + M.clientX - u))), Ka(e);
    }, g = () => {
      window.removeEventListener("pointermove", f), window.removeEventListener("pointerup", g), document.body.classList.remove("music-resizing");
    };
    document.body.classList.add("music-resizing"), window.addEventListener("pointermove", f), window.addEventListener("pointerup", g);
  }), document.addEventListener("pointerdown", (o) => {
    const u = o.target;
    u && (st && !u.closest("#music-dev-dd") && !u.closest("#music-devices-btn") && (st = !1, vi(e)), Pe && !u.closest(".music-search-wrap") && (Pe = !1, Je(e)), Oe && !u.closest("#music-local-add-dd") && !u.closest("#music-local-add") && (Oe = !1, $i(e)), we && !u.closest("#music-q-dd") && !u.closest("#music-b-queue") && !u.closest("#music-queue-btn") && (we = !1, Us(e)), Le && !u.closest("#music-lq-dd") && !u.closest("#music-l-queue") && !u.closest("#music-lp-queue") && (Le = !1, ne(e)), ze && !u.closest("#music-ctx") && ft(e));
  });
  const re = n("#music-search");
  re == null || re.addEventListener("input", () => tc(e, re.value.trim())), re == null || re.addEventListener("focus", () => {
    He && (Pe = !0, Je(e));
  }), re == null || re.addEventListener("keydown", (o) => {
    if (o.key === "Enter" && He) {
      Pe = !1, bt = !0, Je(e), xe(e);
      return;
    }
    o.key === "Escape" && (re.value = "", tc(e, ""));
  }), document.body.addEventListener("mouseenter", () => Bi(e)), document.body.addEventListener("mouseleave", () => Bi(e));
  const he = async (o, u) => {
    o === "play" && await es(e, "spotify");
    try {
      await r("spotify_control", { action: o, value: u });
    } catch (m) {
      s(R(m));
    }
  }, mt = (o, u) => {
    var m;
    for (const f of o) (m = n(`#${f}`)) == null || m.addEventListener("click", u);
  }, x = () => {
    we = !we, Us(e), xi(e), we ? Gc(e) : an(e), Bi(e);
  };
  e.addEventListener("click", (o) => {
    var f;
    const u = o.target;
    if (!u) return;
    const m = u.closest("#music-l-queue, #music-lp-queue, #music-queue-btn, #music-b-queue");
    if (m && r("log_frontend", { level: "warn", message: `[music] queue-btn hit id=${m.id}` }).catch(() => {
    }), u.closest("#music-l-queue, #music-lp-queue")) {
      z();
      const g = e.querySelector("#music-lq-dd"), b = e.querySelector("#music-body"), M = e.querySelector("#music-v-default");
      r("log_frontend", {
        level: "warn",
        message: `[music] queue AFTER toggleLocalQueue: mode=${D} localPage=${te} activeQueueId=${ce} localQueueOpen=${Le} localQueueLen=${K.length} barMode=${ii()} ddExists=${!!g} ddHidden=${g ? g.classList.contains("hidden") : "n/a"} bodyHidden=${b ? b.classList.contains("hidden") : "n/a"} defaultHidden=${M ? M.classList.contains("hidden") : "n/a"}`
      }).catch(() => {
      });
      return;
    }
    if (u.closest("#music-queue-btn, #music-b-queue")) {
      x();
      const g = e.querySelector("#music-q-dd"), b = e.querySelector("#music-q-wrap");
      r("log_frontend", {
        level: "warn",
        message: `[music] queue AFTER toggleQueue: queueOpen=${we} barMode=${ii()} ddExists=${!!g} ddHidden=${g ? g.classList.contains("hidden") : "n/a"} wrapHidden=${b ? b.classList.contains("hidden") : "n/a"} items=${lt ? ((f = lt.items) == null ? void 0 : f.length) ?? 0 : "no-queue"}`
      }).catch(() => {
      });
      return;
    }
  }), mt(["music-prev", "music-b-prev"], () => void he("previous")), mt(["music-next", "music-b-next"], () => void he("next")), mt(["music-play", "music-b-play"], () => void he(_ != null && _.playing ? "pause" : "play")), mt(["music-dual-btn", "music-l-dual-btn"], () => {
    Be = !Be, Dl(Be), Be || (Qt = !1), !Be && !te && S && Jt(e), ne(e), Vt(e), $(e, a(Be ? "music.dual_on" : "music.dual_off"));
  });
  let Z = null, ye = !1;
  const tt = async (o) => {
    if (Z = o, !ye) {
      ye = !0;
      try {
        for (; Z !== null; ) {
          const u = Z;
          Z = null, await he("volume", u);
        }
      } finally {
        ye = !1;
      }
    }
  };
  for (const o of ["music-vol", "music-b-vol"])
    (Ta = n(`#${o}`)) == null || Ta.addEventListener("input", (u) => {
      const m = u.target, f = Number(m.value);
      si(m, f), tt(f);
    });
  mt(["music-mode", "music-b-mode"], () => {
    const o = Yc();
    r("spotify_set_play_mode", { mode: o === "off" ? "shuffle" : o === "shuffle" ? "repeat_one" : "off" }).catch((m) => s(R(m)));
  }), Dt = ["#music-pv-progress", "#music-bp"].map((o) => n(o)).filter((o) => !!o);
  for (const o of Dt) {
    const u = (g) => {
      const b = o.getBoundingClientRect();
      return Math.max(0, Math.min(1, (g - b.left) / Math.max(1, b.width)));
    }, m = (g) => {
      var Y;
      Et = g;
      const b = `${g * 100}%`;
      for (const W of Dt) W.style.setProperty("--seek-pct", b);
      const M = ((Y = _ == null ? void 0 : _.track) == null ? void 0 : Y.duration_ms) ?? 0, O = j(M * g);
      E(o.querySelector(".music-progress-tip"), Ni(M * g)), E(n("#music-pv-pos"), O), E(n("#music-b-time"), `${O} / ${j(M)}`);
    };
    o.addEventListener("pointerdown", (g) => {
      var b;
      if (!((((b = _ == null ? void 0 : _.track) == null ? void 0 : b.duration_ms) ?? 0) <= 0)) {
        try {
          o.setPointerCapture(g.pointerId);
        } catch {
        }
        o.classList.add("music-dragging"), m(u(g.clientX));
      }
    }), o.addEventListener("pointermove", (g) => {
      Et < 0 || m(u(g.clientX));
    });
    const f = (g) => {
      var M;
      if (Et < 0) return;
      const b = Et;
      Et = -1, o.classList.remove("music-dragging");
      try {
        o.releasePointerCapture(g.pointerId);
      } catch {
      }
      he("seek", Math.round((((M = _ == null ? void 0 : _.track) == null ? void 0 : M.duration_ms) ?? 0) * b));
    };
    o.addEventListener("pointerup", f), o.addEventListener("pointercancel", f);
  }
  const G = n("#music-lyr");
  let Lt = !1, it = 0;
  G == null || G.addEventListener("wheel", () => sc(e), { passive: !0 }), G == null || G.addEventListener("pointerdown", (o) => {
    Lt = !1, it = o.clientY, sc(e);
  }), G == null || G.addEventListener("pointermove", (o) => {
    Math.abs(o.clientY - it) > 4 && (Lt = !0);
  }), G == null || G.addEventListener("click", (o) => {
    if (Lt) return;
    const u = o.target.closest(".music-lyr-line"), m = u ? Xt[Number(u.dataset.i)] : void 0;
    m && he("seek", Math.round(m.at * 1e3));
  }), await ys(e), ee(e), an(e), Ls(e), xi(e), Us(e), Gt(e), await Qc(e), cn(e), qs(e);
}
async function Qs(t, e) {
  await es(t, "spotify");
  try {
    await r("spotify_play_uri", { uri: e, deviceId: Ae || void 0 });
  } catch (i) {
    xt(t, R(i));
  }
}
function ro() {
  tn(), dn(), Is(), Gi = null, Ye !== void 0 && (window.clearTimeout(Ye), Ye = void 0), Pt !== void 0 && (window.clearTimeout(Pt), Pt = void 0), ht !== void 0 && (window.clearTimeout(ht), ht = void 0), ai(), qe !== void 0 && (window.clearTimeout(qe), qe = void 0), ci(), S != null && S.path && (De = S.position_ms, Ms(), S = null, K = [], F = -1, r("player_stop").catch(() => {
  })), At && (At(), At = null), Dt = [], Qt = !1, Fl(), Vl();
}
window.__lunac_music_stop = ro;
const po = {
  id: "music",
  name: "音乐歌词",
  keywords: ["音乐", "歌词", "歌曲", "正在播放", "music", "lyrics", "spotify", "播放控制", "暂停", "下一首", "歌单", "播放列表"],
  description: "歌词自动抓取 (LRCLIB + 网易云兜底) + Spotify 播放控制 / 歌单 / 队列",
  icon: "🎵",
  badge: "music",
  // 「本插件一律在**悬浮窗**里打开」（2026-09-29 从 main.ts 的硬编码 `id === "music"` 改成声明）。
  // 为什么要声明而不是让宿主按 id 判：音乐已归入**拓展插件**，要能从市场独立打包分发
  // —— 磁盘插件的代码宿主没法写死，行为只能由插件自己声明（见 ai-spec §3.5「插件契约」）。
  // 这也是「用户 2026-09-28 定的：从 Lunac 进音乐界面时自动展开成独立界面」那条的执行点。
  permissions: ["window.float"],
  async execute() {
    return { type: "html", content: dc ? Ol() : Bl() };
  }
};
export {
  mo as attach,
  mo as attachMusicListeners,
  po as default,
  ro as detach,
  po as musicPlugin,
  ro as stopMusicPolling
};
