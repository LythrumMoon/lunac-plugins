const Za = "__lunac_host";
function ec() {
  return globalThis[Za] ?? null;
}
function a(t, e) {
  const i = ec();
  return i && typeof i.t == "function" ? i.t(t, e) : t;
}
function tc(t, e, i, s) {
  if (typeof e == "function" ? t !== e || !s : !e.has(t)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? s : i === "a" ? s.call(t) : s ? s.value : e.get(t);
}
function ic(t, e, i, s, n) {
  if (typeof e == "function" ? t !== e || !0 : !e.has(t)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return e.set(t, i), i;
}
var qi;
const Se = "__TAURI_TO_IPC_KEY__";
function sc(t, e = !1) {
  return window.__TAURI_INTERNALS__.transformCallback(t, e);
}
async function u(t, e = {}, i) {
  return window.__TAURI_INTERNALS__.invoke(t, e, i);
}
function Qi(t, e = "asset") {
  return window.__TAURI_INTERNALS__.convertFileSrc(t, e);
}
class nc {
  get rid() {
    return tc(this, qi, "f");
  }
  constructor(e) {
    qi.set(this, void 0), ic(this, qi, e);
  }
  /**
   * Destroys and cleans up this resource from memory.
   * **You should not call any method on this object anymore and should drop any reference to it.**
   */
  async close() {
    return u("plugin:resources|close", {
      rid: this.rid
    });
  }
}
qi = /* @__PURE__ */ new WeakMap();
var ue;
(function(t) {
  t.WINDOW_RESIZED = "tauri://resize", t.WINDOW_MOVED = "tauri://move", t.WINDOW_CLOSE_REQUESTED = "tauri://close-requested", t.WINDOW_DESTROYED = "tauri://destroyed", t.WINDOW_FOCUS = "tauri://focus", t.WINDOW_BLUR = "tauri://blur", t.WINDOW_SCALE_FACTOR_CHANGED = "tauri://scale-change", t.WINDOW_THEME_CHANGED = "tauri://theme-changed", t.WINDOW_CREATED = "tauri://window-created", t.WINDOW_SUSPENDED = "tauri://suspended", t.WINDOW_RESUMED = "tauri://resumed", t.WEBVIEW_CREATED = "tauri://webview-created", t.DRAG_ENTER = "tauri://drag-enter", t.DRAG_OVER = "tauri://drag-over", t.DRAG_DROP = "tauri://drag-drop", t.DRAG_LEAVE = "tauri://drag-leave";
})(ue || (ue = {}));
async function pa(t, e) {
  window.__TAURI_EVENT_PLUGIN_INTERNALS__.unregisterListener(t, e), await u("plugin:event|unlisten", {
    event: t,
    eventId: e
  });
}
async function Es(t, e, i) {
  var s;
  const n = typeof (i == null ? void 0 : i.target) == "string" ? { kind: "AnyLabel", label: i.target } : (s = i == null ? void 0 : i.target) !== null && s !== void 0 ? s : { kind: "Any" };
  return u("plugin:event|listen", {
    event: t,
    target: n,
    handler: sc(e)
  }).then((c) => async () => pa(t, c));
}
async function ac(t, e, i) {
  return Es(t, (s) => {
    pa(t, s.id), e(s);
  }, i);
}
async function cc(t, e) {
  await u("plugin:event|emit", {
    event: t,
    payload: e
  });
}
async function lc(t, e, i) {
  await u("plugin:event|emit_to", {
    target: typeof t == "string" ? { kind: "AnyLabel", label: t } : t,
    event: e,
    payload: i
  });
}
async function uc(t, e) {
  await u("plugin:shell|open", {
    path: t,
    with: e
  });
}
class si extends nc {
  /**
   * Creates an Image from a resource ID. For internal use only.
   *
   * @ignore
   */
  constructor(e) {
    super(e);
  }
  /** Creates a new Image using RGBA data, in row-major order from top to bottom, and with specified width and height. */
  static async new(e, i, s) {
    return u("plugin:image|new", {
      rgba: Wi(e),
      width: i,
      height: s
    }).then((n) => new si(n));
  }
  /**
   * Creates a new image using the provided bytes by inferring the file format.
   * If the format is known, prefer [@link Image.fromPngBytes] or [@link Image.fromIcoBytes].
   *
   * Only `ico` and `png` are supported (based on activated feature flag).
   *
   * Note that you need the `image-ico` or `image-png` Cargo features to use this API.
   * To enable it, change your Cargo.toml file:
   * ```toml
   * [dependencies]
   * tauri = { version = "...", features = ["...", "image-png"] }
   * ```
   */
  static async fromBytes(e) {
    return u("plugin:image|from_bytes", {
      bytes: Wi(e)
    }).then((i) => new si(i));
  }
  /**
   * Creates a new image using the provided path.
   *
   * Only `ico` and `png` are supported (based on activated feature flag).
   *
   * Note that you need the `image-ico` or `image-png` Cargo features to use this API.
   * To enable it, change your Cargo.toml file:
   * ```toml
   * [dependencies]
   * tauri = { version = "...", features = ["...", "image-png"] }
   * ```
   */
  static async fromPath(e) {
    return u("plugin:image|from_path", { path: e }).then((i) => new si(i));
  }
  /** Returns the RGBA data for this image, in row-major order from top to bottom.  */
  async rgba() {
    return u("plugin:image|rgba", {
      rid: this.rid
    }).then((e) => new Uint8Array(e));
  }
  /** Returns the size of this image.  */
  async size() {
    return u("plugin:image|size", { rid: this.rid });
  }
}
function Wi(t) {
  return t == null ? null : typeof t == "string" ? t : t instanceof si ? t.rid : t;
}
async function rc(t, e) {
  await u("plugin:clipboard-manager|write_text", {
    label: e == null ? void 0 : e.label,
    text: t
  });
}
async function Xi(t = {}) {
  return typeof t == "object" && Object.freeze(t), await u("plugin:dialog|open", { options: t });
}
async function oc(t = {}) {
  return typeof t == "object" && Object.freeze(t), await u("plugin:dialog|save", { options: t });
}
class fa {
  constructor(...e) {
    this.type = "Logical", e.length === 1 ? "Logical" in e[0] ? (this.width = e[0].Logical.width, this.height = e[0].Logical.height) : (this.width = e[0].width, this.height = e[0].height) : (this.width = e[0], this.height = e[1]);
  }
  /**
   * Converts the logical size to a physical one.
   * @example
   * ```typescript
   * import { LogicalSize } from '@tauri-apps/api/dpi';
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   *
   * const appWindow = getCurrentWindow();
   * const factor = await appWindow.scaleFactor();
   * const size = new LogicalSize(400, 500);
   * const physical = size.toPhysical(factor);
   * ```
   *
   * @since 2.0.0
   */
  toPhysical(e) {
    return new ni(this.width * e, this.height * e);
  }
  [Se]() {
    return {
      width: this.width,
      height: this.height
    };
  }
  toJSON() {
    return this[Se]();
  }
}
class ni {
  constructor(...e) {
    this.type = "Physical", e.length === 1 ? "Physical" in e[0] ? (this.width = e[0].Physical.width, this.height = e[0].Physical.height) : (this.width = e[0].width, this.height = e[0].height) : (this.width = e[0], this.height = e[1]);
  }
  /**
   * Converts the physical size to a logical one.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const appWindow = getCurrentWindow();
   * const factor = await appWindow.scaleFactor();
   * const size = await appWindow.innerSize(); // PhysicalSize
   * const logical = size.toLogical(factor);
   * ```
   */
  toLogical(e) {
    return new fa(this.width / e, this.height / e);
  }
  [Se]() {
    return {
      width: this.width,
      height: this.height
    };
  }
  toJSON() {
    return this[Se]();
  }
}
class St {
  constructor(e) {
    this.size = e;
  }
  toLogical(e) {
    return this.size instanceof fa ? this.size : this.size.toLogical(e);
  }
  toPhysical(e) {
    return this.size instanceof ni ? this.size : this.size.toPhysical(e);
  }
  [Se]() {
    return {
      [`${this.size.type}`]: {
        width: this.size.width,
        height: this.size.height
      }
    };
  }
  toJSON() {
    return this[Se]();
  }
}
class va {
  constructor(...e) {
    this.type = "Logical", e.length === 1 ? "Logical" in e[0] ? (this.x = e[0].Logical.x, this.y = e[0].Logical.y) : (this.x = e[0].x, this.y = e[0].y) : (this.x = e[0], this.y = e[1]);
  }
  /**
   * Converts the logical position to a physical one.
   * @example
   * ```typescript
   * import { LogicalPosition } from '@tauri-apps/api/dpi';
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   *
   * const appWindow = getCurrentWindow();
   * const factor = await appWindow.scaleFactor();
   * const position = new LogicalPosition(400, 500);
   * const physical = position.toPhysical(factor);
   * ```
   *
   * @since 2.0.0
   */
  toPhysical(e) {
    return new Ke(this.x * e, this.y * e);
  }
  [Se]() {
    return {
      x: this.x,
      y: this.y
    };
  }
  toJSON() {
    return this[Se]();
  }
}
class Ke {
  constructor(...e) {
    this.type = "Physical", e.length === 1 ? "Physical" in e[0] ? (this.x = e[0].Physical.x, this.y = e[0].Physical.y) : (this.x = e[0].x, this.y = e[0].y) : (this.x = e[0], this.y = e[1]);
  }
  /**
   * Converts the physical position to a logical one.
   * @example
   * ```typescript
   * import { PhysicalPosition } from '@tauri-apps/api/dpi';
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   *
   * const appWindow = getCurrentWindow();
   * const factor = await appWindow.scaleFactor();
   * const position = new PhysicalPosition(400, 500);
   * const physical = position.toLogical(factor);
   * ```
   *
   * @since 2.0.0
   */
  toLogical(e) {
    return new va(this.x / e, this.y / e);
  }
  [Se]() {
    return {
      x: this.x,
      y: this.y
    };
  }
  toJSON() {
    return this[Se]();
  }
}
class Li {
  constructor(e) {
    this.position = e;
  }
  toLogical(e) {
    return this.position instanceof va ? this.position : this.position.toLogical(e);
  }
  toPhysical(e) {
    return this.position instanceof Ke ? this.position : this.position.toPhysical(e);
  }
  [Se]() {
    return {
      [`${this.position.type}`]: {
        x: this.position.x,
        y: this.position.y
      }
    };
  }
  toJSON() {
    return this[Se]();
  }
}
var hs;
(function(t) {
  t[t.Critical = 1] = "Critical", t[t.Informational = 2] = "Informational";
})(hs || (hs = {}));
class dc {
  constructor(e) {
    this._preventDefault = !1, this.event = e.event, this.id = e.id;
  }
  preventDefault() {
    this._preventDefault = !0;
  }
  isPreventDefault() {
    return this._preventDefault;
  }
}
var zn;
(function(t) {
  t.None = "none", t.Normal = "normal", t.Indeterminate = "indeterminate", t.Paused = "paused", t.Error = "error";
})(zn || (zn = {}));
function ba() {
  return new ha(window.__TAURI_INTERNALS__.metadata.currentWindow.label, {
    // @ts-expect-error `skip` is not defined in the public API but it is handled by the constructor
    skip: !0
  });
}
async function cs() {
  return u("plugin:window|get_all_windows").then((t) => t.map((e) => new ha(e, {
    // @ts-expect-error `skip` is not defined in the public API but it is handled by the constructor
    skip: !0
  })));
}
const ls = ["tauri://created", "tauri://error"];
class ha {
  /**
   * Creates a new Window.
   * @example
   * ```typescript
   * import { Window } from '@tauri-apps/api/window';
   * const appWindow = new Window('my-label');
   * appWindow.once('tauri://created', function () {
   *  // window successfully created
   * });
   * appWindow.once('tauri://error', function (e) {
   *  // an error happened creating the window
   * });
   * ```
   *
   * @param label The unique window label. Must be alphanumeric: `a-zA-Z-/:_`.
   * @returns The {@link Window} instance to communicate with the window.
   */
  constructor(e, i = {}) {
    var s;
    this.label = e, this.listeners = /* @__PURE__ */ Object.create(null), i != null && i.skip || u("plugin:window|create", {
      options: {
        ...i,
        parent: typeof i.parent == "string" ? i.parent : (s = i.parent) === null || s === void 0 ? void 0 : s.label,
        label: e
      }
    }).then(async () => this.emit("tauri://created")).catch(async (n) => this.emit("tauri://error", n));
  }
  /**
   * Gets the Window associated with the given label.
   * @example
   * ```typescript
   * import { Window } from '@tauri-apps/api/window';
   * const mainWindow = Window.getByLabel('main');
   * ```
   *
   * @param label The window label.
   * @returns The Window instance to communicate with the window or null if the window doesn't exist.
   */
  static async getByLabel(e) {
    var i;
    return (i = (await cs()).find((s) => s.label === e)) !== null && i !== void 0 ? i : null;
  }
  /**
   * Get an instance of `Window` for the current window.
   */
  static getCurrent() {
    return ba();
  }
  /**
   * Gets a list of instances of `Window` for all available windows.
   */
  static async getAll() {
    return cs();
  }
  /**
   *  Gets the focused window.
   * @example
   * ```typescript
   * import { Window } from '@tauri-apps/api/window';
   * const focusedWindow = Window.getFocusedWindow();
   * ```
   *
   * @returns The Window instance or `undefined` if there is not any focused window.
   */
  static async getFocusedWindow() {
    for (const e of await cs())
      if (await e.isFocused())
        return e;
    return null;
  }
  /**
   * Listen to an emitted event on this window.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const unlisten = await getCurrentWindow().listen<string>('state-changed', (event) => {
   *   console.log(`Got error: ${payload}`);
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @param event Event name. Must include only alphanumeric characters, `-`, `/`, `:` and `_`.
   * @param handler Event handler.
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async listen(e, i) {
    return this._handleTauriEvent(e, i) ? () => {
      const s = this.listeners[e];
      s.splice(s.indexOf(i), 1);
    } : Es(e, i, {
      target: { kind: "Window", label: this.label }
    });
  }
  /**
   * Listen to an emitted event on this window only once.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const unlisten = await getCurrentWindow().once<null>('initialized', (event) => {
   *   console.log(`Window initialized!`);
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @param event Event name. Must include only alphanumeric characters, `-`, `/`, `:` and `_`.
   * @param handler Event handler.
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async once(e, i) {
    return this._handleTauriEvent(e, i) ? () => {
      const s = this.listeners[e];
      s.splice(s.indexOf(i), 1);
    } : ac(e, i, {
      target: { kind: "Window", label: this.label }
    });
  }
  /**
   * Emits an event to all {@link EventTarget|targets}.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().emit('window-loaded', { loggedIn: true, token: 'authToken' });
   * ```
   *
   * @param event Event name. Must include only alphanumeric characters, `-`, `/`, `:` and `_`.
   * @param payload Event payload.
   */
  async emit(e, i) {
    if (ls.includes(e)) {
      for (const s of this.listeners[e] || [])
        s({
          event: e,
          id: -1,
          payload: i
        });
      return;
    }
    return cc(e, i);
  }
  /**
   * Emits an event to all {@link EventTarget|targets} matching the given target.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().emit('main', 'window-loaded', { loggedIn: true, token: 'authToken' });
   * ```
   * @param target Label of the target Window/Webview/WebviewWindow or raw {@link EventTarget} object.
   * @param event Event name. Must include only alphanumeric characters, `-`, `/`, `:` and `_`.
   * @param payload Event payload.
   */
  async emitTo(e, i, s) {
    if (ls.includes(i)) {
      for (const n of this.listeners[i] || [])
        n({
          event: i,
          id: -1,
          payload: s
        });
      return;
    }
    return lc(e, i, s);
  }
  /** @ignore */
  _handleTauriEvent(e, i) {
    return ls.includes(e) ? (e in this.listeners ? this.listeners[e].push(i) : this.listeners[e] = [i], !0) : !1;
  }
  // Getters
  /**
   * The scale factor that can be used to map physical pixels to logical pixels.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const factor = await getCurrentWindow().scaleFactor();
   * ```
   *
   * @returns The window's monitor scale factor.
   */
  async scaleFactor() {
    return u("plugin:window|scale_factor", {
      label: this.label
    });
  }
  /**
   * The position of the top-left hand corner of the window's client area relative to the top-left hand corner of the desktop.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const position = await getCurrentWindow().innerPosition();
   * ```
   *
   * @returns The window's inner position.
   */
  async innerPosition() {
    return u("plugin:window|inner_position", {
      label: this.label
    }).then((e) => new Ke(e));
  }
  /**
   * The position of the top-left hand corner of the window relative to the top-left hand corner of the desktop.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const position = await getCurrentWindow().outerPosition();
   * ```
   *
   * @returns The window's outer position.
   */
  async outerPosition() {
    return u("plugin:window|outer_position", {
      label: this.label
    }).then((e) => new Ke(e));
  }
  /**
   * The physical size of the window's client area.
   * The client area is the content of the window, excluding the title bar and borders.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const size = await getCurrentWindow().innerSize();
   * ```
   *
   * @returns The window's inner size.
   */
  async innerSize() {
    return u("plugin:window|inner_size", {
      label: this.label
    }).then((e) => new ni(e));
  }
  /**
   * The physical size of the entire window.
   * These dimensions include the title bar and borders. If you don't want that (and you usually don't), use inner_size instead.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const size = await getCurrentWindow().outerSize();
   * ```
   *
   * @returns The window's outer size.
   */
  async outerSize() {
    return u("plugin:window|outer_size", {
      label: this.label
    }).then((e) => new ni(e));
  }
  /**
   * Gets the window's current fullscreen state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const fullscreen = await getCurrentWindow().isFullscreen();
   * ```
   *
   * @returns Whether the window is in fullscreen mode or not.
   */
  async isFullscreen() {
    return u("plugin:window|is_fullscreen", {
      label: this.label
    });
  }
  /**
   * Gets the window's current minimized state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const minimized = await getCurrentWindow().isMinimized();
   * ```
   */
  async isMinimized() {
    return u("plugin:window|is_minimized", {
      label: this.label
    });
  }
  /**
   * Gets the window's current maximized state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const maximized = await getCurrentWindow().isMaximized();
   * ```
   *
   * @returns Whether the window is maximized or not.
   */
  async isMaximized() {
    return u("plugin:window|is_maximized", {
      label: this.label
    });
  }
  /**
   * Gets the window's current focus state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const focused = await getCurrentWindow().isFocused();
   * ```
   *
   * @returns Whether the window is focused or not.
   */
  async isFocused() {
    return u("plugin:window|is_focused", {
      label: this.label
    });
  }
  /**
   * Gets the window's current decorated state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const decorated = await getCurrentWindow().isDecorated();
   * ```
   *
   * @returns Whether the window is decorated or not.
   */
  async isDecorated() {
    return u("plugin:window|is_decorated", {
      label: this.label
    });
  }
  /**
   * Gets the window's current resizable state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const resizable = await getCurrentWindow().isResizable();
   * ```
   *
   * @returns Whether the window is resizable or not.
   */
  async isResizable() {
    return u("plugin:window|is_resizable", {
      label: this.label
    });
  }
  /**
   * Gets the window's native maximize button state.
   *
   * #### Platform-specific
   *
   * - **Linux / iOS / Android:** Unsupported.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const maximizable = await getCurrentWindow().isMaximizable();
   * ```
   *
   * @returns Whether the window's native maximize button is enabled or not.
   */
  async isMaximizable() {
    return u("plugin:window|is_maximizable", {
      label: this.label
    });
  }
  /**
   * Gets the window's native minimize button state.
   *
   * #### Platform-specific
   *
   * - **Linux / iOS / Android:** Unsupported.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const minimizable = await getCurrentWindow().isMinimizable();
   * ```
   *
   * @returns Whether the window's native minimize button is enabled or not.
   */
  async isMinimizable() {
    return u("plugin:window|is_minimizable", {
      label: this.label
    });
  }
  /**
   * Gets the window's native close button state.
   *
   * #### Platform-specific
   *
   * - **iOS / Android:** Unsupported.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const closable = await getCurrentWindow().isClosable();
   * ```
   *
   * @returns Whether the window's native close button is enabled or not.
   */
  async isClosable() {
    return u("plugin:window|is_closable", {
      label: this.label
    });
  }
  /**
   * Gets the window's current visible state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const visible = await getCurrentWindow().isVisible();
   * ```
   *
   * @returns Whether the window is visible or not.
   */
  async isVisible() {
    return u("plugin:window|is_visible", {
      label: this.label
    });
  }
  /**
   * Gets the window's current title.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const title = await getCurrentWindow().title();
   * ```
   */
  async title() {
    return u("plugin:window|title", {
      label: this.label
    });
  }
  /**
   * Gets the window's current theme.
   *
   * #### Platform-specific
   *
   * - **macOS:** Theme was introduced on macOS 10.14. Returns `light` on macOS 10.13 and below.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const theme = await getCurrentWindow().theme();
   * ```
   *
   * @returns The window theme.
   */
  async theme() {
    return u("plugin:window|theme", {
      label: this.label
    });
  }
  /**
   * Whether the window is configured to be always on top of other windows or not.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const alwaysOnTop = await getCurrentWindow().isAlwaysOnTop();
   * ```
   *
   * @returns Whether the window is visible or not.
   */
  async isAlwaysOnTop() {
    return u("plugin:window|is_always_on_top", {
      label: this.label
    });
  }
  async activityName() {
    return u("plugin:window|activity_name", {
      label: this.label
    });
  }
  async sceneIdentifier() {
    return u("plugin:window|scene_identifier", {
      label: this.label
    });
  }
  // Setters
  /**
   * Centers the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().center();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async center() {
    return u("plugin:window|center", {
      label: this.label
    });
  }
  /**
   *  Requests user attention to the window, this has no effect if the application
   * is already focused. How requesting for user attention manifests is platform dependent,
   * see `UserAttentionType` for details.
   *
   * Providing `null` will unset the request for user attention. Unsetting the request for
   * user attention might not be done automatically by the WM when the window receives input.
   *
   * #### Platform-specific
   *
   * - **macOS:** `null` has no effect.
   * - **Linux:** Urgency levels have the same effect.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().requestUserAttention();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async requestUserAttention(e) {
    let i = null;
    return e && (e === hs.Critical ? i = { type: "Critical" } : i = { type: "Informational" }), u("plugin:window|request_user_attention", {
      label: this.label,
      value: i
    });
  }
  /**
   * Updates the window resizable flag.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setResizable(false);
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async setResizable(e) {
    return u("plugin:window|set_resizable", {
      label: this.label,
      value: e
    });
  }
  /**
   * Enable or disable the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setEnabled(false);
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   *
   * @since 2.0.0
   */
  async setEnabled(e) {
    return u("plugin:window|set_enabled", {
      label: this.label,
      value: e
    });
  }
  /**
   * Whether the window is enabled or disabled.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setEnabled(false);
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   *
   * @since 2.0.0
   */
  async isEnabled() {
    return u("plugin:window|is_enabled", {
      label: this.label
    });
  }
  /**
   * Sets whether the window's native maximize button is enabled or not.
   * If resizable is set to false, this setting is ignored.
   *
   * #### Platform-specific
   *
   * - **macOS:** Disables the "zoom" button in the window titlebar, which is also used to enter fullscreen mode.
   * - **Linux / iOS / Android:** Unsupported.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setMaximizable(false);
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async setMaximizable(e) {
    return u("plugin:window|set_maximizable", {
      label: this.label,
      value: e
    });
  }
  /**
   * Sets whether the window's native minimize button is enabled or not.
   *
   * #### Platform-specific
   *
   * - **Linux / iOS / Android:** Unsupported.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setMinimizable(false);
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async setMinimizable(e) {
    return u("plugin:window|set_minimizable", {
      label: this.label,
      value: e
    });
  }
  /**
   * Sets whether the window's native close button is enabled or not.
   *
   * #### Platform-specific
   *
   * - **Linux:** GTK+ will do its best to convince the window manager not to show a close button. Depending on the system, this function may not have any effect when called on a window that is already visible
   * - **iOS / Android:** Unsupported.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setClosable(false);
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async setClosable(e) {
    return u("plugin:window|set_closable", {
      label: this.label,
      value: e
    });
  }
  /**
   * Sets the window title.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setTitle('Tauri');
   * ```
   *
   * @param title The new title
   * @returns A promise indicating the success or failure of the operation.
   */
  async setTitle(e) {
    return u("plugin:window|set_title", {
      label: this.label,
      value: e
    });
  }
  /**
   * Maximizes the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().maximize();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async maximize() {
    return u("plugin:window|maximize", {
      label: this.label
    });
  }
  /**
   * Unmaximizes the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().unmaximize();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async unmaximize() {
    return u("plugin:window|unmaximize", {
      label: this.label
    });
  }
  /**
   * Toggles the window maximized state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().toggleMaximize();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async toggleMaximize() {
    return u("plugin:window|toggle_maximize", {
      label: this.label
    });
  }
  /**
   * Minimizes the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().minimize();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async minimize() {
    return u("plugin:window|minimize", {
      label: this.label
    });
  }
  /**
   * Unminimizes the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().unminimize();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async unminimize() {
    return u("plugin:window|unminimize", {
      label: this.label
    });
  }
  /**
   * Sets the window visibility to true.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().show();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async show() {
    return u("plugin:window|show", {
      label: this.label
    });
  }
  /**
   * Sets the window visibility to false.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().hide();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async hide() {
    return u("plugin:window|hide", {
      label: this.label
    });
  }
  /**
   * Closes the window.
   *
   * Note this emits a closeRequested event so you can intercept it. To force window close, use {@link Window.destroy}.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().close();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async close() {
    return u("plugin:window|close", {
      label: this.label
    });
  }
  /**
   * Destroys the window. Behaves like {@link Window.close} but forces the window close instead of emitting a closeRequested event.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().destroy();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async destroy() {
    return u("plugin:window|destroy", {
      label: this.label
    });
  }
  /**
   * Whether the window should have borders and bars.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setDecorations(false);
   * ```
   *
   * @param decorations Whether the window should have borders and bars.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setDecorations(e) {
    return u("plugin:window|set_decorations", {
      label: this.label,
      value: e
    });
  }
  /**
   * Whether or not the window should have shadow.
   *
   * #### Platform-specific
   *
   * - **Windows:**
   *   - `false` has no effect on decorated window, shadows are always ON.
   *   - `true` will make undecorated window have a 1px white border,
   * and on Windows 11, it will have a rounded corners.
   * - **Linux:** Unsupported.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setShadow(false);
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async setShadow(e) {
    return u("plugin:window|set_shadow", {
      label: this.label,
      value: e
    });
  }
  /**
   * Set window effects.
   */
  async setEffects(e) {
    return u("plugin:window|set_effects", {
      label: this.label,
      value: e
    });
  }
  /**
   * Clear any applied effects if possible.
   */
  async clearEffects() {
    return u("plugin:window|set_effects", {
      label: this.label,
      value: null
    });
  }
  /**
   * Whether the window should always be on top of other windows.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setAlwaysOnTop(true);
   * ```
   *
   * @param alwaysOnTop Whether the window should always be on top of other windows or not.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setAlwaysOnTop(e) {
    return u("plugin:window|set_always_on_top", {
      label: this.label,
      value: e
    });
  }
  /**
   * Whether the window should always be below other windows.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setAlwaysOnBottom(true);
   * ```
   *
   * @param alwaysOnBottom Whether the window should always be below other windows or not.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setAlwaysOnBottom(e) {
    return u("plugin:window|set_always_on_bottom", {
      label: this.label,
      value: e
    });
  }
  /**
   * Prevents the window contents from being captured by other apps.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setContentProtected(true);
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async setContentProtected(e) {
    return u("plugin:window|set_content_protected", {
      label: this.label,
      value: e
    });
  }
  /**
   * Resizes the window with a new inner size.
   * @example
   * ```typescript
   * import { getCurrentWindow, LogicalSize } from '@tauri-apps/api/window';
   * await getCurrentWindow().setSize(new LogicalSize(600, 500));
   * ```
   *
   * @param size The logical or physical inner size.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setSize(e) {
    return u("plugin:window|set_size", {
      label: this.label,
      value: e instanceof St ? e : new St(e)
    });
  }
  /**
   * Sets the window minimum inner size. If the `size` argument is not provided, the constraint is unset.
   * @example
   * ```typescript
   * import { getCurrentWindow, PhysicalSize } from '@tauri-apps/api/window';
   * await getCurrentWindow().setMinSize(new PhysicalSize(600, 500));
   * ```
   *
   * @param size The logical or physical inner size, or `null` to unset the constraint.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setMinSize(e) {
    return u("plugin:window|set_min_size", {
      label: this.label,
      value: e instanceof St ? e : e ? new St(e) : null
    });
  }
  /**
   * Sets the window maximum inner size. If the `size` argument is undefined, the constraint is unset.
   * @example
   * ```typescript
   * import { getCurrentWindow, LogicalSize } from '@tauri-apps/api/window';
   * await getCurrentWindow().setMaxSize(new LogicalSize(600, 500));
   * ```
   *
   * @param size The logical or physical inner size, or `null` to unset the constraint.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setMaxSize(e) {
    return u("plugin:window|set_max_size", {
      label: this.label,
      value: e instanceof St ? e : e ? new St(e) : null
    });
  }
  /**
   * Sets the window inner size constraints.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setSizeConstraints({ minWidth: 300 });
   * ```
   *
   * @param constraints The logical or physical inner size, or `null` to unset the constraint.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setSizeConstraints(e) {
    function i(s) {
      return s ? { Logical: s } : null;
    }
    return u("plugin:window|set_size_constraints", {
      label: this.label,
      value: {
        minWidth: i(e == null ? void 0 : e.minWidth),
        minHeight: i(e == null ? void 0 : e.minHeight),
        maxWidth: i(e == null ? void 0 : e.maxWidth),
        maxHeight: i(e == null ? void 0 : e.maxHeight)
      }
    });
  }
  /**
   * Sets the window outer position.
   * @example
   * ```typescript
   * import { getCurrentWindow, LogicalPosition } from '@tauri-apps/api/window';
   * await getCurrentWindow().setPosition(new LogicalPosition(600, 500));
   * ```
   *
   * @param position The new position, in logical or physical pixels.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setPosition(e) {
    return u("plugin:window|set_position", {
      label: this.label,
      value: e instanceof Li ? e : new Li(e)
    });
  }
  /**
   * Sets the window fullscreen state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setFullscreen(true);
   * ```
   *
   * @param fullscreen Whether the window should go to fullscreen or not.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setFullscreen(e) {
    return u("plugin:window|set_fullscreen", {
      label: this.label,
      value: e
    });
  }
  /**
   * On macOS, Toggles a fullscreen mode that doesn’t require a new macOS space. Returns a boolean indicating whether the transition was successful (this won’t work if the window was already in the native fullscreen).
   * This is how fullscreen used to work on macOS in versions before Lion. And allows the user to have a fullscreen window without using another space or taking control over the entire monitor.
   *
   * On other platforms, this is the same as {@link Window.setFullscreen}.
   *
   * @param fullscreen Whether the window should go to simple fullscreen or not.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setSimpleFullscreen(e) {
    return u("plugin:window|set_simple_fullscreen", {
      label: this.label,
      value: e
    });
  }
  /**
   * Bring the window to front and focus.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setFocus();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async setFocus() {
    return u("plugin:window|set_focus", {
      label: this.label
    });
  }
  /**
   * Sets whether the window can be focused.
   *
   * #### Platform-specific
   *
   * - **macOS**: If the window is already focused, it is not possible to unfocus it after calling `set_focusable(false)`.
   *   In this case, you might consider calling {@link Window.setFocus} but it will move the window to the back i.e. at the bottom in terms of z-order.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setFocusable(true);
   * ```
   *
   * @param focusable Whether the window can be focused.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setFocusable(e) {
    return u("plugin:window|set_focusable", {
      label: this.label,
      value: e
    });
  }
  /**
   * Sets the window icon.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setIcon('/tauri/awesome.png');
   * ```
   *
   * Note that you may need the `image-ico` or `image-png` Cargo features to use this API.
   * To enable it, change your Cargo.toml file:
   * ```toml
   * [dependencies]
   * tauri = { version = "...", features = ["...", "image-png"] }
   * ```
   *
   * @param icon Icon bytes or path to the icon file.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setIcon(e) {
    return u("plugin:window|set_icon", {
      label: this.label,
      value: Wi(e)
    });
  }
  /**
   * Whether the window icon should be hidden from the taskbar or not.
   *
   * #### Platform-specific
   *
   * - **macOS:** Unsupported.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setSkipTaskbar(true);
   * ```
   *
   * @param skip true to hide window icon, false to show it.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setSkipTaskbar(e) {
    return u("plugin:window|set_skip_taskbar", {
      label: this.label,
      value: e
    });
  }
  /**
   * Grabs the cursor, preventing it from leaving the window.
   *
   * There's no guarantee that the cursor will be hidden. You should
   * hide it by yourself if you want so.
   *
   * #### Platform-specific
   *
   * - **Linux:** Unsupported.
   * - **macOS:** This locks the cursor in a fixed location, which looks visually awkward.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setCursorGrab(true);
   * ```
   *
   * @param grab `true` to grab the cursor icon, `false` to release it.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setCursorGrab(e) {
    return u("plugin:window|set_cursor_grab", {
      label: this.label,
      value: e
    });
  }
  /**
   * Modifies the cursor's visibility.
   *
   * #### Platform-specific
   *
   * - **Windows:** The cursor is only hidden within the confines of the window.
   * - **macOS:** The cursor is hidden as long as the window has input focus, even if the cursor is
   *   outside of the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setCursorVisible(false);
   * ```
   *
   * @param visible If `false`, this will hide the cursor. If `true`, this will show the cursor.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setCursorVisible(e) {
    return u("plugin:window|set_cursor_visible", {
      label: this.label,
      value: e
    });
  }
  /**
   * Modifies the cursor icon of the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setCursorIcon('help');
   * ```
   *
   * @param icon The new cursor icon.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setCursorIcon(e) {
    return u("plugin:window|set_cursor_icon", {
      label: this.label,
      value: e
    });
  }
  /**
   * Sets the window background color.
   *
   * #### Platform-specific:
   *
   * - **Windows:** alpha channel is ignored.
   * - **iOS / Android:** Unsupported.
   *
   * @returns A promise indicating the success or failure of the operation.
   *
   * @since 2.1.0
   */
  async setBackgroundColor(e) {
    return u("plugin:window|set_background_color", { color: e });
  }
  /**
   * Changes the position of the cursor in window coordinates.
   * @example
   * ```typescript
   * import { getCurrentWindow, LogicalPosition } from '@tauri-apps/api/window';
   * await getCurrentWindow().setCursorPosition(new LogicalPosition(600, 300));
   * ```
   *
   * @param position The new cursor position.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setCursorPosition(e) {
    return u("plugin:window|set_cursor_position", {
      label: this.label,
      value: e instanceof Li ? e : new Li(e)
    });
  }
  /**
   * Changes the cursor events behavior.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setIgnoreCursorEvents(true);
   * ```
   *
   * @param ignore `true` to ignore the cursor events; `false` to process them as usual.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setIgnoreCursorEvents(e) {
    return u("plugin:window|set_ignore_cursor_events", {
      label: this.label,
      value: e
    });
  }
  /**
   * Starts dragging the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().startDragging();
   * ```
   *
   * @return A promise indicating the success or failure of the operation.
   */
  async startDragging() {
    return u("plugin:window|start_dragging", {
      label: this.label
    });
  }
  /**
   * Starts resize-dragging the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().startResizeDragging();
   * ```
   *
   * @return A promise indicating the success or failure of the operation.
   */
  async startResizeDragging(e) {
    return u("plugin:window|start_resize_dragging", {
      label: this.label,
      value: e
    });
  }
  /**
   * Sets the badge count. It is app wide and not specific to this window.
   *
   * #### Platform-specific
   *
   * - **Windows**: Unsupported. Use @{linkcode Window.setOverlayIcon} instead.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setBadgeCount(5);
   * ```
   *
   * @param count The badge count. Use `undefined` to remove the badge.
   * @return A promise indicating the success or failure of the operation.
   */
  async setBadgeCount(e) {
    return u("plugin:window|set_badge_count", {
      label: this.label,
      value: e
    });
  }
  /**
   * Sets the badge cont **macOS only**.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setBadgeLabel("Hello");
   * ```
   *
   * @param label The badge label. Use `undefined` to remove the badge.
   * @return A promise indicating the success or failure of the operation.
   */
  async setBadgeLabel(e) {
    return u("plugin:window|set_badge_label", {
      label: this.label,
      value: e
    });
  }
  /**
   * Sets the overlay icon. **Windows only**
   * The overlay icon can be set for every window.
   *
   *
   * Note that you may need the `image-ico` or `image-png` Cargo features to use this API.
   * To enable it, change your Cargo.toml file:
   *
   * ```toml
   * [dependencies]
   * tauri = { version = "...", features = ["...", "image-png"] }
   * ```
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setOverlayIcon("/tauri/awesome.png");
   * ```
   *
   * @param icon Icon bytes or path to the icon file. Use `undefined` to remove the overlay icon.
   * @return A promise indicating the success or failure of the operation.
   */
  async setOverlayIcon(e) {
    return u("plugin:window|set_overlay_icon", {
      label: this.label,
      value: e ? Wi(e) : void 0
    });
  }
  /**
   * Sets the taskbar progress state.
   *
   * #### Platform-specific
   *
   * - **Linux / macOS**: Progress bar is app-wide and not specific to this window.
   * - **Linux**: Only supported desktop environments with `libunity` (e.g. GNOME).
   *
   * @example
   * ```typescript
   * import { getCurrentWindow, ProgressBarStatus } from '@tauri-apps/api/window';
   * await getCurrentWindow().setProgressBar({
   *   status: ProgressBarStatus.Normal,
   *   progress: 50,
   * });
   * ```
   *
   * @return A promise indicating the success or failure of the operation.
   */
  async setProgressBar(e) {
    return u("plugin:window|set_progress_bar", {
      label: this.label,
      value: e
    });
  }
  /**
   * Sets whether the window should be visible on all workspaces or virtual desktops.
   *
   * #### Platform-specific
   *
   * - **Windows / iOS / Android:** Unsupported.
   *
   * @since 2.0.0
   */
  async setVisibleOnAllWorkspaces(e) {
    return u("plugin:window|set_visible_on_all_workspaces", {
      label: this.label,
      value: e
    });
  }
  /**
   * Sets the title bar style. **macOS only**.
   *
   * @since 2.0.0
   */
  async setTitleBarStyle(e) {
    return u("plugin:window|set_title_bar_style", {
      label: this.label,
      value: e
    });
  }
  /**
   * Set window theme, pass in `null` or `undefined` to follow system theme
   *
   * #### Platform-specific
   *
   * - **Linux / macOS**: Theme is app-wide and not specific to this window.
   * - **iOS / Android:** Unsupported.
   *
   * @since 2.0.0
   */
  async setTheme(e) {
    return u("plugin:window|set_theme", {
      label: this.label,
      value: e
    });
  }
  // Listeners
  /**
   * Listen to window resize.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from "@tauri-apps/api/window";
   * const unlisten = await getCurrentWindow().onResized(({ payload: size }) => {
   *  console.log('Window resized', size);
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async onResized(e) {
    return this.listen(ue.WINDOW_RESIZED, (i) => {
      i.payload = new ni(i.payload), e(i);
    });
  }
  /**
   * Listen to window move.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from "@tauri-apps/api/window";
   * const unlisten = await getCurrentWindow().onMoved(({ payload: position }) => {
   *  console.log('Window moved', position);
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async onMoved(e) {
    return this.listen(ue.WINDOW_MOVED, (i) => {
      i.payload = new Ke(i.payload), e(i);
    });
  }
  /**
   * Listen to window close requested. Emitted when the user requests to closes the window.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from "@tauri-apps/api/window";
   * import { confirm } from '@tauri-apps/api/dialog';
   * const unlisten = await getCurrentWindow().onCloseRequested(async (event) => {
   *   const confirmed = await confirm('Are you sure?');
   *   if (!confirmed) {
   *     // user did not confirm closing the window; let's prevent it
   *     event.preventDefault();
   *   }
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async onCloseRequested(e) {
    return this.listen(ue.WINDOW_CLOSE_REQUESTED, async (i) => {
      const s = new dc(i);
      await e(s), s.isPreventDefault() || await this.destroy();
    });
  }
  /**
   * Listen to a file drop event.
   * The listener is triggered when the user hovers the selected files on the webview,
   * drops the files or cancels the operation.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from "@tauri-apps/api/webview";
   * const unlisten = await getCurrentWindow().onDragDropEvent((event) => {
   *  if (event.payload.type === 'over') {
   *    console.log('User hovering', event.payload.position);
   *  } else if (event.payload.type === 'drop') {
   *    console.log('User dropped', event.payload.paths);
   *  } else {
   *    console.log('File drop cancelled');
   *  }
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async onDragDropEvent(e) {
    const i = await this.listen(ue.DRAG_ENTER, (d) => {
      e({
        ...d,
        payload: {
          type: "enter",
          paths: d.payload.paths,
          position: new Ke(d.payload.position)
        }
      });
    }), s = await this.listen(ue.DRAG_OVER, (d) => {
      e({
        ...d,
        payload: {
          type: "over",
          position: new Ke(d.payload.position)
        }
      });
    }), n = await this.listen(ue.DRAG_DROP, (d) => {
      e({
        ...d,
        payload: {
          type: "drop",
          paths: d.payload.paths,
          position: new Ke(d.payload.position)
        }
      });
    }), c = await this.listen(ue.DRAG_LEAVE, (d) => {
      e({ ...d, payload: { type: "leave" } });
    });
    return () => {
      i(), n(), s(), c();
    };
  }
  /**
   * Listen to window focus change.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from "@tauri-apps/api/window";
   * const unlisten = await getCurrentWindow().onFocusChanged(({ payload: focused }) => {
   *  console.log('Focus changed, window is focused? ' + focused);
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async onFocusChanged(e) {
    const i = await this.listen(ue.WINDOW_FOCUS, (n) => {
      e({ ...n, payload: !0 });
    }), s = await this.listen(ue.WINDOW_BLUR, (n) => {
      e({ ...n, payload: !1 });
    });
    return () => {
      i(), s();
    };
  }
  /**
   * Listen to window scale change. Emitted when the window's scale factor has changed.
   * The following user actions can cause DPI changes:
   * - Changing the display's resolution.
   * - Changing the display's scale factor (e.g. in Control Panel on Windows).
   * - Moving the window to a display with a different scale factor.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from "@tauri-apps/api/window";
   * const unlisten = await getCurrentWindow().onScaleChanged(({ payload }) => {
   *  console.log('Scale changed', payload.scaleFactor, payload.size);
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async onScaleChanged(e) {
    return this.listen(ue.WINDOW_SCALE_FACTOR_CHANGED, e);
  }
  /**
   * Listen to the system theme change.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from "@tauri-apps/api/window";
   * const unlisten = await getCurrentWindow().onThemeChanged(({ payload: theme }) => {
   *  console.log('New theme: ' + theme);
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async onThemeChanged(e) {
    return this.listen(ue.WINDOW_THEME_CHANGED, e);
  }
}
var Wn;
(function(t) {
  t.Disabled = "disabled", t.Throttle = "throttle", t.Suspend = "suspend";
})(Wn || (Wn = {}));
var Hn;
(function(t) {
  t.Default = "default", t.FluentOverlay = "fluentOverlay";
})(Hn || (Hn = {}));
var Fn;
(function(t) {
  t.AppearanceBased = "appearanceBased", t.Light = "light", t.Dark = "dark", t.MediumLight = "mediumLight", t.UltraDark = "ultraDark", t.Titlebar = "titlebar", t.Selection = "selection", t.Menu = "menu", t.Popover = "popover", t.Sidebar = "sidebar", t.HeaderView = "headerView", t.Sheet = "sheet", t.WindowBackground = "windowBackground", t.HudWindow = "hudWindow", t.FullScreenUI = "fullScreenUI", t.Tooltip = "tooltip", t.ContentBackground = "contentBackground", t.UnderWindowBackground = "underWindowBackground", t.UnderPageBackground = "underPageBackground", t.Mica = "mica", t.Blur = "blur", t.Acrylic = "acrylic", t.Tabbed = "tabbed", t.TabbedDark = "tabbedDark", t.TabbedLight = "tabbedLight";
})(Fn || (Fn = {}));
var jn;
(function(t) {
  t.FollowsWindowActiveState = "followsWindowActiveState", t.Active = "active", t.Inactive = "inactive";
})(jn || (jn = {}));
const ya = "curve", mc = (() => {
  try {
    return ba().label;
  } catch {
    return "";
  }
})(), ga = mc.endsWith(`-${ya}`);
function pc(t) {
  return t === "top" ? "artist" : t;
}
const fc = {
  album: "spotify_albums",
  artist: "spotify_artists",
  show: "spotify_shows",
  top: "spotify_top_artists"
}, _a = ["L", "R", "C", "LFE", "SL", "SR", "BL", "BR"], us = 5e3, vc = 1280, bc = 720, hc = 550, yc = 300, wa = 180, Sa = 520, gc = 4e3, _c = 450, wc = 800, Sc = 8e3, kc = 200, $c = 15e3, xc = 500, Lc = 500, Ec = 250, qc = 500, Tc = 0.3, h = {
  play: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polygon points="6 4 20 12 6 20 6 4"/></svg>',
  pause: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="9" y1="4" x2="9" y2="20"/><line x1="15" y1="4" x2="15" y2="20"/></svg>',
  prev: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polygon points="19 5 9 12 19 19 19 5"/><line x1="5" y1="5" x2="5" y2="19"/></svg>',
  next: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polygon points="5 5 15 12 5 19 5 5"/><line x1="19" y1="5" x2="19" y2="19"/></svg>',
  /** 随机（关 / 随机共用这一个；「关」靠 `data-mode` 变暗区分）。 */
  shuffle: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="16 3 21 3 21 8"/><line x1="4" y1="20" x2="21" y2="3"/><polyline points="21 16 21 21 16 21"/><line x1="15" y1="15" x2="21" y2="21"/><line x1="4" y1="4" x2="9" y2="9"/></svg>',
  /** 循环（单曲循环；那个「1」由 CSS `::after` 加，SVG 里不写字）。 */
  repeat: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="17 1 21 5 17 9"/><path d="M3 11V9a4 4 0 0 1 4-4h14"/><polyline points="7 23 3 19 7 15"/><path d="M21 13v2a4 4 0 0 1-4 4H3"/></svg>',
  list: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="9" y1="6" x2="21" y2="6"/><line x1="9" y1="12" x2="21" y2="12"/><line x1="9" y1="18" x2="21" y2="18"/><circle cx="4" cy="6" r="1" fill="currentColor" stroke="none"/><circle cx="4" cy="12" r="1" fill="currentColor" stroke="none"/><circle cx="4" cy="18" r="1" fill="currentColor" stroke="none"/></svg>',
  /** 进播放界面。 */
  expand: '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 3 21 3 21 9"/><polyline points="9 21 3 21 3 15"/><line x1="21" y1="3" x2="14" y2="10"/><line x1="3" y1="21" x2="10" y2="14"/></svg>',
  /** 回默认界面。**唯一**的退出播放界面的入口 —— 播放停止不会自动退出。 */
  back: '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/><line x1="3" y1="12" x2="9" y2="12"/></svg>',
  chevron: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg>',
  copy: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15V5a2 2 0 0 1 2-2h10"/></svg>',
  link: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.5 1.5"/><path d="M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7L12 19"/></svg>',
  power: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M18.4 6.6a9 9 0 1 1-12.8 0"/><line x1="12" y1="2" x2="12" y2="12"/></svg>',
  gear: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>',
  volume: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M15.5 8.5a5 5 0 0 1 0 7"/></svg>',
  /** 工具条上的「设备」按钮（2026-09-28）。画成一台小音箱，比「显示器」更贴
   *  Spotify 那种「可选的播放设备」语义。 */
  speaker: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="2" width="14" height="20" rx="2"/><circle cx="12" cy="14" r="3.2"/><circle cx="12" cy="6" r="1" fill="currentColor" stroke="none"/></svg>',
  /** 实心心形（「我喜欢的歌曲」那块封面上的图案）。**这个是 `fill`，不是描边** ——
   *  它是一块封面图（Spotify 的收藏夹封面就是实心心 + 渐变底），不是可点按钮。 */
  heart: '<svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" stroke="none"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>',
  // ── 本地媒体库那一页用到的四个（2026-10-01）──
  /** 「本地音乐」入口 + 目录行（画成文件夹）。 */
  folder: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/></svg>',
  /** 「添加目录」。 */
  plus: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>',
  /** 移除一根目录（行尾那枚）。`music.pl-x` 用。 */
  x: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="6" y1="6" x2="18" y2="18"/><line x1="18" y1="6" x2="6" y2="18"/></svg>',
  /** 没有封面的曲目行左侧占位（一个八分音符）。 */
  note: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18V6l10-2v12"/><circle cx="6.5" cy="18" r="2.5"/><circle cx="16.5" cy="16" r="2.5"/></svg>',
  /** 「重新扫描」/「刷新」—— 画成环形箭头。 */
  refresh: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="21 3 21 9 15 9"/><path d="M20.4 14a8.5 8.5 0 1 1-1.6-7.5L21 9"/></svg>',
  /** 「测量」—— 一条起伏的响应曲线（Lucide 的 `activity` 那一族的形状）。 */
  wave: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12h3l2.5-6 3.5 12 3-8 2 2h4"/></svg>',
  /** 编辑（改列表）。**路径逐字抄自 icon-style.md §3 的「编辑 ✎」** —— 规范里已经
   *  给好这条了，不许自己另画一条（§4.2 最后一条：已有的图形不要重复造路径）。 */
  edit: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 3a2.8 2.8 0 0 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/></svg>',
  /** 删除（垃圾桶）。**同样逐字抄自 icon-style.md §3** —— 它是危险操作，
   *  按 §4.2 用同风格线性图标 + 语义色（hover 变 `--red`，见 styles.css）。 */
  trash: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6M14 11v6M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>',
  /** 停止本地播放（本地播放条右端那枚）。**它与暂停不是一回事**：暂停留着这台
   *  音频设备，停止会把设备一起放掉（见 player.rs 的 `player_stop`）。 */
  stop: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="6" y="6" width="12" height="12" rx="1.5"/></svg>',
  /** 「本地与 Spotify 同时出声」那把开关（2026-10-01）。画成**两个相交的圆** ——
   *  「两路并存」最直白的图形（Lucide 里叫 `blend`）。**不画成两个喇叭**：12px 下
   *  两个喇叭会糊成一团，而两个圆在任何尺寸下都认得出来。
   *  开关的「开着」不用第二个图形表达，靠 `.on` 的强调色（与其他开关一致）。 */
  dual: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="9" r="6.5"/><circle cx="15" cy="15" r="6.5"/></svg>',
  /** 「最常听的歌曲」那一行的图标（2026-10-01 用户第 4 条）。画成一条上扬的折线
   *  —— 「最常听 / 热度」最直白的图形（Lucide 的 `trending-up`，与上面这些同源）。
   *  与 `SVG.heart` 一样是 20px 的封面图案，但**保持描边风格**（它不是实心封面，
   *  它是「一行合成出来的入口」，与收藏夹那块渐变实心封面刻意区分开）。 */
  trend: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/></svg>'
  // （工具条上那枚「调音推子」图标 2026-10-01 随入口一起删掉了：调音改成标题栏
  //  三段切换的第三段，那枚图标就没有地方落了。图形本身仍在 icon-style.md §3 里。）
};
let m = null, v = null, se = null, ys = "", gs = !1, qt = [], lt = -1, Ti = null, Kt = null, Mi = !1, f = null, bi = 0, hi = 0, yi = 0, J = [], ht = [[]], Re = 0, ka = [], be = 0, ft = [], Nt = null, G = null, oe = -1, Je = 0, Ge = null, et = !1, Ve = null, qs = null, kt = -1, Xt = !1, Pt = !1, Ci = 0, rs = null;
const Mc = 300;
let Ei = null, Te = { a: !1, b: !1 }, Bt = ["a", "b"], tt = !1, ai = !1, Ts = null;
function Cc() {
  return { kind: "peaking", freq_hz: 1e3, gain_db: 0, q: 0.707, on: !0 };
}
function Yt() {
  bi = (f == null ? void 0 : f.preamp_db) ?? 0, hi = (f == null ? void 0 : f.bass_db) ?? 0, yi = (f == null ? void 0 : f.treble_db) ?? 0, ka = ((f == null ? void 0 : f.graphic_eq) ?? []).map((i) => ({ freq_hz: i.freq_hz, gain_db: i.gain_db })), be = (f == null ? void 0 : f.delay_ms) ?? 0, ft = ((f == null ? void 0 : f.channel_copy) ?? []).map((i) => ({ from: i.from, to: i.to })), Nt = (f == null ? void 0 : f.convolution) ?? null, G = null;
  const t = f != null && f.channels && f.channels > 0 ? f.channels : 2, e = [((f == null ? void 0 : f.filters) ?? []).map((i) => ({ ...i }))];
  for (let i = 1; i <= t; i++) {
    const s = ((f == null ? void 0 : f.if_else) ?? []).find((n) => n.channel === i - 1);
    e.push(((s == null ? void 0 : s.then) ?? []).map((n) => ({ ...n })));
  }
  ht = e, (Re < 0 || Re >= e.length) && (Re = 0), J = e[Re];
}
function Ac() {
  var i;
  if (!f) return [];
  if (Re === 0) return f.response.db;
  const t = (f.if_else ?? []).findIndex((s) => s.channel === Re - 1), e = t >= 0 ? (i = f.cond_db) == null ? void 0 : i[t] : void 0;
  return e && e.length ? e : f.response.db;
}
function Ic() {
  var i;
  const t = new Map(((f == null ? void 0 : f.if_else) ?? []).map((s) => [s.channel, s])), e = [];
  for (let s = 1; s < ht.length; s++) {
    const n = s - 1, c = ht[s], d = ((i = t.get(n)) == null ? void 0 : i.else) ?? [];
    if (c.length === 0 && d.length === 0) continue;
    const b = { channel: n, then: c };
    d.length > 0 && (b.else = d), e.push(b);
  }
  return e;
}
let R = "default", _s = null, ut = null, ve = !1, $a = "", j = null, os = !1, vt = "", Me = "", H = null, Ot = !1, Zt, re = "playlist";
const zt = /* @__PURE__ */ new Map(), ci = /* @__PURE__ */ new Set(), gi = /* @__PURE__ */ new Map();
let M = null, ye = null, Tt = !1, Qe = "", Le = !1, Ze = !1, Ie = "tracks", yt = null, Ue = !1, Z = null, ge = "", ds = !1, Ai = 0;
const Dc = 2e4;
let it = !1, Hi = "", Fi = 0, ji = !1, li = yc, ws = null, ui = "", ne = !1, ce = null, Ui = !1, Wt = "", Ce = "", qe = !1, Ne = /* @__PURE__ */ new Set(), _i = /* @__PURE__ */ new Set(), De = !1, Y = null, Ht = !1, st = "", he = null, wi = "", de, Mt = null, ri, S = null, $i = 0, _e = [], K = -1, rt = !1, te = -1, oi, ke = 0, Ct = [], xt = !1;
function xa() {
  return ne !== xt;
}
const La = "lunac-music-local-last";
function Rc() {
  try {
    const t = localStorage.getItem(La);
    if (!t) return null;
    const e = JSON.parse(t);
    if (!e || !Array.isArray(e.queue) || e.queue.length === 0) return null;
    const i = Number(e.index);
    return {
      queue: e.queue,
      index: Number.isInteger(i) && i >= 0 && i < e.queue.length ? i : 0,
      position_ms: Math.max(0, Number(e.position_ms) || 0)
    };
  } catch {
    return null;
  }
}
function Ki() {
  if (!(_e.length === 0 || K < 0))
    try {
      localStorage.setItem(La, JSON.stringify({
        queue: _e,
        index: K,
        position_ms: ke
      }));
    } catch {
    }
}
const Ea = "lunac-music-dual-play";
let Ee = Nc();
function Nc() {
  try {
    return localStorage.getItem(Ea) === "1";
  } catch {
    return !1;
  }
}
function Pc(t) {
  try {
    localStorage.setItem(Ea, t ? "1" : "0");
  } catch {
  }
}
const qa = "lunac-music-local-mode";
let ee = Bc();
function Bc() {
  try {
    const t = localStorage.getItem(qa);
    return t === "shuffle" || t === "repeat_all" || t === "repeat_one" ? t : "off";
  } catch {
    return "off";
  }
}
function Oc(t) {
  try {
    localStorage.setItem(qa, t);
  } catch {
  }
}
function Ms() {
  return a(ee === "shuffle" ? "music.mode_shuffle" : ee === "repeat_all" ? "music.mode_repeat_all" : ee === "repeat_one" ? "music.mode_repeat_one" : "music.mode_off");
}
let Ye, Ii = !1, ot, Un = !1, Di, Ta = 0, Ma = 0, dt = null, Si = null, mt = 0, Ft = !1, ct = -1, pt = [], di = 0, Pe, bt, Ri = "", Ni = 0, Ss = "";
function Zi() {
  return R === "player" || R === "lplayer";
}
function l(t) {
  return t.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
function mi(t) {
  if (!isFinite(t) || t < 0) return "0:00";
  const e = Math.floor(t / 1e3), i = Math.floor(e / 60), s = e % 60;
  return `${i}:${String(s).padStart(2, "0")}`;
}
function F(t) {
  if (!isFinite(t) || t < 0) return "00:00";
  const e = Math.floor(t / 1e3);
  return `${String(Math.floor(e / 60)).padStart(2, "0")}:${String(e % 60).padStart(2, "0")}`;
}
function C(t) {
  const e = t instanceof Error ? t.message : String(t);
  if (e.includes("ERR_NO_CLIENT_ID")) return a("music.err_no_client_id");
  if (e.includes("ERR_NOT_CONNECTED")) return a("music.err_not_connected");
  if (e.includes("ERR_NO_QUERY")) return a("music.err_no_query");
  if (e.includes("ERR_PORT_BUSY")) return a("music.err_port_busy", { port: String((m == null ? void 0 : m.port) ?? "") });
  if (e.includes("ERR_BAD_URI") || e.includes("ERR_BAD_ID")) return a("music.err_bad_uri");
  if (e.includes("ERR_SPOTIFY_STOPPED"))
    return it = !0, a("music.err_spotify_stopped");
  const i = e.match(/ERR_RATE_LIMITED:(\S*)/);
  return i ? a("music.err_rate_limited", { s: i[1] || "?" }) : e.includes("Insufficient client scope") ? a("music.err_scope") : e.includes("No active device") || e.includes("NO_ACTIVE_DEVICE") ? a("music.err_no_device") : e.includes("Premium required") || e.includes("PREMIUM_REQUIRED") ? a("music.err_premium") : e.includes("Restriction violated") ? a("music.err_restricted") : e;
}
function zc(t) {
  const e = [];
  for (const i of t.split(/\r?\n/)) {
    const s = [...i.matchAll(/\[(\d{1,3}):(\d{1,2})(?:[.:](\d{1,3}))?\]/g)];
    if (s.length === 0) continue;
    const n = i.replace(/\[[^\]]*\]/g, "").trim();
    if (n)
      for (const c of s) {
        const d = c[3] ? Number(c[3].padEnd(3, "0")) / 1e3 : 0;
        e.push({ at: Number(c[1]) * 60 + Number(c[2]) + d, text: n });
      }
  }
  return e.sort((i, s) => i.at - s.at), e;
}
function Wc() {
  return `
  <div class="music-root music-curve-root">
    <div class="music-setview">
      <div class="music-set-head">
        <span class="music-set-title">${a("music.tuning_curve")}</span>
      </div>
      <div class="music-set-body">
        <div class="music-tune-plot">
          <!-- 曲线缩放（与调音页同一条交互）：画布默认铺满宽度，点 ＋/－ 按百分比变宽，
               外层容器横向滚动 —— 看细节放大、看全局缩回。 -->
          <div class="music-tune-toolbar">
            <button type="button" class="music-tune-zoom" id="music-tune-zoom-out" title="${l(a("music.tuning_zoom_out"))}" aria-label="${l(a("music.tuning_zoom_out"))}">－</button>
            <span class="music-tune-zoom-label" id="music-tune-zoom-label">100%</span>
            <button type="button" class="music-tune-zoom" id="music-tune-zoom-in" title="${l(a("music.tuning_zoom_in"))}" aria-label="${l(a("music.tuning_zoom_in"))}">＋</button>
          </div>
          <div class="music-tune-scroll" id="music-tune-scroll">
            <canvas id="music-tune-canvas" width="640" height="280"></canvas>
          </div>
          <div class="music-hint" id="music-tune-rate"></div>
        </div>
        <div class="music-tune-probe">
          <button type="button" class="music-btn" id="music-tune-measure">${h.wave}${a("music.tuning_measure")}</button>
          <div class="music-hint" id="music-tune-probe-hint">${l(a("music.tuning_probe_hint"))}</div>
        </div>
        <div class="music-field">
          <label>${a("music.tuning_slots")}</label>
          <div class="music-seg music-slot-list" id="music-tune-slots"></div>
        </div>
      </div>
    </div>
    <div class="music-msg" id="music-msg"></div>
  </div>`;
}
function Hc() {
  return `
  <div class="music-root">
    <!-- ── 默认界面：顶部工具条 + 状态行 + 连接设置 + 歌单列 / 搜索结果 ──
         工具条与「返回」按钮**分属两态**：默认态用底部栏那个「进播放界面」，
         播放态用**标题栏那个 ←**（syncTitlebarClose 把 × 换成它；歌名模块右端
         原来还有一枚「返回歌单」，2026-10-01 已按用户口径删掉）。
         ⚠️ 本段在模板字符串里，注释里一个反引号都不能出现（预检 #15 / #39 ⑩）。 -->
    <div class="music-view" id="music-v-default">
      <!-- 顶部工具条：头像 / 账号 / 搜索（**带下拉预览**）/ 状态 / 设置。
           2026-09-28 第二次改：设备按钮与「展开播放面板」都**下移到最底下那条控制栏**
           （用户要求「严格对齐 Spotify」，Spotify 的工具条上本来就没有这两样）。 -->
      <div class="music-toolbar">
        <button class="music-avatar" id="music-avatar" title="${l(a("music.account_btn"))}"></button>
        <span class="music-acc" id="music-acc"></span>
        <div class="music-search-wrap">
          <input class="music-search" id="music-search" type="search" autocomplete="off" spellcheck="false" placeholder="${l(a("music.search_ph"))}">
          <!-- 下拉预览：绝对定位挂在工具条下方（**不占布局**，否则窗口高会跟着抖） -->
          <div class="music-dd hidden" id="music-search-dd"></div>
        </div>
        <span class="music-status" id="music-status">${a("music.loading")}</span>
        <!-- 「恢复」按钮（2026-10-02）：**只在 429 硬闸拉着时显示**（见 renderResumeBtn）。
             它是用户唯一的出口 —— 宿主一旦收到 429 就停掉所有 Spotify 请求、且不自动重试。
             放工具条而不是底部提示行：提示行在播放态是绝对定位 + pointer-events:none，点不到。
             ⚠️ 本段是 JS 模板字符串，注释里不能出现反引号（预检 #15 / #39 ⑩）。 -->
        <button class="music-ghost-btn hidden" id="music-resume">${a("music.resume")}</button>
        <!-- 这里原来的「本地音乐」文件夹按钮与「调音」推子按钮**已删除**（2026-10-01
             用户口径）：这两个入口收进了**标题栏那枚三段切换**（在线歌单 / 本地音乐 /
             调音，见 renderTitlebarSwitch）。标题栏是悬浮窗独有的，插件若被嵌在主窗口里
             就没有那一条 —— 那种情况下切换器会退到本工具条里（见 placeSwitcher），
             所以这里不给它们留第二份入口，否则「删掉」就变成了「多一份」。
             ⚠️ 本段是 JS 模板字符串，注释里不能出现反引号（预检 #15 / #39 ⑩）。 -->
        <button class="music-ghost-btn music-icon-btn" id="music-setup-toggle" title="${l(a("music.settings"))}">${h.gear}</button>
      </div>

      <div class="music-setup hidden" id="music-setup">
        <div class="music-hint" id="music-setup-hint">${a("music.setup_hint")}</div>
        <!-- 凭据字段默认只在「没有内置 Client ID」或用户主动展开时显示：
             内置值让「登录」变成一步操作，Redirect URI 那一串对普通用户是噪音。 -->
        <button class="music-ghost-btn music-fields-toggle hidden" id="music-fields-toggle"></button>
        <div id="music-setup-fields">
          <div class="music-field">
            <label for="music-client-id">${a("music.client_id")}</label>
            <input id="music-client-id" type="text" spellcheck="false" autocomplete="off" placeholder="${l(a("music.client_id_ph"))}">
          </div>
          <div class="music-field music-field-port">
            <label for="music-port">${a("music.port")}</label>
            <input id="music-port" type="text" inputmode="numeric" autocomplete="off">
          </div>
          <div class="music-field">
            <label>${a("music.redirect")}</label>
            <div class="music-redirect-row">
              <code id="music-redirect"></code>
              <button class="music-ghost-btn music-icon-btn" id="music-copy-redirect" title="${l(a("music.copy"))}">${h.copy}</button>
            </div>
          </div>
          <!-- 本机播放（librespot）的两项设置：路径留空 = 自动探测；代理留空 = 直连。
               两者都不是「必填」，所以各带一行小字说明（见 renderSetup）。 -->
          <div class="music-field">
            <label for="music-librespot">${a("music.local_play")}</label>
            <input id="music-librespot" type="text" spellcheck="false" autocomplete="off" placeholder="librespot.exe">
          </div>
          <div class="music-field">
            <label for="music-librespot-proxy">proxy</label>
            <input id="music-librespot-proxy" type="text" spellcheck="false" autocomplete="off" placeholder="${l(a("music.librespot_proxy_ph"))}">
          </div>
        </div>
        <div class="music-actions">
          <button class="music-btn" id="music-save">${a("music.save")}</button>
          <button class="music-btn music-primary" id="music-connect">${h.link} ${a("music.connect")}</button>
          <button class="music-btn" id="music-disconnect">${h.power} ${a("music.disconnect")}</button>
        </div>
      </div>

      <!-- 主体：**左栏（宽度可拖）+ 分隔条 + 主区**（用户 2026-09-28 的
           「歌单列作为单独的一列可拉动」「中间大的大部分区域作为歌曲列表」）。
           两栏各自内部滚动 —— 窗口是定尺 1280×720，不是靠内容撑出来的。 -->
      <div class="music-body hidden" id="music-body">
        <aside class="music-side" id="music-side">
          <div class="music-side-tabs" id="music-side-tabs">
            <button class="music-tab on" data-act="side-tab" data-tab="playlist">${a("music.playlists")}</button>
            <button class="music-tab" data-act="side-tab" data-tab="album">${a("music.tab_albums")}</button>
            <button class="music-tab" data-act="side-tab" data-tab="artist">${a("music.tab_artists")}</button>
            <button class="music-tab" data-act="side-tab" data-tab="show">${a("music.tab_shows")}</button>
            <!-- 「最常听」栏（2026-10-01 用户第 4 条）。**放在最后**：那四栏是「我的库」，
                 这一栏是「库外的东西」，顺序上按这个分组走。
                 原先与它并列的「新发行」2026-10-02 删除（端点永久 403）。
                 注：本段在模板字符串里，注释里不能出现反引号（预检 #15 / #39 ⑩）。 -->
            <button class="music-tab" data-act="side-tab" data-tab="top">${a("music.tab_top")}</button>
          </div>
          <!-- 「本地音乐」那一页的左栏头（与上面那排 Spotify 页签**互斥显示**）：
               一个标题 + 一个「添加目录」。它跟着 localPage 切，见 renderLocalSide。 -->
          <div class="music-local-head hidden" id="music-local-head">
            <span class="music-local-title">${a("music.local_library")}</span>
            <div class="music-local-head-btns">
              <!-- 正常态三枚（2026-10-01 用户口径）：
                   ＋ = 添加（**目录或播放列表文件**，两个入口合一）
                   ✎ = 修改列表（进编辑态）—— 取代原来那枚「打开播放列表文件」
                   ⟳ = 重扫。
                   图标一律取自 icon-style.md §3，不自己画（见 SVG.edit / SVG.trash）。 -->
              <button class="music-ghost-btn music-icon-btn" id="music-local-add" title="${l(a("music.local_add"))}">${h.plus}</button>
              <button class="music-ghost-btn music-icon-btn" id="music-local-list" title="${l(a("music.local_edit"))}">${h.edit}</button>
              <button class="music-ghost-btn music-icon-btn" id="music-local-scan" title="${l(a("music.local_rescan"))}">${h.refresh}</button>
              <!-- 编辑态两枚（正常态隐藏，切法见 renderLocalHead）：
                   🗑 = 把勾选的行**摘出列表**（暂存，还能反悔）
                   × = 退出并保存（到这一步才真落盘） -->
              <button class="music-ghost-btn music-icon-btn hidden" id="music-local-del" title="${l(a("music.local_del_sel"))}">${h.trash}</button>
              <button class="music-ghost-btn music-icon-btn hidden" id="music-local-editdone" title="${l(a("music.local_edit_done"))}">${h.x}</button>
              <!-- 那个「＋」的二选一浮层（目录 / 播放列表文件）。画法见 renderLocalAddMenu，
                   定位参照是上面那排按钮（.music-local-head-btns 是 relative）。
                   注：本段在**模板字符串**里，注释里一个反引号都不能出现（预检 #15 / #39 ⑩）。 -->
              <div class="music-dd music-local-add-dd hidden" id="music-local-add-dd"></div>
            </div>
          </div>
          <div class="music-side-list" id="music-side-list"></div>
        </aside>
        <div class="music-split" id="music-split" role="separator" aria-orientation="vertical"></div>
        <main class="music-main" id="music-main"></main>
      </div>

      <!-- ── 底部控制栏（2026-09-28，Spotify 复刻）─────────────────────────
           用户要求「在默认面板下方添加 Spotify 那样的播放控制，并把一些按钮也
           移动到下方控制」。三列 grid：左 = 正在播放（点它 = 打开播放面板）、
           中 = 播放键组、右 = 设备 / 音量 / 队列 / 展开。
           栏顶那条 2px 细进度线**绝对定位**（不占高），拖动即可跳转。
           **两个弹层都挂在右端那一簇里、向上弹**：这条栏贴着窗口下沿，
           向下弹会跑到窗口外面（见 styles.css 里那两条覆盖 top 的规则）。
           注意本段是 JS 模板字符串 —— 注释里不能出现反引号（会把字符串截断）。 -->
      <div class="music-nowbar no-drawer hidden" id="music-nowbar">
        <!-- 「另一侧」的抽屉（2026-10-03 用户口径）：两条控制栏同屏只能有一条，
             另一条收进左端这一枚里 —— 点它把另一条换出来、这一条收进去。
             只在「同时出声」开着**且另一侧确实有东西**时出现（见 syncHead）。
             它是 grid 的第一列（auto 宽），隐藏时整列塌成 0 ⇒ 不开抽屉时外观不变。 -->
        <button type="button" class="music-drawer-btn hidden" id="music-b-drawer"></button>
        <div class="music-bp music-bp-timed" id="music-bp" title="${l(a("music.seek"))}">
          <div class="music-bp-fill" id="music-bp-fill"></div>
          <div class="music-progress-tip" id="music-bp-tip">0:00</div>
          <span class="music-btime" id="music-b-time">00:00 / 00:00</span>
        </div>
        <button class="music-bnow" id="music-bnow" title="${l(a("music.open_player"))}">
          <span class="music-bnow-cover" id="music-bnow-cover"></span>
          <span class="music-bnow-main">
            <span class="music-bnow-n" id="music-bnow-n"></span>
            <span class="music-bnow-a" id="music-bnow-a"></span>
          </span>
          <!-- 「进入小窗播放」的位置**收在左边这一块上**（2026-10-03 用户口径）：
               左块本身就是那个按钮，右端那枚重复的展开按钮已删。这个图标只是为了
               让「它可点」这件事看得见（同一条口径也铺到了本地那条栏，见下面）。 -->
          <span class="music-bnow-go">${h.expand}</span>
        </button>
        <div class="music-bctl">
          <button class="music-round-btn music-mode-btn" id="music-b-mode" data-mode="off"></button>
          <button class="music-round-btn" id="music-b-prev" title="${l(a("music.prev"))}">${h.prev}</button>
          <button class="music-round-btn music-play-btn" id="music-b-play" title="${l(a("music.play_pause"))}">${h.play}</button>
          <button class="music-round-btn" id="music-b-next" title="${l(a("music.next"))}">${h.next}</button>
        </div>
        <div class="music-bend">
          <!-- 与本地播放条上那一枚是**同一个状态**（见 dualPlay 的注释）。
               两枚按钮各自长在自己的控制区里，用户在哪条栏上都够得着。 -->
          <button class="music-ghost-btn music-icon-btn music-dual-btn" id="music-dual-btn" title="${l(a("music.dual_play"))}">${h.dual}</button>
          <button class="music-ghost-btn music-icon-btn" id="music-devices-btn" title="${l(a("music.devices"))}">${h.speaker}</button>
          <span class="music-vol-ico">${h.volume}</span>
          <input class="music-vol" id="music-b-vol" type="range" min="0" max="100" step="1" value="50" style="--vol-pct:50%" title="${l(a("music.volume"))}">
          <button class="music-round-btn" id="music-b-queue" title="${l(a("music.queue"))}">${h.list}</button>
          <!-- 右端那枚「进入小窗播放」**已删**（2026-10-03 用户口径）：它与左边
               「正在播放」那一块是同一个动作（都进小窗播放态），右边这枚是重复入口。
               保留左边那块既有的按钮语义，右端这一簇从此只放设备 / 音量 / 队列。 -->
          <div class="music-dd music-dev-dd hidden" id="music-dev-dd"></div>
          <div class="music-dd hidden" id="music-q-dd"></div>
        </div>
      </div>

      <!-- ── 本地文件播放条（2026-10-01）───────────────────────────────
           与上面那条 Spotify 控制栏**不是一条**：那条的对象是远端播放器
           （Web API 的 spotify_* 命令），这条的对象是宿主里那条本机音频流
           （player.rs 的 player_* 命令）。两者的数据源、可用条件（这条不要求
           登录 Spotify）、能做的事都不一样 —— 合成一条会到处长出
           「如果是本地就…」的分支，那正是两套东西被缝在一起的样子。
           只在「本地页 + 有本地会话」时出现，见 renderLocalNowbar。
           注意本段是 JS 模板字符串 —— 注释里不能出现反引号。 -->
      <div class="music-nowbar music-lnowbar no-drawer hidden" id="music-lnowbar">
        <!-- 「另一侧」的抽屉，与上面那条栏同形同义（点击 = 把在线那条换出来）。 -->
        <button type="button" class="music-drawer-btn hidden" id="music-l-drawer"></button>
        <div class="music-bp" id="music-lbp" title="${l(a("music.seek"))}">
          <div class="music-bp-fill" id="music-lbp-fill"></div>
          <div class="music-progress-tip" id="music-lbp-tip">0:00</div>
        </div>
        <!-- 左边这一块**就是**「进入小窗播放」的入口（2026-10-03 用户口径）：
             原来它是纯展示（本地没有小窗可进），2026-10-01 有了本地小窗之后那句话
             就不成立了 ⇒ 与 Spotify 那条栏同形，做成按钮，点它进 #music-v-lplayer。 -->
        <button class="music-bnow music-lnow" id="music-lnow" title="${l(a("music.open_player"))}">
          <span class="music-bnow-cover" id="music-lnow-cover"></span>
          <span class="music-bnow-main">
            <span class="music-bnow-n" id="music-lnow-n"></span>
            <span class="music-bnow-a" id="music-lnow-a"></span>
          </span>
          <span class="music-bnow-go">${h.expand}</span>
        </button>
        <div class="music-bctl">
          <!-- 播放模式（关 / 随机 / 循环列表 / 单曲循环，2026-10-01 用户第 8 条）。
               与 Spotify 那枚 #music-b-mode **不是一件事**：那枚是远端真相，
               这枚是前端自己算的（见 localMode 的注释），所以两枚各记各的状态。
               注：本段在模板字符串里，注释里不能出现反引号（预检 #15 / #39 ⑩）。 -->
          <button class="music-round-btn music-mode-btn" id="music-l-mode" data-mode="off" title="${l(a("music.mode_off"))}"></button>
          <button class="music-round-btn" id="music-l-prev" title="${l(a("music.prev"))}">${h.prev}</button>
          <button class="music-round-btn music-play-btn" id="music-l-play" title="${l(a("music.play_pause"))}">${h.play}</button>
          <button class="music-round-btn" id="music-l-next" title="${l(a("music.next"))}">${h.next}</button>
          <button class="music-round-btn" id="music-l-stop" title="${l(a("music.local_stop"))}">${h.stop}</button>
        </div>
        <div class="music-bend">
          <button class="music-ghost-btn music-icon-btn music-dual-btn" id="music-l-dual-btn" title="${l(a("music.dual_play"))}">${h.dual}</button>
          <span class="music-ltime" id="music-l-time">0:00 / 0:00</span>
          <span class="music-vol-ico">${h.volume}</span>
          <input class="music-vol" id="music-l-vol" type="range" min="0" max="100" step="1" value="80" style="--vol-pct:80%" title="${l(a("music.volume"))}">
          <!-- 右端那枚「进入小窗播放」**已删**（2026-10-03 用户口径）：动作与左边
               「正在播放」那一块重复，两边只留左边一个入口。 -->
        </div>
      </div>
    </div>

    <!-- ── 播放界面：**550×130 的长条**（封面 100 + 右侧列 450）──────────
         右侧列三块的高度加起来正好是长条高：歌名 30 + 歌词 65 + 控制 35 = 130。
         **这几个数都是用户 2026-09-27 给的定尺**：改任何一个都要同步
         styles.css 的 .music-name / .music-lyr / .music-bar，以及宿主
         plugin_window.rs 的 MUSIC_W（见 ai-spec §4.6 与预检 #39 ④）。 -->
    <!-- 注意：本段是 JS 模板字符串，**注释里不能出现反引号**（会把字符串截断）。 -->
    <div class="music-view music-player hidden" id="music-v-player">
      <div class="music-pv-card">
        <div class="music-pv-cover" id="music-pv-cover"></div>
        <div class="music-pv-col">
          <!-- 歌名模块 H30：歌名（亮）+ 歌手·专辑（暗）。 -->
          <div class="music-name">
            <div class="music-name-text">
              <span class="music-title" id="music-pv-title"></span>
              <span class="music-sub" id="music-pv-sub"></span>
            </div>
            <!-- 「返回歌单」那枚**已删除**（2026-10-01 用户口径：小窗播放里那个不是
                 状态栏里的返回按钮要去掉）。退出去仍然走**标题栏那个 ←** ——
                 它在播放态由 syncTitlebarClose 把 × 换成 ←，语义是「停播 + 回默认面板」
                 （见 stopAndBack），也是用户当初指定的出口。所以这里删掉不留缺口。 -->
          </div>

          <!-- 歌词模块 H65：正好两行可见（行高 32）。已过 + 正在 = 亮，未到 = 暗；
               点某一行 = 跳到那一句的进度。 -->
          <div class="music-lyr" id="music-lyr"></div>

          <!-- 控制面板 H35：进度条**叠在本块顶部**（绝对定位 ⇒ 不占高度，总高仍是 130），
               四个播放键在块内居中，右端音量条 80px + 播放列表按钮。 -->
          <div class="music-bar">
            <!-- 时间在控制块**最左端、进度条下方**（用户 2026-09-27 定）。
                 绝对定位 ⇒ 不参与四钮的居中计算。 -->
            <div class="music-time">
              <span id="music-pv-pos">0:00</span><span class="music-time-sep">/</span><span id="music-pv-dur">0:00</span>
            </div>
            <div class="music-progress" id="music-pv-progress" title="${l(a("music.seek"))}">
              <div class="music-progress-fill" id="music-pv-fill"></div>
              <div class="music-progress-dot" id="music-pv-dot"></div>
              <div class="music-progress-tip" id="music-pv-tip">0:00</div>
            </div>
            <div class="music-bar-main">
              <button class="music-round-btn music-mode-btn" id="music-mode" data-mode="off"></button>
              <button class="music-round-btn" id="music-prev" title="${l(a("music.prev"))}">${h.prev}</button>
              <button class="music-round-btn music-play-btn" id="music-play" title="${l(a("music.play_pause"))}">${h.play}</button>
              <button class="music-round-btn" id="music-next" title="${l(a("music.next"))}">${h.next}</button>
            </div>
            <div class="music-bar-end">
              <span class="music-vol-ico">${h.volume}</span>
              <input class="music-vol" id="music-vol" type="range" min="0" max="100" step="1" value="50" style="--vol-pct:50%" title="${l(a("music.volume"))}">
              <button class="music-round-btn" id="music-queue-btn" title="${l(a("music.queue"))}">${h.list}</button>
            </div>
          </div>
        </div>
      </div>

      <!-- 播放列表（队列）挂在长条**下方**、不再与歌词互斥：长条是定尺 130，
           塞不进队列。开着时窗口按内容长高（applyResize 实测贴合）。 -->
      <div class="music-q-wrap hidden" id="music-q-wrap">
        <div class="music-sec-head">
          <span class="music-sec-title">${a("music.queue")}</span>
          <span class="music-sec-note">${a("music.queue_hint")}</span>
        </div>
        <div class="music-q" id="music-q"></div>
      </div>
    </div>

    <!-- ── 本地小窗：**本地文件播放也有的那条长条**（2026-10-01 用户口径
         「在本地文件播放的情况下也添加小窗模式」）────────────────────────
         与上一个视图**共用同一套外壳类**（music-player / music-pv-card / music-pv-cover /
         music-name / music-bar / music-bp…）⇒ 尺寸（550×130）、圆角、配色、
         进度条的细线与命中区，一行业务 CSS 都不用重写。
         唯一的差别在**中间那一块**：远端那条长条放的是歌词（H65，见 .music-lyr），
         本地文件没有歌词 —— 那一格换成**大号进度线 + 时间**（见 .music-lp-mid）。
         三块的高度仍是 30 + 65 + 35 = 130，与 MUSIC_W_BAR / applyResize 对齐。
         数据与动作**都只有一份**：状态来自 localPlayer，按钮走的是本地播放那几条
         既有函数（见 attachMusicListeners 里那几条绑定）。
         注意本段是 JS 模板字符串 —— 注释里不能出现反引号（预检 #15 / #39 ⑩）。 -->
    <div class="music-view music-player hidden" id="music-v-lplayer">
      <div class="music-pv-card">
        <div class="music-pv-cover" id="music-lp-cover"></div>
        <div class="music-pv-col">
          <div class="music-name">
            <div class="music-name-text">
              <span class="music-title" id="music-lp-title"></span>
              <span class="music-sub" id="music-lp-sub"></span>
            </div>
          </div>
          <div class="music-lp-mid">
            <div class="music-bp music-lp-seek" id="music-lp-progress" title="${l(a("music.seek"))}">
              <div class="music-bp-fill" id="music-lp-fill"></div>
              <div class="music-progress-tip" id="music-lp-tip">0:00</div>
            </div>
            <div class="music-lp-time" id="music-lp-time">0:00 / 0:00</div>
          </div>
          <div class="music-bar">
            <div class="music-bar-main">
              <button class="music-round-btn music-mode-btn" id="music-lp-mode" data-mode="off" title="${l(a("music.mode_off"))}"></button>
              <button class="music-round-btn" id="music-lp-prev" title="${l(a("music.prev"))}">${h.prev}</button>
              <button class="music-round-btn music-play-btn" id="music-lp-play" title="${l(a("music.play_pause"))}">${h.play}</button>
              <button class="music-round-btn" id="music-lp-next" title="${l(a("music.next"))}">${h.next}</button>
              <button class="music-round-btn" id="music-lp-stop" title="${l(a("music.local_stop"))}">${h.stop}</button>
            </div>
            <div class="music-bar-end">
              <span class="music-vol-ico">${h.volume}</span>
              <input class="music-vol" id="music-lp-vol" type="range" min="0" max="100" step="1" value="80" style="--vol-pct:80%" title="${l(a("music.volume"))}">
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- ── 设置页：**整屏**（2026-10-01 用户要求「设置图标进到一个新的设置页面」）──
         与 #music-v-player 同为整屏视图，由 mode = "settings" 切（见 renderMode）。
         职责划分是硬的：**这里只放「偏好」，「连接」仍归头像点开的 #music-setup**
         （Client ID / 端口 / 回调 / librespot 路径与代理），**「调音」也有自己的一页**
         （#music-v-tuning，2026-10-01 用户要求搬出去的）。理由与那张卡片里的
         「保存」按钮直接相关 —— 一个卡片里塞两套保存语义必然出岔子，而现在这几页
         各有各的保存。
         ⚠️ 本段是 JS 模板字符串 —— 注释里**不许出现反引号**，连「引用一个标识符」
         那种写法都不行：它会把模板字符串提前截断（预检 #15 / #39 ⑩，本轮又踩了一次）。 -->
    <div class="music-view music-setview hidden" id="music-v-settings">
      <div class="music-set-head">
        <button class="music-ghost-btn music-icon-btn" id="music-set-back" title="${l(a("music.settings_back"))}">${h.back}</button>
        <span class="music-set-title">${a("music.settings")}</span>
      </div>
      <div class="music-set-body">
        <!-- 串流质量：三档互斥按钮。**不用原生 select 元素** —— WebView2 透明窗口里
             它不渲染弹出层（code-rules §5.2）。三档值只允许 96/160/320（宿主侧
             LIBRESPOT_BITRATES，抄自 librespot --help 的原文）。
             ⚠️ 模板字符串 ⇒ 本段注释里也不许出现反引号（预检 #39 ⑩）。 -->
        <div class="music-field">
          <label>${a("music.quality")}</label>
          <div class="music-seg" id="music-quality">
            ${[96, 160, 320].map((t) => `<button type="button" class="music-seg-btn" data-q="${t}">${t}k</button>`).join("")}
          </div>
          <div class="music-hint">${l(a("music.quality_hint"))}</div>
          <div class="music-hint">${l(a("music.quality_local_note"))}</div>
        </div>
        <!-- 调音页的入口（2026-10-03 用户要求「设置按钮入口」）。**不在这页里编辑调音**：
             调音是**按下即生效、即落盘**的实时功能，而这页那套是「攒着等保存」
             （音质要重启 librespot 才生效）—— 两种保存语义混在一张卡片里必然出岔子。
             所以这里只给一颗**进去的按钮**（切到 #music-v-tuning 那一页）。 -->
        <div class="music-field">
          <label>${a("music.tuning")}</label>
          <div class="music-actions">
            <button type="button" class="music-btn" id="music-set-tuning">${a("music.tuning_open")}</button>
          </div>
        </div>
        <div class="music-actions">
          <button class="music-btn" id="music-set-save">${a("music.save")}</button>
        </div>
      </div>
    </div>

    <!-- ── 调音页：**自己一页**（2026-10-01 用户口径）────────────────────
         用户明确「调音插件的界面不能放置到设置界面里，要新建一个界面专门用来显示调音」
         —— 所以它在 2026-10-01 从设置页那一块**整段搬过来**（上一版是「调音分区」）。
         入口只有一个：标题栏那枚三段切换的第三段（见 renderTitlebarSwitch）——
         **页内那枚返回按钮 2026-10-02 按用户要求取掉了**：切换器本身就是「回得去」的
         那一条路（点回「在线歌单 / 本地音乐」即离页），再摆一个返回是重复入口。
         版面顺序（2026-10-03 用户口径，本轮重排）：三栏骨架 ——
         左 = 工具条（保存 / 导入 / 导出）+ 我的预设；中 = 三条全局水平滑块 +
         **频段柱**（滤波器与均衡器已合并）；右 = 通道槽 + 全局效果器（延迟 / 复制 / 卷积）。
         四条纪律：① 控件**按下就生效、也当场落盘**（与设置页「音质」那两条攒着
         等保存完全不同：音质要重启 librespot 才生效，调音是实时的）；
         ② 滤波器类型的**名单来自宿主**（tuning.kinds，与引擎 Kind::ALL 同源）、
         用户预设名单也来自宿主（tuning.user_presets）—— 前端不维护第二份名单；
         ③ **两条播放链都生效**（2026-10-04 起）：本地文件走宿主 player.rs，在线歌单走
         librespot 的 -B pipe 输出 → 宿主的 live_audio.rs，两条套的是**同一个**
         TuningSource（共享同一份配置与版本号 ⇒ 在哪边调都立刻生效）。唯一例外是
         **首次授权那一次**：那一次不能带 -B pipe（OAuth 会把 URL 打到 stdout、污染
         PCM，见 librespot_args 的三条注释），重启一次 librespot 即接入；
         ④ 频段柱里的控件**全部动态渲染**（见 renderTuningFilters），这里只留容器。
         ⚠️ 本段是 JS 模板字符串 ⇒ 注释里不许出现反引号（预检 #15 / #39 ⑩）。 -->
    <div class="music-view music-setview hidden" id="music-v-tuning">
      <div class="music-set-head">
        <span class="music-set-title">${a("music.tuning")}</span>
        <!-- 频响曲线**不在这页里**（2026-10-03 用户口径「参照 Peace」）：它搬进一扇独立小窗，
             这页只留一颗按钮当入口。理由：曲线是「一边看一边调」的东西，占满这页会把
             推子与数值表挤没；而这一页要按 Peace 的三栏骨架排。 -->
        <button type="button" class="music-btn music-curve-open" id="music-curve-open">${h.wave}${a("music.tuning_curve_open")}</button>
        <button type="button" class="music-switch" id="music-tuning-on" role="switch" aria-checked="false" title="${l(a("music.tuning"))}">
          <span class="music-switch-knob"></span>
        </button>
      </div>
      <!-- 三栏骨架（2026-10-03，参照 Peace 主窗 → 同日按用户第 7/8 条重排）：
             左 = 工具条 + 我的预设、中 = 三条全局滑块 + 频段柱、右 = 扬声器声道 + 全局效果器。
             **接线函数的 id 一律沿用**（music-tuning-user-presets / music-tune-slots /
             music-tuning-filters / music-preamp-range …）：这一页的 render 与委托全按 id 找节点，
             重排只动 HTML 的位置，逻辑一行都不用改。
             ⚠️ 本段是 JS 模板字符串 ⇒ 注释里不许出现反引号（预检 #15 / #39 ⑩）。 -->
      <div class="music-set-body music-tune-cols">
        <!-- ── 左栏：预设（2026-10-03 用户口径：工具条移到最上、内置 5 档整批删掉）── -->
        <div class="music-tune-col music-tune-col-presets">
          <div class="music-actions">
            <button type="button" class="music-btn" id="music-preset-save">${l(a("music.tuning_preset_save"))}</button>
            <button type="button" class="music-btn" id="music-preset-import">${l(a("music.tuning_preset_import"))}</button>
            <button type="button" class="music-btn" id="music-preset-export">${l(a("music.tuning_preset_export"))}</button>
          </div>
          <div class="music-preset-list" id="music-tuning-user-presets"></div>
          <div class="music-preset-edit hidden" id="music-tuning-preset-edit">
            <div class="music-hint" id="music-preset-edit-hint"></div>
            <input type="text" id="music-preset-name" autocomplete="off" spellcheck="false" />
            <button type="button" class="music-btn" id="music-preset-ok"></button>
            <button type="button" class="music-btn" id="music-preset-cancel">${l(a("music.tuning_preset_cancel"))}</button>
          </div>
          <!-- A-B 盲测（2026-10-06）：两个快照槽 + 随机映射 + 揭晓。
               快照 = **整条链**（宿主落 config	uningab-a.json / ab-b.json）；
               切换走 player_tuning_ab_apply（先校验→落盘→改内存→版本号+1 ⇒ 不重播）。
               盲测时两个按钮只显示 1 / 2，映射由 tuneAbSlots 决定，点「揭晓」才告诉用户。 -->
          <div class="music-tune-ab" id="music-tune-ab">
            <div class="music-sub-label">${l(a("music.tuning_ab_title"))}</div>
            <div class="music-actions">
              <button type="button" class="music-btn" id="music-ab-save-a">${l(a("music.tuning_ab_save_a"))}</button>
              <button type="button" class="music-btn" id="music-ab-save-b">${l(a("music.tuning_ab_save_b"))}</button>
            </div>
            <div class="music-actions" id="music-ab-play">
              <button type="button" class="music-btn" id="music-ab-pos1" data-pos="1">A</button>
              <button type="button" class="music-btn" id="music-ab-pos2" data-pos="2">B</button>
              <button type="button" class="music-btn" id="music-ab-blind">${l(a("music.tuning_ab_blind"))}</button>
              <button type="button" class="music-btn hidden" id="music-ab-reveal">${l(a("music.tuning_ab_reveal"))}</button>
            </div>
            <div class="music-hint" id="music-ab-hint"></div>
          </div>
        </div>
        <!-- ── 中栏：三条全局水平滑块 + 频段柱（2026-10-03 用户口径）────────────
             三条滑块 = 总增益 / 低音增益 / 高音增益（Peace 顶部那种「左标签 + 滑块 + 右数值框」）；
             频段柱 = **滤波器与均衡器合并**后的主体：频率可编辑 / 竖拉条 / 大号增益 / Q / 类型按钮。
             延迟属于全局效果器，已挪到右栏（与声道复制 / 卷积同处）。 -->
        <div class="music-tune-col music-tune-col-eq">
          <div class="music-tune-sliderrow">
            <label>${a("music.tuning_preamp")}</label>
            <input type="range" class="music-tune-hslider" id="music-preamp-range" min="-24" max="24" step="0.5" aria-label="${l(a("music.tuning_preamp"))}" />
            <input type="text" class="music-tune-num" id="music-tune-preamp" inputmode="decimal" autocomplete="off" spellcheck="false" aria-label="${l(a("music.tuning_preamp"))}" />
          </div>
          <div class="music-tune-sliderrow">
            <label>${a("music.tuning_bass")}</label>
            <input type="range" class="music-tune-hslider" id="music-bass-range" min="-24" max="24" step="0.5" aria-label="${l(a("music.tuning_bass"))}" />
            <input type="text" class="music-tune-num" id="music-tune-bass" inputmode="decimal" autocomplete="off" spellcheck="false" aria-label="${l(a("music.tuning_bass"))}" />
          </div>
          <div class="music-tune-sliderrow">
            <label>${a("music.tuning_treble")}</label>
            <input type="range" class="music-tune-hslider" id="music-treble-range" min="-24" max="24" step="0.5" aria-label="${l(a("music.tuning_treble"))}" />
            <input type="text" class="music-tune-num" id="music-tune-treble" inputmode="decimal" autocomplete="off" spellcheck="false" aria-label="${l(a("music.tuning_treble"))}" />
          </div>
          <!-- 频段柱：作用域是**右栏选中的那个通道槽**（全局槽 ↔ 引擎的 filters）。
               左侧那列图例（2026-10-06 用户要求）把「频率 / 增益 / 质量」各标一次，并与柱内
               三行**逐行对齐** —— 三个框都只有数字，少了它用户不知道哪个是哪个。行高与柱子
               共用 --tf-* 那四个变量（见 styles.css 的 .music-tune-filterwrap），改一处两边同步。
               第二格是空占位，对齐的是那根竖拉条（增益那一行同时有拉条与大号读数，只标一次）。 -->
          <div class="music-tune-filterwrap">
            <div class="music-tune-legend" aria-hidden="true">
              <span class="l-freq">${l(a("music.tuning_freq"))}</span>
              <span class="l-slider"></span>
              <span class="l-gain">${l(a("music.tuning_gain"))}</span>
              <span class="l-q">${l(a("music.tuning_q"))}</span>
            </div>
            <div class="music-tune-filters" id="music-tuning-filters"></div>
          </div>
          <div class="music-actions">
            <button type="button" class="music-btn" id="music-tune-add">${h.plus}${a("music.tuning_add")}</button>
          </div>
        </div>
        <!-- ── 右栏：通道槽 + 全局效果器（延迟 / 声道复制 / 卷积）──────────────
             三样效果器都是**顶层字段** ⇒ 只在「全局」通道槽里显示（画在通道槽里会看起来像
             只作用于那条声道）。槽本身不落盘 —— 它只是「中栏那排频段柱在编辑哪一份草稿」
             这个视图状态；改动落在草稿里，提交时整排一起发（见 tuneIfElsePayload）。 -->
        <div class="music-tune-col music-tune-col-side">
          <div class="music-sub-label">${a("music.tuning_slots")}</div>
          <div class="music-seg music-slot-list music-slot-col" id="music-tune-slots"></div>
          <div class="music-field hidden" id="music-tune-delay">
            <div class="music-tune-sliderrow">
              <label>${a("music.tuning_delay")}</label>
              <input type="range" class="music-tune-hslider" id="music-delay-range" min="0" max="5000" step="1" aria-label="${l(a("music.tuning_delay"))}" />
              <input type="text" class="music-tune-num" id="music-delay-num" inputmode="decimal" autocomplete="off" spellcheck="false" aria-label="${l(a("music.tuning_delay"))}" />
            </div>
          </div>
          <div class="music-field hidden" id="music-tune-copy">
            <div class="music-copy-list" id="music-copy-list"></div>
            <div class="music-actions">
              <button type="button" class="music-btn" id="music-copy-add">${h.plus}${a("music.tuning_copy_add")}</button>
            </div>
          </div>
          <div class="music-field hidden" id="music-tune-conv">
            <label>${a("music.tuning_conv")}</label>
            <div class="music-hint" id="music-conv-path"></div>
            <div class="music-actions">
              <button type="button" class="music-btn" id="music-conv-pick">${l(a("music.tuning_conv_pick"))}</button>
              <button type="button" class="music-btn hidden" id="music-conv-clear">${l(a("music.tuning_conv_clear"))}</button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="music-msg" id="music-msg"></div>
  </div>`;
}
function x(t, e) {
  t && t.textContent !== e && (t.textContent = e);
}
function I(t, e) {
  if (!t || t.innerHTML === e) return;
  const i = document.createElement("template");
  i.innerHTML = e, t.innerHTML !== i.innerHTML && (t.innerHTML = e);
}
function A(t, e) {
  t == null || t.classList.toggle("hidden", !e);
}
function $e(t, e, i) {
  t && t.getAttribute(e) !== i && t.setAttribute(e, i);
}
function At(t, e) {
  if (!t) return;
  const i = Math.max(0, Math.min(100, Math.round(e)));
  t.style.setProperty("--vol-pct", `${i}%`);
}
function Fc(t) {
  const e = t.querySelector("#music-msg");
  if (!e) return;
  const i = e.textContent ?? "";
  if (i !== Ri) {
    Ri = i, Ni = Date.now();
    return;
  }
  i && Date.now() - Ni >= Sc && (e.textContent = "", Ri = "", Ni = 0);
}
function ie(t) {
  const e = Zi();
  A(t.querySelector("#music-v-default"), R === "default"), A(t.querySelector("#music-v-player"), R === "player"), A(t.querySelector("#music-v-lplayer"), R === "lplayer"), A(t.querySelector("#music-v-settings"), R === "settings");
  const i = R === "tuning";
  A(t.querySelector("#music-v-tuning"), i), i ? (nt(t), vl(t)) : Cs(), t.classList.toggle("music-player-on", e), jc(e), Uc(), pi(t), Jc(), R === "player" ? (lt = -1, Ji(t), is(t)) : R === "lplayer" ? Wa(t) : R === "default" && (A(t.querySelector("#music-body"), !!(m != null && m.connected) || ne), gt(t), we(t), Be(t), jt(t)), vi(t);
}
function jc(t) {
  const e = !t;
  document.getElementById("plugin-titlebar") && ws !== e && (ws = e, u("plugin_window_set_resizable", { resizable: e }).catch(() => {
  }));
}
function Uc() {
  const t = document.getElementById("plugin-close");
  if (!t) return;
  ui || (ui = t.innerHTML);
  const e = Zi() ? "back" : "close";
  if (t.dataset.mode === e) return;
  t.dataset.mode = e, t.innerHTML = e === "back" ? h.back : ui;
  const i = e === "back" ? a("music.back") : "Close";
  t.title = i, t.setAttribute("aria-label", i);
}
function Vc() {
  const t = document.getElementById("plugin-close");
  !t || !ui || t.dataset.mode !== "back" || (t.innerHTML = ui, t.title = "Close", t.setAttribute("aria-label", "Close"), t.dataset.mode = "close");
}
function Gc() {
  return R === "tuning" ? "tuning" : R !== "default" ? "" : ne ? "local" : "online";
}
function Yc(t) {
  const e = document.getElementById("music-tb-switch");
  if (e) return e;
  const i = document.createElement("div");
  i.id = "music-tb-switch", i.className = "music-tb-switch", i.setAttribute("role", "tablist"), i.setAttribute("data-tauri-drag-region", "");
  const s = [
    ["online", a("music.tb_online")],
    ["local", a("music.tb_local")],
    ["tuning", a("music.tb_tuning")]
  ];
  i.innerHTML = s.map(([d, b]) => `<button type="button" class="music-tb-seg" role="tab" data-seg="${d}" title="${l(b)}">${l(b)}</button>`).join("");
  const n = document.getElementById("plugin-titlebar"), c = document.getElementById("plugin-title");
  if (n && c)
    n.insertBefore(i, c.nextSibling);
  else {
    const d = t.querySelector("#music-setup-toggle"), b = t.querySelector(".music-toolbar");
    if (!b) return null;
    b.insertBefore(i, d);
  }
  return i;
}
function Jc() {
  const t = document.getElementById("music-tb-switch");
  if (!t) return;
  const e = Gc();
  for (const i of t.querySelectorAll(".music-tb-seg"))
    $e(i, "aria-pressed", String(i.dataset.seg === e));
}
function Qc() {
  var t;
  (t = document.getElementById("music-tb-switch")) == null || t.remove();
}
async function Xc(t) {
  try {
    await u("spotify_control", { action: "pause" });
  } catch (e) {
    $(t, C(e));
  }
  R = "default", ie(t);
}
function Ca(t) {
  const e = t.querySelector("#music-setup-toggle"), i = t.querySelector(".music-toolbar");
  if (!e || !i) return;
  const s = t.querySelector(".music-local-head-row"), n = ne && s ? s : i;
  e.parentElement !== n && n.appendChild(e);
}
function Vn(t, e, i, s) {
  const n = t.querySelector(e);
  n && n.classList.toggle("no-drawer", !s), A(t.querySelector(i), s);
}
function Gn(t, e, i) {
  if (!t) return;
  const s = a(e);
  t.dataset.label !== s && (t.dataset.label = s, t.innerHTML = `${h.expand}<span>${l(s)}</span>`), $e(t, "title", a(i));
}
function pi(t) {
  const e = R === "player", i = !!(m != null && m.connected);
  A(t.querySelector("#music-nowbar"), !e && i && !xa());
  const s = Ee && i && K >= 0;
  Vn(t, "#music-nowbar", "#music-b-drawer", s), Vn(t, "#music-lnowbar", "#music-l-drawer", s), Gn(t.querySelector("#music-b-drawer"), "music.drawer_local", "music.tb_local"), Gn(t.querySelector("#music-l-drawer"), "music.drawer_online", "music.tb_online");
  for (const n of [".music-search-wrap", "#music-avatar", "#music-acc", "#music-status"])
    A(t.querySelector(n), !ne);
  Ca(t), t.querySelectorAll(".music-dual-btn").forEach((n) => n.classList.toggle("on", Ee));
}
function Lt(t, e) {
  const i = t.querySelector("#music-status");
  m != null && m.client_id ? m.connected ? v ? v.active ? v.playing ? x(i, a("music.status_playing")) : x(i, a("music.status_paused")) : x(i, a("music.status_no_device")) : x(i, a("music.status_connecting")) : x(i, a("music.status_disconnected")) : x(i, a("music.status_unconfigured"));
  const s = t.querySelector("#music-avatar");
  if (s) {
    const c = m != null && m.connected && m.avatar || "";
    I(s, c ? `<img src="${l(c)}" alt="">` : "");
  }
  x(t.querySelector("#music-acc"), m != null && m.connected && m.display_name || "");
  const n = t.querySelector("#music-devices-btn");
  n && ($e(n, "title", `${a("music.devices")}：${(v == null ? void 0 : v.device) || a("music.device_none")}`), n.classList.toggle("warn", !!(m != null && m.connected) && !(v != null && v.active)));
}
function $t(t) {
  A(t.querySelector("#music-setup"), !(m != null && m.connected) || Mi), A(t.querySelector("#music-body"), !!(m != null && m.connected) || ne), gt(t), we(t), m != null && m.connected && (Ga(t, re), Ja(t));
  const e = Ti ?? !(m != null && m.builtin);
  A(t.querySelector("#music-setup-fields"), e), A(t.querySelector("#music-save"), e);
  const i = t.querySelector("#music-fields-toggle");
  A(i, !!(m != null && m.builtin)), x(i, a(e ? "music.hide_fields" : "music.use_own_client_id")), x(
    t.querySelector("#music-setup-hint"),
    m != null && m.builtin ? a("music.setup_builtin") : a("music.setup_hint")
  );
  const s = t.querySelector("#music-client-id"), n = t.querySelector("#music-port"), c = t.querySelector("#music-librespot"), d = t.querySelector("#music-librespot-proxy");
  s && document.activeElement !== s && (s.value = (m == null ? void 0 : m.client_id) ?? ""), n && document.activeElement !== n && (n.value = String((m == null ? void 0 : m.port) ?? 8899)), c && document.activeElement !== c && (c.value = (m == null ? void 0 : m.librespot_path) ?? ""), d && document.activeElement !== d && (d.value = (m == null ? void 0 : m.librespot_proxy) ?? "");
  const b = Kt ?? (m == null ? void 0 : m.librespot_bitrate) ?? 320;
  for (const g of t.querySelectorAll("#music-quality .music-seg-btn"))
    $e(g, "aria-pressed", String(Number(g.dataset.q) === b));
  x(t.querySelector("#music-redirect"), (m == null ? void 0 : m.redirect_uri) ?? "");
}
function Yn(t) {
  const e = a(`music.tk_${t}`);
  return e.startsWith("music.") ? t : e;
}
function Jn(t) {
  return Number.isFinite(t) ? Math.min(2e4, Math.max(20, t)) : 1e3;
}
function Qn(t) {
  return Number.isFinite(t) ? Math.min(24, Math.max(-24, t)) : 0;
}
function U(t, e = 3) {
  return t === void 0 || !Number.isFinite(t) ? "" : String(Math.round(t * 10 ** e) / 10 ** e);
}
function ms(t, e) {
  return e === "freq_hz" ? U(t.freq_hz, 1) : e === "gain_db" ? U(t.gain_db ?? 0, 1) : e === "q" ? U(t.q ?? 0.707, 3) : "";
}
async function nt(t) {
  let e;
  try {
    e = await u("player_tuning_get");
  } catch (i) {
    $(t, C(i));
    return;
  }
  JSON.stringify(e) !== JSON.stringify(f) && (f = e, Yt(), oe = -1), await sl(), ae(t);
}
function Aa(t) {
  const e = t.querySelector("#music-tune-measure");
  e && e.disabled !== et && (e.disabled = et), $e(e, "aria-busy", String(et));
  const i = t.querySelector("#music-tune-probe-hint");
  if (!i) return;
  if (et) {
    x(i, a("music.tuning_measuring"));
    return;
  }
  const s = Ge;
  if (!s) {
    x(i, a("music.tuning_probe_hint"));
    return;
  }
  const n = (b, g) => {
    let L = 0, _ = 0;
    for (let T = 0; T < b.length && T < g.length; T++)
      L += b[T] - g[T], _ += 1;
    return _ > 0 ? L / _ : 0;
  }, c = n(s.chain_db ?? [], s.ref_db), d = n(s.db, s.chain_db ?? []);
  x(
    i,
    a("music.tuning_probe_result", {
      cov: String(Math.round(s.coverage * 100)),
      dev: `${c >= 0 ? "+" : ""}${c.toFixed(1)}`,
      sys: `${d >= 0 ? "+" : ""}${d.toFixed(1)}`,
      ms: String(s.elapsed_ms)
    })
  );
}
function Kc(t) {
  if (!f) return;
  const e = f.user_presets ?? [], i = t.querySelector("#music-tuning-user-presets");
  i && I(
    i,
    e.map((d) => {
      const b = f.preset === d;
      return `<div class="music-preset-user" data-preset="${l(d)}" aria-pressed="${b}"><button type="button" class="music-preset-item" data-act="use">${l(d)}</button><button type="button" class="music-preset-icon" data-act="rename" title="${l(a("music.tuning_preset_rename"))}">✎</button><button type="button" class="music-preset-icon" data-act="delete" title="${l(a("music.tuning_preset_delete"))}">✕</button></div>`;
    }).join("")
  );
  const s = Ve;
  if (A(t.querySelector("#music-tuning-preset-edit"), s !== null), !s) return;
  const n = s.mode === "delete";
  x(
    t.querySelector("#music-preset-edit-hint"),
    s.mode === "save" ? a("music.tuning_preset_save_prompt") : s.mode === "rename" ? a("music.tuning_preset_rename_prompt", { name: s.from }) : a("music.tuning_preset_delete_confirm", { name: s.name })
  );
  const c = t.querySelector("#music-preset-name");
  A(c, !n), c && c !== document.activeElement && c.value !== s.name && (c.value = s.name), x(
    t.querySelector("#music-preset-ok"),
    s.mode === "save" ? s.overwrite ? a("music.tuning_preset_overwrite") : a("music.tuning_preset_ok") : s.mode === "rename" ? a("music.tuning_preset_rename") : a("music.tuning_preset_delete")
  );
}
function Zc(t) {
  return t === 0 ? a("music.tuning_slot_global") : _a[t - 1] ?? `#${t}`;
}
function el(t) {
  const e = t.querySelector("#music-tune-slots");
  e && I(
    e,
    ht.map((i, s) => {
      const n = Zc(s), c = i.filter((d) => d.on).length;
      return `<button type="button" class="music-seg-btn music-slot-btn" data-slot="${s}" aria-pressed="${s === Re}" title="${l(n)}">${l(n)}<em>${c}</em></button>`;
    }).join("")
  );
}
function tl(t, e) {
  e === Re || e < 0 || e >= ht.length || (Re = e, J = ht[e], oe = -1, ae(t));
}
function Xn(t) {
  return _a[t] ?? "#" + (t + 1);
}
function Ia(t) {
  const e = t.querySelector("#music-copy-list");
  if (!e) return;
  const i = Math.max(1, (f == null ? void 0 : f.channels) || 2);
  I(
    e,
    ft.map((s, n) => {
      const c = (G == null ? void 0 : G.row) === n ? G.side : null, d = (g) => c === g ? `<div class="music-tune-menu">${Array.from({ length: i }, (L, _) => {
        const T = (g === "from" ? s.from : s.to) === _;
        return `<button type="button" class="music-seg-btn" data-act="pick" data-i="${n}" data-side="${g}" data-ch="${_}" aria-pressed="${T}">${l(Xn(_))}</button>`;
      }).join("")}</div>` : "", b = (g, L) => `<button type="button" class="music-tune-kind" data-act="menu" data-i="${n}" data-side="${g}" aria-expanded="${c === g}"><span>${l(Xn(L))}</span>${h.chevron}</button>`;
      return `<div class="music-copy-row" data-i="${n}">
        ${b("from", s.from)}<span class="music-copy-arrow">→</span>${b("to", s.to)}
        <button type="button" class="music-tune-del" data-act="del" data-i="${n}" title="${l(a("music.tuning_del"))}">${h.trash}</button>
        ${d("from")}${d("to")}
      </div>`;
    }).join("")
  ), A(t.querySelector("#music-copy-empty"), ft.length === 0);
}
function il(t) {
  const e = Re === 0;
  if (A(t.querySelector("#music-tune-delay"), e), A(t.querySelector("#music-tune-copy"), e), A(t.querySelector("#music-tune-conv"), e), !e || Pt) return;
  const i = t.querySelector("#music-delay-num");
  i && document.activeElement !== i && i.value !== U(be, 1) && (i.value = U(be, 1));
  const s = t.querySelector("#music-delay-range");
  s && s.value !== String(be) && (s.value = String(be)), Ia(t), x(t.querySelector("#music-conv-path"), Nt ?? a("music.tuning_conv_none")), A(t.querySelector("#music-conv-clear"), Nt !== null);
}
function ps(t, e, i, s) {
  const n = t.querySelector(e);
  n && n.value !== U(s, 1) && (n.value = U(s, 1));
  const c = t.querySelector(i);
  c && document.activeElement !== c && c.value !== U(s, 1) && (c.value = U(s, 1));
}
async function sl() {
  try {
    Te = await u("player_tuning_ab_state");
  } catch {
    Te = { a: !1, b: !1 };
  }
}
function ki(t) {
  var s;
  for (const n of [1, 2]) {
    const c = t.querySelector(`#music-ab-pos${n}`);
    if (!c) continue;
    const d = Bt[n - 1], b = d === "a" ? Te.a : Te.b;
    c.dataset.ab = d, c.textContent = tt ? String(n) : d.toUpperCase(), c.disabled = !b, c.classList.toggle("active", b && Ts === d);
  }
  const e = t.querySelector("#music-ab-blind");
  e && (e.classList.toggle("active", tt), e.disabled = !(Te.a && Te.b)), (s = t.querySelector("#music-ab-reveal")) == null || s.classList.toggle("hidden", !tt || ai);
  const i = t.querySelector("#music-ab-hint");
  i && (i.textContent = nl());
}
function nl() {
  return !Te.a && !Te.b ? a("music.tuning_ab_empty") : tt ? ai ? a("music.tuning_ab_revealed", {
    one: Bt[0].toUpperCase(),
    two: Bt[1].toUpperCase()
  }) : a("music.tuning_ab_blind_hint") : a("music.tuning_ab_hint", {
    a: Te.a ? "A" : "—",
    b: Te.b ? "B" : "—"
  });
}
async function Kn(t, e) {
  try {
    Te = await u("player_tuning_ab_save", { slot: e }), $(t, a(e === "a" ? "music.tuning_ab_saved_a" : "music.tuning_ab_saved_b"));
  } catch (i) {
    $(t, C(i));
  }
  ki(t);
}
async function al(t, e) {
  const i = Bt[e - 1];
  if (i) {
    try {
      await u("player_tuning_ab_apply", { slot: i }), Ts = i, await nt(t);
    } catch (s) {
      $(t, C(s));
    }
    ki(t);
  }
}
function ae(t) {
  f && ($e(t.querySelector("#music-tuning-on"), "aria-checked", String(f.enabled)), Aa(t), Kc(t), ki(t), ps(t, "#music-preamp-range", "#music-tune-preamp", bi), ps(t, "#music-bass-range", "#music-tune-bass", hi), ps(t, "#music-treble-range", "#music-tune-treble", yi), el(t), Da(t), il(t), Na(t), x(
    t.querySelector("#music-tune-rate"),
    a("music.tuning_rate", { rate: U(f.response.sample_rate / 1e3, 1) })
  ));
}
function cl(t, e, i, s) {
  const n = i.find((P) => P.name === t.kind), c = n ? n.gain : t.gain_db !== void 0, d = n ? n.order !== 1 : t.q !== void 0, b = t.gain_db ?? 0, g = `<input type="text" class="music-tune-num music-band-freq" data-f="freq_hz" inputmode="decimal" autocomplete="off" spellcheck="false" value="${l(U(t.freq_hz, 1))}" aria-label="${l(a("music.tuning_freq"))}" />`, L = c ? `<input type="range" class="music-tune-vslider" data-f="gain_db" min="-24" max="24" step="0.5" value="${l(U(b, 1))}" aria-label="${l(a("music.tuning_gain"))}" />` : '<div class="music-tune-vslider-na"></div>', _ = c ? `<input type="text" class="music-tune-num music-band-gain" data-f="gain_db" inputmode="decimal" autocomplete="off" spellcheck="false" value="${l(U(b, 1))}" aria-label="${l(a("music.tuning_gain"))}" />` : '<span class="music-band-gain na">—</span>', T = d ? `<input type="text" class="music-tune-num music-band-q" data-f="q" inputmode="decimal" autocomplete="off" spellcheck="false" value="${l(U(t.q ?? 0.707, 3))}" aria-label="${l(a("music.tuning_q"))}" />` : "", q = s ? `<div class="music-tune-menu">${i.map(
    (P) => `<button type="button" class="music-seg-btn" data-act="pick" data-kind="${l(P.name)}" aria-pressed="${P.name === t.kind}">${l(Yn(P.name))}</button>`
  ).join("")}</div>` : "";
  return `<div class="music-tune-band music-tune-row${t.on ? "" : " off"}" data-i="${e}">
      ${g}
      ${L}
      ${_}
      ${T}
      <div class="music-band-foot">
        <button type="button" class="music-tune-kind" data-act="kind" aria-expanded="${s}"><span>${l(Yn(t.kind))}</span>${h.chevron}</button>
        <button type="button" class="music-tune-sw" data-act="on" aria-pressed="${t.on}" title="${l(t.on ? a("music.tuning_off") : a("music.tuning_on"))}">${h.power}</button>
        <button type="button" class="music-tune-del" data-act="del" title="${l(a("music.tuning_del"))}">${h.trash}</button>
      </div>
      ${q}
    </div>`;
}
function Da(t) {
  if (Pt) return;
  const e = t.querySelector("#music-tuning-filters");
  if (!e || !f || e.contains(document.activeElement)) return;
  const i = f.kinds;
  I(e, J.map((s, n) => cl(s, n, i, oe === n)).join(""));
}
function Zn(t, e, i) {
  const s = qs;
  if (!s) return null;
  const n = t.getBoundingClientRect(), c = s.w / (n.width || s.w), d = s.h / (n.height || s.h), b = (e - n.left) * c, g = (i - n.top) * d, L = Math.log10(20), _ = Math.log10(2e4), T = (b - s.padL) / s.plotW, q = 10 ** (L + T * (_ - L)), P = s.span - (g - s.padT) / s.plotH * (2 * s.span);
  return { f: q, db: P, x: b, y: g };
}
function Ra(t, e, i) {
  const s = Math.log10(20), n = Math.log10(2e4), c = t.padL + (Math.log10(Math.max(1, e)) - s) / (n - s) * t.plotW, d = t.padT + (t.span - i) / (2 * t.span) * t.plotH;
  return { x: c, y: d };
}
let Et = 1;
function Na(t) {
  const e = t.querySelector("#music-tune-canvas");
  e && (e.style.width = `${Et * 100}%`), x(t.querySelector("#music-tune-zoom-label"), `${Math.round(Et * 100)}%`), Vi(t);
}
function Vi(t) {
  var as;
  const e = t.querySelector("#music-tune-canvas");
  if (!e || !f) return;
  const i = e.clientWidth || e.width, s = e.clientHeight || e.height;
  if (i < 2 || s < 2) return;
  const n = window.devicePixelRatio || 1;
  (e.width !== Math.round(i * n) || e.height !== Math.round(s * n)) && (e.width = Math.round(i * n), e.height = Math.round(s * n));
  const c = e.getContext("2d");
  if (!c) return;
  c.setTransform(n, 0, 0, n, 0, 0), c.clearRect(0, 0, i, s);
  const d = getComputedStyle(t), b = d.getPropertyValue("--accent").trim() || "#7aa2f7", g = d.getPropertyValue("--border-glass").trim() || "rgba(255,255,255,0.12)", L = d.getPropertyValue("--text-dim").trim() || "rgba(255,255,255,0.55)", { freqs: _ } = f.response, T = Ac(), q = 30, P = 8, N = 8, ze = 16, Ae = Math.max(1, i - q - P), pe = Math.max(1, s - N - ze);
  let We = 0;
  for (const E of T) Number.isFinite(E) && (We = Math.max(We, Math.abs(E)));
  for (const E of (Ge == null ? void 0 : Ge.db) ?? [])
    Number.isFinite(E) && (We = Math.max(We, Math.abs(E)));
  const V = Math.min(60, Math.max(12, Math.ceil((We + 1) / 6) * 6)), _t = Math.log10(20), ns = Math.log10(2e4), Xe = (E) => q + (Math.log10(Math.max(1, E)) - _t) / (ns - _t) * Ae, O = (E) => N + (V - E) / (2 * V) * pe, He = { w: i, h: s, padL: q, padT: N, plotW: Ae, plotH: pe, span: V };
  qs = He, c.lineWidth = 1, c.font = "9px system-ui, -apple-system, sans-serif", c.textBaseline = "middle";
  for (const E of [V, V / 2, 0, -V / 2, -V])
    c.strokeStyle = g, c.globalAlpha = E === 0 ? 0.9 : 0.45, c.setLineDash(E === 0 ? [] : [3, 3]), c.beginPath(), c.moveTo(q, O(E)), c.lineTo(q + Ae, O(E)), c.stroke();
  c.setLineDash([]), c.fillStyle = L;
  for (const E of [20, 100, 1e3, 1e4, 2e4]) {
    const B = Xe(E);
    c.globalAlpha = 0.45, c.strokeStyle = g, c.beginPath(), c.moveTo(B, N), c.lineTo(B, N + pe), c.stroke(), c.globalAlpha = 0.9, c.textAlign = E === 20 ? "left" : E === 2e4 ? "right" : "center", c.fillText(E >= 1e3 ? `${E / 1e3}k` : String(E), B, N + pe + 8);
  }
  c.textAlign = "right";
  for (const E of [V, V / 2, 0, -V / 2, -V])
    c.globalAlpha = 0.9, c.fillStyle = L, c.fillText(`${E > 0 ? "+" : ""}${U(E, 0)}`, q - 3, O(E));
  if (c.textAlign = "left", c.globalAlpha = 1, _.length >= 2 && T.length === _.length) {
    c.beginPath();
    for (let E = 0; E < _.length; E++) {
      const B = Xe(_[E]), Q = O(T[E]);
      E === 0 ? c.moveTo(B, Q) : c.lineTo(B, Q);
    }
    c.lineTo(Xe(_[_.length - 1]), O(0)), c.lineTo(Xe(_[0]), O(0)), c.closePath(), c.globalAlpha = 0.12, c.fillStyle = b, c.fill(), c.globalAlpha = 1, c.beginPath();
    for (let E = 0; E < _.length; E++) {
      const B = Xe(_[E]), Q = O(T[E]);
      E === 0 ? c.moveTo(B, Q) : c.lineTo(B, Q);
    }
    c.strokeStyle = b, c.lineWidth = 1.5, c.stroke();
  }
  const le = Ge;
  if (le && le.freqs.length >= 2) {
    const E = d.getPropertyValue("--green").trim() || "#8fc99a", B = d.getPropertyValue("--blue").trim() || "#9490b4", Q = (xe, z, Fe, wt) => {
      if (!(xe.length < 2)) {
        c.save(), c.beginPath(), c.rect(q, N, Ae, pe), c.clip(), c.beginPath();
        for (let je = 0; je < le.freqs.length && je < xe.length; je++) {
          const Jt = Xe(le.freqs[je]), Qt = O(xe[je]);
          je === 0 ? c.moveTo(Jt, Qt) : c.lineTo(Jt, Qt);
        }
        c.setLineDash(z), c.strokeStyle = Fe, c.lineWidth = wt, c.stroke(), c.setLineDash([]), c.restore();
      }
    };
    Q(le.db, [1.5, 3], B, 1.2), Q(le.chain_db ?? [], [5, 3], E, 1.5);
  }
  if (J.length > 0) {
    c.save(), c.font = "9px system-ui, -apple-system, sans-serif", c.textAlign = "center", c.textBaseline = "middle";
    for (let E = 0; E < J.length; E++) {
      const B = J[E], Q = ((as = f.kinds.find((wt) => wt.name === B.kind)) == null ? void 0 : as.gain) ?? B.gain_db !== void 0, { x: xe, y: z } = Ra(He, B.freq_hz, Q ? B.gain_db ?? 0 : 0), Fe = E === kt;
      c.globalAlpha = B.on ? 1 : 0.4, c.beginPath(), Q ? c.arc(xe, z, Fe ? 6 : 4.5, 0, Math.PI * 2) : (c.moveTo(xe, z - 5), c.lineTo(xe + 5, z + 3), c.lineTo(xe - 5, z + 3), c.closePath()), c.fillStyle = Fe ? b : "rgba(0,0,0,0.65)", c.fill(), c.strokeStyle = b, c.lineWidth = 1.5, c.stroke(), Q && E < 9 && (c.globalAlpha = 1, c.fillStyle = Fe ? "rgba(0,0,0,0.8)" : b, c.fillText(String(E + 1), xe, z + 0.5));
    }
    c.globalAlpha = 1, c.restore();
  }
}
function ll(t, e, i) {
  t.kind = e;
  const s = i.find((n) => n.name === e);
  s && (s.gain ? t.gain_db === void 0 && (t.gain_db = 0) : delete t.gain_db, s.order === 1 ? delete t.q : t.q === void 0 && (t.q = 0.707));
}
async function X(t, e = !1) {
  var L, _, T;
  const i = ++Je, s = document.activeElement, n = (L = s == null ? void 0 : s.closest) == null ? void 0 : L.call(s, ".music-tune-row"), c = s instanceof HTMLInputElement && s.type === "text" ? s.dataset.f : void 0, d = n ? Number(n.dataset.i) : -1, b = s instanceof HTMLInputElement && s.type === "text" && !n ? s.id : "";
  let g;
  try {
    g = await u("player_tuning_set_chain", {
      preampDb: bi,
      // 低音 / 高音快捷增益：引擎不认识它们，宿主会追加成 low_shelf / high_shelf 两条。
      bassDb: hi,
      trebleDb: yi,
      // ⚠️ **全局槽 = `tuneSlotDrafts[0]`，不是 `tuneFilters`**（P5-2）：后者是「表正在编辑
      // 的那一份」，用户停在某个通道槽时它指的是那条声道 —— 拿它当全局发会把通道的段搬进全局。
      filters: ht[0],
      // 新效果器全部**走草稿**（它们现在都有界面了：P5-3 图示均衡器 / P5-4 延迟 + 复制 + 卷积）。
      // 宿主那条命令的语义是「**覆盖整条链**」⇒ 少发一样就等于把它清掉。
      graphicEq: ka,
      delayMs: be,
      channelCopy: ft,
      convolution: Nt,
      // 通道段由**全部槽的草稿**拼（P5-2）—— 不是把宿主那份原样回传：用户这会儿
      // 可能正在某个通道槽里改，那份改动就在 `tuneSlotDrafts` 里。
      ifElse: Ic()
    });
  } catch (q) {
    if (i !== Je) return;
    $(t, C(q)), await nt(t);
    return;
  }
  i === Je && (f = g, Yt(), e || $(t, a("music.tuning_saved")), ae(t), c && d >= 0 && d < J.length ? (_ = t.querySelector(`.music-tune-row[data-i="${d}"] input[type="text"][data-f="${c}"]`)) == null || _.focus() : b && ((T = t.querySelector(`#${b}`)) == null || T.focus()));
}
async function ul(t, e) {
  const i = ++Je;
  let s;
  try {
    s = await u("player_tuning_set_enabled", { enabled: e });
  } catch (n) {
    if (i !== Je) return;
    $(t, C(n)), await nt(t);
    return;
  }
  i === Je && (f = s, Yt(), $(t, a("music.tuning_saved")), ae(t));
}
async function rl(t, e) {
  const i = ++Je;
  let s;
  try {
    s = await u("player_tuning_set", { enabled: !0, preset: e });
  } catch (n) {
    if (i !== Je) return;
    $(t, C(n)), await nt(t);
    return;
  }
  i === Je && (f = s, Yt(), oe = -1, Ge = null, $(t, a("music.tuning_saved")), ae(t));
}
async function ea(t) {
  var s;
  const e = Ve;
  if (!e) return;
  const i = e.mode === "delete" ? e.name : (((s = t.querySelector("#music-preset-name")) == null ? void 0 : s.value) ?? "").trim();
  if (e.mode !== "delete" && !i) {
    $(t, a("music.tuning_preset_name_empty"));
    return;
  }
  try {
    e.mode === "save" ? (f = await u("player_tuning_preset_save", { name: i, overwrite: e.overwrite }), $(t, a("music.tuning_preset_saved", { name: i }))) : e.mode === "rename" ? (f = await u("player_tuning_preset_rename", { from: e.from, to: i }), $(t, a("music.tuning_preset_renamed", { name: i }))) : (f = await u("player_tuning_preset_delete", { name: i }), $(t, a("music.tuning_preset_deleted", { name: i }))), Ve = null, Yt(), ae(t);
  } catch (n) {
    const c = C(n);
    if (c.includes("ERR_PRESET_EXISTS")) {
      e.mode === "save" ? (Ve = { mode: "save", name: i, overwrite: !0 }, ae(t)) : $(t, a("music.tuning_preset_exists", { name: i }));
      return;
    }
    $(t, c);
  }
}
async function ol(t) {
  let e;
  try {
    e = await Xi({
      multiple: !1,
      filters: [{ name: "Lunac preset", extensions: ["json"] }]
    });
  } catch (i) {
    $(t, C(i));
    return;
  }
  if (typeof e == "string")
    try {
      f = await u("player_tuning_preset_import", { path: e }), Yt(), oe = -1, Ge = null, ae(t), $(t, a("music.tuning_preset_imported", { name: f.preset }));
    } catch (i) {
      $(t, C(i));
    }
}
async function dl(t) {
  let e;
  try {
    e = await Xi({
      multiple: !1,
      filters: [{ name: "WAV", extensions: ["wav"] }]
    });
  } catch (i) {
    $(t, C(i));
    return;
  }
  typeof e == "string" && (Nt = e, await X(t));
}
async function ml(t) {
  if (!f) return;
  const e = f.preset && f.preset !== "custom" ? f.preset : "lunac-chain";
  let i;
  try {
    i = await oc({
      defaultPath: `${e}.json`,
      filters: [{ name: "Lunac preset", extensions: ["json"] }]
    });
  } catch (s) {
    $(t, C(s));
    return;
  }
  if (typeof i == "string")
    try {
      await u("player_tuning_preset_export", { path: i }), $(t, a("music.tuning_preset_exported", { path: i }));
    } catch (s) {
      $(t, C(s));
    }
}
function Pi(t) {
  const e = Date.now();
  if (e - Ci >= 120) {
    Ci = e, X(t, !0);
    return;
  }
  rs == null && (rs = window.setTimeout(() => {
    rs = null, Ci = Date.now(), X(t, !0);
  }, 120));
}
function fs(t) {
  Ei != null && window.clearTimeout(Ei), Ei = window.setTimeout(() => {
    Ei = null, X(t);
  }, Mc);
}
async function pl(t) {
  if (!et) {
    et = !0, Aa(t);
    try {
      Ge = await u("player_tuning_measure");
    } catch (e) {
      $(t, C(e));
    } finally {
      et = !1, ae(t);
    }
  }
}
function fl(t) {
  const e = t.querySelector("#music-tune-canvas");
  if (!e) return;
  const i = (n, c, d) => {
    var q;
    const b = Zn(n, c, d), g = qs;
    if (!b || !g) return null;
    let L = -1, _ = 14;
    for (let P = 0; P < J.length; P++) {
      const N = J[P], ze = ((q = f == null ? void 0 : f.kinds.find((We) => We.name === N.kind)) == null ? void 0 : q.gain) ?? N.gain_db !== void 0, Ae = Ra(g, N.freq_hz, ze ? N.gain_db ?? 0 : 0), pe = Math.hypot(Ae.x - b.x, Ae.y - b.y);
      pe < _ && (_ = pe, L = P);
    }
    const T = b.x >= g.padL - 6 && b.x <= g.padL + g.plotW + 6 && b.y >= g.padT - 6 && b.y <= g.padT + g.plotH + 6;
    return { p: b, idx: L, inside: T };
  };
  e.addEventListener("pointerdown", (n) => {
    const c = n.currentTarget, d = i(c, n.clientX, n.clientY);
    if (!d) return;
    let b = d.idx;
    Xt = !1, !(b < 0 && !d.inside) && (b < 0 && (J.push({
      kind: "peaking",
      freq_hz: Jn(d.p.f),
      gain_db: Qn(d.p.db),
      q: 0.707,
      on: !0
    }), b = J.length - 1, oe = -1, Xt = !0), kt = b, Pt = !0, c.setPointerCapture(n.pointerId), Vi(t), n.preventDefault());
  }), e.addEventListener("pointermove", (n) => {
    var T;
    if (kt < 0) return;
    const c = n.currentTarget, d = J[kt], b = Zn(c, n.clientX, n.clientY);
    if (!d || !b) return;
    const g = ((T = f == null ? void 0 : f.kinds.find((q) => q.name === d.kind)) == null ? void 0 : T.gain) ?? d.gain_db !== void 0, L = Jn(b.f), _ = Qn(b.db);
    (L !== d.freq_hz || g && _ !== d.gain_db) && (Xt = !0), d.freq_hz = L, g && (d.gain_db = _), Vi(t), Pi(t), n.preventDefault();
  });
  const s = (n) => {
    var b;
    if (kt < 0) return;
    const c = n.currentTarget, d = Xt;
    kt = -1, Xt = !1, Pt = !1, (b = c.hasPointerCapture) != null && b.call(c, n.pointerId) && c.releasePointerCapture(n.pointerId), Ci = 0, d && X(t);
  };
  e.addEventListener("pointerup", s), e.addEventListener("pointercancel", s);
}
function Pa(t) {
  var s, n, c, d, b;
  (s = t.querySelector("#music-tune-measure")) == null || s.addEventListener("click", () => {
    pl(t);
  });
  const e = (g, L) => {
    const _ = t.querySelector("#music-tune-scroll"), T = t.querySelector("#music-tune-canvas");
    if (!_ || !T) return;
    const q = T.getBoundingClientRect(), P = q.width > 0 ? (g - q.left) / q.width : 0.5, N = Math.min(3, Math.max(1, Math.round(L * 100) / 100));
    if (N === Et) return;
    Et = N, Na(t);
    const ze = T.getBoundingClientRect();
    _.scrollLeft += ze.left + P * ze.width - g;
  }, i = (g) => {
    const L = t.querySelector("#music-tune-scroll");
    if (!L) return;
    const _ = L.getBoundingClientRect();
    e(_.left + _.width / 2, Et + g);
  };
  (n = t.querySelector("#music-tune-zoom-in")) == null || n.addEventListener("click", () => i(0.25)), (c = t.querySelector("#music-tune-zoom-out")) == null || c.addEventListener("click", () => i(-0.25)), (d = t.querySelector("#music-tune-scroll")) == null || d.addEventListener(
    "wheel",
    (g) => {
      g.preventDefault(), e(g.clientX, Et + (g.deltaY < 0 ? 0.2 : -0.2));
    },
    { passive: !1 }
  ), fl(t), (b = t.querySelector("#music-tune-slots")) == null || b.addEventListener("click", (g) => {
    const L = g.target.closest("[data-slot]");
    L && tl(t, Number(L.dataset.slot));
  });
}
let fi;
const ta = 1200;
function ks() {
  fi !== void 0 && (window.clearTimeout(fi), fi = void 0);
}
let It;
const ia = 1200;
function Cs() {
  It !== void 0 && (window.clearTimeout(It), It = void 0);
}
function vl(t) {
  if (It !== void 0) return;
  const e = async () => {
    if (!t.isConnected || R !== "tuning") {
      Cs();
      return;
    }
    await nt(t), t.isConnected && R === "tuning" && (It = window.setTimeout(() => void e(), ia));
  };
  It = window.setTimeout(() => void e(), ia);
}
async function bl(t) {
  ks(), Ge = null, et = !1, Pa(t), await nt(t);
  const e = async () => {
    if (!t.isConnected) {
      ks();
      return;
    }
    await nt(t), t.isConnected && (fi = window.setTimeout(() => void e(), ta));
  };
  fi = window.setTimeout(() => void e(), ta);
}
async function hl(t) {
  try {
    await u("open_plugin_window", { pluginId: "music", key: ya, input: "" });
  } catch (e) {
    $(t, C(e));
  }
}
function yl(t) {
  var e;
  return !!t.uri && ((e = v == null ? void 0 : v.track) == null ? void 0 : e.uri) === t.uri;
}
function $(t, e) {
  x(t.querySelector("#music-msg"), e);
}
function es(t, e, i, s = "", n = "") {
  return `<button class="music-tr${yl(t) ? " playing" : ""}" data-act="${i}" data-uri="${l(t.uri)}"${s ? ` data-i="${l(s)}"` : ""}${n ? ` title="${l(n)}"` : ""}>
    <span class="music-tr-i">${e + 1}</span>
    <span class="music-tr-main">
      <span class="music-tr-n">${l(t.name || "?")}</span>
      <span class="music-tr-a">${l(t.artists || t.album)}</span>
    </span>
    <span class="music-tr-d">${mi(t.duration_ms)}</span>
  </button>`;
}
function ts(t) {
  return { id: t.id, uri: t.uri, name: t.name, cover: t.cover, subtitle: t.owner, total: t.total };
}
function Bi(t, e) {
  const i = !!e.uri && (v == null ? void 0 : v.context_uri) === e.uri, s = (M == null ? void 0 : M.kind) === t && M.id === e.id, n = e.cover ? `<img src="${l(e.cover)}" alt="">` : "";
  return `<div class="music-pl${i ? " playing" : ""}${s ? " on" : ""}" data-uri="${l(e.uri)}">
    <button class="music-pl-btn" data-act="open" data-kind="${t}" data-id="${l(e.id)}" title="${l(e.name || "?")}">
      <span class="music-pl-cover">${n}</span>
      <span class="music-pl-main">
        <span class="music-pl-name">${l(e.name || "?")}</span>
        <span class="music-pl-sub">${l(e.subtitle)}</span>
      </span>
    </button>
  </div>`;
}
function gl() {
  return `<div class="music-pl${(M == null ? void 0 : M.kind) === "top-tracks" ? " on" : ""}">
    <button class="music-pl-btn" data-act="open" data-kind="top-tracks" data-id="top-tracks" title="${l(a("music.top_tracks"))}">
      <span class="music-pl-cover music-pl-trend-cover">${h.trend}</span>
      <span class="music-pl-main">
        <span class="music-pl-name">${l(a("music.top_tracks"))}</span>
        <span class="music-pl-sub">${l(a("music.top_tracks_sub"))}</span>
      </span>
    </button>
  </div>`;
}
function _l(t, e) {
  const i = e.cover ? `<img src="${l(e.cover)}" alt="">` : "";
  return `<button class="music-card" data-act="open" data-kind="${t}" data-id="${l(e.id)}" title="${l(e.name)}">
    <span class="music-card-cover${t === "artist" ? " round" : ""}">${i}</span>
    <span class="music-card-n">${l(e.name)}</span>
    <span class="music-card-s">${l(e.subtitle)}</span>
  </button>`;
}
function wl() {
  const t = (M == null ? void 0 : M.kind) === "liked", e = j ? String(j.total) : "", i = vt || [(m == null ? void 0 : m.display_name) || "", e].filter(Boolean).join(" · ");
  return `<div class="music-pl music-pl-liked${t ? " on" : ""}${vt ? " err" : ""}">
    <button class="music-pl-btn" data-act="open" data-kind="liked" data-id="liked" title="${l(a("music.liked_songs"))}">
      <span class="music-pl-cover music-pl-liked-cover">${h.heart}</span>
      <span class="music-pl-main">
        <span class="music-pl-name">${l(a("music.liked_songs"))}</span>
        <span class="music-pl-sub">${l(i)}</span>
      </span>
    </button>
  </div>`;
}
function gt(t) {
  if (ne) {
    at(t);
    return;
  }
  A(t.querySelector("#music-side-tabs"), !0), A(t.querySelector("#music-local-head"), !1), t.querySelectorAll("#music-side-tabs .music-tab").forEach((c) => {
    c.classList.toggle("on", c.dataset.tab === re);
  });
  const e = t.querySelector("#music-side-list");
  if (!e) return;
  if (!(m != null && m.connected)) {
    I(e, `<div class="music-empty">${a("music.playlists_login")}</div>`);
    return;
  }
  const i = zt.get(re), s = gi.get(re);
  let n = re === "playlist" ? wl() : re === "top" ? gl() : "";
  ci.has(re) ? n += `<div class="music-empty">${a("music.loading")}</div>` : s ? n += `<div class="music-empty music-empty-err">${l(s)}</div>` : i && (n += i.length === 0 ? `<div class="music-empty">${a(re === "playlist" ? "music.playlists_empty" : "music.lib_empty")}</div>` : i.map((c) => Bi(re, c)).join("")), I(e, n);
}
function vs(t) {
  t.querySelectorAll("#music-side-list .music-pl").forEach((e) => {
    const i = e.querySelector(".music-pl-btn"), s = !!M && (i == null ? void 0 : i.dataset.kind) === M.kind && (i == null ? void 0 : i.dataset.id) === M.id;
    e.classList.toggle("on", s);
  });
}
function we(t) {
  if (ne) {
    Oa(t);
    return;
  }
  const e = t.querySelector("#music-main");
  if (!e) return;
  if (Ze && Me) {
    I(e, Sl());
    return;
  }
  if (!M) {
    I(e, `<div class="music-empty">${m != null && m.connected ? a("music.pick_hint") : a("music.playlists_login")}</div>`);
    return;
  }
  const i = M.cover ? `<img src="${l(M.cover)}" alt="">` : "", s = M.kind === "liked" ? a("music.liked_songs") : M.kind === "top-tracks" ? a("music.top_tracks") : M.kind === "playlist" ? a("music.playlists") : M.kind === "album" ? a("music.tab_albums") : M.kind === "artist" ? a("music.tab_artists") : M.kind === "top" ? a("music.tab_top") : a("music.tab_shows");
  let n;
  Tt ? n = `<div class="music-empty">${a("music.loading")}</div>` : Qe ? n = `<div class="music-empty music-empty-err">${l(Qe)}</div>` : !ye || ye.length === 0 ? n = `<div class="music-empty">${a("music.playlist_empty")}</div>` : n = ye.map((c, d) => es(c, d, "main-track", String(d))).join(""), I(e, `<div class="music-page">
    <div class="music-page-head">
      <span class="music-page-cover${M.kind === "artist" ? " round" : ""}">${i}</span>
      <div class="music-page-info">
        <span class="music-page-kind">${l(s)}</span>
        <span class="music-page-name">${l(M.name || "?")}</span>
        <span class="music-page-sub">${l(M.subtitle)}</span>
        <div class="music-page-actions">
          <button class="music-btn music-primary" data-act="main-play-all">${h.play} ${a("music.play_all")}</button>
        </div>
      </div>
    </div>
    <div class="music-list">${n}</div>
  </div>`);
}
function Sl() {
  const t = H, i = [
    ["tracks", a("music.tracks")],
    ["artists", a("music.tab_artists")],
    ["albums", a("music.tab_albums")],
    ["playlists", a("music.playlists")],
    ["shows", a("music.tab_shows")]
  ].map(([n, c]) => `<button class="music-tab${Ie === n ? " on" : ""}" data-act="search-tab" data-tab="${n}">${l(c)}</button>`).join("");
  let s;
  if (Ot || !t)
    s = `<div class="music-empty">${a("music.loading")}</div>`;
  else if (Ie === "tracks")
    s = t.tracks.length ? t.tracks.map((n, c) => es(n, c, "main-track", String(c))).join("") : `<div class="music-empty">${a("music.search_empty")}</div>`;
  else {
    const c = (Ie === "artists" ? t.artists : Ie === "albums" ? t.albums : Ie === "shows" ? t.shows : t.playlists.map(ts)).map((d) => _l(Ie === "playlists" ? "playlist" : Ie === "artists" ? "artist" : Ie === "albums" ? "album" : "show", d));
    s = c.length ? `<div class="music-grid">${c.join("")}</div>` : `<div class="music-empty">${a("music.search_empty")}</div>`;
  }
  return `<div class="music-page">
    <div class="music-page-info music-page-info-flat">
      <span class="music-page-kind">${a("music.search_result")}</span>
      <span class="music-page-name">${l(Me)}</span>
    </div>
    <div class="music-tabs">${i}</div>
    <div class="music-list">${s}</div>
  </div>`;
}
function Be(t) {
  const e = t.querySelector("#music-search-dd");
  if (!e) return;
  const i = !!(m != null && m.connected) && Le && !!Me;
  if (A(e, i), !i) return;
  if (!H) {
    I(e, Ot ? `<div class="music-empty">${a("music.loading")}</div>` : "");
    return;
  }
  const s = H, n = [];
  s.tracks.slice(0, 3).forEach((c, d) => n.push(es(c, d, "dd-track"))), s.artists.slice(0, 2).forEach((c) => n.push(Bi("artist", c))), s.albums.slice(0, 2).forEach((c) => n.push(Bi("album", c))), s.playlists.slice(0, 2).forEach((c) => n.push(Bi("playlist", ts(c)))), n.length || n.push(`<div class="music-empty">${a("music.search_empty")}</div>`), n.push(`<button class="music-dd-all" data-act="search-all">${a("music.search_all")}</button>`), I(e, n.join(""));
}
function jt(t) {
  const e = t.querySelector("#music-dev-dd");
  if (!e || (A(e, Ue), !Ue)) return;
  const i = Z;
  let s = `<div class="music-dd-head">${a("music.devices")}</div>`;
  i != null && i.available && !i.has_credentials ? s += `<button class="music-dev-row" data-act="local-login">
      <span class="music-dev-ico">${h.power}</span>
      <span class="music-dev-main">
        <span class="music-dev-n">${a("music.local_login")}</span>
        <span class="music-dev-s">${a("music.local_login_hint")}</span>
      </span>
    </button>` : i != null && i.available ? s += `<button class="music-dev-row${i.running ? " on" : ""}" data-act="local-toggle">
      <span class="music-dev-ico">${h.power}</span>
      <span class="music-dev-main">
        <span class="music-dev-n">${a("music.local_play")}</span>
        <span class="music-dev-s">${l(i.path || "")}</span>
      </span>
    </button>` : s += `<div class="music-dev-row disabled">
      <span class="music-dev-ico">${h.power}</span>
      <span class="music-dev-main">
        <span class="music-dev-n">${a("music.local_play")}</span>
        <span class="music-dev-s">${a("music.local_no_exe")}</span>
      </span>
    </div>`;
  const n = yt ?? [];
  s += n.length ? n.map((c) => `<button class="music-dev-row${c.active ? " on" : ""}" data-act="dev-pick" data-id="${l(c.id)}">
        <span class="music-dev-ico">${h.speaker}</span>
        <span class="music-dev-main">
          <span class="music-dev-n">${l(c.name || "?")}</span>
          <span class="music-dev-s">${l(c.kind)}</span>
        </span>
      </button>`).join("") : `<div class="music-empty">${a("music.device_none")}</div>`, I(e, s);
}
function kl(t) {
  var s;
  const e = (v == null ? void 0 : v.context_uri) ?? "", i = ((s = v == null ? void 0 : v.track) == null ? void 0 : s.uri) ?? "";
  t.querySelectorAll(".music-pl").forEach((n) => {
    n.classList.toggle("playing", !!e && n.dataset.uri === e);
  }), t.querySelectorAll(".music-tr").forEach((n) => {
    n.classList.toggle("playing", !!i && n.dataset.uri === i);
  });
}
function $l(t) {
  if (!t) return "";
  const e = new Date(t), i = (s) => String(s).padStart(2, "0");
  return `${e.getFullYear()}-${i(e.getMonth() + 1)}-${i(e.getDate())} ${i(e.getHours())}:${i(e.getMinutes())}`;
}
function Ba(t) {
  qe && (De = !1);
  const e = (i, s) => A(t.querySelector(i), s);
  e("#music-local-add", !qe), e("#music-local-list", !qe), e("#music-local-scan", !qe), e("#music-local-del", qe), e("#music-local-editdone", qe), ei(t);
}
function ei(t) {
  const e = t.querySelector("#music-local-add-dd");
  e && (A(e, De), De && I(e, `
    <div class="music-dd-head">${l(a("music.local_add_head"))}</div>
    <button class="music-dev-row" data-act="media-add-dir">
      <span class="music-dev-ico">${h.folder}</span>
      <span class="music-dev-main">
        <span class="music-dev-n">${l(a("music.local_add_dir"))}</span>
        <span class="music-dev-s">${l(a("music.local_add_dir_hint"))}</span>
      </span>
    </button>
    <button class="music-dev-row" data-act="media-add-list">
      <span class="music-dev-ico">${h.list}</span>
      <span class="music-dev-main">
        <span class="music-dev-n">${l(a("music.local_open_playlist"))}</span>
        <span class="music-dev-s">${l(a("music.local_add_list_hint"))}</span>
      </span>
    </button>`));
}
function xl(t) {
  const e = t.missing ? a("music.local_missing") : [
    a("music.local_n_tracks", { n: String(t.tracks) }),
    t.last_scan_at ? $l(t.last_scan_at) : a("music.local_never_scanned")
  ].join(" · "), i = qe && Ne.has(t.path);
  return `<div class="music-pl${Ce === t.path ? " on" : ""}${t.missing ? " err" : ""}${i ? " sel" : ""}">
    <button class="music-pl-btn" data-act="media-root" data-path="${l(t.path)}" title="${l(t.path)}">
      <span class="music-pl-cover music-pl-dir">${h.folder}</span>
      <span class="music-pl-main">
        <span class="music-pl-name">${l(t.name || t.path)}</span>
        <span class="music-pl-sub">${l(e)}</span>
      </span>
    </button>
  </div>`;
}
function at(t) {
  A(t.querySelector("#music-side-tabs"), !1), A(t.querySelector("#music-local-head"), !0), Ba(t);
  const e = t.querySelector("#music-side-list");
  if (!e) return;
  const i = (ce ?? []).filter((c) => !_i.has(c.path)), s = i.reduce((c, d) => c + d.tracks, 0);
  let n = `<div class="music-pl${Ce === "" ? " on" : ""}">
    <button class="music-pl-btn" data-act="media-root" data-path="" title="${l(a("music.local_all"))}">
      <span class="music-pl-cover music-pl-dir">${h.note}</span>
      <span class="music-pl-main">
        <span class="music-pl-name">${l(a("music.local_all"))}</span>
        <span class="music-pl-sub">${l(a("music.local_n_tracks", { n: String(s) }))}</span>
      </span>
    </button>
  </div>`;
  Ui ? n += `<div class="music-empty">${a("music.loading")}</div>` : Wt ? n += `<div class="music-empty music-empty-err">${l(Wt)}</div>` : ce && i.length === 0 ? n += `<div class="music-empty">${l(a("music.local_no_roots"))}</div>` : ce && (n += i.map((c) => xl(c)).join("")), I(e, n);
}
function Ll(t, e) {
  const i = t.cover ? `<img src="${l(Qi(t.cover))}" alt="">` : `<span class="music-mt-ico">${h.note}</span>`, s = [t.artist, t.album].filter(Boolean).join(" · ");
  return `<button class="music-mt${!!(S != null && S.active) && S.path === t.path ? " playing" : ""}" data-act="local-track" data-i="${e}" data-path="${l(t.path)}" title="${l(t.path)}">
    <span class="music-mt-i">${e + 1}</span>
    <span class="music-mt-cover">${i}</span>
    <span class="music-mt-main">
      <span class="music-mt-n">${l(t.title || "?")}</span>
      <span class="music-mt-a">${l(s)}</span>
    </span>
    <span class="music-mt-d">${mi(t.duration_ms)}</span>
  </button>`;
}
function Oa(t) {
  const e = t.querySelector("#music-main");
  if (!e) return;
  e.querySelector("#music-local-page") || (e.innerHTML = `<div class="music-local-page" id="music-local-page">
      <div class="music-local-head-row">
        <input class="music-local-q" id="music-mt-q" type="search" autocomplete="off" spellcheck="false"
               placeholder="${l(a("music.local_filter_ph"))}" value="${l(wi)}">
        <span class="music-list-chip hidden" id="music-list-chip">
          <span class="music-list-chip-n" id="music-list-chip-n"></span>
          <button class="music-pl-x" data-act="media-list-close" title="${l(a("music.local_close_playlist"))}">${h.x}</button>
        </span>
        <!-- 重扫（2026-10-01 用户口径）：**只留图标**，「重扫」那两个可见字去掉 ——
             它右边紧挨着设置齿轮（见 placeGear），带文字那一行会挤。
             title 仍然留着（鼠标悬浮还能问出这是什么）；去掉的是**可见文字**。
             ⚠️ 本行属于**动态骨架**（#music-main 会被 renderMain 整块重写、回来时重建），
             所以它只能走 data-act 委托，直接 addEventListener 会在下次重建时失效。 -->
        <button class="music-ghost-btn music-icon-btn" data-act="media-scan" title="${l(a("music.local_rescan"))}">${h.refresh}</button>
      </div>
      <div class="music-scan hidden" id="music-scan"></div>
      <!-- 视频的**画面层**（2026-10-01 用户第 8 条）。里面那个 video 元素由
           renderLocalVideo 现造现拆（离开 / 换曲时整块清掉，见那里的注释）。
           注：本段在模板字符串里，注释里一个反引号都不能出现（预检 #15 / #39 ⑩）。 -->
      <div class="music-video hidden" id="music-video"></div>
      <div class="music-list" id="music-mt-list"></div>
    </div>`), A(t.querySelector("#music-mt-q"), !he);
  const i = t.querySelector("#music-list-chip");
  A(i, !!he), he && x(
    t.querySelector("#music-list-chip-n"),
    `${he.name} · ${a("music.local_n_tracks", { n: String((Y == null ? void 0 : Y.total) ?? 0) })}`
  ), El(t), za(t), ql(t), Ca(t);
}
function El(t) {
  const e = t.querySelector("#music-scan");
  if (!e) return;
  const i = Mt;
  let s = "";
  if (i != null && i.running) {
    const n = i.total, c = n > 0 ? Math.min(100, Math.round(i.scanned / n * 100)) : 0, d = n > 0 ? a("music.local_scanning", { a: String(i.scanned), b: String(n) }) : a("music.local_scanning_n", { a: String(i.scanned) });
    s = `<div class="music-scan-row">
      <span class="music-scan-bar"><span class="music-scan-fill" style="width:${c}%"></span></span>
      <span class="music-scan-txt">${l(d)}</span>
    </div>`;
  } else i != null && i.error ? s = `<div class="music-scan-row music-scan-err">${l(i.error)}</div>` : i != null && i.done_at && (s = `<div class="music-scan-row music-scan-done">${l(a("music.local_scan_done", {
    added: String(i.added),
    updated: String(i.updated),
    removed: String(i.removed),
    failed: String(i.failed)
  }))}</div>`);
  I(e, s), A(e, !!s);
}
function ql(t) {
  const e = t.querySelector("#music-mt-list");
  if (!e) return;
  let i;
  Ht ? i = `<div class="music-empty">${a("music.loading")}</div>` : st ? i = `<div class="music-empty music-empty-err">${l(st)}</div>` : !he && ce && ce.length === 0 ? i = `<div class="music-empty">${l(a("music.local_add_hint"))}</div>` : !Y || Y.items.length === 0 ? i = `<div class="music-empty">${l(a(he ? "music.local_list_empty" : "music.local_empty"))}</div>` : (i = Y.items.map((s, n) => Ll(s, n)).join(""), Y.total > Y.items.length && (i += `<div class="music-empty">${l(a("music.local_more", {
    a: String(Y.items.length),
    b: String(Y.total)
  }))}</div>`)), I(e, i);
}
function za(t) {
  const e = t.querySelector("#music-video");
  if (!e) return;
  const i = S, s = !!i && i.video && i.path !== "";
  if (A(e, s), !s) {
    e.firstChild && (e.innerHTML = "");
    return;
  }
  const n = Qi(i.path);
  let c = e.querySelector(".music-video-el");
  if (!c || c.dataset.src !== n) {
    if (e.innerHTML = '<video class="music-video-el" muted playsinline preload="auto"></video>', c = e.querySelector(".music-video-el"), !c) return;
    c.dataset.src = n, c.src = n, c.addEventListener("loadedmetadata", () => sa(c, i), { once: !0 }), c.addEventListener("error", () => {
      x(t.querySelector("#music-msg"), a("music.video_unsupported"));
    });
  }
  sa(c, i);
}
function sa(t, e) {
  e.playing ? t.paused && t.play().catch(() => {
  }) : t.paused || t.pause();
  const i = e.playing ? Date.now() - $i : 0, s = (e.position_ms + Math.max(0, i)) / 1e3;
  t.readyState >= 1 && !t.seeking && Math.abs(t.currentTime - s) > Tc && (t.currentTime = s);
}
function Wa(t) {
  if (R !== "lplayer") return;
  const e = t.querySelector("#music-v-lplayer"), i = S;
  if (!e || !i || !i.path) return;
  const s = _e[K], n = (s == null ? void 0 : s.title) || i.path.split(/[\\/]/).pop() || i.path;
  x(e.querySelector("#music-lp-title"), n), x(e.querySelector("#music-lp-sub"), s ? [s.artist, s.album].filter(Boolean).join(" · ") : ""), I(
    e.querySelector("#music-lp-cover"),
    s != null && s.cover ? `<img src="${l(Qi(s.cover))}" alt="">` : h.note
  ), I(e.querySelector("#music-lp-play"), i.active && i.playing ? h.pause : h.play);
  const c = e.querySelector("#music-lp-mode");
  c && ($e(c, "data-mode", ee), $e(c, "title", Ms()), I(c, ee === "repeat_all" || ee === "repeat_one" ? h.repeat : h.shuffle));
  const d = i.duration_ms, b = te >= 0 ? te : d > 0 ? Math.min(1, i.position_ms / d) : 0, g = e.querySelector("#music-lp-progress");
  g && te < 0 && g.style.setProperty("--seek-pct", `${b * 100}%`), x(e.querySelector("#music-lp-time"), d > 0 ? `${F(i.position_ms)} / ${F(d)}` : F(i.position_ms));
  const L = e.querySelector("#music-lp-vol");
  L && document.activeElement !== L && (L.value = String(Math.round(i.volume * 100)), At(L, i.volume * 100));
}
function me(t) {
  za(t), Wa(t);
  const e = t.querySelector("#music-lnowbar");
  if (!e) return;
  const i = S, s = !!i && i.path !== "", n = xa();
  if (A(e, n), !n) return;
  const c = _e[K] ?? null, d = (i && s ? i.path : "") || (c == null ? void 0 : c.path) || "";
  if (!c && !s) {
    x(e.querySelector("#music-lnow-n"), a("music.local_bar_empty")), x(e.querySelector("#music-lnow-a"), ""), I(e.querySelector("#music-lnow-cover"), h.note), I(e.querySelector("#music-l-play"), h.play), x(e.querySelector("#music-l-time"), "0:00");
    const _ = e.querySelector("#music-lbp");
    _ && te < 0 && _.style.setProperty("--seek-pct", "0%");
  } else {
    const _ = (c == null ? void 0 : c.title) || d.split(/[\\/]/).pop() || d;
    x(e.querySelector("#music-lnow-n"), _), x(e.querySelector("#music-lnow-a"), c ? [c.artist, c.album].filter(Boolean).join(" · ") : ""), I(
      e.querySelector("#music-lnow-cover"),
      c != null && c.cover ? `<img src="${l(Qi(c.cover))}" alt="">` : h.note
    ), I(e.querySelector("#music-l-play"), i != null && i.active && (i != null && i.playing) ? h.pause : h.play);
    const T = (i && s ? i.duration_ms : 0) || (c == null ? void 0 : c.duration_ms) || 0, q = i && s ? i.position_ms : ke, P = te >= 0 ? te : T > 0 ? Math.min(1, q / T) : 0, N = e.querySelector("#music-lbp");
    N && te < 0 && N.style.setProperty("--seek-pct", `${P * 100}%`), x(e.querySelector("#music-l-time"), T > 0 ? `${F(q)} / ${F(T)}` : F(q));
  }
  const b = !!c || s;
  for (const _ of ["#music-l-prev", "#music-l-next", "#music-l-mode", "#music-l-stop", "#music-l-play"]) {
    const T = e.querySelector(_);
    T && (T.disabled = !b);
  }
  const g = e.querySelector("#music-l-mode");
  g && ($e(g, "data-mode", ee), $e(g, "title", Ms()), I(g, ee === "repeat_all" || ee === "repeat_one" ? h.repeat : h.shuffle));
  const L = e.querySelector("#music-l-vol");
  if (L && document.activeElement !== L) {
    const _ = i ? i.volume : Number(L.value) / 100;
    L.value = String(Math.round(_ * 100)), At(L, _ * 100);
  }
}
function As(t) {
  const e = S != null && S.active ? S.path : "";
  t.querySelectorAll(".music-mt").forEach((i) => {
    i.classList.toggle("playing", !!e && i.dataset.path === e);
  });
}
function Oe(t) {
  ne && (at(t), Oa(t), me(t));
}
async function Ha(t) {
  Ui = !0, Wt = "", Oe(t);
  try {
    ce = await u("media_roots");
  } catch (e) {
    Wt = String(e);
  } finally {
    Ui = !1, Oe(t);
  }
}
async function Ut(t) {
  he = null, Ht = !0, st = "", Oe(t);
  try {
    Y = await u("media_tracks", {
      // 空串 ⇒ 传 null（宿主的 `Option<String>` 收 None = 全库 / 不筛选）
      root: Ce || null,
      query: wi || null,
      limit: xc
    });
  } catch (e) {
    st = String(e);
  } finally {
    Ht = !1, Oe(t);
  }
}
function Dt() {
  ri !== void 0 && (window.clearInterval(ri), ri = void 0);
}
function Fa(t) {
  ri === void 0 && (ri = window.setInterval(() => {
    (async () => {
      if (!t.isConnected) {
        Dt();
        return;
      }
      try {
        const e = await u("media_scan_status");
        Mt = e, e.running || (Dt(), await Ha(t), await Ut(t));
      } catch {
        Dt();
      }
      Oe(t);
    })();
  }, Lc));
}
async function $s(t, e) {
  try {
    Mt = await u("media_scan_start", { root: e || null });
  } catch (i) {
    const s = String(i);
    $(t, s.includes("ERR_SCAN_RUNNING") ? a("music.local_scan_busy") : s);
    return;
  }
  Oe(t), Fa(t);
}
async function Tl(t) {
  let e = null;
  try {
    e = await Xi({ directory: !0, multiple: !1, title: a("music.local_add_dir") });
  } catch (i) {
    $(t, String(i));
    return;
  }
  if (!(typeof e != "string" || !e)) {
    try {
      ce = await u("media_add_root", { path: e });
    } catch (i) {
      $(t, String(i));
      return;
    }
    Ce = Ml(e), Oe(t), await $s(t, Ce || e);
  }
}
function Ml(t) {
  var s;
  const e = (n) => n.replace(/[\\/]+$/, "").toLowerCase(), i = e(t);
  return ((s = ce == null ? void 0 : ce.find((n) => e(n.path) === i)) == null ? void 0 : s.path) ?? "";
}
function Cl(t) {
  qe = !0, Ne.clear(), at(t);
}
function Al(t) {
  if (Ne.size) {
    for (const e of Ne) _i.add(e);
    Ne.clear(), at(t);
  }
}
async function Il(t) {
  const e = Array.from(_i);
  if (qe = !1, Ne.clear(), _i.clear(), Ba(t), !e.length) {
    at(t);
    return;
  }
  let i = "";
  for (const s of e)
    try {
      ce = await u("media_remove_root", { path: s });
    } catch (n) {
      const c = String(n);
      i = c.includes("ERR_SCAN_RUNNING") ? a("music.local_remove_busy") : c;
    }
  Ce && !(ce ?? []).some((s) => s.path === Ce) && (Ce = ""), at(t), await Ut(t), i && $(t, i);
}
function Dl(t) {
  const e = t instanceof Error ? t.message : String(t);
  return e.includes("ERR_NOT_PLAYLIST") ? a("music.local_not_playlist") : e;
}
async function Rl(t) {
  let e = null;
  try {
    e = await Xi({
      multiple: !1,
      title: a("music.local_open_playlist"),
      filters: [{ name: "Playlist", extensions: ["m3u", "m3u8", "pls"] }]
    });
  } catch (i) {
    $(t, String(i));
    return;
  }
  if (!(typeof e != "string" || !e)) {
    Ht = !0, st = "", Y = null, Oe(t);
    try {
      Y = await u("media_playlist", { path: e }), he = { path: e, name: e.split(/[\\/]/).pop() || e }, Ce = "";
    } catch (i) {
      he = null, st = Dl(i);
    } finally {
      Ht = !1, Oe(t);
    }
  }
}
function Nl(t) {
  he = null, Ut(t);
}
function ja(t) {
  const e = t instanceof Error ? t.message : String(t);
  return e.includes("ERR_NO_AUDIO_DEVICE") ? a("music.local_no_device") : e.includes("找不到这个文件") ? a("music.local_file_missing") : e.includes("解不开") || e.includes("打不开") ? a("music.local_decode_failed") : e;
}
async function Vt(t, e, i = 0) {
  if (rt) return !1;
  await xi(t, "local"), rt = !0;
  try {
    S = await u("player_play", { path: e });
  } catch (s) {
    return $(t, ja(s)), rt = !1, !1;
  }
  if (rt = !1, ke = 0, i > 0)
    try {
      S = await u("player_seek", { positionMs: Math.round(i) }), ke = S.position_ms;
    } catch {
    }
  return $i = Date.now(), Ki(), me(t), As(t), Ua(t), !0;
}
async function Pl(t, e) {
  const i = (Y == null ? void 0 : Y.items) ?? [], s = i[e];
  s && (_e = i.slice(), K = e, Ct = [], await Vt(t, s.path));
}
async function ti(t, e, i) {
  var c;
  const s = _e.length;
  if (s === 0) return;
  if (i && ee === "repeat_one") {
    await Vt(t, ((c = _e[K]) == null ? void 0 : c.path) ?? "");
    return;
  }
  let n;
  if (ee === "shuffle" && s > 1)
    if (e < 0 && Ct.length > 0)
      n = Ct.pop();
    else {
      do
        n = Math.floor(Math.random() * s);
      while (n === K);
      K >= 0 && Ct.push(K);
    }
  else
    n = K + e;
  if (ee === "repeat_all" || ee === "shuffle")
    n = (n % s + s) % s;
  else if (n < 0 || n >= s) {
    i || $(t, a("music.local_queue_end"));
    return;
  }
  K = n, await Vt(t, _e[n].path);
}
async function na(t) {
  var i;
  if (rt) return;
  const e = S;
  if (!e || e.path === "") {
    const s = ((i = _e[K]) == null ? void 0 : i.path) ?? "";
    if (!s) return;
    await Vt(t, s, ke);
    return;
  }
  if (!e.active) {
    await Vt(t, e.path);
    return;
  }
  try {
    S = await u(e.playing ? "player_pause" : "player_resume");
  } catch (s) {
    $(t, ja(s));
    return;
  }
  $i = Date.now(), me(t), S != null && S.active && Ua(t);
}
async function ii(t) {
  Rt(), S != null && S.path && (ke = S.position_ms), te = -1, Ct = [], S = null, $i = 0, Ki();
  const e = R === "lplayer";
  e && (R = "default"), me(t), As(t), e && ie(t);
  try {
    await u("player_stop");
  } catch {
  }
}
async function xi(t, e) {
  if (!Ee) {
    if (e === "local") {
      if (m != null && m.connected && (v != null && v.playing))
        try {
          await u("spotify_control", { action: "pause" });
        } catch {
        }
      return;
    }
    S && await ii(t);
  }
}
async function Bl(t, e) {
  if (!S || S.path === "") {
    ke = Math.max(0, Math.round(e)), Ki(), me(t);
    return;
  }
  try {
    S = await u("player_seek", { positionMs: e });
  } catch {
    return;
  }
  ke = S.position_ms, me(t);
}
async function aa(t, e) {
  try {
    S = await u("player_volume", { volume: e });
  } catch {
    return;
  }
  me(t);
}
function Rt() {
  oi !== void 0 && (window.clearInterval(oi), oi = void 0);
}
function Ua(t) {
  oi === void 0 && (oi = window.setInterval(() => {
    (async () => {
      if (!t.isConnected) {
        Rt();
        return;
      }
      if (te >= 0 || rt) return;
      let e;
      try {
        e = await u("player_status");
      } catch {
        return;
      }
      if (!t.isConnected) {
        Rt();
        return;
      }
      const i = !e.active && e.path !== "" && e.path === (S == null ? void 0 : S.path);
      S = e, ke = e.position_ms, $i = Date.now(), me(t), As(t), i && (Rt(), await ti(t, 1, !0));
    })();
  }, qc));
}
function Ol(t, e) {
  wi = e, de !== void 0 && window.clearTimeout(de), de = window.setTimeout(() => {
    de = void 0, Ut(t);
  }, Ec);
}
function ca(t) {
  li = Math.min(Sa, Math.max(wa, Math.round(li))), t.style.setProperty("--music-side-w", `${li}px`);
}
function Va(t, e) {
  var s;
  if (t === "liked")
    return { id: "liked", uri: "", name: a("music.liked_songs"), cover: "", subtitle: "", total: (j == null ? void 0 : j.total) ?? 0 };
  if (t === "top-tracks")
    return {
      id: "top-tracks",
      uri: "",
      name: a("music.top_tracks"),
      cover: "",
      subtitle: a("music.top_tracks_sub"),
      total: 0
    };
  const i = t === "artist" ? H == null ? void 0 : H.artists : t === "album" ? H == null ? void 0 : H.albums : t === "show" ? H == null ? void 0 : H.shows : H == null ? void 0 : H.playlists.map(ts);
  return ((s = zt.get(t)) == null ? void 0 : s.find((n) => n.id === e)) ?? (i == null ? void 0 : i.find((n) => n.id === e)) ?? null;
}
async function Ga(t, e) {
  if (!(!(m != null && m.connected) || ci.has(e) || zt.has(e))) {
    ci.add(e), gi.delete(e), gt(t);
    try {
      const i = e === "playlist" ? (_s = await u("spotify_playlists")).map(ts) : await u(fc[e]);
      zt.set(e, i);
    } catch (i) {
      gi.set(e, C(i));
    } finally {
      ci.delete(e), gt(t);
    }
  }
}
async function zl(t, e, i) {
  const s = Va(e, i);
  if (s) {
    if (Ze = !1, Le = !1, M = { kind: e, id: s.id, uri: s.uri, name: s.name, cover: s.cover, subtitle: s.subtitle }, ye = null, Qe = "", e === "liked") {
      ye = (j == null ? void 0 : j.items) ?? null, Qe = vt, Tt = !j, Be(t), vs(t), we(t), j || await Ja(t);
      return;
    }
    Tt = !0, Be(t), vs(t), we(t);
    try {
      ye = e === "top-tracks" ? await u("spotify_top_tracks") : await u("spotify_item_tracks", { kind: pc(e), id: s.id });
    } catch (n) {
      Qe = C(n);
    } finally {
      Tt = !1, vs(t), we(t);
    }
  }
}
async function la(t, e, i, s = 0) {
  const n = Va(e, i);
  if (n) {
    await xi(t, "spotify");
    try {
      if (e === "liked" || e === "show" || e === "top-tracks") {
        const c = (e === "liked" ? j == null ? void 0 : j.items : ye) ?? [];
        if (!c.length) return;
        await u("spotify_play_uris", { uris: c.slice(Math.max(0, s)).map((d) => d.uri), deviceId: ge || void 0 });
      } else if (n.uri)
        await u("spotify_play_context", { contextUri: n.uri, offsetUri: "", deviceId: ge || void 0 });
      else
        return;
    } catch (c) {
      $(t, C(c));
    }
  }
}
async function Wl(t, e) {
  if (!M) return;
  const i = ye ?? [], s = i[e];
  if (s) {
    await xi(t, "spotify");
    try {
      M.kind === "liked" || M.kind === "show" ? await u("spotify_play_uris", { uris: i.slice(e).map((n) => n.uri), deviceId: ge || void 0 }) : await u("spotify_play_context", { contextUri: M.uri, offsetUri: s.uri, deviceId: ge || void 0 });
    } catch (n) {
      $(t, C(n));
    }
  }
}
async function Gi(t, e = !1) {
  if (!(m != null && m.connected)) return;
  if (!e && ge && Date.now() - Ai < Dc) {
    await Gt(t);
    return;
  }
  if (ds) return;
  ds = !0;
  const i = !!(Z != null && Z.running), s = window.setTimeout(() => $(t, a("music.auto_starting")), 600);
  try {
    const n = await u("music_autoconfigure", { allowLocal: !ji });
    ge = n.device_id || "", Ai = Date.now(), n.source === "needs_login" ? $(t, a("music.auto_need_login")) : n.source === "local" && !n.device_id ? $(t, a("music.auto_local_unregistered")) : n.started_local && !i ? $(t, a("music.auto_local_started")) : n.source === "start_failed" ? $(t, a("music.auto_start_failed")) : n.source === "none" && !ji && $(t, a("music.auto_none"));
  } catch (n) {
    ge = "", Ai = 0, String(n) !== "ERR_NOT_CONNECTED" && $(t, C(n));
  } finally {
    window.clearTimeout(s), ds = !1;
  }
  await Gt(t);
}
function Hl(t) {
  if (t <= 0) return "";
  if (t >= 3600) {
    const e = Math.floor(t / 3600), i = Math.round(t % 3600 / 60);
    return i > 0 ? a("music.wait_hm", { h: String(e), m: String(i) }) : a("music.wait_h", { h: String(e) });
  }
  return t >= 60 ? a("music.wait_m", { m: String(Math.round(t / 60)) }) : a("music.wait_s", { s: String(Math.ceil(t)) });
}
function Fl() {
  return Fi <= 0 ? 0 : Math.max(0, Math.round((Fi - Date.now()) / 1e3));
}
async function Ya(t) {
  try {
    const e = await u("spotify_api_state");
    it = e.stopped, Hi = e.reason, Fi = e.retry_at_ms;
  } catch {
  }
  Yi(t);
}
function Yi(t) {
  const e = t.querySelector("#music-resume");
  if (A(e, it), !e) return;
  if (!it) {
    e.textContent = a("music.resume"), e.title = "";
    return;
  }
  const i = Hl(Fl());
  e.textContent = i ? a("music.resume_in", { wait: i }) : a("music.resume"), e.title = i ? a("music.resume_hint", { wait: i, reason: Hi }) : Hi;
}
async function jl(t) {
  try {
    await u("spotify_resume");
  } catch {
  }
  it = !1, Hi = "", Fi = 0, Yi(t), $(t, a("music.resumed")), Gi(t, !0);
}
async function Gt(t) {
  try {
    yt = await u("spotify_devices");
  } catch (e) {
    yt = [], $(t, C(e));
  }
  try {
    Z = await u("librespot_status");
  } catch {
    Z = null;
  }
  jt(t);
}
async function Ul(t) {
  if (!(Z != null && Z.available)) return;
  const e = Z.running;
  try {
    Z = await u(e ? "librespot_stop" : "librespot_start");
  } catch (i) {
    $(t, C(i));
    return;
  }
  if (ji = e, jt(t), e) {
    ge = "", Ai = 0, await Gi(t, !0);
    return;
  }
  for (let i = 0; i < 6; i++) {
    await new Promise((s) => window.setTimeout(s, 1500));
    try {
      const s = await u("spotify_devices");
      yt = s;
      const n = s.find((c) => c.name === "Lunac");
      if (n && !n.active && await u("spotify_transfer", { deviceId: n.id, play: !0 }), n) {
        ge = n.id;
        break;
      }
    } catch {
    }
  }
  await Gt(t);
}
async function Vl(t) {
  try {
    Z = await u("librespot_login");
  } catch (e) {
    $(t, C(e));
    return;
  }
  ji = !1, jt(t), $(t, a("music.local_login_started"));
  for (let e = 0; e < 60; e++) {
    if (await new Promise((s) => window.setTimeout(s, 2e3)), !t.isConnected) return;
    let i;
    try {
      i = await u("librespot_status");
    } catch {
      continue;
    }
    if (Z = i, !!i.has_credentials) {
      i.running || (Z = await u("librespot_start").catch(() => i));
      for (let s = 0; s < 8; s++) {
        if (await new Promise((d) => window.setTimeout(d, 1500)), !t.isConnected) return;
        const n = await u("spotify_devices").catch(() => []);
        yt = n;
        const c = n.find((d) => d.name === "Lunac");
        if (c) {
          c.active || await u("spotify_transfer", { deviceId: c.id, play: !1 }), ge = c.id;
          break;
        }
      }
      $(t, a("music.local_login_ok"));
      break;
    }
  }
  await Gt(t);
}
async function Gl(t, e) {
  if (e) {
    try {
      await u("spotify_transfer", { deviceId: e, play: !1 }), Ue = !1;
    } catch (i) {
      $(t, C(i));
    }
    await Gt(t);
  }
}
async function Ja(t) {
  if (!(!(m != null && m.connected) || os || j)) {
    os = !0, vt = "", gt(t);
    try {
      j = await u("spotify_liked");
    } catch (e) {
      vt = C(e);
    } finally {
      os = !1, (M == null ? void 0 : M.kind) === "liked" && (ye = (j == null ? void 0 : j.items) ?? null, Tt = !1, Qe = vt), gt(t), we(t);
    }
  }
}
function ua(t, e) {
  if (Me = e, Le = !!e, Zt !== void 0 && (window.clearTimeout(Zt), Zt = void 0), !e) {
    H = null, Ot = !1, Ze = !1, Be(t), we(t);
    return;
  }
  Ot = !0, Be(t), we(t), Zt = window.setTimeout(() => void Yl(t, e), _c);
}
async function Yl(t, e) {
  Zt = void 0;
  try {
    const i = await u("spotify_search", { query: e });
    if (Me !== e) return;
    H = i;
  } catch (i) {
    if (Me !== e) return;
    H = null, $(t, C(i));
  } finally {
    Me === e && (Ot = !1, Be(t), we(t));
  }
}
function Oi(t) {
  const e = (ut == null ? void 0 : ut.items) ?? [], i = a("music.play_from_here"), s = e.length === 0 ? `<div class="music-empty">${a(ut ? "music.queue_empty" : "music.loading")}</div>` : e.map((n, c) => es(n, c, "play-uri", "", i)).join("");
  for (const n of ["#music-q", "#music-q-dd"]) I(t.querySelector(n), s);
}
async function Qa(t) {
  var e;
  try {
    ut = await u("spotify_queue"), $a = ((e = v == null ? void 0 : v.track) == null ? void 0 : e.id) ?? "";
  } catch (i) {
    ut = null, x(t.querySelector("#music-msg"), C(i));
  }
  Oi(t);
}
function xs(t) {
  const e = (v == null ? void 0 : v.track) ?? null, i = e != null && e.cover ? `<img src="${l(e.cover)}" alt="">` : "", s = [e == null ? void 0 : e.artists, e == null ? void 0 : e.album].filter(Boolean).join(" · ") || (v != null && v.active ? "" : a("music.no_device_hint"));
  I(t.querySelector("#music-pv-cover"), i), I(t.querySelector("#music-bnow-cover"), i), x(t.querySelector("#music-pv-title"), (e == null ? void 0 : e.name) || a("music.no_track")), x(t.querySelector("#music-bnow-n"), (e == null ? void 0 : e.name) || a("music.no_track")), x(t.querySelector("#music-pv-sub"), s), x(t.querySelector("#music-bnow-a"), s);
  const n = (e == null ? void 0 : e.duration_ms) ?? 0, c = Math.min((v == null ? void 0 : v.progress_ms) ?? 0, n || Number.MAX_SAFE_INTEGER), d = n > 0 ? Math.max(0, Math.min(100, c / n * 100)) : 0;
  if (Ta = c, Ma = Date.now(), ct < 0)
    for (const q of pt) q.style.setProperty("--seek-pct", `${d}%`);
  x(t.querySelector("#music-pv-pos"), F(c)), x(t.querySelector("#music-pv-dur"), F(n)), x(t.querySelector("#music-b-time"), `${F(c)} / ${F(n)}`);
  const b = v != null && v.playing ? h.pause : h.play;
  I(t.querySelector("#music-play"), b), I(t.querySelector("#music-b-play"), b);
  const g = Xa(), L = a(g === "shuffle" ? "music.mode_shuffle" : g === "repeat_one" ? "music.mode_repeat_one" : "music.mode_off");
  for (const q of [t.querySelector("#music-mode"), t.querySelector("#music-b-mode")])
    q && ($e(q, "data-mode", g), $e(q, "title", L), I(q, g === "repeat_one" ? h.repeat : h.shuffle));
  const _ = v && v.volume_percent >= 0 ? v.volume_percent : -1;
  for (const q of [t.querySelector("#music-vol"), t.querySelector("#music-b-vol")])
    q && _ >= 0 && document.activeElement !== q && (q.value = String(_), At(q, _));
  const T = !(v != null && v.active);
  t.querySelectorAll("#music-v-player .music-bar button, #music-nowbar button").forEach((q) => {
    q.id === "music-devices-btn" || q.id === "music-bnow" || q.id === "music-b-drawer" || (q.disabled = T);
  });
}
function Jl(t) {
  var n;
  if (!t.isConnected || !(v != null && v.playing) || ct >= 0) return;
  const e = ((n = v.track) == null ? void 0 : n.duration_ms) ?? 0;
  if (e <= 0) return;
  const i = Math.min(Ta + (Date.now() - Ma), e), s = Math.max(0, Math.min(100, i / e * 100));
  for (const c of pt) c.style.setProperty("--seek-pct", `${s}%`);
  x(t.querySelector("#music-pv-pos"), F(i)), x(t.querySelector("#music-b-time"), `${F(i)} / ${F(e)}`);
}
function Xa() {
  return (v == null ? void 0 : v.repeat) === "track" ? "repeat_one" : v != null && v.shuffle ? "shuffle" : "off";
}
function bs(t) {
  var e, i;
  A(t.querySelector("#music-q-wrap"), ve), A(t.querySelector("#music-q-dd"), ve), (e = t.querySelector("#music-queue-btn")) == null || e.classList.toggle("on", ve), (i = t.querySelector("#music-b-queue")) == null || i.classList.toggle("on", ve);
}
function Ji(t) {
  const e = t.querySelector("#music-lyr");
  if (!e) return;
  if (Is(), lt = -1, qt = [], Ft && (Ft = !1, Pe !== void 0 && (window.clearTimeout(Pe), Pe = void 0)), gs) {
    I(e, `<div class="music-empty">${a("music.lyrics_loading")}</div>`);
    return;
  }
  if (se != null && se.synced) {
    const s = zc(se.synced);
    if (s.length > 0) {
      qt = s;
      const n = l(a("music.seek_line"));
      I(
        e,
        `<div class="music-lyr-lines">${s.map((c, d) => `<div class="music-lyr-line" data-i="${d}" title="${n}">${l(c.text)}</div>`).join("")}</div>`
      );
      return;
    }
  }
  const i = ((se == null ? void 0 : se.plain) || "").trim();
  if (i) {
    I(e, `<div class="music-lyr-plain">${l(i)}</div>`);
    return;
  }
  if (se != null && se.instrumental) {
    I(e, `<div class="music-empty">${a("music.lyrics_instrumental")}</div>`);
    return;
  }
  I(e, `<div class="music-empty">${a("music.lyrics_none")}</div>`);
}
function Is() {
  di && (cancelAnimationFrame(di), di = 0);
}
function ra(t, e) {
  Is();
  const i = t.scrollTop, s = e - i;
  if (Math.abs(s) < 1) {
    t.scrollTop = e;
    return;
  }
  let n = 0;
  const c = (d) => {
    n || (n = d);
    const b = Math.min(1, (d - n) / wc);
    t.scrollTop = i + s * (1 - Math.pow(1 - b, 5)), di = b < 1 ? requestAnimationFrame(c) : 0;
  };
  di = requestAnimationFrame(c);
}
function is(t) {
  var g, L;
  if (qt.length === 0) return;
  const e = t.querySelector("#music-lyr");
  if (!e || !e.isConnected || e.clientHeight === 0) return;
  const i = ((v == null ? void 0 : v.progress_ms) ?? 0) / 1e3;
  let s = -1;
  for (let _ = 0; _ < qt.length && qt[_].at <= i; _++)
    s = _;
  if (s === lt) return;
  const n = Math.min(lt, s), c = Math.max(lt, s);
  for (let _ = Math.max(0, n + 1); _ <= c; _++)
    (g = e.querySelector(`.music-lyr-line[data-i="${_}"]`)) == null || g.classList.toggle("done", _ <= s);
  (L = e.querySelector(".music-lyr-line.on")) == null || L.classList.remove("on"), lt = s;
  const d = e.querySelector(`.music-lyr-line[data-i="${s}"]`);
  if (!d) {
    Ft || ra(e, 0);
    return;
  }
  if (d.classList.add("on"), Ft) return;
  const b = d.getBoundingClientRect().top - e.getBoundingClientRect().top + e.scrollTop;
  ra(e, Math.max(0, b));
}
function oa(t) {
  Ft = !0, Is(), Pe !== void 0 && window.clearTimeout(Pe), Pe = window.setTimeout(() => {
    Pe = void 0, Ft = !1, lt = -1, is(t);
  }, gc);
}
async function zi(t) {
  try {
    m = await u("music_config_get");
  } catch (e) {
    x(t.querySelector("#music-msg"), C(e));
    return;
  }
  !m.connected && R === "player" && (R = "default", ie(t)), $t(t), Lt(t);
}
async function Ql(t) {
  if (ys === t.id) return;
  ys = t.id, gs = !0, se = null;
  const e = Si;
  e && Ji(e);
  try {
    se = await u("lyrics_get", {
      title: t.name,
      artist: t.artists,
      album: t.album,
      duration: t.duration_ms / 1e3
    });
  } catch (i) {
    se = { found: !1, instrumental: !1, track: "", artist: "", album: "", duration: 0, synced: null, plain: null }, e && x(e.querySelector("#music-msg"), C(i));
  } finally {
    gs = !1, e && (Ji(e), is(e));
  }
}
async function Ds(t, e) {
  if (e === mt) {
    if (!t.isConnected) {
      ss();
      return;
    }
    if (Fc(t), m != null && m.connected) {
      if (!it) {
        if (!document.hidden && !Ii) {
          Ii = !0;
          try {
            if (v = await u("spotify_status"), e !== mt) return;
            Lt(t), xs(t), is(t), kl(t), pi(t), vi(t), it && Yi(t);
          } catch (i) {
            if (e !== mt) return;
            String(i).includes("ERR_NOT_CONNECTED") ? await zi(t) : (x(t.querySelector("#music-msg"), C(i)), Yi(t), it && Ya(t));
          } finally {
            Ii = !1;
          }
        }
        ve && (v != null && v.track) && v.track.id !== $a && Qa(t);
      }
      v != null && v.track && Ql(v.track);
    }
    e === mt && (Ye = window.setTimeout(() => void Ds(t, e), $c));
  }
}
function ss() {
  Ye !== void 0 && (window.clearTimeout(Ye), Ye = void 0), ot !== void 0 && (window.clearTimeout(ot), ot = void 0), Di !== void 0 && (window.clearInterval(Di), Di = void 0), mt++, Ii = !1;
}
function Ls(t) {
  ss();
  const e = mt;
  Ye = window.setTimeout(() => void Ds(t, e), 200), Di = window.setInterval(() => Jl(t), kc);
}
const Xl = 2e3;
let da = 0;
function Kl(t) {
  const e = Math.max(400, Xl - (Date.now() - da));
  ot !== void 0 && window.clearTimeout(ot), ot = window.setTimeout(() => {
    ot = void 0, !(!t.isConnected || document.hidden) && (da = Date.now(), Ye !== void 0 && (window.clearTimeout(Ye), Ye = void 0), Ye = window.setTimeout(() => void Ds(t, mt), 0));
  }, e);
}
function Zl() {
  if (Un) return;
  Un = !0, document.addEventListener("visibilitychange", () => {
    const e = Si;
    !e || !e.isConnected || (document.hidden ? ss() : Ls(e));
  });
  const t = (e) => {
    const i = Si;
    if (!i || !i.isConnected || document.hidden) return;
    const s = e.target;
    !s || !i.contains(s) || Kl(i);
  };
  document.addEventListener("click", t, !0), document.addEventListener("input", t, !0), document.addEventListener("change", t, !0);
}
function vi(t) {
  document.getElementById("plugin-titlebar") && (bt !== void 0 && window.clearTimeout(bt), bt = window.setTimeout(() => void eu(t), 80));
}
async function eu(t) {
  if (bt = void 0, !document.getElementById("plugin-titlebar")) return;
  let e = vc, i = bc;
  if (Zi()) {
    const n = t.closest(".plugin-result"), c = n == null ? void 0 : n.closest("#results-list");
    if (!n || !c) return;
    const d = getComputedStyle(c), b = parseFloat(d.paddingTop || "0") + parseFloat(d.paddingBottom || "0"), g = window.innerHeight - c.clientHeight;
    i = Math.round(g + b + n.getBoundingClientRect().height), e = hc;
  }
  const s = `${e}x${i}`;
  if (s !== Ss)
    try {
      await u("plugin_window_resize", { width: e, height: i }), Ss = s;
    } catch {
    }
}
async function iu(t) {
  var je, Jt, Qt, Rs, Ns, Ps, Bs, Os, zs, Ws, Hs, Fs, js, Us, Vs, Gs, Ys, Js, Qs, Xs, Ks, Zs, en, tn, sn, nn, an, cn, ln, un, rn, on, dn, mn, pn, fn, vn, bn, hn, yn, gn, _n, wn, Sn, kn, $n, xn, Ln, En, qn, Tn, Mn, Cn, An, In, Dn, Rn, Nn, Pn, Bn, On;
  if (ga) return bl(t);
  const e = t.querySelector(".music-root");
  if (!e) return;
  Si = e, Zl(), R = "default", Ti = null, Mi = !1, Kt = null, ve = !1, Ss = "", tt = !1, ai = !1, Bt = ["a", "b"], Ts = null, ws = null, Ri = "", Ni = 0, j = null, vt = "", _s = null, zt.clear(), ci.clear(), gi.clear(), re = "playlist", M = null, ye = null, Tt = !1, Qe = "", yt = null, Ue = !1, Z = null, ge = "", Me = "", H = null, Ot = !1, Le = !1, Ze = !1, Ie = "tracks", pt = [], ne = !1, ce = null, Ui = !1, Wt = "", Ce = "", qe = !1, Ne.clear(), _i.clear(), De = !1, Y = null, Ht = !1, st = "", he = null, wi = "", Mt = null, Dt(), de !== void 0 && (window.clearTimeout(de), de = void 0), S = null, rt = !1, te = -1, Ct = [], Rt();
  const i = Rc();
  _e = (i == null ? void 0 : i.queue) ?? [], K = i ? i.index : -1, ke = (i == null ? void 0 : i.position_ms) ?? 0;
  const s = (r) => x(e.querySelector("#music-msg"), r), n = (r) => e.querySelector(r);
  dt && (dt(), dt = null), dt = await Es("spotify-auth", (r) => {
    e.isConnected && (r.payload.ok ? (s(a("music.auth_ok")), zi(e).then(() => {
      Ls(e), Gi(e, !0);
    })) : s(r.payload.message || a("music.auth_failed")));
  });
  const c = () => {
    R = "player", ie(e);
  }, d = () => {
    R = "default", ie(e);
  }, b = () => {
    R = "settings", ie(e);
  };
  (je = n("#music-setup-toggle")) == null || je.addEventListener("click", b), (Jt = n("#music-resume")) == null || Jt.addEventListener("click", () => void jl(e)), (Qt = n("#music-set-back")) == null || Qt.addEventListener("click", d), (Rs = n("#music-set-tuning")) == null || Rs.addEventListener("click", () => {
    R = "tuning", ie(e);
  }), (Ns = n("#music-tuning-on")) == null || Ns.addEventListener("click", () => {
    f && ul(e, !f.enabled);
  }), Pa(e), (Ps = n("#music-curve-open")) == null || Ps.addEventListener("click", () => void hl(e));
  const g = (r, o, p, k) => {
    var w;
    const y = n(r);
    y == null || y.addEventListener("input", (D) => {
      const W = Number.parseFloat(D.target.value);
      if (!Number.isFinite(W)) return;
      k(W);
      const fe = e.querySelector(o);
      fe && (fe.value = U(W, 1)), Pi(e);
    }), y == null || y.addEventListener("change", (D) => {
      const W = Number.parseFloat(D.target.value);
      Number.isFinite(W) && k(W), X(e);
    }), (w = n(o)) == null || w.addEventListener("change", (D) => {
      const W = D.target, fe = Number.parseFloat(W.value.trim());
      if (!Number.isFinite(fe)) {
        W.value = U(p(), 1);
        return;
      }
      fe !== p() && (k(fe), fs(e));
    });
  };
  g("#music-preamp-range", "#music-tune-preamp", () => bi, (r) => bi = r), g("#music-bass-range", "#music-tune-bass", () => hi, (r) => hi = r), g("#music-treble-range", "#music-tune-treble", () => yi, (r) => yi = r), (Bs = n("#music-tuning-user-presets")) == null || Bs.addEventListener("click", (r) => {
    var y;
    const o = r.target.closest(".music-preset-user"), p = o == null ? void 0 : o.dataset.preset;
    if (!p) return;
    const k = ((y = r.target.closest("[data-act]")) == null ? void 0 : y.dataset.act) ?? "use";
    k === "rename" ? (Ve = { mode: "rename", from: p, name: p }, ae(e), setTimeout(() => {
      var w;
      return (w = e.querySelector("#music-preset-name")) == null ? void 0 : w.select();
    }, 0)) : k === "delete" ? (Ve = { mode: "delete", name: p }, ae(e)) : rl(e, p);
  }), (Os = n("#music-preset-save")) == null || Os.addEventListener("click", () => {
    var o;
    if (!f) return;
    Ve = { mode: "save", name: (o = f.user_presets) != null && o.includes(f.preset) ? f.preset : "", overwrite: !1 }, ae(e), setTimeout(() => {
      var p;
      return (p = e.querySelector("#music-preset-name")) == null ? void 0 : p.select();
    }, 0);
  }), (zs = n("#music-preset-cancel")) == null || zs.addEventListener("click", () => {
    Ve = null, ae(e);
  }), (Ws = n("#music-preset-ok")) == null || Ws.addEventListener("click", () => void ea(e)), (Hs = n("#music-preset-name")) == null || Hs.addEventListener("keydown", (r) => {
    r.key === "Enter" ? (r.preventDefault(), ea(e)) : r.key === "Escape" && (r.preventDefault(), Ve = null, ae(e));
  }), (Fs = n("#music-preset-import")) == null || Fs.addEventListener("click", () => void ol(e)), (js = n("#music-preset-export")) == null || js.addEventListener("click", () => void ml(e));
  const L = () => n("#music-delay-range");
  (Us = L()) == null || Us.addEventListener("input", (r) => {
    const o = Number.parseFloat(r.target.value);
    if (!Number.isFinite(o)) return;
    be = Math.min(us, Math.max(0, o));
    const p = e.querySelector("#music-delay-num");
    p && (p.value = U(be, 1)), Pi(e);
  }), (Vs = L()) == null || Vs.addEventListener("change", (r) => {
    const o = Number.parseFloat(r.target.value);
    Number.isFinite(o) && (be = Math.min(us, Math.max(0, o))), X(e);
  }), (Gs = n("#music-delay-num")) == null || Gs.addEventListener("change", (r) => {
    const o = r.target, p = Number.parseFloat(o.value.trim());
    if (!Number.isFinite(p) || p < 0 || p > us) {
      o.value = U(be, 1);
      return;
    }
    p !== be && (be = p, fs(e));
  }), (Ys = n("#music-copy-list")) == null || Ys.addEventListener("click", (r) => {
    const o = r.target.closest("[data-act]");
    if (!o) return;
    const p = Number(o.dataset.i), k = o.dataset.act;
    if (k === "menu") {
      const y = o.dataset.side === "to" ? "to" : "from";
      G = (G == null ? void 0 : G.row) === p && G.side === y ? null : { row: p, side: y }, Ia(e);
    } else if (k === "pick") {
      const y = ft[p], w = Number(o.dataset.ch);
      if (!y || !Number.isInteger(w)) return;
      o.dataset.side === "to" ? y.to = w : y.from = w, G = null, X(e);
    } else k === "del" && (ft.splice(p, 1), (G == null ? void 0 : G.row) === p ? G = null : G && G.row > p && (G.row -= 1), X(e));
  }), (Js = n("#music-copy-add")) == null || Js.addEventListener("click", () => {
    const r = Math.max(2, (f == null ? void 0 : f.channels) || 2);
    ft.push({ from: 0, to: Math.min(1, r - 1) }), X(e);
  }), (Qs = n("#music-conv-pick")) == null || Qs.addEventListener("click", () => void dl(e)), (Xs = n("#music-conv-clear")) == null || Xs.addEventListener("click", () => {
    Nt = null, X(e);
  }), (Ks = n("#music-ab-save-a")) == null || Ks.addEventListener("click", () => void Kn(e, "a")), (Zs = n("#music-ab-save-b")) == null || Zs.addEventListener("click", () => void Kn(e, "b")), (en = n("#music-ab-play")) == null || en.addEventListener("click", (r) => {
    const o = r.target.closest("[data-pos]"), p = Number(o == null ? void 0 : o.dataset.pos);
    (p === 1 || p === 2) && al(e, p);
  }), (tn = n("#music-ab-blind")) == null || tn.addEventListener("click", () => {
    tt = !tt, ai = !1, Bt = tt && Math.random() < 0.5 ? ["b", "a"] : ["a", "b"], ki(e);
  }), (sn = n("#music-ab-reveal")) == null || sn.addEventListener("click", () => {
    ai = !0, ki(e);
  });
  const _ = () => n("#music-tuning-filters");
  (nn = _()) == null || nn.addEventListener("click", (r) => {
    const o = r.target.closest("[data-act]"), p = o == null ? void 0 : o.closest(".music-tune-row"), k = Number(p == null ? void 0 : p.dataset.i), y = J[k];
    if (!o || !p || !y) return;
    const w = o.dataset.act;
    if (w === "on")
      y.on = !y.on, X(e);
    else if (w === "del")
      J.splice(k, 1), oe === k ? oe = -1 : oe > k && (oe -= 1), X(e);
    else if (w === "kind")
      oe = oe === k ? -1 : k, Da(e);
    else if (w === "pick") {
      const D = o.dataset.kind;
      if (!D) return;
      ll(y, D, (f == null ? void 0 : f.kinds) ?? []), oe = -1, X(e);
    }
  }), (an = _()) == null || an.addEventListener("input", (r) => {
    var fe;
    const o = r.target;
    if (!(o instanceof HTMLInputElement) || o.type !== "range") return;
    const p = o.dataset.f, k = o.closest(".music-tune-row"), y = J[Number(k == null ? void 0 : k.dataset.i)];
    if (!p || !y) return;
    const w = Number.parseFloat(o.value);
    if (!Number.isFinite(w)) return;
    if (p === "gain_db") y.gain_db = w;
    else if (p === "q") y.q = w;
    else return;
    const D = k == null ? void 0 : k.querySelector(`input.music-tune-num[data-f="${p}"]`);
    D && (D.value = ms(y, p));
    const W = (fe = o.closest(".music-tune-slider")) == null ? void 0 : fe.querySelector("em");
    W && (W.textContent = ms(y, p)), Pt = !0, Vi(e), Pi(e);
  }), (cn = _()) == null || cn.addEventListener("change", (r) => {
    var W;
    const o = r.target, p = (W = o == null ? void 0 : o.dataset) == null ? void 0 : W.f;
    if (!p) return;
    const k = o.closest(".music-tune-row"), y = J[Number(k == null ? void 0 : k.dataset.i)];
    if (!y) return;
    o.type === "range" && (Pt = !1);
    const w = Number.parseFloat(o.value.trim());
    if (!Number.isFinite(w)) {
      o.value = ms(y, p);
      return;
    }
    let D = !1;
    if (p === "freq_hz")
      D = w !== y.freq_hz, y.freq_hz = w;
    else if (p === "gain_db")
      D = w !== y.gain_db, y.gain_db = w;
    else if (p === "q")
      D = w !== y.q, y.q = w;
    else
      return;
    !D && o.type !== "range" || (o.type === "range" ? X(e) : fs(e));
  }), (ln = n("#music-tune-add")) == null || ln.addEventListener("click", () => {
    J.push(Cc()), X(e);
  }), (un = n("#music-avatar")) == null || un.addEventListener("click", () => {
    R !== "default" && (R = "default", ie(e)), Mi = !Mi, $t(e);
  }), (rn = n("#music-bnow")) == null || rn.addEventListener("click", c);
  const T = (r) => {
    ne !== r && (ne = r, xt = !1, r ? (!Ee && (v != null && v.playing) && u("spotify_control", { action: "pause" }).catch(() => {
    }), Ze = !1, Le = !1, M = null, ye = null, Qe = "", ce = null, Y = null, Wt = "", st = "", Mt = null, he = null) : (Dt(), wi = "", de !== void 0 && (window.clearTimeout(de), de = void 0), re = "playlist", S != null && S.path && !Ee && ii(e)), ie(e), Lt(e), me(e), r && (Ha(e), Ut(e), u("media_scan_status").then((o) => {
      !ne || !e.isConnected || (Mt = o, o.running && Fa(e), Oe(e));
    }).catch(() => {
    })));
  }, q = (r) => {
    if (r === "tuning") {
      R = "tuning", ie(e);
      return;
    }
    R = "default", T(r === "local"), ie(e);
  }, P = Yc(e);
  P == null || P.addEventListener("click", (r) => {
    const o = r.target.closest(".music-tb-seg"), p = o == null ? void 0 : o.dataset.seg;
    p && q(p);
  }), (on = n("#music-local-add")) == null || on.addEventListener("click", () => {
    De = !De, ei(e);
  }), (dn = n("#music-local-list")) == null || dn.addEventListener("click", () => Cl(e)), (mn = n("#music-local-del")) == null || mn.addEventListener("click", () => Al(e)), (pn = n("#music-local-editdone")) == null || pn.addEventListener("click", () => void Il(e)), (fn = n("#music-local-scan")) == null || fn.addEventListener("click", () => void $s(e)), (vn = n("#music-main")) == null || vn.addEventListener("input", (r) => {
    const o = r.target;
    (o == null ? void 0 : o.id) === "music-mt-q" && Ol(e, o.value.trim());
  }), (bn = n("#music-l-prev")) == null || bn.addEventListener("click", () => void ti(e, -1, !1)), (hn = n("#music-l-next")) == null || hn.addEventListener("click", () => void ti(e, 1, !1)), (yn = n("#music-l-play")) == null || yn.addEventListener("click", () => void na(e)), (gn = n("#music-l-stop")) == null || gn.addEventListener("click", () => void ii(e)), (_n = n("#music-b-drawer")) == null || _n.addEventListener("click", () => {
    xt = !0, pi(e), me(e);
  }), (wn = n("#music-l-drawer")) == null || wn.addEventListener("click", () => {
    xt = !1, pi(e), me(e);
  });
  const N = n("#music-l-vol");
  N == null || N.addEventListener("input", () => {
    At(N, Number(N.value)), aa(e, Number(N.value) / 100);
  });
  const ze = () => {
    const r = ["off", "shuffle", "repeat_all", "repeat_one"];
    ee = r[(r.indexOf(ee) + 1) % r.length], Oc(ee), me(e), $(e, Ms());
  };
  (Sn = n("#music-l-mode")) == null || Sn.addEventListener("click", ze);
  const Ae = (r, o) => {
    const p = (w) => {
      const D = r.getBoundingClientRect();
      return Math.max(0, Math.min(1, (w - D.left) / Math.max(1, D.width)));
    }, k = (w) => {
      te = w, r.style.setProperty("--seek-pct", `${w * 100}%`), o(w);
    };
    r.addEventListener("pointerdown", (w) => {
      if (!(((S == null ? void 0 : S.duration_ms) ?? 0) <= 0)) {
        try {
          r.setPointerCapture(w.pointerId);
        } catch {
        }
        r.classList.add("music-dragging"), k(p(w.clientX));
      }
    }), r.addEventListener("pointermove", (w) => {
      te < 0 || k(p(w.clientX));
    });
    const y = (w) => {
      if (te < 0) return;
      const D = te;
      te = -1, r.classList.remove("music-dragging");
      try {
        r.releasePointerCapture(w.pointerId);
      } catch {
      }
      Bl(e, Math.round(((S == null ? void 0 : S.duration_ms) ?? 0) * D));
    };
    r.addEventListener("pointerup", y), r.addEventListener("pointercancel", y);
  }, pe = n("#music-lbp");
  pe && Ae(pe, (r) => {
    const o = (S == null ? void 0 : S.duration_ms) ?? 0;
    x(pe.querySelector(".music-progress-tip"), mi(o * r));
    const p = e.querySelector("#music-l-time");
    p && x(p, `${F(o * r)} / ${F(o)}`);
  });
  const We = async () => {
    var r;
    if (!S || !S.path) {
      const o = ((r = _e[K]) == null ? void 0 : r.path) ?? "";
      if (!o || !await Vt(e, o, ke)) return;
    }
    R = "lplayer", ie(e);
  };
  (kn = n("#music-lnow")) == null || kn.addEventListener("click", () => void We()), ($n = n("#music-lp-prev")) == null || $n.addEventListener("click", () => void ti(e, -1, !1)), (xn = n("#music-lp-next")) == null || xn.addEventListener("click", () => void ti(e, 1, !1)), (Ln = n("#music-lp-play")) == null || Ln.addEventListener("click", () => void na(e)), (En = n("#music-lp-stop")) == null || En.addEventListener("click", () => void ii(e)), (qn = n("#music-lp-mode")) == null || qn.addEventListener("click", ze);
  const V = n("#music-lp-vol");
  V == null || V.addEventListener("input", () => {
    At(V, Number(V.value)), aa(e, Number(V.value) / 100);
  });
  const _t = n("#music-lp-progress");
  _t && Ae(_t, (r) => {
    const o = (S == null ? void 0 : S.duration_ms) ?? 0;
    x(_t.querySelector(".music-progress-tip"), mi(o * r));
    const p = e.querySelector("#music-lp-time");
    p && x(p, `${F(o * r)} / ${F(o)}`);
  });
  const ns = (r) => {
    var o;
    !e.isConnected || !Zi() || (o = r.target) != null && o.closest("#plugin-close") && (r.stopPropagation(), r.preventDefault(), R === "lplayer" ? d() : Xc(e));
  };
  document.addEventListener("click", ns, !0), (Tn = n("#music-fields-toggle")) == null || Tn.addEventListener("click", () => {
    Ti = !(Ti ?? !(m != null && m.builtin)), $t(e);
  }), (Mn = n("#music-copy-redirect")) == null || Mn.addEventListener("click", () => {
    const r = (m == null ? void 0 : m.redirect_uri) || "";
    r && rc(r).then(() => s(a("music.copied"))).catch(() => {
    });
  });
  for (const r of e.querySelectorAll("#music-quality .music-seg-btn"))
    r.addEventListener("click", () => {
      Kt = Number(r.dataset.q), $t(e);
    });
  (Cn = n("#music-set-save")) == null || Cn.addEventListener("click", async () => {
    try {
      m = await u("music_config_set", { librespotBitrate: Kt }), Kt = null, s(a("music.saved")), $t(e), Lt(e);
    } catch (r) {
      s(C(r));
    }
  }), (An = n("#music-save")) == null || An.addEventListener("click", async () => {
    var k, y, w, D;
    const r = ((k = n("#music-client-id")) == null ? void 0 : k.value.trim()) ?? "", o = ((y = n("#music-port")) == null ? void 0 : y.value.trim()) ?? "", p = Number(o);
    if (!r) {
      s(a("music.err_no_client_id"));
      return;
    }
    if (!Number.isInteger(p) || p < 1024 || p > 65535) {
      s(a("music.err_bad_port"));
      return;
    }
    try {
      m = await u("music_config_set", {
        clientId: r,
        port: p,
        // 本机播放那两项**一起交上去**（留空 = 自动探测 / 直连，都是合法值）
        librespotPath: ((w = n("#music-librespot")) == null ? void 0 : w.value.trim()) ?? "",
        librespotProxy: ((D = n("#music-librespot-proxy")) == null ? void 0 : D.value.trim()) ?? ""
        // 音质**不在这里提交**（2026-10-01 起它归设置页，那个页面有自己的「保存」）：
        // 不传 = `None` = 别动，宿主本来就是这个语义。把两页的保存混在一处，
        // 就会出现「在设置页点了 320、回连接卡片点保存、结果把它一起落盘了」。
      }), s(a("music.saved")), $t(e), Lt(e), Z = null;
    } catch (W) {
      s(C(W));
    }
  }), (In = n("#music-connect")) == null || In.addEventListener("click", async () => {
    var p, k;
    const r = ((p = n("#music-client-id")) == null ? void 0 : p.value.trim()) ?? "", o = Number(((k = n("#music-port")) == null ? void 0 : k.value.trim()) ?? "");
    if (r && Number.isInteger(o) && o >= 1024)
      try {
        m = await u("music_config_set", {
          clientId: r,
          port: o,
          librespotPath: null,
          librespotProxy: null,
          // 串流质量同上：这条路径只是「先落盘再连」，别动用户选的档
          librespotBitrate: null
        });
      } catch (y) {
        s(C(y));
        return;
      }
    try {
      const y = await u("spotify_connect");
      s(a("music.browser_hint")), await uc(y);
    } catch (y) {
      s(C(y));
    }
  }), (Dn = n("#music-disconnect")) == null || Dn.addEventListener("click", async () => {
    try {
      await u("spotify_disconnect"), v = null, se = null, ys = "", _s = null, zt.clear(), gi.clear(), ut = null, ve = !1, M = null, ye = null, Qe = "", H = null, Me = "", Le = !1, Ze = !1, yt = null, R = "default", await zi(e), ie(e), Oi(e), s(a("music.disconnected"));
    } catch (r) {
      s(C(r));
    }
  });
  const Xe = (r) => {
    var y;
    const o = (y = r.target) == null ? void 0 : y.closest("[data-act]");
    if (!o) return;
    const p = o.dataset.kind || "", k = o.dataset.id || "";
    switch (o.dataset.act) {
      case "side-tab":
        re = o.dataset.tab || "playlist", gt(e), Ga(e, re);
        break;
      case "search-tab":
        Ie = o.dataset.tab || "tracks", we(e);
        break;
      case "open":
        zl(e, p, k);
        break;
      case "main-track":
        Wl(e, Number(o.dataset.i || "0"));
        break;
      case "main-play-all":
        M && la(e, M.kind, M.id);
        break;
      case "dd-track":
        o.dataset.uri && ma(e, o.dataset.uri);
        break;
      case "play-uri":
        o.dataset.uri && ma(e, o.dataset.uri);
        break;
      case "search-all":
        Le = !1, Ze = !0, Be(e), we(e);
        break;
      case "dev-pick":
        Gl(e, k);
        break;
      case "local-toggle":
        Ul(e);
        break;
      case "local-login":
        Vl(e);
        break;
      // ── 本地音乐页（2026-10-01）──
      case "media-root": {
        const w = o.dataset.path || "";
        if (qe) {
          w && (Ne.has(w) ? Ne.delete(w) : Ne.add(w)), at(e);
          break;
        }
        Ce = w, at(e), Ut(e);
        break;
      }
      case "media-scan":
        $s(e);
        break;
      // `＋` 浮层里的两行（2026-10-01）：目录 vs 播放列表文件。
      // **先关浮层再干活** —— 目录对话框是模态的，浮层留着会在对话框背后一闪一闪。
      case "media-add-dir":
        De = !1, ei(e), Tl(e);
        break;
      case "media-add-list":
        De = !1, ei(e), Rl(e);
        break;
      case "media-list-close":
        Nl(e);
        break;
      case "local-track":
        Pl(e, Number(o.dataset.i || "0"));
        break;
    }
  };
  for (const r of ["#music-side-list", "#music-side-tabs", "#music-main", "#music-search-dd", "#music-dev-dd", "#music-q", "#music-q-dd", "#music-local-add-dd"])
    (Rn = n(r)) == null || Rn.addEventListener("click", Xe);
  (Nn = n("#music-side-list")) == null || Nn.addEventListener("dblclick", (r) => {
    var y;
    const o = (y = r.target) == null ? void 0 : y.closest('[data-act="open"]');
    if (!o) return;
    const p = o.dataset.kind || "", k = o.dataset.id || "";
    k && la(e, p, k);
  }), (Pn = n("#music-devices-btn")) == null || Pn.addEventListener("click", () => {
    Ue = !Ue, jt(e), Ue && Gt(e);
  }), ca(e), (Bn = n("#music-split")) == null || Bn.addEventListener("pointerdown", (r) => {
    var w;
    r.preventDefault();
    const o = r.clientX, p = ((w = n("#music-side")) == null ? void 0 : w.getBoundingClientRect().width) ?? li, k = (D) => {
      li = Math.min(Sa, Math.max(wa, Math.round(p + D.clientX - o))), ca(e);
    }, y = () => {
      window.removeEventListener("pointermove", k), window.removeEventListener("pointerup", y), document.body.classList.remove("music-resizing");
    };
    document.body.classList.add("music-resizing"), window.addEventListener("pointermove", k), window.addEventListener("pointerup", y);
  }), document.addEventListener("pointerdown", (r) => {
    const o = r.target;
    o && (Ue && !o.closest("#music-dev-dd") && !o.closest("#music-devices-btn") && (Ue = !1, jt(e)), Le && !o.closest(".music-search-wrap") && (Le = !1, Be(e)), De && !o.closest("#music-local-add-dd") && !o.closest("#music-local-add") && (De = !1, ei(e)), ve && !o.closest("#music-q-dd") && !o.closest("#music-b-queue") && !o.closest("#music-queue-btn") && (ve = !1, bs(e)));
  });
  const O = n("#music-search");
  O == null || O.addEventListener("input", () => ua(e, O.value.trim())), O == null || O.addEventListener("focus", () => {
    Me && (Le = !0, Be(e));
  }), O == null || O.addEventListener("keydown", (r) => {
    if (r.key === "Enter" && Me) {
      Le = !1, Ze = !0, Be(e), we(e);
      return;
    }
    r.key === "Escape" && (O.value = "", ua(e, ""));
  }), document.body.addEventListener("mouseenter", () => vi(e)), document.body.addEventListener("mouseleave", () => vi(e));
  const He = async (r, o) => {
    r === "play" && await xi(e, "spotify");
    try {
      await u("spotify_control", { action: r, value: o });
    } catch (p) {
      s(C(p));
    }
  }, le = (r, o) => {
    var p;
    for (const k of r) (p = n(`#${k}`)) == null || p.addEventListener("click", o);
  };
  le(["music-queue-btn", "music-b-queue"], () => {
    ve = !ve, bs(e), Oi(e), ve ? Qa(e) : xs(e), vi(e);
  }), le(["music-prev", "music-b-prev"], () => void He("previous")), le(["music-next", "music-b-next"], () => void He("next")), le(["music-play", "music-b-play"], () => void He(v != null && v.playing ? "pause" : "play")), le(["music-dual-btn", "music-l-dual-btn"], () => {
    Ee = !Ee, Pc(Ee), Ee || (xt = !1), !Ee && !ne && S && ii(e), me(e), pi(e), $(e, a(Ee ? "music.dual_on" : "music.dual_off"));
  });
  let B = null, Q = !1;
  const xe = async (r) => {
    if (B = r, !Q) {
      Q = !0;
      try {
        for (; B !== null; ) {
          const o = B;
          B = null, await He("volume", o);
        }
      } finally {
        Q = !1;
      }
    }
  };
  for (const r of ["music-vol", "music-b-vol"])
    (On = n(`#${r}`)) == null || On.addEventListener("input", (o) => {
      const p = o.target, k = Number(p.value);
      At(p, k), xe(k);
    });
  le(["music-mode", "music-b-mode"], () => {
    const r = Xa();
    u("spotify_set_play_mode", { mode: r === "off" ? "shuffle" : r === "shuffle" ? "repeat_one" : "off" }).catch((p) => s(C(p)));
  }), pt = ["#music-pv-progress", "#music-bp"].map((r) => n(r)).filter((r) => !!r);
  for (const r of pt) {
    const o = (y) => {
      const w = r.getBoundingClientRect();
      return Math.max(0, Math.min(1, (y - w.left) / Math.max(1, w.width)));
    }, p = (y) => {
      var fe;
      ct = y;
      const w = `${y * 100}%`;
      for (const Ka of pt) Ka.style.setProperty("--seek-pct", w);
      const D = ((fe = v == null ? void 0 : v.track) == null ? void 0 : fe.duration_ms) ?? 0, W = F(D * y);
      x(r.querySelector(".music-progress-tip"), mi(D * y)), x(n("#music-pv-pos"), W), x(n("#music-b-time"), `${W} / ${F(D)}`);
    };
    r.addEventListener("pointerdown", (y) => {
      var w;
      if (!((((w = v == null ? void 0 : v.track) == null ? void 0 : w.duration_ms) ?? 0) <= 0)) {
        try {
          r.setPointerCapture(y.pointerId);
        } catch {
        }
        r.classList.add("music-dragging"), p(o(y.clientX));
      }
    }), r.addEventListener("pointermove", (y) => {
      ct < 0 || p(o(y.clientX));
    });
    const k = (y) => {
      var D;
      if (ct < 0) return;
      const w = ct;
      ct = -1, r.classList.remove("music-dragging");
      try {
        r.releasePointerCapture(y.pointerId);
      } catch {
      }
      He("seek", Math.round((((D = v == null ? void 0 : v.track) == null ? void 0 : D.duration_ms) ?? 0) * w));
    };
    r.addEventListener("pointerup", k), r.addEventListener("pointercancel", k);
  }
  const z = n("#music-lyr");
  let Fe = !1, wt = 0;
  z == null || z.addEventListener("wheel", () => oa(e), { passive: !0 }), z == null || z.addEventListener("pointerdown", (r) => {
    Fe = !1, wt = r.clientY, oa(e);
  }), z == null || z.addEventListener("pointermove", (r) => {
    Math.abs(r.clientY - wt) > 4 && (Fe = !0);
  }), z == null || z.addEventListener("click", (r) => {
    if (Fe) return;
    const o = r.target.closest(".music-lyr-line"), p = o ? qt[Number(o.dataset.i)] : void 0;
    p && He("seek", Math.round(p.at * 1e3));
  }), await zi(e), ie(e), xs(e), Ji(e), Oi(e), bs(e), Lt(e), await Ya(e), Ls(e), Gi(e);
}
async function ma(t, e) {
  await xi(t, "spotify");
  try {
    await u("spotify_play_uri", { uri: e, deviceId: ge || void 0 });
  } catch (i) {
    x(t.querySelector("#music-msg"), C(i));
  }
}
function tu() {
  ks(), Cs(), ss(), Si = null, Pe !== void 0 && (window.clearTimeout(Pe), Pe = void 0), bt !== void 0 && (window.clearTimeout(bt), bt = void 0), Dt(), de !== void 0 && (window.clearTimeout(de), de = void 0), Rt(), S != null && S.path && (ke = S.position_ms, Ki(), S = null, _e = [], K = -1, u("player_stop").catch(() => {
  })), dt && (dt(), dt = null), pt = [], xt = !1, Vc(), Qc();
}
window.__lunac_music_stop = tu;
const su = {
  id: "music",
  name: "音乐歌词",
  keywords: ["音乐", "歌词", "歌曲", "正在播放", "music", "lyrics", "spotify", "播放控制", "暂停", "下一首", "歌单", "播放列表"],
  description: "歌词自动抓取 (LRCLIB + 网易云兜底) + Spotify 播放控制 / 歌单 / 队列",
  icon: "🎵",
  badge: "music",
  // 「本插件一律在**悬浮窗**里打开」（2026-09-29 从 main.ts 的硬编码 `id === "music"` 改成声明）。
  // 为什么要声明而不是让宿主按 id 判：音乐已归入**拓展插件**，要能从市场独立打包分发
  // —— 磁盘插件的代码宿主没法写死，行为只能由插件自己声明（见 ai-spec §3.5「插件契约」）。
  // 这也是「用户 2026-09-28 定的：从 Lunac 进音乐界面时自动展开成独立界面」那条的执行点。
  permissions: ["window.float"],
  async execute() {
    return { type: "html", content: ga ? Wc() : Hc() };
  }
};
export {
  iu as attach,
  iu as attachMusicListeners,
  su as default,
  tu as detach,
  su as musicPlugin,
  tu as stopMusicPolling
};
