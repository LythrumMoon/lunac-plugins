function me(t, e, i, a) {
  if (typeof e == "function" ? t !== e || !a : !e.has(t)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? a : i === "a" ? a.call(t) : a ? a.value : e.get(t);
}
function fe(t, e, i, a, l) {
  if (typeof e == "function" ? t !== e || !0 : !e.has(t)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return e.set(t, i), i;
}
var j;
const m = "__TAURI_TO_IPC_KEY__";
function ve(t, e = !1) {
  return window.__TAURI_INTERNALS__.transformCallback(t, e);
}
async function n(t, e = {}, i) {
  return window.__TAURI_INTERNALS__.invoke(t, e, i);
}
function q(t, e = "asset") {
  return window.__TAURI_INTERNALS__.convertFileSrc(t, e);
}
class _e {
  get rid() {
    return me(this, j, "f");
  }
  constructor(e) {
    j.set(this, void 0), fe(this, j, e);
  }
  /**
   * Destroys and cleans up this resource from memory.
   * **You should not call any method on this object anymore and should drop any reference to it.**
   */
  async close() {
    return n("plugin:resources|close", {
      rid: this.rid
    });
  }
}
j = /* @__PURE__ */ new WeakMap();
var g;
(function(t) {
  t.WINDOW_RESIZED = "tauri://resize", t.WINDOW_MOVED = "tauri://move", t.WINDOW_CLOSE_REQUESTED = "tauri://close-requested", t.WINDOW_DESTROYED = "tauri://destroyed", t.WINDOW_FOCUS = "tauri://focus", t.WINDOW_BLUR = "tauri://blur", t.WINDOW_SCALE_FACTOR_CHANGED = "tauri://scale-change", t.WINDOW_THEME_CHANGED = "tauri://theme-changed", t.WINDOW_CREATED = "tauri://window-created", t.WINDOW_SUSPENDED = "tauri://suspended", t.WINDOW_RESUMED = "tauri://resumed", t.WEBVIEW_CREATED = "tauri://webview-created", t.DRAG_ENTER = "tauri://drag-enter", t.DRAG_OVER = "tauri://drag-over", t.DRAG_DROP = "tauri://drag-drop", t.DRAG_LEAVE = "tauri://drag-leave";
})(g || (g = {}));
async function se(t, e) {
  window.__TAURI_EVENT_PLUGIN_INTERNALS__.unregisterListener(t, e), await n("plugin:event|unlisten", {
    event: t,
    eventId: e
  });
}
async function H(t, e, i) {
  var a;
  const l = typeof (i == null ? void 0 : i.target) == "string" ? { kind: "AnyLabel", label: i.target } : (a = i == null ? void 0 : i.target) !== null && a !== void 0 ? a : { kind: "Any" };
  return n("plugin:event|listen", {
    event: t,
    target: l,
    handler: ve(e)
  }).then((f) => async () => se(t, f));
}
async function xe(t, e, i) {
  return H(t, (a) => {
    se(t, a.id), e(a);
  }, i);
}
async function N(t, e) {
  await n("plugin:event|emit", {
    event: t,
    payload: e
  });
}
async function ke(t, e, i) {
  await n("plugin:event|emit_to", {
    target: typeof t == "string" ? { kind: "AnyLabel", label: t } : t,
    event: e,
    payload: i
  });
}
class re {
  constructor(...e) {
    this.type = "Logical", e.length === 1 ? "Logical" in e[0] ? (this.width = e[0].Logical.width, this.height = e[0].Logical.height) : (this.width = e[0].width, this.height = e[0].height) : (this.width = e[0], this.height = e[1]);
  }
  /**
   * Converts the logical size to a physical one.
   * @example
   * ```typescript
   * import { LogicalSize } from '@tauri-apps/api/dpi';
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   *
   * const appWindow = getCurrentWindow();
   * const factor = await appWindow.scaleFactor();
   * const size = new LogicalSize(400, 500);
   * const physical = size.toPhysical(factor);
   * ```
   *
   * @since 2.0.0
   */
  toPhysical(e) {
    return new T(this.width * e, this.height * e);
  }
  [m]() {
    return {
      width: this.width,
      height: this.height
    };
  }
  toJSON() {
    return this[m]();
  }
}
class T {
  constructor(...e) {
    this.type = "Physical", e.length === 1 ? "Physical" in e[0] ? (this.width = e[0].Physical.width, this.height = e[0].Physical.height) : (this.width = e[0].width, this.height = e[0].height) : (this.width = e[0], this.height = e[1]);
  }
  /**
   * Converts the physical size to a logical one.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const appWindow = getCurrentWindow();
   * const factor = await appWindow.scaleFactor();
   * const size = await appWindow.innerSize(); // PhysicalSize
   * const logical = size.toLogical(factor);
   * ```
   */
  toLogical(e) {
    return new re(this.width / e, this.height / e);
  }
  [m]() {
    return {
      width: this.width,
      height: this.height
    };
  }
  toJSON() {
    return this[m]();
  }
}
class I {
  constructor(e) {
    this.size = e;
  }
  toLogical(e) {
    return this.size instanceof re ? this.size : this.size.toLogical(e);
  }
  toPhysical(e) {
    return this.size instanceof T ? this.size : this.size.toPhysical(e);
  }
  [m]() {
    return {
      [`${this.size.type}`]: {
        width: this.size.width,
        height: this.size.height
      }
    };
  }
  toJSON() {
    return this[m]();
  }
}
class oe {
  constructor(...e) {
    this.type = "Logical", e.length === 1 ? "Logical" in e[0] ? (this.x = e[0].Logical.x, this.y = e[0].Logical.y) : (this.x = e[0].x, this.y = e[0].y) : (this.x = e[0], this.y = e[1]);
  }
  /**
   * Converts the logical position to a physical one.
   * @example
   * ```typescript
   * import { LogicalPosition } from '@tauri-apps/api/dpi';
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   *
   * const appWindow = getCurrentWindow();
   * const factor = await appWindow.scaleFactor();
   * const position = new LogicalPosition(400, 500);
   * const physical = position.toPhysical(factor);
   * ```
   *
   * @since 2.0.0
   */
  toPhysical(e) {
    return new L(this.x * e, this.y * e);
  }
  [m]() {
    return {
      x: this.x,
      y: this.y
    };
  }
  toJSON() {
    return this[m]();
  }
}
class L {
  constructor(...e) {
    this.type = "Physical", e.length === 1 ? "Physical" in e[0] ? (this.x = e[0].Physical.x, this.y = e[0].Physical.y) : (this.x = e[0].x, this.y = e[0].y) : (this.x = e[0], this.y = e[1]);
  }
  /**
   * Converts the physical position to a logical one.
   * @example
   * ```typescript
   * import { PhysicalPosition } from '@tauri-apps/api/dpi';
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   *
   * const appWindow = getCurrentWindow();
   * const factor = await appWindow.scaleFactor();
   * const position = new PhysicalPosition(400, 500);
   * const physical = position.toLogical(factor);
   * ```
   *
   * @since 2.0.0
   */
  toLogical(e) {
    return new oe(this.x / e, this.y / e);
  }
  [m]() {
    return {
      x: this.x,
      y: this.y
    };
  }
  toJSON() {
    return this[m]();
  }
}
class $ {
  constructor(e) {
    this.position = e;
  }
  toLogical(e) {
    return this.position instanceof oe ? this.position : this.position.toLogical(e);
  }
  toPhysical(e) {
    return this.position instanceof L ? this.position : this.position.toPhysical(e);
  }
  [m]() {
    return {
      [`${this.position.type}`]: {
        x: this.position.x,
        y: this.position.y
      }
    };
  }
  toJSON() {
    return this[m]();
  }
}
class M extends _e {
  /**
   * Creates an Image from a resource ID. For internal use only.
   *
   * @ignore
   */
  constructor(e) {
    super(e);
  }
  /** Creates a new Image using RGBA data, in row-major order from top to bottom, and with specified width and height. */
  static async new(e, i, a) {
    return n("plugin:image|new", {
      rgba: V(e),
      width: i,
      height: a
    }).then((l) => new M(l));
  }
  /**
   * Creates a new image using the provided bytes by inferring the file format.
   * If the format is known, prefer [@link Image.fromPngBytes] or [@link Image.fromIcoBytes].
   *
   * Only `ico` and `png` are supported (based on activated feature flag).
   *
   * Note that you need the `image-ico` or `image-png` Cargo features to use this API.
   * To enable it, change your Cargo.toml file:
   * ```toml
   * [dependencies]
   * tauri = { version = "...", features = ["...", "image-png"] }
   * ```
   */
  static async fromBytes(e) {
    return n("plugin:image|from_bytes", {
      bytes: V(e)
    }).then((i) => new M(i));
  }
  /**
   * Creates a new image using the provided path.
   *
   * Only `ico` and `png` are supported (based on activated feature flag).
   *
   * Note that you need the `image-ico` or `image-png` Cargo features to use this API.
   * To enable it, change your Cargo.toml file:
   * ```toml
   * [dependencies]
   * tauri = { version = "...", features = ["...", "image-png"] }
   * ```
   */
  static async fromPath(e) {
    return n("plugin:image|from_path", { path: e }).then((i) => new M(i));
  }
  /** Returns the RGBA data for this image, in row-major order from top to bottom.  */
  async rgba() {
    return n("plugin:image|rgba", {
      rid: this.rid
    }).then((e) => new Uint8Array(e));
  }
  /** Returns the size of this image.  */
  async size() {
    return n("plugin:image|size", { rid: this.rid });
  }
}
function V(t) {
  return t == null ? null : typeof t == "string" ? t : t instanceof M ? t.rid : t;
}
var Z;
(function(t) {
  t[t.Critical = 1] = "Critical", t[t.Informational = 2] = "Informational";
})(Z || (Z = {}));
class Le {
  constructor(e) {
    this._preventDefault = !1, this.event = e.event, this.id = e.id;
  }
  preventDefault() {
    this._preventDefault = !0;
  }
  isPreventDefault() {
    return this._preventDefault;
  }
}
var X;
(function(t) {
  t.None = "none", t.Normal = "normal", t.Indeterminate = "indeterminate", t.Paused = "paused", t.Error = "error";
})(X || (X = {}));
function ce() {
  return new ue(window.__TAURI_INTERNALS__.metadata.currentWindow.label, {
    // @ts-expect-error `skip` is not defined in the public API but it is handled by the constructor
    skip: !0
  });
}
async function J() {
  return n("plugin:window|get_all_windows").then((t) => t.map((e) => new ue(e, {
    // @ts-expect-error `skip` is not defined in the public API but it is handled by the constructor
    skip: !0
  })));
}
const Y = ["tauri://created", "tauri://error"];
class ue {
  /**
   * Creates a new Window.
   * @example
   * ```typescript
   * import { Window } from '@tauri-apps/api/window';
   * const appWindow = new Window('my-label');
   * appWindow.once('tauri://created', function () {
   *  // window successfully created
   * });
   * appWindow.once('tauri://error', function (e) {
   *  // an error happened creating the window
   * });
   * ```
   *
   * @param label The unique window label. Must be alphanumeric: `a-zA-Z-/:_`.
   * @returns The {@link Window} instance to communicate with the window.
   */
  constructor(e, i = {}) {
    var a;
    this.label = e, this.listeners = /* @__PURE__ */ Object.create(null), i != null && i.skip || n("plugin:window|create", {
      options: {
        ...i,
        parent: typeof i.parent == "string" ? i.parent : (a = i.parent) === null || a === void 0 ? void 0 : a.label,
        label: e
      }
    }).then(async () => this.emit("tauri://created")).catch(async (l) => this.emit("tauri://error", l));
  }
  /**
   * Gets the Window associated with the given label.
   * @example
   * ```typescript
   * import { Window } from '@tauri-apps/api/window';
   * const mainWindow = Window.getByLabel('main');
   * ```
   *
   * @param label The window label.
   * @returns The Window instance to communicate with the window or null if the window doesn't exist.
   */
  static async getByLabel(e) {
    var i;
    return (i = (await J()).find((a) => a.label === e)) !== null && i !== void 0 ? i : null;
  }
  /**
   * Get an instance of `Window` for the current window.
   */
  static getCurrent() {
    return ce();
  }
  /**
   * Gets a list of instances of `Window` for all available windows.
   */
  static async getAll() {
    return J();
  }
  /**
   *  Gets the focused window.
   * @example
   * ```typescript
   * import { Window } from '@tauri-apps/api/window';
   * const focusedWindow = Window.getFocusedWindow();
   * ```
   *
   * @returns The Window instance or `undefined` if there is not any focused window.
   */
  static async getFocusedWindow() {
    for (const e of await J())
      if (await e.isFocused())
        return e;
    return null;
  }
  /**
   * Listen to an emitted event on this window.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const unlisten = await getCurrentWindow().listen<string>('state-changed', (event) => {
   *   console.log(`Got error: ${payload}`);
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @param event Event name. Must include only alphanumeric characters, `-`, `/`, `:` and `_`.
   * @param handler Event handler.
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async listen(e, i) {
    return this._handleTauriEvent(e, i) ? () => {
      const a = this.listeners[e];
      a.splice(a.indexOf(i), 1);
    } : H(e, i, {
      target: { kind: "Window", label: this.label }
    });
  }
  /**
   * Listen to an emitted event on this window only once.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const unlisten = await getCurrentWindow().once<null>('initialized', (event) => {
   *   console.log(`Window initialized!`);
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @param event Event name. Must include only alphanumeric characters, `-`, `/`, `:` and `_`.
   * @param handler Event handler.
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async once(e, i) {
    return this._handleTauriEvent(e, i) ? () => {
      const a = this.listeners[e];
      a.splice(a.indexOf(i), 1);
    } : xe(e, i, {
      target: { kind: "Window", label: this.label }
    });
  }
  /**
   * Emits an event to all {@link EventTarget|targets}.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().emit('window-loaded', { loggedIn: true, token: 'authToken' });
   * ```
   *
   * @param event Event name. Must include only alphanumeric characters, `-`, `/`, `:` and `_`.
   * @param payload Event payload.
   */
  async emit(e, i) {
    if (Y.includes(e)) {
      for (const a of this.listeners[e] || [])
        a({
          event: e,
          id: -1,
          payload: i
        });
      return;
    }
    return N(e, i);
  }
  /**
   * Emits an event to all {@link EventTarget|targets} matching the given target.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().emit('main', 'window-loaded', { loggedIn: true, token: 'authToken' });
   * ```
   * @param target Label of the target Window/Webview/WebviewWindow or raw {@link EventTarget} object.
   * @param event Event name. Must include only alphanumeric characters, `-`, `/`, `:` and `_`.
   * @param payload Event payload.
   */
  async emitTo(e, i, a) {
    if (Y.includes(i)) {
      for (const l of this.listeners[i] || [])
        l({
          event: i,
          id: -1,
          payload: a
        });
      return;
    }
    return ke(e, i, a);
  }
  /** @ignore */
  _handleTauriEvent(e, i) {
    return Y.includes(e) ? (e in this.listeners ? this.listeners[e].push(i) : this.listeners[e] = [i], !0) : !1;
  }
  // Getters
  /**
   * The scale factor that can be used to map physical pixels to logical pixels.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const factor = await getCurrentWindow().scaleFactor();
   * ```
   *
   * @returns The window's monitor scale factor.
   */
  async scaleFactor() {
    return n("plugin:window|scale_factor", {
      label: this.label
    });
  }
  /**
   * The position of the top-left hand corner of the window's client area relative to the top-left hand corner of the desktop.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const position = await getCurrentWindow().innerPosition();
   * ```
   *
   * @returns The window's inner position.
   */
  async innerPosition() {
    return n("plugin:window|inner_position", {
      label: this.label
    }).then((e) => new L(e));
  }
  /**
   * The position of the top-left hand corner of the window relative to the top-left hand corner of the desktop.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const position = await getCurrentWindow().outerPosition();
   * ```
   *
   * @returns The window's outer position.
   */
  async outerPosition() {
    return n("plugin:window|outer_position", {
      label: this.label
    }).then((e) => new L(e));
  }
  /**
   * The physical size of the window's client area.
   * The client area is the content of the window, excluding the title bar and borders.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const size = await getCurrentWindow().innerSize();
   * ```
   *
   * @returns The window's inner size.
   */
  async innerSize() {
    return n("plugin:window|inner_size", {
      label: this.label
    }).then((e) => new T(e));
  }
  /**
   * The physical size of the entire window.
   * These dimensions include the title bar and borders. If you don't want that (and you usually don't), use inner_size instead.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const size = await getCurrentWindow().outerSize();
   * ```
   *
   * @returns The window's outer size.
   */
  async outerSize() {
    return n("plugin:window|outer_size", {
      label: this.label
    }).then((e) => new T(e));
  }
  /**
   * Gets the window's current fullscreen state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const fullscreen = await getCurrentWindow().isFullscreen();
   * ```
   *
   * @returns Whether the window is in fullscreen mode or not.
   */
  async isFullscreen() {
    return n("plugin:window|is_fullscreen", {
      label: this.label
    });
  }
  /**
   * Gets the window's current minimized state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const minimized = await getCurrentWindow().isMinimized();
   * ```
   */
  async isMinimized() {
    return n("plugin:window|is_minimized", {
      label: this.label
    });
  }
  /**
   * Gets the window's current maximized state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const maximized = await getCurrentWindow().isMaximized();
   * ```
   *
   * @returns Whether the window is maximized or not.
   */
  async isMaximized() {
    return n("plugin:window|is_maximized", {
      label: this.label
    });
  }
  /**
   * Gets the window's current focus state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const focused = await getCurrentWindow().isFocused();
   * ```
   *
   * @returns Whether the window is focused or not.
   */
  async isFocused() {
    return n("plugin:window|is_focused", {
      label: this.label
    });
  }
  /**
   * Gets the window's current decorated state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const decorated = await getCurrentWindow().isDecorated();
   * ```
   *
   * @returns Whether the window is decorated or not.
   */
  async isDecorated() {
    return n("plugin:window|is_decorated", {
      label: this.label
    });
  }
  /**
   * Gets the window's current resizable state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const resizable = await getCurrentWindow().isResizable();
   * ```
   *
   * @returns Whether the window is resizable or not.
   */
  async isResizable() {
    return n("plugin:window|is_resizable", {
      label: this.label
    });
  }
  /**
   * Gets the window's native maximize button state.
   *
   * #### Platform-specific
   *
   * - **Linux / iOS / Android:** Unsupported.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const maximizable = await getCurrentWindow().isMaximizable();
   * ```
   *
   * @returns Whether the window's native maximize button is enabled or not.
   */
  async isMaximizable() {
    return n("plugin:window|is_maximizable", {
      label: this.label
    });
  }
  /**
   * Gets the window's native minimize button state.
   *
   * #### Platform-specific
   *
   * - **Linux / iOS / Android:** Unsupported.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const minimizable = await getCurrentWindow().isMinimizable();
   * ```
   *
   * @returns Whether the window's native minimize button is enabled or not.
   */
  async isMinimizable() {
    return n("plugin:window|is_minimizable", {
      label: this.label
    });
  }
  /**
   * Gets the window's native close button state.
   *
   * #### Platform-specific
   *
   * - **iOS / Android:** Unsupported.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const closable = await getCurrentWindow().isClosable();
   * ```
   *
   * @returns Whether the window's native close button is enabled or not.
   */
  async isClosable() {
    return n("plugin:window|is_closable", {
      label: this.label
    });
  }
  /**
   * Gets the window's current visible state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const visible = await getCurrentWindow().isVisible();
   * ```
   *
   * @returns Whether the window is visible or not.
   */
  async isVisible() {
    return n("plugin:window|is_visible", {
      label: this.label
    });
  }
  /**
   * Gets the window's current title.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const title = await getCurrentWindow().title();
   * ```
   */
  async title() {
    return n("plugin:window|title", {
      label: this.label
    });
  }
  /**
   * Gets the window's current theme.
   *
   * #### Platform-specific
   *
   * - **macOS:** Theme was introduced on macOS 10.14. Returns `light` on macOS 10.13 and below.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const theme = await getCurrentWindow().theme();
   * ```
   *
   * @returns The window theme.
   */
  async theme() {
    return n("plugin:window|theme", {
      label: this.label
    });
  }
  /**
   * Whether the window is configured to be always on top of other windows or not.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * const alwaysOnTop = await getCurrentWindow().isAlwaysOnTop();
   * ```
   *
   * @returns Whether the window is visible or not.
   */
  async isAlwaysOnTop() {
    return n("plugin:window|is_always_on_top", {
      label: this.label
    });
  }
  async activityName() {
    return n("plugin:window|activity_name", {
      label: this.label
    });
  }
  async sceneIdentifier() {
    return n("plugin:window|scene_identifier", {
      label: this.label
    });
  }
  // Setters
  /**
   * Centers the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().center();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async center() {
    return n("plugin:window|center", {
      label: this.label
    });
  }
  /**
   *  Requests user attention to the window, this has no effect if the application
   * is already focused. How requesting for user attention manifests is platform dependent,
   * see `UserAttentionType` for details.
   *
   * Providing `null` will unset the request for user attention. Unsetting the request for
   * user attention might not be done automatically by the WM when the window receives input.
   *
   * #### Platform-specific
   *
   * - **macOS:** `null` has no effect.
   * - **Linux:** Urgency levels have the same effect.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().requestUserAttention();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async requestUserAttention(e) {
    let i = null;
    return e && (e === Z.Critical ? i = { type: "Critical" } : i = { type: "Informational" }), n("plugin:window|request_user_attention", {
      label: this.label,
      value: i
    });
  }
  /**
   * Updates the window resizable flag.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setResizable(false);
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async setResizable(e) {
    return n("plugin:window|set_resizable", {
      label: this.label,
      value: e
    });
  }
  /**
   * Enable or disable the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setEnabled(false);
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   *
   * @since 2.0.0
   */
  async setEnabled(e) {
    return n("plugin:window|set_enabled", {
      label: this.label,
      value: e
    });
  }
  /**
   * Whether the window is enabled or disabled.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setEnabled(false);
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   *
   * @since 2.0.0
   */
  async isEnabled() {
    return n("plugin:window|is_enabled", {
      label: this.label
    });
  }
  /**
   * Sets whether the window's native maximize button is enabled or not.
   * If resizable is set to false, this setting is ignored.
   *
   * #### Platform-specific
   *
   * - **macOS:** Disables the "zoom" button in the window titlebar, which is also used to enter fullscreen mode.
   * - **Linux / iOS / Android:** Unsupported.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setMaximizable(false);
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async setMaximizable(e) {
    return n("plugin:window|set_maximizable", {
      label: this.label,
      value: e
    });
  }
  /**
   * Sets whether the window's native minimize button is enabled or not.
   *
   * #### Platform-specific
   *
   * - **Linux / iOS / Android:** Unsupported.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setMinimizable(false);
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async setMinimizable(e) {
    return n("plugin:window|set_minimizable", {
      label: this.label,
      value: e
    });
  }
  /**
   * Sets whether the window's native close button is enabled or not.
   *
   * #### Platform-specific
   *
   * - **Linux:** GTK+ will do its best to convince the window manager not to show a close button. Depending on the system, this function may not have any effect when called on a window that is already visible
   * - **iOS / Android:** Unsupported.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setClosable(false);
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async setClosable(e) {
    return n("plugin:window|set_closable", {
      label: this.label,
      value: e
    });
  }
  /**
   * Sets the window title.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setTitle('Tauri');
   * ```
   *
   * @param title The new title
   * @returns A promise indicating the success or failure of the operation.
   */
  async setTitle(e) {
    return n("plugin:window|set_title", {
      label: this.label,
      value: e
    });
  }
  /**
   * Maximizes the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().maximize();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async maximize() {
    return n("plugin:window|maximize", {
      label: this.label
    });
  }
  /**
   * Unmaximizes the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().unmaximize();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async unmaximize() {
    return n("plugin:window|unmaximize", {
      label: this.label
    });
  }
  /**
   * Toggles the window maximized state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().toggleMaximize();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async toggleMaximize() {
    return n("plugin:window|toggle_maximize", {
      label: this.label
    });
  }
  /**
   * Minimizes the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().minimize();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async minimize() {
    return n("plugin:window|minimize", {
      label: this.label
    });
  }
  /**
   * Unminimizes the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().unminimize();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async unminimize() {
    return n("plugin:window|unminimize", {
      label: this.label
    });
  }
  /**
   * Sets the window visibility to true.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().show();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async show() {
    return n("plugin:window|show", {
      label: this.label
    });
  }
  /**
   * Sets the window visibility to false.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().hide();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async hide() {
    return n("plugin:window|hide", {
      label: this.label
    });
  }
  /**
   * Closes the window.
   *
   * Note this emits a closeRequested event so you can intercept it. To force window close, use {@link Window.destroy}.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().close();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async close() {
    return n("plugin:window|close", {
      label: this.label
    });
  }
  /**
   * Destroys the window. Behaves like {@link Window.close} but forces the window close instead of emitting a closeRequested event.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().destroy();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async destroy() {
    return n("plugin:window|destroy", {
      label: this.label
    });
  }
  /**
   * Whether the window should have borders and bars.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setDecorations(false);
   * ```
   *
   * @param decorations Whether the window should have borders and bars.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setDecorations(e) {
    return n("plugin:window|set_decorations", {
      label: this.label,
      value: e
    });
  }
  /**
   * Whether or not the window should have shadow.
   *
   * #### Platform-specific
   *
   * - **Windows:**
   *   - `false` has no effect on decorated window, shadows are always ON.
   *   - `true` will make undecorated window have a 1px white border,
   * and on Windows 11, it will have a rounded corners.
   * - **Linux:** Unsupported.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setShadow(false);
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async setShadow(e) {
    return n("plugin:window|set_shadow", {
      label: this.label,
      value: e
    });
  }
  /**
   * Set window effects.
   */
  async setEffects(e) {
    return n("plugin:window|set_effects", {
      label: this.label,
      value: e
    });
  }
  /**
   * Clear any applied effects if possible.
   */
  async clearEffects() {
    return n("plugin:window|set_effects", {
      label: this.label,
      value: null
    });
  }
  /**
   * Whether the window should always be on top of other windows.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setAlwaysOnTop(true);
   * ```
   *
   * @param alwaysOnTop Whether the window should always be on top of other windows or not.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setAlwaysOnTop(e) {
    return n("plugin:window|set_always_on_top", {
      label: this.label,
      value: e
    });
  }
  /**
   * Whether the window should always be below other windows.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setAlwaysOnBottom(true);
   * ```
   *
   * @param alwaysOnBottom Whether the window should always be below other windows or not.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setAlwaysOnBottom(e) {
    return n("plugin:window|set_always_on_bottom", {
      label: this.label,
      value: e
    });
  }
  /**
   * Prevents the window contents from being captured by other apps.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setContentProtected(true);
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async setContentProtected(e) {
    return n("plugin:window|set_content_protected", {
      label: this.label,
      value: e
    });
  }
  /**
   * Resizes the window with a new inner size.
   * @example
   * ```typescript
   * import { getCurrentWindow, LogicalSize } from '@tauri-apps/api/window';
   * await getCurrentWindow().setSize(new LogicalSize(600, 500));
   * ```
   *
   * @param size The logical or physical inner size.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setSize(e) {
    return n("plugin:window|set_size", {
      label: this.label,
      value: e instanceof I ? e : new I(e)
    });
  }
  /**
   * Sets the window minimum inner size. If the `size` argument is not provided, the constraint is unset.
   * @example
   * ```typescript
   * import { getCurrentWindow, PhysicalSize } from '@tauri-apps/api/window';
   * await getCurrentWindow().setMinSize(new PhysicalSize(600, 500));
   * ```
   *
   * @param size The logical or physical inner size, or `null` to unset the constraint.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setMinSize(e) {
    return n("plugin:window|set_min_size", {
      label: this.label,
      value: e instanceof I ? e : e ? new I(e) : null
    });
  }
  /**
   * Sets the window maximum inner size. If the `size` argument is undefined, the constraint is unset.
   * @example
   * ```typescript
   * import { getCurrentWindow, LogicalSize } from '@tauri-apps/api/window';
   * await getCurrentWindow().setMaxSize(new LogicalSize(600, 500));
   * ```
   *
   * @param size The logical or physical inner size, or `null` to unset the constraint.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setMaxSize(e) {
    return n("plugin:window|set_max_size", {
      label: this.label,
      value: e instanceof I ? e : e ? new I(e) : null
    });
  }
  /**
   * Sets the window inner size constraints.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setSizeConstraints({ minWidth: 300 });
   * ```
   *
   * @param constraints The logical or physical inner size, or `null` to unset the constraint.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setSizeConstraints(e) {
    function i(a) {
      return a ? { Logical: a } : null;
    }
    return n("plugin:window|set_size_constraints", {
      label: this.label,
      value: {
        minWidth: i(e == null ? void 0 : e.minWidth),
        minHeight: i(e == null ? void 0 : e.minHeight),
        maxWidth: i(e == null ? void 0 : e.maxWidth),
        maxHeight: i(e == null ? void 0 : e.maxHeight)
      }
    });
  }
  /**
   * Sets the window outer position.
   * @example
   * ```typescript
   * import { getCurrentWindow, LogicalPosition } from '@tauri-apps/api/window';
   * await getCurrentWindow().setPosition(new LogicalPosition(600, 500));
   * ```
   *
   * @param position The new position, in logical or physical pixels.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setPosition(e) {
    return n("plugin:window|set_position", {
      label: this.label,
      value: e instanceof $ ? e : new $(e)
    });
  }
  /**
   * Sets the window fullscreen state.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setFullscreen(true);
   * ```
   *
   * @param fullscreen Whether the window should go to fullscreen or not.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setFullscreen(e) {
    return n("plugin:window|set_fullscreen", {
      label: this.label,
      value: e
    });
  }
  /**
   * On macOS, Toggles a fullscreen mode that doesn’t require a new macOS space. Returns a boolean indicating whether the transition was successful (this won’t work if the window was already in the native fullscreen).
   * This is how fullscreen used to work on macOS in versions before Lion. And allows the user to have a fullscreen window without using another space or taking control over the entire monitor.
   *
   * On other platforms, this is the same as {@link Window.setFullscreen}.
   *
   * @param fullscreen Whether the window should go to simple fullscreen or not.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setSimpleFullscreen(e) {
    return n("plugin:window|set_simple_fullscreen", {
      label: this.label,
      value: e
    });
  }
  /**
   * Bring the window to front and focus.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setFocus();
   * ```
   *
   * @returns A promise indicating the success or failure of the operation.
   */
  async setFocus() {
    return n("plugin:window|set_focus", {
      label: this.label
    });
  }
  /**
   * Sets whether the window can be focused.
   *
   * #### Platform-specific
   *
   * - **macOS**: If the window is already focused, it is not possible to unfocus it after calling `set_focusable(false)`.
   *   In this case, you might consider calling {@link Window.setFocus} but it will move the window to the back i.e. at the bottom in terms of z-order.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setFocusable(true);
   * ```
   *
   * @param focusable Whether the window can be focused.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setFocusable(e) {
    return n("plugin:window|set_focusable", {
      label: this.label,
      value: e
    });
  }
  /**
   * Sets the window icon.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setIcon('/tauri/awesome.png');
   * ```
   *
   * Note that you may need the `image-ico` or `image-png` Cargo features to use this API.
   * To enable it, change your Cargo.toml file:
   * ```toml
   * [dependencies]
   * tauri = { version = "...", features = ["...", "image-png"] }
   * ```
   *
   * @param icon Icon bytes or path to the icon file.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setIcon(e) {
    return n("plugin:window|set_icon", {
      label: this.label,
      value: V(e)
    });
  }
  /**
   * Whether the window icon should be hidden from the taskbar or not.
   *
   * #### Platform-specific
   *
   * - **macOS:** Unsupported.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setSkipTaskbar(true);
   * ```
   *
   * @param skip true to hide window icon, false to show it.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setSkipTaskbar(e) {
    return n("plugin:window|set_skip_taskbar", {
      label: this.label,
      value: e
    });
  }
  /**
   * Grabs the cursor, preventing it from leaving the window.
   *
   * There's no guarantee that the cursor will be hidden. You should
   * hide it by yourself if you want so.
   *
   * #### Platform-specific
   *
   * - **Linux:** Unsupported.
   * - **macOS:** This locks the cursor in a fixed location, which looks visually awkward.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setCursorGrab(true);
   * ```
   *
   * @param grab `true` to grab the cursor icon, `false` to release it.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setCursorGrab(e) {
    return n("plugin:window|set_cursor_grab", {
      label: this.label,
      value: e
    });
  }
  /**
   * Modifies the cursor's visibility.
   *
   * #### Platform-specific
   *
   * - **Windows:** The cursor is only hidden within the confines of the window.
   * - **macOS:** The cursor is hidden as long as the window has input focus, even if the cursor is
   *   outside of the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setCursorVisible(false);
   * ```
   *
   * @param visible If `false`, this will hide the cursor. If `true`, this will show the cursor.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setCursorVisible(e) {
    return n("plugin:window|set_cursor_visible", {
      label: this.label,
      value: e
    });
  }
  /**
   * Modifies the cursor icon of the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setCursorIcon('help');
   * ```
   *
   * @param icon The new cursor icon.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setCursorIcon(e) {
    return n("plugin:window|set_cursor_icon", {
      label: this.label,
      value: e
    });
  }
  /**
   * Sets the window background color.
   *
   * #### Platform-specific:
   *
   * - **Windows:** alpha channel is ignored.
   * - **iOS / Android:** Unsupported.
   *
   * @returns A promise indicating the success or failure of the operation.
   *
   * @since 2.1.0
   */
  async setBackgroundColor(e) {
    return n("plugin:window|set_background_color", { color: e });
  }
  /**
   * Changes the position of the cursor in window coordinates.
   * @example
   * ```typescript
   * import { getCurrentWindow, LogicalPosition } from '@tauri-apps/api/window';
   * await getCurrentWindow().setCursorPosition(new LogicalPosition(600, 300));
   * ```
   *
   * @param position The new cursor position.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setCursorPosition(e) {
    return n("plugin:window|set_cursor_position", {
      label: this.label,
      value: e instanceof $ ? e : new $(e)
    });
  }
  /**
   * Changes the cursor events behavior.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setIgnoreCursorEvents(true);
   * ```
   *
   * @param ignore `true` to ignore the cursor events; `false` to process them as usual.
   * @returns A promise indicating the success or failure of the operation.
   */
  async setIgnoreCursorEvents(e) {
    return n("plugin:window|set_ignore_cursor_events", {
      label: this.label,
      value: e
    });
  }
  /**
   * Starts dragging the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().startDragging();
   * ```
   *
   * @return A promise indicating the success or failure of the operation.
   */
  async startDragging() {
    return n("plugin:window|start_dragging", {
      label: this.label
    });
  }
  /**
   * Starts resize-dragging the window.
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().startResizeDragging();
   * ```
   *
   * @return A promise indicating the success or failure of the operation.
   */
  async startResizeDragging(e) {
    return n("plugin:window|start_resize_dragging", {
      label: this.label,
      value: e
    });
  }
  /**
   * Sets the badge count. It is app wide and not specific to this window.
   *
   * #### Platform-specific
   *
   * - **Windows**: Unsupported. Use @{linkcode Window.setOverlayIcon} instead.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setBadgeCount(5);
   * ```
   *
   * @param count The badge count. Use `undefined` to remove the badge.
   * @return A promise indicating the success or failure of the operation.
   */
  async setBadgeCount(e) {
    return n("plugin:window|set_badge_count", {
      label: this.label,
      value: e
    });
  }
  /**
   * Sets the badge cont **macOS only**.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setBadgeLabel("Hello");
   * ```
   *
   * @param label The badge label. Use `undefined` to remove the badge.
   * @return A promise indicating the success or failure of the operation.
   */
  async setBadgeLabel(e) {
    return n("plugin:window|set_badge_label", {
      label: this.label,
      value: e
    });
  }
  /**
   * Sets the overlay icon. **Windows only**
   * The overlay icon can be set for every window.
   *
   *
   * Note that you may need the `image-ico` or `image-png` Cargo features to use this API.
   * To enable it, change your Cargo.toml file:
   *
   * ```toml
   * [dependencies]
   * tauri = { version = "...", features = ["...", "image-png"] }
   * ```
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from '@tauri-apps/api/window';
   * await getCurrentWindow().setOverlayIcon("/tauri/awesome.png");
   * ```
   *
   * @param icon Icon bytes or path to the icon file. Use `undefined` to remove the overlay icon.
   * @return A promise indicating the success or failure of the operation.
   */
  async setOverlayIcon(e) {
    return n("plugin:window|set_overlay_icon", {
      label: this.label,
      value: e ? V(e) : void 0
    });
  }
  /**
   * Sets the taskbar progress state.
   *
   * #### Platform-specific
   *
   * - **Linux / macOS**: Progress bar is app-wide and not specific to this window.
   * - **Linux**: Only supported desktop environments with `libunity` (e.g. GNOME).
   *
   * @example
   * ```typescript
   * import { getCurrentWindow, ProgressBarStatus } from '@tauri-apps/api/window';
   * await getCurrentWindow().setProgressBar({
   *   status: ProgressBarStatus.Normal,
   *   progress: 50,
   * });
   * ```
   *
   * @return A promise indicating the success or failure of the operation.
   */
  async setProgressBar(e) {
    return n("plugin:window|set_progress_bar", {
      label: this.label,
      value: e
    });
  }
  /**
   * Sets whether the window should be visible on all workspaces or virtual desktops.
   *
   * #### Platform-specific
   *
   * - **Windows / iOS / Android:** Unsupported.
   *
   * @since 2.0.0
   */
  async setVisibleOnAllWorkspaces(e) {
    return n("plugin:window|set_visible_on_all_workspaces", {
      label: this.label,
      value: e
    });
  }
  /**
   * Sets the title bar style. **macOS only**.
   *
   * @since 2.0.0
   */
  async setTitleBarStyle(e) {
    return n("plugin:window|set_title_bar_style", {
      label: this.label,
      value: e
    });
  }
  /**
   * Set window theme, pass in `null` or `undefined` to follow system theme
   *
   * #### Platform-specific
   *
   * - **Linux / macOS**: Theme is app-wide and not specific to this window.
   * - **iOS / Android:** Unsupported.
   *
   * @since 2.0.0
   */
  async setTheme(e) {
    return n("plugin:window|set_theme", {
      label: this.label,
      value: e
    });
  }
  // Listeners
  /**
   * Listen to window resize.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from "@tauri-apps/api/window";
   * const unlisten = await getCurrentWindow().onResized(({ payload: size }) => {
   *  console.log('Window resized', size);
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async onResized(e) {
    return this.listen(g.WINDOW_RESIZED, (i) => {
      i.payload = new T(i.payload), e(i);
    });
  }
  /**
   * Listen to window move.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from "@tauri-apps/api/window";
   * const unlisten = await getCurrentWindow().onMoved(({ payload: position }) => {
   *  console.log('Window moved', position);
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async onMoved(e) {
    return this.listen(g.WINDOW_MOVED, (i) => {
      i.payload = new L(i.payload), e(i);
    });
  }
  /**
   * Listen to window close requested. Emitted when the user requests to closes the window.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from "@tauri-apps/api/window";
   * import { confirm } from '@tauri-apps/api/dialog';
   * const unlisten = await getCurrentWindow().onCloseRequested(async (event) => {
   *   const confirmed = await confirm('Are you sure?');
   *   if (!confirmed) {
   *     // user did not confirm closing the window; let's prevent it
   *     event.preventDefault();
   *   }
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async onCloseRequested(e) {
    return this.listen(g.WINDOW_CLOSE_REQUESTED, async (i) => {
      const a = new Le(i);
      await e(a), a.isPreventDefault() || await this.destroy();
    });
  }
  /**
   * Listen to a file drop event.
   * The listener is triggered when the user hovers the selected files on the webview,
   * drops the files or cancels the operation.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from "@tauri-apps/api/webview";
   * const unlisten = await getCurrentWindow().onDragDropEvent((event) => {
   *  if (event.payload.type === 'over') {
   *    console.log('User hovering', event.payload.position);
   *  } else if (event.payload.type === 'drop') {
   *    console.log('User dropped', event.payload.paths);
   *  } else {
   *    console.log('File drop cancelled');
   *  }
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async onDragDropEvent(e) {
    const i = await this.listen(g.DRAG_ENTER, (c) => {
      e({
        ...c,
        payload: {
          type: "enter",
          paths: c.payload.paths,
          position: new L(c.payload.position)
        }
      });
    }), a = await this.listen(g.DRAG_OVER, (c) => {
      e({
        ...c,
        payload: {
          type: "over",
          position: new L(c.payload.position)
        }
      });
    }), l = await this.listen(g.DRAG_DROP, (c) => {
      e({
        ...c,
        payload: {
          type: "drop",
          paths: c.payload.paths,
          position: new L(c.payload.position)
        }
      });
    }), f = await this.listen(g.DRAG_LEAVE, (c) => {
      e({ ...c, payload: { type: "leave" } });
    });
    return () => {
      i(), l(), a(), f();
    };
  }
  /**
   * Listen to window focus change.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from "@tauri-apps/api/window";
   * const unlisten = await getCurrentWindow().onFocusChanged(({ payload: focused }) => {
   *  console.log('Focus changed, window is focused? ' + focused);
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async onFocusChanged(e) {
    const i = await this.listen(g.WINDOW_FOCUS, (l) => {
      e({ ...l, payload: !0 });
    }), a = await this.listen(g.WINDOW_BLUR, (l) => {
      e({ ...l, payload: !1 });
    });
    return () => {
      i(), a();
    };
  }
  /**
   * Listen to window scale change. Emitted when the window's scale factor has changed.
   * The following user actions can cause DPI changes:
   * - Changing the display's resolution.
   * - Changing the display's scale factor (e.g. in Control Panel on Windows).
   * - Moving the window to a display with a different scale factor.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from "@tauri-apps/api/window";
   * const unlisten = await getCurrentWindow().onScaleChanged(({ payload }) => {
   *  console.log('Scale changed', payload.scaleFactor, payload.size);
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async onScaleChanged(e) {
    return this.listen(g.WINDOW_SCALE_FACTOR_CHANGED, e);
  }
  /**
   * Listen to the system theme change.
   *
   * @example
   * ```typescript
   * import { getCurrentWindow } from "@tauri-apps/api/window";
   * const unlisten = await getCurrentWindow().onThemeChanged(({ payload: theme }) => {
   *  console.log('New theme: ' + theme);
   * });
   *
   * // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
   * unlisten();
   * ```
   *
   * @returns A promise resolving to a function to unlisten to the event.
   * Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
   */
  async onThemeChanged(e) {
    return this.listen(g.WINDOW_THEME_CHANGED, e);
  }
}
var ee;
(function(t) {
  t.Disabled = "disabled", t.Throttle = "throttle", t.Suspend = "suspend";
})(ee || (ee = {}));
var te;
(function(t) {
  t.Default = "default", t.FluentOverlay = "fluentOverlay";
})(te || (te = {}));
var ie;
(function(t) {
  t.AppearanceBased = "appearanceBased", t.Light = "light", t.Dark = "dark", t.MediumLight = "mediumLight", t.UltraDark = "ultraDark", t.Titlebar = "titlebar", t.Selection = "selection", t.Menu = "menu", t.Popover = "popover", t.Sidebar = "sidebar", t.HeaderView = "headerView", t.Sheet = "sheet", t.WindowBackground = "windowBackground", t.HudWindow = "hudWindow", t.FullScreenUI = "fullScreenUI", t.Tooltip = "tooltip", t.ContentBackground = "contentBackground", t.UnderWindowBackground = "underWindowBackground", t.UnderPageBackground = "underPageBackground", t.Mica = "mica", t.Blur = "blur", t.Acrylic = "acrylic", t.Tabbed = "tabbed", t.TabbedDark = "tabbedDark", t.TabbedLight = "tabbedLight";
})(ie || (ie = {}));
var ne;
(function(t) {
  t.FollowsWindowActiveState = "followsWindowActiveState", t.Active = "active", t.Inactive = "inactive";
})(ne || (ne = {}));
async function K(t = {}) {
  return typeof t == "object" && Object.freeze(t), await n("plugin:dialog|open", { options: t });
}
const De = "pet", Ee = "engine/live2dcubismcore.min.js", Ce = "engine/live2d-engine.js";
function Q(t, e) {
  const i = t.includes("\\") ? "\\" : "/", a = t.replace(/[\\/]+$/, "").split(/[\\/]+/);
  for (const l of e.split(/[\\/]+/))
    if (!(!l || l === ".")) {
      if (l === "..") {
        a.length > 1 && a.pop();
        continue;
      }
      a.push(l);
    }
  return a.join(i);
}
function Se(t) {
  var i;
  const e = Number((t == null ? void 0 : t.Version) ?? 0);
  if (!((i = t == null ? void 0 : t.FileReferences) != null && i.Moc) || !(e >= 3))
    throw new Error("这不是 Cubism 4 的模型定义（缺 `FileReferences.Moc` 或 `Version < 3`）—— 请选 `*.model3.json`");
}
async function We(t) {
  let e;
  try {
    e = await fetch(q(t));
  } catch (i) {
    throw new Error(`读不到模型文件（asset 协议拒绝或文件已移动）：${i instanceof Error ? i.message : String(i)}`);
  }
  if (!e.ok) throw new Error(`读模型定义失败（HTTP ${e.status}）`);
  try {
    return await e.json();
  } catch {
    throw new Error("模型定义不是合法 JSON");
  }
}
async function ze(t) {
  var e;
  try {
    const i = await We(t);
    Se(i);
    const a = i.FileReferences ?? {}, l = Object.keys(a.Motions ?? {});
    return {
      ok: !0,
      info: `Cubism ${Number(i.Version)} · 纹理 ${((e = a.Textures) == null ? void 0 : e.length) ?? 0} · 动作组 ${l.length ? l.join(" / ") : "无"}`
    };
  } catch (i) {
    return { ok: !1, reason: i instanceof Error ? i.message : String(i) };
  }
}
async function de() {
  const t = await n("plugins_dir_path");
  return Q(t, De);
}
async function Ie() {
  return Q(await de(), Ee);
}
async function Ne() {
  return Q(await de(), Ce);
}
function pe() {
  return !!globalThis.Live2DCubismCore;
}
let B = null;
function Oe() {
  return pe() ? Promise.resolve() : (B || (B = Re().catch((t) => {
    throw B = null, t instanceof Error ? t : new Error(String(t));
  })), B);
}
async function Re() {
  if (await Pe(q(await Ie())), !pe()) throw new Error("Cubism Core 已注入但全局对象仍不可见（文件可能不完整）");
}
function Pe(t) {
  return new Promise((e, i) => {
    const a = document.createElement("script");
    a.src = t, a.async = !1, a.onload = () => e(), a.onerror = () => i(new Error(`引擎文件加载失败（asset 协议拒绝或文件缺失）：${t}`)), document.head.appendChild(a);
  });
}
const O = "pet-control", he = "lunac.pet.v1", Ae = "plugin-pet", ae = { image: "", model: "", scale: 1, clickThrough: !1 };
function p() {
  try {
    const t = localStorage.getItem(he);
    if (!t) return { ...ae };
    const e = JSON.parse(t);
    return {
      image: typeof e.image == "string" ? e.image : "",
      model: typeof e.model == "string" ? e.model : "",
      scale: typeof e.scale == "number" && e.scale >= 0.4 && e.scale <= 2 ? e.scale : 1,
      clickThrough: e.clickThrough === !0
    };
  } catch {
    return { ...ae };
  }
}
function _(t) {
  try {
    localStorage.setItem(he, JSON.stringify(t));
  } catch {
  }
}
function U(t) {
  return t.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
function le() {
  return location.pathname.endsWith("plugin.html");
}
let G = null;
function Te() {
  return G || (G = (async () => (await Oe(), await import(q(await Ne()))))().catch((t) => {
    throw G = null, t instanceof Error ? t : new Error(String(t));
  })), G;
}
function Me(t) {
  const e = t.model.trim().length > 0, i = t.image.trim().length > 0;
  return `
<div class="pet-console">
  <div class="pet-row pet-row-main">
    <button id="pet-show" class="pet-btn pet-btn-primary">${e || i ? "显示桌宠" : "导入形象并显示"}</button>
    <button id="pet-hide" class="pet-btn">收起来</button>
  </div>
  <div class="pet-row">
    <button id="pet-pick-model" class="pet-btn">选择 Live2D 模型…</button>
    <button id="pet-clear-model" class="pet-btn" hidden>不用模型</button>
  </div>
  <div class="pet-row">
    <button id="pet-pick" class="pet-btn">选择图片…</button>
    <label class="pet-check">
      <input type="checkbox" id="pet-through" ${t.clickThrough ? "checked" : ""}>
      鼠标穿透（桌宠不吃鼠标点击，桌面照常操作）
    </label>
  </div>
  <div class="pet-row">
    <span class="pet-label">形象大小</span>
    <input type="range" id="pet-scale" min="40" max="200" step="5" value="${Math.round(t.scale * 100)}">
    <span class="pet-val" id="pet-scale-val">${Math.round(t.scale * 100)}%</span>
  </div>
  <div class="pet-file" id="pet-file"></div>
  <div class="pet-note">
    形象由你自己准备 —— Lunac 只带引擎，不随包分发任何模型或素材（桌宠是独立的悬浮窗，
    与搜索窗同时存在）。<b>Live2D 要选那个 <code>*.model3.json</code></b>：同目录的纹理、
    动作、表情会自动带上，不需要你逐个挑。<br>
    <b>穿透开着时桌宠窗收不到鼠标事件</b>，所以关掉它的开关只放在这里 ——
    桌宠窗自己那份右键菜单在穿透状态下是收不到点击的。
  </div>
</div>`;
}
function be() {
  if (document.getElementById("pet-style")) return;
  const t = document.createElement("style");
  t.id = "pet-style", t.textContent = Be, document.head.appendChild(t);
}
async function Fe(t) {
  var d, v, y, h, W, D;
  const e = (o) => t.querySelector(`#${o}`), i = (o = "") => {
    const u = p(), b = u.model.trim(), E = u.image.trim(), F = e("pet-pick-model"), R = e("pet-pick"), P = e("pet-clear-model"), z = e("pet-show");
    F && (F.textContent = b ? "更换 Live2D 模型…" : "选择 Live2D 模型…"), R && (R.textContent = E ? "更换图片…" : "选择图片…"), P && (P.hidden = !b), z && (z.textContent = b || E ? "显示桌宠" : "导入形象并显示");
    const x = e("pet-file");
    if (!x) return;
    const C = o ? `<br><span class="pet-dim">${U(o)}</span>` : "";
    b ? x.innerHTML = `当前用 Live2D 模型：<code>${U(b)}</code>${C}` : E ? x.innerHTML = `当前用图片：<code>${U(E)}</code>${C}` : x.innerHTML = "还没有形象 —— 选一张图片（png / jpg / webp / gif），或选一个 Live2D 模型（<code>*.model3.json</code>）。";
  };
  async function a() {
    await n("open_plugin_window", { pluginId: "pet", input: "" });
  }
  (d = e("pet-show")) == null || d.addEventListener("click", () => {
    (async () => {
      const o = p();
      !o.model.trim() && !o.image.trim() && !await f() || await a();
    })().catch((o) => console.error("[lunac pet] 显示桌宠失败：", o));
  }), (v = e("pet-hide")) == null || v.addEventListener("click", () => {
    n("close_plugin_window", { pluginId: "pet" }).catch(() => {
    });
  }), (y = e("pet-pick")) == null || y.addEventListener("click", () => {
    f();
  }), (h = e("pet-pick-model")) == null || h.addEventListener("click", () => {
    c();
  }), (W = e("pet-clear-model")) == null || W.addEventListener("click", () => {
    _({ ...p(), model: "" }), i(), N(O, { type: "reload" });
  }), (D = e("pet-through")) == null || D.addEventListener("change", (o) => {
    const u = o.target.checked, b = p();
    _({ ...b, clickThrough: u }), N(O, { type: "set-click-through", value: u });
  });
  const l = e("pet-scale");
  l == null || l.addEventListener("input", () => {
    const o = Math.round(Number(l.value)) / 100, u = e("pet-scale-val");
    u && (u.textContent = `${Math.round(o * 100)}%`), _({ ...p(), scale: o }), N(O, { type: "set-scale", value: o });
  });
  async function f() {
    const o = await K({
      multiple: !1,
      directory: !1,
      filters: [{ name: "图片", extensions: ["png", "jpg", "jpeg", "webp", "gif", "bmp"] }]
    });
    return typeof o != "string" || !o ? "" : (_({ ...p(), image: o, model: "" }), i(), N(O, { type: "reload" }), o);
  }
  async function c() {
    const o = await K({
      multiple: !1,
      directory: !1,
      filters: [{ name: "Live2D 模型定义", extensions: ["json"] }]
    });
    if (typeof o != "string" || !o) return;
    const u = e("pet-file");
    u && (u.innerHTML = "正在检查模型…");
    const b = await ze(o);
    if (!b.ok) {
      u && (u.innerHTML = `<span class="pet-bad">这个文件用不了：${U(b.reason)}</span>`);
      return;
    }
    _({ ...p(), model: o, image: "" }), i(b.info), N(O, { type: "reload" });
  }
  be(), i();
}
function $e() {
  return `
<div class="pet-root" id="pet-root">
  <div class="pet-stage" id="pet-stage">
    <div class="pet-l2d" id="pet-l2d"></div>
    <img class="pet-img" id="pet-img" alt="" draggable="false">
    <div class="pet-empty" id="pet-empty">还没有形象<br><span>在控制台里选一张图片或一个 Live2D 模型</span></div>
  </div>
  <div class="pet-err" id="pet-err"></div>
  <div class="pet-menu" id="pet-menu">
    <button data-act="pick">更换图片…</button>
    <button data-act="through">开启鼠标穿透</button>
    <button data-act="bigger">大一点</button>
    <button data-act="smaller">小一点</button>
    <button data-act="close" class="danger">关闭桌宠</button>
  </div>
</div>`;
}
const Be = `
.pet-root{position:fixed;inset:0;display:flex;align-items:flex-end;justify-content:center;overflow:hidden;}
.pet-stage{position:relative;width:100%;height:100%;display:flex;align-items:flex-end;justify-content:center;cursor:grab;touch-action:none;}
.pet-stage:active{cursor:grabbing;}
.pet-img{width:100%;height:100%;object-fit:contain;object-position:bottom center;transform-origin:50% 100%;pointer-events:none;-webkit-user-drag:none;filter:drop-shadow(0 6px 14px rgba(0,0,0,.35));}
.pet-l2d{position:absolute;inset:0;display:none;}
.pet-l2d.on{display:block;}
.pet-l2d canvas{display:block;}
.pet-err{position:absolute;left:8px;right:8px;bottom:8px;display:none;font-size:.68rem;line-height:1.6;color:var(--red);background:var(--surface-glass);border:1px solid var(--border-glass);border-radius:var(--radius);padding:8px 10px;word-break:break-all;backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);}
.pet-err.on{display:block;}
.pet-empty{position:absolute;left:50%;bottom:38%;transform:translateX(-50%);text-align:center;font-size:.72rem;line-height:1.7;color:var(--text-dim);background:var(--surface-glass);border:1px solid var(--border-glass);border-radius:var(--radius);padding:10px 14px;backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);}
.pet-empty span{font-size:.66rem;opacity:.75;}
.pet-menu{position:absolute;display:none;flex-direction:column;min-width:132px;padding:4px;background:var(--surface-glass);border:1px solid var(--border-glass);border-radius:var(--radius);backdrop-filter:blur(20px);-webkit-backdrop-filter:blur(20px);box-shadow:0 8px 24px rgba(0,0,0,.28);}
.pet-menu.open{display:flex;}
.pet-menu button{appearance:none;background:none;border:0;text-align:left;font:inherit;font-size:.72rem;color:var(--text);padding:6px 10px;border-radius:6px;cursor:pointer;white-space:nowrap;}
.pet-menu button:hover{background:var(--border-glass);}
.pet-menu button.danger:hover{color:var(--red);}
.pet-console{padding:10px 12px 14px;font-size:.76rem;color:var(--text);}
.pet-row{display:flex;align-items:center;gap:8px;margin-bottom:10px;flex-wrap:wrap;}
.pet-row-main{gap:10px;}
.pet-btn{appearance:none;font:inherit;font-size:.74rem;color:var(--text);background:var(--surface-glass);border:1px solid var(--border-glass);border-radius:8px;padding:6px 12px;cursor:pointer;}
.pet-btn:hover{border-color:var(--accent);color:var(--accent);}
.pet-btn-primary{background:var(--accent);border-color:var(--accent);color:#fff;font-weight:600;}
.pet-btn-primary:hover{color:#fff;opacity:.92;}
.pet-check{display:flex;align-items:center;gap:6px;color:var(--text-dim);cursor:pointer;}
.pet-label{color:var(--text-dim);}
.pet-val{color:var(--text-dim);min-width:3.2em;}
.pet-file{margin:2px 0 10px;color:var(--text-dim);word-break:break-all;line-height:1.6;}
.pet-file code{font-size:.7rem;color:var(--text);}
.pet-dim{opacity:.72;}
.pet-bad{color:var(--red);}
.pet-note{color:var(--text-dim);opacity:.72;font-size:.68rem;line-height:1.7;border-top:1px solid var(--border-glass);padding-top:9px;}
.pet-note b{color:var(--text);opacity:.9;}
`;
let A = null;
async function Ue(t) {
  const e = (s) => t.querySelector(`#${s}`), i = e("pet-stage"), a = e("pet-img"), l = e("pet-l2d"), f = e("pet-err"), c = e("pet-empty"), d = e("pet-menu");
  let v = 0, y = p(), h = null, W = 0, D = !0;
  function o(s) {
    f && (f.textContent = s, f.classList.toggle("on", !!s));
  }
  function u() {
    h == null || h.destroy(), h = null;
  }
  async function b() {
    const s = ++W;
    y = p(), o("");
    const r = y.model.trim(), k = y.image.trim();
    if (r && l) {
      a && (a.removeAttribute("src"), a.style.display = "none"), c && (c.style.display = "none"), l.classList.add("on"), z(), u();
      try {
        const { mountLive2D: w } = await Te(), S = await w(l, { modelPath: r, scale: y.scale });
        if (s !== W) {
          S.destroy();
          return;
        }
        h = S, S.setScale(p().scale), S.setRunning(D);
      } catch (w) {
        if (s !== W) return;
        u(), l.classList.remove("on"), o(`Live2D 载入失败：${w instanceof Error ? w.message : String(w)}`);
      }
      return;
    }
    u(), l == null || l.classList.remove("on"), a && c && (k ? (a.src = q(k), a.style.display = "", c.style.display = "none") : (a.removeAttribute("src"), a.style.display = "none", c.style.display = "")), a && (a.style.transform = `scale(${y.scale}) translateY(0)`), D && P();
  }
  function E(s) {
    if (y = { ...y, scale: s }, h) {
      h.setScale(s);
      return;
    }
    a && (a.style.transform = `scale(${s}) translateY(0)`);
  }
  const F = performance.now();
  function R(s) {
    if (v = requestAnimationFrame(R), !!t.isConnected && a && a.style.display !== "none") {
      const r = Math.sin((s - F) / 1400) * 3;
      a.style.transform = `scale(${y.scale}) translateY(${r.toFixed(2)}px)`;
    }
  }
  function P() {
    v || (v = requestAnimationFrame(R));
  }
  function z() {
    v && cancelAnimationFrame(v), v = 0;
  }
  async function x(s) {
    try {
      await n("plugin_window_set_click_through", { ignore: s });
    } catch (r) {
      console.error("[lunac pet] 设置穿透失败：", r);
    }
  }
  function C() {
    d == null || d.classList.remove("open");
  }
  function we(s, r) {
    d && (d.style.left = `${Math.max(2, Math.min(s, window.innerWidth - 140))}px`, d.style.top = `${Math.max(2, Math.min(r, window.innerHeight - 150))}px`, d.classList.add("open"));
  }
  i == null || i.addEventListener("contextmenu", (s) => {
    s.preventDefault(), we(s.clientX, s.clientY);
  }), i == null || i.addEventListener("mousedown", (s) => {
    s.button === 0 && (C(), ce().startDragging().catch(() => {
    }));
  }), t.addEventListener("mousedown", (s) => {
    d != null && d.classList.contains("open") && !d.contains(s.target) && C();
  }), d == null || d.addEventListener("click", (s) => {
    var k;
    const r = (k = s.target.closest("button")) == null ? void 0 : k.dataset.act;
    r && (C(), (async () => {
      if (r === "pick") {
        const w = await K({
          multiple: !1,
          directory: !1,
          filters: [{ name: "图片", extensions: ["png", "jpg", "jpeg", "webp", "gif", "bmp"] }]
        });
        typeof w == "string" && w && (_({ ...p(), image: w, model: "" }), b());
        return;
      }
      if (r === "through") {
        _({ ...p(), clickThrough: !0 }), await x(!0);
        return;
      }
      if (r === "bigger" || r === "smaller") {
        const w = p().scale, S = Math.min(2, Math.max(0.4, +(w + (r === "bigger" ? 0.1 : -0.1)).toFixed(2)));
        _({ ...p(), scale: S }), E(S);
        return;
      }
      r === "close" && await n("plugin_window_close").catch(() => {
      });
    })().catch((w) => console.error("[lunac pet]", w)));
  });
  const ge = await H(O, (s) => {
    const r = s.payload;
    if (r != null && r.type) {
      if (r.type === "reload") {
        b();
        return;
      }
      if (r.type === "set-scale" && typeof r.value == "number") {
        _({ ...p(), scale: r.value }), E(r.value);
        return;
      }
      r.type === "set-click-through" && typeof r.value == "boolean" && x(r.value);
    }
  }), ye = await H(
    "plugin-window-visibility",
    (s) => {
      var r, k;
      (r = s.payload) != null && r.label && s.payload.label !== Ae || (((k = s.payload) == null ? void 0 : k.visible) === !1 ? (D = !1, z(), h == null || h.setRunning(!1), C()) : (D = !0, h ? h.setRunning(!0) : P()));
    }
  );
  be(), b(), y.clickThrough && await x(!0), A = () => {
    z(), u(), ge(), ye();
  };
}
const Ge = {
  id: "pet",
  name: "桌宠",
  keywords: ["桌宠", "宠物", "桌面宠物", "pet", "desktop pet", "live2d", "看板娘", "吉祥物"],
  description: "桌宠 —— 独立透明置顶的桌面形象窗（图片或 Live2D 模型，由你自己导入）",
  icon: "🐾",
  // **刻意不声明 `window.float`**：搜索打开的是**控制台**（普通内嵌面板），
  // 桌宠窗由控制台的「显示桌宠」打开。理由见文件头「为什么穿透开关必须放在控制台」。
  permissions: [],
  async execute(t) {
    return le() ? { type: "html", content: $e() } : { type: "html", content: Me(p()) };
  },
  async attach(t) {
    le() ? await Ue(t) : await Fe(t);
  },
  detach() {
    A == null || A(), A = null;
  }
};
export {
  Ge as default
};
