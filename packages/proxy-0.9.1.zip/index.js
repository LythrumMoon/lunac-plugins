async function u(t, r = {}, n) {
  return window.__TAURI_INTERNALS__.invoke(t, r, n);
}
const $ = "__lunac_host";
function S() {
  return globalThis[$] ?? null;
}
function i(t, r) {
  const n = S();
  return n && typeof n.t == "function" ? n.t(t, r) : t;
}
let e = null, p = null, l = !1, x;
function s(t) {
  return t.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
function d(t) {
  return document.querySelector(t);
}
function a(t) {
  const r = d("#proxy-msg");
  r && (r.textContent = t, x !== void 0 && window.clearTimeout(x), x = window.setTimeout(() => {
    const n = d("#proxy-msg");
    n && (n.textContent = ""), x = void 0;
  }, 3e3));
}
function E() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
}
function L(t) {
  const r = t.trim();
  return r ? /\s/.test(r) ? i("proxy.err_space") : r.includes(":") ? null : i("proxy.err_port") : i("proxy.err_empty");
}
function T(t) {
  const r = t.trim().toLowerCase();
  return r.startsWith("http://") || r.startsWith("https://");
}
async function v() {
  try {
    e = await u("proxy_config_get");
  } catch (t) {
    a(String(t));
    return;
  }
  try {
    p = await u("proxy_system_get");
  } catch {
    p = null;
  }
  k();
}
function k() {
  C(), f();
  const t = d("#proxy-link");
  t && document.activeElement !== t && (t.checked = !!(e != null && e.link_librespot));
}
function C() {
  const t = d("#proxy-state");
  if (!t) return;
  if (!p) {
    t.textContent = "";
    return;
  }
  const r = e == null ? void 0 : e.entries.find((n) => n.id === (e == null ? void 0 : e.active));
  if (p.enabled ? t.textContent = i("proxy.state_on", { server: p.server }) : t.textContent = i("proxy.state_off"), t.classList.toggle("warn", !p.enabled && !!r), !p.enabled && r) {
    const n = r.label || r.server;
    t.textContent += "  " + i("proxy.state_mismatch", { label: n });
  }
}
function f() {
  const t = d("#proxy-list");
  if (!t) return;
  const r = (e == null ? void 0 : e.entries) ?? [];
  if (r.length === 0) {
    t.innerHTML = `<div class="proxy-empty">${s(i("proxy.empty"))}</div>`;
    return;
  }
  t.innerHTML = r.map((n) => {
    const o = (e == null ? void 0 : e.active) === n.id, y = !T(n.server);
    return `<div class="proxy-row${o ? " on" : ""}" data-id="${s(n.id)}">
        <div class="proxy-row-main">
          <div class="proxy-row-label">${s(n.label || n.server)}${o ? `<span class="proxy-tag">${s(i("proxy.in_use"))}</span>` : ""}</div>
          <div class="proxy-row-server">${s(n.server)}${y ? `<span class="proxy-row-note">${s(i("proxy.socks_note"))}</span>` : ""}</div>
        </div>
        <button type="button" class="proxy-btn${o ? "" : " primary"}" data-act="${o ? "disable" : "enable"}"${l ? " disabled" : ""}>${s(i(o ? "proxy.disable" : "proxy.enable"))}</button>
        <button type="button" class="proxy-btn danger" data-act="del"${l ? " disabled" : ""}>${s(i("proxy.del"))}</button>
      </div>`;
  }).join("");
}
async function m(t) {
  try {
    await u("librespot_set_proxy", { proxy: t });
  } catch (r) {
    a(i("proxy.err_librespot", { err: String(r) }));
  }
}
async function H(t) {
  const r = e == null ? void 0 : e.entries.find((n) => n.id === t);
  if (!(!r || l)) {
    l = !0, f();
    try {
      p = await u("proxy_enable", { id: t });
    } catch (n) {
      l = !1, a(String(n)), f();
      return;
    }
    l = !1, e != null && e.link_librespot && await m(r.server), p.enabled || a(i("proxy.err_not_applied")), await v();
  }
}
async function g() {
  if (!l) {
    l = !0, f();
    try {
      p = await u("proxy_disable");
    } catch (t) {
      l = !1, a(String(t)), f();
      return;
    }
    l = !1, e != null && e.link_librespot && await m(""), await v();
  }
}
async function P(t) {
  if (!e || l || e.active === t && (await g(), !e))
    return;
  const r = {
    entries: e.entries.filter((n) => n.id !== t),
    active: e.active === t ? "" : e.active,
    link_librespot: e.link_librespot
  };
  try {
    e = await u("proxy_config_set", { config: r }), a(i("proxy.removed"));
  } catch (n) {
    a(String(n));
  }
  await v();
}
async function w() {
  if (!e) return;
  const t = d("#proxy-label"), r = d("#proxy-server"), n = ((r == null ? void 0 : r.value) ?? "").trim(), o = L(n);
  if (o) {
    a(o);
    return;
  }
  if (e.entries.some((c) => c.server.trim() === n)) {
    a(i("proxy.err_dup"));
    return;
  }
  const y = {
    entries: [...e.entries, { id: E(), label: ((t == null ? void 0 : t.value) ?? "").trim(), server: n, bypass: "" }],
    active: e.active,
    link_librespot: e.link_librespot
  };
  try {
    e = await u("proxy_config_set", { config: y }), t && (t.value = ""), r && (r.value = ""), a(i("proxy.added"));
  } catch (c) {
    a(String(c));
  }
  await v();
}
async function q(t) {
  if (!e) return;
  const r = { entries: e.entries, active: e.active, link_librespot: t };
  try {
    e = await u("proxy_config_set", { config: r });
  } catch (o) {
    a(String(o)), await v();
    return;
  }
  const n = e.entries.find((o) => o.id === (e == null ? void 0 : e.active));
  t && n && await m(n.server), t || a(i("proxy.saved")), k();
}
function A() {
  return `<div class="plugin-result proxy-panel">
  <div class="proxy-head">
    <div class="proxy-title">${s(i("proxy.title"))}</div>
    <div class="proxy-state" id="proxy-state"></div>
  </div>
  <div class="proxy-list" id="proxy-list"></div>
  <div class="proxy-form">
    <input id="proxy-label" type="text" autocomplete="off" spellcheck="false" placeholder="${s(i("proxy.label_ph"))}" />
    <input id="proxy-server" type="text" autocomplete="off" spellcheck="false" placeholder="${s(i("proxy.server_ph"))}" />
    <button type="button" class="proxy-btn primary" id="proxy-add">${s(i("proxy.add"))}</button>
  </div>
  <label class="proxy-link">
    <input type="checkbox" id="proxy-link" />
    <span>${s(i("proxy.link"))}</span>
  </label>
  <div class="proxy-hint">${s(i("proxy.link_hint"))}</div>
  <div class="proxy-hint">${s(i("proxy.hint"))}</div>
  <div class="proxy-msg" id="proxy-msg"></div>
</div>`;
}
const D = {
  id: "proxy",
  name: "Proxy",
  keywords: ["proxy", "代理", "系统代理", "梯子", "vpn", "socks5", "http proxy", "clash"],
  description: "系统代理管理 + 让本机播放（librespot）走代理",
  icon: "🌐",
  badge: "Network",
  // 接管型：面板 HTML 写进结果区、切成 detached（与 OCR 同一条路，见 attach.ts）
  permissions: ["layout.takeover"],
  execute: async () => ({ type: "html", content: A() })
};
async function I() {
  var t, r, n, o;
  (t = d("#proxy-list")) == null || t.addEventListener("click", (y) => {
    const c = y.target.closest("[data-act]"), b = c == null ? void 0 : c.closest(".proxy-row"), _ = b == null ? void 0 : b.dataset.id;
    if (!c || !_) return;
    const h = c.dataset.act;
    h === "enable" ? H(_) : h === "disable" ? g() : h === "del" && P(_);
  }), (r = d("#proxy-add")) == null || r.addEventListener("click", () => void w());
  for (const y of ["#proxy-label", "#proxy-server"])
    (n = d(y)) == null || n.addEventListener("keydown", (c) => {
      c.key === "Enter" && w();
    });
  (o = d("#proxy-link")) == null || o.addEventListener("change", (y) => {
    q(y.target.checked);
  }), await v();
}
function M() {
  x !== void 0 && (window.clearTimeout(x), x = void 0), e = null, p = null, l = !1;
}
export {
  I as attach,
  D as default,
  M as detach,
  D as proxyPlugin
};
