async function y(t, o = {}, n) {
  return window.__TAURI_INTERNALS__.invoke(t, o, n);
}
const U = "__lunac_host";
function Y() {
  return globalThis[U] ?? null;
}
function i(t, o) {
  const n = Y();
  return n && typeof n.t == "function" ? n.t(t, o) : t;
}
let e = null, _ = null, f = null, E = [], b = !1, h = !1, $;
function r(t) {
  return t.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
function l(t) {
  return document.querySelector(t);
}
function c(t) {
  const o = l("#proxy-msg");
  o && (o.textContent = t, $ !== void 0 && window.clearTimeout($), $ = window.setTimeout(() => {
    const n = l("#proxy-msg");
    n && (n.textContent = ""), $ = void 0;
  }, 3e3));
}
function z() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
}
function G(t) {
  const o = t.trim();
  return o ? /\s/.test(o) ? i("proxy.err_space") : o.includes(":") ? null : i("proxy.err_port") : i("proxy.err_empty");
}
function J(t) {
  const o = t.trim().toLowerCase();
  return o.startsWith("http://") || o.startsWith("https://");
}
async function k() {
  try {
    e = await y("proxy_config_get");
  } catch (t) {
    c(String(t));
    return;
  }
  try {
    _ = await y("proxy_system_get");
  } catch {
    _ = null;
  }
  await A(), F();
}
async function A() {
  try {
    f = await y("mihomo_status");
  } catch {
    f = null;
  }
  if (f != null && f.running)
    try {
      E = await y("mihomo_proxies");
    } catch {
      E = [];
    }
  else
    E = [];
}
function F() {
  X(), K(), M();
  const t = l("#proxy-link");
  t && document.activeElement !== t && (t.checked = !!(e != null && e.link_librespot));
}
function K() {
  const t = e == null ? void 0 : e.mihomo, o = f, n = (d, g) => {
    const w = l(d);
    w && document.activeElement !== w && !w.value && (w.value = g);
  };
  t && (n("#mihomo-port", String(t.mixed_port)), n("#mihomo-ctrl", String(t.controller_port)), n("#mihomo-release", t.release_base));
  const s = l("#mihomo-state");
  s && (o ? o.installed ? o.running ? s.textContent = i("proxy.m_running", { ver: o.version, port: String(o.mixed_port) }) : s.textContent = i("proxy.m_stopped", { ver: o.version }) : s.textContent = i("proxy.m_need_core") : s.textContent = "", s.classList.toggle("warn", !!(o != null && o.installed) && !(o != null && o.running)));
  const p = l("#mihomo-actions");
  if (p) {
    const d = b ? " disabled" : "";
    if (o != null && o.installed ? o.running ? p.innerHTML = `<button type="button" class="proxy-btn danger" id="mihomo-stop"${d}>${r(i("proxy.m_stop"))}</button>` : p.innerHTML = `<button type="button" class="proxy-btn primary" id="mihomo-start"${d}>${r(i("proxy.m_start"))}</button>` : p.innerHTML = `<button type="button" class="proxy-btn primary" id="mihomo-install"${d}>${r(i("proxy.m_install"))}</button>`, b) {
      const g = document.createElement("span");
      g.className = "proxy-row-note", g.textContent = i("proxy.m_working"), p.appendChild(g);
    }
  }
  const v = l("#mihomo-mode");
  v && t && v.querySelectorAll("[data-mode]").forEach((d) => {
    d.classList.toggle("on", d.dataset.mode === t.mode);
  }), Q(t), H();
}
function Q(t) {
  const o = l("#mihomo-subs");
  if (!o) return;
  const n = (t == null ? void 0 : t.subscriptions) ?? [];
  if (n.length === 0) {
    o.innerHTML = `<div class="proxy-empty">${r(i("proxy.m_no_subs"))}</div>`;
    return;
  }
  o.innerHTML = n.map(
    (s, p) => `<div class="proxy-row" data-sub="${p}">
      <div class="proxy-row-main">
        <div class="proxy-row-label">${r(s.name || i("proxy.m_unnamed"))}</div>
        <div class="proxy-row-server">${r(s.url)}</div>
      </div>
      <button type="button" class="proxy-btn danger" data-mact="sub-del"${b ? " disabled" : ""}>${r(i("proxy.del"))}</button>
    </div>`
  ).join("");
}
function H() {
  const t = l("#mihomo-nodes");
  if (t) {
    if (!(f != null && f.running)) {
      t.innerHTML = "";
      return;
    }
    if (E.length === 0) {
      t.innerHTML = `<div class="proxy-empty">${r(i("proxy.m_no_nodes"))}</div>`;
      return;
    }
    t.innerHTML = E.map((o) => {
      const n = V(o), s = n === null ? "dim" : n > 800 ? "bad" : "ok", p = n === null ? "—" : `${n} ms`;
      if (o.is_group) {
        const v = [...o.all].map(
          (d) => `<button type="button" class="proxy-seg-btn${d === o.now ? " on" : ""}" data-group-pick="${r(d)}"${b ? " disabled" : ""}>${r(d)}</button>`
        ).join("");
        return `<div class="proxy-row proxy-row-group" data-group="${r(o.name)}">
          <div class="proxy-row-main">
            <div class="proxy-row-label">${r(o.name)}<span class="proxy-tag">${r(o.type)}</span></div>
            <div class="proxy-seg proxy-seg-wrap">${v}</div>
          </div>
        </div>`;
      }
      return `<div class="proxy-row" data-node="${r(o.name)}">
        <div class="proxy-row-main">
          <div class="proxy-row-label">${r(o.name)}<span class="proxy-tag">${r(o.type)}</span></div>
        </div>
        <span class="proxy-delay ${s}">${r(p)}</span>
        <button type="button" class="proxy-btn" data-mact="delay" data-name="${r(o.name)}"${b ? " disabled" : ""}>${r(i("proxy.m_test"))}</button>
      </div>`;
    }).join("");
  }
}
function V(t) {
  const o = t.history;
  if (!Array.isArray(o) || o.length === 0) return null;
  const n = o[o.length - 1], s = Number(n == null ? void 0 : n.delay);
  return Number.isFinite(s) && s > 0 ? s : null;
}
function X() {
  const t = l("#proxy-state");
  if (!t) return;
  if (!_) {
    t.textContent = "";
    return;
  }
  const o = e == null ? void 0 : e.entries.find((n) => n.id === (e == null ? void 0 : e.active));
  if (_.enabled ? t.textContent = i("proxy.state_on", { server: _.server }) : t.textContent = i("proxy.state_off"), t.classList.toggle("warn", !_.enabled && !!o), !_.enabled && o) {
    const n = o.label || o.server;
    t.textContent += "  " + i("proxy.state_mismatch", { label: n });
  }
}
function M() {
  const t = l("#proxy-list");
  if (!t) return;
  const o = (e == null ? void 0 : e.entries) ?? [];
  if (o.length === 0) {
    t.innerHTML = `<div class="proxy-empty">${r(i("proxy.empty"))}</div>`;
    return;
  }
  t.innerHTML = o.map((n) => {
    const s = (e == null ? void 0 : e.active) === n.id, p = !J(n.server);
    return `<div class="proxy-row${s ? " on" : ""}" data-id="${r(n.id)}">
        <div class="proxy-row-main">
          <div class="proxy-row-label">${r(n.label || n.server)}${s ? `<span class="proxy-tag">${r(i("proxy.in_use"))}</span>` : ""}</div>
          <div class="proxy-row-server">${r(n.server)}${p ? `<span class="proxy-row-note">${r(i("proxy.socks_note"))}</span>` : ""}</div>
        </div>
        <button type="button" class="proxy-btn${s ? "" : " primary"}" data-act="${s ? "disable" : "enable"}"${h ? " disabled" : ""}>${r(i(s ? "proxy.disable" : "proxy.enable"))}</button>
        <button type="button" class="proxy-btn danger" data-act="del"${h ? " disabled" : ""}>${r(i("proxy.del"))}</button>
      </div>`;
  }).join("");
}
async function T(t) {
  try {
    await y("librespot_set_proxy", { proxy: t });
  } catch (o) {
    c(i("proxy.err_librespot", { err: String(o) }));
  }
}
async function Z(t) {
  const o = e == null ? void 0 : e.entries.find((n) => n.id === t);
  if (!(!o || h)) {
    h = !0, M();
    try {
      _ = await y("proxy_enable", { id: t });
    } catch (n) {
      h = !1, c(String(n)), M();
      return;
    }
    h = !1, e != null && e.link_librespot && await T(o.server), _.enabled || c(i("proxy.err_not_applied")), await k();
  }
}
async function O() {
  if (!h) {
    h = !0, M();
    try {
      _ = await y("proxy_disable");
    } catch (t) {
      h = !1, c(String(t)), M();
      return;
    }
    h = !1, e != null && e.link_librespot && await T(""), await k();
  }
}
async function tt(t) {
  if (!e || h || e.active === t && (await O(), !e))
    return;
  const o = {
    entries: e.entries.filter((n) => n.id !== t),
    active: e.active === t ? "" : e.active,
    link_librespot: e.link_librespot
  };
  try {
    e = await y("proxy_config_set", { config: o }), c(i("proxy.removed"));
  } catch (n) {
    c(String(n));
  }
  await k();
}
async function R() {
  if (!e) return;
  const t = l("#proxy-label"), o = l("#proxy-server"), n = ((o == null ? void 0 : o.value) ?? "").trim(), s = G(n);
  if (s) {
    c(s);
    return;
  }
  if (e.entries.some((v) => v.server.trim() === n)) {
    c(i("proxy.err_dup"));
    return;
  }
  const p = {
    entries: [...e.entries, { id: z(), label: ((t == null ? void 0 : t.value) ?? "").trim(), server: n, bypass: "" }],
    active: e.active,
    link_librespot: e.link_librespot
  };
  try {
    e = await y("proxy_config_set", { config: p }), t && (t.value = ""), o && (o.value = ""), c(i("proxy.added"));
  } catch (v) {
    c(String(v));
  }
  await k();
}
async function ot(t) {
  if (!e) return;
  const o = { entries: e.entries, active: e.active, link_librespot: t };
  try {
    e = await y("proxy_config_set", { config: o });
  } catch (s) {
    c(String(s)), await k();
    return;
  }
  const n = e.entries.find((s) => s.id === (e == null ? void 0 : e.active));
  t && n && await T(n.server), t || c(i("proxy.saved")), F();
}
async function S(t) {
  if (!b) {
    b = !0, K();
    try {
      await t();
    } catch (o) {
      c(String(o));
    }
    b = !1, await k();
  }
}
async function N(t, o) {
  f = await y("mihomo_config_set", { cfg: t }), c(i(o));
}
async function et() {
  await S(async () => {
    const t = await y("mihomo_install_core");
    c(t);
  });
}
async function nt() {
  await S(async () => {
    f = await y("mihomo_start"), e != null && e.link_librespot && await T(`http://127.0.0.1:${f.mixed_port}`);
  });
}
async function it() {
  await S(async () => {
    f = await y("mihomo_stop"), e != null && e.link_librespot && await T("");
  });
}
async function rt() {
  var p, v, d;
  const t = e == null ? void 0 : e.mihomo;
  if (!t) return;
  const o = Number((((p = l("#mihomo-port")) == null ? void 0 : p.value) ?? "").trim()) || t.mixed_port, n = Number((((v = l("#mihomo-ctrl")) == null ? void 0 : v.value) ?? "").trim()) || t.controller_port;
  if (o === n) {
    c(i("proxy.m_err_same_port"));
    return;
  }
  const s = (((d = l("#mihomo-release")) == null ? void 0 : d.value) ?? "").trim();
  await S(
    () => N({ ...t, mixed_port: o, controller_port: n, release_base: s }, "proxy.m_saved")
  );
}
async function W() {
  const t = e == null ? void 0 : e.mihomo;
  if (!t || b) return;
  const o = l("#mihomo-sub-name"), n = l("#mihomo-sub-url"), s = ((n == null ? void 0 : n.value) ?? "").trim();
  if (!/^https?:\/\//i.test(s)) {
    c(i("proxy.m_err_url"));
    return;
  }
  const p = ((o == null ? void 0 : o.value) ?? "").trim() || `sub_${t.subscriptions.length}`;
  if (t.subscriptions.some((v) => v.url === s)) {
    c(i("proxy.err_dup"));
    return;
  }
  o && (o.value = ""), n && (n.value = ""), await S(() => N({ ...t, subscriptions: [...t.subscriptions, { name: p, url: s }] }, "proxy.m_saved"));
}
async function st(t) {
  const o = e == null ? void 0 : e.mihomo;
  o && await S(
    () => N({ ...o, subscriptions: o.subscriptions.filter((n, s) => s !== t) }, "proxy.m_saved")
  );
}
async function at(t) {
  await S(async () => {
    f = await y("mihomo_set_mode", { mode: t });
  });
}
async function lt(t) {
  if (!b) {
    b = !0, H();
    try {
      const o = await y("mihomo_delay", { name: t });
      c(i("proxy.m_delay_ok", { name: t, ms: String(o) }));
    } catch (o) {
      c(String(o));
    }
    b = !1, await A(), H();
  }
}
async function ct(t, o) {
  if (!b) {
    b = !0;
    try {
      await y("mihomo_select", { group: t, node: o });
    } catch (n) {
      c(String(n));
    }
    b = !1, await A(), H();
  }
}
async function B() {
  try {
    const t = await y("mihomo_log"), o = l("#mihomo-log");
    o && (o.textContent = t || i("proxy.m_log_empty"));
  } catch (t) {
    c(String(t));
  }
}
function pt() {
  return `<div class="plugin-result proxy-panel">
  <div class="proxy-head">
    <div class="proxy-title">${r(i("proxy.title"))}</div>
    <div class="proxy-state" id="proxy-state"></div>
  </div>

  <div class="proxy-body">
    <nav class="proxy-nav" id="proxy-nav">
      <button type="button" class="proxy-nav-btn on" data-page="proxies">${r(i("proxy.nav_proxies"))}</button>
      <button type="button" class="proxy-nav-btn" data-page="subs">${r(i("proxy.nav_subs"))}</button>
      <button type="button" class="proxy-nav-btn" data-page="log">${r(i("proxy.nav_log"))}</button>
      <button type="button" class="proxy-nav-btn" data-page="settings">${r(i("proxy.nav_settings"))}</button>
    </nav>

    <div class="proxy-pages">
      <section class="proxy-page on" data-page="proxies">
        <div class="proxy-sec-title">${r(i("proxy.m_title"))}</div>
        <div class="proxy-state" id="mihomo-state" title="${r(i("proxy.m_hint"))}"></div>
        <div class="proxy-actions" id="mihomo-actions"></div>
        <div class="proxy-seg" id="mihomo-mode">
          <button type="button" class="proxy-seg-btn" data-mode="rule">rule</button>
          <button type="button" class="proxy-seg-btn" data-mode="global">global</button>
          <button type="button" class="proxy-seg-btn" data-mode="direct">direct</button>
        </div>
        <div class="proxy-list" id="mihomo-nodes"></div>
      </section>

      <section class="proxy-page" data-page="subs">
        <div class="proxy-list" id="mihomo-subs"></div>
        <div class="proxy-form">
          <input id="mihomo-sub-name" type="text" autocomplete="off" spellcheck="false" placeholder="${r(i("proxy.m_sub_name_ph"))}" />
          <input id="mihomo-sub-url" type="text" autocomplete="off" spellcheck="false" placeholder="${r(i("proxy.m_sub_url_ph"))}" />
          <button type="button" class="proxy-btn primary" id="mihomo-sub-add">${r(i("proxy.m_sub_add"))}</button>
        </div>
      </section>

      <section class="proxy-page" data-page="log">
        <div class="proxy-form">
          <button type="button" class="proxy-btn" id="mihomo-log-btn">${r(i("proxy.m_log"))}</button>
        </div>
        <pre class="proxy-log" id="mihomo-log"></pre>
      </section>

      <section class="proxy-page" data-page="settings">
        <div class="proxy-form">
          <input id="mihomo-port" type="number" min="1" max="65535" autocomplete="off" placeholder="${r(i("proxy.m_port_ph"))}" />
          <input id="mihomo-ctrl" type="number" min="1" max="65535" autocomplete="off" placeholder="${r(i("proxy.m_ctrl_ph"))}" />
          <button type="button" class="proxy-btn" id="mihomo-save">${r(i("proxy.m_save"))}</button>
        </div>
        <div class="proxy-form">
          <input id="mihomo-release" type="text" autocomplete="off" spellcheck="false" placeholder="${r(i("proxy.m_release_ph"))}" />
        </div>
        <div class="proxy-sec-title" title="${r(i("proxy.hint"))}">${r(i("proxy.manual_title"))}</div>
        <div class="proxy-list" id="proxy-list"></div>
        <div class="proxy-form">
          <input id="proxy-label" type="text" autocomplete="off" spellcheck="false" placeholder="${r(i("proxy.label_ph"))}" />
          <input id="proxy-server" type="text" autocomplete="off" spellcheck="false" placeholder="${r(i("proxy.server_ph"))}" />
          <button type="button" class="proxy-btn primary" id="proxy-add">${r(i("proxy.add"))}</button>
        </div>
        <label class="proxy-link" title="${r(i("proxy.link_hint"))}">
          <input type="checkbox" id="proxy-link" />
          <span>${r(i("proxy.link"))}</span>
        </label>
        <div class="proxy-msg" id="proxy-msg"></div>
      </section>
    </div>
  </div>
</div>`;
}
const dt = {
  id: "proxy",
  name: "Proxy",
  keywords: ["proxy", "代理", "系统代理", "梯子", "vpn", "socks5", "http proxy", "clash", "mihomo", "订阅", "节点"],
  description: "系统代理管理 + mihomo 内核托管（订阅 / 测速 / 规则）+ 本机播放走代理",
  icon: "🌐",
  badge: "Network",
  // 接管型：面板 HTML 写进结果区、切成 detached（与 OCR 同一条路，见 attach.ts）
  permissions: ["layout.takeover"],
  execute: async () => ({ type: "html", content: pt() })
};
async function ut() {
  var o, n, s, p, v, d, g, w, q, D, P, j, I;
  const t = l(".proxy-panel");
  (o = t == null ? void 0 : t.querySelector("#proxy-nav")) == null || o.addEventListener("click", (m) => {
    const a = m.target.closest("[data-page]"), u = a == null ? void 0 : a.dataset.page;
    !t || !u || a != null && a.classList.contains("on") || (t.querySelectorAll("#proxy-nav [data-page]").forEach((x) => {
      x.classList.toggle("on", x.dataset.page === u);
    }), t.querySelectorAll(".proxy-page").forEach((x) => {
      x.classList.toggle("on", x.dataset.page === u);
    }), u === "log" && B());
  }), (n = l("#proxy-list")) == null || n.addEventListener("click", (m) => {
    const a = m.target.closest("[data-act]"), u = a == null ? void 0 : a.closest(".proxy-row"), x = u == null ? void 0 : u.dataset.id;
    if (!a || !x) return;
    const L = a.dataset.act;
    L === "enable" ? Z(x) : L === "disable" ? O() : L === "del" && tt(x);
  }), (s = l("#proxy-add")) == null || s.addEventListener("click", () => void R()), (p = l("#mihomo-actions")) == null || p.addEventListener("click", (m) => {
    const a = m.target.id;
    a === "mihomo-install" ? et() : a === "mihomo-start" ? nt() : a === "mihomo-stop" && it();
  }), (v = l("#mihomo-subs")) == null || v.addEventListener("click", (m) => {
    const a = m.target.closest("[data-mact='sub-del']"), u = a == null ? void 0 : a.closest("[data-sub]"), x = u == null ? void 0 : u.dataset.sub;
    a && x !== void 0 && st(Number(x));
  }), (d = l("#mihomo-nodes")) == null || d.addEventListener("click", (m) => {
    const a = m.target, u = a.closest("[data-group-pick]");
    if ((u == null ? void 0 : u.dataset.groupPick) !== void 0) {
      const C = u.closest("[data-group]");
      C != null && C.dataset.group && ct(C.dataset.group, u.dataset.groupPick);
      return;
    }
    const x = a.closest("[data-mact='delay']"), L = x == null ? void 0 : x.dataset.name;
    x && L && lt(L);
  }), (g = l("#mihomo-save")) == null || g.addEventListener("click", () => void rt()), (w = l("#mihomo-sub-add")) == null || w.addEventListener("click", () => void W());
  for (const m of ["#mihomo-sub-name", "#mihomo-sub-url"])
    (q = l(m)) == null || q.addEventListener("keydown", (a) => {
      a.key === "Enter" && W();
    });
  (D = l("#mihomo-mode")) == null || D.addEventListener("click", (m) => {
    const a = m.target.closest("[data-mode]");
    a != null && a.dataset.mode && at(a.dataset.mode);
  }), (P = l("#mihomo-log-btn")) == null || P.addEventListener("click", () => void B());
  for (const m of ["#proxy-label", "#proxy-server"])
    (j = l(m)) == null || j.addEventListener("keydown", (a) => {
      a.key === "Enter" && R();
    });
  (I = l("#proxy-link")) == null || I.addEventListener("change", (m) => {
    ot(m.target.checked);
  }), await k();
}
function yt() {
  $ !== void 0 && (window.clearTimeout($), $ = void 0), e = null, _ = null, f = null, E = [], h = !1, b = !1;
}
export {
  ut as attach,
  dt as default,
  yt as detach,
  dt as proxyPlugin
};
