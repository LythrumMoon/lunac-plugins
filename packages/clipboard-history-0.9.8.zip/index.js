async function y(o, t = {}, n) {
  return window.__TAURI_INTERNALS__.invoke(o, t, n);
}
async function m(o, t) {
  await y("plugin:clipboard-manager|write_text", {
    label: t == null ? void 0 : t.label,
    text: o
  });
}
const h = "__lunac_host";
function v() {
  return globalThis[h] ?? null;
}
function i(o, t) {
  const n = v();
  return n && typeof n.t == "function" ? n.t(o, t) : o;
}
const _ = 30;
async function f() {
  try {
    return await y("load_clipboard_history");
  } catch {
    return [];
  }
}
async function b(o) {
  try {
    await y("save_clipboard_history", {
      entries: o.slice(0, _)
    });
  } catch {
  }
}
function x(o) {
  return o.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
const S = {
  id: "clipboard-history",
  name: "Clipboard History",
  keywords: ["clipboard", "history", "paste", "剪切板", "历史", "剪贴板", "粘贴", "复制"],
  description: "Clipboard history manager — auto-saves on copy",
  icon: "📋",
  badge: "History",
  execute: async (o) => {
    const t = await f();
    if (t.length === 0)
      return {
        type: "html",
        content: `<div style="color:var(--text-dim);padding:16px 12px;">
          ${i("clipboard.empty")}
        </div>`
      };
    const n = Date.now(), u = t.map((r, e) => {
      const s = w(n - r.time), a = r.clip_type === "file", c = a && r.text.split(/[\\/]/).pop() || r.text, l = c.length > 80 ? c.slice(0, 80).replace(/\n/g, " ") + "…" : c.replace(/\n/g, " "), d = a ? "📁" : "📋", p = a ? "" : ` · ${i("clipboard.chars", { count: String(r.text.length) })}`;
      return `
        <div class="clip-item" data-idx="${e}" title="${x(r.text)}">
          <span class="clip-item-icon" style="flex-shrink:0;font-size:1rem;">${d}</span>
          <div class="clip-item-preview">${x(l)}</div>
          <div class="clip-item-meta">${s}${p}</div>
          <button class="clip-item-copy" data-idx="${e}" title="${i("clipboard.copy_tooltip")}">${i("clipboard.copy_label")}</button>
        </div>`;
    }).join(""), g = `
      <div class="plugin-result">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;">
          <span style="font-size:0.72rem;color:var(--text-dim);">${i("clipboard.items", { count: String(t.length) })}</span>
          <button id="clip-clear-all" style="font-size:0.68rem;background:none;border:none;color:var(--red);cursor:pointer;opacity:0.7;">${i("clipboard.clear_all")}</button>
        </div>
        ${u}
      </div>
    `;
    return setTimeout(() => {
      var r;
      document.querySelectorAll(".clip-item-copy").forEach((e) => {
        e.addEventListener("click", async (s) => {
          s.stopPropagation();
          const a = parseInt(e.dataset.idx || "0"), c = t[a];
          if (c)
            try {
              await m(c.text);
              const l = await f(), d = l.findIndex((p) => p.text === c.text);
              if (d >= 0) {
                const [p] = l.splice(d, 1);
                l.unshift(p), await b(l);
              }
              e.textContent = i("clipboard.copied"), setTimeout(() => {
                e.textContent = i("clipboard.copy_label");
              }, 1500);
            } catch {
              e.textContent = i("clipboard.copy_failed"), setTimeout(() => {
                e.textContent = i("clipboard.copy_label");
              }, 1500);
            }
        });
      }), document.querySelectorAll(".clip-item").forEach((e) => {
        e.addEventListener("click", async () => {
          const s = parseInt(e.dataset.idx || "0"), a = t[s];
          if (a)
            try {
              await m(a.text), e.querySelector(".clip-item-copy").textContent = i("clipboard.copied"), setTimeout(() => {
                const c = e.querySelector(".clip-item-copy");
                c && (c.textContent = i("clipboard.copy_label"));
              }, 1500);
            } catch {
            }
        });
      }), (r = document.getElementById("clip-clear-all")) == null || r.addEventListener("click", async () => {
        await b([]);
        const e = document.querySelector(".plugin-result");
        e && (e.innerHTML = `<div style="color:var(--text-dim);padding:16px 12px;">${i("clipboard.cleared")}</div>`);
      });
    }, 50), { type: "html", content: g };
  }
};
function w(o) {
  if (o < 6e4) return i("clipboard.just_now");
  const t = Math.floor(o / 6e4);
  if (t < 60) return i("clipboard.m_ago", { m: String(t) });
  const n = Math.floor(t / 60);
  if (n < 24) return i("clipboard.h_ago", { h: String(n) });
  const u = Math.floor(n / 24);
  return i("clipboard.d_ago", { d: String(u) });
}
export {
  S as clipboardHistoryPlugin,
  S as default
};
